# tradelab backtest - tree

tl_backtest v1.3.1 (tradelab v1.3.1), 2026-11-09T18:06:39. pick_meta run PM_20261017_001. Strategy strategies\tree.py (sha b9d3159e5d8de78f, mode daily), compared with plan.
Tag: -. Declared rule: descriptive: ENS tree vs all ENS top-3 at the open, 2021-2026.

## Verdict first

- Per pick slot: strategy **+79.3 [+42.8, +114.3] bp**, plan +93.7 [+43.4, +143.7] bp, difference **-14.4 [-39.6, +11.9] bp -> NOT SHOWN (interval spans 0)** (4,241 picks, 1,414 signal days).
- On the picks the strategy actually traded (3,168): difference +86.5 [+68.1, +108.1] bp.
- Picks the plan finished but the strategy could not trade (0, {}): the plan made n/a bp on them vs +93.7 [+43.4, +143.7] bp on the paired picks - a large gap means the pairing is not a fair sample.
- Entered 74.7% of picks; average size used 0.75 of the target; net on the money actually used +106.2 bp.

## Money view (one account, the strategy's sizing)

| | strategy | plan |
|---|---|---|
| CAGR | +72.11% | +79.64% |
| worst drawdown | -37.54% (2025-12-23 -> 2026-04-07) | -40.02% (2021-10-08 -> 2022-02-01) |
| Sharpe (daily x sqrt 252) | 1.66 | 1.65 |
| average exposure | 0.76 | 0.80 |
| trades opened | 837 | 841 |
| skipped (reason) | {'max_open': 2331} | {'max_open': 3400} |
| legs trimmed / skipped by cash | 264 / 0 | 244 / 0 |

Daily return difference: -2.30 [-14.47, +9.30] bp a day -> NOT SHOWN (interval spans 0).

## Detail

- Win rate: strategy 38.6%, plan 50.6%.
- Legs filled (share of entered picks): {'tree': 1.0}.
- Exit reasons: {'tree': 3168}.
- Median MFE +4.48%, median MAE -3.27% (from the first buy, while held).
- Average exit session 5.14; locked exits 106; bars where a stop and a target were both inside the bar (settled by the 'worst' policy): 0.
- Left out of the pairing: strategy {'not_entered': 1}, plan {'stuck': 1}.

### By year (bp per pick)

| year | picks | strategy | plan | difference |
|---|---|---|---|---|
| 2021 | 744 | +104.1 | +139.2 | -35.1 |
| 2022 | 744 | +105.3 | +102.1 | +3.2 |
| 2023 | 738 | +63.0 | +96.0 | -33.0 |
| 2024 | 746 | +92.6 | +160.2 | -67.6 |
| 2025 | 747 | +71.9 | +19.8 | +52.2 |
| 2026 | 522 | +21.5 | +24.3 | -2.9 |

### By engine and rank (bp per pick)

| engine | rank | picks | strategy | plan | difference |
|---|---|---|---|---|---|
| ENS | 1 | 1,413 | +110.7 | +115.4 | -4.8 |
| ENS | 2 | 1,414 | +76.9 | +102.8 | -25.9 |
| ENS | 3 | 1,414 | +50.3 | +62.8 | -12.5 |

## How much to trust this

- The tradelab ledger held 1 earlier backtests (1 distinct strategy files) before this one. With 20 variants tried on the same years, about one will look BETTER at the 95% level by luck alone.
- Same 2020-2026 history the engines were built and studied on. Treat any edge found here as a hypothesis: declare the rule (--declare, decision_rule) and judge it on the forward paper ledger.
- Costs: flat 35 bp round trip on entry notional (half at buy, half at sale); slippage 0.0 bp a side. Fills: next-bar opens, stop / limit levels from the previous bar, official open / close for 'at' orders, honest lower-circuit exits.
- Not modelled: upper-circuit buys that cannot fill, partial fills, market impact beyond the cost model.

## Decision rule: {'rule': {'metric': 'diff_mean_bp', 'pass_if': 'lower > 0'}, 'value': -39.5728648551259, 'verdict': 'FAIL'}

## Market context and stock state: where the strategy helps or hurts (v1.1, states v1.3.1)

### The money by environment (known at the previous close)

Each account's daily returns grouped by the environment known before the day began: mean day return (bp, 95% block-bootstrap interval), the worst drawdown inside that environment (its days chained), average exposure and the most positions open at once.

| account | environment | days | mean day bp | total | worst drawdown inside | worst day bp | avg exposure | max positions |
|---|---|---|---|---|---|---|---|---|
| tree | broad_bullish | 426 (30%) | +29.87 [+10.11, +49.07] | +228.05% | -21.42% | -624 | 0.78 | 3 |
| tree | narrow_bullish | 383 (27%) | +34.55 [+12.80, +57.36] | +242.24% | -20.70% | -649 | 0.76 | 3 |
| tree | mixed | 194 (14%) | +8.71 [-23.59, +42.64] | +11.83% | -28.77% | -672 | 0.75 | 3 |
| tree | broad_bearish | 224 (16%) | +15.24 [-23.39, +52.25] | +29.52% | -27.73% | -1065 | 0.71 | 3 |
| tree | high_stress | 191 (13%) | +20.37 [-24.64, +57.93] | +36.84% | -35.88% | -673 | 0.76 | 3 |
| plan | broad_bullish | 426 (30%) | +29.39 [+11.23, +48.11] | +219.26% | -15.08% | -871 | 0.80 | 3 |
| plan | narrow_bullish | 383 (27%) | +30.29 [+8.13, +52.89] | +188.15% | -22.29% | -657 | 0.80 | 3 |
| plan | mixed | 194 (14%) | +21.56 [-9.42, +51.99] | +41.43% | -20.72% | -900 | 0.80 | 3 |
| plan | broad_bearish | 224 (16%) | +14.91 [-35.93, +68.31] | +23.43% | -36.63% | -1064 | 0.81 | 3 |
| plan | high_stress | 191 (13%) | +34.44 [-11.15, +83.75] | +77.00% | -25.51% | -801 | 0.80 | 3 |

### The paired picks by the market and by the stock's state at the pick

'difference' = strategy - plan on the same picks, bp, 95% block-bootstrap intervals over signal days. Many groups are shown: a single group 'BETTER' is a hypothesis to declare and test forward, not a finding. Nothing here filters trades.

#### engine ENS

**environment at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| broad_bullish | 1,278 | 30% | +67.8 [+15.9, +117.4] | +61.3 [-2.7, +122.5] | +6.5 [-18.2, +31.9] | 42% | 11.7% |
| narrow_bullish | 1,149 | 27% | +79.3 [+31.0, +125.4] | +104.5 [+37.3, +173.3] | -25.2 [-72.5, +18.0] | 40% | 10.5% |
| mixed | 576 | 14% | +17.9 [-62.5, +90.9] | +25.2 [-100.0, +139.6] | -7.3 [-75.9, +65.6] | 32% | 12.5% |
| broad_bearish | 665 | 16% | +85.1 [-40.8, +198.9] | +86.3 [-98.9, +273.9] | -1.3 [-94.0, +92.7] | 37% | 14.9% |
| high_stress | 573 | 14% | +160.1 [+77.5, +238.8] | +221.7 [+96.8, +342.2] | -61.6 [-131.2, +6.5] | 38% | 9.6% |

**high stress at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no | 3,668 | 86% | +66.7 [+31.8, +102.1] | +73.7 [+22.7, +125.8] | -7.0 [-34.2, +20.0] | 39% | 12.0% |
| yes | 573 | 14% | +160.1 [+77.5, +238.8] | +221.7 [+96.8, +342.2] | -61.6 [-131.2, +6.5] | 38% | 9.6% |

**direction at the pick (stress ignored)** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| broad_bullish | 1,365 | 32% | +67.2 [+20.0, +116.9] | +59.1 [-2.7, +120.9] | +8.1 [-17.0, +33.3] | 41% | 11.6% |
| narrow_bullish | 1,314 | 31% | +101.3 [+47.4, +152.0] | +123.1 [+52.8, +192.6] | -21.8 [-65.3, +19.3] | 40% | 10.0% |
| mixed | 657 | 15% | +40.6 [-39.1, +114.9] | +61.2 [-59.0, +175.9] | -20.6 [-81.7, +42.7] | 34% | 11.6% |
| broad_bearish | 905 | 21% | +93.7 [-14.8, +198.5] | +126.7 [-32.8, +280.8] | -33.0 [-111.8, +45.1] | 36% | 14.3% |

**breadth at the pick (10-day A/D)** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < 0.40 | 444 | 10% | +166.4 [+71.3, +257.2] | +246.2 [+90.1, +402.4] | -79.9 [-179.7, +32.6] | 41% | 11.9% |
| 0.40 - 0.50 | 2,048 | 48% | +70.0 [+17.7, +121.3] | +86.6 [+17.4, +157.8] | -16.6 [-51.5, +17.1] | 36% | 11.8% |
| 0.50 - 0.60 | 1,629 | 38% | +60.5 [+16.5, +105.2] | +54.1 [-1.5, +111.1] | +6.4 [-20.1, +33.1] | 40% | 11.7% |
| >= 0.60 | 120 | 3% | +172.0 [+32.0, +285.9] | +189.0 [+58.7, +312.3] | -17.0 [-58.2, +25.2] | 48% | 9.2% |

**VIX 5-day change at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < -10% | 504 | 12% | +80.8 [+12.8, +147.5] | +69.0 [-21.4, +162.4] | +11.8 [-44.9, +67.0] | 36% | 11.3% |
| -10% .. 0% | 1,734 | 41% | +57.4 [+18.4, +96.3] | +60.7 [+8.8, +112.3] | -3.3 [-39.2, +28.5] | 39% | 11.7% |
| 0% .. +10% | 1,368 | 32% | +92.9 [+37.8, +145.1] | +118.1 [+37.2, +198.0] | -25.2 [-62.8, +16.6] | 38% | 11.8% |
| +10% .. +25% | 539 | 13% | +107.6 [+28.8, +185.8] | +149.4 [+40.9, +254.3] | -41.7 [-102.4, +17.4] | 40% | 11.5% |
| >= +25% | 96 | 2% | +114.0 [-54.0, +245.0] | +158.3 [-22.0, +383.3] | -44.4 [-238.3, +152.2] | 38% | 13.5% |

**NIFTY minus Smallcap, 20 days, at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < -3 pts (small caps ahead) | 1,188 | 28% | +38.5 [-21.4, +94.0] | +36.1 [-40.2, +105.5] | +2.4 [-26.8, +32.9] | 38% | 12.4% |
| -3 .. 0 pts | 1,508 | 36% | +80.6 [+29.6, +131.5] | +76.4 [+5.6, +142.8] | +4.2 [-29.8, +37.9] | 40% | 11.2% |
| 0 .. +3 pts | 960 | 23% | +92.2 [+14.8, +160.6] | +151.6 [+39.5, +271.2] | -59.4 [-120.0, -7.5] | 39% | 12.3% |
| >= +3 pts (NIFTY ahead: narrow) | 585 | 14% | +137.5 [+54.2, +225.7] | +160.1 [+5.4, +325.2] | -22.6 [-144.5, +88.6] | 34% | 10.6% |

**size class (AMFI)** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no list | 4,241 | 100% | +79.3 [+42.8, +114.3] | +93.7 [+43.4, +143.7] | -14.4 [-39.6, +11.9] | 39% | 11.7% |

**home index** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| NIFTY 50 | 303 | 7% | +20.6 [-117.9, +147.0] | +11.4 [-206.1, +204.7] | +9.2 [-68.9, +98.5] | 39% | 9.6% |
| Midcap 150 | 815 | 19% | +72.3 [-15.2, +150.0] | +59.3 [-30.5, +138.3] | +13.0 [-17.9, +48.0] | 44% | 11.0% |
| Smallcap 250 | 3,122 | 74% | +86.8 [+50.1, +124.8] | +110.7 [+55.2, +164.4] | -23.9 [-54.3, +6.3] | 37% | 12.1% |
| (blank) | 1 | 0% | +0.0 | -35.0 | +35.0 | 0% | 0.0% |

**stock state at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| S01 | 604 | 14% | +94.0 [+22.4, +161.5] | +79.0 [-27.7, +176.5] | +15.0 [-41.3, +71.3] | 42% | 12.3% |
| S02 | 260 | 6% | +80.5 [-32.2, +194.0] | +34.4 [-67.4, +140.8] | +46.1 [-2.4, +95.8] | 35% | 11.9% |
| S03 | 541 | 13% | +40.3 [-19.4, +99.0] | +40.0 [-21.8, +101.1] | +0.3 [-23.0, +27.4] | 44% | 11.1% |
| S06 | 102 | 2% | +294.1 [+71.4, +531.6] | +247.3 [-3.0, +506.0] | +46.8 [-17.5, +116.4] | 46% | 12.7% |
| S07 | 160 | 4% | +7.9 [-60.2, +75.6] | +59.4 [-51.1, +186.2] | -51.5 [-142.6, +17.2] | 39% | 6.9% |
| S08 | 464 | 11% | +123.2 [+39.7, +203.7] | +158.3 [+32.5, +286.3] | -35.1 [-136.1, +51.7] | 37% | 10.6% |
| S09 | 990 | 23% | +81.8 [+10.8, +155.8] | +126.3 [+16.5, +234.9] | -44.5 [-102.7, +10.8] | 37% | 11.5% |
| S12 | 3 | 0% | +0.0 | +535.8 | -535.8 | 0% | 0.0% |
| UNKNOWN | 1,117 | 26% | +60.3 [+1.1, +119.3] | +75.4 [+0.4, +149.2] | -15.0 [-54.8, +21.3] | 37% | 12.9% |

**state phase at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| EARLY | 1,059 | 25% | +74.5 [+24.0, +120.8] | +111.6 [+42.3, +178.6] | -37.1 [-79.4, +4.1] | 40% | 11.6% |
| MATURE | 1,560 | 37% | +83.1 [+34.1, +132.6] | +102.1 [+38.1, +166.3] | -19.0 [-53.1, +13.4] | 38% | 11.2% |
| DETERIORATING | 505 | 12% | +119.6 [+56.9, +182.8] | +70.7 [-24.5, +158.0] | +48.9 [-14.3, +114.2] | 41% | 10.9% |
| (blank) | 1,117 | 26% | +60.3 [+1.1, +119.3] | +75.4 [+0.4, +149.2] | -15.0 [-54.8, +21.3] | 37% | 12.9% |

**state confidence at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| HIGH | 1,455 | 34% | +81.3 [+32.4, +130.9] | +97.3 [+29.4, +172.1] | -16.0 [-61.3, +25.6] | 39% | 11.3% |
| MEDIUM | 1,164 | 27% | +77.5 [+32.8, +124.1] | +116.8 [+57.4, +179.7] | -39.3 [-76.3, -4.4] | 40% | 11.3% |
| LOW | 505 | 12% | +119.6 [+56.9, +182.8] | +70.7 [-24.5, +158.0] | +48.9 [-14.3, +114.2] | 41% | 10.9% |
| UNKNOWN | 1,117 | 26% | +60.3 [+1.1, +119.3] | +75.4 [+0.4, +149.2] | -15.0 [-54.8, +21.3] | 37% | 12.9% |

**event in the last 10 sessions** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| BREAKOUT:NEW | 289 | 7% | +133.9 [+17.2, +266.7] | +120.1 [-2.9, +259.3] | +13.8 [-21.7, +54.0] | 47% | 15.9% |
| BREAKOUT:CONFIRMED | 552 | 13% | +119.0 [+51.6, +189.2] | +122.6 [+43.7, +206.8] | -3.6 [-47.8, +38.3] | 40% | 9.8% |
| BREAKOUT:STALLED | 37 | 1% | -2.7 [-127.9, +138.1] | +51.6 [-116.2, +272.8] | -54.4 [-146.4, +2.2] | 38% | 10.8% |
| FAILED_BREAKOUT:FAILED | 459 | 11% | +58.1 [-7.4, +129.5] | +41.1 [-29.6, +112.9] | +17.0 [-29.7, +71.3] | 36% | 10.7% |
| BREAKDOWN:NEW | 1,177 | 28% | +96.0 [+30.8, +164.3] | +140.4 [+50.1, +230.2] | -44.4 [-93.0, +6.6] | 39% | 12.7% |
| BREAKDOWN:CONFIRMED | 479 | 11% | +39.7 [-89.0, +145.7] | +57.6 [-127.7, +225.6] | -17.9 [-112.1, +73.5] | 32% | 13.6% |
| BREAKDOWN:STALLED | 23 | 1% | +69.0 [-106.9, +284.6] | -5.6 [-235.8, +224.7] | +74.6 [-12.0, +161.2] | 26% | 8.7% |
| FAILED_BREAKDOWN:FAILED | 160 | 4% | -37.5 [-131.7, +67.6] | +11.2 [-135.5, +170.2] | -48.7 [-135.9, +28.7] | 34% | 13.8% |
| (blank) | 1,065 | 25% | +73.0 [+24.6, +123.7] | +74.8 [+11.3, +139.3] | -1.8 [-33.3, +30.9] | 40% | 9.8% |

**S05 overextension at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no | 4,100 | 97% | +79.4 [+43.1, +114.5] | +96.6 [+45.2, +148.0] | -17.2 [-43.5, +8.8] | 38% | 11.4% |
| overextended | 129 | 3% | +160.8 [+3.0, +325.4] | +89.2 [-105.9, +274.8] | +71.6 [-22.4, +177.8] | 48% | 18.6% |
| extreme | 12 | 0% | -844.2 | -855.7 | +11.5 | 0% | 33.3% |

**stock volatility at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| COMPRESSED | 658 | 16% | +101.4 [+36.1, +167.5] | +100.8 [+35.2, +166.7] | +0.6 [-0.0, +1.5] | 50% | 10.8% |
| NORMAL | 2,070 | 49% | +59.3 [+10.9, +106.0] | +52.3 [-7.3, +110.7] | +7.0 [-14.8, +32.6] | 41% | 14.4% |
| ELEVATED | 812 | 19% | +92.1 [+40.7, +142.7] | +130.7 [+54.1, +206.8] | -38.6 [-97.9, +20.0] | 31% | 8.1% |
| EXTREME | 701 | 17% | +102.8 [+35.2, +170.2] | +166.4 [+32.3, +293.0] | -63.5 [-159.6, +29.1] | 29% | 8.7% |

**Smallcap over the hold** - observed AFTER entry: explains, cannot select

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < -3% | 370 | 9% | -537.6 [-640.7, -435.9] | -618.8 [-729.8, -498.7] | +81.2 [+42.7, +125.4] | 21% | 49.2% |
| -3% .. -1% | 455 | 11% | -157.2 [-223.0, -91.9] | -210.5 [-287.0, -142.4] | +53.3 [+19.9, +100.6] | 31% | 26.6% |
| -1% .. +1% | 1,100 | 26% | +93.3 [+38.7, +149.3] | +22.4 [-38.6, +78.7] | +70.9 [+48.9, +96.5] | 49% | 10.9% |
| +1% .. +3% | 931 | 22% | +330.8 [+268.8, +400.2] | +250.6 [+179.8, +319.5] | +80.3 [+48.2, +120.6] | 67% | 5.9% |
| >= +3% | 312 | 7% | +628.6 [+478.1, +784.8] | +413.6 [+257.9, +541.5] | +214.9 [+132.1, +306.9] | 81% | 5.8% |
| (blank) | 1,073 | 25% | +0.0 [+0.0, +0.0] | +312.3 [+230.3, +388.2] | -312.3 [-388.2, -230.3] | 0% | 0.0% |


## Frozen setups (setuplab tags)

Tags TAGS_20261108_001 (setuplab v0.7), freeze sha256 483f1539324f3ae5, signal days ['2020-01-16', '2026-09-15']; they cover 4,159 of this run's picks. Columns in trades.csv: setups (e.g. S2@D3 = setup S2 entered on watch day 3), n_setups, su_<ID>_day, setups_tagged.

This strategy enters on its own rules: for it the tags are hindsight (a setup is known only on its own entry day) - describe trades with them, never pick trades by them.

## Calm / jumpy lanes and the entry tree (setuplab tree)

Tree run TREE_20261109_001 (setuplab v1.1), TREE.json sha256 5cd4571765c2de80, freeze 483f1539324f3ae5, history window ['2021-01-01', '2026-09-22'], RECONCILED with the declaration; it covers 4,159 of this run's picks. Lane = the pick's 14-session ATR / close against its year's cut-off (the 2/3 quantile of earlier years' picks): 2021 5.77%, 2022 5.64%, 2023 5.75%, 2024 5.35%, 2025 5.49%, 2026 5.52%. CALM = at or below, JUMPY = above; picks before the first cut-off year have no lane. The lane is known at the pick's close (a pre-pick breakdown); trades.csv also carries the tree's action on each rank 1-3 pick (tree_action, tree_how, tree_net, opened_up - hindsight: the tree decides at the open and on each setup's own day).

This strategy IS the tree: it buys where the tree bought (tree_how: 'open' = the D1 open, 'S2@D3' = setup S2's own day-3 open) and sells where the tree sold (the 5th close; N1 4 sessions after its entry); a pick the tree skips is not entered (0 bp). The comparison buys every pick at the D1 open. The money view uses tradelab's account (integer shares, its tie order: rank, then engine); setuplab's TREE.md is the reference for the tree's own book numbers. These years are the history the tree was declared on (descriptive); only the forward record judges it.

Paired picks by lane: strategy, plan and the difference (strategy - plan), bp, 95% block-bootstrap intervals over signal days. Descriptive: one lane 'BETTER' is a hypothesis.

| engine | lane | picks | entered | strategy bp | plan bp | difference bp | verdict |
|---|---|---|---|---|---|---|---|
| ENS | CALM | 2,561 | 2,561 | +75.6 [+29.7, +121.9] | +75.6 [+29.7, +121.9] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| ENS | JUMPY | 1,597 | 607 | +89.4 [+47.2, +131.1] | +127.7 [+40.0, +218.6] | -38.3 [-108.5, +29.0] | NOT SHOWN (interval spans 0) |
| ENS | no lane | 83 | 0 | +0.0 [+0.0, +0.0] | -2.0 [-69.5, +73.6] | +2.0 [-73.6, +69.5] | NOT SHOWN (interval spans 0) |
