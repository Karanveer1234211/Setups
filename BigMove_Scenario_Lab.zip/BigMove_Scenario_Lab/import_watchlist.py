"""Build a new research dataset from TradeLab exports without editing either source."""
import argparse, os, tarfile, tempfile
from pathlib import Path
import pandas as pd

def table(path, suffix):
    reader=pd.read_parquet if suffix.endswith('parquet') else pd.read_csv
    if path.is_dir():
        hits=list(path.rglob(Path(suffix).name))
        if len(hits)!=1:raise ValueError(f'Expected one {suffix}, found {len(hits)}')
        return reader(hits[0])
    with tarfile.open(path) as archive:
        names=[n for n in archive.getnames() if n.endswith('/'+suffix) or n==suffix]
        if len(names)!=1:raise ValueError(f'Expected one {suffix}, found {len(names)}')
        with archive.extractfile(names[0]) as f:return reader(f)

def build(journal,paths,out):
    if out.exists():raise ValueError('Choose a new dataset folder. Existing folders are preserved.')
    p=table(journal,'trades.parquet')
    p=p[p.engine.isin(['D','ENS']) & p['rank'].between(1,3)].copy()
    if not p.trade_id.is_unique:raise ValueError('Duplicate trade IDs in journal')
    cols=['trade_id','engine','symbol','rank','signal_day','entry_day','signal_close','status','entry','entry_gap','mfe','s_atr14','net_bp','score','prob_win','both_engines']
    cats={'pre_state','pre_env_direction','pre_state_phase','pre_state_event','pre_state_confidence','pre_state_vol_regime'}
    cols += [c for c in p if c.startswith('pre_') and (p[c].dtype.kind in 'bifu' or c in cats)]
    p['signal_day']=pd.to_datetime(p.signal_day)
    z=p[cols].copy()
    pathcols=[f'{name}_{i}' for name in ['close','overnight'] for i in range(1,11)]
    if paths:
        x=table(paths,'trades_paths.csv');x['signal_day']=pd.to_datetime(x.signal_day)
        z=z.merge(x[['signal_day','symbol','entry',*pathcols]],on=['signal_day','symbol','entry'],how='left',validate='many_to_one')
    else:
        for c in pathcols:z[c]=float('nan')
    raw=p.set_index('trade_id').loc[z.trade_id]
    for i in range(1,6):
        z[f'close_{i}']=raw[f'close_ret_s{i}'].to_numpy()
        if i>1:z[f'overnight_{i}']=(1+raw[f'open_ret_s{i}'].to_numpy())/(1+z[f'close_{i-1}'])-1
    z['overnight_1']=z.entry_gap
    cal=table(journal,'market_days.parquet')[['date']].drop_duplicates().sort_values('date')
    out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(dir=out.parent) as staging:
        data=Path(staging)/'dataset';data.mkdir()
        z.to_parquet(data/'watchlist.parquet',index=False);cal.to_parquet(data/'calendar.parquet',index=False)
        os.rename(data,out)
    print(f'Saved {len(z):,} picks across {z.signal_day.nunique():,} dates to {out}')
if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--journal',type=Path,required=True);ap.add_argument('--paths',type=Path)
    ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();build(a.journal,a.paths,a.out)
