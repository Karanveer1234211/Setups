"""Run replay checks and small timing fixtures with python verify.py."""
from copy import deepcopy
from tempfile import TemporaryDirectory
from pathlib import Path
import unittest
import pandas as pd
import numpy as np
from app import Feed,PRESETS,rule,event,preset,run
from engine import trigger,exit_trade,Missing,validate

class ReplayChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.feed=Feed()
    def test_master_reconciliations(self):
        for idx,count,mean in [(0,1683,.9459633333),(1,420,.2102794582),(2,420,1.5235695408)]:
            r=run(self.feed,PRESETS[idx])
            self.assertEqual((r['n'],r['missing']),(count,0))
            self.assertAlmostEqual(r['mean'],mean,places=7)
    def test_unsupported_close_feature_at_open(self):
        with self.assertRaises(ValueError):validate(self.feed,preset('bad',[event('open',rule('rsi14','>',50))]))
    def test_cap_and_matched_cohort(self):
        r=run(self.feed,dict(PRESETS[0],one=True));z=[x for x in r['rows'] if x['status']=='Filled']
        self.assertEqual(len({x['date'] for x in z}),len(z));self.assertGreater(r['counts']['Daily cap'],0)
    def test_close_sequence_intraday_and_bracket(self):
        with TemporaryDirectory() as tmp:
            dates=pd.bdate_range('2019-11-01','2020-02-14')
            df=pd.DataFrame(dict(symbol='INDIANB',date=dates,open=100.,high=101.,low=99.,close=100.,volume=100.))
            # D-20200116-1 enters 17 Jan. First event volume spike visible at close.
            df.loc[df.date==pd.Timestamp('2020-01-17'),'volume']=400.
            df.loc[df.date==pd.Timestamp('2020-01-20'),['open','high','low','close']]=[103.,112.,95.,105.]
            path=Path(tmp)/'panel.parquet';df.to_parquet(path)
            intradir=Path(tmp)/'bars';intradir.mkdir()
            dates3=pd.date_range('2020-01-17 09:15',periods=125,freq='3min')
            b=pd.DataFrame(dict(timestamp=dates3,open=100.,high=101.,low=99.,close=100.,volume=10))
            b.loc[5,['open','high','low','close']]=[100,103,100,102]
            b.loc[6,['open','high','low','close']]=[102,103,100.9,102]
            b.loc[7,['open','high','low','close']]=[102,102,100,101]
            b.to_parquet(intradir/'INDIANB_3m.parquet')
            f=Feed(path,[],intradir,3);r=next(x for x in f.picks if x['trade_id']=='D-20200116-1')
            e=trigger(f,r,PRESETS[5]);self.assertEqual((e['day'],e['price']),(2,103.))
            c=dict(PRESETS[5],hold=1,tp=5,sl=1);v=exit_trade(f,r,c,e)
            self.assertTrue(v['ambiguous']);self.assertAlmostEqual(v['ret'],-1.35)
            e=trigger(f,r,PRESETS[6]);self.assertEqual((e['day'],e['price'],e['time']),(1,102.,'2020-01-17 09:36:00'))
            close_signal=preset('close only',[event('close',rule('volume','>=',300))],window=1)
            self.assertIsNone(trigger(f,r,close_signal))
            # Missing confirmation data is distinct from an observed false signal.
            with self.assertRaises(Missing):trigger(f,r,preset('bars',[event('intraday',rule('bar_close','>',1000))]))
if __name__=='__main__':unittest.main(verbosity=2)
