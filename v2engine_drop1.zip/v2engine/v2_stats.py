r"""v2_stats.py - inference for v2 (drop 1).

Circular block bootstrap over sessions (the signal day is the inference unit): 10-session blocks,
2,000 resamples, seed 7 by default. Every series compared with another is resampled on the SAME
session draws, so paired differences and max-t keep their dependence.
"""
import math

import numpy as np


class DayBoot:
    """Shared circular-block resample of n sessions."""

    def __init__(self, n_sessions, block=10, B=2000, seed=7):
        self.n, self.block, self.B, self.seed = int(n_sessions), int(block), int(B), int(seed)
        rng = np.random.default_rng(seed)
        k = math.ceil(self.n / self.block)
        starts = rng.integers(0, self.n, size=(self.B, k))
        idx = (starts[:, :, None] + np.arange(self.block)[None, None, :]) % self.n
        self.idx = idx.reshape(self.B, -1)[:, :self.n]

    def by_day(self, day_idx, values):
        """Per-session sums and counts of observation values (observations keyed by their signal day)."""
        day_idx = np.asarray(day_idx, dtype=int)
        values = np.asarray(values, dtype=float)
        sums = np.bincount(day_idx, weights=values, minlength=self.n)
        cnts = np.bincount(day_idx, minlength=self.n).astype(float)
        return sums, cnts

    def mean(self, sums, cnts):
        """Observed mean per observation and its resampled means."""
        tot = cnts.sum()
        obs = sums.sum() / tot if tot else np.nan
        bs = sums[self.idx].sum(axis=1)
        bc = cnts[self.idx].sum(axis=1)
        with np.errstate(invalid="ignore", divide="ignore"):
            boots = np.where(bc > 0, bs / bc, np.nan)
        return obs, boots

    def ratio(self, num, den):
        """Observed sum(num)/sum(den) (e.g. P&L per unit of capital in use) and its resampled values."""
        obs = num.sum() / den.sum() if den.sum() else np.nan
        bn = num[self.idx].sum(axis=1)
        bd = den[self.idx].sum(axis=1)
        with np.errstate(invalid="ignore", divide="ignore"):
            boots = np.where(bd > 0, bn / bd, np.nan)
        return obs, boots


def interval(boots, level=0.95):
    b = boots[~np.isnan(boots)]
    if len(b) == 0:
        return np.nan, np.nan
    a = (1.0 - level) / 2.0
    return float(np.quantile(b, a)), float(np.quantile(b, 1.0 - a))


def summary(obs, boots):
    lo, hi = interval(boots)
    sd = float(np.nanstd(boots, ddof=1)) if np.sum(~np.isnan(boots)) > 1 else np.nan
    return {"mean": float(obs), "lo": lo, "hi": hi, "se": sd,
            "verdict": "ABOVE 0" if lo > 0 else ("BELOW 0" if hi < 0 else "SPANS 0")}


def max_t(obs_list, boots_list):
    """Studentised max-t across a family's cells (one-sided, H1: mean > 0), Reality-Check style:
    t_k = m_k / se_k; the null is the resampled max over k of (m*_k - m_k) / se_k."""
    m = np.asarray(obs_list, dtype=float)
    bm = np.column_stack(boots_list)                       # B x K
    se = np.nanstd(bm, axis=0, ddof=1)
    t = m / se
    centred = (bm - m[None, :]) / se[None, :]
    mx = np.nanmax(centred, axis=1)
    p = np.array([(1 + np.sum(mx >= tk)) / (len(mx) + 1) for tk in t])
    return t, p


def bh(pvals, q=0.05):
    """Benjamini-Hochberg step-up. Returns (reject flags, adjusted p) in the input order."""
    p = np.asarray(pvals, dtype=float)
    n = len(p)
    if n == 0:
        return np.array([], dtype=bool), np.array([])
    order = np.argsort(p)
    ranked = p[order] * n / np.arange(1, n + 1)
    adj = np.minimum.accumulate(ranked[::-1])[::-1]
    adj = np.minimum(adj, 1.0)
    out_adj = np.empty(n)
    out_adj[order] = adj
    return out_adj <= q, out_adj


def eb_shrink(means, ses, counts):
    """Empirical-Bayes pooling of cell means toward their weighted parent mean (method of moments):
    tau^2 = max(0, var(means) - mean(se^2)); weight_k = tau^2 / (tau^2 + se_k^2).
    Returns (pooled means, weights, parent mean, tau^2)."""
    m = np.asarray(means, dtype=float)
    s2 = np.asarray(ses, dtype=float) ** 2
    w_n = np.asarray(counts, dtype=float)
    ok = ~np.isnan(m) & ~np.isnan(s2) & (w_n > 0)
    if ok.sum() == 0:
        return m, np.zeros_like(m), np.nan, np.nan
    parent = np.average(m[ok], weights=w_n[ok])
    tau2 = max(0.0, float(np.var(m[ok], ddof=1) if ok.sum() > 1 else 0.0) - float(np.mean(s2[ok])))
    with np.errstate(invalid="ignore", divide="ignore"):
        w = np.where(ok, tau2 / (tau2 + s2), 0.0)
    pooled = np.where(ok, w * m + (1 - w) * parent, np.nan)
    return pooled, w, parent, tau2
