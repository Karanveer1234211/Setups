# MANIFEST_V2.md - v2engine 0.1 (drop 1), 31 Oct 2026

Copy the whole folder to C:\Users\karanvsi\PyCharmMiscProject\v2engine\ . Nothing to ignore; nothing goes into bigmove_deploy, pathlab or tradelab.

| file | sha256 (first 16) | bytes |
|---|---|---|
| v2engine.py | 1780417aa680e09f | 1,395 |
| v2_core.py | 0ee19035accfa9b9 | 19,467 |
| v2_families.py | 3af2729ddfc0273a | 5,091 |
| v2_research.py | 53add2dee56dd154 | 15,320 |
| v2_stats.py | 4dba063907926b61 | 4,492 |
| tests\v2_world.py | 69aeaf38275570a8 | 7,282 |
| tests\test_v2.py | dfcdd4f0f5bac9c3 | 30,116 |
| V2_DECLARATION_DRAFT.json | 74aac29053adac09 | 4,910 |
| README_V2.md | 766445a81ef19d04 | 5,657 |
