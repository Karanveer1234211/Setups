r"""v2_world.py - synthetic worlds for v2 drop 1.

Prices follow a martingale built from intraday paths (16 steps a session plus an overnight gap). The
day's high and low are the continuous path's extremes (Brownian-bridge max / min between samples), so a
buy-stop filled at a level the high reached is fair by construction. Taking the high from the samples
alone overshoots the level and faked +34 bp a trade in the first build of this world (the same trap as
the straight-line bars of doc 13).

Selections: each session, 3 D picks (mostly stocks that fell that day) and 3 ENS picks (about a third
shared with D), ranks 1-3 by a random raw score.

Planted effect for T1-2 (turn after the dip), keyed to the family's own trigger (that session's high
+ 0.1 ATR, armed at each close inside the window):
  absent   no drift anywhere
  planted  -delta a session while the stock waits for the trigger, +delta from the crossing for 5 sessions
  reverse  no drift while waiting, -delta from the crossing for 5 sessions (a false break)
"""
import datetime as dt
import math

import numpy as np

from v2_core import BarStore, SelectionRegistry, SessionCalendar


def business_days(start, n, holiday_every=37):
    d = dt.date.fromisoformat(start)
    out, k = [], 0
    while len(out) < n:
        if d.weekday() < 5:
            k += 1
            if not (holiday_every and k % holiday_every == 0):
                out.append(d)
        d += dt.timedelta(days=1)
    return out


def _wilder_step(atr, acc, cnt, tr, n=14):
    """One Wilder ATR14 update, element-wise, in the same arithmetic order as v2_core.wilder_atr."""
    new_atr = atr.copy()
    seeding = cnt < n
    acc = np.where(seeding, acc + tr, acc)
    cnt = np.where(seeding, cnt + 1, cnt)
    just = seeding & (cnt == n)
    new_atr = np.where(just, acc / n, new_atr)
    rolling = ~seeding
    new_atr = np.where(rolling, (atr * (n - 1) + tr) / n, new_atr)
    return new_atr, acc, cnt


def make_world(mode="absent", n_days=1000, n_sym=150, delta=0.006, sigma=0.025, gap_sd=0.006, steps=16,
               picks=3, seed=1, post_len=5, offset_atr=0.1, warmup=20, pick_run="PM_SYN"):
    if mode not in ("absent", "planted", "reverse"):
        raise ValueError(mode)
    days = business_days("2020-01-01", n_days)
    cal = SessionCalendar(days)
    rng = np.random.default_rng(seed)
    n, S = cal.n, n_sym
    O, H, L, C = (np.full((S, n), np.nan) for _ in range(4))
    mu_watch = {"absent": 0.0, "planted": -delta, "reverse": 0.0}[mode]
    mu_post = {"absent": 0.0, "planted": delta, "reverse": -delta}[mode]
    atr = np.full(S, np.nan)
    acc, cnt = np.zeros(S), np.zeros(S)
    state = np.zeros(S, dtype=int)            # 0 idle, 1 waiting for the trigger, 2 after the crossing
    watch_end = np.full(S, -1)
    post_end = np.full(S, -1)
    level = np.full(S, np.nan)
    sd_step = sigma / math.sqrt(steps)
    price0 = 100.0 * np.exp(rng.normal(0.0, 0.5, S))
    sels = []
    crossings = 0
    for s in range(n):
        state = np.where((state == 1) & (s > watch_end), 0, state)
        state = np.where((state == 2) & (s > post_end), 0, state)
        if s == 0:
            o = price0
        else:
            o = C[:, s - 1] * np.exp(rng.normal(-gap_sd ** 2 / 2.0, gap_sd, S))
        # log-price path; the day's high and low are the CONTINUOUS path's extremes (Brownian-bridge
        # maximum / minimum between the sampled points), so a buy-stop at a level the high reached
        # really traded there - discrete samples alone overshoot the level and fake an edge.
        x = np.log(o)
        hi = x.copy()
        lo = x.copy()
        logL = np.log(np.where(np.isnan(level), np.inf, level))
        hit0 = (state == 1) & (x >= logL)
        if hit0.any():
            crossings += int(hit0.sum())
            state = np.where(hit0, 2, state)
            post_end = np.where(hit0, s + post_len, post_end)
        v = sd_step ** 2
        for j in range(steps):
            mu = np.where(state == 2, mu_post, np.where(state == 1, mu_watch, 0.0)) / steps
            x1 = x + rng.normal(mu - v / 2.0, sd_step, S)
            u1, u2 = rng.random(S), rng.random(S)
            bmax = (x + x1 + np.sqrt((x1 - x) ** 2 - 2.0 * v * np.log(u1))) / 2.0
            bmin = (x + x1 - np.sqrt((x1 - x) ** 2 - 2.0 * v * np.log(u2))) / 2.0
            hit = (state == 1) & (bmax >= logL)
            if hit.any():
                crossings += int(hit.sum())
                state = np.where(hit, 2, state)
                post_end = np.where(hit, s + post_len, post_end)
            hi = np.maximum(hi, bmax)
            lo = np.minimum(lo, bmin)
            x = x1
        O[:, s], H[:, s], L[:, s], C[:, s] = o, np.exp(hi), np.exp(lo), np.exp(x)
        if s == 0:
            tr = H[:, s] - L[:, s]
        else:
            pc = C[:, s - 1]
            tr = np.maximum(H[:, s] - L[:, s], np.maximum(np.abs(H[:, s] - pc), np.abs(L[:, s] - pc)))
        atr, acc, cnt = _wilder_step(atr, acc, cnt, tr)
        # trigger level for the next session (the family arms at this close)
        level = np.where(state == 1, H[:, s] + offset_atr * atr, level)
        if s < warmup or s >= n - 1:
            continue
        fell = np.where(C[:, s] < C[:, s - 1])[0]
        others = np.setdiff1d(np.arange(S), fell)
        d_pick = []
        while len(d_pick) < picks:
            pool = fell if (rng.random() < 0.85 and len(fell)) else others
            c = int(rng.choice(pool))
            if c not in d_pick:
                d_pick.append(c)
        e_pick = []
        while len(e_pick) < picks:
            if rng.random() < 0.34:
                c = int(rng.choice(d_pick))
            else:
                c = int(rng.integers(0, S))
            if c not in e_pick:
                e_pick.append(c)
        for eng, lst in (("D", d_pick), ("ENS", e_pick)):
            scores = rng.random(len(lst))
            order = np.argsort(-scores)
            for rank, k in enumerate(order, start=1):
                sym = lst[k]
                sels.append((eng, rank, cal.date(s), "S%03d" % sym, float(scores[k]),
                             {"state": "S08" if sym % 3 == 0 else ("S01" if sym % 3 == 1 else "S07")}))
        for sym in set(d_pick) | set(e_pick):
            if state[sym] == 0 and C[sym, s] < C[sym, s - 1]:
                state[sym] = 1
                watch_end[sym] = s + 10
                level[sym] = H[sym, s] + offset_atr * atr[sym]
    bars = BarStore(cal)
    for k in range(S):
        bars.put_arrays("S%03d" % k, {"open": O[k], "high": H[k], "low": L[k], "close": C[k],
                                      "volume": np.ones(n)})
    reg = SelectionRegistry(cal)
    for eng, rank, T, sym, score, snap in sels:
        reg.add(pick_run, eng, rank, T, sym, score, snap)
    return {"cal": cal, "bars": bars, "registry": reg, "mode": mode, "crossings": crossings}


def tiny_calendar(n=60, holiday_every=0, start="2024-01-01"):
    return SessionCalendar(business_days(start, n, holiday_every))


def flat_bars(cal, price=100.0, width=1.0):
    """Every session: open = close = price, high = price + width, low = price - width."""
    n = cal.n
    p = np.full(n, price)
    return {"open": p.copy(), "high": p + width, "low": p - width, "close": p.copy(), "volume": np.ones(n)}
