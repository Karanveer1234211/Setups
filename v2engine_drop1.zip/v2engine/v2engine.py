r"""v2engine.py - command line for the BigMove v2 execution engine (drop 1).

    python v2engine.py --selftest          full verification suite (synthetic data only)
    python v2engine.py --selftest quick    the same without the 20 calibration worlds
    python v2engine.py --version

Drop 1 has no data adapters. Any command that would read your cache, pick_meta, tradelab or pathlab
outputs is refused until the adapters are built on your uploaded pathlab and tradelab code.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from v2_core import VERSION  # noqa: E402

NOT_WIRED = ("not wired yet: real-data commands need the pathlab and tradelab code "
             "(the adapters are built after your zips arrive)")


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if not argv:
        print(VERSION)
        print("usage: python v2engine.py --selftest [quick] | --version")
        print("Real-data commands are " + NOT_WIRED + ".")
        return 2
    if argv[0] == "--version":
        print(VERSION)
        return 0
    if argv[0] == "--selftest":
        sys.path.insert(0, str(Path(__file__).resolve().parent / "tests"))
        import test_v2
        return test_v2.main(argv[1:])
    print("%s: '%s' is %s." % (VERSION, argv[0], NOT_WIRED))
    return 2


if __name__ == "__main__":
    sys.exit(main())
