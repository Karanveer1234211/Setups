r"""v2_core.py - BigMove v2 execution engine: core mechanics (drop 1).

Pure, point-in-time building blocks on a declared input schema. Nothing here reads the cache or any
production file: drop 1 is verified on synthetic worlds only, and the adapters to pathlab / tradelab /
stage E come once their code is uploaded.

  SessionCalendar    NSE sessions; a selection at T may enter on T+1 .. T+10 inclusive
  SelectionRegistry  one immutable record per (pick run, engine, rank, T); repeat flags; append-only store
  BarStore           daily bars per symbol on the calendar, Wilder ATR14 known at each close
  fill_buy_stop / fill_preopen   the research fill model (daily bars)
  run_exit           exit policies X1 (time), X2 (event-only), X3 (R target), X5 (long hold)

Spec: "BigMove Execution Engine - Spec v2" (Claude Doc), v2.3 of 31 Oct 2026.
"""
import datetime as dt
import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

VERSION = "v2engine 0.1 (drop 1)"
CONFIG = {"cost_rt": 0.0035,     # 35 bp round trip, charged once per filled trade (tests may set 0)
          "stop_slip_atr": 0.05}  # a buy-stop fills this many ATRs above its trigger (declared; stress 0 / 0.10)


def cost():
    return CONFIG["cost_rt"]


def set_cost(x):
    CONFIG["cost_rt"] = float(x)


def set_stop_slip(x):
    CONFIG["stop_slip_atr"] = float(x)
WINDOW = 10                 # entry on sessions T+1 .. T+10 inclusive
LOCK_WAIT = 20              # a lower-locked exit waits for the first unlocked open within 20 sessions


class V2Error(Exception):
    pass


def to_day(x):
    """Any date-like -> numpy datetime64[D]."""
    if isinstance(x, np.datetime64):
        return x.astype("datetime64[D]")
    if isinstance(x, (dt.date, dt.datetime)):
        return np.datetime64(x.strftime("%Y-%m-%d"), "D")
    return np.datetime64(str(x)[:10], "D")


def day_str(d):
    return str(to_day(d))


def sha16(obj):
    raw = json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:16]


# ============================================================================ calendar
class SessionCalendar:
    """The NSE session calendar.

    sessions       every trading session (the calendar stage E uses for PLAN's 5th close)
    special        special sessions such as Muhurat trading
    count_special  True: special sessions count as sessions for T+k but take no entries;
                   False: they are not sessions at all (dropped from the counting calendar)
    """

    def __init__(self, sessions, special=(), count_special=False):
        days = np.array(sorted({to_day(s) for s in sessions}), dtype="datetime64[D]")
        if len(days) < 2:
            raise V2Error("calendar needs at least two sessions")
        spec = {to_day(s).item() for s in special}          # datetime.date, like days.tolist()
        unknown = spec - set(days.tolist())
        if unknown:
            raise V2Error("special sessions not in the calendar: %s" % sorted(map(str, unknown)))
        if not count_special:
            days = np.array([d for d in days.tolist() if d not in spec], dtype="datetime64[D]")
        self.days = days
        self.n = len(days)
        self.count_special = bool(count_special)
        self._pos = {d: i for i, d in enumerate(days.tolist())}
        self.entry_ok = np.array([d not in spec for d in days.tolist()], dtype=bool)

    def idx(self, d):
        try:
            return self._pos[to_day(d).item()]
        except KeyError:
            raise V2Error("%s is not a session in the calendar" % day_str(d))

    def has(self, d):
        return to_day(d).item() in self._pos

    def date(self, i):
        return self.days[i]

    def window(self, t_idx):
        """Session indices T+1 .. T+10 that exist in the calendar (fewer at the end of data)."""
        return list(range(t_idx + 1, min(t_idx + WINDOW, self.n - 1) + 1))

    def complete(self, t_idx):
        return t_idx + WINDOW <= self.n - 1

    def arming_closes(self, t_idx):
        """Closes after which an order for the next session may be armed: T .. T+9, entry session allowed."""
        out = []
        for a in range(t_idx, min(t_idx + WINDOW - 1, self.n - 2) + 1):
            if self.entry_ok[a + 1]:
                out.append(a)
        return out


# ============================================================================ selections
@dataclass(frozen=True)
class Selection:
    sid: str
    pick_run: str
    engine: str
    rank: int
    T: str
    t_idx: int
    symbol: str
    raw_score: float
    snapshot: tuple = ()
    corrects: str = ""
    fingerprint: str = ""

    def snap(self):
        return dict(self.snapshot)


def make_sid(pick_run, engine, T, rank):
    return "%s/%s-%s-%d" % (pick_run, engine, day_str(T).replace("-", ""), int(rank))


class SelectionRegistry:
    """Every selection keeps its own identity; nothing is merged or extended here."""

    ENGINES = ("D", "ENS")

    def __init__(self, cal):
        self.cal = cal
        self.items = []
        self.by_sid = {}

    def add(self, pick_run, engine, rank, T, symbol, raw_score, snapshot=None, corrects=""):
        if engine not in self.ENGINES:
            raise V2Error("engine must be D or ENS, got %r" % engine)
        rank = int(rank)
        if rank < 1:
            raise V2Error("rank must be >= 1")
        t_idx = self.cal.idx(T)
        sid = make_sid(pick_run, engine, T, rank)
        if corrects:
            n = sum(1 for s in self.items if s.corrects == corrects) + 1
            sid = "%s#c%d" % (corrects, n)
        snap = tuple(sorted((snapshot or {}).items()))
        body = {"sid": sid, "pick_run": pick_run, "engine": engine, "rank": rank, "T": day_str(T),
                "symbol": symbol, "raw_score": float(raw_score), "snapshot": snap, "corrects": corrects}
        fp = sha16(body)
        if sid in self.by_sid:
            old = self.by_sid[sid]
            if old.fingerprint == fp:
                return old
            raise V2Error("selection %s already exists with different content; "
                          "write a correction record instead of editing it" % sid)
        sel = Selection(sid, pick_run, engine, rank, day_str(T), t_idx, symbol, float(raw_score),
                        snap, corrects, fp)
        self.items.append(sel)
        self.by_sid[sid] = sel
        return sel

    def active(self):
        """Selections that are not superseded by a correction."""
        superseded = {s.corrects for s in self.items if s.corrects}
        return [s for s in self.items if s.sid not in superseded]

    def flags(self):
        """Repeat flags (derived, never stored on the record).

        overlap_prior   ids of earlier selections of the same stock whose window overlaps this one
        same_day_other  ids of selections of the same stock on the same T in the other engine
        first           no earlier overlapping selection, and first in priority among same-day ones
        """
        out = {}
        by_sym = {}
        for s in self.active():
            by_sym.setdefault(s.symbol, []).append(s)
        for sym, lst in by_sym.items():
            lst = sorted(lst, key=lambda s: (s.t_idx, s.rank, 0 if s.engine == "D" else 1, -s.raw_score))
            for i, s in enumerate(lst):
                prior = [p.sid for p in lst if p.t_idx < s.t_idx and s.t_idx - p.t_idx <= WINDOW - 1]
                same = [p.sid for p in lst if p.t_idx == s.t_idx and p.sid != s.sid]
                earlier_same = [p for p in lst[:i] if p.t_idx == s.t_idx]
                out[s.sid] = {"overlap_prior": prior, "same_day_other": same,
                              "first": (not prior) and (not earlier_same)}
        return out


class SelectionStore:
    """Append-only JSONL of selection records. A record is never edited; a changed record is refused."""

    def __init__(self, path):
        self.path = Path(path)

    def read(self):
        if not self.path.exists():
            return {}
        out = {}
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                rec = json.loads(line)
                out[rec["sid"]] = rec
        return out

    def append(self, selections):
        have = self.read()
        new = []
        for s in selections:
            rec = {"sid": s.sid, "pick_run": s.pick_run, "engine": s.engine, "rank": s.rank, "T": s.T,
                   "symbol": s.symbol, "raw_score": s.raw_score, "snapshot": [list(kv) for kv in s.snapshot],
                   "corrects": s.corrects, "fingerprint": s.fingerprint}
            if s.sid in have:
                if have[s.sid]["fingerprint"] != s.fingerprint:
                    raise V2Error("store already holds %s with a different fingerprint; refused" % s.sid)
                continue
            new.append(rec)
        if new:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8", newline="\n") as fh:
                for rec in new:
                    fh.write(json.dumps(rec, sort_keys=True) + "\n")
        return len(new)


# ============================================================================ bars
FIELDS = ("open", "high", "low", "close", "volume")


class BarStore:
    """Daily bars per symbol on the calendar's session index. Missing bars are NaN.

    upper_locked / lower_locked: bars locked at the price band (inputs; stage E's rule in integration).
    """

    def __init__(self, cal):
        self.cal = cal
        self.data = {}

    def put(self, symbol, dates, open_, high, low, close, volume=None, upper_locked=None, lower_locked=None):
        n = self.cal.n
        rec = {f: np.full(n, np.nan) for f in FIELDS}
        rec["upper_locked"] = np.zeros(n, dtype=bool)
        rec["lower_locked"] = np.zeros(n, dtype=bool)
        vol = volume if volume is not None else np.zeros(len(dates))
        ul = upper_locked if upper_locked is not None else np.zeros(len(dates), dtype=bool)
        ll = lower_locked if lower_locked is not None else np.zeros(len(dates), dtype=bool)
        for j, d in enumerate(dates):
            if not self.cal.has(d):
                continue            # e.g. a special session dropped from the counting calendar
            i = self.cal.idx(d)
            rec["open"][i], rec["high"][i], rec["low"][i] = open_[j], high[j], low[j]
            rec["close"][i], rec["volume"][i] = close[j], vol[j]
            rec["upper_locked"][i], rec["lower_locked"][i] = bool(ul[j]), bool(ll[j])
        bad = ~np.isnan(rec["open"]) & ((rec["high"] < np.fmax(rec["open"], rec["close"]) - 1e-9) |
                                        (rec["low"] > np.fmin(rec["open"], rec["close"]) + 1e-9))
        if bad.any():
            raise V2Error("%s: %d bars with high/low outside open/close" % (symbol, int(bad.sum())))
        rec["atr"] = wilder_atr(rec["high"], rec["low"], rec["close"])
        self.data[symbol] = rec

    def put_arrays(self, symbol, rec):
        """Bars already on the session index (synthetic worlds); ATR computed here."""
        n = self.cal.n
        for f in FIELDS:
            if len(rec[f]) != n:
                raise V2Error("%s: %s has %d values, calendar has %d" % (symbol, f, len(rec[f]), n))
        rec = dict(rec)
        rec.setdefault("upper_locked", np.zeros(n, dtype=bool))
        rec.setdefault("lower_locked", np.zeros(n, dtype=bool))
        rec["atr"] = wilder_atr(rec["high"], rec["low"], rec["close"])
        self.data[symbol] = rec

    def __getitem__(self, symbol):
        try:
            return self.data[symbol]
        except KeyError:
            raise V2Error("no bars for %s" % symbol)

    def symbols(self):
        return sorted(self.data)


def wilder_atr(high, low, close, n=14):
    """Wilder ATR14 known at each close: true range uses the previous close; the first value is the
    simple mean of the first 14 true ranges; a missing bar carries the last value forward."""
    m = len(close)
    tr = np.full(m, np.nan)
    prev = np.nan
    for i in range(m):
        if np.isnan(close[i]):
            continue
        if np.isnan(prev):
            tr[i] = high[i] - low[i]
        else:
            tr[i] = max(high[i] - low[i], abs(high[i] - prev), abs(low[i] - prev))
        prev = close[i]
    atr = np.full(m, np.nan)
    seen, acc, cur = 0, 0.0, np.nan
    for i in range(m):
        if np.isnan(tr[i]):
            atr[i] = cur
            continue
        if seen < n:
            acc += tr[i]
            seen += 1
            if seen == n:
                cur = acc / n
        else:
            cur = (cur * (n - 1) + tr[i]) / n
        atr[i] = cur
    return atr


# ============================================================================ fills
FILLED, NOT_TRIGGERED, GAPPED_OVER, BLOCKED, NO_BAR, INVALID_AT_OPEN = (
    "FILLED", "NOT_TRIGGERED", "GAPPED_OVER", "BLOCKED", "NO_BAR", "INVALID_AT_OPEN")


def fill_buy_stop(b, i, trigger, limit):
    """A GTT buy-stop for session i: triggers when the day's high reaches the level; fills at the higher
    of the open and the level plus a declared slippage (stop_slip_atr x the arming close's ATR), never
    above the limit; an open above the limit is a miss; a bar locked at the upper band cannot be bought.
    A buy-stop buys into a rising price, so it pays slippage the opening auction does not."""
    o, h = b["open"][i], b["high"][i]
    if np.isnan(o):
        return NO_BAR, np.nan
    if h < trigger:
        return NOT_TRIGGERED, np.nan
    if b["upper_locked"][i]:
        return BLOCKED, np.nan
    if o > limit:
        return GAPPED_OVER, np.nan
    slip = CONFIG["stop_slip_atr"] * b["atr"][i - 1] if i >= 1 and not np.isnan(b["atr"][i - 1]) else 0.0
    return FILLED, min(max(trigger + slip, o), limit)


def fill_preopen(b, i, cap_atr):
    """A pre-open limit buy capped at the previous close + cap_atr x ATR (both known at the close
    before); fills at the open (the auction price)."""
    o = b["open"][i]
    if np.isnan(o):
        return NO_BAR, np.nan
    prev_close, prev_atr = b["close"][i - 1], b["atr"][i - 1]
    if b["upper_locked"][i]:
        return BLOCKED, np.nan
    if not np.isnan(prev_close) and not np.isnan(prev_atr) and o > prev_close + cap_atr * prev_atr:
        return GAPPED_OVER, np.nan
    return FILLED, o


# ============================================================================ exits
@dataclass
class ExitPolicy:
    """kind: X1 time | X2 event-only | X3 R target | X5 long hold (X4 structure target: drop 2)."""
    kind: str
    target_r: float = np.nan        # X3 only
    backstop: int = 20              # X2/X3: 20; X5: 40
    time_sessions: int = 5          # X1: exit at the open this many sessions after the entry session

    def name(self):
        if self.kind == "X3":
            return "X3_%gR" % self.target_r
        return self.kind


X1 = ExitPolicy("X1")
X2 = ExitPolicy("X2", backstop=20)
X5 = ExitPolicy("X5", backstop=40)


def x3(r):
    return ExitPolicy("X3", target_r=float(r), backstop=20)


def _unlocked_open(b, i, n):
    """First session >= i with an open and no lower lock, within LOCK_WAIT sessions."""
    for k in range(i, min(i + LOCK_WAIT, n - 1) + 1):
        if not np.isnan(b["open"][k]) and not b["lower_locked"][k]:
            return k
    return None


def run_exit(b, cal, entry_idx, entry_px, entry_kind, policy, stop=np.nan, events=None):
    """Exit of one long trade on daily bars.

    entry_kind 'stop' (an intraday buy-stop fill) or 'open' (a pre-open fill at the open).
    events: boolean array on the session index; True at a close means exit at the next open.
    Order inside a day without 3-minute bars is worst case: a stop and a target in one day's range
    -> the stop; on the entry day of a buy-stop fill, a low at or below the stop counts as stopped.
    Returns dict(exit_idx, exit_px, reason, held, mfe, mae, net).
    """
    n = cal.n
    out = {"exit_idx": None, "exit_px": np.nan, "reason": "", "held": 0, "mfe": 0.0, "mae": 0.0, "net": np.nan}
    hi_seen, lo_seen = entry_px, entry_px

    def finish(i, px, reason):
        out.update(exit_idx=i, exit_px=px, reason=reason, held=i - entry_idx,
                   mfe=hi_seen / entry_px - 1.0, mae=lo_seen / entry_px - 1.0,
                   net=px / entry_px - 1.0 - cost())
        return out

    def deferred(i, reason):
        k = _unlocked_open(b, i, n)
        if k is None:
            last = min(i + LOCK_WAIT, n - 1)
            return finish(last, b["close"][last], "STUCK")
        return finish(k, b["open"][k], reason + ("" if k == i else "_LOCKWAIT"))

    if policy.kind == "X1":
        k = entry_idx + policy.time_sessions
        if k > n - 1:
            out["reason"] = "OPEN_AT_END"
            return out
        for j in range(entry_idx, k):
            if not np.isnan(b["high"][j]):
                hi_seen, lo_seen = max(hi_seen, b["high"][j]), min(lo_seen, b["low"][j])
        return deferred(k, "TIME")

    if policy.kind not in ("X2", "X3", "X5"):
        raise V2Error("exit policy %s is not built in drop 1" % policy.kind)
    if not (stop < entry_px):
        raise V2Error("stop %.4f must be below the entry %.4f" % (stop, entry_px))
    target = np.nan
    if policy.kind == "X3":
        target = entry_px + policy.target_r * (entry_px - stop)
    has_t = not np.isnan(target)
    last_idx = entry_idx + policy.backstop
    for i in range(entry_idx, n):
        o, h, lo, c = b["open"][i], b["high"][i], b["low"][i], b["close"][i]
        if np.isnan(o):
            continue
        locked = bool(b["lower_locked"][i])
        if i > entry_idx:
            if o <= stop:
                return deferred(i, "STOP_GAP") if locked else finish(i, o, "STOP_GAP")
            if has_t and o >= target:
                return finish(i, o, "TARGET_GAP")
        hit_stop = lo <= stop
        hit_tgt = has_t and h >= target
        hi_seen, lo_seen = max(hi_seen, h), min(lo_seen, lo)
        if hit_stop:
            if locked:
                return deferred(i + 1, "STOP")
            return finish(i, stop, "STOP")
        if hit_tgt:
            return finish(i, target, "TARGET")
        if i == last_idx:
            if locked:
                return deferred(i + 1, "BACKSTOP")
            return finish(i, c, "BACKSTOP")
        if events is not None and events[i] and i + 1 <= n - 1:
            return deferred(i + 1, "EVENT")
    out["reason"] = "OPEN_AT_END"
    return out


def plan_trade(b, cal, t_idx, exit_kind="CLOSE5"):
    """Original BigMove: buy at T+1's open; sell at T+5's close (PLAN) or T+6's open (OPEN6).
    A locked exit waits for the first unlocked open within 20 sessions (stage E's rule)."""
    n = cal.n
    e = t_idx + 1
    x = t_idx + (5 if exit_kind == "CLOSE5" else 6)
    if x > n - 1 or np.isnan(b["open"][e]):
        return np.nan, "NO_TRADE"
    if b["upper_locked"][e]:
        return 0.0, "BLOCKED"
    entry = b["open"][e]
    if exit_kind == "CLOSE5":
        if not b["lower_locked"][x] and not np.isnan(b["close"][x]):
            return b["close"][x] / entry - 1.0 - cost(), "CLOSE5"
        k = _unlocked_open(b, x + 1, n)
    else:
        k = _unlocked_open(b, x, n)
    if k is None:
        return np.nan, "STUCK"
    return b["open"][k] / entry - 1.0 - cost(), "OPEN" if exit_kind != "CLOSE5" else "CLOSE5_LOCKWAIT"
