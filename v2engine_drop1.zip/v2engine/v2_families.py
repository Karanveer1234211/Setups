r"""v2_families.py - Tier 1 setup families built in drop 1: T1-1 delay, T1-2 turn after the dip,
T1-4 burst after a squeeze. Each family arms at most one order per selection per close, from bars
known at that close; nothing here looks past the arming close.

General rule (spec section 5): a buy-stop is armed only while its trigger sits above the last close.
A trigger at or below the close means the move already happened ("already through"): no order that
evening. Below the price, a Kite GTT would act as a buy-on-dip and the daily fill model would buy at
the open; neither is the setup.

T1-3 failed breakdown, T1-5 breakout acceptance and T1-7 home-index turn need tl_state events and
index bars: drop 2.
"""
from dataclasses import dataclass

import numpy as np

LIMIT_ATR = 0.3          # buy-stop limit = trigger + 0.3 ATR (declared)


@dataclass(frozen=True)
class Order:
    kind: str            # 'stop' (GTT buy-stop) or 'preopen' (limit buy in the pre-open)
    trigger: float       # nan for preopen
    limit: float         # nan for preopen (its cap is applied by the fill model)
    stop: float          # initial stop = setup invalidation (1R)
    arm_idx: int         # the close it was armed after; it trades in session arm_idx + 1
    family: str
    variant: str


class Family:
    name = "base"
    priority = 99        # lower = armed first (declared)

    def __init__(self, variant="v1"):
        self.variant = variant

    @property
    def key(self):
        return "%s:%s" % (self.name, self.variant)

    def eligible(self, b, cal, sel):
        return True

    def arm(self, b, cal, sel, a):
        raise NotImplementedError


def _ok(*vals):
    return all(not np.isnan(v) for v in vals)


class Delay(Family):
    """T1-1: no signal; buy at the open of T+d with a pre-open order. Stop: selection-day low - 0.5 ATR."""
    name = "T1-1"
    priority = 8

    def __init__(self, d=2, stop_atr=0.5):
        super().__init__("d%d" % d)
        self.d, self.stop_atr = int(d), float(stop_atr)

    def arm(self, b, cal, sel, a):
        T = sel.t_idx
        if a != T + self.d - 1:
            return None
        lowT, atrT = b["low"][T], b["atr"][T]
        if not _ok(lowT, atrT):
            return None
        return Order("preopen", np.nan, np.nan, lowT - self.stop_atr * atrT, a, self.name, self.variant)


class TurnAfterDip(Family):
    """T1-2: the pick fell into T (close below the previous close); each evening inside the window a
    buy-stop at that session's high + offset x ATR. Stop: lowest low since selection - 0.25 ATR."""
    name = "T1-2"
    priority = 2

    def __init__(self, offset_atr=0.1, stop_atr=0.25, variant=None):
        super().__init__(variant or "o%g" % offset_atr)
        self.offset_atr, self.stop_atr = float(offset_atr), float(stop_atr)

    def eligible(self, b, cal, sel):
        T = sel.t_idx
        if T < 1:
            return False
        c0, c1 = b["close"][T - 1], b["close"][T]
        return _ok(c0, c1) and c1 < c0

    def arm(self, b, cal, sel, a):
        h, c, atr = b["high"][a], b["close"][a], b["atr"][a]
        if not _ok(h, c, atr):
            return None
        trig = h + self.offset_atr * atr
        if trig <= c:
            return None                                   # already through
        lows = b["low"][sel.t_idx:a + 1]
        lows = lows[~np.isnan(lows)]
        if len(lows) == 0:
            return None
        stop = lows.min() - self.stop_atr * atr
        return Order("stop", trig, trig + LIMIT_ATR * atr, stop, a, self.name, self.variant)


class SqueezeBurst(Family):
    """T1-4: at least min_len consecutive narrow sessions ending at the arming close, all on or after T
    (narrow = high - low <= nr_ratio x the previous close's ATR). Buy-stop at the squeeze high + 0.1 ATR
    or the close + 4%, whichever is lower. Stop: squeeze low - 0.1 ATR."""
    name = "T1-4"
    priority = 4

    def __init__(self, nr_ratio=0.75, min_len=3, pct_cap=0.04, variant=None):
        super().__init__(variant or "nr%g_n%d" % (nr_ratio, min_len))
        self.nr_ratio, self.min_len, self.pct_cap = float(nr_ratio), int(min_len), float(pct_cap)

    def _narrow(self, b, s):
        if s < 1:
            return False
        h, lo, prev_atr = b["high"][s], b["low"][s], b["atr"][s - 1]
        return _ok(h, lo, prev_atr) and (h - lo) <= self.nr_ratio * prev_atr

    def arm(self, b, cal, sel, a):
        T = sel.t_idx
        run = 0
        s = a
        while s >= T and self._narrow(b, s):
            run += 1
            s -= 1
        if run < self.min_len:
            return None
        seg = slice(a - run + 1, a + 1)
        sq_hi, sq_lo = np.nanmax(b["high"][seg]), np.nanmin(b["low"][seg])
        c, atr = b["close"][a], b["atr"][a]
        if not _ok(c, atr):
            return None
        trig = min(sq_hi + 0.1 * atr, c * (1.0 + self.pct_cap))
        if trig <= c:
            return None                                   # already through
        return Order("stop", trig, trig + LIMIT_ATR * atr, sq_lo - 0.1 * atr, a, self.name, self.variant)
