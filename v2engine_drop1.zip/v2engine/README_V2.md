# v2engine 0.1 (drop 1) - BigMove v2 execution engine core

Built 31 Oct 2026 from Spec v2.3 ("BigMove Execution Engine - Spec v2", Claude Doc).
**Synthetic data only.** Nothing here reads your cache, pick_meta, tradelab or pathlab. Real-data
commands are refused until the adapters are built on your uploaded pathlab and tradelab code.

## Run (cmd)

    cd /d C:\Users\karanvsi\PyCharmMiscProject\v2engine
    python v2engine.py --selftest quick     (about 20-30 s)
    python v2engine.py --selftest           (about 45-60 s; adds 20 calibration worlds)

Expected last line: `VERIFIED (v2engine 0.1 (drop 1))`. Needs numpy only (no pandas).

## What drop 1 contains

| File | What it does |
|---|---|
| v2_core.py | NSE session calendar (entry on T+1..T+10 inclusive; special sessions never take entries); selection registry (one immutable record per pick run / engine / rank / T, repeat flags, append-only store, corrections as new records); Wilder ATR14 known at each close; fill model; exits X1, X2, X3 (fixed R), X5; PLAN and OPEN6 per selection |
| v2_families.py | T1-1 delay, T1-2 turn after the dip, T1-4 burst after a squeeze; "already through" rule |
| v2_research.py | Per armed order: trigger vs B2, B2p, B3b, B4, B0, B0'. Budgeted book: allocator (2 a day, 6 in 5 sessions, 8 open, one per stock, same-stock selections merged into one order) for the trigger book and the act-now (B2) book; comparison on net return per session on the capital in use |
| v2_stats.py | Circular block bootstrap keyed by signal day; studentised max-t; Benjamini-Hochberg; empirical-Bayes pooling |
| v2engine.py | Command line: --selftest, --version; everything else refused ("not wired yet") |
| tests/v2_world.py | Synthetic worlds (martingale, continuous-path highs and lows; absent / planted / reverse T1-2 effect) |
| tests/test_v2.py | The suite |
| V2_DECLARATION_DRAFT.json | Every declared default so far. DRAFT: frozen only after the map and the trigger counts |

## Verified here

- Full suite: 60 checks, 0 failed, on Python 3.13 / numpy 2.5.3 and Python 3.12 / numpy 2.4.1 (your
  numpy); the two runs print identical numbers.
- Worlds (1,000 sessions, 150 stocks, T1-2, exit X1, test half = sessions 500-999):

| World | Trigger minus B2, per armed order | Minus B2p (same participation) | Minus B3b | Budgeted book minus B2 book, per session |
|---|---|---|---|---|
| absent (no effect, costs 0) | +2.7 bp [-22.6, +28.9] | +2.8 [-22.3, +28.7] | +14.0 [-9.1, +37.2] | -0.5 [-7.0, +5.6] |
| planted | +245.8 [+210.3, +281.5] | +244.1 [+210.4, +278.7] | +171.2 [+146.6, +194.4] | +32.8 [+25.7, +39.9] |
| reverse | -98.9 [-121.6, -74.9] | -100.8 [-123.2, -76.9] | -180.1 [-202.5, -158.5] | -16.8 [-24.0, -9.6] |

- A baseline chosen by later trigger outcomes (B2 on filled orders only) shows -295.0 bp
  [-357.4, -231.8] in a world with no effect; the honest B2 shows +8.2 [-22.1, +38.3]. This is why
  every baseline is fixed at the arming close.
- 11 planted bugs (mutations), each caught by the suite: already-through guard removed; B2 entering at
  the trigger's fill session; the 6-in-5 cap miscounted; no merging; window one session too long; ATR
  read one session ahead; target before stop; slippage ignored; X1 one session late; B3b ignoring the
  fill rate; the world's high taken from samples only.

## Found while building (changes to the spec)

1. **Buy-stop fills were optimistic.** With the high taken from sampled points, a fill at the trigger
   level faked +33.6 bp a trade in a world with no effect (the overshoot past the level is credited as
   profit; doc 13 saw the same with straight-line bars). The world now uses continuous-path highs and
   lows, and the fill model charges a declared buy-stop slippage of 0.05 ATR (stress 0 and 0.10).
   The opening auction (B2, T1-1) pays none.
2. **The 1,000-draw B3b percentile ran hot.** It holds the price paths fixed and ignores their noise:
   in 20 no-effect worlds 8 landed in the outer 10% (expected 2). Gate 3 now uses the paired form
   (trigger minus B3b's expected outcome per armed order, with the day-block interval): 0 of 20 missed.
3. **Per armed order, trading less is not skill.** A trigger that fills less often looks better or
   worse depending only on whether trading pays on average. Hence B2p and B3b at the family's
   training-year fill rate, and the budgeted book (which redeploys unused slots) as the primary test.

## Calibration (no-effect worlds, inference intervals)

Across 160 no-effect worlds the trigger-minus-B2 interval missed zero 14 times (8.75%, against 5%
nominal); the spread of z-scores was 1.00 to 1.08 in two 40-world runs. Slightly optimistic (an
inference from simulation, not a real-data measurement). A PASS still needs every lens, each engine and
2 of 3 test years.

## Not built yet

- Drop 2 (this session, next): T1-3 failed breakdown and T1-5 breakout acceptance on a tl_state events
  input; T1-7 home-index turn; X3 target learning with pooling; X4 structure target; Level 1 and
  Level 2 context contrasts; B3a (allocator null); per-family exit-policy choice on training years.
- After your zips: adapters to pick_meta (PM_20261017_001), stage E's loader and calendar, TLX trades
  (B0), tl_state, tl_context, the 3-minute store (T1-8, intraday order of events), the ETF rule;
  stage E's simulator for the money view; the watch-only Pine indicator; the trade map in tl_journal.

## Rules kept

No `label_*` input; no raw price level as a model input (levels appear only inside trigger rules); costs
35 bp; nothing written anywhere (the only writer is SelectionStore, used by the tests in a temporary
folder); no default paths.
