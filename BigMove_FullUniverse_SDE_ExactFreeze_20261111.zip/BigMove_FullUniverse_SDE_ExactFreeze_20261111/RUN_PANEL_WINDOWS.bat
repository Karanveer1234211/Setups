@echo off
setlocal
REM READ ONLY: All stock-dates already in panel, not only BigMove picks.
set "PANEL=C:\QuantData\cache_daily\panel\panel.parquet"
set "BASE=C:\QuantData\research_sde_exact_freeze"
for /f %%a in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "STAMP=%%a"
set "OUT=%BASE%\PANEL_%STAMP%"
echo [START] Exact frozen setups x full panel. Results: %OUT%
python "%~dp0sde_universe_setup_study.py" --panel "%PANEL%" --frozen-json "%~dp0FROZEN_SETUPS.json" --from 2021-01-01 --through 2026-09-22 --out "%OUT%"
if errorlevel 1 (
  echo [STOPPED] No production/frozen files were changed.
  pause
  exit /b 1
)
echo [COMPLETE] Open %OUT%\REPORT.md
pause
endlocal
