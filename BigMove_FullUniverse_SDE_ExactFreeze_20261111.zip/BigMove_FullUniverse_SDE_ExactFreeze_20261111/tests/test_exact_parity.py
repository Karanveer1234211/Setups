import sys, unittest
from pathlib import Path
import numpy as np
import pandas as pd
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import frozen_setuplab_reference as ref
import sde_universe_setup_study as study


class ExactFreezeTests(unittest.TestCase):
    def setUp(self):
        self.json_path=ROOT/'FROZEN_SETUPS.json'
        self.path, self.doc=ref.load_frozen(self.json_path)

    def make(self,n=310,seed=7):
        rng=np.random.default_rng(seed)
        dates=pd.bdate_range('2022-01-03',periods=n)
        logc=np.log(105.)+np.cumsum(rng.normal(0,.024,n))
        c=np.exp(logc)
        o=np.r_[c[0],c[:-1]*np.exp(rng.normal(0,.012,n-1))]
        h=np.maximum(c,o)*1.03
        l=np.minimum(c,o)*.97
        d={'symbol':'TST','timestamp':dates,'open':o,'high':h,'low':l,'close':c}
        for feat in study.FEATURES:
            if feat=='d_bb_pctb_20':
                d[feat]=rng.normal(.4,.7,n)
            else:
                d[feat]=rng.normal(0,10,n).astype(float)
        return study.normalize(pd.DataFrame(d))

    def test_supplied_frozen_json_passes_original_validator(self):
        self.assertEqual(self.doc['sha256'],'483f1539324f3ae5c06756b00b32c189f5eb995f73956a681673f005ce399c8f')
        self.assertEqual(tuple(ref.frozen_conds(self.doc)),study.ORDER)

    def test_sde_strict_extremes(self):
        self.assertAlmostEqual(study.sde10(np.arange(40.))[10],1)
        self.assertAlmostEqual(study.sde10(-np.arange(40.))[10],-1)
        self.assertEqual(study.sde_bucket(-.5),'MID')
        self.assertEqual(study.sde_bucket(.5),'MID')
        self.assertEqual(study.sde_bucket(-.5001),'NEG_LT_-0.5')

    def test_symbol_scan_equals_frozen_market_entries(self):
        # Cross-check actual market_entries() against the original trigger()
        # used by the new runner, across all 7 setups and 290+ random days.
        g=self.make(n=340)
        dates=g.timestamp.to_numpy().astype('datetime64[D]')
        n=len(g)
        d0=np.arange(10,n-5)
        sde=study.sde10(g.close)
        atr=ref.atr_simple(g.high.to_numpy(),g.low.to_numpy(),g.close.to_numpy())
        d_ok=np.zeros(n,bool)
        d_ok[d0]=np.isfinite(sde[d0]) & np.isfinite(atr[d0]) & (atr[d0]>0)
        f={}
        for name in study.FEATURES:
            f[name]=g[name].to_numpy(float)
            f[name+'_change']=np.r_[np.nan,np.diff(f[name])]
        ref_entries=ref.market_entries(dates, g.open.to_numpy(),g.close.to_numpy(),f,atr,ref.frozen_conds(self.doc),d_ok)
        cal={d:i for i,d in enumerate(g.timestamp)}
        actual,first,stats=study.scan_symbol(g,cal,None,None,self.doc,float(self.doc['cost_pp']))
        self.assertGreater(len(actual),15)
        for setup in study.ORDER:
            expected_dates=set(dates[ref_entries[setup]].astype(str))
            # market_entries() includes triggers whose exits are not yet recorded;
            # our scanner requires settled exits, so trim to available exits.
            sub=actual[actual.setup==setup]
            got_dates=set(sub.entry_date)
            self.assertTrue(got_dates.issubset(expected_dates),(setup,got_dates-expected_dates))
            available_end=dates[n-1]
            for x in expected_dates-got_dates:
                # If close at appropriate exit is complete, should have emitted.
                e=np.flatnonzero(dates.astype(str)==x)[0]
                if self.doc['setups'][study.ORDER.index(setup)]['primary_exit']=='fresh' and e+4>=n: continue
                self.fail(f'Missing frozen market_entries event {setup} {x}, row={e}')
        self.assertTrue(set(first[['symbol','d0_date']].itertuples(index=False,name=None)).issubset(
            set(actual[['symbol','d0_date']].itertuples(index=False,name=None))))

    def test_s1_picks_14day_simple_atr_not_current_ema_atr(self):
        g=self.make()
        a=ref.atr_simple(g.high.to_numpy(),g.low.to_numpy(),g.close.to_numpy())
        self.assertAlmostEqual(a[100], pd.Series(np.maximum(g.high.to_numpy()[1:]-g.low.to_numpy()[1:],
            np.maximum(abs(g.high.to_numpy()[1:]-g.close.to_numpy()[:-1]),
                       abs(g.low.to_numpy()[1:]-g.close.to_numpy()[:-1])))).rolling(14).mean().iloc[99]/g.close.iloc[100])

if __name__=='__main__': unittest.main()
