# Verification record

- Frozen config semantic SHA256: `483f1539324f3ae5c06756b00b32c189f5eb995f73956a681673f005ce399c8f`
- Original supplied JSON byte SHA256: `bed8fd610cf686af2ddafabfc9e6db43d2a60c9666e1076857da1d539c6da2e8`
- Original supplied `setuplab.py` byte SHA256: `9979d418aecec6debcd91991f5d4454696af866be8d84fb1fb79d977364e088f`
- Exact `setuplab.trigger()` is invoked for each setup and every hypothetical watch, not reimplemented.
- Original `setuplab.market_entries()` cross-check passed for all seven setups on random synthetic OHLCV/feature data.
- Comparison rounding: exactly original 9 decimal places.
- S1 ATR: original `setuplab.atr_simple`, captured at D0.
- N1 exit: `entry session + 4`; other exits: D0+5 close.
- No historical NSE full universe was run in this environment: original full cache is available only on the user's PC.
- PyArrow not available in container; CSV end-to-end and original feature-engine integration tests passed.
- No original source/frozen/production files changed.
