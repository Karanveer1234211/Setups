#!/usr/bin/env python3
"""Read-only FULL UNIVERSE SDE x FROZEN SETUPS, using the supplied setuplab v1.1 trigger.

The seven conditions, their ordering, nine-decimal comparisons, first-hit semantics,
ATR (simple 14 TR / D0 close), and primary exit are loaded from the hash-verified
FROZEN_SETUPS.json and frozen_setuplab_reference.py. NEVER edits these files.

Each stock/date is an independent hypothetical D0, not a BigMove-ranked pick.
Reports each frozen setup INDEPENDENTLY, plus earliest-entry first-setup-wins.
Exploratory conditional returns, NOT a capital-constrained investable strategy.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import sys
from collections import Counter
from pathlib import Path
import numpy as np
import pandas as pd
import frozen_setuplab_reference as freeze

FEATURES = ("d_bb_bw_20", "d_bb_pctb_20", "d_ema20_angle_deg", "d_mdi14",
            "d_mdi14_diff5", "d_wq_16", "d_wq_40", "d_wq_44", "w_ret_13w")
PRICE = ("timestamp", "symbol", "open", "high", "low", "close")
OTHER = ("d_dollar_vol", "volume")
EXCLUDED = {"NIFTY 50", "NIFTY BANK", "NIFTY IT", "INDIA VIX", "NIFTY50", "NIFTYBANK", "NIFTYIT"}
ORDER = ("S1", "S2", "S3", "C1", "C2", "C3", "N1")
OUTCOLS = ["symbol", "d0_date", "signal_date", "entry_date", "exit_date", "setup", "entry_watch_day",
           "sde_d0", "sde_signal", "sde_bucket_d0", "sde_bucket_signal", "entry_open", "exit_close",
           "net_setup_pct", "net_d1_same_exit_pct", "net_d1_d5_pct", "entry_discount_pp",
           "ret_vs_d1_same_exit_pp", "d0_atr_fraction", "entry_buyability_warning"]


def date_ist(s):
    t = pd.to_datetime(s, errors="coerce")
    if isinstance(t.dtype, pd.DatetimeTZDtype):
        t = t.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
    return t.dt.normalize()


def sde10(c):
    c = pd.Series(np.asarray(c, float))
    den = c.diff().abs().rolling(10, min_periods=10).sum()
    return ((c-c.shift(10))/den.where(den > 0)).to_numpy(float)


def sde_bucket(s):
    s = np.asarray(s)
    ret = np.select([s < -.5, s > .5], ["NEG_LT_-0.5", "POS_GT_+0.5"], default="MID")
    return ret.item() if s.ndim == 0 else ret


def read_panel(p):
    if p.suffix.lower() == ".parquet":
        import pyarrow.parquet as pq
        names = pq.read_schema(p).names
    else:
        names = list(pd.read_csv(p, nrows=0).columns)
    low = {x.lower(): x for x in names}
    requested = set(PRICE) | set(FEATURES)
    missing = requested - low.keys()
    if missing:
        raise ValueError("Required panel columns missing: " + ", ".join(sorted(missing)))
    all_fields = list(requested) + [x+"_change" for x in FEATURES if x+"_change" in low] + [x for x in OTHER if x in low]
    # Preserve source-supplied *_change columns when present, as setuplab Book._join does.
    columns = [low[x] for x in all_fields]
    if p.suffix.lower() == ".parquet":
        df = pd.read_parquet(p, columns=columns)
    else:
        df = pd.read_csv(p, usecols=columns)
    df = df.rename(columns={low[x]:x for x in all_fields})
    return normalize(df)


def normalize(df):
    df = df.copy()
    df.columns = [x.lower() for x in df.columns]
    if "date" in df and "timestamp" not in df:
        df = df.rename(columns={"date":"timestamp"})
    must = set(PRICE)|set(FEATURES)
    if not must.issubset(df):
        raise ValueError(f"Missing required columns {sorted(must-set(df))}")
    df["timestamp"] = date_ist(df["timestamp"])
    if df.timestamp.isna().any(): raise ValueError("Invalid session dates")
    df["symbol"] = df.symbol.astype(str).str.strip().str.upper()
    if df.duplicated(["symbol", "timestamp"]).any():
        raise ValueError("Duplicate symbol-date bars; no silent deduplication")
    for c in df.columns:
        if c not in ("timestamp", "symbol"):
            df[c] = pd.to_numeric(df[c], errors="coerce")
    return df.sort_values(["symbol", "timestamp"], kind="mergesort").reset_index(drop=True)


def from_raw(p, features_code, module_cache):
    if module_cache[0] is None:
        spec = importlib.util.spec_from_file_location("bigmove_features_raw_readonly", str(features_code))
        if spec is None or spec.loader is None: raise ValueError(f"Cannot load {features_code}")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        if hasattr(mod, "assert_leak_free"): mod.assert_leak_free()
        module_cache[0] = mod
    raw = pd.read_parquet(p)
    if not {"timestamp", "open", "high", "low", "close", "volume"}.issubset(raw):
        raise ValueError(f"Raw file {p} missing OHLCV")
    if raw.timestamp.isna().any() or raw.duplicated(["timestamp"]).any():
        raise ValueError(f"Missing/duplicate raw bars: {p}")
    raw = raw.sort_values("timestamp").reset_index(drop=True)
    built = module_cache[0].build_features(raw)
    built = module_cache[0].drop_warmup(built)
    built["symbol"] = p.name.removesuffix("_daily.parquet").upper()
    return normalize(built)


class PseudoBook:
    """Tiny read-only adapter to call the ORIGINAL setuplab.trigger() verbatim."""
    def __init__(self, g, d0, first_open, atr):
        self.n = len(d0)
        self.ok = np.ones(self.n, bool)
        self.O = np.full((self.n, 6), np.nan)
        self.arr = {}
        n = len(g)
        c = g.close.to_numpy(float)
        o = g.open.to_numpy(float)
        for day in range(1,6):
            e = d0+day
            self.O[:,day] = o[e]
        for f in FEATURES:
            a = g[f].to_numpy(float)
            chname = f+"_change"
            if chname in g:
                ch = g[chname].to_numpy(float)
            else:
                ch = np.r_[np.nan,np.diff(a)]
            vv = np.full((self.n,6), np.nan)
            cc = np.full((self.n,6), np.nan)
            for day in range(1,6):
                sig = d0+day-1
                vv[:,day] = a[sig]
                cc[:,day] = ch[sig]
            self.arr[f] = vv
            self.arr[chname] = cc
        for fld in ("gap_pct", "pc_vs_d1", "pc_vs_d1_atr", "day", "weekday", "prev_intraday", "prev_ret"):
            self.arr[fld] = np.full((self.n,6), np.nan)
        for day in range(1,6):
            e = d0+day
            j = e-1
            self.arr["gap_pct"][:,day] = (o[e]/c[j]-1)*100
            self.arr["day"][:,day] = float(day)
            self.arr["weekday"][:,day] = pd.DatetimeIndex(g.timestamp.to_numpy()[e]).weekday.to_numpy(float)
            if day == 1:
                for fld in ("pc_vs_d1", "pc_vs_d1_atr", "prev_intraday", "prev_ret"):
                    self.arr[fld][:,day] = 0.
            else:
                self.arr["pc_vs_d1"][:,day] = (c[j]/first_open-1)*100
                self.arr["pc_vs_d1_atr"][:,day] = (c[j]/first_open-1)/atr
                self.arr["prev_intraday"][:,day] = (c[j]/o[j]-1)*100
                self.arr["prev_ret"][:,day] = (c[j]/c[j-1]-1)*100

    def field(self, name):
        return self.arr[name]


def scan_symbol(g, calendar, start, end, doc, cost_pp):
    """All per-setup entries AND first-across-setup entries, using setuplab.trigger."""
    sde = sde10(g.close)
    o = g.open.to_numpy(float)
    h = g.high.to_numpy(float)
    l = g.low.to_numpy(float)
    c = g.close.to_numpy(float)
    dates = g.timestamp.to_numpy()
    n = len(g)
    stats = Counter()
    if n < 25:
        stats["short_history_symbols"] += 1
        return pd.DataFrame(columns=OUTCOLS), pd.DataFrame(columns=OUTCOLS), stats
    cal_idx = np.array([calendar[x] for x in g.timestamp], dtype=int)
    discontinuities = np.r_[0, np.cumsum(np.diff(cal_idx) != 1)]
    d0 = np.arange(10,n-5,dtype=int)
    if start is not None: d0 = d0[dates[d0] >= np.datetime64(start)]
    if end is not None: d0 = d0[dates[d0] <= np.datetime64(end)]
    stats["potential_d0_rows"] += len(d0)
    if not len(d0): return pd.DataFrame(columns=OUTCOLS), pd.DataFrame(columns=OUTCOLS), stats
    # Freeze's (simple SMA TR14)/D0-close, NOT Wilder or future ATR.
    atr_all = freeze.atr_simple(h,l,c)
    prices_valid = np.isfinite(o[d0+1]) & (o[d0+1] > 0) & np.isfinite(c[d0+5]) & (c[d0+5] > 0)
    consecutive = discontinuities[d0+5] == discontinuities[d0]
    valid = (np.isfinite(sde[d0]) & np.isfinite(atr_all[d0]) & (atr_all[d0] > 0) &
             prices_valid & consecutive)
    stats["d0_excluded_missing_price_sde_atr_or_sessions"] += int((~valid).sum())
    d0 = d0[valid]
    stats["eligible_d0"] += len(d0)
    if not len(d0): return pd.DataFrame(columns=OUTCOLS), pd.DataFrame(columns=OUTCOLS), stats
    book = PseudoBook(g, d0, o[d0+1], atr_all[d0])
    conds = freeze.frozen_conds(doc)
    setups_meta = {x["id"]:x for x in doc["setups"]}
    out = []
    first = np.full(len(d0), -1, int)
    first_s = np.full(len(d0), "", dtype="<U2")
    for setup in ORDER:
        k, status = freeze.trigger(book, conds[setup])
        stats[f"{setup}_missing_signal"] += int(np.sum(status == "Missing signal data"))
        found = k > 0
        stats[f"{setup}_raw_triggers"] += int(found.sum())
        hit_ix = np.flatnonzero(found)
        if not len(hit_ix): continue
        # First trigger wins chronologically even if its EXIT cannot yet settle.
        # Never replace an earlier trigger using the hindsight availability of
        # a later setup's exit. A first-hit with no complete exit is omitted.
        best = first[hit_ix]
        take = (best < 0) | (k[hit_ix] < best)
        first[hit_ix[take]] = k[hit_ix[take]]
        first_s[hit_ix[take]] = setup
        b = d0[hit_ix]
        ent = b+k[hit_ix]
        exit_idx = np.where(setups_meta[setup]["primary_exit"]=="fresh", ent+4, b+5)
        settle = (exit_idx < n)
        exclip = np.clip(exit_idx,0,n-1)
        settle &= (discontinuities[exclip]==discontinuities[ent]) & np.isfinite(c[exclip]) & (c[exclip] > 0)
        settle &= np.isfinite(o[ent]) & (o[ent] > 0)
        stats[f"{setup}_triggered_missing_settlement"] += int((~settle).sum())
        hit_ix = hit_ix[settle]
        if not len(hit_ix): continue
        b = d0[hit_ix]
        ent = b+k[hit_ix]
        endi = np.where(setups_meta[setup]["primary_exit"]=="fresh",ent+4,b+5)
        signal = ent-1
        traded = (c[endi]/o[ent]-1)*100-cost_pp
        # BOTH comparators: baseline D1 to same exit, and original D1 to D5.
        same_exit = (c[endi]/o[b+1]-1)*100-cost_pp
        orig_d5 = (c[b+5]/o[b+1]-1)*100-cost_pp
        gap = o[ent]/c[signal]-1
        locked = (np.isclose(o[ent],h[ent],atol=np.maximum(.001,o[ent]*1e-6),rtol=0) & (gap >= .019))
        rows = pd.DataFrame({
            "symbol": g.symbol.iloc[0],
            "d0_date": dates[b].astype("datetime64[D]").astype(str),
            "signal_date": dates[signal].astype("datetime64[D]").astype(str),
            "entry_date": dates[ent].astype("datetime64[D]").astype(str),
            "exit_date": dates[endi].astype("datetime64[D]").astype(str),
            "setup": setup, "entry_watch_day": k[hit_ix],
            "sde_d0": sde[b], "sde_signal": sde[signal],
            "sde_bucket_d0": sde_bucket(sde[b]), "sde_bucket_signal": sde_bucket(sde[signal]),
            "entry_open": o[ent], "exit_close": c[endi],
            "net_setup_pct": traded, "net_d1_same_exit_pct": same_exit,
            "net_d1_d5_pct": orig_d5,
            "entry_discount_pp": (o[b+1]/o[ent]-1)*100,
            "ret_vs_d1_same_exit_pp": traded-same_exit,
            "d0_atr_fraction": atr_all[b], "entry_buyability_warning": locked,
        })
        out.append(rows[OUTCOLS])
    all_df = pd.concat(out,ignore_index=True) if out else pd.DataFrame(columns=OUTCOLS)
    if all_df.empty:
        return all_df, all_df.copy(), stats
    ids = pd.DataFrame({"d0_date":dates[d0].astype("datetime64[D]").astype(str),
                        "setup":first_s, "entry_watch_day":first})
    ids = ids.loc[ids.entry_watch_day > 0]
    # Join exact first chosen key to underlying single-setup row for each D0.
    fw = all_df.merge(ids, on=["d0_date", "setup", "entry_watch_day"], how="inner", validate="one_to_one")
    stats["all_setup_entries"] += len(all_df)
    stats["first_setup_entries"] += len(fw)
    return all_df, fw, stats


def summarize(df, cols):
    head = cols + ["n", "avg_net_pct", "median_net_pct", "win_pct", "severe_loss_pct",
                   "mean_vs_d1_same_exit_pp", "mean_d1_d5_pct"]
    if df.empty: return pd.DataFrame(columns=head)
    out=[]
    for keys,g in df.groupby(cols,dropna=False):
        if not isinstance(keys,tuple): keys=(keys,)
        x=g.net_setup_pct.astype(float)
        out.append(dict(zip(cols,keys))|{"n":len(g), "avg_net_pct":x.mean(),
                 "median_net_pct":x.median(), "win_pct":100*(x>0).mean(),
                 "severe_loss_pct":100*(x<=-5).mean(),
                 "mean_vs_d1_same_exit_pp":g.ret_vs_d1_same_exit_pp.mean(),
                 "mean_d1_d5_pct":g.net_d1_d5_pct.mean()} )
    return pd.DataFrame(out)[head].sort_values(cols)


def report_outputs(df, prefix, out):
    df.to_csv(out/f"{prefix}_ALL_TRADES.csv",index=False)
    # INDEPENDENT: one stock+setup+entry event; several setups can fire same date.
    # FIRST-WINS: one stock+entry event; multiple synthetic D0s cannot generate
    # an executable separate order for the same stock and open.
    # Nearest preceding D0 retained, an EXPLORATORY dedup convention.
    event_key = (["symbol","entry_date"] if prefix == "first_setup_wins" else
                 ["symbol","setup","entry_date"])
    events = df.drop_duplicates(event_key,keep="last").copy()
    events.to_csv(out/f"{prefix}_UNIQUE_EVENTS.csv",index=False)
    for title,d in (("candidates",df),("events",events)):
        for key,cols in (("d0_sde",["sde_bucket_d0"]),
                         ("setup_x_d0_sde",["setup","sde_bucket_d0"]),
                         ("setup_x_signal_sde",["setup","sde_bucket_signal"]),
                         ("signal_sde",["sde_bucket_signal"])):
            summarize(d,cols).to_csv(out/f"{prefix}_{title}_{key}.csv",index=False)
        if not d.empty:
            y=d.copy()
            y["year"] = pd.to_datetime(y.entry_date).dt.year
            summarize(y,["year","setup","sde_bucket_d0"]).to_csv(out/f"{prefix}_{title}_year.csv",index=False)
        else: pd.DataFrame().to_csv(out/f"{prefix}_{title}_year.csv",index=False)
    return events


def plot_results(events, out, prefix):
    if events.empty: return
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return
    groups = ["NEG_LT_-0.5","MID","POS_GT_+0.5"]
    vals=[events.loc[events.sde_bucket_signal==x,"net_setup_pct"].mean() for x in groups]
    ns=[int((events.sde_bucket_signal==x).sum()) for x in groups]
    fig,ax=plt.subplots(figsize=(10,5))
    bars=ax.bar(["< -0.5","middle","> +0.5"],vals)
    ax.axhline(0,c="gray",lw=.8)
    for bar,n,v in zip(bars,ns,vals):
        if np.isfinite(v): ax.annotate(f"{v:+.2f}% (n={n:,})",(bar.get_x()+bar.get_width()/2,v),
                                     xytext=(0,5 if v>=0 else -15),textcoords="offset points",ha="center")
    ax.set_ylabel("Net return %")
    ax.set_title(f"{prefix}: unique setup events by PRE-ENTRY signal-close SDE10")
    fig.tight_layout()
    fig.savefig(out/f"{prefix}_by_signal_sde.png",dpi=165)
    plt.close(fig)
    fig,ax=plt.subplots(figsize=(10,5))
    sub=events.sample(min(len(events),20000),random_state=22)
    ax.scatter(sub.sde_d0,sub.net_setup_pct,alpha=.14,s=8)
    ax.axvline(-.5,c="gray",ls="--");ax.axvline(.5,c="gray",ls="--");ax.axhline(0,c="gray",lw=.7)
    ax.set_xlabel("SDE10 at hypothetical D0 close")
    ax.set_ylabel("Net setup return %")
    ax.set_title(f"{prefix}: SDE vs setup return")
    fig.tight_layout()
    fig.savefig(out/f"{prefix}_scatter.png",dpi=165)
    plt.close(fig)


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    src=p.add_mutually_exclusive_group(required=True)
    src.add_argument("--panel",type=Path)
    src.add_argument("--daily-dir",type=Path)
    p.add_argument("--features-code",type=Path,help="Original features_daily.py required for --daily-dir")
    p.add_argument("--frozen-json",type=Path,default=Path(__file__).resolve().with_name("FROZEN_SETUPS.json"))
    p.add_argument("--out",type=Path,required=True)
    p.add_argument("--from",dest="start",default="2021-01-01")
    p.add_argument("--through",dest="end",default="2026-09-22")
    p.add_argument("--limit-symbols",type=int,default=0,help="DEBUG ONLY")
    args=p.parse_args(argv)
    if args.out.exists(): p.error(f"Refusing to overwrite output directory: {args.out}")
    if args.daily_dir and not args.features_code: p.error("--daily-dir needs --features-code")
    if args.panel and not args.panel.is_file(): p.error(f"Missing panel {args.panel}")
    if args.daily_dir and not args.daily_dir.is_dir(): p.error(f"Missing raw folder {args.daily_dir}")
    if args.features_code and not args.features_code.is_file(): p.error(f"Missing feature source {args.features_code}")
    frozen_path,doc=freeze.load_frozen(args.frozen_json)
    if tuple(x["id"] for x in doc["setups"])!=ORDER: raise ValueError("Unexpected frozen setup list/order")
    if tuple(freeze.frozen_features(doc)) and set(freeze.frozen_features(doc)) != set(FEATURES):
        raise ValueError("Unexpected frozen feature names")
    start,end=pd.Timestamp(args.start),pd.Timestamp(args.end)
    if end<start:p.error("--through precedes --from")
    if args.panel:
        df=read_panel(args.panel)
        dates=pd.DatetimeIndex(df.timestamp.unique()).sort_values()
        groups=((s,g) for s,g in df.groupby("symbol",sort=True))
        count=df.symbol.nunique()
    else:
        paths=sorted(args.daily_dir.glob("*_daily.parquet"))
        if not paths: raise ValueError("No *_daily.parquet files found")
        print(f"Reading calendar from {len(paths)} files",flush=True)
        calset=set()
        for i,pth in enumerate(paths):
            t=pd.read_parquet(pth,columns=["timestamp"])
            calset.update(date_ist(t.timestamp).dropna().tolist())
            if (i+1)%250==0: print(f"Calendar: {i+1}/{len(paths)}",flush=True)
        dates=pd.DatetimeIndex(sorted(calset))
        module=[None]
        groups=((pth.stem,from_raw(pth,args.features_code,module)) for pth in paths)
        count=len(paths)
    calendar={d:i for i,d in enumerate(dates)}
    args.out.mkdir(parents=True)
    allframes=[]; firstframes=[]; c=Counter(); processed=0
    print(f"READ ONLY | Frozen verified {doc['sha256']} | cost {doc['cost_pp']} pp",flush=True)
    for sym,g in groups:
        if str(sym).strip().upper() in EXCLUDED:
            c["excluded_non_stock"]+=1
            continue
        if args.limit_symbols and processed >= args.limit_symbols:break
        processed+=1
        try:
            a,f,s=scan_symbol(g,calendar,start,end,doc,float(doc["cost_pp"]))
        except Exception as exc:
            raise RuntimeError(f"STOPPED on {sym}: {exc}") from exc
        c.update(s)
        if len(a):allframes.append(a)
        if len(f):firstframes.append(f)
        if processed%100==0:print(f"Stocks: {processed}/{count}; all setup entries: {c['all_setup_entries']:,}",flush=True)
    all_df=pd.concat(allframes,ignore_index=True) if allframes else pd.DataFrame(columns=OUTCOLS)
    first_df=pd.concat(firstframes,ignore_index=True) if firstframes else pd.DataFrame(columns=OUTCOLS)
    all_df=all_df.sort_values(["symbol","setup","entry_date","d0_date"],kind="mergesort").reset_index(drop=True)
    first_df=first_df.sort_values(["symbol","setup","entry_date","d0_date"],kind="mergesort").reset_index(drop=True)
    all_events=report_outputs(all_df,"independent_setups",args.out)
    first_events=report_outputs(first_df,"first_setup_wins",args.out)
    for name,e in [("independent_setups",all_events),("first_setup_wins",first_events)]:plot_results(e,args.out,name)
    run={"status":"VERIFIED FROZEN RULES + ORIGINAL setuplab.trigger / EXPLORATORY FULL-UNIVERSE STUDY",
        "source":str(args.panel or args.daily_dir), "stock_count":processed,
        "feature_source":str(args.features_code) if args.features_code else "panel features",
        "frozen_sha256":doc["sha256"],
        "frozen_reference_code_file_sha256":hashlib.sha256(Path(freeze.__file__).read_bytes()).hexdigest(),
        "all_pseudo_d0_setup_rows":len(all_df),"independent_unique_symbol_setup_entry_events":len(all_events),
        "first_wins_rows":len(first_df),"first_wins_unique_stock_entry_events":len(first_events),
        "cost_roundtrip_pp":doc["cost_pp"],"counters":dict(c),
        "caveats":["All stocks and all dates are hypothetical D0 watches; NO BigMove model selection",
          "Each setup is tested separately. First-wins selects earliest settled setup; same-day tie uses JSON setup order as SHADOW research convention (not a Tree rule).",
          "Unique-event dedup uses nearest D0; independent setup events by symbol+setup+entry, first-wins by symbol+entry. D0 SDE depends on hypothetical watch date; signal-close SDE is unambiguous for a shared entry event.",
          "S1 ATR is full-history 14-period SIMPLE TR divided by D0 close, matching setuplab.atr_simple; not Wilder ATR.",
          "setuplab.trigger stops a D0/setup if a missing needed feature cannot be ruled out by a false condition.",
          "No simultaneous-position capital limit, market impact/circuit fill certainty, or independent OOS test.",
          "No slippage beyond frozen 35bp assumption; split/merger adjusted OHLCV and historic NSE universe remain inputs' responsibility.",
          "D1 baseline same-exit comparison is required for N1, whose fresh exit is later than D5."]}
    (args.out/"RUN.json").write_text(json.dumps(run,indent=2,default=str),encoding="utf-8")
    lines=["# BigMove full universe | Extreme SDE x EXACT frozen setup definitions","",
           f"Frozen source validated: `{doc['sha256']}`; evaluator: original `setuplab.trigger` (nine-decimal comparison / missing semantics).",
           f"Scanned {processed:,} cached stock files/panel symbols, {c['eligible_d0']:,} eligible synthetic D0 sessions.",
           "Every stock/date is eligible (not only BigMove Top-3). Costs = 0.35 pp round trip. No portfolio constraint.",
           "", "## Independent setup events (unique symbol + setup + entry date)",""]
    for section,e in [("All seven independent setups",all_events),("First setup wins",first_events)]:
        lines += ["## "+section,"","| Signal-close SDE10 | N | Mean setup return | Win rate | Loss >=5% |",
                  "|---|---:|---:|---:|---:|"]
        summary=summarize(e,["sde_bucket_signal"]).set_index("sde_bucket_signal") if len(e) else pd.DataFrame()
        for label in ("NEG_LT_-0.5","MID","POS_GT_+0.5"):
            if len(e) and label in summary.index:
                r=summary.loc[label]
                lines.append(f"| {label} | {int(r['n']):,} | {r['avg_net_pct']:+.3f}% | {r['win_pct']:.1f}% | {r['severe_loss_pct']:.1f}% |")
            else: lines.append(f"| {label} | 0 | - | - | - |")
        lines += ["","See `*_events_setup_x_signal_sde.csv` for setup-specific groups and `*_candidates_*` for the D0-SDE universe.",""]
    lines += ["## Interpretation", "", "The pre-entry SDE signal-close groups are most meaningful for unique entry events. A signal is known at the prior close; S2 also needs the next open to gap down.","",
              "D0 SDE is valid in the candidate-level watch tests but is not unique when multiple earlier D0s lead to the same trade. Avoid inferring significance from overlapping windows.",
              "","**No live modifications.** Neither the user's production files nor the frozen research source is written to."]
    (args.out/"REPORT.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(f"FINISHED: {len(all_df):,} per-setup candidate rows, {len(first_df):,} first-wins rows.",flush=True)
    print(f"Report: {args.out/'REPORT.md'}",flush=True)
    return 0

if __name__=="__main__":
    try:raise SystemExit(main())
    except Exception as exc:
        print(f"[STOPPED] {type(exc).__name__}: {exc}",file=sys.stderr)
        raise
