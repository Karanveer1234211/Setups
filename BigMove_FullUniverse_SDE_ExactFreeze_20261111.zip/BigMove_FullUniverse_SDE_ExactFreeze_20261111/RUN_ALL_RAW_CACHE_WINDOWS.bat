@echo off
setlocal
REM READ ONLY: All cached stocks, recomputes frozen feature definitions.
REM EDIT DAILY if *_daily.parquet files reside in a different subfolder.
set "DAILY=C:\QuantData\cache_daily"
set "FEATURES=C:\Users\karanvis\PyCharmProjects\bigmove_deploy\features_daily.py"
set "BASE=C:\QuantData\research_sde_exact_freeze"
for /f %%a in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "STAMP=%%a"
set "OUT=%BASE%\RAW_%STAMP%"
echo [START] Exact frozen setups x ALL cached symbols. Results: %OUT%
python "%~dp0sde_universe_setup_study.py" --daily-dir "%DAILY%" --features-code "%FEATURES%" --frozen-json "%~dp0FROZEN_SETUPS.json" --from 2021-01-01 --through 2026-09-22 --out "%OUT%"
if errorlevel 1 (
  echo [STOPPED] Verify raw cache folder and features_daily.py path.
  pause
  exit /b 1
)
echo [COMPLETE] Open %OUT%\REPORT.md
pause
endlocal
