# setuplab - setups x logical confluences (setuplab v0.6) - engine D, ranks 1-10, 15819 picks

Pool: NONE, A, B, C, A+B, A+C, B+C, w_ret_13w_change<0&d_mdi14_change>0, w_ret_13w_change<0&d_mdi14_rrank20_change>0, w_ret_13w_change<0&d_ema20_angle_z252_change<0, w_ret_13w_change<0&d_rsi7_change<0, w_ret_13w_change<0&d_rsi14_z252_change<0, w_ret_13w_change<0&d_dist_from_52wl_change<0, w_ret_13w_change<0&d_mdi14_rrank10_change>0, w_ret_13w_change<0&d_bb_pctb_20_change<0, w_ret_13w_change<0&d_dist_from_20h_change<0, w_ret_13w_change<0&d_mdi14_diff5_change>0, w_ret_13w_change<0&d_wq_40_change>0, w_ret_13w_change<0&d_lh_run_change>0, w_ret_13w_change<0&x_z_d_downside_dev_60_change>0, w_ret_13w_change<0&d_adx14_change>0, w_ret_13w_change<0&d_wq_16_change>0, w_ret_13w_change<0&d_ll_run_change>0, w_ret_13w_change<0&d_wq_29_change>0, d_ema20_angle_deg_change<0&d_ema20_angle_z252_change>0, d_rsi7_change<0&d_donch_pos_20_change>0, d_rsi14_z252_change<0&d_donch_pos_20_change>0, w_ret_13w_change<0&d_amihud_60_change>0.

Confluences (declared before the run): price DIP1, DIP2, DIP3, DIPATR1, GREEN, UPCLOSE, GAPDOWN, GAPUP; context BEARSTATE, BULLSTATE, NIFTY_ABOVE_MA50, NIFTY_BELOW_MA50, MKT_BULLISH, MKT_BEARISH, VIX_LOW, VIX_HIGH, BREADTH_WEAK, NOT_OVEREXT, VOL_ELEVATED, TOP3; and every price x context pair.

Each row: the combination's own trades vs the model's D1 entry on the same ids; 'adds' = the same combination vs the confluence ALONE on the same ids (what the indicator setup adds); years = signal years with net per trade above 0. Net % after 0.35 pp; 95% block bootstrap over signal days. Exploratory: 3248 combinations on the history the setups came from - expect some to look good by chance.

## original_d5 exit - top 25 combinations by net per trade (n >= 150, lift over D1 interval above 0)

| setup | confluence | n | net | D1 | lift over D1 [95%] | adds over the confluence alone [95%] | years net > 0 |
|---|---|---:|---:|---:|---|---|---:|
| w_ret_13w_change<0&d_wq_40_change>0 | GAPDOWN&VOL_ELEVATED | 460 | +3.2858 | +0.3820 | +2.9038 [+2.1589, +3.6273] | +1.9617 [+1.3068, +2.5895] | 6/7 |
| w_ret_13w_change<0&d_wq_16_change>0 | GAPDOWN&MKT_BEARISH | 420 | +3.1414 | -0.0034 | +3.1449 [+2.2457, +4.0277] | +2.0264 [+1.2829, +2.7469] | 6/7 |
| w_ret_13w_change<0&d_wq_16_change>0 | GAPDOWN&VOL_ELEVATED | 530 | +3.0727 | +0.2824 | +2.7904 [+2.0566, +3.4847] | +1.8201 [+1.1947, +2.4268] | 7/7 |
| w_ret_13w_change<0&d_wq_40_change>0 | GAPDOWN&BEARSTATE | 455 | +3.0349 | -0.3558 | +3.3907 [+2.6917, +4.0434] | +2.4462 [+1.8406, +3.0786] | 7/7 |
| B+C | GAPDOWN&MKT_BEARISH | 321 | +3.0142 | -1.4638 | +4.4780 [+3.5914, +5.2910] | +2.9759 [+2.2046, +3.7701] | 5/7 |
| w_ret_13w_change<0&d_mdi14_diff5_change>0 | GAPDOWN&VOL_ELEVATED | 525 | +2.9373 | -1.0612 | +3.9985 [+3.1709, +4.7292] | +2.5582 [+1.8653, +3.2743] | 7/7 |
| w_ret_13w_change<0&d_wq_16_change>0 | GAPDOWN&BEARSTATE | 505 | +2.8858 | +0.0020 | +2.8839 [+2.1341, +3.6162] | +2.0332 [+1.4081, +2.6874] | 7/7 |
| w_ret_13w_change<0&d_wq_16_change>0 | DIP3&MKT_BEARISH | 408 | +2.8703 | -4.6430 | +7.5133 [+6.8093, +8.2052] | +1.8160 [+1.2834, +2.3412] | 7/7 |
| w_ret_13w_change<0&d_wq_16_change>0 | GAPDOWN&NIFTY_BELOW_MA50 | 620 | +2.8456 | -0.2706 | +3.1162 [+2.4118, +3.7887] | +1.8932 [+1.3363, +2.4509] | 6/7 |
| w_ret_13w_change<0&d_wq_16_change>0 | DIP2&MKT_BEARISH | 471 | +2.8364 | -3.9429 | +6.7793 [+6.0528, +7.4672] | +1.9274 [+1.3772, +2.4638] | 7/7 |
| w_ret_13w_change<0&d_wq_40_change>0 | DIP3&MKT_BEARISH | 341 | +2.8340 | -5.2141 | +8.0481 [+7.3110, +8.7049] | +1.9814 [+1.4132, +2.4801] | 7/7 |
| B+C | DIPATR1&BEARSTATE | 212 | +2.8286 | -6.9346 | +9.7632 [+8.8597, +10.6216] | +1.6463 [+1.1046, +2.1523] | 6/7 |
| w_ret_13w_change<0&d_wq_16_change>0 | DIPATR1&VOL_ELEVATED | 241 | +2.8147 | -7.2210 | +10.0357 [+9.1949, +10.8402] | +1.1964 [+0.7372, +1.6194] | 6/7 |
| w_ret_13w_change<0&d_wq_16_change>0 | DIPATR1&BEARSTATE | 249 | +2.8122 | -6.7813 | +9.5935 [+8.7277, +10.3495] | +1.6080 [+1.0582, +2.1158] | 6/7 |
| w_ret_13w_change<0&d_wq_40_change>0 | DIP2&MKT_BEARISH | 389 | +2.8053 | -4.4953 | +7.3006 [+6.5818, +7.9410] | +2.0504 [+1.4120, +2.6230] | 7/7 |
| B+C | DIP3&BEARSTATE | 369 | +2.7860 | -4.9801 | +7.7661 [+7.0272, +8.4704] | +1.9862 [+1.4420, +2.4965] | 6/7 |
| A+C | GAPDOWN&VOL_ELEVATED | 275 | +2.7703 | -1.5448 | +4.3151 [+3.4050, +5.1749] | +3.0314 [+2.2147, +3.8712] | 6/7 |
| w_ret_13w_change<0&d_wq_40_change>0 | DIPATR1&MKT_BEARISH | 192 | +2.7378 | -7.3605 | +10.0983 [+9.2533, +10.9193] | +1.6953 [+1.1749, +2.1316] | 6/7 |
| B+C | GAPDOWN&VOL_ELEVATED | 383 | +2.6998 | -1.4048 | +4.1046 [+3.3685, +4.8160] | +2.7203 [+2.0614, +3.4233] | 6/7 |
| w_ret_13w_change<0&d_wq_16_change>0 | DIPATR1&MKT_BEARISH | 225 | +2.6672 | -6.9495 | +9.6168 [+8.6675, +10.5490] | +1.3261 [+0.8061, +1.8369] | 6/7 |
| w_ret_13w_change<0&d_wq_40_change>0 | DIPATR1&VOL_ELEVATED | 183 | +2.6610 | -7.8912 | +10.5522 [+9.8003, +11.3016] | +1.2145 [+0.8044, +1.5904] | 6/7 |
| A+C | GAPDOWN&VIX_LOW | 270 | +2.6568 | -1.2593 | +3.9161 [+3.2186, +4.6236] | +2.3082 [+1.6806, +3.0517] | 5/7 |
| A+C | DIPATR1&BEARSTATE | 192 | +2.6255 | -7.1832 | +9.8087 [+8.8023, +10.7330] | +1.6307 [+1.0494, +2.1940] | 6/7 |
| B+C | DIP2&BEARSTATE | 415 | +2.6074 | -4.5680 | +7.1753 [+6.4300, +7.8637] | +2.3722 [+1.8244, +2.8694] | 6/7 |
| w_ret_13w_change<0&d_wq_40_change>0 | DIPATR1&BEARSTATE | 216 | +2.6007 | -7.2764 | +9.8771 [+9.0072, +10.6495] | +1.7011 [+1.1956, +2.1526] | 6/7 |

### The confluences ALONE (no indicator setup) - top 15 by net per trade (n >= 150)

| confluence | n | net | D1 | lift over D1 [95%] | years net > 0 |
|---|---:|---:|---:|---|---:|
| BEARSTATE | 4635 | +1.2491 | +1.2491 | +0.0000 [+0.0000, +0.0000] | 6/7 |
| TOP3 | 4716 | +1.2377 | +1.2377 | +0.0000 [+0.0000, +0.0000] | 7/7 |
| VOL_ELEVATED | 5040 | +1.2013 | +1.2013 | +0.0000 [+0.0000, +0.0000] | 6/7 |
| VIX_HIGH | 7909 | +1.1049 | +1.1049 | +0.0000 [+0.0000, +0.0000] | 6/7 |
| DIP3&BEARSTATE | 1985 | +0.9845 | -4.3750 | +5.3595 [+5.0079, +5.7468] | 6/7 |
| BREADTH_WEAK | 7902 | +0.9466 | +0.9466 | +0.0000 [+0.0000, +0.0000] | 5/7 |
| DIPATR1&VOL_ELEVATED | 1037 | +0.9449 | -8.2519 | +9.1968 [+8.4210, +10.1361] | 5/7 |
| GAPDOWN&TOP3 | 3462 | +0.9370 | +0.5127 | +0.4242 [+0.2239, +0.6133] | 7/7 |
| DIP2&BEARSTATE | 2375 | +0.8988 | -3.4088 | +4.3076 [+3.9819, +4.6597] | 6/7 |
| GAPUP&BEARSTATE | 4476 | +0.8946 | +1.5550 | -0.6603 [-0.8514, -0.4848] | 7/7 |
| NOT_OVEREXT | 15236 | +0.8908 | +0.8908 | +0.0000 [+0.0000, +0.0000] | 7/7 |
| GAPUP&TOP3 | 4586 | +0.8837 | +1.4774 | -0.5937 [-0.7200, -0.4645] | 7/7 |
| DIP2&TOP3 | 2229 | +0.8785 | -3.2694 | +4.1480 [+3.9320, +4.3637] | 6/7 |
| DIPATR1&BEARSTATE | 1104 | +0.8672 | -7.3628 | +8.2300 [+7.4303, +9.2100] | 6/7 |
| NIFTY_BELOW_MA50 | 5892 | +0.8626 | +0.8626 | +0.0000 [+0.0000, +0.0000] | 6/7 |

## fresh exit - top 25 combinations by net per trade (n >= 150, lift over D1 interval above 0)

| setup | confluence | n | net | D1 | lift over D1 [95%] | adds over the confluence alone [95%] | years net > 0 |
|---|---|---:|---:|---:|---|---|---:|
| w_ret_13w_change<0&d_wq_40_change>0 | DIPATR1&BEARSTATE | 216 | +4.7184 | -7.2764 | +11.9948 [+10.1583, +13.7107] | +2.0986 [+1.1103, +3.0629] | 6/7 |
| w_ret_13w_change<0&d_wq_40_change>0 | DIPATR1&VOL_ELEVATED | 183 | +4.3511 | -7.8912 | +12.2422 [+10.6820, +13.8459] | +1.5016 [+0.7881, +2.2848] | 6/7 |
| w_ret_13w_change<0&d_wq_40_change>0 | DIPATR1&MKT_BEARISH | 192 | +4.2478 | -7.3605 | +11.6083 [+9.8363, +13.4083] | +2.0794 [+1.0137, +3.1292] | 6/7 |
| w_ret_13w_change<0&d_adx14_change>0 | DIPATR1&VIX_LOW | 315 | +4.2394 | -6.0171 | +10.2565 [+8.4886, +11.8597] | +1.7815 [+1.0873, +2.4550] | 6/7 |
| w_ret_13w_change<0&d_wq_16_change>0 | DIPATR1&VOL_ELEVATED | 241 | +4.2378 | -7.2210 | +11.4588 [+9.5615, +13.3732] | +0.9874 [+0.1530, +1.8592] | 6/7 |
| w_ret_13w_change<0&d_wq_29_change>0 | DIPATR1&BEARSTATE | 279 | +4.1578 | -6.9906 | +11.1484 [+9.5035, +12.8864] | +1.5663 [+0.9923, +2.2207] | 6/7 |
| w_ret_13w_change<0&d_wq_16_change>0 | DIP3&MKT_BEARISH | 408 | +4.1133 | -4.6430 | +8.7563 [+7.1809, +10.2299] | +1.9264 [+1.0513, +2.7432] | 6/7 |
| w_ret_13w_change<0&d_mdi14_diff5_change>0 | DIPATR1&VOL_ELEVATED | 261 | +4.0993 | -7.9481 | +12.0475 [+10.2307, +13.6756] | +1.3815 [+0.7828, +1.9872] | 6/7 |
| A+C | DIPATR1&VOL_ELEVATED | 157 | +4.0762 | -8.2704 | +12.3466 [+10.0483, +14.7397] | +1.5362 [+0.6476, +2.5120] | 6/7 |
| w_ret_13w_change<0&d_wq_29_change>0 | DIPATR1&VOL_ELEVATED | 246 | +4.0720 | -7.6748 | +11.7468 [+9.9591, +13.4560] | +1.2621 [+0.7523, +1.8736] | 6/7 |
| w_ret_13w_change<0&d_mdi14_diff5_change>0 | DIPATR1&BEARSTATE | 276 | +4.0517 | -7.3942 | +11.4459 [+9.7525, +13.1201] | +1.6473 [+0.9592, +2.3293] | 6/7 |
| w_ret_13w_change<0&d_wq_16_change>0 | DIPATR1&MKT_BEARISH | 225 | +4.0494 | -6.9495 | +10.9989 [+8.8519, +13.1668] | +1.4700 [+0.3784, +2.5175] | 6/7 |
| w_ret_13w_change<0&d_wq_16_change>0 | DIPATR1&BEARSTATE | 249 | +4.0426 | -6.7813 | +10.8239 [+8.9801, +12.6682] | +1.5136 [+0.5205, +2.4760] | 6/7 |
| w_ret_13w_change<0&d_wq_16_change>0 | DIP2&MKT_BEARISH | 471 | +4.0237 | -3.9429 | +7.9666 [+6.5292, +9.3564] | +1.9963 [+1.2045, +2.7343] | 7/7 |
| w_ret_13w_change<0&d_mdi14_change>0 | DIPATR1&VOL_ELEVATED | 332 | +3.9483 | -8.0306 | +11.9789 [+10.4845, +13.4512] | +1.4558 [+0.8526, +2.0794] | 6/7 |
| w_ret_13w_change<0&d_wq_40_change>0 | DIP3&MKT_BEARISH | 341 | +3.9440 | -5.2141 | +9.1581 [+7.7404, +10.5308] | +2.2319 [+1.2249, +3.1579] | 6/7 |
| w_ret_13w_change<0&d_wq_40_change>0 | GAPDOWN&BEARSTATE | 455 | +3.9401 | -0.3558 | +4.2959 [+3.2429, +5.4117] | +2.7431 [+2.0769, +3.5024] | 7/7 |
| A+C | DIPATR1&BREADTH_WEAK | 295 | +3.8236 | -6.6142 | +10.4378 [+8.6855, +12.1416] | +1.6096 [+0.9599, +2.2971] | 6/7 |
| w_ret_13w_change<0&d_mdi14_diff5_change>0 | DIPATR1&VIX_LOW | 438 | +3.7981 | -5.5000 | +9.2981 [+7.9556, +10.6544] | +1.6625 [+1.1545, +2.1884] | 6/7 |
| B+C | DIPATR1&BEARSTATE | 212 | +3.7638 | -6.9346 | +10.6984 [+8.8293, +12.6214] | +1.6143 [+0.7451, +2.4657] | 6/7 |
| w_ret_13w_change<0&d_mdi14_change>0 | DIPATR1&BEARSTATE | 362 | +3.7205 | -7.3366 | +11.0571 [+9.6166, +12.5527] | +1.6276 [+0.9569, +2.2559] | 6/7 |
| w_ret_13w_change<0&d_wq_40_change>0 | DIP2&MKT_BEARISH | 389 | +3.7058 | -4.4953 | +8.2010 [+6.6794, +9.5840] | +2.1388 [+1.0593, +3.1046] | 6/7 |
| w_ret_13w_change<0&d_mdi14_diff5_change>0 | DIP3&MKT_BEARISH | 416 | +3.6818 | -5.7155 | +9.3973 [+7.8980, +10.7788] | +2.5206 [+1.9060, +3.1108] | 6/7 |
| w_ret_13w_change<0&d_wq_40_change>0 | GAPDOWN&VOL_ELEVATED | 460 | +3.6814 | +0.3820 | +3.2994 [+2.2063, +4.4374] | +1.9647 [+1.2995, +2.7023] | 6/7 |
| w_ret_13w_change<0&d_mdi14_diff5_change>0 | DIP2&MKT_BEARISH | 471 | +3.6802 | -5.0143 | +8.6944 [+7.2923, +10.0172] | +2.6307 [+1.9791, +3.2439] | 6/7 |

### The confluences ALONE (no indicator setup) - top 15 by net per trade (n >= 150)

| confluence | n | net | D1 | lift over D1 [95%] | years net > 0 |
|---|---:|---:|---:|---|---:|
| DIPATR1&VOL_ELEVATED | 1037 | +1.4407 | -8.2519 | +9.6926 [+8.6644, +10.7738] | 6/7 |
| DIP3&BEARSTATE | 1985 | +1.3521 | -4.3750 | +5.7271 [+5.0294, +6.3763] | 5/7 |
| DIP2&TOP3 | 2229 | +1.3268 | -3.2694 | +4.5963 [+4.2120, +4.9958] | 7/7 |
| DIPATR1&BREADTH_WEAK | 1969 | +1.2829 | -6.7986 | +8.0815 [+7.2428, +8.9175] | 6/7 |
| DIP2&BEARSTATE | 2375 | +1.2607 | -3.4088 | +4.6695 [+4.0737, +5.2586] | 5/7 |
| DIPATR1&TOP3 | 1105 | +1.2534 | -6.4292 | +7.6826 [+7.0506, +8.3711] | 6/7 |
| BEARSTATE | 4635 | +1.2491 | +1.2491 | +0.0000 [+0.0000, +0.0000] | 6/7 |
| TOP3 | 4716 | +1.2377 | +1.2377 | +0.0000 [+0.0000, +0.0000] | 7/7 |
| DIP3&BREADTH_WEAK | 3253 | +1.2263 | -4.4549 | +5.6812 [+5.1378, +6.1990] | 6/7 |
| GAPDOWN&TOP3 | 3462 | +1.2238 | +0.5127 | +0.7111 [+0.4381, +0.9842] | 7/7 |
| VOL_ELEVATED | 5040 | +1.2013 | +1.2013 | +0.0000 [+0.0000, +0.0000] | 6/7 |
| DIPATR1&BEARSTATE | 1104 | +1.1617 | -7.3628 | +8.5245 [+7.5241, +9.5500] | 5/7 |
| DIP3&MKT_BEARISH | 1554 | +1.1525 | -4.8066 | +5.9591 [+5.0595, +6.8208] | 5/7 |
| DIP3&TOP3 | 1786 | +1.1283 | -4.3290 | +5.4572 [+5.0322, +5.9167] | 6/7 |
| DIP2&MKT_BEARISH | 1830 | +1.1226 | -3.8810 | +5.0037 [+4.2303, +5.7894] | 5/7 |

