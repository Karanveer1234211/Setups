"""A FROZEN SETUP as a strategy (setups add-on v1.0): S2 on D's and ENS's ranks 1-10, the way setuplab tests it.

S2 (frozen 8 Nov 2026, setuplab FROZEN_SETUPS.json): at the close before the entry day -DI's 5-day change rose and
the 13-week return fell, and the entry day OPENS below that close (a gap down) - inside the pick's five watch days.
The leg {"setup": "S2"} buys the OPEN of S2's own entry day (D1..D5) as setuplab's tags record it; a pick where S2
never entered is not traded (0 bp, cash). Exit: the pick's 5th close (S2's primary exit, original_d5).

Change only the id to test another frozen setup: S1 S2 S3 C1 C2 C3 (primary exit original_d5) or N1 (primary exit
fresh = held 5 sessions from its entry: use the exit {"name": "fresh", "type": "time", "hold": 5} and
"max_sessions": 9). Needs the tags: python setuplab.py tag ... once, then SETUPLAB_OUT (env_tradelab.bat sets it).

    python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --strategy strategies\\setup_s2_d5.py

How to read it: 'on the picks the strategy actually traded' is Karan's frame - S2's own trades against the same
picks bought at the D1 open by the plan. These years are the history the setups were chosen on (descriptive, not
new evidence); only the forward record judges them (setuplab's forward rule, month 12 = 2027-09-30).
"""
STRATEGY = {
    "name": "setup_s2_d5",
    "description": "frozen setup S2: buy the open of its own entry day (D1-D5), sell the pick's 5th close, 35 bp",
    "mode": "daily",
    "picks": {"engines": ["D", "ENS"], "ranks": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]},
    "max_sessions": 5,
    "entries": [{"name": "s2", "size": 1.0, "setup": "S2"}],
    "exits": [{"name": "time", "type": "time", "at": "close", "session": 5}],
    "costs": {"model": "flat", "round_trip_bp": 35},
    "decision_rule": {"metric": "diff_mean_bp", "pass_if": "lower > 0"},
}
