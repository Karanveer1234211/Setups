"""
tests/test_tradelab.py - tradelab v1.3.1 + setups add-on v1.2. Prints one line per check and ends with
VERIFIED (tradelab v1.3.1 + setups add-on v1.2).

    python tests\\test_tradelab.py            (from the tradelab folder; about 9-15 minutes)

Every check runs on synthetic worlds (tests/tl_world.py) with stand-in production modules - nothing on your
cache is read or written. Sections:
  1 rules        compiler, refusals (firewall, look-ahead, unsafe syntax), NaN truth, state rules
  2 functions    every series function is point in time (values up to t unchanged when later bars change)
  3 by hand      plan, scale-in, half target + stop, trailing stop, gap through a stop, stop/target in one bar
                 (worst / best / 3-minute), locked exits (5th close, 6th open), stuck, filter = cash
  4 worlds       planted / absent / reverse VWAP worlds give BETTER / NOT SHOWN / WORSE; fill fairness
  5 point in time  bars after a moment scrambled (daily and 3-minute): every fill and timeline row before it
                 unchanged, for several strategies
  6 plugins      a plugin works; a look-ahead plugin is refused; name clashes refused
  7 portfolio    rupee P&L adds up to the equity change; cash never negative; limits; min order
  8 export       reconcile 100%; tampered record -> STOP (exit 3, nothing else written); wrong hash -> refuse;
                 files, firewall on features, running P&L ends at net, 3-minute rows
  9 backtest/sim paired identity; sim = backtest for a trade; ledger order; guards; UTC daily stamps;
                 3-minute layout stop; env_tradelab.bat CRLF and unique labels
 10-13 v1.1 market context (tests/test_context.py, worlds in tests/tl_ctx_world.py): index values, breadth,
                 environment and stress labels by hand; AMFI lists (CSV / Excel / PDF) point in time, a missing
                 half-year left blank, renamed companies via ISIN; beta and correlation; the market / stock split by
                 hand; pre_* unchanged when later bars are scrambled; post_* refused in rules; research (outcome
                 groups, warning signs, walk-forward) by hand and on planted / absent effects; open positions by hand
                 (v1 portfolio fix); cards, diary, dictionary coverage; a world without Midcap / Smallcap / VIX
 14-15 v1.3 stock states and the watch page (tests/test_state.py, paths in tests/tl_state_world.py): the arithmetic
                 by hand; swings by brute force, never used before knowable; every planted state found (S01, S02, S03,
                 S06, S07, S08, S09, S12, S04 -> confirmed, S11, S10, S05) and absent where not planted; declared
                 precedence, 2-session confirmation, confidence and phase re-derived on every session; point in time;
                 missing volume / short history; the watch page end to end (market = tl_context, pick_meta numbers and
                 marks, Soul copied, nothing written into the cache, rerun / force / index, LATE rule, point in time);
                 export pre_state_* = tl_state, the state breakdown, the research state book by hand, the card line,
                 a backtest filter on a state attribute
 16 v1.3.1       --all-missing: a page for every recorded day without one (LATE when built after its time), the
                 existing page untouched, watch_all.csv = every page's rows, a catch-up page = the same day built on
                 its own, a rerun builds nothing; run_tonight.bat read as text (CRLF, ASCII, labels, parentheses)
                 and, on Windows, EXECUTED by cmd.exe with stand-ins for Run Now, env_daily.bat, pick_meta and
                 tl_watch (the order, each step's folder and PYTHONPATH, Run Now isolated, every step reported, the
                 log line, auto vs double-click); the backtest's state at every pick = tl_state and its state
                 dimensions; the simulator's state table = tl_state
 17 setups add-on (tests/test_setups.py, tl_setups v1.0): setuplab's tags read only when their hash matches; setup
                 entries at each setup's own entry day (prices and both exits by hand); the guards (a filter or rule
                 naming a tag, no tags, an unknown setup, a hold that cannot fit); tag columns documented; the
                 simulator's line; the watch page's setups column and section; the journal's FROZEN SETUPS band;
                 run_tonight.bat's setup scan step (section 16)
 18 setups add-on v1.2 (tests/test_setups.py, tl_setups v1.2): setuplab's entry-tree run read only when its hash
                 matches; the tree strategy's buys and sells by hand (D1 open, each setup's own day, N1 to session 9);
                 'calm' as a filter; the guards (tree columns in rules, a tree entry without its exit / with a session
                 / beside another entry / max_sessions < 9 / no tree run / tags that disagree / another freeze); lane
                 and tree columns documented; the report's lane table by hand; the simulator's line; the journal's
                 CALM / JUMPY AND THE ENTRY TREE band; without a tree run nothing changes
 Needs (once): pip install pypdf pdfplumber openpyxl reportlab - the tests write AMFI lists as Excel / PDF files.
"""
from __future__ import annotations

import io
import json
import os
import shutil
import sys
import tempfile
import time
import contextlib
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
LAB = HERE.parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(LAB))

# v1.1's tests write AMFI lists as Excel and PDF files and read them back: these libraries must be installed
import importlib.util  # noqa: E402
_need = [m for m in ("pypdf", "pdfplumber", "openpyxl", "reportlab") if importlib.util.find_spec(m) is None]
if _need:
    print("NOT VERIFIED: the tests need " + ", ".join(_need) + ". Install them once with:\n"
          "    pip install pypdf pdfplumber openpyxl reportlab\nthen run this again.")
    sys.exit(2)

import tl_world as W  # noqa: E402

FAILS = []
N_CHECKS = 0


def check(cond, msg):
    global N_CHECKS
    N_CHECKS += 1
    print(("  ok    " if cond else "  FAIL  ") + msg, flush=True)
    if not cond:
        FAILS.append(msg)


def quiet(fn, *a, **k):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        r = fn(*a, **k)
    return r, buf.getvalue()


def fresh_modules(root):
    W.use_mods(root)
    import importlib
    import tl_common, tl_data, tl_rules, tl_engine, tl_portfolio, tl_context, tl_dictionary, tl_research, tl_cards
    import tl_state, tl_run, tl_export, tl_backtest, tl_sim, tl_watch, tl_setups, tl_check
    for m in (tl_common, tl_data, tl_rules, tl_setups, tl_engine, tl_portfolio, tl_context, tl_state, tl_dictionary,
              tl_research, tl_cards, tl_run, tl_export, tl_backtest, tl_sim, tl_watch, tl_check):
        importlib.reload(m)
    tl_rules.clear_plugins()
    return tl_data, tl_rules, tl_engine


TMP = Path(tempfile.mkdtemp(prefix="tradelab_test_"))
os.environ.pop("CACHE_DAILY_ROOT", None)
os.environ.pop("BIGMOVE_DIR", None)
os.environ.pop("TRADELAB_OUT", None)
os.environ.pop("SETUPLAB_OUT", None)
os.environ.pop("SETUPLAB_DIR", None)
# add-on v1.1.1: the tests never import production. env_tradelab.bat puts bigmove_deploy and open_close on PYTHONPATH;
# on Karan's PC (8 Nov) importing production's panel_build put those folders ahead of the test's stand-ins, so
# production's intraday_cache was loaded in a test world (section 13 FAIL, then a crash). Every folder on the path that
# holds one of production's modules is taken off for this run.
PROD_FILES = ("stage_e_execution.py", "intraday_cache.py", "data_quality.py", "panel_build.py", "stage_b_screen.py",
              "research_common.py", "pick_meta.py", "features_daily.py")


def production_on_path():
    return [p for p in sys.path if p and "_mods" not in Path(p).parts and Path(p).is_dir()
            and any((Path(p) / f).is_file() for f in PROD_FILES)]


PROD_OFF = production_on_path()
for _p in PROD_OFF:
    while _p in sys.path:
        sys.path.remove(_p)
if PROD_OFF:
    print("production folders taken off this test's path (it uses stand-ins only): " + "; ".join(PROD_OFF))
t_start = time.time()

# ======================================================================
print("1. rules")
w_abs = W.make_world(TMP / "absent", "absent", 11)
D, R, E = fresh_modules(w_abs["root"])
n = 12
sess = np.array([0] * 4 + [1] * 4 + [2] * 4)
bis = np.array([0, 1, 2, 3] * 3)
close = np.array([10, 10.5, 10.2, 10.8, 11, 10.9, 11.2, 11.5, 11.4, 11.0, 10.7, 10.9])
vwap = np.array([10, 10.2, 10.3, 10.4, 11, 11.0, 11.05, 11.2, 11.3, 11.2, 11.0, 10.95])
ctx = R.Ctx(n, sess, bis, 4, {"close": close, "high": close + 0.1, "low": close - 0.1})
names = R.Names("intraday", pick_attrs=["rank", "prob_big", "pred_mfe_q50"], features=None, leg_names=["a20", "b80"],
                events={"up": "crosses_above(close, vwap)", "c1": "c2", "c2": "c1"})
env = {"__builtins__": {}, **R.BASE_NS, **R.series_namespace(ctx), "close": close, "vwap": vwap, "session": sess,
       "rank": 2.0, "prob_big": 0.6, "pred_mfe_q50": 0.05}
r = R.Rule("up and session >= 1", names, "t")
check(r.vector(env, n).tolist() == [False] * 6 + [True] + [False] * 5, "events expand; crosses_above fires on the crossing bar only")
check(R.Rule("1 < session <= 2", names, "t").vector(env, n).tolist() == [False] * 8 + [True] * 4, "chained comparisons")
check(np.allclose(R.Rule("close if session == 1 else vwap", names, "t", "num").vector(env, n)[4:8], close[4:8]),
      "x if c else y")
check(R.Rule("rank <= 2 and prob_big > 0.5 and pred_mfe_q50 > 0.01", names, "t").vector(env, n).all(),
      "pick attributes (incl. pick_meta forecasts pred_mfe_*) are readable")
r = R.Rule("shift(close, 2)", names, "t", "num")
v = r.vector(env, n)
check(np.isnan(v[:2]).all() and np.allclose(v[2:], close[:-2]), "shift(x, 2) looks back two bars")
check(not R.Rule("nz(shift(close, 1)) > 0 and shift(close, 1) > 0", names, "t").vector(env, n)[0], "NaN is false in conditions")
rs = R.Rule("upnl < -0.02 and close < vwap", names, "t")
pre = dict(rs.prepare(env, n))
outs = []
for t in range(n):
    ns = {"__builtins__": {}, **R.BASE_NS, "upnl": -0.03 if t >= 9 else 0.0}
    ns.update({k: v_[t] for k, v_ in pre.items()})
    outs.append(rs.scalar(ns))
check(rs.stateful and outs == [False] * 9 + [True, True, True], "trade-state rules evaluate bar by bar")
for bad, why in [("shift(close, -1)", "shift into the future"), ("close.mean()", "attribute"), ("x[1]", "indexing"),
                 ("label_exit_ret > 0", "label_*"), ("ret_5d_close_pct > 0", "forward column"),
                 ("s_own_mfe_fwd > 0", "forward pattern"), ("__import__('os')", "dunder"), ("'a' == 'a'", "strings"),
                 ("lambda: 1", "lambda"), ("ema(upnl, 5) > 0", "series function on trade state"),
                 ("c1", "event cycle"), ("foo(close)", "unknown function"), ("filled_x > 0", "unknown leg"),
                 ("sma(close, 0)", "window 0"), ("open_ += 1", "statement")]:
    try:
        R.Rule(bad, names, "bad")
        check(False, f"refuses {why}: {bad}")
    except (R.RuleError, Exception) as e:
        check(isinstance(e, R.RuleError), f"refuses {why}: {bad}")
try:
    R.Rule("close > vwap", R.Names("daily"), "d")
    check(False, "vwap refused in daily mode")
except R.RuleError:
    check(True, "vwap refused in daily mode (needs 3-minute bars)")
try:
    R.Rule("filled_a2O > 0", names, "t")
    check(False, "typo refused")
except R.RuleError as e:
    check("filled_a20" in str(e), "a typo gets a suggestion")

# ======================================================================
print("2. functions are point in time")
rng = np.random.default_rng(3)
N = 300
xs = np.cumsum(rng.normal(size=N)) + 100
ss = np.repeat(np.arange(-1, 5), 50)
bb = np.tile(np.arange(50), 6)
full_ctx = R.Ctx(N, ss, bb, 50, {"close": xs, "high": xs + 1, "low": xs - 1})
calls = {"shift": (xs, 3), "prev": (xs,), "sma": (xs, 10), "ema": (xs, 10), "rsi": (xs, 14), "std": (xs, 10),
         "zscore": (xs, 10), "highest": (xs, 7), "lowest": (xs, 7), "roc": (xs, 5), "change": (xs, 5), "rsum": (xs, 4),
         "crosses_above": (xs, np.roll(xs, 1)), "crosses_below": (xs, np.roll(xs, 1)), "rising": (xs, 2),
         "falling": (xs, 2), "bars_since": (xs > 101,), "held_for": (xs > 100, 3), "count_true": (xs > 100, 5),
         "trade_max": (xs,), "trade_min": (xs,), "session_max": (xs,), "session_min": (xs,), "session_sum": (xs,),
         "session_first": (xs,), "prev_session": (xs,), "opening_range_high": (5,), "opening_range_low": (5,)}
bad_fns = []
for nm, args in calls.items():
    f = R.SERIES_IMPL[nm]
    full = np.asarray(f(full_ctx, *args), float)
    for T in (60, 137, 201):
        cut = R.Ctx(T + 1, ss[:T + 1], bb[:T + 1], 50, {"close": xs[:T + 1], "high": xs[:T + 1] + 1, "low": xs[:T + 1] - 1})
        a2 = [x[:T + 1] if isinstance(x, np.ndarray) else x for x in args]
        if nm in ("crosses_above", "crosses_below"):
            a2 = [xs[:T + 1], np.roll(xs, 1)[:T + 1]]
        part = np.asarray(f(cut, *a2), float)
        same = (np.isnan(full[:T + 1]) & np.isnan(part)) | (np.abs(full[:T + 1] - part) < 1e-9)
        if not same.all():
            bad_fns.append(nm)
            break
check(not bad_fns, f"all {len(calls)} series functions unchanged up to t when later bars are cut {bad_fns or ''}")

# ======================================================================
print("3. trades by hand (daily bars)")
root = w_abs["root"]
prod = D.Production(stage_e_any=True)
m = D.Market(root, prod)
Tall, _ = D.load_picks(root, "PM_TEST_001", ["D", "ENS"], list(range(1, 11)))
m.load(sorted(Tall["symbol"].unique()))
pa = D.rule_pick_columns(Tall.columns)
H = W.HAND


def pick_of(sym):
    return Tall[(Tall["symbol"] == sym) & (Tall["engine"] == "D")].iloc[0].to_dict()


def strat(d, mode="daily"):
    base = {"name": d.pop("name", "t"), "mode": mode, "picks": {"engines": ["D"], "ranks": [1, 2, 3]}}
    base.update(d)
    return E.Strategy(base, None, pa)


def run1(s, sym, cache=None, timeline=False):
    return E.TradeSim(s, m, intraday_cache=cache).run(pick_of(sym), timeline=timeline)


plan = strat({"max_sessions": 5, "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}],
              "exits": [{"name": "time", "type": "time", "at": "close", "session": 5}]})
r = run1(plan, "HANDSYM")
hand = H[5][3] / H[1][0] - 1 - 0.0035
check(r.status == "ok" and abs(r.net - hand) < 1e-12, f"plan: net {r.net:.6f} = 103.5/100 - 1 - 0.0035 = {hand:.6f}")
check(abs(r.mfe - (108 / 100 - 1)) < 1e-12 and abs(r.mae - (99 / 100 - 1)) < 1e-12 and r.mfe_session == 3,
      "plan: MFE +8% on session 3, MAE -1%")
pth = pd.DataFrame(r.path)
check(abs(pth["day_net"].iloc[1:].sum() - r.net) < 1e-12 and abs(pth["day_net"].iloc[1] - (103 / 100 - 1 - 0.00175)) < 1e-12,
      "path: day 1 P&L = 103/100 - 1 - 17.5 bp; the days add up to the net")
s_scale = strat({"max_sessions": 5, "entries": [{"name": "a20", "size": 0.2, "at": "open", "session": 1},
                                                {"name": "b80", "size": 0.8, "when": "close > prev_close", "sessions": [2, 2]}],
                 "exits": [{"name": "time", "type": "time", "at": "close", "session": 5}]})
r = run1(s_scale, "HANDSYM")
Q = 0.2 / 100 + 0.8 / 103
hand = Q * 103.5 - 1 - 0.0035
check(abs(r.net - hand) < 1e-12 and abs(r.avg_entry - 1 / Q) < 1e-9 and r.fills[1].price == 103.0,
      f"scale-in 20% @100 + 80% @103 (session-1 close above the previous close -> session-2 open): net {r.net:.6f} = {hand:.6f}")
s_ht = strat({"max_sessions": 5, "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}],
              "exits": [{"name": "t5", "type": "target", "level": "avg_entry * 1.05", "size": 0.5},
                        {"name": "s8", "type": "stop", "level": "avg_entry * 0.92"},
                        {"name": "time", "type": "time", "at": "close", "session": 5}]})
r = run1(s_ht, "HANDSYM")
hand = 0.5 * (105 / 100 - 1) + 0.5 * (103.5 / 100 - 1) - 0.0035
check(abs(r.net - hand) < 1e-12 and [f.leg for f in r.fills] == ["open", "t5", "time"] and r.fills[1].price == 105.0,
      f"half at +5% (session 2, 105) + rest at the 5th close: net {r.net:.6f} = {hand:.6f}")
s_tr = strat({"max_sessions": 10, "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}],
              "exits": [{"name": "trail", "type": "trail", "pct": 0.04, "activate": "mfe_sofar >= 0.05"},
                        {"name": "time", "type": "time", "at": "close", "session": 10}]})
r = run1(s_tr, "HANDSYM")
check(r.fills[-1].leg == "trail" and abs(r.fills[-1].price - 108 * 0.96) < 1e-9 and r.fills[-1].session == 4,
      f"trailing 4% under the highest high once MFE >= 5%: sold on session 4 at 108 x 0.96 = {108 * 0.96:.2f}")
s_gap = strat({"max_sessions": 5, "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}],
               "exits": [{"name": "s5", "type": "stop", "level": "avg_entry * 0.95"},
                         {"name": "time", "type": "time", "at": "close", "session": 5}]})
r = run1(s_gap, "GAPSYM")
check(r.fills[-1].leg == "s5" and r.fills[-1].price == 930.0 and r.fills[-1].session == 2,
      "a gap through a stop fills at the open (930), not at the stop (950)")
for pol, want in (("worst", ("s5", 95.0)), ("best", ("t6", 106.0)), ("intraday", ("t6", 106.0))):
    s_amb = strat({"max_sessions": 5, "intrabar": pol, "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}],
                   "exits": [{"name": "s5", "type": "stop", "level": "avg_entry * 0.95"},
                             {"name": "t6", "type": "target", "level": "avg_entry * 1.06"},
                             {"name": "time", "type": "time", "at": "close", "session": 5}]})
    cache = None
    if pol == "intraday":
        ds = m.series("AMBSYM")
        cache = {"AMBSYM": m.intraday.sessions("AMBSYM", list(ds.dates), ds)}
    r = run1(s_amb, "AMBSYM", cache)
    check((r.fills[1].leg, r.fills[1].price) == want and r.ambiguous_bars == 1,
          f"stop and target inside one day, intrabar '{pol}' -> {want[0]} at {want[1]}")
r = run1(plan, "LOCKSYM")
ds = m.series("LOCKSYM")
sig = ds.idx(np.datetime64(pick_of("LOCKSYM")["signal_day"], "D"))
check(r.locked_exit and r.fills[-1].session == 7 and r.fills[-1].price == ds.o[sig + 7] and r.fills[-1].kind == "locked_open",
      "5th close locked, 6th open locked -> sold at the 7th open (stage E's rule)")
o6 = strat({"max_sessions": 6, "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}],
            "exits": [{"name": "o6", "type": "time", "at": "open", "session": 6}]})
r = run1(o6, "LOCKSYM")
check(r.fills[-1].session == 7 and r.locked_exit, "6th-open exit on a locked open -> the 7th open")
o6m8 = strat({"max_sessions": 8, "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}],
              "exits": [{"name": "o6", "type": "time", "at": "open", "session": 6}]})
r = run1(o6m8, "LOCKSYM")
pth = pd.DataFrame(r.path).set_index("session")
check(r.fills[-1].session == 7 and pth.loc[7, "pos"] == 0 and pth.loc[8, "pos"] == 0 and pth.loc[6, "pos"] == 1
      and abs(pth.loc[8, "mtm_net"] - r.net) < 1e-12, "an early locked open exit: sold at the next unlocked open; later path rows show it sold")
r = run1(plan, "STUCKSYM")
check(r.status == "stuck" and r.fills[-1].session == 25, "locked for 25 sessions -> stuck (marked at the 25th close)")
s_f = strat({"max_sessions": 5, "picks": {"engines": ["D"], "ranks": [1, 2, 3], "filter": "rank > 5"},
             "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}]})
r = run1(s_f, "HANDSYM")
check(r.status == "filtered" and r.net == 0.0, "a filtered pick is a slot left in cash: 0 bp")
s_ne = strat({"max_sessions": 5, "entries": [{"name": "never", "size": 1.0, "when": "close > 1e9", "sessions": [1, 5]}]})
r = run1(s_ne, "HANDSYM")
check(r.status == "not_entered" and r.net == 0.0 and r.deployed == 0, "an entry that never fires: not_entered, 0 bp")
s_clip = strat({"max_sessions": 5, "entries": [{"name": "a", "size": 0.7, "at": "open", "session": 1},
                                               {"name": "b", "size": 0.7, "when": "session >= 1", "sessions": [2, 2]}]})
r = run1(s_clip, "HANDSYM")
check(abs(r.max_pos - 1.0) < 1e-12 and abs(r.fills[1].frac - 0.3) < 1e-12, "a buy is clipped so the position never exceeds the target")
for bad_raw, why in [({"entries": [{"name": "x", "size": 1, "at": "close", "session": 1}]}, "close entry without same_bar_close_fills"),
                     ({"exits": [{"name": "x", "type": "time", "at": "open", "session": 6}]}, "exit beyond max_sessions"),
                     ({"entries": [{"name": "1bad", "size": 1, "at": "open", "session": 1}]}, "leg name not an identifier"),
                     ({"wrong_key": 1}, "unknown strategy key"),
                     ({"entries": [{"name": "x", "size": 1, "fill": "stop", "when": "session > 0"}]}, "stop entry without level"),
                     ({"exits": [{"name": "x", "type": "trail"}]}, "trail without pct/atr"),
                     ({"entries": [{"name": "x", "size": 1, "when": "hhmm > 1000", "time": ["10:00", "11:00"]}]}, "time window in daily mode")]:
    try:
        strat(dict(bad_raw))
        check(False, f"refuses {why}")
    except Exception as e:
        check(type(e).__name__ in ("TLError", "RuleError"), f"refuses {why}")

# ======================================================================
print("4. planted / absent / reverse worlds (20% at the open + 80% on a VWAP reclaim vs the plan)")
import tl_common as C  # noqa: E402

worlds = {"absent": w_abs}
for kind, seed in (("planted", 11), ("reverse", 11)):
    worlds[kind] = W.make_world(TMP / kind, kind, seed)
verdicts = {}
for kind, w in worlds.items():
    D, R, E = fresh_modules(w["root"])
    from tl_run import Workspace
    ws = Workspace(w["root"], "PM_TEST_001", stage_e_any=True, quiet=True)
    T = ws.picks(["D", "ENS"], "1-10")
    S = ws.strategy(str(LAB / "strategies" / "scale_20_80_vwap.py"), T)
    S.picks.update({"engines": ["D", "ENS"], "ranks": list(range(1, 11))})
    import tl_backtest as BT
    Pn = BT.plan_like(S, ws.pick_attrs(T))
    res, _ = ws.simulate([S, Pn], T)
    A = pd.DataFrame([x.row() for x in res[S.name]])
    B = pd.DataFrame([x.row() for x in res[Pn.name]])
    ev = BT.paired_eval(T, A, B)
    verdicts[kind] = ev["summary"]
    d = ev["summary"]["diff"]
    print(f"        {kind}: difference {C.fmt_bp(*d)} bp")
check(verdicts["planted"]["diff"][1] > 0, "planted world: the VWAP scale-in is BETTER (interval above 0)")
def tstat(v):
    se = (v[2] - v[1]) / (2 * 1.96)
    return v[0] / se if se > 0 else float("inf")


check(abs(tstat(verdicts["absent"]["diff"])) < 3.5,
      f"absent world (a martingale): no gain from the VWAP timing (|t| = {abs(tstat(verdicts['absent']['diff'])):.2f} < 3.5; "
      f"16-world calibration: mean -0.04 bp, 1 of 16 intervals off zero)")
check(verdicts["reverse"]["diff"][2] < 0, "reverse world: WORSE (interval below 0)")
s_ = verdicts["absent"]
check(abs(s_["diff"][0] - (s_["strategy"][0] - s_["compare"][0])) < 1e-9, "paired identity: difference = strategy - plan")
# fill fairness for stop and limit entries in the martingale world
D, R, E = fresh_modules(w_abs["root"])
from tl_run import Workspace  # noqa: E402
import tl_backtest as BT  # noqa: E402
ws = Workspace(w_abs["root"], "PM_TEST_001", stage_e_any=True, quiet=True)
T = ws.picks(["D", "ENS"], "1-10")
fair = {}
for nm in ("orb_add_on.py", "dip_or_fallback.py"):
    S = ws.strategy(str(LAB / "strategies" / nm), T)
    S.picks.update({"engines": ["D", "ENS"], "ranks": list(range(1, 11))})
    Pn = BT.plan_like(S, ws.pick_attrs(T))
    res, _ = ws.simulate([S, Pn], T)
    A = pd.DataFrame([x.row() for x in res[S.name]])
    B = pd.DataFrame([x.row() for x in res[Pn.name]])
    fair[nm] = BT.paired_eval(T, A, B)["summary"]["diff"]
    print(f"        {nm}: difference {C.fmt_bp(*fair[nm])} bp on {len(T):,} picks")
check(all(abs(tstat(v)) < 3.5 for v in fair.values()),
      f"fill fairness: buy-stop and buy-limit entries gain nothing on a martingale (|t| {[round(abs(tstat(v)), 2) for v in fair.values()]} < 3.5)")

# ======================================================================
print("5. point in time: scramble every bar after a moment, nothing before it may change")


def scramble_after(src_root, dst_root, sym, cut_day, cut_minute):
    """Copy the world; scramble the symbol's 3-minute bars that start after cut_day 09:15 + cut_minute, then
    rebuild its daily bars from the 3-minute bars from cut_day on (so daily and 3-minute stay consistent)."""
    shutil.copytree(src_root, dst_root)
    rng_ = np.random.default_rng(99)
    q = dst_root / "intraday_3m" / f"{sym}_3m.parquet"
    X = pd.read_parquet(q)
    ts = pd.to_datetime(X["timestamp"]).dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
    cut = cut_day + pd.Timedelta(minutes=9 * 60 + 15 + cut_minute)
    mk = (ts > cut).to_numpy()
    f = np.exp(np.cumsum(rng_.normal(0, 0.01, mk.sum())))
    for c in ("open", "high", "low", "close"):
        X.loc[mk, c] = X.loc[mk, c].to_numpy() * f * rng_.uniform(0.995, 1.005, mk.sum())
    X.loc[mk, "high"] = X.loc[mk, ["open", "high", "low", "close"]].max(axis=1)
    X.loc[mk, "low"] = X.loc[mk, ["open", "high", "low", "close"]].min(axis=1)
    X.to_parquet(q, index=False)
    day = ts.dt.normalize()
    agg = X.assign(day=day).groupby("day").agg(open=("open", "first"), high=("high", "max"), low=("low", "min"),
                                               close=("close", "last"))
    p = dst_root / f"{sym}_daily.parquet"
    df = pd.read_parquet(p)
    dd = pd.to_datetime(df["timestamp"]).dt.tz_convert("Asia/Kolkata").dt.tz_localize(None).dt.normalize()
    sel = (dd >= cut_day).to_numpy()
    for c in ("open", "high", "low", "close"):
        df.loc[sel, c] = agg.reindex(dd[sel])[c].to_numpy()
    df.to_parquet(p, index=False)


wp = worlds["planted"]
D, R, E = fresh_modules(wp["root"])
from tl_run import Workspace  # noqa: E402
ws0 = Workspace(wp["root"], "PM_TEST_001", stage_e_any=True, quiet=True)
T0 = ws0.picks(["D"], "1-3")
cands = T0[T0["symbol"].str.match(r"^S\d\d$")].iloc[[20, 90, 160]]
strat_files = ["scale_20_80_vwap.py", "orb_add_on.py", "half_target_stop.py", "trail_after_5pct.py", "weak_close_exit.py",
               "dip_or_fallback.py"]
pit_ok, pit_cnt, n_changed = True, 0, 0
for _, pk in cands.iterrows():
    sym, sd = pk["symbol"], pd.Timestamp(pk["signal_day"])
    ds = ws0.market.series(sym)
    sig = ds.idx(np.datetime64(sd, "D"))
    cut_day = pd.Timestamp(ds.dates[sig + 2])
    dst = TMP / f"pit_{sym}_{sd:%Y%m%d}"
    scramble_after(wp["root"], dst, sym, cut_day, 120)
    for sf in strat_files:
        D, R, E = fresh_modules(wp["root"])
        from tl_run import Workspace  # noqa: E402
        wsa = Workspace(wp["root"], "PM_TEST_001", stage_e_any=True, quiet=True)
        Ta = wsa.picks(["D"], "1-3")
        Ta = Ta[Ta["trade_id"] == pk["trade_id"]].reset_index(drop=True)
        Sa = wsa.strategy(str(LAB / "strategies" / sf), Ta)
        ra = wsa.simulate([Sa], Ta, timeline_ids=[pk["trade_id"]])[0][Sa.name][0]
        D, R, E = fresh_modules(dst)
        from tl_run import Workspace  # noqa: E402
        wsb = Workspace(dst, "PM_TEST_001", stage_e_any=True, quiet=True)
        Tb = wsb.picks(["D"], "1-3")
        Tb = Tb[Tb["trade_id"] == pk["trade_id"]].reset_index(drop=True)
        Sb = wsb.strategy(str(LAB / "strategies" / sf), Tb)
        rb = wsb.simulate([Sb], Tb, timeline_ids=[pk["trade_id"]])[0][Sb.name][0]
        if Sa.mode == "daily":
            # the cut day's daily high / low / close changed: compare fills up to its open, rows before it
            cut_ts = np.datetime64(cut_day.date(), "m") + np.timedelta64(9 * 60 + 15, "m")
            row_cut = pd.Timestamp(cut_day.date())
        else:
            cut_ts = np.datetime64(cut_day.date(), "m") + np.timedelta64(9 * 60 + 15 + 120, "m")
            row_cut = pd.Timestamp(cut_ts)
        fa = [(f.leg, f.side, float(f.price), str(f.ts)) for f in ra.fills if f.ts is not None and np.datetime64(f.ts, "m") <= cut_ts]
        fb = [(f.leg, f.side, float(f.price), str(f.ts)) for f in rb.fills if f.ts is not None and np.datetime64(f.ts, "m") <= cut_ts]
        tla, tlb = ra.timeline, rb.timeline
        if tla is None or tlb is None:
            same_tl = tla is None and tlb is None and ra.status == rb.status
        else:
            ka = pd.to_datetime(tla["time"]) < row_cut
            kb = pd.to_datetime(tlb["time"]) < row_cut
            A_ = tla[ka].drop(columns=["fills"]).reset_index(drop=True)
            B_ = tlb[kb].drop(columns=["fills"]).reset_index(drop=True)
            same_tl = A_.shape == B_.shape and len(A_) > 0 and np.allclose(
                A_.select_dtypes("number").to_numpy(float), B_.select_dtypes("number").to_numpy(float), equal_nan=True)
        n_changed += int(abs(ra.net - rb.net) > 1e-12)
        pit_ok &= (fa == fb) and same_tl
        pit_cnt += 1
        if not ((fa == fb) and same_tl):
            print(f"        mismatch {sf} {pk['trade_id']}: fills {fa} vs {fb} timeline {same_tl}")
check(pit_ok, f"{pit_cnt} trade x strategy runs: fills and timeline rows before the cut identical after scrambling later bars")
check(n_changed > 0, f"the scramble has teeth: {n_changed} of {pit_cnt} runs end with a different net")

# ======================================================================
print("6. plugins")
D, R, E = fresh_modules(w_abs["root"])
from tl_run import Workspace  # noqa: E402
ws = Workspace(w_abs["root"], "PM_TEST_001", stage_e_any=True, quiet=True)
T = ws.picks(["D"], "1-3").head(40)
S = ws.strategy(str(LAB / "strategies" / "weak_close_exit.py"), T)
res, _ = ws.simulate([S], T, timeline_ids=[T["trade_id"].iloc[3]])
r3 = res[S.name][3]
check("vol_surge" in R.PLUGIN_VARS and r3.timeline is not None and "vol_surge" in r3.timeline.columns,
      "the example plugin's value is usable in rules and recorded in the timeline")
bad_plugin = TMP / "peek_plugin.py"
bad_plugin.write_text("import numpy as np\nfrom tl_rules import variable\n@variable('next_close', 'peeks')\n"
                      "def nc(ctx):\n    return np.r_[ctx.close[1:], np.nan]\n", encoding="utf-8")
sp = TMP / "peek_strategy.py"
sp.write_text("STRATEGY = {'name': 'peek', 'mode': 'intraday', 'plugins': [r'%s'], 'max_sessions': 5,\n"
              " 'entries': [{'name': 'x', 'size': 1.0, 'when': 'next_close > close', 'sessions': [1, 2]}]}\n" % bad_plugin,
              encoding="utf-8")
try:
    S = ws.strategy(str(sp), T)
    ws.simulate([S], T)
    check(False, "a plugin that reads the next bar is refused")
except R.RuleError as e:
    check("looks ahead" in str(e), "a plugin that reads the next bar is refused (look-ahead check)")
try:
    R.variable("close")(lambda c: c.close)
    check(False, "plugin name clash refused")
except R.RuleError:
    check(True, "a plugin may not reuse a built-in name")
R.clear_plugins()

# ======================================================================
print("7. portfolio")
D, R, E = fresh_modules(w_abs["root"])
from tl_run import Workspace  # noqa: E402
from tl_portfolio import run_portfolio  # noqa: E402
ws = Workspace(w_abs["root"], "PM_TEST_001", stage_e_any=True, quiet=True)
T = ws.picks(["D"], "1-3")
S = ws.strategy(str(LAB / "strategies" / "half_target_stop.py"), T)
res, _ = ws.simulate([S], T)
P = run_portfolio(res[S.name], S, ws.market)
st = P.stats
check(abs(st["pnl_check"]) < 1e-6 * st["capital"], f"rupee P&L of all trades = equity change (diff {st['pnl_check']:.6f})")
check((P.daily["cash"] >= -1e-6).all() and (P.daily["n_open"] <= 15 + 3).all(), "cash never negative")
S.portfolio.update({"max_new_per_day": 2, "max_open": 6})
P2 = run_portfolio(res[S.name], S, ws.market)
check(P2.daily["new_trades"].max() <= 2 and P2.daily["n_open"].max() <= 6 and "max_new_per_day" in P2.stats["trades_skipped"],
      "max_new_per_day and max_open respected (skips counted)")
S.portfolio.update({"max_new_per_day": None, "max_open": None, "capital": 3000.0})
P3 = run_portfolio(res[S.name], S, ws.market)
check(P3.stats["legs_skipped_by_cash"] + P3.stats["trades_skipped"].get("size_zero", 0) > 0,
      "tiny capital: legs that cash cannot fund to 25% of plan are skipped (min order rule)")
S.sizing = {"rule": "expression", "expression": "equity / 15 * min(1.5, 0.03 / signal_atr14_pct)"}
P4 = run_portfolio(res[S.name], S, ws.market)
check(P4.stats["trades_opened"] > 0 and abs(P4.stats["pnl_check"]) < 1e-6 * P4.stats["capital"],
      "expression sizing (equity, signal ATR) runs and adds up")

# ======================================================================
print("8. export")
D, R, E = fresh_modules(w_abs["root"])
import tl_export as X  # noqa: E402
out = TMP / "out"
rc, log = quiet(X.main, ["--root", str(w_abs["root"]), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                         "--bars3", "D-20230925-1"])
runs = sorted((out / "export").glob("TLX_*"))
check(rc == 0 and len(runs) == 1 and "OK - D" in log, "export runs; the plan reproduces the recorded trades")
rd = runs[0]
want = {"trades.csv", "trades.parquet", "trade_days.csv", "trade_days.parquet", "trade_day_features.parquet",
        "daily_book.csv", "daily_book.parquet", "trade_bars_3m.csv", "trade_bars_3m.parquet", "report.md",
        "summary.json", "outputs.sha256"}
check(want <= {p.name for p in rd.iterdir()}, "all export files written")
tr = pd.read_parquet(rd / "trades.parquet")
dd = pd.read_parquet(rd / "trade_days.parquet")
ft = pd.read_parquet(rd / "trade_day_features.parquet")
b3 = pd.read_parquet(rd / "trade_bars_3m.parquet")
check(len(tr) == len(Tall) and tr["matches_record"].mean() > 0.995, f"one row per pick ({len(tr):,}); match share {tr['matches_record'].mean():.2%}")
last = dd.groupby("trade_id")["cum_pnl_bp"].last()
okn = tr.set_index("trade_id")["net_bp"].dropna()
check(float((last.reindex(okn.index) - okn).abs().max()) < 1e-6, "each trade's running P&L ends at its net")
check(set(ft.columns) >= {"D_rsi14", "D_atr_pct"} and not ({"label_exit_ret", "ret_5d_close_pct", "close", "X_turnover_med",
                                                             "s_own_mfe_hist", "name_str"} & set(ft.columns)),
      "features: labels, forward names, raw levels and text are out")
check(len(b3) == 125 * 6 and b3["session"].min() == 0 and b3["session"].max() == 5, "3-minute rows: 125 bars x sessions 0-5")
check(tr["excess_bp"].notna().mean() > 0.9, "buy-everything and excess computed")
hs = tr[tr["symbol"] == "HANDSYM"].iloc[0]
check(abs(hs["net_bp"] - (103.5 / 100 - 1 - 0.0035) * 1e4) < 1e-6 and hs["touch_up5_session"] == 2 and hs["touch_dn3_session"] != hs["touch_dn3_session"],
      "HANDSYM row: net, +5% touched on session 2, -3% never")
# tamper: 1% of recorded nets shifted, hash rewritten -> stop
P0 = pd.read_parquet(w_abs["root"] / "research2" / "pick_meta" / "PM_TEST_001" / "predictions.parquet")
Pt = P0.copy()
idx = Pt[Pt["status"] == "ok"].sample(frac=0.02, random_state=1).index
Pt.loc[idx, "net"] += 0.001
W.rewrite_predictions(w_abs["root"], Pt)
out2 = TMP / "out_tamper"
rc, log = quiet(X.main, ["--root", str(w_abs["root"]), "--pm-run", "PM_TEST_001", "--out", str(out2), "--stage-e-any",
                         "--no-benchmark", "--features", "none"])
rdirs = sorted((out2 / "export").glob("TLX_*"))
names_ = {p.name for p in rdirs[0].iterdir()} if rdirs else set()
check(rc == 3 and names_ == {"STOPPED.txt", "reconcile_mismatches.csv"}, "tampered record (2% of nets) -> STOPPED, nothing else written")
# only MFE / MAE differ (another definition) -> reported, not a stop
Pm = P0.copy()
idm = Pm[Pm["status"] == "ok"].sample(frac=0.05, random_state=2).index
Pm.loc[idm, "mfe"] += 0.01
W.rewrite_predictions(w_abs["root"], Pm)
rc, log = quiet(X.main, ["--root", str(w_abs["root"]), "--pm-run", "PM_TEST_001", "--out", str(TMP / "out_mfe"), "--stage-e-any",
                         "--no-benchmark", "--features", "none"])
check(rc == 0 and "MFE/MAE agree on 9" in log, "MFE/MAE that differ from the record are reported, not a stop (the stop is status + net)")
# a 16-character fingerprint in outputs.sha256 is accepted
W.rewrite_predictions(w_abs["root"], P0)
hp = w_abs["root"] / "research2" / "pick_meta" / "PM_TEST_001" / "outputs.sha256"
full = hp.read_text().split()[0]
hp.write_text(f"{full[:16]}  predictions.parquet\n")
rc, log = quiet(X.main, ["--root", str(w_abs["root"]), "--pm-run", "PM_TEST_001", "--out", str(TMP / "out_fp"), "--stage-e-any",
                         "--no-benchmark", "--features", "none"])
check(rc == 0, "outputs.sha256 holding a 16-character fingerprint is accepted")
W.rewrite_predictions(w_abs["root"], P0, fix_hash=False)
(w_abs["root"] / "research2" / "pick_meta" / "PM_TEST_001" / "outputs.sha256").write_text("0" * 64 + "  predictions.parquet\n")
rc, log = quiet(X.main, ["--root", str(w_abs["root"]), "--pm-run", "PM_TEST_001", "--out", str(TMP / "out_hash"), "--stage-e-any"])
check(rc == 2 and "does not match" in log, "predictions not matching outputs.sha256 -> refused")
W.rewrite_predictions(w_abs["root"], P0)

# ======================================================================
print("9. backtest, sim, ledger, guards")
D, R, E = fresh_modules(w_abs["root"])
import tl_backtest as BT  # noqa: E402
import tl_sim as SIM  # noqa: E402
out3 = TMP / "out_bt"
tid = "D-20230925-1"
rc, log = quiet(BT.main, ["--root", str(w_abs["root"]), "--pm-run", "PM_TEST_001", "--out", str(out3), "--stage-e-any",
                          "--strategy", str(LAB / "strategies" / "scale_20_80_vwap.py"), "--timeline", tid,
                          "--declare", "BETTER if the paired lower bound > 0", "--tag", "test"])
bt = sorted((out3 / "backtest").glob("TLB_*"))
check(rc == 0 and len(bt) == 1 and (bt[0] / "timelines" / f"{tid}.csv").exists() and (bt[0] / "portfolio_daily.csv").exists(),
      "backtest runs and writes trades / fills / days / portfolio / timelines")
A = pd.read_parquet(bt[0] / "trades.parquet")
sm = json.loads((bt[0] / "summary.json").read_text())
pr = sm["paired"]
check(abs(pr["diff"][0] - (pr["strategy"][0] - pr["compare"][0])) < 1e-9 and abs(A.loc[A["paired"], "diff_bp"].mean() - pr["diff"][0]) < 1e-9,
      "summary's difference = strategy - plan = mean of the per-pick differences")
led = [json.loads(x) for x in (out3 / "tradelab_ledger.jsonl").read_text().splitlines()]
check([x["event"] for x in led] == ["backtest_declared", "backtest_run"] and led[0]["declared_rule"].startswith("BETTER"),
      "ledger: the declared line is written before the run line")
rc, log = quiet(SIM.main, ["--root", str(w_abs["root"]), "--pm-run", "PM_TEST_001", "--out", str(out3), "--stage-e-any",
                           "--trade", tid, "--strategy", str(LAB / "strategies" / "scale_20_80_vwap.py")])
sim = sorted((out3 / "sim").glob("TLS_*"))[0]
ssum = json.loads((sim / "summary.json").read_text())
row_sim = ssum["results"]["scale_20_80_vwap"][0]
row_bt = A[A["trade_id"] == tid].iloc[0]
tl_bt = pd.read_csv(bt[0] / "timelines" / f"{tid}.csv")
tl_sim = pd.read_csv(sim / f"{tid}__scale_20_80_vwap_timeline.csv")
check(rc == 0 and abs(row_sim["net"] - row_bt["net"]) < 1e-12 and tl_bt.equals(tl_sim) and (sim / f"{tid}_chart.html").exists(),
      "sim gives the same trade as the backtest (net, every timeline row) and draws the chart")
rc, log = quiet(SIM.main, ["--root", str(w_abs["root"]), "--pm-run", "PM_TEST_001", "--out", str(out3), "--stage-e-any",
                           "--trade", tid, "--strategy", str(LAB / "strategies" / "plan_intraday.py"),
                           "--values", "rvol,clv,D_rsi14,prob_big,atr14_pct"])
sim2 = sorted((out3 / "sim").glob("TLS_*"))[-1]
tl2 = pd.read_csv(sim2 / f"{tid}__plan_intraday_timeline.csv")
check(rc == 0 and {"rvol", "clv", "D_rsi14", "prob_big", "atr14_pct"} <= set(tl2.columns),
      "--values records extra built-ins, pick attributes and panel features bar by bar")
rc, log = quiet(SIM.main, ["--root", str(w_abs["root"]), "--pm-run", "PM_TEST_001", "--out", str(out3), "--stage-e-any",
                           "--trade", tid, "--values", "label_exit_ret"])
check(rc == 2 and "firewall" in log, "--values refuses a label")
rc, log = quiet(BT.main, ["--pm-run", "PM_TEST_001", "--strategy", "plan.py"])
check(rc == 2 and "--root is required" in log, "no --root -> refused (no silent default path)")
rc, log = quiet(BT.main, ["--root", str(w_abs["root"]), "--pm-run", "PM_TEST_001", "--out", str(w_abs["root"] / "x"),
                          "--stage-e-any", "--strategy", "plan.py"])
check(rc == 2 and "inside" in log, "an output folder inside the cache is refused")
rc, log = quiet(BT.main, ["--root", str(w_abs["root"]), "--pm-run", "PM_TEST_001", "--out", str(out3), "--strategy", "plan.py"])
check(rc == 2 and "158883f0af70728d" in log, "stage_e_execution that is not the shipped v1.2 is refused without --stage-e-any")
# UTC instants in the daily bars (IST midnight stored as 18:30 UTC) -> identical trades
D, R, E = fresh_modules(w_abs["root"])
mod = w_abs["root"] / "_mods" / "stage_e_execution.py"
txt = mod.read_text()
mod.write_text(txt.replace("UTC_STAMPS = False", "UTC_STAMPS = True"))
D, R, E = fresh_modules(w_abs["root"])
mu = D.Market(w_abs["root"], D.Production(stage_e_any=True))
rr = E.TradeSim(E.Strategy({"name": "p", "mode": "daily", "max_sessions": 5}, None, pa), mu).run(pick_of("HANDSYM"))
check(abs(rr.net - (103.5 / 100 - 1 - 0.0035)) < 1e-12 and mu.diag.get("utc_shifted", 0) > 0,
      "daily bars stamped as UTC instants are read on the right IST day")
mod.write_text(txt)
# 3-minute bars stamped with their END time -> layout stop
wl = W.make_world(TMP / "layout", "absent", 5, n_syms=12)
for f in (wl["root"] / "intraday_3m").glob("*_3m.parquet"):
    X3 = pd.read_parquet(f)
    X3["timestamp"] = X3["timestamp"] + pd.Timedelta(minutes=3)
    X3.to_parquet(f, index=False)
D, R, E = fresh_modules(wl["root"])
import tl_backtest as BT  # noqa: E402
rc, log = quiet(BT.main, ["--root", str(wl["root"]), "--pm-run", "PM_TEST_001", "--out", str(TMP / "out_l"), "--stage-e-any",
                          "--strategy", str(LAB / "strategies" / "scale_20_80_vwap.py"), "--ranks", "1-10", "--engines", "D", "ENS"])
check(rc == 3 and "layout" in log, "3-minute bars stamped with their end time -> STOPPED by the layout check")
D, R, E = fresh_modules(w_abs["root"])
import tl_check as K  # noqa: E402
rc, log = quiet(K.main, ["--root", str(w_abs["root"]), "--pm-run", "PM_TEST_001", "--stage-e-any"])
check(rc == 0 and "CHECK OK" in log and "100.00%" in log, "tl_check: the preflight passes and reproduces the plan on a sample")
bat = LAB / "env_tradelab.bat"
if bat.exists():
    raw = bat.read_bytes()
    lines = raw.split(b"\r\n")
    labels = [l.strip().lower() for l in raw.decode("ascii", "replace").splitlines() if l.strip().startswith(":") and not l.strip().startswith("::")]
    check(raw.count(b"\n") == raw.count(b"\r\n") and len(labels) == len(set(labels)), "env_tradelab.bat: CRLF line endings, labels unique")
else:
    check(False, "env_tradelab.bat present next to the code")

# ======================================================================
import test_context as TC  # noqa: E402
TC.run_all(check, quiet, fresh_modules, TMP, LAB)

# ======================================================================
import test_state as TST  # noqa: E402
TST.run_all(check, quiet, fresh_modules, TMP, LAB)

# ======================================================================
import test_setups as TSU  # noqa: E402
TSU.run_all(check, quiet, fresh_modules, TMP, LAB)
TSU.run_tree(check, quiet, fresh_modules, TMP, LAB)          # setups add-on v1.2: section 18

# ======================================================================
check(not production_on_path(), "no production folder came back onto the test's path during the run (add-on v1.1.1)"
      + ("" if not production_on_path() else " - found: " + "; ".join(production_on_path())))
print()
dt_ = time.time() - t_start
shutil.rmtree(TMP, ignore_errors=True)
print(f"{N_CHECKS} checks, {len(FAILS)} failures, {dt_:,.0f} s, pandas {pd.__version__} / numpy {np.__version__}")
if FAILS:
    print("NOT VERIFIED:")
    for f in FAILS:
        print("  - " + f)
    sys.exit(1)
print("VERIFIED (tradelab v1.3.1 + setups add-on v1.2)")
