"""
tl_check.py - tradelab v1.1: a 30-second preflight on your PC (reads only; writes nothing).

    python tl_check.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001

Prints what tradelab sees: library versions; the production modules it borrows (stage E's loader and lock rule,
intraday_cache, data_quality, research_common, panel_build) with their files and fingerprints; pick_meta's run
(hash check, rows, engines, ranks, columns, statuses); the daily bars (calendar, time stamps); one 3-minute file
(columns, stamps on the 09:15 + 3k grid, usable sessions); the panel (features kept / dropped by the firewall);
and the plan reproduced on 300 random picks against pick_meta's record. v1.1: the index files the market context
reads (NIFTY 50, Midcap 150, Smallcap 250, India VIX, NIFTY 500, Bank, IT and the sector indices: sessions, last date,
whether the open is usable) and any AMFI size lists in %CACHE_DAILY_ROOT%\\sectors\\amfi\\ (read, validated, used from
which date). v1.3: what the watch page reads, and one stock's state. v1.3.1: what run_tonight.bat will start - Run
Now's file and its commands, env_daily.bat, pick_meta.py and run_pick_meta.bat's python lines (read, never run).
Ends with CHECK OK (+ warnings) or the problems found.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from tl_common import StopRun, TLError, VERSION, provenance, require_root, say
import tl_data as D
import tl_engine as E
import tl_context as CX

TOOL = "tl_check v1.3.1"


def _bat_lines(path: Path) -> List[str]:
    """A batch file's commands: blank lines, rem / :: comments and @echo off left out."""
    out = []
    for ln in path.read_text(encoding="utf-8", errors="replace").splitlines():
        x = ln.strip()
        if x and not re.match(r"(?i)^(rem\b|::|@?echo\s+off\s*$)", x):
            out.append(x)
    return out


def tonight_lines(bat: Path, big: Optional[str] = None, setuplab: Optional[str] = None) -> Tuple[List[str], List[str]]:
    """What run_tonight.bat will start, read from the files (nothing is run). big / setuplab: BIGMOVE_DIR /
    SETUPLAB_DIR to use instead of the ones written in the files (tests)."""
    if not bat.exists():
        return [f"tonight (v1.3.1): {bat.name} not found beside tl_check.py"], [f"tonight: {bat.name} not found"]
    t = bat.read_text(encoding="ascii", errors="replace")
    mb = re.search(r'^set "BIGMOVE_DIR=([^"]+)"', t, re.M)
    mr = re.search(r'^set "TN_RUN_NOW=([^"]+)"', t, re.M)
    bigd = big or (mb.group(1) if mb else "")
    run_now = Path((mr.group(1) if mr else "").replace("%BIGMOVE_DIR%", bigd).replace("\\", "/" if "/" in bigd else "\\"))
    lines, warns = [f"tonight (v1.3.1): run_tonight.bat starts Run Now = {run_now}"], []
    if run_now.exists():
        cmds = _bat_lines(run_now)
        lines.append(f"   Run Now found; its commands ({len(cmds)}): " + " | ".join(cmds[:15]) + (" | ..." if len(cmds) > 15 else ""))
        if any(re.match(r"(?i)^pause\b", c) for c in cmds):
            lines.append("   Run Now pauses: press a key once when it asks (with 'auto' it gets no keyboard and goes on)")
        if any(re.match(r"(?i)^start\b", c) for c in cmds):
            warns.append("tonight: Run Now hands its work to another window (START) - run_tonight.bat cannot wait for "
                         "it, so steps 2-4 may run before it has finished; send Claude run_now.bat")
    else:
        warns.append(f"tonight: Run Now's file not found ({run_now}) - edit TN_RUN_NOW at the top of run_tonight.bat")
    for rel in ("env_daily.bat", "open_close/pick_meta.py"):
        f = Path(bigd) / rel
        if not f.exists():
            warns.append(f"tonight: {f} not found - step 2 (pick_meta) cannot run")
    rpm = Path(bigd) / "open_close" / "run_pick_meta.bat"
    if rpm.exists():
        py = [c for c in _bat_lines(rpm) if re.search(r"(?i)\bpython\b", c)]
        lines.append("   run_pick_meta.bat's python lines: " + " | ".join(py) + "   (step 2 runs: pick_meta.py publish "
                     "--all-missing, then pick_meta.py score)")
        other = [c for c in py if not re.search(r"pick_meta\.py\s+(publish|score)\b", c)]
        if other:
            warns.append("tonight: run_pick_meta.bat also runs " + " | ".join(other) + " - step 2 does not; send Claude "
                         "run_pick_meta.bat")
    else:
        lines.append("   run_pick_meta.bat not found (step 2 does not need it: it runs pick_meta.py itself)")
    if "setuplab.py scan" in t:                    # setups add-on: step 3, the frozen setups' nightly scan
        sd = setuplab
        env = bat.with_name("env_tradelab.bat")
        if sd is None and env.exists():
            ms = re.search(r'^set "SETUPLAB_DIR=([^"]+)"', env.read_text(encoding="ascii", errors="replace"), re.M)
            sd = ms.group(1) if ms else ""
        sp = Path(sd) / "setuplab.py" if sd else None
        if sp is not None and sp.exists():
            fz = sp.with_name("FROZEN_SETUPS.json")
            lines.append(f"   step 3 (setup scan): {sp}; freeze file {'found' if fz.exists() else 'NOT FOUND'}")
            if not fz.exists():
                warns.append(f"tonight: {fz} not found - the setup scan refuses without the freeze file")
        else:
            warns.append(f"tonight: setuplab.py not found ({sp}) - step 3 (the setup scan) cannot run; edit SETUPLAB_DIR "
                         f"at the top of env_tradelab.bat")
    return lines, warns


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="tradelab preflight")
    ap.add_argument("--root")
    ap.add_argument("--pm-run")
    ap.add_argument("--panel", default="panel_oc")
    ap.add_argument("--stage-e-any", action="store_true")
    ap.add_argument("--sample", type=int, default=300)
    a = ap.parse_args(sys.argv[1:] if argv is None else argv)
    problems = []
    warnings = []
    try:
        root = require_root(a.root)
        pv = provenance()
        say(f"{TOOL} ({VERSION}) | python {pv['python']} pandas {pv['pandas']} numpy {pv['numpy']} "
            f"pyarrow {pv.get('pyarrow', 'MISSING')}")
        if "pyarrow" not in pv:
            problems.append("pyarrow is not installed (pip install pyarrow)")
        prod = D.Production(stage_e_any=a.stage_e_any)
        d = prod.describe()
        say(f"stage_e_execution: {d['stage_e_file']} sha {d['stage_e_sha16']} ({d['stage_e_version']}) "
            f"{'= shipped v1.2' if d['stage_e_is_shipped'] else 'NOT the shipped v1.2'}")
        for mod in ("data_quality", "research_common", "panel_build"):
            try:
                m = __import__(mod)
                say(f"{mod}: {Path(m.__file__).resolve()}")
            except Exception as e:
                say(f"{mod}: not importable ({type(e).__name__}) - tradelab uses its own copy of the rules")
        m = D.Market(root, prod)
        cal = m.cal
        say(f"calendar (NIFTY50): {len(cal):,} sessions {cal[0]} .. {cal[-1]}; daily stamp notes {m.diag or 'none'}")
        try:
            from types import SimpleNamespace
            say("market context (v1.1) - index files and AMFI size lists:")
            lines, probs = CX.check_lines(SimpleNamespace(market=m, root=root))
            for x in lines:
                say(x)
            warnings += probs
        except TLError as e:
            warnings.append(f"market context: {e}")
        # v1.3: what the watch page reads, and one stock's state
        try:
            import tl_watch as WT
            import tl_state as ST
            L_ = WT.read_ledger(root)
            dl = pd.Timestamp(L_["signal_day"].max())
            say(f"watch (v1.3): paper ledger {len(L_):,} records, latest day {dl:%Y-%m-%d} "
                f"({', '.join(f'{e} {n}' for e, n in L_[L_['signal_day'] == dl]['engine'].value_counts().items())}); "
                f"unreadable lines {L_.attrs.get('unreadable_lines', 0)}")
            pmf, wlf = WT.pm_card_path(root, dl), WT.wl_path(root, dl)
            say(f"   pick_meta card {pmf.name}: {'found' if pmf.exists() else 'NOT FOUND (run run_pick_meta.bat)'}; "
                f"paper watchlist {wlf.name}: {'found' if wlf.exists() else 'not found (Soul cards will be skipped)'}")
            if wlf.exists():
                sy = sorted(L_[L_["signal_day"] == dl]["symbol"].unique())
                found = WT.soul_sections(wlf.read_text(encoding="utf-8", errors="replace"), sy)
                say(f"   Soul cards found for {len(found)} of {len(sy)} stocks" + ("" if len(found) == len(sy) else
                    f" - missing: {', '.join(s_ for s_ in sy if s_ not in found)[:200]} (send Claude the WL file)"))
                if len(found) < len(sy):
                    warnings.append("watch: some Soul cards were not found in the paper watchlist file")
            s0 = L_[L_["signal_day"] == dl]["symbol"].iloc[0]
            ds = m.series(s0)
            if ds is not None:
                ss = ST.StateSeries(s0, ds.dates, ds.o, ds.h, ds.l, ds.c, ds.v)
                i = ss.idx(np.datetime64(dl.date()))
                say(f"   state of {s0} on {dl:%Y-%m-%d}: {ss.row(i)['headline'] if i >= 0 else 'no bar that day'}")
        except Exception as e:  # noqa: BLE001 - a preflight: anything here is a warning, never a crash
            warnings.append(f"watch: {e}")
        # v1.3.1: what run_tonight.bat will start (read, never run)
        try:
            tl_, tw_ = tonight_lines(HERE / "run_tonight.bat")
            for x in tl_:
                say(x)
            warnings += tw_
        except Exception as e:  # noqa: BLE001
            warnings.append(f"tonight: {e}")
        T, info = D.load_picks(root, a.pm_run, ["D", "ENS"], list(range(1, 11)))
        say(f"pick_meta {a.pm_run}: hash OK; {info['rows_in_file']:,} rows, engines {info['engines_in_file']}, "
            f"{info['signal_days_in_file']:,} signal days {info['first_day']} .. {info['last_day']}")
        say(f"   ranks {sorted(T['rank'].unique().tolist())}; recorded status {T['status_recorded'].value_counts().to_dict()}")
        say(f"   rule attributes: {info['rule_attributes']}")
        # daily bars of a recent pick
        recent = T.sort_values("signal_day").iloc[-1]
        m.load([recent["symbol"]])
        ds = m.series(recent["symbol"])
        if ds is None:
            problems.append(f"no daily bars for {recent['symbol']}")
        else:
            say(f"daily bars {recent['symbol']}: {len(ds):,} sessions {ds.dates[0]} .. {ds.dates[-1]}; volume "
                f"{'present' if np.isfinite(ds.v).any() else 'MISSING'}")
        # 3-minute bars
        try:
            st = m.intraday
            say(f"3-minute folder: {st.dir} ({len(list(st.dir.glob('*.parquet'))):,} files); intraday_cache "
                f"{prod.describe().get('intraday_cache_file')}")
            cand = T[T["signal_day"] >= pd.Timestamp("2022-01-01")].sort_values("signal_day")
            sym = None
            for s_ in cand["symbol"].iloc[::-1].unique()[:30]:
                if st.path(s_).exists():
                    sym = s_
                    break
            if sym is None:
                problems.append("no 3-minute file found for recent picks")
            else:
                fp = st.path(sym)
                X = pd.read_parquet(fp)
                say(f"   sample {fp.name}: columns {list(X.columns)}; timestamp dtype {X['timestamp'].dtype}; "
                    f"{X['timestamp'].iloc[0]} .. {X['timestamp'].iloc[-1]}; {len(X):,} bars")
                ts = pd.to_datetime(X["timestamp"])
                if getattr(ts.dt, "tz", None) is not None:
                    ts = ts.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
                mins = (ts - ts.dt.normalize()).dt.total_seconds() / 60 - (9 * 60 + 15)
                on_grid = ((mins >= 0) & (mins <= 372) & (np.abs(mins / 3 - np.round(mins / 3)) < 1e-6)).mean()
                first_slot = (mins == 0).groupby(ts.dt.normalize()).any().mean()
                say(f"   bars on the 09:15 + 3k grid: {on_grid:.1%}; days with a 09:15 bar: {first_slot:.1%}")
                if on_grid < 0.95 or first_slot < 0.9:
                    problems.append(f"3-minute layout looks wrong in {fp.name} (end-stamped bars or another zone?)")
                dsx = m.series(sym)
                days = list(dsx.dates[-20:]) if dsx is not None else []
                ss = st.sessions(sym, days, dsx)
                ok = sum(1 for s in ss.values() if s.usable)
                say(f"   last 20 sessions of {sym}: {ok} usable ({st.reasons})")
        except TLError as e:
            problems.append(str(e))
        # panel
        try:
            P = m.panel(a.panel)
            md = P.pf.metadata
            say(f"panel {P.path}: {md.num_rows:,} rows, {md.num_columns} columns; features kept {len(P.allowed)}; "
                f"dropped " + ", ".join(f"{k} {len(v)}" for k, v in P.dropped.items() if isinstance(v, list))
                + f" ({P.dropped['rule']})")
        except TLError as e:
            problems.append(str(e))
        # plan reproduction on a sample
        from tl_export import PLAN, reconcile
        smp = T.sample(min(a.sample, len(T)), random_state=7).reset_index(drop=True)
        m.load(sorted(smp["symbol"].unique()))
        plan = E.Strategy(dict(PLAN), None, D.rule_pick_columns(T.columns))
        sim = E.TradeSim(plan, m)
        res = [sim.run(p) for p in smp.to_dict("records")]
        rec = reconcile(smp, res, m)
        say(f"plan on {len(smp)} random picks: {rec['line']}")
        if not rec["ok"]:
            problems.append("the plan does not reproduce pick_meta's record on the sample")
            say(rec["mismatches"].head(10).to_string())
    except (TLError, StopRun) as e:
        problems.append(str(e))
    if warnings:
        say("WARNINGS (tradelab runs; the affected market-context columns stay blank - never filled):")
        for w in warnings:
            say(f"  - {w}")
    if problems:
        say("PROBLEMS:")
        for p in problems:
            say(f"  - {p}")
        say("CHECK FAILED - send Claude everything above")
        return 2
    say("CHECK OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
