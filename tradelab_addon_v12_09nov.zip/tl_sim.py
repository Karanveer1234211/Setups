"""
tl_sim.py - tradelab v1.3.1: replay single trades bar by bar, in their market, with the stock's state.

    python tl_sim.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --trade D-20240425-2
        [--trade ENS-20250102-1 ...] [--strategy strategies\\scale_20_80_vwap.py --strategy strategies\\plan.py]
    python tl_sim.py ... --symbol RELIANCE --signal-day 2024-04-25      (any stock and day, picked or not)

For every trade and strategy it writes, under <out>\\sim\\TLS_YYYYMMDD_NNN\\:
  <trade>__<strategy>_story.md      what happened, in order: every buy / sell with its reason, when each named
                                    event first fired, a day-by-day table (prices, position, the day's P&L)
  <trade>__<strategy>_timeline.csv  one row per bar: prices, VWAP, every value the strategy's rules use, each
                                    event true/false, position, average entry, unrealised P&L, MFE / MAE so far,
                                    armed orders and trailing levels, fills on that bar
  <trade>_chart.html                price (3-minute closes or daily candles), VWAP, session lines, every strategy's
                                    buys and sells, and below it each strategy's position and running P&L; v1.1: a
                                    third panel - the stock against NIFTY 50 / Midcap 150 / Smallcap 250 from the
                                    pick-day close
and prints the story. The numbers are the same as tl_backtest.py's for that trade (same engine, same rules).
v1.1: the story opens with the chain - the market the day before and on the pick day, the pick (size class, the
index it moves with), each session's stock move next to NIFTY / Midcap / Smallcap / VIX, and the split of the trade
into the market part and the stock part. --context auto (default) | full | saved | indices | none.
v1.3.1: the story then shows the stock's state (tl_state): at the pick - known before entry - with what it rested on
and what would end it, and session by session through the trade (observed after entry: explains, never selects).
Setups add-on v1.2: with setuplab's entry tree the story also names the pick's lane (calm / jumpy, known at the pick's
close) and what the tree did with it; a strategy with the entry {"tree": True} trades the tree (strategies/tree.py).
"""
from __future__ import annotations

import argparse
import html
import json
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from tl_common import (StopRun, TLError, VERSION, ledger_append, new_run_dir, out_base, parse_day, provenance,
                       require_root, say, write_outputs_sha)
import tl_engine as E
import tl_context as CX
import tl_setups as SU
from tl_run import Workspace

TOOL = "tl_sim v1.3.1"
COLORS = ["#1f6feb", "#d1242f", "#1a7f37", "#9a6700"]


def parse_args(argv):
    ap = argparse.ArgumentParser(description="tradelab sim: replay trades bar by bar")
    ap.add_argument("--root")
    ap.add_argument("--pm-run")
    ap.add_argument("--trade", action="append", default=[])
    ap.add_argument("--symbol", default=None)
    ap.add_argument("--signal-day", default=None)
    ap.add_argument("--engine", default="X")
    ap.add_argument("--strategy", action="append", default=[])
    ap.add_argument("--values", default="", help="extra values recorded in the timelines, e.g. vwap,rvol,clv,D_rsi14")
    ap.add_argument("--panel", default="panel_oc")
    ap.add_argument("--out", default=None)
    ap.add_argument("--stage-e-any", action="store_true")
    ap.add_argument("--context", default="auto", help="market context: auto (default) | full | saved | indices | none")
    ap.add_argument("--setups", default=None, help="setuplab's output folder (default: SETUPLAB_OUT): the pick's "
                    "frozen setups in the story, and setup entry legs")
    return ap.parse_args(argv)


def setup_line(p: dict, tinfo: dict, tagged: set) -> str:
    """The setups add-on's line in the story: which frozen setups entered this pick (hindsight before their day)."""
    if not tinfo.get("used"):
        return ""
    d = p.get("_setup_days") or {}
    if str(p.get("trade_id")) not in tagged:
        txt = f"not covered by the tags {tinfo.get('run')}"
    elif not d:
        txt = "none of the frozen setups entered this pick"
    else:
        txt = ", ".join(f"{k} on D{v}" for k, v in sorted(d.items(), key=lambda kv: (kv[1], kv[0])))
    return (f"\n**Frozen setups on this pick** ({tinfo.get('run')}): {txt}. A setup is known only on its own entry "
            f"day - hindsight for any entry before it.\n")


def tree_line(p: dict, trinfo: dict) -> str:
    """setups add-on v1.2: the pick's lane and the entry tree's action (hindsight after the pick's close)."""
    if not trinfo.get("used"):
        return ""
    tg = p.get("tree_tagged")
    if not (isinstance(tg, (bool, np.bool_)) and tg):
        return f"\n**Entry tree** ({trinfo.get('run')}): this pick is not covered by the tree run.\n"
    lane = str(p.get("lane") or "")
    atr, cut = p.get("lane_atr14"), p.get("lane_cutoff")
    try:
        lv = f" (ATR14 {float(atr):.2%} of the close vs the year's cut-off {float(cut):.2%})"
    except (TypeError, ValueError):
        lv = ""
    act = str(p.get("tree_action") or "") or "no action (the tree acts on ranks 1-3 from its first cut-off year)"
    try:
        nt = f"; the tree's own trade made {float(p.get('tree_net')):+.2f}% net" if np.isfinite(float(p.get("tree_net"))) \
            else ""
    except (TypeError, ValueError):
        nt = ""
    return (f"\n**Entry tree** ({trinfo.get('run')}): lane {lane}{lv} - known at the pick's close. The tree: {act}{nt}. "
            f"The tree's action is decided at the open and on each setup's own day - hindsight before then.\n")


def main(argv=None) -> int:
    a = parse_args(sys.argv[1:] if argv is None else argv)
    t0 = time.time()
    try:
        root = require_root(a.root)
        base = out_base(a.out, root)
        ws = Workspace(root, a.pm_run, stage_e_any=a.stage_e_any, panel=a.panel, quiet=True)
        allp = ws.picks(["D", "ENS"], "1-10")
        tree, trinfo = SU.load_tree(SU.base_dir(a.setups))    # setups add-on v1.2: the entry tree
        if tree is not None:
            allp = SU.tree_columns(allp, tree)
        rows = []
        for tid in a.trade:
            m = allp[allp["trade_id"] == tid]
            if m.empty:
                raise TLError(f"trade {tid} not found (format ENGINE-YYYYMMDD-RANK, e.g. D-20240425-2)")
            rows.append(m.iloc[0].to_dict())
        if a.symbol:
            d = parse_day(a.signal_day)
            if d is None:
                raise TLError("--symbol needs --signal-day YYYY-MM-DD")
            hit = allp[(allp["symbol"] == a.symbol) & (allp["signal_day"] == pd.Timestamp(str(d)))]
            if len(hit):
                rows.append(hit.iloc[0].to_dict())
                say(f"note: {a.symbol} on {d} was picked ({hit.iloc[0]['trade_id']}); using that pick")
            else:
                rows.append({"trade_id": f"{a.engine}-{str(d).replace('-', '')}-{a.symbol}", "engine": a.engine,
                             "symbol": a.symbol, "signal_day": pd.Timestamp(str(d)), "rank": np.nan, "traded": False})
        if not rows:
            raise TLError("give --trade ENGINE-YYYYMMDD-RANK (repeatable) or --symbol with --signal-day")
        T = pd.DataFrame(rows).reset_index(drop=True)
        for c in allp.columns:
            if c not in T.columns:
                T[c] = np.nan
        ctx = ws.context(a.context, base) if a.context != "none" else None
        if ctx is not None:
            T = ws.add_pick_context(T)
        paths = a.strategy or [str(HERE / "strategies" / "plan.py")]
        if tree is None:
            for p_ in paths:
                if SU.reads_calm(E.read_strategy(p_)[0]):
                    raise TLError(f"{p_}: 'calm' (the entry tree's lane) needs setuplab's tree run: {trinfo.get('why')}")
        strats = [ws.strategy(p, allp) for p in paths]
        need = sorted({x for s in strats for x in s.setup_ids})
        use_tree = any(s.uses_tree for s in strats)
        tags, tinfo = SU.load_tags(SU.base_dir(a.setups), need=bool(need) or use_tree)
        bad = [x for x in need if x not in tinfo.get("setups", [])]
        if bad:
            raise TLError(f"setup entries {bad} are not frozen setups (the tags hold {tinfo.get('setups')})")
        sd = SU.setup_days(tags, tinfo.get("setups", []))
        T["_setup_days"] = [sd.get(str(t), {}) for t in T["trade_id"]]
        if use_tree:
            if tree is None:
                SU.load_tree(SU.base_dir(a.setups), need=True)
            T["_tree"] = SU.tree_entries(T, tree, tags, tinfo, trinfo)
        tagged = set(tags["trade_id"]) if tags is not None else set()
        extra = [x.strip() for x in a.values.split(",") if x.strip()]
        if extra:
            allowed = ws.market.panel(a.panel).allowed if any(
                x not in E.R.MARKET_VARS and x not in E.R.PLUGIN_VARS for x in extra) else []
            for s in strats:
                s.observe(extra, allowed)
        names = [s.name for s in strats]
        if len(set(names)) != len(names):
            raise TLError(f"two strategies share a name {names}; give each STRATEGY a distinct 'name'")
        res, extra = ws.simulate(strats, T, timeline_ids=set(T["trade_id"]))
        run_dir = new_run_dir(base, "sim", "TLS")
        written = []
        states: Dict[str, object] = {}
        for i, p in enumerate(T.to_dict("records")):
            per = []
            for s in strats:
                r = res[s.name][i]
                per.append((s, r))
                stem = f"{p['trade_id']}__{s.name}"
                story = story_md(p, s, r) + (context_md(p, s, r, ctx, ws) + state_md(p, s, r, ws, states)
                                             if ctx is not None else "") + setup_line(p, tinfo, tagged) + tree_line(p, trinfo)
                (run_dir / f"{stem}_story.md").write_text(story, encoding="utf-8")
                written.append(f"{stem}_story.md")
                if r.timeline is not None and len(r.timeline):
                    r.timeline.to_csv(run_dir / f"{stem}_timeline.csv", index=False)
                    written.append(f"{stem}_timeline.csv")
                say(story)
            if any(r.timeline is not None and len(r.timeline) for _, r in per):
                (run_dir / f"{p['trade_id']}_chart.html").write_text(chart_html(p, per, ctx, ws), encoding="utf-8")
                written.append(f"{p['trade_id']}_chart.html")
        (run_dir / "summary.json").write_text(json.dumps(
            {"tool": TOOL, "version": VERSION, "trades": T["trade_id"].tolist(), "strategies":
             [s.summary() for s in strats], "results": {s.name: [r.row() for r in res[s.name]] for s in strats},
             "files": written, "production": ws.prod.describe(), "provenance": provenance()}, indent=2, default=str),
            encoding="utf-8")
        write_outputs_sha(run_dir)
        ledger_append(base, {"tool": TOOL, "event": "sim", "run": run_dir.name, "trades": T["trade_id"].tolist(),
                             "strategies": [(s.name, s.sha) for s in strats]})
        say(f"DONE {run_dir}  ({time.time() - t0:,.1f} s)")
        return 0
    except StopRun as e:
        say(f"STOPPED: {e}")
        return 3
    except TLError as e:
        say(f"ERROR: {e}")
        return 2


# ----------------------------------------------------------------------
def story_md(p: dict, s: E.Strategy, r: E.TradeResult) -> str:
    head = (f"## {p['trade_id']} {p['symbol']} - {s.name}\n\n"
            f"{p.get('engine')} rank {p.get('rank')}, signal day {pd.Timestamp(p['signal_day']).date()}, "
            f"mode {s.mode}. Status: **{r.status}**{(' - ' + r.note) if r.note else ''}.\n")
    if r.status not in ("ok", "not_entered", "stuck", "pending"):
        return head
    L = [head]
    if r.fills:
        L.append(f"Result: **net {r.net * 1e4:+.1f} bp** of the target size (gross {r.gross * 1e4:+.1f}, costs "
                 f"{r.costs * 1e4:.1f}); bought {r.deployed:.0%} of the target, average entry {r.avg_entry:.2f}, last "
                 f"sale {r.exit_price:.2f} ({r.exit_reason}, session {r.exit_session}); MFE {r.mfe:+.2%} (session "
                 f"{r.mfe_session}), MAE {r.mae:+.2%} (session {r.mae_session}).\n")
    else:
        L.append("Result: never entered (no entry condition fired) - 0 bp, the slot stayed in cash.\n")
    ev = []
    for f in r.fills:
        ev.append((str(f.ts) if f.ts is not None else f.when, f"**{f.side.upper()} {f.leg}** "
                   f"{f.frac:.0%} {'of the target' if f.side == 'buy' else 'of the position'} @ {f.price:.2f} "
                   f"({f.kind}: {f.reason})"))
    for nm, when in r.events_first.items():
        ev.append((when.replace(" ", "T") if " " in when else when, f"event *{nm}* first true"))
    ev.sort(key=lambda x: x[0])
    L.append("### What happened, in order\n")
    for w, txt in ev:
        L.append(f"- {w.replace('T', ' ')[:16]}  {txt}")
    if r.path:
        L.append("\n### Day by day (official daily prices)\n")
        L.append("| session | date | open | high | low | close | position | day P&L bp | total bp | trades |")
        L.append("|---|---|---|---|---|---|---|---|---|---|")
        for row in r.path:
            tr = " ".join(x for x in (row.get("buys") and "buy " + row["buys"], row.get("sells") and "sell " + row["sells"]) if x)
            L.append(f"| {row['session']} | {row['date']} | {row['open']:.2f} | {row['high']:.2f} | {row['low']:.2f} | "
                     f"{row['close']:.2f} | {row['pos']:.0%} | {row['day_net'] * 1e4:+.1f} | {row['mtm_net'] * 1e4:+.1f} | "
                     f"{tr} |")
    return "\n".join(L) + "\n"


def chart_html(p: dict, per: List, ctx=None, ws=None) -> str:
    """Self-contained SVG chart: price + VWAP + fills on top; position and running P&L per strategy below; v1.1: the
    stock against NIFTY 50 / Midcap 150 / Smallcap 250 (from the pick-day close, at each session's close)."""
    tl = next(r.timeline for _, r in per if r.timeline is not None and len(r.timeline))
    n = len(tl)
    W, PH, QH, ML, MR, MT = 1100, 330, 150, 64, 16, 28
    IH = 170 if ctx is not None else 0
    H = MT + PH + 40 + QH + 40 + (IH + 40 if IH else 0)
    x = lambda i: ML + (W - ML - MR) * (i / max(1, n - 1))
    lo = float(np.nanmin(tl["low"]))
    hi = float(np.nanmax(tl["high"]))
    pad = (hi - lo) * 0.06 or 1.0
    lo, hi = lo - pad, hi + pad
    y = lambda v: MT + PH * (1 - (v - lo) / (hi - lo))
    parts = [f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg" font-family="Segoe UI, Arial" font-size="11">']
    parts.append(f'<rect x="{ML}" y="{MT}" width="{W - ML - MR}" height="{PH}" fill="#fafbfc" stroke="#d0d7de"/>')
    for k in range(5):
        v = lo + (hi - lo) * k / 4
        parts.append(f'<line x1="{ML}" x2="{W - MR}" y1="{y(v):.1f}" y2="{y(v):.1f}" stroke="#eaeef2"/>')
        parts.append(f'<text x="{ML - 6}" y="{y(v) + 4:.1f}" text-anchor="end" fill="#57606a">{v:.2f}</text>')
    sess = tl["session"].to_numpy()
    starts = [0] + [i for i in range(1, n) if sess[i] != sess[i - 1]]
    for i in starts:
        parts.append(f'<line x1="{x(i):.1f}" x2="{x(i):.1f}" y1="{MT}" y2="{MT + PH}" stroke="#d0d7de" stroke-dasharray="3,3"/>')
        parts.append(f'<text x="{x(i) + 3:.1f}" y="{MT - 8}" fill="#57606a">s{sess[i]} {html.escape(str(tl["time"].iloc[i])[:10])}</text>')
    daily = "bar_in_session" in tl and int(tl["bar_in_session"].max()) == 0
    if daily:
        bw = max(2.0, (W - ML - MR) / max(1, n) * 0.6)
        for i, row in tl.iterrows():
            col = "#1a7f37" if row["close"] >= row["open"] else "#d1242f"
            parts.append(f'<line x1="{x(i):.1f}" x2="{x(i):.1f}" y1="{y(row["high"]):.1f}" y2="{y(row["low"]):.1f}" stroke="{col}"/>')
            top, bot = y(max(row["open"], row["close"])), y(min(row["open"], row["close"]))
            parts.append(f'<rect x="{x(i) - bw / 2:.1f}" y="{top:.1f}" width="{bw:.1f}" height="{max(1, bot - top):.1f}" fill="{col}"/>')
    else:
        pts = " ".join(f"{x(i):.1f},{y(v):.1f}" for i, v in enumerate(tl["close"]) if np.isfinite(v))
        parts.append(f'<polyline points="{pts}" fill="none" stroke="#24292f" stroke-width="1.2"/>')
        if "vwap" in tl:
            seg = []
            for i in range(n):
                if i in starts and seg:
                    parts.append(f'<polyline points="{" ".join(seg)}" fill="none" stroke="#bf8700" stroke-width="1.2" stroke-dasharray="4,2"/>')
                    seg = []
                v = tl["vwap"].iloc[i]
                if np.isfinite(v):
                    seg.append(f"{x(i):.1f},{y(v):.1f}")
            if seg:
                parts.append(f'<polyline points="{" ".join(seg)}" fill="none" stroke="#bf8700" stroke-width="1.2" stroke-dasharray="4,2"/>')
    # fills
    for si, (s, r) in enumerate(per):
        col = COLORS[si % len(COLORS)]
        for f in r.fills:
            i = f.bar if 0 <= f.bar < n else n - 1
            yy = y(min(max(f.price, lo), hi))
            if f.side == "buy":
                parts.append(f'<path d="M{x(i):.1f},{yy - 1:.1f} l-6,11 l12,0 z" fill="{col}"><title>{html.escape(s.name)} BUY {html.escape(f.leg)} {f.frac:.0%} @ {f.price:.2f} ({html.escape(f.reason)})</title></path>')
            else:
                parts.append(f'<path d="M{x(i):.1f},{yy + 1:.1f} l-6,-11 l12,0 z" fill="none" stroke="{col}" stroke-width="2"><title>{html.escape(s.name)} SELL {html.escape(f.leg)} {f.frac:.0%} @ {f.price:.2f} ({html.escape(f.reason)})</title></path>')
    # lower panel: running P&L (bp) per strategy
    top2 = MT + PH + 40
    vals = []
    for s, r in per:
        if r.timeline is not None and len(r.timeline) == n:
            pos = r.timeline["pos"].to_numpy(float)
            up = r.timeline["upnl"].to_numpy(float)
            vals.append((s, pos, up))
    allv = np.concatenate([np.nan_to_num(v[2] * 1e4) for v in vals]) if vals else np.array([0.0])
    vlo, vhi = min(-10.0, float(np.nanmin(allv))), max(10.0, float(np.nanmax(allv)))
    y2 = lambda v: top2 + QH * (1 - (v - vlo) / (vhi - vlo))
    parts.append(f'<rect x="{ML}" y="{top2}" width="{W - ML - MR}" height="{QH}" fill="#fafbfc" stroke="#d0d7de"/>')
    parts.append(f'<line x1="{ML}" x2="{W - MR}" y1="{y2(0):.1f}" y2="{y2(0):.1f}" stroke="#8c959f"/>')
    parts.append(f'<text x="{ML - 6}" y="{y2(vhi) + 10:.1f}" text-anchor="end" fill="#57606a">{vhi:+.0f}</text>')
    parts.append(f'<text x="{ML - 6}" y="{y2(vlo):.1f}" text-anchor="end" fill="#57606a">{vlo:+.0f}</text>')
    parts.append(f'<text x="{ML}" y="{top2 - 8}" fill="#57606a">unrealised P&amp;L on the position held (bp of the average entry); shaded = position size</text>')
    for si, (s, pos, up) in enumerate(vals):
        col = COLORS[si % len(COLORS)]
        pts = " ".join(f"{x(i):.1f},{y2(v * 1e4):.1f}" for i, v in enumerate(up) if np.isfinite(v))
        if pts:
            parts.append(f'<polyline points="{pts}" fill="none" stroke="{col}" stroke-width="1.4"/>')
        for i in range(n):
            if pos[i] > 0:
                parts.append(f'<rect x="{x(i):.1f}" y="{top2 + QH - 6 - 6 * si:.1f}" width="{max(1.0, (W - ML - MR) / n):.1f}" height="4" fill="{col}" opacity="{0.25 + 0.6 * min(1, pos[i]):.2f}"/>')
    if IH:
        parts += _index_panel(tl, p, ctx, ws, x, ML, W - MR, MT + PH + 40 + QH + 40 + 10, IH)
    parts.append("</svg>")
    legend = " ".join(f'<span style="color:{COLORS[i % len(COLORS)]}">&#9632; {html.escape(s.name)}: net '
                      f'{r.net * 1e4:+.1f} bp ({html.escape(r.status)})</span>' for i, (s, r) in enumerate(per))
    title = f"{p['trade_id']} {p['symbol']} - signal {pd.Timestamp(p['signal_day']).date()}"
    return (f"<!doctype html><html><head><meta charset='utf-8'><title>{html.escape(title)}</title>"
            f"<style>body{{font-family:Segoe UI,Arial;margin:18px;color:#24292f}}h1{{font-size:18px}}"
            f".lg span{{margin-right:18px}}</style></head><body><h1>{html.escape(title)}</h1>"
            f"<div class='lg'>{legend}</div><p style='color:#57606a'>Triangles: filled = buy, outline = sell "
            f"(hover for the reason). Dashed gold = session VWAP. Dashed grey = session starts.</p>"
            f"{''.join(parts)}</body></html>")


# ----------------------------------------------------------------------
# v1.3.1: the stock's state at the pick and through the trade
# ----------------------------------------------------------------------
def state_md(p: dict, s: E.Strategy, r: E.TradeResult, ws, cache: Optional[dict] = None) -> str:
    """Session 0 = the signal day (known before entry); sessions 1.. = observed after entry."""
    import tl_state as ST
    cache = {} if cache is None else cache
    sym = p["symbol"]
    if sym not in cache:
        ds = ws.market.series(sym)
        cache[sym] = None if ds is None or len(ds) == 0 else ST.StateSeries(sym, ds.dates, ds.o, ds.h, ds.l, ds.c, ds.v)
    ss = cache[sym]
    L = ["", "### The stock's state (tl_state - session 0 is known before entry; later rows were observed after "
             "entry: they explain, they never select)", ""]
    if ss is None:
        return "\n".join(L + ["- no daily bars for this stock", ""]) + "\n"
    i0 = ss.idx(np.datetime64(pd.Timestamp(p["signal_day"]).date(), "D"))
    if i0 < 0:
        return "\n".join(L + ["- no bar on the signal day - no state", ""]) + "\n"
    r0 = ss.row(i0)
    txt = {**ST.cond_text(ss.cfg), **ST.EXTRA_TEXT}
    L.append(f"- At the pick: **{r0['headline']}**")
    if r0["state"] in ST.STATES:
        ev = ss.evidence(i0)
        req = sum(v == 1 for _, v in ev["required"])
        sup = [k for k, v in ev["supporting"] if v == 1]
        con = [txt.get(k, k) for k, v in ev["conflicting"] if v == 1]
        L.append(f"- {ST.STATE_NAMES[r0['state']]} began {r0['began']:%d %b %Y}, confirmed {r0['confirmed']:%d %b %Y} "
                 f"(before it: {r0['prev_state'] or '-'}); required {req} of {len(ev['required'])} hold, supporting "
                 f"{len(sup)} of {len(ev['supporting'])} (support {r0['support']:.0%}), conflicts: "
                 f"{'; '.join(con) if con else 'none'}")
        L.append(f"- What would end it: {r0['invalidation']}")
    elif r0["state"] == "UNKNOWN":
        L.append(f"- Why unknown: {r0['unknown_why']}")
    if r0["event_text"]:
        L.append(f"- Event: {r0['event_text']}")
    if r0["risks"]:
        L.append("- Risk flags: " + "; ".join(ST.RISK_TEXT.get(x, x) for x in r0["risks"].split(",") if x))
    if r0["notes"]:
        L.append("- Notes: " + "; ".join(ST.NOTE_TEXT.get(x, x) for x in r0["notes"].split(",") if x))
    hist = ss.history(i0)
    if hist:
        L.append("- Transitions before the pick: " + " -> ".join([hist[0][2]] + [f"{t} ({b:%d %b})" for a, b, f, t in hist]))
    last = max([int(x["session"]) for x in r.path] + [s.max_sessions]) if r.path else s.max_sessions
    L += ["", "| s | date | close | state | that day's reading | confidence | phase | event | risk flags |",
          "|---|---|---|---|---|---|---|---|---|"]
    for k in range(0, last + 1):
        j = i0 + k
        if j >= ss.n:
            break
        e = ""
        if ss.ev_kind[j]:
            code, nm = ST.EVENT_NAMES[ss.ev_kind[j]]
            e = f"{code + ' ' if code else ''}{nm}" + ("" if ss.ev_status[j] == "FAILED" else f" {ss.ev_status[j].lower()}")
        rk = "; ".join(ST.RISK_TEXT.get(x, x) for x in str(ss.risks[j]).split(",") if x)
        L.append(f"| {k} | {ss.day(j):%a %d %b %Y} | {ss.c[j]:,.2f} | {ss.state[j]} | {ss.raw[j]} | {ss.confidence[j]} | "
                 f"{str(ss.phase[j]).lower()} | {e} | {rk} |")
    return "\n".join(L) + "\n"


# ----------------------------------------------------------------------
# v1.1: the market around the trade
# ----------------------------------------------------------------------
IDX_COLORS = {"nifty": "#1f6feb", "mid": "#9a6700", "small": "#d1242f"}


def _session_rows(p: dict, ctx, ws, last_session: int) -> List[dict]:
    """Sessions -1 .. last: the stock's day return and the market that day (by the calendar days of the stock's bars)."""
    ds = ws.market.series(p["symbol"])
    if ds is None:
        return []
    sig = ds.idx(np.datetime64(pd.Timestamp(p["signal_day"]).date(), "D"))
    if sig < 0:
        return []
    out = []
    for k in range(-1, last_session + 1):
        j = sig + k
        if j < 1 or j >= len(ds):
            continue
        q = ctx.ib.pos1(ds.dates[j])
        rec = {"session": k, "date": pd.Timestamp(str(ds.dates[j])), "stock": float(ds.c[j] / ds.c[j - 1] - 1),
               "close": float(ds.c[j])}
        for c in ("nifty_ret", "mid_ret", "small_ret", "vix", "vix_chg_pct", "ad_ratio", "environment", "high_stress",
                  "nifty_close", "mid_close", "small_close"):
            rec[c] = ctx.fcol(c, [q])[0]
        out.append(rec)
    return out


def context_md(p: dict, s: E.Strategy, r: E.TradeResult, ctx, ws) -> str:
    L = ["", "### The market around the trade (pre = known before entry; the table's later rows = observed after)", ""]
    F = ctx.frame.set_index("date")
    for lbl, d in (("Day before", p.get("pre_prev_date")), ("Pick day", p.get("signal_day"))):
        if d is None or pd.isna(d):
            continue
        d = pd.Timestamp(d).normalize()
        if d in F.index:
            L.append(f"- {lbl}: {CX.day_sentence({**F.loc[d].to_dict(), 'date': d})}")
    prof = []
    sc = p.get("pre_size_class")
    if sc in ("large", "mid", "small"):
        prof.append(f"size {str(sc).upper()} ({p.get('pre_amfi_list')})")
    elif sc:
        prof.append(f"size class {sc}")
    if p.get("pre_home_index_name"):
        if CX.fin(p.get("pre_beta_home")):
            prof.append(f"moves most with {p['pre_home_index_name']} (beta {float(p['pre_beta_home']):.2f}, "
                        f"correlation {float(p['pre_corr_home']):.2f})")
        else:
            prof.append(f"moves most with {p['pre_home_index_name']}")
    if prof:
        L.append("- The pick: " + "; ".join(prof) + ".")
    last = max([int(x["session"]) for x in r.path] + [s.max_sessions]) if r.path else s.max_sessions
    rows = _session_rows(p, ctx, ws, last)
    pos = {int(x["session"]): x for x in r.path} if r.path else {}
    h = p.get("pre_home_index") or ""
    if rows:
        L += ["", "| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |",
              "|---|---|---|---|---|---|---|---|---|---|---|---|"]
        for x in rows:
            hv = x.get(f"{h}_ret") if h else np.nan
            pr = pos.get(int(x["session"]), {})
            vix = f"{float(x['vix']):.1f}" if CX.fin(x["vix"]) else "n/a"
            adr = f"{float(x['ad_ratio']):.2f}" if CX.fin(x["ad_ratio"]) else "n/a"
            env = CX.ENV_TEXT.get(x.get("environment") or "", "n/a")
            rel = CX.pts(x["stock"] - hv) if CX.fin(hv) else "n/a"
            dn = pr.get("day_net", np.nan)
            dpl = f"{float(dn) * 1e4:+.0f}" if CX.fin(dn) else ""
            L.append(f"| {x['session']} | {x['date'].strftime('%a %d %b %Y')} | {CX.pct(x['stock'])} | "
                     f"{CX.pct(x['nifty_ret'])} | {CX.pct(x['mid_ret'])} | {CX.pct(x['small_ret'])} | {adr} | {vix} | "
                     f"{env} | {rel} | {float(pr.get('pos', 0) or 0):.0%} | {dpl} |")
    buys = [f for f in r.fills if f.side == "buy"]
    sells = [f for f in r.fills if f.side == "sell"]
    ds = ws.market.series(p["symbol"])
    if buys and sells and ds is not None and r.deployed > 0:
        sig = ds.idx(np.datetime64(pd.Timestamp(p["signal_day"]).date(), "D"))
        bj, sj = sig + int(buys[0].session), sig + int(sells[-1].session)
        if 0 <= bj < len(ds) and 0 <= sj < len(ds):
            w = ctx.window_returns(ds.dates[bj], "close" if buys[0].kind == "close" else "open", ds.dates[sj],
                                   "close" if sells[-1].kind == "close" else "open", CX.BROAD)
            g = float(r.gross / r.deployed)
            L += ["", f"- From the first buy to the last sale: NIFTY {CX.pct(w['nifty'])}, Midcap {CX.pct(w['mid'])}, "
                  f"Smallcap {CX.pct(w['small'])}; the trade made {CX.pct(g, 2)} gross on the money it used."]
            b = p.get("pre_beta_home")
            if h and CX.fin(b) and CX.fin(w.get(h)):
                mk = float(b) * w[h]
                L.append(f"- Split (on the money used): market part {CX.pct(mk, 2)} = beta {float(b):.2f} x "
                         f"{p.get('pre_home_index_name')} {CX.pct(w[h], 2)}; stock part {CX.pct(g - mk, 2)} -> "
                         f"{CX.DRIVER_TEXT.get(CX.driver_of(g, mk, g - mk), '')}.")
    return "\n".join(L) + "\n"


def _index_panel(tl: pd.DataFrame, p: dict, ctx, ws, x, x0: float, x1: float, top: float, h: float) -> List[str]:
    """The stock and the three indices at each session's close, % from the pick-day close."""
    sess = tl["session"].to_numpy()
    n = len(tl)
    ends = [i for i in range(n) if i == n - 1 or sess[i + 1] != sess[i]]
    last = int(sess[-1]) if n else 0
    rows = {int(r["session"]): r for r in _session_rows(p, ctx, ws, last)}
    base = rows.get(0)
    if base is None:
        return []
    ser = {"stock": [], "nifty": [], "mid": [], "small": []}
    xs = []
    for i in ends:
        r = rows.get(int(sess[i]))
        if r is None:
            continue
        xs.append(x(i))
        ser["stock"].append(r["close"] / base["close"] - 1)
        for k in ("nifty", "mid", "small"):
            a_, b_ = r.get(f"{k}_close"), base.get(f"{k}_close")
            ser[k].append(a_ / b_ - 1 if CX.fin(a_) and CX.fin(b_) else np.nan)
    allv = np.array([v for vv in ser.values() for v in vv if CX.fin(v)] + [0.0])
    lo, hi = float(allv.min()), float(allv.max())
    pad = (hi - lo) * 0.08 or 0.01
    lo, hi = lo - pad, hi + pad
    y = lambda v: top + h * (1 - (v - lo) / (hi - lo))
    P = [f'<rect x="{x0}" y="{top}" width="{x1 - x0}" height="{h}" fill="#fafbfc" stroke="#d0d7de"/>',
         f'<line x1="{x0}" x2="{x1}" y1="{y(0):.1f}" y2="{y(0):.1f}" stroke="#8c959f" stroke-dasharray="3,3"/>',
         f'<text x="{x0}" y="{top - 6}" fill="#57606a">at each session close, % from the pick-day close: '
         f'{html.escape(str(p["symbol"]))} (black), NIFTY 50 (blue), Midcap 150 (gold), Smallcap 250 (red)</text>',
         f'<text x="{x0 - 6}" y="{y(hi) + 10:.1f}" text-anchor="end" fill="#57606a">{hi * 100:+.1f}%</text>',
         f'<text x="{x0 - 6}" y="{y(lo):.1f}" text-anchor="end" fill="#57606a">{lo * 100:+.1f}%</text>']
    for k, vals in ser.items():
        pts = " ".join(f"{xx:.1f},{y(v):.1f}" for xx, v in zip(xs, vals) if CX.fin(v))
        col = "#24292f" if k == "stock" else IDX_COLORS[k]
        if pts:
            P.append(f'<polyline points="{pts}" fill="none" stroke="{col}" stroke-width="{2.2 if k == "stock" else 1.4}"/>')
            for xx, v in zip(xs, vals):
                if CX.fin(v):
                    P.append(f'<circle cx="{xx:.1f}" cy="{y(v):.1f}" r="2.5" fill="{col}"><title>{k} {v * 100:+.2f}%</title></circle>')
    return P


if __name__ == "__main__":
    raise SystemExit(main())
