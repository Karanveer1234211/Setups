@echo off
rem run_tonight.bat - tradelab v1.3.1 + setups add-on v1.0: the whole evening in ONE double-click. It replaces
rem pressing Run Now, then run_pick_meta.bat, then run_watch.bat:
rem   1  Run Now exactly as you double-click it: bigmove_deploy\run_now.bat, unchanged, started from its own folder
rem      in a child cmd - nothing inside it can end this script
rem   2  pick_meta: publish the cards (every recorded day still without one) and score the tracker - the commands of
rem      open_close\run_pick_meta.bat, in the same environment
rem   3  setuplab: the frozen setups' scan of the last five days' picks (what to buy at the next open), for tonight
rem      and every evening since the freeze still without one; its own on-time ledger (SETUPLAB_DIR / SETUPLAB_OUT
rem      come from env_tradelab.bat)
rem   4  tradelab: the watch page for tonight and for every recorded day still without one (with the setups at the
rem      next open); opens tonight's page
rem Every step runs even when an earlier one failed: each works only on what production has already recorded, so a
rem failed or partial Run Now gives at worst nothing new - never a wrong card or page. RESULT names each failed step.
rem Start it when you would press Run Now, never while another run is going. If Run Now asks for a key at its end,
rem press it once and the rest carries on.
rem Nothing in bigmove_deploy is changed; tradelab writes only under TRADELAB_OUT, setuplab only under SETUPLAB_OUT.
rem Task Scheduler (no clicks): program run_tonight.bat, argument  auto  - no pause, no browser, and Run Now gets no
rem keyboard, so a prompt inside it fails at once instead of waiting all night.
rem Every run adds one line to TRADELAB_OUT\tonight_log.txt: when, and each step's exit code.
setlocal
set "BIGMOVE_DIR=C:\Users\karanvsi\PyCharmMiscProject\bigmove_deploy"
set "TN_RUN_NOW=%BIGMOVE_DIR%\run_now.bat"
set "TN_TL_DIR=%~dp0"
set "TN_AUTO="
if /i "%~1"=="auto" set "TN_AUTO=1"
set "TN_FAILED="
set "TN_RC1=skipped"
set "TN_RC2=skipped"
set "TN_RC3=skipped"
set "TN_RC4=skipped"
title tonight - Run Now, pick_meta, setups, tradelab

rem where tradelab writes - read from env_tradelab.bat in a scope of its own, so Run Now starts in a clean environment
setlocal
call "%TN_TL_DIR%env_tradelab.bat" >nul
endlocal & set "TN_OUT=%TRADELAB_OUT%"
if "%TN_OUT%"=="" set "TN_OUT=C:\QuantData\tradelab"
if not exist "%TN_OUT%" mkdir "%TN_OUT%"

echo.
echo   ==== STEP 1 of 4: Run Now - started %DATE% %TIME% ====
if exist "%TN_RUN_NOW%" goto :run_now
echo   NOT FOUND: %TN_RUN_NOW%
echo   Edit TN_RUN_NOW at the top of run_tonight.bat: the file you double-click as Run Now.
set "TN_RC1=9"
goto :step2
:run_now
for %%I in ("%TN_RUN_NOW%") do set "TN_RUN_NOW_DIR=%%~dpI"
pushd "%TN_RUN_NOW_DIR%"
if defined TN_AUTO goto :run_now_auto
cmd /c ""%TN_RUN_NOW%""
set "TN_RC1=%ERRORLEVEL%"
popd
goto :step2
:run_now_auto
cmd /c ""%TN_RUN_NOW%"" <nul
set "TN_RC1=%ERRORLEVEL%"
popd

:step2
if not "%TN_RC1%"=="0" set "TN_FAILED=%TN_FAILED% [step 1 Run Now: code %TN_RC1%]"
echo.
echo   ==== STEP 2 of 4: pick_meta - publish the cards, score the tracker - %TIME% ====
setlocal
call "%BIGMOVE_DIR%\env_daily.bat"
if "%CACHE_DAILY_ROOT%"=="" goto :pm_noenv
pushd "%BIGMOVE_DIR%\open_close"
set "PYTHONPATH=%BIGMOVE_DIR%"
python pick_meta.py publish --root "%CACHE_DAILY_ROOT%" --all-missing
set "TN_R=%ERRORLEVEL%"
python pick_meta.py score --root "%CACHE_DAILY_ROOT%"
if "%TN_R%"=="0" set "TN_R=%ERRORLEVEL%"
popd
goto :pm_done
:pm_noenv
echo   CACHE_DAILY_ROOT is empty after env_daily.bat - pick_meta skipped
set "TN_R=9"
:pm_done
endlocal & set "TN_RC2=%TN_R%"
if not "%TN_RC2%"=="0" set "TN_FAILED=%TN_FAILED% [step 2 pick_meta: code %TN_RC2%]"

echo.
echo   ==== STEP 3 of 4: setuplab - the frozen setups' scan of the last five days' picks - %TIME% ====
setlocal
call "%TN_TL_DIR%env_tradelab.bat"
if "%CACHE_DAILY_ROOT%"=="" goto :su_noenv
if not exist "%SETUPLAB_DIR%\setuplab.py" goto :su_nofile
pushd "%SETUPLAB_DIR%"
python setuplab.py scan --root "%CACHE_DAILY_ROOT%" --out "%SETUPLAB_OUT%" --all-missing
set "TN_R=%ERRORLEVEL%"
popd
goto :su_done
:su_noenv
echo   CACHE_DAILY_ROOT is empty after env_tradelab.bat - the setup scan skipped
set "TN_R=9"
goto :su_done
:su_nofile
echo   NOT FOUND: %SETUPLAB_DIR%\setuplab.py - edit SETUPLAB_DIR at the top of env_tradelab.bat
set "TN_R=9"
:su_done
endlocal & set "TN_RC3=%TN_R%"
if not "%TN_RC3%"=="0" set "TN_FAILED=%TN_FAILED% [step 3 setup scan: code %TN_RC3%]"

echo.
echo   ==== STEP 4 of 4: tradelab - the watch page - %TIME% ====
setlocal
call "%TN_TL_DIR%env_tradelab.bat"
if "%CACHE_DAILY_ROOT%"=="" goto :tl_noenv
pushd "%TN_TL_DIR%"
python tl_watch.py --root "%CACHE_DAILY_ROOT%" --all-missing
set "TN_R=%ERRORLEVEL%"
popd
goto :tl_done
:tl_noenv
echo   CACHE_DAILY_ROOT is empty after env_tradelab.bat - the watch page skipped
set "TN_R=9"
:tl_done
endlocal & set "TN_RC4=%TN_R%"
if not "%TN_RC4%"=="0" set "TN_FAILED=%TN_FAILED% [step 4 tl_watch: code %TN_RC4%]"
if not defined TN_AUTO if "%TN_RC4%"=="0" call :open_latest

echo.
if defined TN_FAILED goto :result_failed
echo   RESULT: OK - Run Now, pick_meta's cards, the setup scan and the watch page are done
echo   Pages: %TN_OUT%\watch
set "TN_RC=0"
goto :result_log
:result_failed
echo   RESULT: FAILED at%TN_FAILED%
echo   Read that step's own lines above. The steps after it still ran on what production had already recorded.
set "TN_RC=1"
:result_log
>>"%TN_OUT%\tonight_log.txt" echo %DATE% %TIME%  run_now=%TN_RC1%  pick_meta=%TN_RC2%  setup_scan=%TN_RC3%  tl_watch=%TN_RC4%%TN_FAILED%
if not defined TN_AUTO pause
endlocal & exit /b %TN_RC%

:open_latest
for /f "delims=" %%F in ('dir /b /o-n "%TN_OUT%\watch\WATCH_*.html" 2^>nul') do (
    start "" "%TN_OUT%\watch\%%F"
    goto :eof
)
goto :eof
