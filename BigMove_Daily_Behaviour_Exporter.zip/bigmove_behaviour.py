"""BigMove: every selection, every daily move, fixed ten panel features.
Read-only input. pip install pandas numpy pyarrow
"""
from pathlib import Path
import argparse, json, itertools, hashlib, zipfile, html, sys
from datetime import datetime
import numpy as np
import pandas as pd
import pyarrow.parquet as pq

FEATURES = ['D_ema20_angle_deg','D_donch_pos_50_rmean50','D_bb_bw_20','W_ret_13w','D_cmf20_rmean50','D_WQ_44','D_mdi14_diff1','D_WQ_33','D_rsi14_obv_x','D_WQ_12']
ROOT = Path(__file__).resolve().parent

def dates(s):
    t=pd.to_datetime(s,errors='raise')
    if t.dt.tz is not None: t=t.dt.tz_convert('Asia/Kolkata').dt.tz_localize(None)
    return t.dt.normalize()

def direction(s):
    return pd.Series(np.select([s>0,s<0,s==0],['rising','falling','unchanged'],default='missing'),index=s.index)

def schedule(trades, calendar):
    calendar=pd.DatetimeIndex(sorted(set(calendar)))
    rows=[]
    for r in trades.to_dict('records'):
        sig=pd.Timestamp(r['signal_day']); ent=pd.Timestamp(r['entry_day'])
        if sig not in calendar or ent not in calendar: raise ValueError('Missing session in calendar: '+r['trade_id'])
        i=calendar.get_loc(sig); j=calendar.get_loc(ent)
        if j!=i+1: raise ValueError('Entry must be next exchange session: '+r['trade_id'])
        if j+4>=len(calendar): raise ValueError('Calendar needs T-2 through D5: '+r['trade_id'])
        for day in range(-2,6):
            if i+day<0: continue  # Do not invent pre-history sessions.
            dt=calendar[i+day]
            rows.append({'trade_id':r['trade_id'],'symbol':r['symbol'],'day':day,'date':dt})
    return pd.DataFrame(rows)

def load_panel(path, wanted, mapping, batch_size):
    pf=pq.ParquetFile(path)
    names=pf.schema_arrow.names
    lower={c.lower():c for c in names}
    def resolve(key, candidates):
        if key in mapping:
            if mapping[key] not in names: raise ValueError('Mapped column absent: '+mapping[key])
            return mapping[key]
        for c in candidates:
            if c.lower() in lower:return lower[c.lower()]
        return None
    sym=resolve('symbol',['symbol','ticker','tradingsymbol'])
    date=resolve('date',['timestamp','date','datetime','trading_date'])
    if not sym or not date:raise ValueError('Cannot identify symbol/date. Use --mapping JSON. Available: '+str(names))
    fm={f:resolve(f,[f]) for f in FEATURES}
    missing=[f for f,c in fm.items() if c is None]
    if missing:raise ValueError('Missing exact features: '+str(missing)+' . No substitute indicators will be used. Use --mapping only for verified equivalent columns.')
    cols=list(dict.fromkeys([sym,date,*fm.values()]))
    keys=pd.MultiIndex.from_frame(wanted[['symbol','date']].drop_duplicates())
    symbols=set(wanted.symbol);lo=wanted.date.min();hi=wanted.date.max();parts=[];scanned=0
    for n,b in enumerate(pf.iter_batches(batch_size=batch_size,columns=cols),1):
        d=b.to_pandas();scanned+=len(d)
        d['__sym']=d[sym].astype(str).str.strip().str.upper()
        d=d[d['__sym'].isin(symbols)].copy()
        if len(d):
            d['__date']=dates(d[date]);d=d[d['__date'].between(lo,hi)]
            ix=pd.MultiIndex.from_arrays([d['__sym'],d['__date']])
            d=d[ix.isin(keys)]
            if len(d):
                z=pd.DataFrame({'symbol':d['__sym'],'date':d['__date']})
                for f,c in fm.items():z[f]=pd.to_numeric(d[c],errors='raise').replace([np.inf,-np.inf],np.nan)
                parts.append(z)
        if n%10==0: print(f'Scanned {scanned:,} rows; retained {sum(map(len,parts)):,}',flush=True)
    if not parts:raise ValueError('No panel rows matched. Check dates and symbol naming.')
    result=pd.concat(parts,ignore_index=True)
    if result.duplicated(['symbol','date']).any():raise ValueError('Duplicate panel symbol/date keys. Resolve source duplicates; no arbitrary deduplication.')
    return result, {'scanned_rows':scanned,'matched_unique_rows':len(result),'column_mapping':fm,'symbol_column':sym,'date_column':date}

def journal(trades, sched, panel):
    base=sched.merge(panel,on=['symbol','date'],how='left',validate='many_to_one',indicator=True)
    base['panel_row_present']=base.pop('_merge').eq('both')
    base=base.sort_values(['trade_id','day'])
    long=base.melt(id_vars=['trade_id','symbol','day','date','panel_row_present'],value_vars=FEATURES,var_name='feature',value_name='value')
    long=long.sort_values(['trade_id','feature','day']);g=long.groupby(['trade_id','feature'],sort=False)
    long['previous_value']=g.value.shift(1)
    long['change']=long.value-long.previous_value
    long['previous_change']=g['change'].shift(1)
    long['acceleration']=long.change-long.previous_change
    anchor=long[long.day==0].set_index(['trade_id','feature']).value
    long['change_from_signal']=long.value-pd.MultiIndex.from_frame(long[['trade_id','feature']]).map(anchor)
    long['direction']=direction(long.change)
    events=[]
    for r in trades.to_dict('records'):
        for k in range(1,6):
            c=1+r[f'close_ret_s{k}'];prev=(1+r[f'close_ret_s{k-1}']) if k>1 else r['signal_close']/r['entry']
            o=(1+r[f'open_ret_s{k}']) if k>1 else 1.
            valid=all(np.isfinite(v) and v>0 for v in [c,prev,o])
            row={x:r[x] for x in ['trade_id','symbol','engine','rank','signal_day','status','pre_state','pre_environment']}
            row.update(day=k,year=pd.Timestamp(r['signal_day']).year,gap_return=o/prev-1 if valid else np.nan,open_close_return=c/o-1 if valid else np.nan,close_close_return=c/prev-1 if valid else np.nan)
            events.append(row)
    e=pd.DataFrame(events).merge(sched[sched.day>0][['trade_id','day','date']],on=['trade_id','day'],validate='one_to_one')
    # D1 close-to-close includes signal-close -> entry gap, consistently with D2-D5.
    pre=long[long.day.between(0,4)].copy();pre.day+=1
    pre=pre[['trade_id','day','feature','value','change','acceleration','direction']].rename(columns={c:'pre_'+c for c in ['value','change','acceleration','direction']})
    post=long[long.day>0].merge(pre,on=['trade_id','day','feature'],validate='one_to_one').merge(e.drop(columns=['symbol','date']),on=['trade_id','day'],validate='many_to_one')
    return e, long[long.day>=0], post, base

def summaries(events, observations, min_count):
    records=[]
    scopes=[[],['year'],['pre_state'],['day'],['year','pre_state'],['pre_state','day'],['year','pre_state','day']]
    returns=['open_close_return','close_close_return']
    # Every pattern is compared with the same feature-availability cohort.
    # Baselines are matched on state, signal year and holding day within each scope.
    def aggregate(frame, pattern, timing, identity):
        for ret in returns:
            z=frame[frame[ret].notna() & frame[pattern].notna()].copy()
            if z.empty:continue
            z['positive']=z[ret]>0;z['negative']=z[ret]<0;z['flat']=z[ret]==0
            cell=['year','pre_state','day']
            z['baseline_positive']=z.groupby(cell,dropna=False).positive.transform('mean')
            z['baseline_return']=z.groupby(cell,dropna=False)[ret].transform('mean')
            for scope in scopes:
                keys=scope+[pattern]
                for key,b in z.groupby(keys,dropna=False,sort=False):
                    key=key if isinstance(key,tuple) else (key,)
                    out=dict(zip(keys,key));out['pattern']=out.pop(pattern)
                    out.update(scope='+'.join(scope) or 'all',timing=timing,features=identity,return_basis=ret,n=len(b),unique_trades=b.trade_id.nunique(),unique_signal_dates=b.signal_day.nunique(),positive_rate=b.positive.mean(),negative_rate=b.negative.mean(),flat_rate=b.flat.mean(),mean_return=b[ret].mean(),median_return=b[ret].median(),p10_return=b[ret].quantile(.1),p90_return=b[ret].quantile(.9),matched_baseline_positive_rate=b.baseline_positive.mean(),positive_lift_pp=100*(b.positive.mean()-b.baseline_positive.mean()),matched_baseline_return=b.baseline_return.mean(),mean_return_lift=b[ret].mean()-b.baseline_return.mean(),small_sample=len(b)<min_count)
                    records.append(out)
    for f,b in observations.groupby('feature',sort=False):
        print('Summarising '+f,flush=True)
        for timing,col in [('before','pre_direction'),('during','direction')]:
            b=b.copy();b['pattern']=b[col].replace('missing',np.nan)
            aggregate(b,'pattern',timing,f)
        b=b.copy();a=direction(b.pre_acceleration);b['pattern']=b.pre_direction+' | acceleration '+a
        b.loc[(b.pre_direction=='missing')|(a=='missing'),'pattern']=np.nan
        aggregate(b,'pattern','before_sequence',f)
    for timing,col in [('before','pre_direction'),('during','direction')]:
        wide=observations.pivot(index=['trade_id','day'],columns='feature',values=col).reset_index().merge(events,on=['trade_id','day'],validate='one_to_one')
        for a,b in itertools.combinations(FEATURES,2):
            w=wide.copy();w['pattern']=w[a]+' | '+w[b];w.loc[(w[a]=='missing')|(w[b]=='missing'),'pattern']=np.nan
            aggregate(w,'pattern',timing,a+' + '+b)
    return pd.DataFrame(records)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--panel',default=r'C:\QuantData\cache_daily\panel\panel.parquet')
    ap.add_argument('--trades',default=str(ROOT/'master_selections.csv'))
    ap.add_argument('--calendar',default=str(ROOT/'sessions.csv'))
    ap.add_argument('--mapping',help='JSON canonical feature/symbol/date -> actual panel column')
    ap.add_argument('--out',default=str(ROOT/'outputs'))
    ap.add_argument('--batch-size',type=int,default=100000)
    ap.add_argument('--min-count',type=int,default=50)
    ap.add_argument('--skip-summaries',action='store_true',help='Extract journal only')
    args=ap.parse_args()
    run=Path(args.out)/datetime.now().strftime('behaviour_%Y%m%d_%H%M%S_%f');run.mkdir(parents=True,exist_ok=False)
    t=pd.read_csv(args.trades);t['signal_day']=dates(t.signal_day);t['entry_day']=dates(t.entry_day);t.symbol=t.symbol.str.strip().str.upper();t.pre_state=t.pre_state.fillna('UNKNOWN');t.pre_environment=t.pre_environment.fillna('UNKNOWN')
    if t.trade_id.duplicated().any():raise ValueError('Duplicate trade_id')
    cal=dates(pd.read_csv(args.calendar)['date']);sched=schedule(t,cal)
    mapping=json.loads(Path(args.mapping).read_text()) if args.mapping else {}
    panel,meta=load_panel(args.panel,sched,mapping,args.batch_size)
    e,long,obs,base=journal(t,sched,panel)
    e.to_csv(run/'daily_outcomes.csv',index=False)
    long.to_csv(run/'feature_journey_D0_D5.csv.gz',index=False,compression='gzip')
    obs.to_csv(run/'daily_behaviour_journal.csv.gz',index=False,compression='gzip')
    panel.to_parquet(run/'required_panel_extract.parquet',index=False)
    base[~base.panel_row_present].to_csv(run/'missing_panel_rows.csv',index=False)
    coverage=obs.groupby('feature').agg(total_days=('value','size'),current_values=('value','count'),previous_values=('pre_value','count'),prior_changes=('pre_change','count'),prior_accelerations=('pre_acceleration','count'))
    coverage.to_csv(run/'coverage.csv')
    if not args.skip_summaries:
        s=summaries(e,obs,args.min_count);s.to_csv(run/'pattern_summary.csv.gz',index=False,compression='gzip')
    else:s=pd.DataFrame()
    meta.update(arguments=vars(args),trades=len(t),trade_days=len(e),features=FEATURES,missing_panel_rows=int((~base.panel_row_present).sum()),master_sha256=hashlib.sha256(Path(args.trades).read_bytes()).hexdigest(),panel_size_bytes=Path(args.panel).stat().st_size,panel_mtime=Path(args.panel).stat().st_mtime,status='descriptive_only',notes=['Year is signal year; pre_state is frozen signal context, not recomputed daily state.','Rates are fractions; lift_pp is percentage points. Flat means exactly zero.','No final trade P&L filtering. All return magnitudes included.','During-day features use that close and are descriptive, not advance signals.','All 45 pairs use directional combinations; continuous raw values retained for later analysis.','No significance or predictive validation claimed; overlapping picks are dependent.','No arbitrary raw-level thresholds or favorable-direction assumptions.'])
    (run/'manifest.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    table=coverage.to_html()
    if len(s):
        top=s[(s.scope=='all')&(s.timing=='before')&(~s.small_sample)&(s.return_basis=='open_close_return')].sort_values('positive_lift_pp',ascending=False).head(30)
        table+= '<h2>Exploratory prior-close patterns (not validated signals)</h2>'+top[['features','pattern','n','positive_rate','matched_baseline_positive_rate','positive_lift_pp','mean_return']].to_html(index=False)
    page='<html><meta charset="utf-8"><style>body{font:15px system-ui;margin:36px;color:#123}table{border-collapse:collapse}td,th{padding:8px;border:1px solid #ccd}th{background:#e9f2fa}</style><h1>BigMove daily behaviour journal</h1><p>'+f'{len(t):,} selections · {len(e):,} trade-days · ten features · 45 pairs'+'</p><p>Every daily return included. Before = information at prior close. During = response observed at current close. Missing values are excluded only from affected pattern denominators; inspect coverage. Baselines matched by signal state, year and holding day. Patterns are descriptive, with no multiple-testing-adjusted predictive claims.</p>'+table+'</html>'
    (run/'report.html').write_text(page,encoding='utf-8')
    bundle=run/'UPLOAD_RESULTS.zip'
    with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
        for p in run.iterdir():
            if p!=bundle and p.is_file():z.write(p,p.name)
    print('\nCOMPLETE. Open '+str(run/'report.html')+'\nUpload '+str(bundle),flush=True)

if __name__=='__main__':
    try:main()
    except Exception as exc:
        print('FAILED: '+str(exc),file=sys.stderr);sys.exit(1)
