# BigMove daily behaviour exporter

## Run on Windows
1. Extract this entire ZIP to a new research folder. Keep all bundled files together.
2. In a terminal in that folder run `python -m pip install -r requirements.txt`.
3. Double-click RUN.bat, or run:

```
python bigmove_behaviour.py --panel "C:\QuantData\cache_daily\panel\panel.parquet"
```

If your frozen research panel is at `C:\QuantData\cache_daily\panel_oc\panel.parquet`, pass that path instead. RUN.bat checks panel first, then panel_oc if the first file does not exist. Choose the panel matching your frozen model; the script does not certify feature provenance merely from column names.

No model rerun, broker connection or internet is required after dependency installation. Inputs are read-only. Each run creates a separate timestamped output folder. Upload its **UPLOAD_RESULTS.zip** here. Open report.html locally for a readable overview.

## Included data
The 4,965 Engine D rank 1–3 master selections and the archived exchange-session calendar are bundled. Includes the trade marked stuck: its daily price journey is still observable. The calendar begins at the archive boundary, so unavailable prior sessions for the earliest trades produce missing changes/accelerations; no dates are invented. Signal dates span January 2020–September 2026.

## Outputs
- daily_outcomes.csv: all 24,825 trade-days; opening gap, open-to-close and close-to-close returns, selection state and market context. Returns are decimal fractions, so 0.01 = 1%.
- feature_journey_D0_D5.csv.gz: all ten feature readings, changes, acceleration, and change from signal, through the five-day journey.
- daily_behaviour_journal.csv.gz: one row per trade-day-feature; prior-close readings/changes alongside current-close readings and that day's outcomes. Expected 248,250 rows.
- pattern_summary.csv.gz: individual feature directions, direction-plus-acceleration sequences and all 45 pairs of feature directions, separately before/during moves. Overall, year, state, holding-day and combined breakdowns.
- required_panel_extract.parquet: only the relevant stock-date rows and ten feature columns, including available T-2/T-1 history.
- coverage.csv and missing_panel_rows.csv: missing data is visible, never silently filled.
- manifest.json: parameters, column mapping, counts, input master checksum and interpretation notes.
- report.html: compact coverage and exploratory pattern overview.

Rates are fractions, positive_lift_pp is percentage points. A positive day means return >0; negative <0; flat exactly zero. No 5% threshold, winner filter, final-P&L conditioning, or outcome-selected sample.

## Correct interpretation
Before-day patterns are known at the previous close. During-day changes include the current close and can be mechanical reactions to price; do not treat them as entry signals. Positive-rate baselines use the same feature-availability population, weighted to match each pattern's state × signal-year × holding-day distribution. Both return bases are reported independently; D1 close-to-close includes the signal-close to D1-open gap, unlike earlier reports that mixed D1 open-to-close with later close-to-close.

State/market labels are the recorded **signal context**, not freshly computed daily states. The ten features are copied from the panel without guessing formulas, signs or equivalents. No return positivity is assumed for a rising indicator. Numerical levels and interactions are retained in the journal; automated summaries use transparent directions, not an exhaustive search over every possible continuous threshold, product or higher-order combination.

These are descriptive associations. Overlapping trades are dependent; the program does not assert statistical significance, causation or a profitable strategy. Year breakdowns are not held-out validation. Independent-date counts and small-sample flags help interpretation but are not confidence intervals. Future predictive validation must freeze definitions and use time-separated, overlap-aware testing.

## Troubleshooting / options
- Missing feature columns: the script fails rather than substitute other indicators. Use `--mapping mapping.json` only for known equivalent names, e.g. `{"date":"timestamp","D_WQ_44":"verified_equivalent_column"}`. Unlisted names remain canonical.
- Missing panel rows or values: extraction still finishes and reports gaps. Coverage must be reviewed before interpreting patterns.
- Duplicate stock/date keys or duplicate trade IDs: fails explicitly.
- `--batch-size 50000` reduces scan batch memory. Only the required eleven/twelve fields are read; the full panel is never loaded into RAM. Retained rows and summaries are held in memory.
- `--skip-summaries` produces the complete journal/extract first if you only need data to share.
- `--trades FILE --calendar FILE` can replace the bundled cohort/calendar with the same schemas. Calendar must contain actual exchange sessions, not business-day approximations.
- Interrupted runs can be rerun; each run is isolated. No resume claim: an interrupted scan restarts. Only a completed run prints COMPLETE and produces UPLOAD_RESULTS.zip.

## Verification
Tested locally using synthetic feature-panel data aligned with eight real selection schedules: return decomposition, prior-close timing, row counts, streaming schema resolution and full report/summary/archive generation. All 4,965 selection schedules were checked against the bundled calendar. Your actual panel has not been executed here; its coverage and values will be verified from the output.
