@echo off
cd /d "%~dp0"
set "PANEL=C:\QuantData\cache_daily\panel\panel.parquet"
if not exist "%PANEL%" set "PANEL=C:\QuantData\cache_daily\panel_oc\panel.parquet"
python bigmove_behaviour.py --panel "%PANEL%"
pause
