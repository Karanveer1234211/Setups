# tradelab v1.3.1 — the whole evening in one double-click; tonight's watchlist with the market and every stock's state; every pick, trade by trade; a backtester and a trade simulator

tradelab sits **next to** `bigmove\_deploy` (not inside it). It reads production data read-only — the cache, pick\_meta's research run, `panel\_oc`, the 3-minute bars, and stage E's lower-circuit rule — and writes only under `C:\\QuantData\\tradelab`. Nothing in production changes. D and ENS predictions are read as recorded (hash-checked) and the plan is recomputed and must match them.

## Setups add-on v1.0 (8 Nov 2026): the seven frozen setups in every tool

tradelab stays **v1.3.1** (v2engine and pathlab check that version); the add-on adds `tl_setups.py` and changes the watch page, the backtester, the simulator, the journal, the dictionary, `tl_check.py`, `run_tonight.bat` and `env_tradelab.bat`. **Nothing in tradelab computes a setup**: setuplab v0.7 does (one source of truth), and tradelab only reads its files, hash-checked, from `SETUPLAB_OUT` (`env_tradelab.bat` sets `C:\QuantData\setuplab`) or `--setups <folder>`. Neither = no setup columns (said once, never guessed).

|where|what you get|
|-|-|
|`run_tonight.bat`|**a new step 3 of 4**: `setuplab.py scan --all-missing` — the paper ledger's D and ENS ranks 1–10 of the last five sessions against the 7 frozen setups (S1 S2 S3 C1 C2 C3 N1). The watch page is now step 4 and runs even if the scan fails; the log line adds `setup_scan=`|
|watch page|a column **setups at the next open** on tonight's picks (`C3 buy at the open`, `S2 buy at the open only if open below 123.45`) and a section **Frozen setups at the next open** with every FIRES / ARMED / ENTERED row of the last five sessions' picks, the scan file's SHA and whether it was ON TIME|
|`tl_backtest.py`|every pick in `trades.csv` carries `setups` (e.g. `S2@D3 C1@D3` = S2 and C1 entered on watch day 3), `n_setups`, `su_<ID>_day`, `setups_tagged`; the report says where the tags came from|
|a setup as a strategy|an entry leg `{"name": "s2", "size": 1.0, "setup": "S2"}` buys the open of S2's own entry day (D1–D5), as setuplab's tags record it; a pick where S2 never entered is not traded. Exit at the pick's 5th close (`"session": 5`) or `{"name": "fresh", "type": "time", "hold": 5}` = the close 4 sessions after the entry (N1's primary exit; needs `"max_sessions": 9`). Example: `strategies\setup_s2_d5.py`|
|`tl_sim.py`|the story names the pick's frozen setups and the day each entered|
|`tl_journal.py`|a **FROZEN SETUPS** band: which setups entered each pick and each setup's net % at its primary exit|

**The one guard.** A setup is known only on its OWN entry day (its conditions are read at the close before it, S2's gap at that day's open). So a filter, event, sizing or exit rule that names `setups`, `n_setups` or any `su_*` is **refused** — it would look at sessions after the pick. To trade a setup, use the entry leg above.

**How to read a setup backtest.** *On the picks the strategy actually traded* is your frame: the setup's own trades against the plan's D1-open entry on the same picks. The per-pick-slot line counts every pick the setup never entered as 0 (cash) — that is the money question, not the same-trade one. Tags on 2020–2026 are the years the setups were chosen on: they describe, they never select, and they are not new evidence. Only setuplab's scan ledger (ON TIME records) is forward evidence, judged at month 12 (entries through 2027-09-30).

```
call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --strategy strategies\setup_s2_d5.py
python tl_journal.py --export TLX_20261025_001
```

|command|what it gives you|
|-|-|
|`run\_tonight.bat` (v1.3.1)|**every night, one double-click:** Run Now, then pick\_meta's cards, then the watch page below (and a page for any recorded day still without one); opens tonight's page|
|`run\_watch.bat` / `tl\_watch.py` (v1.3)|the paper test's D and ENS top 10 on one page — the market at the close (environment, high stress, breadth, VIX, NIFTY vs Midcap / Smallcap), each stock's size and the index it moves with, its **state** (primary state, event, risk flags, confidence, how long, what it was before), pick\_meta's numbers and the Soul card|
|`tl\_state.py` (v1.3)|the stock-state engine: `show` one stock's state on any day with the evidence and its last sessions · `rules` writes `STATE\_RULES.md`|
|`tl\_check.py`|a 30-second preflight: what tradelab sees on your PC (now also the index files, breadth stock count and AMFI lists), and the plan reproduced on 300 random picks|
|`tl\_export.py`|every pick D and ENS made (ranks 1–10, 2020–2026) with its outcomes, day by day for sessions 0–5, **the market before and during each trade**, the research report, trade cards, a data dictionary|
|`tl\_backtest.py`|any strategy on the picks, compared with the plan on the same picks (95% intervals), a money view — and in v1.1 the comparison and the money **by market environment**, and a before / after split date; v1.3.1: **by the stock's state at the pick** too|
|`tl\_sim.py`|one trade (or a few) replayed bar by bar: a written story (the market around the trade; v1.3.1: the stock's state at the pick and on every day held), every bar's values, a chart (with NIFTY / Midcap / Smallcap beside the stock)|
|`tl\_context.py` (v1.1)|`check` the market inputs · `build` the daily breadth once · `diary` one plain-English line per session|
|`tl\_research.py` (v1.1)|re-run the research report on an export: winners vs losers vs severe losers, warning signs, walk-forward|
|`tl\_cards.py` (v1.1)|trade cards for any selection (worst 20, a symbol, a day…) and the market diary for any dates|

## Install (once)

1. Copy the `tradelab` folder to `C:\\Users\\karanvsi\\PyCharmMiscProject\\tradelab` (beside `bigmove\_deploy`, not inside it). For v1.1, replace the whole v1 folder (your outputs in `C:\\QuantData\\tradelab` are not touched).
2. Open `cmd`:

```
   call C:\\Users\\karanvsi\\PyCharmMiscProject\\tradelab\\env\_tradelab.bat
   pip install pypdf pdfplumber openpyxl reportlab
   python tests\\test\_tradelab.py
   ```

   It must end with `VERIFIED (tradelab v1.3.1 + setups add-on v1.0)` (about 10–16 minutes). The test uses synthetic data only — on Windows it also runs a copy of `run\_tonight.bat` for real, pointed at stand-in folders inside the test's temporary folder (never at bigmove\_deploy). `pypdf` / `openpyxl` read AMFI's lists; `pdfplumber` and `reportlab` are needed by the tests.

3. AMFI size lists (once, then one new file each January and July): see **Size class** below.
4. Preflight on your real data (reads only, about 30 seconds):

```
   python tl\_check.py --root %CACHE\_DAILY\_ROOT% --pm-run PM\_20261017\_001
   ```

   It must end with `CHECK OK`. Warnings (a missing index file, a refused AMFI list) do not stop it — they say which columns will stay blank. If it prints `CHECK FAILED`, send me the whole output.

`env\_tradelab.bat` runs your `env\_daily.bat` (sets `CACHE\_DAILY\_ROOT`), puts `tradelab`, then `bigmove\_deploy\\open\_close`, then `bigmove\_deploy` on `PYTHONPATH`, and sets `TRADELAB\_OUT=C:\\QuantData\\tradelab`. Every command needs `--root %CACHE\_DAILY\_ROOT%` (no silent default path) and, except `tl\_context.py`, `tl\_cards.py` and `tl\_research.py`, `--pm-run PM\_20261017\_001`.

## 0\. Every night: one double-click (v1.3.1)

Double-click **`run\_tonight.bat`** in the tradelab folder when you would press Run Now. It does the whole evening in one window:

1. **Run Now** — `bigmove\_deploy\\run\_now.bat`, unchanged, started from its own folder exactly as when you double-click it (in a child cmd, so nothing inside it can end the rest). If Run Now asks for a key at its end, press it once; the rest carries on.
2. **pick\_meta** — `publish --all-missing` (tonight's cards, plus any recorded day still without a card — such a card is marked LATE by pick\_meta, as before) and `score`: the commands of `open\_close\\run\_pick\_meta.bat`, in its environment.
3. **The setup scan** (setups add-on, 8 Nov) — `setuplab.py scan --all-missing` from `SETUPLAB_DIR`, writing to `SETUPLAB_OUT`: what the frozen setups buy at the next open (`C:\QuantData\setuplab\scan\SCAN_<date>.md`, a TradingView import file `tv_<date>.txt`).
4. **The watch page** — `tl\_watch.py --all-missing`: tonight's page, plus a page for every recorded day still without one; then it opens tonight's page.

**Every step runs even when an earlier one failed** — each works only on what production has already recorded, so after a failed or partial Run Now you get at worst nothing new, never a wrong card or page. The last line says `RESULT: OK`, or `RESULT: FAILED at \[step 1 Run Now: code 1]` (each failed step with its code). Each run adds a line to `C:\\QuantData\\tradelab\\tonight\_log.txt` (when, and each step's exit code). Nothing in bigmove\_deploy changes.

**The first time** it also builds a page for every paper day since 30 Sep: each stock's state and the market as they were at that day's close (point in time — nothing after it is used), with that day's pick\_meta card and Soul cards, each page marked **LATE** (built after its time — not forward evidence). `C:\\QuantData\\tradelab\\watch\\watch\_all.csv` collects every page's rows in one table (one row per pick and day, with when its page was written and whether it was LATE).

**Without any click (optional):** Windows Task Scheduler can run it with the argument `auto` — no pause, no browser, and Run Now gets no keyboard, so a prompt inside it (a Kite login, say) fails at once instead of waiting all night; steps 2 and 3 still run and the log shows what happened. Only if Run Now runs unattended on your PC:

```
schtasks /Create /TN "tradelab\_tonight" /TR "C:\\Users\\karanvsi\\PyCharmMiscProject\\tradelab\\run\_tonight.bat auto" /SC WEEKLY /D MON,TUE,WED,THU,FRI /ST 20:45
```

(pick the time you usually press Run Now; do not keep a second task that runs daily\_run.bat at the same time.)

By hand, the page alone:

```
call C:\\Users\\karanvsi\\PyCharmMiscProject\\tradelab\\env\_tradelab.bat
python tl\_watch.py --root %CACHE\_DAILY\_ROOT% --all-missing                    (tonight + any day without a page)
python tl\_watch.py --root %CACHE\_DAILY\_ROOT% --date 2026-10-23 --force        (rebuild one day)
```

`run\_watch.bat` still does the page alone (it passes its arguments on, e.g. `run\_watch.bat --date 2026-10-23 --force`).

### What the page reads and writes (v1.3)

It **reads** `paper\\ledger.jsonl` (D's and ENS's top 10 as recorded), `research2\\pick\_meta\\forward\\PM\_cards\_YYYYMMDD.csv` (pick\_meta's numbers, when published), `paper\\watchlists\\WL\_YYYYMMDD.md` (the Soul cards, copied verbatim) and the daily bars. It **writes** only `C:\\QuantData\\tradelab\\watch\\WATCH\_YYYYMMDD.html` (the page), `.md` (text), `.csv` (every number, one row per pick; `DATA\_DICTIONARY.md` beside it), `watch\_YYYYMMDD.json` (settings, versions, the inputs' fingerprints) and a line in `watch\\index.jsonl`. A page written at or after 09:00 of the next weekday is marked **LATE** (not forward evidence). A day already written is skipped; `--force` rewrites it (both are in the index).

**How to read it — top to bottom:**

1. **The market banner** — the environment at the signal day's close in one word (BROAD BULLISH, NARROW BULLISH, MIXED, BROAD BEARISH, or HIGH STRESS with its direction), how many sessions it has lasted, the high-stress flag and why, NIFTY / Midcap / Smallcap (day, 20 days, above or below their 50-day averages), breadth today and over 10 days, VIX and its 5-day change, NIFTY minus Smallcap, and the last 10 sessions' labels. These are tl\_context's labels declared on 24 Oct.
2. **D's and ENS's top 10** — per stock: size (AMFI membership) and the index it moves with (b = beta: sensitivity, a different thing from membership); its **state** as a coloured chip (green bullish, blue reversal attempt, grey range, red bearish, purple unstable) with confidence, sessions in it and phase; under it the latest event (S04 breakout NEW / CONFIRMED, S11 failed breakout, S10 breakdown) and any risk flag (S05 overextended, large down candle, gaps, bearish divergence candidate); the stock's volatility; then pick\_meta's P(+5%), P(+10%), swing class, P(−8%), P(stuck) with its marks; relative strength over 20 days against its size index. Ranks 1–3 in bold are the paper test's trades.
3. **A card per stock** — the state with when it began and was confirmed, what it was before, support / conflicts / completeness, the invalidation (what would end it, with prices), the transitions, the evidence (every required, supporting and conflicting condition, ticked or not), the market around the stock (size, beta, moves vs its indices over 20 / 60 days), pick\_meta's numbers, the measurements (EMAs, slopes, efficiency, RSI, swings with the day each became known) and the Soul card.

**What it is not:** a filter. The paper test's picks, ranks and trades are unchanged; nothing re-ranks or skips a pick. States and labels are descriptive research defaults (see §7) until a declared test says otherwise. Expect a fair share of **UNKNOWN**: when the evidence conflicts the engine says so instead of forcing a label (the card names the two closest states and what each lacks). The page also lists which of tl\_research's declared warning signs (W1–W8) are on at that close — for information; none of them filters anything.

**Before the first night:** `python tl\_check.py --root %CACHE\_DAILY\_ROOT% --pm-run PM\_20261017\_001` prints a `tonight (v1.3.1)` block — the Run Now file `run\_tonight.bat` will start and its commands, and `run\_pick\_meta.bat`'s python lines next to what step 2 runs (it warns if Run Now's file is missing, if Run Now hands its work to another window with START — nothing could wait for it — or if `run\_pick\_meta.bat` runs something step 2 does not) — and a `watch (v1.3)` block: the paper ledger's latest day, whether pick\_meta's card and the paper watchlist exist, **how many Soul cards it found** (the page copies the section of the paper watchlist whose heading names the stock) and one stock's state. If it finds fewer Soul cards than stocks, send me that day's `paper\\watchlists\\WL\_YYYYMMDD.md` and I will fit the reader to its layout.

## 1\. Export every pick

```
python tl\_export.py --root %CACHE\_DAILY\_ROOT% --pm-run PM\_20261017\_001
```

Options: `--engines D ENS` · `--ranks 1-10` (default; `1-3` = the traded picks) · `--from 2020-01-01 --to 2026-09-30` · `--features all|none|D\_rsi14,D\_atr\_pct` · `--features-csv` · `--bars3 D-20240425-2,ENS-20250102-1` or `--bars3 traded` · `--no-benchmark` · v1.1: `--context full|saved|indices|none` (default `full`: indices + AMFI + breadth; `none` = exactly v1's files) · `--amfi-dir <folder>` · `--cards 5` (sample cards: best and worst 5 per engine; 0 = none).

**Safety stop.** The plan (buy the session-1 open, sell the session-5 close, a locked close sells at the first unlocked open within 20 sessions, 35 bp) is recomputed from the bars for every pick and must match pick\_meta's recorded status and net to 1e-9 for at least 99.5% of each engine's picks, with the mean net within 0.01 bp. Otherwise the run writes only `STOPPED.txt` and `reconcile\_mismatches.csv` — send me that CSV.

Files in `C:\\QuantData\\tradelab\\export\\TLX\_YYYYMMDD\_NNN\\` — **start with `report.md`, then `research\\research\_report.md`, then `cards\\cards\_sample.html`.**

|file|one row per|main columns|
|-|-|-|
|`trades`|pick|identity (trade\_id, engine, rank, traded, overlaps, repeat\_of), forecasts (prob\_*, pred\_*), the plan's outcome (entry, exit, exit\_kind, locked\_exit, net\_bp, win), path outcomes (mfe, mae and their sessions, `touch\_\*`, `close\_ret\_s1..s5`, `open\_ret\_s2..s6`), alternatives (`open6\_net\_bp`, `hold10\_net\_bp`), the record and `matches\_record`, buy-everything that day (`mkt\_net\_bp`) and `excess\_bp`; v1.1: every `pre\_\*` and `post\_\*` column (below), `outcome` (winner / loser / severe\_loser) and `story` (the trade in one sentence)|
|`trade\_days`|pick × session 0–5 (longer for a locked exit)|daily OHLCV, `ret\_\*\_vs\_entry`, `day\_ret`, `gap`, `range\_pct`, `clv`, `vol\_ratio20`, `atr\_ratio`, `rel\_nifty\_day`, `held\_at\_close`, `day\_pnl\_bp`, `cum\_pnl\_bp` (ends at net\_bp), `mfe\_sofar`, `mae\_sofar`, `after\_exit`; v1.1: Midcap / Smallcap day returns, VIX, breadth, environment and stress that session, the home index's day, `rel\_home\_day`, and each held day split into `mkt\_part\_day\_bp` + `stock\_part\_day\_bp` with a `market\_line` in words|
|`trade\_day\_features`|pick × session 0–5|every allowed panel feature at that session's close|
|`daily\_book`|engine × session|positions open, new, exits, the book's day P\&L (1/15 of capital per slot — a proxy) and its running total|
|`trade\_bars\_3m`|3-minute bar (chosen trades)|OHLCV, VWAP, cumulative volume, return vs entry and vs the previous close, session high / low so far|
|v1.1 `market\_days`|session|everything below for every session of the export's span, plus `summary` (the day in one sentence) and `missing`|
|v1.1 `market\_diary.md`|session|one plain-English line per session, by month|
|v1.1 `context\_breakdown.csv`|engine × market dimension × bucket|trades, mean net with its 95% interval, win rate, severe-loser rate, market part, stock part|
|v1.1 `research\\`|—|`research\_report.md` (verdict first), `outcome\_groups.csv`, `outcome\_profiles.csv`, `warning\_signs.csv`, `walk\_forward.csv`, `walk\_forward\_verdicts.csv`, `book\_by\_environment.csv`, `severe\_losers.md/.html` (a card for each of the worst trades), `research\_summary.json`|
|v1.1 `cards\\`|—|`cards\_sample.md/.html`: the best and worst trades told as a chain|
|v1.1 `DATA\_DICTIONARY.md`, `data\_dictionary.csv`|column|every column of every table: meaning, unit, and **when it is known** (at the pick / that day / after entry)|

## 2\. The market around every trade (v1.1)

The chain for each pick: **what the market did on the session before the pick → the pick (its rank) → what the market and the stock did on the signal day → what they did during the hold.** Everything is point in time: a value for day *d* uses bars up to *d*'s close and nothing later (tested by scrambling every later bar: no earlier value changes).

**Before entry vs after entry — the column names say which.**

* `pre\_\*` = known at the signal-day close, before the entry (the pick day's market, the previous session's market, the stock's size class, beta, correlation, home index). A rule, filter or sizing expression may use these.
* `post\_\*` = observed after the entry (the entry day's gap, the market over the hold, the market / stock split of the result). For understanding only: **a rule that names a `post\_\*` column is refused.**

**What is measured** (definitions declared 24 Oct 2026, before any real run — fixed in `tl\_context.py`, never tuned on results):

|category|values|how|
|-|-|-|
|market direction|NIFTY 50, NIFTY Midcap 150, NIFTY Smallcap 250: day return, gap, open-to-close, 5- and 20-day return, close vs its 50-day average, the day's move in standard deviations (of the previous 60 days)|the cache's `NIFTY50`, `NIFTYMIDCAP150`, `NIFTYSMLCAP250` daily files|
|divergence|NIFTY minus Midcap, NIFTY minus Smallcap, the day and 20 days (> 0 = NIFTY ahead = a narrow market)||
|breadth|advancers / (advancers + decliners), and its 10-day average|counted over **every stock in your cache** that traded that day (unchanged stocks left out); `ad\_n` = how many. Not NSE's official count: stocks delisted before the cache was built are missing (survivorship)|
|volatility|India VIX level, day change, 5-day % change, percentile within its last 250 sessions|the cache's `INDIAVIX` daily file|
|size class|large / mid / small, AMFI rank|AMFI's official half-yearly lists only (below)|
|sensitivity|beta and correlation of the stock to each of the three indices over the 120 sessions up to the pick (≥ 60 returns); home index = the one it correlates with most||
|environment|one readable label a day|below|

**Environment labels** (an index is *up* when it closes at or above its 50-day average; breadth = the 10-day average A/D):

|label|rule|
|-|-|
|Broad bullish|NIFTY, Midcap and Smallcap all up, and breadth ≥ 0.50|
|Narrow bullish|NIFTY up, but Midcap or Smallcap down, or breadth < 0.50|
|Broad bearish|all three down, and breadth < 0.50|
|Mixed / ranging|anything else|
|**High stress**|a **separate flag** that can sit on top of any of the above: VIX at or above the 90th percentile of its last 250 sessions, or VIX up 25%+ in 5 sessions, or a NIFTY or Smallcap day move of 2.5 standard deviations or more. `high\_stress` = 1 / 0 / blank (unknown); `stress\_reason` says which fired. The five-label `environment` = High stress when the flag is on, else the direction|

**Missing data is never filled.** A missing index file, a missing day or too little history leaves the value blank; `missing` names what was missing. The labels are blank when an input they need is blank. The stress flag is 1 if any condition fired; otherwise blank (not 0) when an input was missing.

**The split of each result.** Market part = the stock's beta to its home index × the home index's move over exactly the same hold; stock part = the rest (`post\_mkt\_part\_bp` + `post\_stock\_part\_bp` = gross). `post\_driver` says which dominated (market, stock, both, opposite, flat). The same split is done day by day in `trade\_days`. This answers "NIFTY was up 1% but my pick fell 2% — was it Smallcap?": the card shows the home index, its move, and the split.

**Size class (AMFI, point in time).** SEBI's large (ranks 1–100), mid (101–250) and small (251+) by AMFI's six-monthly average market cap list. Download the lists from AMFI's *Categorisation of Large, Mid and Small Cap Stocks* page — the **Excel (.xlsx)** files are the most reliable to read (PDF also works) — for every half-year from **Jan–Jun 2019** to **Jan–Jun 2026** (15 files), and put them, names unchanged, in

```
%CACHE\_DAILY\_ROOT%\\sectors\\amfi\\
```

Each list is used from **1 Feb / 1 Aug** — the 1st of the second month after its half-year. That is an assumed, conservative availability date, not AMFI's publication date (lists were reported on 5 Jan 2021 and by 9 Jul 2025; funds realign within a month). If you know the real dates, put them in `amfi\_published.csv` in the same folder (`file,published` with `YYYY-MM-DD`): that list is then used from the next day. A list stays in force **until the next half-year's list starts**. Before the first list, or for a half-year whose list is missing, the class is `no list` (blank) — an older list is never carried on; a stock the list does not name is `not in list`. A renamed stock (e.g. an old symbol in the 2023 list) is found by its company's ISIN; the class always comes from the list in force that day. Every list is checked when read (ranks 1–250 present, categories agree with the rank cut-offs, NSE symbols found) and **refused** otherwise — `tl\_check` shows each file's status, warns about a missing half-year, and says how many of your cached stocks the latest list covers. Add each new list when AMFI publishes it (next: Jul–Dec 2026, early January 2027).

**Breadth** is counted once and saved under `C:\\QuantData\\tradelab\\context\\` (the export does it; `python tl\_context.py build --root %CACHE\_DAILY\_ROOT%` refreshes it after a cache update). The backtester and simulator reuse the saved copy (`--context auto`); days after it are blank and they say so.

**The diary.** `python tl\_context.py diary --root %CACHE\_DAILY\_ROOT% --from 2024-06-01 --to 2024-06-30` prints and saves one line per session. The format (this line is from the synthetic test world, so its numbers are not real): *"Tue 07 Mar 2023: NIFTY -0.8%, Midcap -1.0%, Smallcap -1.3%; NIFTY minus Smallcap +0.5 pts (20-day -0.8 pts); breadth 0.18 (11 up / 50 down of 61; 10-day 0.42); VIX 19.4 (day +9.4%, 5-day -1.9%, 79th percentile); environment: Broad bearish."*

## 3\. Research: what goes with the worst losses (v1.1)

The question: **can we identify the market conditions associated with D/ENS's worst losses before entering those trades, and reduce drawdown without destroying the existing edge?** The export answers it with `research\\research\_report.md` (or re-run on an export: `python tl\_research.py --export C:\\QuantData\\tradelab\\export\\TLX\_...`). Everything here was declared on 24 Oct 2026, before any real run, and is logged in the ledger before the result.

* **Groups** (per engine, ranks 1–3 traded): winner (net > 0), loser (−500 < net ≤ 0), **severe loser (net ≤ −500 bp)** after the 35 bp cost. `outcome\_profiles.csv` compares the three groups on every `pre\_\*` value (what was known before entry) and on the `post\_\*` values (what happened during the hold).
* **Warning signs** — each is a condition known before entry, tested on winners **and** losers: how many flagged trades, how many severe losers caught, **how many winners it would also have skipped**, the P\&L change if flagged trades were skipped, the difference in mean net (flagged − unflagged) with a 95% interval, and the book's worst drawdown with and without them.

|id|warning sign (at the signal-day close)|
|-|-|
|W1|high stress|
|W2|broad bearish|
|W3|narrow bullish|
|W4|weak breadth: 10-day A/D below 0.40|
|W5|VIX up 15% or more in 5 days|
|W6|Smallcap fell 1.5% or more on the pick day|
|W7|NIFTY ahead of Smallcap by 3 pts or more over 20 days|
|W8|high-beta pick: beta to its home index 1.5 or more|
|ANY|any of the above|

* **Walk-forward (chronological, out of sample; v1.2 rules).** For each year, a sign *qualifies* only on trades that had **actually exited before 1 Jan of that year** (purged), comparing flagged vs **known** unflagged trades (a blank input is left out and never flags), with ≥ 30 flagged trades on ≥ 20 days and a one-sided bootstrap **p ≤ 0.05 / 8** (Bonferroni over the 8 signs, 10,000 resamples). Skipping it is then judged on that year alone in the **money view**: the plan's own fills, compounded and cash-limited (₹10 lakh, 1/15 of equity a position, integer shares, flat 35 bp), skipped money left in cash, fresh capital each year. A sign is a **CANDIDATE for a stage E replay** only if it qualified in at least 2 years and, over those years, skipping it did not lower the money view's return and improved the year's worst drawdown in at least half. The money view is tradelab's simulator, **not** stage E's execution backtest (the −47.64% baseline): the −25% target can only be judged in a stage E replay.
* **The book by environment** (`book\_by\_environment.csv`): days, total return, worst drawdown inside, average / maximum positions — each day labelled with the environment known at the previous close.

**Nothing filters trades automatically.** A CANDIDATE is a hypothesis: replay it in stage E's simulator, then a declared forward paper test. Re-running the research on an older export needs the cache: `python tl\_research.py --export C:\\QuantData\\tradelab\\export\\TLX\_... --root %CACHE\_DAILY\_ROOT% --pm-run PM\_20261017\_001`. The month-6 checkpoint (2027-03-31) of the paper ledger is still the judge.

## 4\. Backtest a strategy

```
python tl\_backtest.py --root %CACHE\_DAILY\_ROOT% --pm-run PM\_20261017\_001 --strategy strategies\\scale\_20\_80\_vwap.py
```

Options: `--compare auto` (default: the plan on the same picks and clock) or another strategy file · `--values rvol,clv,D\_rsi14` · `--engines`, `--ranks`, `--from`, `--to` · `--capital 1000000` · `--no-portfolio` · `--timeline D-20240425-2,...` · `--tag "what I am trying"` · `--declare "PASS if the paired lower bound > 0"` · `--list-names` · v1.1: `--context auto|full|saved|indices|none` · `--split-date 2024-01-01` (the comparison and the money view before and from that date — write the date down before you run).

The report leads with the verdict: the strategy's mean net per pick slot, the plan's on the **same** picks, and the paired difference with its 95% interval (circular blocks of 10 signal days, 2,000 resamples, seed 7) → BETTER / WORSE / NOT SHOWN. Then fills, exits, MFE/MAE, by year / engine / rank, the money view (CAGR, worst drawdown with dates, Sharpe, exposure, skipped trades), and in v1.1: **where the strategy helps or hurts** — the paired difference by the market at the pick (`context\_breakdown.csv`) and the money by environment (`money\_by\_environment.csv`: return, worst drawdown, worst / best day, positions and exposure by environment, strategy and comparison side by side).

**The stock's state (v1.3.1).** Every pick in `trades.csv` carries its state at the signal-day close (`pre\_state\_\*`, the same columns as the export: known before entry), and *where the strategy helps or hurts* adds the paired difference by the stock's state, its phase (early / mature / deteriorating), confidence, the latest event, S05 and volatility. That table now has about 60 rows per engine (about 30 of them for the state): at 95%, about 3 will look different by luck — a row that stands out is a hypothesis to declare, not a rule. `--context none` leaves the tables exactly as in v1.

**Discipline.** Every backtest is logged in `C:\\QuantData\\tradelab\\tradelab\_ledger.jsonl` *before* it runs (with your `--declare` rule) and again with its result; the report says how many backtests and distinct strategies the ledger holds. With 20 variants on the same years, one will look BETTER by luck. A strategy found here is a hypothesis until a declared rule passes on the forward paper ledger.

## 5\. Simulate single trades

```
python tl\_sim.py --root %CACHE\_DAILY\_ROOT% --pm-run PM\_20261017\_001 --trade D-20240425-2 --strategy strategies\\scale\_20\_80\_vwap.py --strategy strategies\\plan.py
python tl\_sim.py --root %CACHE\_DAILY\_ROOT% --pm-run PM\_20261017\_001 --symbol RELIANCE --signal-day 2024-04-25
```

Add `--values rvol,clv,rel\_nifty\_day,D\_rsi14,prob\_big,ad\_ratio,small\_prev\_ret` to record any value on every bar of the timeline.

Writes, per trade and strategy: `\*\_story.md` (v1.1: opens with the market around the trade — the session before, the signal day, each session held — and the market / stock split; then every buy / sell with its reason; v1.3.1: **the stock's state** — at the pick: its state, when it began and was confirmed, what it was before, required / supporting conditions, conflicts, what would end it, the event and risk flags, the transitions before the pick; then a table with the state on every session from the signal day to the exit, with that day's raw reading, confidence, phase, event and risk flags), `\*\_timeline.csv` and `<trade>\_chart.html` (v1.1: a second panel with the stock against NIFTY, Midcap and Smallcap from the signal-day close). Same engine as the backtester — identical numbers. Session 0 (the signal day) is known before entry; the later rows were observed after entry: they explain a trade, they never select one.

## 6\. Trade cards and the diary (v1.1)

```
python tl\_cards.py --export C:\\QuantData\\tradelab\\export\\TLX\_20261024\_001 --worst 20 --engine D
python tl\_cards.py --export C:\\QuantData\\tradelab\\export\\TLX\_20261024\_001 --symbol RELIANCE
python tl\_cards.py --export C:\\QuantData\\tradelab\\export\\TLX\_20261024\_001 --day 2024-06-04
python tl\_cards.py --export C:\\QuantData\\tradelab\\export\\TLX\_20261024\_001 --where "pre\_high\_stress == 1 and outcome == 'severe\_loser'"
python tl\_cards.py --export C:\\QuantData\\tradelab\\export\\TLX\_20261024\_001 --diary 2024-06-01 2024-06-30
```

Each card (Markdown and HTML) opens with the trade in one line (rank, size class, home index and beta) and has four parts: **1. The market before entry** (the session before and the signal day, the stock's own move, the warning signs that fired), **2. What the model expected** (pick\_meta's forecasts), **3. Day by day: the stock next to its market** (NIFTY, Midcap, Smallcap, breadth, VIX, environment, the stock against its home index, and each held day's market / stock part), **4. Verdict** (entry and exit, net, the split, what drove it). Other selectors: `--trade`, `--best N`, `--ranks 1-3`, `--from/--to`, `--max`, `--name`.

## 7\. Stock states (v1.3)

`tl\_state.py` reads a stock's own daily bars up to a session's close (never later) and gives:

|part|what it is|
|-|-|
|**primary state** (the one shown)|S01 Strong bullish continuation · S02 Emerging bullish trend · S03 Bullish consolidation · S06 Bullish reversal attempt · S07 Neutral range · S08 Bearish continuation · S09 Emerging bearish trend · S12 Unstable / disorderly · or **UNKNOWN** (the evidence conflicts — the card names the two closest states and what each lacks) / **INSUFFICIENT\_DATA** (under 60 sessions)|
|**event** (beside it, last 10 sessions)|S04 breakout: NEW on the close above the 55- (else 20-) session high, CONFIRMED after 3 sessions holding above it, or STALLED · S11 failed breakout (bull trap): back below the level within 5 sessions · S10 breakdown (mirror) · failed breakdown (bear trap)|
|**risk flags**|S05 overextended / extreme (3.0 / 4.5 ATR above EMA20, or 6 / 9 above EMA50, or a 6 ATR rise in 10 sessions — a risk condition, not a sell signal) · stretched down · large down candle · repeated gaps · bearish divergence candidate · price up with volume flow down (candidate)|
|**volatility**|COMPRESSED / NORMAL / ELEVATED / EXTREME — its own dimension, never bearish by itself|
|**confidence**|HIGH / MEDIUM / LOW / UNKNOWN from evidence agreement, conflicts, persistence and data completeness. **Not a probability** — nothing here is calibrated against outcomes|
|**transitions**|the state before, the session the change began and the session it was confirmed (a change needs 2 sessions in a row), sessions in the state, phase EARLY / MATURE / DETERIORATING, a pending change, the last transitions|

How a session is read, the precedence when two states fit (S12 > S03 > S01 > S02 > S06 > S08 > S09 > S07), every condition and every setting are in **`STATE\_RULES.md`** (written by `python tl\_state.py rules`). Swing highs and lows count only from the session they became knowable (3 sessions after the pivot) — never back-dated. All thresholds are research defaults declared on 25 Oct 2026 before any real run; they are transparent, configurable, recorded with every output, and **not proven**.

```
python tl\_state.py show --root %CACHE\_DAILY\_ROOT% --symbol RELIANCE --date 2026-10-23 --sessions 40
```

prints one stock's state, its evidence, measurements, transitions and the last 40 sessions' readings.

**For every trade the models have produced so far:** re-run the export (`python tl\_export.py --root %CACHE\_DAILY\_ROOT% --pm-run PM\_20261017\_001`) — every pick 2020–2026 gets its state at the signal day. Backtests and simulations carry the states by themselves (v1.3.1). The paper days since 30 Sep get their pages from the first `run\_tonight.bat`.

**In the export and the research (v1.3):** every pick gets `pre\_state\_\*` columns (the state known at the signal-day close: state, confidence, phase, age, event, risk flags and the measurements in ATR units — no raw price levels); `context\_breakdown.csv` adds the state, phase, confidence, event, S05 and volatility dimensions; the research report adds **section 6 — D / ENS by the stock's state and its phase** (early / mature / deteriorating), each cell with its 95% interval and its difference from the rest. That section is research-declaration-3: **descriptive only**, about 50 cells per engine (2–3 will look different by luck), no rule chosen from it. Numeric `pre\_state\_\*` values can be used in a strategy's filter (e.g. `"filter": "pre\_state\_num != 12"`) — a hypothesis to backtest, then to declare and test forward.

## Writing strategies

A strategy is a Python file with a `STRATEGY` dict (or JSON). Start from a file in `strategies\\`:

|file|idea|
|-|-|
|`plan.py`, `plan\_intraday.py`|the paper test's plan (daily / on the 3-minute clock)|
|`open6.py`|sell at the 6th open|
|`scale\_20\_80\_vwap.py`|20% at the open, 80% when a 3-minute close crosses above VWAP (sessions 1–2, 09:30–14:30)|
|`orb\_add\_on.py`|50% at the open, 50% on a buy stop at the 15-minute opening-range high|
|`dip\_or\_fallback.py`|limit 1% under the open until 11:00, else buy at 11:00|
|`half\_target\_stop.py`|half at +5%, stop at −8%, rest at the 5th close|
|`trail\_after\_5pct.py`|trail 4% under the highest high once MFE ≥ 5%, hold up to 10 sessions|
|`filtered\_rsi\_entry.py`|skip picks with P(stuck) ≥ 10%; buy only if RSI(14) at the signal close < 70 (a panel feature)|
|`weak\_close\_exit.py`|sell after 14:30 in sessions 2–4 if under VWAP and down 3%+ (with a plugin)|
|v1.1 `hypo\_skip\_smallcap\_fall.py`|**a hypothesis to test, not a rule to trade**: the plan, skipping picks made on a day Smallcap fell 1.5%+ (warning sign W6); run it with `--split-date`|
|setups add-on `setup_s2_d5.py`|frozen setup S2 on D and ENS ranks 1–10: buy the open of S2's own entry day, sell the pick's 5th close; change the id for another setup|

```python





JOURNAL



call C:\\Users\\karanvsi\\PyCharmMiscProject\\tradelab\\env\_tradelab.bat

python tl\_journal.py --selftest

python tl\_journal.py --export TLX\_20261025\_001






STRATEGY = {
    "name": "my\_idea",
    "mode": "intraday",               # "daily" = one bar a session; "intraday" = 3-minute bars (Oct 2021 on)
    "picks": {"engines": \["D"], "ranks": \[1, 2, 3], "from": None, "to": None, "filter": "prob\_trap < 0.10"},
    "max\_sessions": 5,                # the trade ends at this session's close at the latest
    "warmup\_sessions": 1,             # sessions before the signal day loaded for indicators (daily default 30)
    "events": {"reclaim": "crosses\_above(close, vwap)"},          # named conditions, usable anywhere
    "entries": \[
        {"name": "first", "size": 0.2, "at": "open", "session": 1},                       # official open
        {"name": "add", "size": 0.8, "when": "reclaim", "sessions": \[1, 2], "time": \["09:30", "14:30"]},
        # fill: "next\_open" (default) | "stop" / "limit" (with "level": "...") | "close" (needs same\_bar\_close\_fills)
        # "cancel\_if": "..." cancels a waiting leg for good
    ],
    "exits": \[
        {"name": "stop", "type": "stop", "level": "avg\_entry \* 0.95"},           # sell stop (gap -> the open)
        {"name": "tgt", "type": "target", "level": "first\_entry \* 1.10", "size": 0.5},
        {"name": "trail", "type": "trail", "pct": 0.04, "activate": "upnl > 0.03"},  # or "atr": 2.0
        {"name": "weak", "type": "signal", "when": "close < vwap and upnl < -0.02", "sessions": \[2, 4]},
        {"name": "time", "type": "time", "at": "close", "session": 5},           # "at": "open" for an open exit
    ],
    "intrabar": "worst",              # stop and target in one bar: worst | best | intraday (daily mode)
    "costs": {"model": "flat", "round\_trip\_bp": 35},   # or per\_side (buy\_bp, sell\_bp) or zerodha (itemised)
    "slippage\_bp": 0,                 # added against you on every fill
    "sizing": {"rule": "equal\_slots", "slots": 15, "max\_pct": 0.25},
    "portfolio": {"capital": 1000000, "integer\_shares": True, "min\_order\_frac": 0.25,
                  "max\_new\_per\_day": None, "max\_open": None, "allow\_duplicates": True},
    "decision\_rule": {"metric": "diff\_mean\_bp", "pass\_if": "lower > 0"},
    "plugins": \["example\_plugin.py"],
}
```

**Timing rules (no look-ahead).** A rule checked at a bar's close acts at the next bar's open. Stop / limit / trail levels are computed at the previous bar's close (state-based levels such as `avg\_entry \* 0.95` are refreshed right after fills at a bar's open) — so inside a level, `low` means the low of the bar before, and `opening\_range\_high(5)` is blank until the session's 5th bar (give such orders a `time` window that starts after the range). `at: open/close` orders use the session's official open / close. A window (`sessions`, `time`) applies to the bar where the order fills. An entry filled inside a bar cannot exit inside that same bar. A level built on today's open is valid from the second bar on (`time` starting 09:18).

**Sizes.** Entry sizes are fractions of the trade's target size; P\&L is measured on the full target, so an unfilled leg counts as cash. Legs may add up to more than 1.0 when they are alternatives — a buy is clipped so the position never exceeds the target. Exit sizes are fractions of the position held.

**Sizing rules** (`sizing.rule`): `equal\_slots` (equity / slots), `pct\_equity` (`pct`), `fixed` (`amount`), `atr\_risk` (`risk\_pct`, `atr\_mult`: risk\_pct × equity / (atr\_mult × the stock's ATR14% on the signal day)), `expression` (any rule over `equity`, `cash`, `open\_positions`, `signal\_atr14\_pct` and pick attributes, e.g. `"equity / 15 \* min(1.5, 0.03 / signal\_atr14\_pct)"`). Caps: `max\_pct` of equity, `liquidity\_cap` (share of the 20-session median turnover), `min\_notional`.

**What a rule can use** — run `python tl\_backtest.py --list-names --root %CACHE\_DAILY\_ROOT% --pm-run PM\_20261017\_001`:

* bar: `open high low close volume typical hl\_range body upper\_wick lower\_wick clv bar\_ret`
* clock: `session` (0 = signal day, 1 = entry day) `bar\_in\_session minute hhmm is\_first\_bar is\_last\_bar weekday sessions\_left`
* session: `vwap` (3-minute only) `session\_open session\_high session\_low session\_volume day\_ret gap prev\_close prev\_open prev\_high prev\_low prev\_volume dist\_prev\_high dist\_prev\_low entry\_open signal\_close ret\_vs\_entry\_open`
* daily context: `atr14 atr14\_pct vol\_med20 rvol nifty nifty\_day\_ret rel\_nifty\_day nifty\_ret5` (values known when the rule is checked)
* v1.1 market context: `mid\_day\_ret small\_day\_ret` (daily mode; blank intraday — no 3-minute Midcap / Smallcap index), `nifty\_prev\_ret mid\_prev\_ret small\_prev\_ret` (the session before), `nifty\_minus\_mid\_20 nifty\_minus\_small\_20 ad\_ratio ad\_ratio\_10 vix vix\_chg\_pct vix\_chg5\_pct vix\_pct250 env\_code high\_stress` — in daily mode the bar's own session (checked at its close), in intraday mode the last completed session. `env\_code`: 0 broad bullish, 1 narrow bullish, 2 mixed, 3 broad bearish
* pick attributes (constant per trade): `rank score other\_rank both\_engines repeat engine\_D s\_atr14 prob\_\* pred\_\*`, and v1.1 every numeric `pre\_\*` value (e.g. `pre\_small\_ret pre\_high\_stress pre\_env\_code pre\_ad\_ratio\_10 pre\_vix\_chg5\_pct pre\_beta\_home pre\_size\_class\_num pre\_amfi\_rank`) — usable in `picks.filter`, rules and sizing
* panel features by name (daily values; in intraday mode the previous session's)
* trade state: `pos in\_pos avg\_entry first\_entry upnl upnl\_first mfe\_sofar mae\_sofar peak\_close bars\_in\_trade sessions\_in\_trade legs\_filled exits\_done realized filled\_<leg>`
* functions: `shift prev sma/mean ema rsi std zscore highest lowest roc change rsum crosses\_above crosses\_below rising falling bars\_since held\_for count\_true trade\_max trade\_min session\_max session\_min session\_sum session\_first prev\_session opening\_range\_high opening\_range\_low` and `abs min max log exp sqrt sign round clip where isnan nz`
* operators: `+ - \* / \*\* % //`, comparisons (chains allowed), `and or not`, `x if cond else y`

A blank value is false in a condition: `pre\_small\_ret > -0.015` also skips picks whose Smallcap return is unknown; `not (pre\_small\_ret <= -0.015)` keeps them.

Refused: `label\_\*` and forward-looking names (the firewall), **`post\_\*` (observed after entry)**, `shift(x, -1)`, attributes, indexing, strings, lambdas, imports.

**Your own values and functions** — copy `plugins\\example\_plugin.py`:

```python
from tl\_rules import variable, function

@variable("vol\_surge", "bar volume / mean of the previous 20 bars")
def vol\_surge(ctx):                       # ctx.open/high/low/close/volume, ctx.var("vwap"), ctx.daily, ...
    v = pd.Series(ctx.volume)
    return (v / v.shift(1).rolling(20, min\_periods=20).mean()).to\_numpy(float)
```

List it in the strategy (`"plugins": \["my\_plugin.py"]`). tradelab recomputes every plugin value with the later bars removed and refuses the run if anything earlier changes.

## Limits

* 3-minute bars start Oct 2021: intraday strategies skip earlier picks (`no\_intraday`); the plan comparison uses the same picks.
* Exits are decided on the planned position; if cash trims a leg in the money view, the shares held follow the same exit decisions (counted in the report).
* Not modelled: buys at an upper-circuit lock, partial fills, impact beyond the cost model. VWAP is computed from 3-minute bars (typical price × volume), close to — not identical with — the exchange VWAP.
* v1.1 breadth is counted over your cache, not NSE's official advance / decline (coverage and survivorship differ; `ad\_n` shows the count each day). Midcap / Smallcap / VIX values exist only where the cache has their daily files; intraday rules cannot see a same-day Midcap / Smallcap move.
* v1.1 AMFI classes exist only from the first list you add; the half-year a list covers comes from its title or file name.
* Results on 2020–2026 are the same history the engines were built and studied on: descriptive, not new evidence. The warning signs and walk-forward use that same history — a CANDIDATE is a hypothesis for the forward paper test, nothing more.
* v1.3 stock states are rule-based readings of price and volume with research-default thresholds. They describe; they have not been shown to predict. The confidence label is evidence agreement, not a chance of anything. Volume-based signs are candidates from OHLCV, never proof of accumulation or distribution.
* The watch page's Soul cards are copied from the paper test's own watchlist file; if its layout changes, `tl\_check.py` says how many cards it found.

## Changelog

**setups add-on v1.0 — 8 Nov 2026: the frozen setups in every tool** (tradelab stays v1.3.1; nothing in production changes)

* New `tl_setups.py` (tl_setups v1.0): reads setuplab's newest tag run (refused when `setup_tags.parquet` does not match its `outputs.sha256`) and the nightly scan; refuses any rule that names a setup tag.
* `tl_engine.py` (engine v1.1): entry legs `{"setup": "S2"}` (the open of the setup's own entry day) and time exits with `"hold"` (sessions from the first fill). `tl_backtest.py` / `tl_sim.py`: `--setups`, the tag columns, the report's setups paragraph, the story's setups line. `tl_journal.py` v1.1: the FROZEN SETUPS band. `tl_watch.py` v1.2: the setups column and section. `tl_dictionary.py`: the tag columns.
* `run_tonight.bat`: 4 steps (the setup scan is step 3); `env_tradelab.bat`: `SETUPLAB_DIR`, `SETUPLAB_OUT`; `tl_check.py`: the tonight block shows the scan step and whether the freeze file is found.
* Tests: section 17 (`tests/test_setups.py`, 7 checks); section 16 runs the 4-step `run_tonight.bat` (and a failing scan). setuplab's own self-test (f14) reads its real tags and scan with `tl_setups`.

**v1.3.1 — 25 Oct 2026: one double-click a night; states in the backtester and the simulator** (nothing in production changes)

* New `run\_tonight.bat`: Run Now (unchanged, from its own folder, in a child cmd), then pick\_meta `publish --all-missing` and `score`, then `tl\_watch --all-missing`; every step runs and is reported; one pause; `auto` for Task Scheduler; a log line per run.
* `tl\_watch.py` v1.1: `--all-missing` builds a page for every recorded day without one (oldest first; LATE when built after its time) and `watch\_all.csv` (every page's rows in one table). `run\_watch.bat` opens the newest day's page by name.
* `tl\_backtest.py`: the state at every pick in `trades.csv`; the state, phase, confidence, event, S05 and volatility rows in `context\_breakdown.csv` and the report. `tl\_sim.py`: the stock's state at the pick and on every session of the trade in the story.
* `tl\_state.py` v1.1: *what would end it* now states the level the rules actually use — the swing level less (or plus) 0.25 ATR, on 2 sessions in a row. v1.3 printed the bare swing level, so a close just under it while the state held read as a contradiction (on a synthetic world: 95 of 11,323 sessions). Every reading is unchanged (same settings, same fingerprint); `STATE\_RULES.md` rewritten to match.
* `tl\_check.py`: a `tonight (v1.3.1)` block — what `run\_tonight.bat` will start, read from the files (never run). `tl\_watch --all-missing`: an earlier day that cannot be built is reported and skipped; tonight's page is still built.
* Tests: section 16 — the catch-up (a catch-up page = the same day built alone; a rerun builds nothing), every `watch\_all.csv` column documented, `run\_tonight.bat` read as text and — on Windows — executed by cmd.exe with stand-ins (checked here under wine, and against seven deliberate breaks), the backtest's states = tl\_state on 25 picks by hand, the simulator's state table = tl\_state.

**v1.3 — 25 Oct 2026: stock states and the nightly watch page** (nothing in production changes; nothing filters a trade)

* New `tl\_state.py`: the 12 research states as one primary state (8 structural states, UNKNOWN, INSUFFICIENT\_DATA) with events (S04, S10, S11, bear trap) and risk flags (S05 and others) beside it, a separate volatility dimension, HIGH / MEDIUM / LOW / UNKNOWN confidence, 2-session confirmation, phase, transitions and invalidation levels. Swings used only once knowable. Every threshold a declared research default (`STATE\_RULES.md`).
* New `tl\_watch.py` + `run\_watch.bat`: tonight's D and ENS top 10 with the market at the close, each stock's size / sensitivity / relative strength, its state, pick\_meta's numbers and the Soul card — HTML, text, CSV, settings and an append-only index (LATE marked).
* Export: `pre\_state\_\*` columns on every pick; state dimensions in `context\_breakdown.csv`. Research: section 6, D / ENS by state and phase (research-declaration-3, descriptive). Trade cards: the stock's state at the pick. Rules: numeric `pre\_state\_\*` values usable in filters. `tl\_check.py`: what the watch page will read and one stock's state.
* Tests: sections 14–15 (`tests/test\_state.py`, paths in `tests/tl\_state\_world.py`): every planted state found and absent where not planted, the arithmetic and swings by brute force, precedence / confirmation / confidence / phase re-derived on every session, point in time, the watch page end to end (nothing written into the cache).

**v1.2.1 — 24 Oct 2026 (after the first real run):** beta and correlation use only returns between consecutive sessions. A return across a gap in a stock's bars (a suspension, or a stale bar long before listing) is no longer one giant data point: on your data it had given AVALON a beta of 1,152.5 and pushed ENS's average 'market part' to +111.3 bp.

**v1.2 — 24 Oct 2026: fixes after a review** (research-declaration-2, declared before any real run)

* Walk-forward training is **purged**: a test year qualifies signs only on trades whose actual exit (incl. lower-circuit delays) came before 1 Jan of that year. v1.1 used every trade signalled earlier, so late-December trades brought January outcomes into the decision.
* **Blank inputs** are left out of both sides of each comparison and counted (`unknown`). v1.1 counted them as unflagged in the statistic but not in the displayed mean.
* **Multiplicity:** qualification needs a one-sided bootstrap p ≤ 0.05 / 8 (Bonferroni, 10,000 resamples) instead of each sign's own 95% interval.
* **Drawdown and return** in the research come from the plan's compounded, cash-limited money view, not the additive 1/15 proxy; the verdict is now "CANDIDATE for a stage E replay", because tradelab's money view is not stage E's simulator.
* **Portfolio fix (present since v1):** the running peak now starts at the starting capital. Before, a loss ahead of the first new high (₹100 → ₹90 on day 1) showed 0% drawdown in the backtest / sim money view.
* **AMFI timing:** lists are used from 1 Feb / 1 Aug (assumed, disclosed), or from the day after an actual publication date given in `amfi\_published.csv`; v1.1 assumed 10 days.
* `tl\_research.py` needs `--root` and `--pm-run` to rebuild the money view for an older export.

**v1.1 — 24 Oct 2026: the market intelligence layer** (an observation and investigation tool; nothing filters trades automatically)

* New `tl\_context.py`: NIFTY 50 / Midcap 150 / Smallcap 250 direction, divergence, breadth (A/D over the cached stocks), India VIX, AMFI size class (point in time, lists expire after their half-year, renamed stocks via ISIN, malformed lists refused), beta / correlation to the three indices with a home index, and the declared environment labels with High stress as a separate flag. Missing inputs stay blank and are named; nothing is filled.
* Every pick gets `pre\_\*` (known before entry) and `post\_\*` (after entry) context; `trade\_days` gets the market each session and the daily market / stock split; new `market\_days`, `market\_diary.md`, `context\_breakdown.csv`.
* New `tl\_research.py`: winners / losers / severe losers, warning signs W1–W8 tested on winners as well as losers, chronological walk-forward by year, the book by environment — declared before any real run and logged before its result.
* New `tl\_cards.py` (trade cards, diary) and `tl\_dictionary.py` (every column documented with its unit and when it is known: `DATA\_DICTIONARY.md`).
* `tl\_backtest.py`: `--context`, `--split-date` (chronological before / from view), the paired difference by market condition, `money\_by\_environment.csv`. `tl\_sim.py`: the market around the trade in the story and an index panel in the chart.
* Rules: 15 market-context values, every numeric `pre\_\*` value as a pick attribute; `post\_\*` names refused.
* **Fix (portfolio, present since v1):** a trade whose every buy leg cash could not fund stayed "open" with no shares until the end of the run. That inflated `n\_open` and `trades\_opened`, fed a wrong `open\_positions` to expression sizing, and — with `max\_open` or `allow\_duplicates: False` — blocked later trades (in a test world with ₹30,000 and `allow\_duplicates: False`, v1 held 839 trades and reported 21 unfunded ones as opened; v1.1 holds 1,055). Now such a trade is reported as skipped (`skip\_reason` = `cash`) and is never an open position. With the default portfolio settings the equity and P\&L were not affected.
* Tests: sections 10–13 (`tests/test\_context.py`, worlds in `tests/tl\_ctx\_world.py`); new example `strategies/hypo\_skip\_smallcap\_fall.py`; tl\_check lists the index files, breadth count and AMFI lists.

**v1 — 24 Oct 2026:** first release — export of every pick with day-by-day outcomes, the rule language, the trade engine, the backtester with paired intervals and a money view, the trade simulator.

