"""
tests/test_setups.py - the setups add-on (tl_setups v1.0) for tradelab v1.3.1, checked (section 17 of the suite).

Run it through tests/test_tradelab.py. Synthetic worlds only (tests/tl_world.py, tests/tl_ctx_world.py and the watch
world of tests/test_state.py) with a fake setuplab output (tags + a nightly scan) planted by hand:
  17 setups  the tags are read only when their hash matches; a strategy enters at a setup's OWN entry day and nowhere
             else (entry price = that day's open, the D5-close exit and a 'hold' exit by hand); the same-trade line of
             the report; every guard (a filter or rule naming a tag, a setup leg without tags, an unknown setup, a
             hold that cannot fit, a setup leg with a session); tag columns on a plain backtest, documented; the
             simulator's story line; the watch page's setups column and section from the scan (and without one);
             the trade journal's FROZEN SETUPS band
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import tl_world as W  # noqa: E402
import tl_ctx_world as CW  # noqa: E402

IST = "Asia/Kolkata"


def _sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def fake_tags(base: Path, picks: pd.DataFrame, plan: dict) -> Path:
    """setuplab tag's output for the planted entries: plan = {trade_id: {setup id: watch day}}."""
    run = base / "TAGS" / "TAGS_20261108_001"
    run.mkdir(parents=True, exist_ok=True)
    ids = ["S2", "C1", "N1"]
    rows = []
    for t in picks["trade_id"].astype(str):
        r = {"trade_id": t}
        d = plan.get(t, {})
        for sid in ids:
            r[f"su_{sid}_day"] = float(d[sid]) if sid in d else np.nan
            r[f"su_{sid}_net_d5"] = 1.0 + 0.1 * d[sid] if sid in d else np.nan
            r[f"su_{sid}_net_fresh"] = 2.0 + 0.1 * d[sid] if sid in d else np.nan
        r["setups"] = " ".join(f"{s}@D{d[s]}" for s in ids if s in d)
        r["n_setups"] = len(d)
        rows.append(r)
    T = pd.DataFrame(rows)
    T.to_parquet(run / "setup_tags.parquet", index=False)
    meta = {"version": "setuplab v0.7", "frozen_sha256": "f" * 64, "signal_days": ["2023-01-02", "2023-08-01"],
            "setups": [{"id": "S2", "name": "Bad week + minus-DI 5-day change rising + gap down",
                        "primary_exit": "original_d5"},
                       {"id": "C1", "name": "Bad week + minus-DI rising + 2% dip", "primary_exit": "original_d5"},
                       {"id": "N1", "name": "Below the lower Bollinger band + 2% dip", "primary_exit": "fresh"}]}
    (run / "TAGS.json").write_text(json.dumps(meta), encoding="utf-8")
    (run / "outputs.sha256").write_text(f"{_sha(run / 'setup_tags.parquet')}  setup_tags.parquet\n", encoding="utf-8")
    return run


def run_all(check_suite, quiet, fresh_modules, TMP: Path, LAB: Path) -> None:
    def check(cond, msg, detail=None):
        """the suite's check(cond, msg); a failing check also names what it saw"""
        check_suite(cond, msg if cond or detail is None else f"{msg}   <- {str(detail)[:600]}")

    print("17. setups add-on: frozen setups (setuplab) in the backtester, simulator, watch page and journal")
    os.environ.pop("SETUPLAB_OUT", None)
    w = W.make_world(TMP / "su_world", "absent", seed=11, n_syms=12, n_days=170, with_special=False)
    root = w["root"]
    fresh_modules(root)
    import tl_setups as SU
    from tl_common import TLError
    P = pd.read_parquet(root / "research2" / "pick_meta" / "PM_TEST_001" / "predictions.parquet")
    days = w["days"]
    P["signal_day"] = pd.to_datetime(P["signal_day"]).dt.normalize()
    P["trade_id"] = [f"{e}-{d:%Y%m%d}-{int(r)}" for e, d, r in zip(P["engine"], P["signal_day"], P["rank"])]
    pos = {d.normalize(): i for i, d in enumerate(days)}
    P["sig"] = P["signal_day"].map(lambda d: pos.get(pd.Timestamp(d).tz_localize(None).normalize(), -1))
    cand = P[(P["engine"] == "D") & (P["sig"] >= 40) & (P["sig"] <= len(days) - 15)].sort_values(["sig", "rank"])
    cand = cand.iloc[::9].head(24)
    plan = {}
    for i, t in enumerate(cand["trade_id"]):
        d = {"S2": 1 + i % 5}
        if i % 3 == 0:
            d["C1"] = 1 + (i + 2) % 5
        if i % 4 == 1:
            d["N1"] = 2
        plan[t] = d
    base = TMP / "su_out"
    run = fake_tags(base, P, plan)
    # ---- the tags: read only with their hash
    T0, i0 = SU.load_tags(None)
    try:
        SU.load_tags(None, need=True)
        need_ok = False
    except TLError as e:
        need_ok = "--setups" in str(e)
    tags, info = SU.load_tags(base)
    good = (run / "setup_tags.parquet").read_bytes()
    pd.read_parquet(run / "setup_tags.parquet").assign(n_setups=9).to_parquet(run / "setup_tags.parquet", index=False)
    try:
        SU.load_tags(base)
        tamper = False
    except TLError as e:
        tamper = "does not match" in str(e)
    (run / "setup_tags.parquet").write_bytes(good)
    check(T0 is None and not i0["used"] and need_ok and tags is not None and info["setups"] == ["S2", "C1", "N1"] and
          info["primary_exit"]["N1"] == "fresh" and tamper,
          "tags: none without --setups / SETUPLAB_OUT (and a clear refusal when a strategy needs them); the newest "
          "TAGS run is read only when its outputs.sha256 matches - a changed table is refused")
    # ---- a strategy that enters at S2's own entry day, sold at the D5 close; and with a 'hold' exit
    import tl_backtest as BT
    sdir = TMP / "su_strats"
    sdir.mkdir(exist_ok=True)
    s_d5 = sdir / "s2_d5.py"
    s_d5.write_text('STRATEGY = {"name": "s2_d5", "mode": "daily", "max_sessions": 5, "picks": {"engines": ["D"], '
                    '"ranks": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}, "entries": [{"name": "s2", "size": 1.0, "setup": "S2"}], '
                    '"exits": [{"name": "d5", "type": "time", "at": "close", "session": 5}]}\n', encoding="utf-8")
    s_fr = sdir / "s2_fresh.py"
    s_fr.write_text('STRATEGY = {"name": "s2_fresh", "mode": "daily", "max_sessions": 9, "picks": {"engines": ["D"], '
                    '"ranks": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}, "entries": [{"name": "s2", "size": 1.0, "setup": "S2"}], '
                    '"exits": [{"name": "fresh", "type": "time", "hold": 5}]}\n', encoding="utf-8")
    out = TMP / "su_bt"
    daily = {s: pd.read_parquet(root / f"{s}_daily.parquet") for s in w["names"]}
    res = {}
    for nm, sp in (("d5", s_d5), ("fresh", s_fr)):
        rc, log = quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                                  "--strategy", str(sp), "--no-portfolio", "--context", "none", "--setups", str(base)])
        bt = sorted((out / "backtest").glob("TLB_*"))[-1]
        res[nm] = (rc, log, pd.read_parquet(bt / "trades.parquet"), json.loads((bt / "summary.json").read_text()),
                   (bt / "report.md").read_text(encoding="utf-8"), bt)
    ok_ent, bad = True, []
    for nm, hold in (("d5", None), ("fresh", 5)):
        rc, log, A, sm, rep, bt = res[nm]
        A = A.set_index("trade_id")
        for t, d in plan.items():
            k = d["S2"]
            r = A.loc[t]
            sym = cand.set_index("trade_id").at[t, "symbol"]
            sig = int(cand.set_index("trade_id").at[t, "sig"])
            o = float(daily[sym]["open"].iloc[sig + k])
            xs = 5 if hold is None else k + hold - 1
            c = float(daily[sym]["close"].iloc[sig + xs])
            want = (c / o - 1 - 0.0035) * 1e4
            good_row = (r["status"] == "ok" and int(r["entry_session"]) == k and abs(r["first_entry"] - o) < 1e-9
                        and int(r["exit_session"]) == xs and abs(r["net_bp"] - want) < 1e-6
                        and r["setups"] == plan_txt(d))
            if not good_row:
                bad.append((nm, t, r["status"], r["entry_session"], k, r["exit_session"], xs))
            ok_ent &= good_row
        others = A.drop(index=list(plan))
        ok_ent &= bool((others["status"].isin(["not_entered", "pending"])).all() and
                       (others.loc[others["status"] == "not_entered", "net_bp"] == 0).all() and
                       (others["status"] == "not_entered").mean() > 0.9)
        ok_ent &= rc == 0
    rc, log, A, sm, rep, bt = res["d5"]
    traded = A[A["entered"].astype(bool)]
    same = abs(sm["paired"]["diff_on_traded"][0] - traded["diff_bp"].mean()) < 1e-6
    check(ok_ent and same and "## Frozen setups (setuplab tags)" in rep and "ENTERS at setups ['S2']" in rep and
          sm["setups"]["run"] == run.name and sm["strategy"]["setup_entries"] == ["S2"],
          f"setup entries: each of the {len(plan)} planted S2 picks bought at the open of ITS entry day (D1-D5) and "
          f"nowhere else; sold at the D5 close, or with 'hold': 5 at the close 4 sessions after the entry (net = "
          f"exit / that open - 1 - 35 bp, by hand); every other pick not entered (0 bp); 'on the picks the strategy "
          f"traded' = the setup's own trades vs the plan on the same picks", bad[:4])
    # ---- the guards
    def bt_rc(text, extra=()):
        sp = sdir / "guard.py"
        sp.write_text(text, encoding="utf-8")
        return quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                               "--strategy", str(sp), "--no-portfolio", "--context", "none"] + list(extra))
    g1 = bt_rc('STRATEGY = {"name": "g1", "picks": {"engines": ["D"], "filter": "su_S2_day > 0"}}\n', ["--setups", str(base)])
    g2 = bt_rc('STRATEGY = {"name": "g2", "picks": {"engines": ["D"]}, "entries": [{"name": "b", "size": 1.0, '
               '"when": "close < open and n_setups > 0", "sessions": [1, 4]}]}\n', ["--setups", str(base)])
    g3 = bt_rc(s_d5.read_text(encoding="utf-8"))
    g4 = bt_rc(s_d5.read_text(encoding="utf-8").replace('"S2"', '"S9"'), ["--setups", str(base)])
    g5 = bt_rc(s_fr.read_text(encoding="utf-8").replace('"max_sessions": 9', '"max_sessions": 8'), ["--setups", str(base)])
    g6 = bt_rc(s_d5.read_text(encoding="utf-8").replace('"setup": "S2"', '"setup": "S2", "session": 2'),
               ["--setups", str(base)])
    check(g1[0] == 2 and "is a setup tag" in g1[1] and g2[0] == 2 and "'n_setups' is a setup tag" in g2[1] and
          g3[0] == 2 and "needs the frozen setups' tags" in g3[1] and g4[0] == 2 and "not frozen setups" in g4[1] and
          g5[0] == 2 and "max_sessions >= 9" in g5[1] and g6[0] == 2 and "takes no 'session'" in g6[1],
          "guards: a filter or an entry rule naming a setup tag is refused (look-ahead), with the way out; a setup "
          "leg without tags, an unknown setup, a 5-session hold that cannot fit after a D5 entry, and a setup leg "
          "with its own session are refused",
          [x[1][-160:] for x in (g1, g2, g3, g4, g5, g6) if x[0] != 2])
    # ---- tag columns on a plain backtest (hindsight), every column documented
    rc, log = quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                              "--strategy", str(LAB / "strategies" / "plan.py"), "--no-portfolio", "--context", "none",
                              "--setups", str(base)])
    bt = sorted((out / "backtest").glob("TLB_*"))[-1]
    A = pd.read_parquet(bt / "trades.parquet").set_index("trade_id")
    dd = pd.read_csv(bt / "data_dictionary.csv")
    rep = (bt / "report.md").read_text(encoding="utf-8")
    tag_ok = all(A.at[t, "setups"] == plan_txt(d) and int(A.at[t, "su_S2_day"]) == d["S2"] for t, d in plan.items()
                 if t in A.index)
    check(rc == 0 and tag_ok and {"setups", "n_setups", "su_S2_day", "su_C1_day", "su_N1_day", "setups_tagged"} <=
          set(A.columns) and bool(A["setups_tagged"].all()) and not (dd["meaning"] == "UNDOCUMENTED").any() and
          "hindsight" in rep,
          "the plan's own backtest carries the tags (setups 'S2@D3 C1@D5', su_<ID>_day) as hindsight columns, "
          "documented in the data dictionary; the report says they describe trades, never choose them")
    # ---- the simulator's story
    import tl_sim as SIM
    t1 = next(iter(plan))
    rc, log = quiet(SIM.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                               "--trade", t1, "--strategy", str(s_d5), "--context", "none", "--setups", str(base)])
    sim = sorted((out / "sim").glob("TLS_*"))[-1]
    story = (sim / f"{t1}__s2_d5_story.md").read_text(encoding="utf-8")
    ssum = json.loads((sim / "summary.json").read_text())
    rs = ssum["results"]["s2_d5"][0]
    check(rc == 0 and "Frozen setups on this pick" in story and f"S2 on D{plan[t1]['S2']}" in story and
          int(rs["entry_session"]) == plan[t1]["S2"],
          "the simulator: the story names the pick's frozen setups (hindsight before their day) and a setup "
          "strategy enters on S2's own day")
    # ---- the watch page: the setups column and section from the scan
    import test_state as TST
    winfo = CW.make_ctx_world(TMP / "su_watch_world", "absent", 7, n_days=420)
    wroot = winfo["root"]
    fresh_modules(wroot)
    import tl_watch as WT
    day_idx = 400
    planted = TST._write_planted(wroot, winfo["days"], day_idx)
    day = TST._paper(wroot, winfo, day_idx, planted)
    L = [json.loads(x) for x in (wroot / "paper" / "ledger.jsonl").read_text().splitlines() if x.startswith("{")]
    tonight = [x for x in L if x["date"] == f"{day:%Y-%m-%d}" and x["engine"] == "D"]
    older = [x for x in L if x["date"] < f"{day:%Y-%m-%d}"]
    r1, r2, r3 = tonight[0], tonight[1], older[0]
    scan = pd.DataFrame([
        {"scan_date": f"{day:%Y-%m-%d}", "setup": "C3", "status": "FIRES", "trade_id": "x1", "engine": "D",
         "rank": r1["rank"], "symbol": r1["symbol"], "signal_day": r1["date"], "next_watch_day": 1, "rule_at_open": "",
         "entered_day": "", "entry": np.nan},
        {"scan_date": f"{day:%Y-%m-%d}", "setup": "S2", "status": "ARMED", "trade_id": "x2", "engine": "D",
         "rank": r2["rank"], "symbol": r2["symbol"], "signal_day": r2["date"], "next_watch_day": 1,
         "rule_at_open": "open below 123.45", "entered_day": "", "entry": np.nan},
        {"scan_date": f"{day:%Y-%m-%d}", "setup": "C1", "status": "ENTERED", "trade_id": "x3", "engine": r3["engine"],
         "rank": r3["rank"], "symbol": r3["symbol"], "signal_day": r3["date"], "next_watch_day": 4, "rule_at_open": "",
         "entered_day": 3, "entry": 99.5},
        {"scan_date": f"{day:%Y-%m-%d}", "setup": "S1", "status": "WATCHING", "trade_id": "x4", "engine": "D",
         "rank": r1["rank"], "symbol": r1["symbol"], "signal_day": r1["date"], "next_watch_day": 1, "rule_at_open": "",
         "entered_day": "", "entry": np.nan}])
    sdir2 = base / "scan"
    sdir2.mkdir(parents=True, exist_ok=True)
    scan.to_csv(sdir2 / f"scan_{day:%Y%m%d}.csv", index=False)
    (sdir2 / "setup_ledger.jsonl").write_text(json.dumps({"event": "scan", "scan_date": f"{day:%Y-%m-%d}",
                                                          "on_time": True, "recorded_at": "x"}) + "\n", encoding="utf-8")
    wout = TMP / "su_watch_out"
    rc, log = quiet(WT.main, ["--root", str(wroot), "--out", str(wout), "--stage-e-any", "--setups", str(base)])
    R = pd.read_csv(wout / "watch" / f"WATCH_{day:%Y%m%d}.csv")
    md = (wout / "watch" / f"WATCH_{day:%Y%m%d}.md").read_text(encoding="utf-8")
    H = (wout / "watch" / f"WATCH_{day:%Y%m%d}.html").read_text(encoding="utf-8")
    g = R.set_index(["engine", "rank"])["setups"].fillna("")
    rc2, log2 = quiet(WT.main, ["--root", str(wroot), "--out", str(TMP / "su_watch_out2"), "--stage-e-any"])
    md2 = (TMP / "su_watch_out2" / "watch" / f"WATCH_{day:%Y%m%d}.md").read_text(encoding="utf-8")
    R2 = pd.read_csv(TMP / "su_watch_out2" / "watch" / f"WATCH_{day:%Y%m%d}.csv")
    check(rc == 0 and g[("D", r1["rank"])] == "C3 buy at the open" and
          g[("D", r2["rank"])] == "S2 buy at the open only if open below 123.45" and
          "## Frozen setups at the next open" in md and "recorded ON TIME" in md and "C1 entered D3 at 99.50" in md and
          "S1" not in md.split("## Frozen setups at the next open")[1].split("## Stock cards")[0] and
          "Frozen setups at the next open" in H and rc2 == 0 and "Setup scan: no --setups and no SETUPLAB_OUT" in md2
          and R2["setups"].fillna("").eq("").all(),
          "the watch page: tonight's picks show what fires / is armed at the next open (from setuplab's scan), a "
          "section lists every FIRES / ARMED / ENTERED row of the last five sessions (not WATCHING) and says the scan "
          "was on time; without a scan the column is blank and the page says so")
    # ---- the trade journal: the FROZEN SETUPS band
    import tl_export as X
    import tl_journal as J
    rc, log = quiet(X.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(TMP / "su_exp"),
                             "--stage-e-any", "--features", "none", "--no-benchmark"])
    ex = sorted((TMP / "su_exp" / "export").glob("TLX_*"))[-1]
    from openpyxl import load_workbook
    res_j = {}
    for nm, sb in (("with", str(base)), ("without", None)):
        quiet(J.build, ex, False, f"J_{nm}.xlsx", lambda m: None, sb)
        wb = load_workbook(ex / f"J_{nm}.xlsx", read_only=True)
        ws = wb["Trades"]
        rows = list(ws.iter_rows(values_only=True))
        hdr = next(r for r in rows if r and "Symbol" in r)
        res_j[nm] = (hdr, rows[rows.index(hdr) + 1:])
    hdr, body = res_j["with"]
    traded_tagged = [t for t in plan if int(t.rsplit("-", 1)[1]) <= 3]
    ci = hdr.index("Setups")
    n_tagged = sum(1 for r in body if r[ci])
    check("Setups" in hdr and "S2 %" in hdr and "N1 %" in hdr and n_tagged == len(traded_tagged) and
          "Setups" not in res_j["without"][0],
          f"the trade journal: a FROZEN SETUPS band (which setups entered each traded pick, each setup's net at its "
          f"primary exit) - {len(traded_tagged)} tagged traded picks; no band without the tags",
          (n_tagged, len(traded_tagged)))


def plan_txt(d: dict) -> str:
    return " ".join(f"{s}@D{d[s]}" for s in ("S2", "C1", "N1") if s in d)
