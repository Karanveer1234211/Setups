"""
tests/test_state.py - tradelab v1.3.1: the stock-state engine and the watch page, checked (sections 14-16 of the suite).

Run it through tests/test_tradelab.py (which prints VERIFIED (tradelab v1.3.1)). Synthetic worlds only
(tests/tl_state_world.py, tests/tl_ctx_world.py) with stand-in production modules - nothing on your cache is read
or written.
  14 states      the arithmetic by hand (ATR, EMA, RSI, efficiency, rank, relative volume, volume flow); swings by
                 brute force and never used before they were knowable; every PLANTED state found where it was
                 planted (S01, S02, S03, S06, S07, S08, S09, S12, S04 -> confirmed, S11, S10, S05) and ABSENT where it
                 was not; the precedence, the 2-session confirmation and the confidence rules re-derived on every
                 session; point in time (every later bar scrambled: nothing up to the cut changes); missing volume;
                 too little history; settings recorded and an unknown setting refused; pick states for an export
  15 watch       the page end to end: planted stocks show their states, market columns = tl_context's, pick_meta's
                 numbers and marks copied as its card shows them, the Soul cards copied verbatim, every CSV column
                 documented; nothing written into the cache, the paper ledger or pick_meta's files; a rerun is
                 skipped, --force rewrites and both are indexed; the LATE rule; point in time; a missing card and a
                 stock without a bar; the export's pre_state_* columns = tl_state, the state breakdown, the research
                 state book by hand, the trade card line, and a backtest filter on a state attribute
  16 v1.3.1      the catch-up (--all-missing) and watch_all.csv; run_tonight.bat read as text (CRLF, ASCII, labels,
                 parentheses, order of the steps) and executed by cmd.exe on Windows with stand-ins (skipped
                 elsewhere; TL_TEST_WINE=<wine> runs it under wine);
                 tl_backtest's pre_state_* at every pick = tl_state and the state dimensions; tl_sim's state table =
                 tl_state session by session; --context none leaves both as in v1
"""
from __future__ import annotations

import json
import re
import shutil
import sys
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import tl_state_world as SW  # noqa: E402
import tl_ctx_world as CW  # noqa: E402

IST = "Asia/Kolkata"


# ----------------------------------------------------------------------
# independent arithmetic (plain loops - no tradelab code)
# ----------------------------------------------------------------------
def i_wilder(x, n):
    out = np.full(len(x), np.nan)
    f = next(i for i, v in enumerate(x) if np.isfinite(v))
    if len(x) - f < n:
        return out
    a = float(np.mean(x[f:f + n]))
    out[f + n - 1] = a
    for t in range(f + n, len(x)):
        a = a + (x[t] - a) / n
        out[t] = a
    return out


def i_ema(c, n):
    out = np.full(len(c), np.nan)
    a = float(np.mean(c[:n]))
    out[n - 1] = a
    for t in range(n, len(c)):
        a = a + 2.0 / (n + 1) * (c[t] - a)
        out[t] = a
    return out


def i_measures(df):
    o, h, l, c, v = (df[k].to_numpy(float) for k in ("open", "high", "low", "close", "volume"))
    n = len(c)
    tr = np.full(n, np.nan)
    for t in range(1, n):
        tr[t] = max(h[t] - l[t], abs(h[t] - c[t - 1]), abs(l[t] - c[t - 1]))
    atr = i_wilder(tr, 14)
    g = np.full(n, np.nan)
    ls = np.full(n, np.nan)
    for t in range(1, n):
        d = c[t] - c[t - 1]
        g[t], ls[t] = max(d, 0.0), max(-d, 0.0)
    ag, al = i_wilder(g, 14), i_wilder(ls, 14)
    rsi = np.where(al > 0, 100 - 100 / (1 + ag / np.where(al > 0, al, 1)), np.where(ag > 0, 100.0, 50.0))
    rsi = np.where(np.isfinite(ag) & np.isfinite(al), rsi, np.nan)
    eff = np.full(n, np.nan)
    for t in range(20, n):
        s = sum(abs(c[i] - c[i - 1]) for i in range(t - 19, t + 1))
        eff[t] = (c[t] - c[t - 20]) / s if s > 0 else np.nan
    rvol = np.full(n, np.nan)
    flow = np.full(n, np.nan)
    for t in range(n):
        prev = v[max(0, t - 50):t]
        if len(prev) >= 20:
            rvol[t] = v[t] / np.median(prev)
        if t >= 20:
            sg = np.sign(c[t - 19:t + 1] - c[t - 20:t])
            flow[t] = float(np.sum(sg * v[t - 19:t + 1]) / np.sum(v[t - 19:t + 1]))
    return {"atr": atr, "ema20": i_ema(c, 20), "ema50": i_ema(c, 50), "rsi14": rsi, "eff20": eff, "rvol": rvol,
            "flow20": flow}


def i_pivots(h, l, k=3):
    hi, lo = [], []
    for p in range(k, len(h) - k):
        if h[p] > max(h[p - k:p]) and h[p] >= max(h[p + 1:p + k + 1]):
            hi.append(p)
        if l[p] < min(l[p - k:p]) and l[p] <= min(l[p + 1:p + k + 1]):
            lo.append(p)
    return hi, lo


def scramble_df(df, cut, seed=3):
    """Every bar after position `cut` multiplied by a random factor (O / H / L / C), volume shuffled."""
    rng = np.random.default_rng(seed)
    d = df.copy()
    m = np.arange(len(d)) > cut
    k = np.exp(rng.normal(0, 0.08, m.sum()))
    for col in ("open", "high", "low", "close"):
        x = d[col].to_numpy(float).copy()
        x[m] = x[m] * k
        d[col] = x
    vv = d["volume"].to_numpy(float).copy()
    vv[m] = rng.permutation(vv[m]) * 1.7
    d["volume"] = vv
    return d


def same(a, b) -> bool:
    a, b = np.asarray(a), np.asarray(b)
    if a.shape != b.shape:
        return False
    if a.dtype.kind not in "biuf" or b.dtype.kind not in "biuf":
        return all((x == y) or (pd.isna(x) and pd.isna(y)) for x, y in zip(a.tolist(), b.tolist()))
    return np.allclose(a.astype(float), b.astype(float), rtol=0, atol=1e-12, equal_nan=True)


def subseq(seq, want) -> bool:
    it = iter(seq)
    return all(any(x == w for x in it) for w in want)


# ======================================================================
def run_all(check, quiet, fresh_modules, TMP: Path, LAB: Path) -> None:
    import tl_state as S
    from tl_common import TLError
    from tl_context import rolling_pct_rank
    P = SW.paths()
    SS = {nm: SW.series(df, nm) for nm, (df, _f) in P.items()}

    print("14. stock states: arithmetic, swings, planted / absent states, rules, point in time")
    # --- arithmetic by hand
    df = P["REVERSAL"][0]
    ss = SS["REVERSAL"]
    I = i_measures(df)
    ok = all(np.allclose(ss.A[k], I[k], rtol=0, atol=1e-9, equal_nan=True) for k in I)
    worst = max(float(np.nanmax(np.abs(ss.A[k] - I[k]))) for k in I)
    check(ok, f"ATR (Wilder), EMA20 / EMA50 (simple-mean seed), RSI 14, efficiency, relative volume and volume flow = "
              f"plain loops (largest difference {worst:.1e})")
    x = ss.A["atr_pct"]
    check(same(S.rolling_rank(x, 250, 60), rolling_pct_rank(x, 250, 60)),
          "ATR% rank = tl_context's percentile rank (same definition, vectorised)")
    # --- swings: brute force, known k sessions later, never back-dated
    k = int(S.STATE_CFG["swing_k"])
    hi, lo = i_pivots(df["high"].to_numpy(float), df["low"].to_numpy(float), k)
    check(list(ss.piv_hi) == hi and list(ss.piv_lo) == lo, f"swing highs / lows = brute force ({len(hi)} / {len(lo)})")
    li, kn = ss.A["last_hi_i"], ss.A["last_hi_known"]
    t = np.arange(ss.n)
    okk = np.isfinite(li)
    early_use = any((li[p:p + k] == p).any() for p in hi)
    check(bool(np.all(kn[okk] == li[okk] + k) and np.all(kn[okk] <= t[okk]) and not early_use),
          "a swing is used only from the session it became knowable (pivot + 3), never on or after the pivot day "
          "before that")
    lv = ss.A["last_hi"]
    exp_last = np.full(ss.n, np.nan)
    hh = df["high"].to_numpy(float)
    for p in hi:
        exp_last[p + k:] = hh[p]
    check(same(lv, exp_last), "the last confirmed swing high on every session = the latest pivot known by then")

    # --- planted states
    st = {nm: s.state for nm, s in SS.items()}
    up, dn = SS["UP"], SS["DOWN"]
    check(up.state[-1] == "S01" and up.confidence[-1] == "HIGH" and subseq([x[3] for x in up.transitions], ["S02", "S01"]),
          f"UP: S02 (emerging) then S01 strong bullish continuation, HIGH ({up.row(up.n - 1)['headline']})")
    check(dn.state[-1] == "S08" and subseq([x[3] for x in dn.transitions], ["S09", "S08"]),
          f"DOWN: S09 (emerging) then S08 bearish continuation ({dn.row(dn.n - 1)['headline']})")
    rg = SS["RANGE"].state[150:]
    check(np.mean(rg == "S07") >= 0.6 and not np.isin(rg, ["S01", "S08", "S02", "S09"]).any(),
          f"RANGE: neutral range on {np.mean(rg == 'S07'):.0%} of sessions after 150, never a trend state")
    seq = [x[3] for x in SS["REVERSAL"].transitions]
    check(subseq(seq, ["S08", "S06", "S02", "S01"]),
          f"REVERSAL: S08 -> S06 reversal attempt -> S02 -> S01 in that order ({' -> '.join(seq)})")
    co = SS["CONSOL"]
    check(co.state[-1] == "S03" and "S01" in co.state[:-30],
          f"CONSOL: a strong uptrend then S03 bullish consolidation ({co.row(co.n - 1)['headline']})")
    for nm, kind in (("BREAKOUT", "BREAKOUT"), ("BREAKDOWN", "BREAKDOWN")):
        s_, f_ = SS[nm], P[nm][1]
        cx = f_["cross"]
        check(s_.ev_kind[cx] == kind and s_.ev_status[cx] == "NEW" and s_.ev_kind[cx - 1] == "" and
              s_.ev_status[cx + 2] == "NEW" and s_.ev_status[cx + 3] == "CONFIRMED",
              f"{nm}: {'S04' if kind == 'BREAKOUT' else 'S10'} detected on the crossing session (NEW), CONFIRMED after "
              f"holding 3 sessions - not before")
    tr = SS["TRAP"]
    fl = P["TRAP"][1]["fail"]
    check(tr.ev_kind[fl - 1] == "BREAKOUT" and tr.ev_kind[fl] == "FAILED_BREAKOUT" and tr.ev_status[fl] == "FAILED"
          and "S11" in tr.event_text(fl), f"TRAP: S11 failed breakout on the session it closed back below ({tr.event_text(fl)})")
    wd = SS["WILD"]
    wf = P["WILD"][1]["wild_from"]
    check(np.mean(wd.state[wf:wf + 30] == "S12") >= 0.5 and not (wd.state[:wf] == "S12").any(),
          f"WILD: S12 unstable on {np.mean(wd.state[wf:wf + 30] == 'S12'):.0%} of the first 30 wild sessions, never "
          f"in the quiet part")
    pa = SS["PARABOLIC"]
    check("S05_EXTREME" in pa.risks[-1] and not any("S05" in r for r in pa.risks[:P["PARABOLIC"][1]["para_from"]]),
          "PARABOLIC: S05 extreme overextension at the end (a risk flag beside the state), none before the run-up")
    # --- absent
    u2 = slice(200, None)
    check(not (up.state[u2] == "S12").any() and not any("S05_EXTREME" in r for r in up.risks[u2]) and
          not (up.ev_kind[u2] == "BREAKDOWN").any(), "absent: an established uptrend never shows S12, S05 extreme or "
                                                     "a breakdown")
    check(not any("S05" in r for r in SS["RANGE"].risks[150:]), "absent: a range never shows S05 overextension")

    # --- rules re-derived on every session of every path
    g = S.STATE_CFG
    ok_prec, ok_hyst, ok_conf, ok_phase, ok_age = True, True, True, True, True
    for nm, s_ in SS.items():
        for t_ in range(s_.n):
            r = s_.raw[t_]
            if r == "INSUFFICIENT_DATA":
                continue
            first = next((x for x in S.PRECEDENCE if s_.req_ok[x][t_]), "UNKNOWN")
            ok_prec &= (r == first)
        trs = s_.transitions
        for (tt, b, f, to) in trs:
            if "INSUFFICIENT_DATA" in (f, to):
                continue
            ok_hyst &= (s_.raw[tt] == to and tt - b + 1 == g["confirm_n"] and all(s_.raw[j] != f for j in range(b, tt + 1)))
        changes = [tt for tt in range(1, s_.n) if s_.state[tt] != s_.state[tt - 1]]
        ok_hyst &= changes == [x[0] for x in trs]
        known = np.isin(s_.state, S.PRIMARY)
        pend = s_.pending != ""
        sup, con, cmp_, age = s_.st_support, s_.st_conflicts, s_.st_complete, s_.age
        for t_ in range(s_.n):
            if not known[t_]:
                ok_conf &= s_.confidence[t_] == "UNKNOWN" and s_.phase[t_] == ""
                continue
            low = pend[t_] or not np.isfinite(sup[t_]) or sup[t_] < g["weak_support"] or con[t_] >= g["conflicts_low"] or \
                cmp_[t_] < g["complete_low"]
            high = (not pend[t_]) and sup[t_] >= g["high_support"] and con[t_] == 0 and cmp_[t_] >= g["complete_high"] and \
                age[t_] >= g["high_age"]
            want = "LOW" if low else ("HIGH" if high else "MEDIUM")
            ok_conf &= s_.confidence[t_] == want
            det = pend[t_] or (np.isfinite(sup[t_]) and sup[t_] < g["weak_support"]) or con[t_] >= g["conflicts_low"]
            ok_phase &= s_.phase[t_] == ("DETERIORATING" if det else ("EARLY" if age[t_] <= g["early_n"] else "MATURE"))
        ok_age &= all(s_.age[t_] == t_ - s_.began[t_] + 1 for t_ in range(s_.n))
    check(ok_prec, "every session's raw state = the first state in the declared precedence whose required conditions "
                   "all hold (else UNKNOWN)")
    declared = ("S12", "S03", "S01", "S02", "S06", "S08", "S09", "S07")       # as STATE_RULES.md declares it
    n_both, ok_both, pairs = 0, True, set()
    for nm, s_ in SS.items():
        for a_i, a in enumerate(declared):
            for b in declared[a_i + 1:]:
                m = s_.req_ok[a] & s_.req_ok[b] & (s_.raw != "INSUFFICIENT_DATA")
                if m.any():
                    n_both += int(m.sum())
                    pairs.add(f"{a}>{b}")
                    first = [next(x for x in declared if s_.req_ok[x][t_]) for t_ in np.flatnonzero(m)]
                    ok_both &= all(s_.raw[t_] == f_ for t_, f_ in zip(np.flatnonzero(m), first))
    check(tuple(S.PRECEDENCE) == declared and n_both >= 20 and {"S03>S01", "S12>S07", "S02>S06"} <= pairs and ok_both,
          f"precedence = the declared order; on the {n_both} sessions where two states' requirements hold at once "
          f"({', '.join(sorted(pairs))}) the earlier one wins (consolidation over continuation, unstable over range, "
          f"emerging over attempt)")
    check(ok_hyst, "a change is confirmed only after 2 sessions in a row off the old state; the new state = that "
                   "session's reading; no other change ever happens")
    check(ok_conf, "confidence HIGH / MEDIUM / LOW / UNKNOWN re-derived on every session from support, conflicts, "
                   "completeness, age and a pending change (conflicts and a pending change always lower it)")
    check(ok_phase and ok_age, "phase EARLY / MATURE / DETERIORATING and sessions-in-state re-derived on every session")
    hs = [(nm, t_) for nm, s_ in SS.items() for t_ in range(s_.n) if s_.confidence[t_] == "HIGH"]
    lowc = [(nm, t_) for nm, s_ in SS.items() for t_ in range(s_.n) if s_.st_conflicts[t_] >= 2 and np.isin(s_.state[t_], S.PRIMARY)]
    check(len(hs) > 100 and all(SS[nm].confidence[t_] == "LOW" for nm, t_ in lowc),
          f"the engine is willing to say LOW / UNKNOWN: every session with 2+ conflicts is LOW ({len(lowc)} sessions); "
          f"HIGH on {len(hs)}")

    # --- point in time: scramble every bar after a cut
    ok_pit = True
    for nm, cut in (("REVERSAL", 330), ("TRAP", 121), ("WILD", 160), ("UP", 250)):
        d0 = P[nm][0]
        a, b = SW.series(d0, nm), SW.series(scramble_df(d0, cut, seed=cut), nm)
        sl = slice(0, cut + 1)
        for arr in ("raw", "state", "prev", "age", "began", "conf_i", "pending", "pending_n", "confidence", "phase",
                    "ev_kind", "ev_status", "ev_start", "ev_change", "ev_level", "risks", "notes", "vol_regime",
                    "st_support", "st_conflicts", "st_complete"):
            ok_pit &= same(getattr(a, arr)[sl], getattr(b, arr)[sl])
        for kk in a.A:
            ok_pit &= same(a.A[kk][sl], b.A[kk][sl])
        for kk in a.C:
            ok_pit &= same(a.C[kk][sl], b.C[kk][sl])
        ok_pit &= [x for x in a.transitions if x[0] <= cut] == [x for x in b.transitions if x[0] <= cut]
        ok_pit &= [e for e in a.event_log if e["change"] <= cut] == [e for e in b.event_log if e["change"] <= cut]
        ok_pit &= a.row(cut)["headline"] == b.row(cut)["headline"]
    check(ok_pit, "point in time: every later bar scrambled -> every measurement, condition, state, event, flag, "
                  "confidence and transition up to the cut unchanged (4 paths)")

    # --- missing data
    short = SW.series(SW.ohlc(SW.segs(100, [(50, 0.5)])), "SHORT")
    check((short.state == "INSUFFICIENT_DATA").all() and (short.confidence == "UNKNOWN").all() and
          short.row(49)["headline"] == "INSUFFICIENT DATA (50 sessions of bars)",
          "50 sessions of bars -> INSUFFICIENT_DATA on every session, confidence UNKNOWN")
    check((up.state[:59] == "INSUFFICIENT_DATA").all() and up.state[59] != "INSUFFICIENT_DATA",
          "the first 59 sessions are INSUFFICIENT_DATA; classification starts at session 60")
    yu = SW.series(SW.ohlc(SW.segs(300, SW.zig(6, 1.0, 1.0))), "YOUNGUP")
    yd = SW.series(SW.ohlc(SW.segs(300, [(8, -1.0), (4, 1.0)] * 6)), "YOUNGDN")
    check(np.isnan(yu.A["bull_share"]).all() and yu.state[-1] in ("S01", "S02") and yd.state[-1] in ("S08", "S09") and
          not np.isin(yu.state[59:], ["UNKNOWN"]).any(),
          f"a young stock (72 sessions, the 40-session context not yet available) is still read: clean uptrend "
          f"{yu.state[-1]}, clean downtrend {yd.state[-1]} - 'established' judged on how long the structure held")
    nv = SW.series(SW.ohlc(SW.segs(100, [(70, 0.0)] + SW.zig(30, 1.0, 1.0)), vol=False), "NOVOL")
    m01 = (nv.state == "S01") & (up.state == "S01")
    check(np.isnan(nv.A["flow20"]).all() and np.isnan(nv.A["rvol"]).all() and m01.sum() > 100 and
          float(np.mean(nv.st_complete[m01])) < float(np.mean(up.st_complete[m01])) and (nv.state[-1] == "S01"),
          f"no volume: volume signs not evaluated (never filled), completeness lower "
          f"({np.mean(nv.st_complete[m01]):.0%} vs {np.mean(up.st_complete[m01]):.0%}), the structural state unchanged")
    # --- settings
    h0 = S.cfg_hash(S.STATE_CFG)
    s2 = SW.series(P["UP"][0], "UP", {"confirm_n": 1})
    raise_ok = False
    try:
        S.cfg_with({"confirm_nn": 3})
    except TLError:
        raise_ok = True
    nz = s2.raw != "INSUFFICIENT_DATA"
    check(raise_ok and S.cfg_hash(s2.cfg) != h0 and (s2.state[nz] == s2.raw[nz]).all(),
          "settings: an unknown setting is refused; a changed one changes the fingerprint; confirm_n = 1 follows the "
          "raw reading exactly")
    md = S.rules_md()
    txt = S.cond_text(S.STATE_CFG)
    check(all(v in md for v in txt.values()), "STATE_RULES.md lists every condition in words")
    check(all(f"### {s} " in md for s in S.PRIMARY) and '"confirm_n": 2' in md and "## Precedence and conflicts" in md
          and "S04" in md and "S11" in md and "S05" in md and "S10" in md,
          "STATE_RULES.md documents the 8 primary states, events S04 / S10 / S11, risk S05, precedence and settings")

    # --- pick states (as the export uses them)
    class FakeDS:
        def __init__(self, d):
            t = pd.to_datetime(d["timestamp"]).dt.tz_convert(IST).dt.tz_localize(None).dt.normalize()
            self.dates = t.values.astype("datetime64[D]")
            self.o, self.h, self.l, self.c, self.v = (d[k].to_numpy(float) for k in ("open", "high", "low", "close", "volume"))
            self._p = {x: i for i, x in enumerate(self.dates.tolist())}

        def __len__(self):
            return len(self.dates)

        def idx(self, day):
            return self._p.get(np.datetime64(day, "D").item(), -1)

    class FakeMarket:
        def __init__(self):
            self.d = {nm: FakeDS(P[nm][0]) for nm in ("UP", "TRAP")}

        def series(self, sym):
            return self.d.get(sym)
    fm = FakeMarket()
    du = fm.d["UP"].dates
    T = pd.DataFrame({"symbol": ["UP", "TRAP", "UP", "NONE", "TRAP"],
                      "signal_day": pd.to_datetime([du[300], fm.d["TRAP"].dates[123], du[59], du[10], "2030-01-01"])})
    X = S.pick_states(fm, T)
    r0 = SS["UP"].pick_columns(300)
    r1 = SS["TRAP"].pick_columns(123)
    ok = all(same([X[c].iloc[0]], [r0[c]]) for c in S.STATE_PICK_COLUMNS) and \
        all(same([X[c].iloc[1]], [r1[c]]) for c in S.STATE_PICK_COLUMNS)
    check(ok and X["pre_state"].iloc[2] in S.PRIMARY + ("UNKNOWN",) and X["pre_state_failed_breakout"].iloc[1] == 1 and
          X["pre_state"].iloc[3] == "" and X["pre_state"].iloc[4] == "" and
          X["pre_state_name"].iloc[4] == "no bar on the signal day" and list(X.columns) == S.STATE_PICK_COLUMNS,
          "pick states = the series at the signal day (S11 flagged on the trap); no stock or no bar that day -> blank, "
          "never the nearest day")
    check(not any(c in ("pre_state_close", "pre_state_level") or c.endswith(("_close", "_level")) for c in S.STATE_PICK_COLUMNS)
          and not any(c.startswith("label_") for c in S.STATE_PICK_COLUMNS) and
          all(c not in S.STATE_PICK_ATTRS for c in S.STATE_TEXT_COLS),
          "pick columns carry no raw price level and no label; text columns are not rule inputs")

    # ==================================================================
    print("15. the watch page (market context + states + pick_meta + Soul) and the export / research / cards")
    _watch(check, quiet, fresh_modules, TMP, LAB)
    _export(check, quiet, fresh_modules, TMP, LAB)
    print("16. v1.3.1: catch-up pages and the table of all pages, the one-click nightly runner, states in the backtest "
          "and the simulator")
    _v131(check, quiet, fresh_modules, TMP, LAB)


# ----------------------------------------------------------------------
def _write_planted(root: Path, days, end_pos: int) -> dict:
    """Planted stocks in the world's calendar, their last bar on days[end_pos]."""
    P = SW.paths()
    import tl_state as S
    out = {}
    specs = {"PLTUP": SW.ohlc(SW.segs(100, [(70, 0.0)] + SW.zig(25, 1.0, 1.0))),
             "PLTDN": SW.ohlc(SW.segs(400, [(70, 0.0)] + [(8, -1.0), (4, 1.0)] * 25)),
             "PLTTRAP": P["TRAP"][0].iloc[:124].reset_index(drop=True)}
    wd = P["WILD"][0]
    s_w = SW.series(wd, "W")
    cut = next(i for i in range(155, s_w.n) if s_w.state[i] == "S12")
    specs["PLTWILD"] = wd.iloc[:cut + 1].reset_index(drop=True)
    for sym, d in specs.items():
        n = len(d)
        d = d.copy()
        d["timestamp"] = days[end_pos - n + 1:end_pos + 1].tz_localize(IST)
        d.to_parquet(root / f"{sym}_daily.parquet", index=False)
        out[sym] = d
    return out


def _paper(root: Path, info: dict, day_idx: int, planted) -> pd.Timestamp:
    days = info["days"]
    P = pd.DataFrame(info["picks"], columns=["engine", "t", "symbol", "rank"])
    pdir = root / "paper"
    (pdir / "watchlists").mkdir(parents=True, exist_ok=True)
    lines = []
    for t in sorted(P["t"].unique()):
        if t < day_idx - 3 or t > day_idx:
            continue
        d = days[t]
        G = P[P["t"] == t].sort_values(["engine", "rank"])
        for r in G.to_dict("records"):
            sym = r["symbol"]
            if t == day_idx and r["engine"] == "D" and r["rank"] <= len(planted):
                sym = list(planted)[r["rank"] - 1]
            if t == day_idx and r["engine"] == "ENS" and r["rank"] == 10:
                sym = "BETA15"                                   # beta 1.5 x Smallcap by construction
            lines.append(json.dumps({"date": f"{d:%Y-%m-%d}", "engine": r["engine"], "rank": int(r["rank"]),
                                     "symbol": sym, "score": round(1 - r["rank"] / 100, 4),
                                     "recorded_at": (d + pd.Timedelta(hours=21, minutes=40)).isoformat(),
                                     "prev_sha": "x" * 16}))
    lines.append("not json")
    (pdir / "ledger.jsonl").write_text("\n".join(lines) + "\n", encoding="utf-8")
    d = days[day_idx]
    L = [json.loads(x) for x in lines if x.startswith("{")]
    W = pd.DataFrame([x for x in L if x["date"] == f"{d:%Y-%m-%d}"])
    rng = np.random.default_rng(4)
    pm = W[["engine", "rank", "symbol"]].copy()
    pm["signal_day"] = f"{d:%Y-%m-%d}"
    pm["swing_class"] = rng.integers(1, 11, len(pm))
    for c, v in (("swing_p20_pct", 4.1), ("swing_p50_pct", 9.2), ("swing_p80_pct", 15.3), ("p_swing_lt5_pct", 21.0),
                 ("p_swing_ge10_pct", 41.0), ("mfe_q50_pct", 5.6), ("mae_q50_pct", -3.4), ("dip8_pct", 12.4)):
        pm[c] = v
    pm["up5_pct"] = rng.uniform(30, 70, len(pm)).round(1)
    pm["up10_pct"] = rng.uniform(5, 25, len(pm)).round(1)
    pm["stuck_pct"] = np.nan                                   # not shown -> the raw number is
    pm["raw_stuck_pct"] = 2.25
    pm["raw_up5_pct"] = 50.0
    pm["conf_marks"] = "up5=CALIBRATED|up10=CALIBRATED|dip8=MISCALIBRATED|stuck=UNCORRECTED|profit=NO SKILL"
    pm["code"] = "pick_meta v1.3"
    pm["conf_run"] = "PC_TEST_001"
    fw = root / "research2" / "pick_meta" / "forward"
    fw.mkdir(parents=True, exist_ok=True)
    pm.to_csv(fw / f"PM_cards_{d:%Y%m%d}.csv", index=False)
    md = [f"# Paper watchlist for the open after {d:%Y-%m-%d}", "", "pre-open: buy the first 3", "", "## D", "",
          "| rank | symbol | score |", "|---|---|---|"] + [f"| {r} | {s} | 0.5 |" for r, s in zip(W["rank"], W["symbol"])]
    md += ["", "## Soul cards", ""]
    for s in W["symbol"].unique():
        md += [f"### {s} (D)", "", f"**Personality** SOUL-UNIQUE-{s} target first 41%.", "", "| what | value |",
               "|---|---|", "| own MFE | +5.2% |", "", "**Memory** 20 own analogues.", "- record: 3 picks", ""]
    md += ["## Notes", "", "the end"]
    (pdir / "watchlists" / f"WL_{d:%Y%m%d}.md").write_text("\n".join(md), encoding="utf-8")
    return d


def res_cards(H: str) -> list:
    import re
    return re.findall(r"<div class='card' id='c-", H)


def _snapshot(root: Path) -> dict:
    """Every file under the fake cache (the test's stand-in modules in _mods are not production data)."""
    return {str(p.relative_to(root)): (p.stat().st_size, p.stat().st_mtime_ns) for p in root.rglob("*")
            if p.is_file() and "_mods" not in p.relative_to(root).parts}


def _watch(check, quiet, fresh_modules, TMP: Path, LAB: Path) -> None:
    from tl_common import sha256_file
    info = CW.make_ctx_world(TMP / "watch_world", "absent", 5, n_days=420)
    root = info["root"]
    fresh_modules(root)
    import tl_state as S
    import tl_watch as WT
    import tl_context as C
    import tl_dictionary as DD
    day_idx = 400
    planted = _write_planted(root, info["days"], day_idx)
    day = _paper(root, info, day_idx, planted)
    out = TMP / "watch_out"
    snap = _snapshot(root)
    led_sha = sha256_file(root / "paper" / "ledger.jsonl")
    pm_sha = sha256_file(root / "research2" / "pick_meta" / "forward" / f"PM_cards_{day:%Y%m%d}.csv")
    rc, log = quiet(WT.main, ["--root", str(root), "--out", str(out), "--stage-e-any"])
    wdir = out / "watch"
    files = {k: wdir / f"{p}_{day:%Y%m%d}.{e}" for k, p, e in (("html", "WATCH", "html"), ("md", "WATCH", "md"),
                                                                  ("csv", "WATCH", "csv"), ("json", "watch", "json"))}
    check(rc == 0 and all(f.exists() for f in files.values()) and "WATCHLIST for the open after" in log,
          "tl_watch: the latest recorded day (from the paper ledger) -> page, text, table, settings; console summary")
    R = pd.read_csv(files["csv"])
    J = json.loads(files["json"].read_text(encoding="utf-8"))
    H = files["html"].read_text(encoding="utf-8")
    M = files["md"].read_text(encoding="utf-8")
    check(len(R) == 20 and list(R["engine"].unique()) == ["D", "ENS"] and (R.groupby("engine")["rank"].apply(list).map(
        lambda x: x == list(range(1, 11)))).all(), "20 rows: D ranks 1-10 then ENS ranks 1-10, as recorded (an unreadable "
                                                   "ledger line skipped)")
    # planted states = tl_state on the same file, = the planted truth
    want = {"PLTUP": "S01", "PLTDN": "S08", "PLTWILD": "S12"}
    ok = True
    for sym in planted:
        d = pd.read_parquet(root / f"{sym}_daily.parquet")
        ss = SW.series(d, sym)
        i = ss.n - 1
        row = R[(R["symbol"] == sym) & (R["engine"] == "D")].iloc[0]
        ok &= row["state"] == ss.state[i] and str(row["confidence"]) == ss.confidence[i] and int(row["age"]) == ss.age[i]
        ok &= (str(row["event"]) if pd.notna(row["event"]) else "") == ss.ev_kind[i]
    pr = R.set_index("symbol")
    check(ok and all(pr.loc[s, "state"] == v for s, v in want.items()) and pr.loc["PLTTRAP", "event"] == "FAILED_BREAKOUT",
          "planted stocks on the page: PLTUP S01, PLTDN S08, PLTWILD S12, PLTTRAP S11 failed breakout - each = tl_state "
          "on its own bars (state, confidence, age, event)")
    # market columns = tl_context's frame on that day
    import tl_data as D
    m = D.Market(root, D.Production(stage_e_any=True))
    ctx = C.build_context(type("W", (), {"market": m, "root": root})(), "full", TMP / "watch_ctx_check", log=lambda *_: None)
    fr = ctx.frame.set_index("date").loc[pd.Timestamp(day)]
    ok = all(R["environment"].fillna("") == (fr["environment"] or "")) and np.allclose(R["breadth"], fr["ad_ratio"]) and \
        np.allclose(R["vix"], fr["vix"]) and np.allclose(R["breadth_10d"], fr["ad_ratio_10"], equal_nan=True)
    X = ctx.pick_context(R.assign(signal_day=pd.Timestamp(day))[["signal_day", "symbol"]])
    ok &= np.allclose(R["beta_home"].to_numpy(float), X["pre_beta_home"].to_numpy(float), equal_nan=True) and \
        all(R["size_class"].fillna("") == X["pre_size_class"].fillna(""))
    check(ok, f"market columns = tl_context on that day (environment '{fr['environment']}', breadth, VIX, size, beta)")
    # relative strength by hand for one AMFI-classified stock
    one = R[R["size_class"].isin(["large", "mid", "small"])].iloc[0]
    k = {"large": "nifty", "mid": "mid", "small": "small"}[one["size_class"]]
    ds = m.series(one["symbol"])
    i = ds.idx(np.datetime64(day.date()))
    p = ctx.ib.pos1(day)
    a = ctx.ib.a[k]["close"]
    rs = (ds.c[i] / ds.c[i - 20] - 1) - (a[p] / a[p - 20] - 1)
    check(abs(rs - one["rs20_size"]) < 1e-8, f"relative strength vs its AMFI size index by hand ({one['symbol']}: "
                                             f"{rs:+.4f})")
    # pick_meta numbers and marks
    pm = pd.read_csv(root / "research2" / "pick_meta" / "forward" / f"PM_cards_{day:%Y%m%d}.csv")
    J2 = R.merge(pm, on=["engine", "rank", "symbol"], suffixes=("", "_pm"))
    check(len(J2) == 20 and np.allclose(J2["pm_up5"], J2["up5_pct"]) and np.allclose(J2["pm_stuck"], 2.25) and
          (J2["pm_dip8_mark"] == "!").all() and (J2["pm_stuck_mark"] == "(raw)").all() and
          "12% !" in H and "2.2% (raw)" in H,
          "pick_meta: the number its card shows (up5_pct; raw when the corrected one is blank) with its marks "
          "(! failed check, (raw) not corrected)")
    v12, mk = WT.pm_value({"p_plus5_pct": 44.0, "conf_marks": ""}, "up5")
    check(v12 == 44.0 and mk == "", "pick_meta v1.2 cards read too (p_plus5_pct)")
    # Soul verbatim
    souls = all(f"SOUL-UNIQUE-{s}" in H and f"SOUL-UNIQUE-{s}" in M for s in R["symbol"].unique())
    check(souls and R["soul_found"].all() and "the end" not in H.split("Soul (the paper")[1][:2000],
          "the paper watchlist's Soul card of every stock copied verbatim (its own section only)")
    # page content: market first, states, evidence
    check(H.index("MARKET at the close") < H.index("D - top 10") < H.index("Stock cards") and "Why S01" in H and
          "invalidation" in H and "transitions" in H and "Soul (the paper watchlist" in H and
          not re.search(r"\bnan\b", H + M, flags=re.I),
          "page: market banner first, then D / ENS tables, then a card per stock (state, evidence, invalidation, "
          "transitions, measurements, Soul); no 'nan' in the text")
    # declared warning signs re-derived from the page's own columns
    tw = {"W1": R["high_stress"] == 1, "W4": R["breadth_10d"] < 0.40, "W5": R["vix_chg5"] >= 0.15,
          "W7": R["nifty_minus_small_20"] >= 0.03, "W8": R["beta_home"] >= 1.5}
    got = R["warnings"].fillna("").astype(str)
    ok = all(((got.str.split(",").map(lambda x: w in x)) == m.fillna(False)).all() for w, m in tw.items())
    b15 = R[R["symbol"] == "BETA15"].iloc[0]
    check(ok and (("W8 high beta" in H) == bool(tw["W8"].any())) and "Declared warning signs at this close" in H and
          abs(b15["beta_home"] - 1.5) < 1e-6 and b15["home_index"] == "Smallcap 250",
          f"declared warning signs W1 / W4 / W5 / W7 / W8 re-derived from the page's columns; BETA15 (1.5 x Smallcap by "
          f"construction) beta {b15['beta_home']:.6f} to Smallcap 250, W8 {'flagged' if 'W8' in str(b15['warnings']) else 'not flagged'}")
    check(H.count("last 20 sessions") >= len(res_cards(H)) and "Last 20 sessions:" in M,
          "every card shows the state of its last 20 sessions")
    und = DD.undocumented("watch", list(R.columns))
    check(not und and (wdir / "DATA_DICTIONARY.md").exists(), f"every CSV column documented ({len(R.columns)}) {und}")
    check(J["state_settings_hash"] == S.cfg_hash(S.STATE_CFG) and J["state_settings"]["confirm_n"] == 2 and
          J["pick_meta"]["sha256"] == pm_sha and J["ledger"]["unreadable_lines"] == 1,
          "settings, their fingerprint and the inputs' SHA-256 recorded with the page")
    # nothing written into production
    snap2 = _snapshot(root)
    check(snap == snap2 and sha256_file(root / "paper" / "ledger.jsonl") == led_sha,
          "nothing written or changed under the cache: paper ledger, pick_meta's cards, the paper watchlist, bars")
    # rerun / force / index
    idx = [json.loads(x) for x in (wdir / "index.jsonl").read_text().splitlines()]
    rc2, log2 = quiet(WT.main, ["--root", str(root), "--out", str(out), "--stage-e-any"])
    idx2 = [json.loads(x) for x in (wdir / "index.jsonl").read_text().splitlines()]
    rc3, _ = quiet(WT.main, ["--root", str(root), "--out", str(out), "--stage-e-any", "--force",
                             "--date", f"{day:%Y-%m-%d}"])
    idx3 = [json.loads(x) for x in (wdir / "index.jsonl").read_text().splitlines()]
    check(rc2 == 0 and "already written" in log2 and len(idx2) == len(idx) == 1 and rc3 == 0 and len(idx3) == 2 and
          idx3[1]["rewrite"] and idx3[0]["files"][files["html"].name] == idx[0]["files"][files["html"].name] and
          all(len(v) == 64 for v in idx3[1]["files"].values()),
          "a day already written is skipped; --force rewrites it; index.jsonl keeps a line (SHA-256 of each file) per write")
    import datetime as dt
    d0 = pd.Timestamp("2026-10-23")      # a Friday: the next weekday is Monday
    check(not WT.is_late(dt.datetime(2026, 10, 23, 23, 50), d0) and not WT.is_late(dt.datetime(2026, 10, 26, 8, 59), d0)
          and WT.is_late(dt.datetime(2026, 10, 26, 9, 0), d0), "LATE = written at or after 09:00 of the next weekday")
    rc4, log4 = quiet(WT.main, ["--root", str(root), "--out", str(out), "--stage-e-any", "--date", "2030-01-01"])
    check(rc4 == 2 and "no watchlist recorded" in log4, "a day with no recorded watchlist is refused with the latest days")
    # point in time: every bar after the watch day scrambled
    import test_context as TC
    sc = TMP / "watch_world_scr"
    TC.scramble_after(root, sc, pd.Timestamp(day), seed=9)
    # extend: give the scrambled world 5 later sessions so 'after' exists for every stock
    for f in sc.glob("*_daily.parquet"):
        d = pd.read_parquet(f)
        last = d.iloc[[-1] * 5].copy()
        ts = pd.to_datetime(d["timestamp"]).iloc[-1]
        last["timestamp"] = [ts + pd.offsets.BDay(j) for j in range(1, 6)]
        rng = np.random.default_rng(len(f.name))
        kf = np.exp(rng.normal(0, 0.1, 5))
        for col in ("open", "high", "low", "close"):
            last[col] = last[col].to_numpy(float) * kf
        pd.concat([d, last], ignore_index=True).to_parquet(f, index=False)
    fresh_modules(sc)
    import tl_watch as WT2
    rc5, _ = quiet(WT2.main, ["--root", str(sc), "--out", str(TMP / "watch_out_scr"), "--stage-e-any", "--date",
                              f"{day:%Y-%m-%d}"])
    R2 = pd.read_csv(TMP / "watch_out_scr" / "watch" / f"WATCH_{day:%Y%m%d}.csv")
    cols = [c for c in R.columns if c not in ("recorded_at",)]
    ok = rc5 == 0 and all(same(R[c].to_numpy(), R2[c].to_numpy()) for c in cols)
    bad = [c for c in cols if not same(R[c].to_numpy(), R2[c].to_numpy())]
    check(ok, f"point in time: every bar after the signal day changed (and 5 more sessions added) -> every column of "
              f"the page's table unchanged {bad[:5]}")
    fresh_modules(root)
    import tl_watch as WT3
    # a missing pick_meta card and a stock without a bar on the day
    pmf = root / "research2" / "pick_meta" / "forward" / f"PM_cards_{day:%Y%m%d}.csv"
    hid = pmf.with_suffix(".hidden")
    pmf.rename(hid)
    led = root / "paper" / "ledger.jsonl"
    raw = led.read_bytes()
    try:
        L = raw.decode("utf-8").splitlines()
        L = [x.replace('"symbol": "PLTUP"', '"symbol": "NOBARS"') if f'"{day:%Y-%m-%d}"' in x else x for x in L]
        led.write_text("\n".join(L) + "\n", encoding="utf-8")
        res = WT3.build(root, pd.Timestamp(day), "saved", TMP / "watch_out", True, True, lambda *_: None)
        Rm = res["rows"]
        H2, M2, C2 = WT3.to_html(res), WT3.to_md(res), WT3.console(res)
        check((~Rm["pm_found"]).all() and Rm.set_index("symbol").loc["NOBARS", "state_name"] == "no daily bars" and
              "NOBARS" not in res["cards"] and len(res["cards"]) == Rm[Rm["state"].fillna("") != ""]["symbol"].nunique()
              and "no daily bars" in H2 and "NOBARS" in M2 and "NOBARS" in C2 and
              not re.search(r"\bnan\b", H2 + M2 + C2, flags=re.I),
              "no pick_meta card -> the page is still built (pm columns blank); a stock without bars -> said so on the "
              "page, no card, no 'nan' anywhere")
    finally:
        hid.rename(pmf)
        led.write_bytes(raw)


def _export(check, quiet, fresh_modules, TMP: Path, LAB: Path) -> None:
    """The export made by section 10 (tradelab v1.3): state columns, breakdown, research, cards, a state filter."""
    exs = sorted((TMP / "out_ctx" / "export").glob("TLX_*"))
    if not exs:
        check(False, "section 10's export folder exists")
        return
    ex = exs[0]
    root = TMP / "ctx_planted"
    fresh_modules(root)
    import tl_state as S
    T = pd.read_parquet(ex / "trades.parquet")
    have = [c for c in S.STATE_PICK_COLUMNS if c in T.columns]
    check(len(have) == len(S.STATE_PICK_COLUMNS), f"export: every pre_state_* column in trades ({len(have)})")
    rng = np.random.default_rng(1)
    pick = rng.choice(len(T), size=min(40, len(T)), replace=False)
    ok = True
    cache = {}
    for j in pick:
        r = T.iloc[j]
        sym = r["symbol"]
        if sym not in cache:
            cache[sym] = SW.series(pd.read_parquet(root / f"{sym}_daily.parquet"), sym)
        ss = cache[sym]
        i = ss.idx(np.datetime64(pd.Timestamp(r["signal_day"]).date()))
        exp = ss.pick_columns(i)
        ok &= all(same([r[c]], [exp[c]]) for c in S.STATE_PICK_COLUMNS)
    check(ok, "export: pre_state_* of 40 random picks = tl_state on the stock's own bars at the signal day")
    B = pd.read_csv(ex / "context_breakdown.csv")
    check({"stock state at the pick", "state phase at the pick", "event in the last 10 sessions"} <= set(B["dimension"]),
          "context breakdown has the state, phase and event dimensions (known before entry)")
    SB = pd.read_csv(ex / "research" / "state_book.csv")
    rep = (ex / "research" / "research_report.md").read_text(encoding="utf-8")
    Tt = T[T["traded"] & (T["status"] == "ok")].copy()
    e0 = "D"
    G = Tt[Tt["engine"] == e0]
    row = SB[(SB["engine"] == e0) & (SB["grouping"] == "phase, all states") & (SB["cell"] == "MATURE")].iloc[0]
    f = (G["pre_state_phase"] == "MATURE").to_numpy()
    known = (G["pre_state_phase"].fillna("") != "").to_numpy()
    mm = G["net_bp"][f].mean()
    dd = mm - G["net_bp"][known & ~f].mean()
    check(abs(row["net_bp_mean"] - mm) < 1e-6 and abs(row["diff_vs_rest_bp"] - dd) < 1e-6 and row["trades"] == f.sum(),
          f"research state book by hand: D MATURE {mm:+.1f} bp ({int(f.sum())} trades), vs the rest {dd:+.1f} bp")
    check("## 6. Stock states at the pick" in rep and "research-declaration-3" in rep and "DESCRIPTIVE ONLY" in rep and
          "by the phase of the stock's state" in rep, "research report: section 6 (declared, descriptive) and a "
                                                       "verdict-first line by phase")
    import tl_cards as TCD
    days = pd.read_parquet(ex / "trade_days.parquet")
    mk = pd.read_parquet(ex / "market_days.parquet")
    t0 = Tt.iloc[0].to_dict()
    md = TCD.card_md(t0, days[days["trade_id"] == t0["trade_id"]], mk)
    check("Its state (tl_state" in md and S.pick_headline(t0) in md, "trade card: the stock's state at the pick")
    # a backtest filter on a state attribute (rules can read pre_state_* numbers)
    strat = TMP / "state_filter.py"
    strat.write_text('STRATEGY = {"name": "skip_unstable", "mode": "daily", "picks": {"engines": ["D"], "ranks": [1, 2, 3], '
                     '"filter": "pre_state_num != 12 and pre_state_overextended < 2"}, "max_sessions": 5, '
                     '"entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}], '
                     '"exits": [{"name": "time", "type": "time", "at": "close", "session": 5}], '
                     '"costs": {"model": "flat", "round_trip_bp": 35}}\n', encoding="utf-8")
    import tl_backtest as BT
    rc, log = quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(TMP / "bt_state"),
                              "--stage-e-any", "--strategy", str(strat), "--context", "indices"])
    bts = sorted((TMP / "bt_state" / "backtest").glob("*"))
    check(rc == 0 and len(bts) == 1, f"tl_backtest runs a strategy that filters on pre_state_* (rc {rc})")


# ----------------------------------------------------------------------
def _v131(check, quiet, fresh_modules, TMP: Path, LAB: Path) -> None:
    root = TMP / "watch_world"
    out = TMP / "watch_out"
    if not (root / "paper" / "ledger.jsonl").exists():
        check(False, "section 15's watch world exists")
        return
    fresh_modules(root)
    import tl_watch as WT
    import tl_state as S
    wdir = out / "watch"
    L = WT.read_ledger(root)
    days = sorted(pd.to_datetime(L["signal_day"].unique()))
    before = sorted(p.name for p in wdir.glob("WATCH_*.html"))
    n_idx = len((wdir / "index.jsonl").read_text().splitlines())
    rc, log = quiet(WT.main, ["--root", str(root), "--out", str(out), "--stage-e-any", "--all-missing"])
    after = sorted(p.name for p in wdir.glob("WATCH_*.html"))
    idx = [json.loads(x) for x in (wdir / "index.jsonl").read_text().splitlines()]
    new = idx[n_idx:]
    want = [f"WATCH_{d:%Y%m%d}.html" for d in days]
    check(rc == 0 and after == want and len(before) == 1 and len(new) == len(days) - 1 and all(x["late"] for x in new)
          and "missing page(s)" in log and "already had its page" in log,
          f"--all-missing: a page for each of the {len(days) - 1} recorded days without one (oldest first, all marked "
          f"LATE: built after their time), the existing page untouched")
    A = pd.read_csv(wdir / "watch_all.csv")
    parts = [pd.read_csv(wdir / f"WATCH_{d:%Y%m%d}.csv") for d in days]
    check(len(A) == sum(len(x) for x in parts) and {"page_written_at", "page_late"} <= set(A.columns) and
          list(pd.to_datetime(A["date"]).drop_duplicates()) == days and A["state"].notna().all(),
          f"watch_all.csv: every page's rows in one table ({len(A)} rows, {len(days)} days) with when each was written")
    # a page built in the catch-up = the same day built on its own (nothing leaks between days)
    d1 = days[0]
    rc2, _ = quiet(WT.main, ["--root", str(root), "--out", str(TMP / "watch_out_one"), "--stage-e-any",
                             "--date", f"{d1:%Y-%m-%d}"])
    X1 = pd.read_csv(wdir / f"WATCH_{d1:%Y%m%d}.csv")
    X2 = pd.read_csv(TMP / "watch_out_one" / "watch" / f"WATCH_{d1:%Y%m%d}.csv")
    check(rc2 == 0 and list(X1.columns) == list(X2.columns) and all(same(X1[c].to_numpy(), X2[c].to_numpy()) for c in X1.columns),
          f"a catch-up page = the same day built on its own, every column ({d1:%Y-%m-%d})")
    rc3, log3 = quiet(WT.main, ["--root", str(root), "--out", str(out), "--stage-e-any", "--all-missing"])
    n3 = len((wdir / "index.jsonl").read_text().splitlines())
    check(rc3 == 0 and "nothing new" in log3 and n3 == len(idx), "run again: nothing new, nothing rewritten")
    import tl_dictionary as DD
    check(not DD.undocumented("watch_all", list(A.columns)), "every watch_all.csv column documented")
    # an earlier day that cannot be built never stops tonight's page; tonight's failing is an error
    from tl_common import TLError as TLE
    orig = WT.build_day

    def boom(P, d, soul=True, log=None, bad=days[1], err=RuntimeError("planted failure")):
        if d == bad:
            raise err
        return orig(P, d, soul, log)

    o8 = TMP / "watch_out_fail"
    shutil.rmtree(o8, ignore_errors=True)
    WT.build_day = boom
    try:
        rc8, log8 = quiet(WT.main, ["--root", str(root), "--out", str(o8), "--stage-e-any", "--all-missing"])
        WT.build_day = lambda P, d, soul=True, log=None: boom(P, d, soul, log, days[-1], TLE("planted: tonight fails"))
        rc9, log9 = quiet(WT.main, ["--root", str(root), "--out", str(TMP / "watch_out_fail2"), "--stage-e-any",
                                    "--all-missing"])
    finally:
        WT.build_day = orig
    b8 = sorted(x.name for x in (o8 / "watch").glob("WATCH_*.html"))
    check(rc8 == 0 and b8 == [f"WATCH_{d:%Y%m%d}.html" for d in days if d != days[1]] and
          "NOT BUILT - RuntimeError: planted failure" in log8 and "1 earlier day(s) could not be built" in log8 and
          rc9 == 2 and "could not be built" in log9,
          "an earlier day that fails (an unexpected error, planted) is reported and skipped - tonight's page is still "
          "built; tonight's day failing stops with exit 2")

    # --- the one-click nightly runner: read as text here, then executed for real (_tonight_exec)
    raw = (LAB / "run_tonight.bat").read_bytes()
    t = raw.decode("ascii")
    labels = re.findall(r"^:(\w+)", t, re.M)
    targets = set(re.findall(r"goto :(\w+)", t)) | set(re.findall(r"call :(\w+)", t))
    i_run, i_pub = t.index('cmd /c ""%TN_RUN_NOW%""'), t.index("pick_meta.py publish")
    i_sco, i_w = t.index("pick_meta.py score"), t.index("tl_watch.py --root")
    i_su = t.index("setuplab.py scan")
    depth, ok_par = 0, True
    for ln in t.split("\r\n"):
        if ln.strip().lower().startswith("rem"):
            continue
        q = False
        for ch in ln:
            if ch == '"':
                q = not q
            elif not q and ch in "()":
                depth += 1 if ch == "(" else -1
                ok_par &= depth >= 0
    sets_with_paren = [m for m in re.findall(r'set "\w+=([^"]*)"', t) if "(" in m or ")" in m]
    check(raw.count(b"\n") == raw.count(b"\r\n") and len(labels) == len(set(labels)) and targets <= set(labels) | {"eof"}
          and all(b < 128 for b in raw) and ok_par and depth == 0 and not sets_with_paren,
          f"run_tonight.bat: CRLF, ASCII, labels unique {labels}, every goto / call target exists, parentheses "
          f"balanced, no value holding a parenthesis (it would break an if-block)")
    check(i_run < i_pub < i_sco < i_su < i_w and 'set "TN_RUN_NOW=%BIGMOVE_DIR%\\run_now.bat"' in t and
          'cmd /c ""%TN_RUN_NOW%"" <nul' in t and "--all-missing" in t[i_pub:i_sco] and "--all-missing" in t[i_w:] and
          "--all-missing" in t[i_su:i_w] and '--out "%SETUPLAB_OUT%"' in t[i_su:i_w] and
          'set "PYTHONPATH=%BIGMOVE_DIR%"' in t and "goto :finish" not in t and 'if not defined TN_AUTO pause' in t
          and "/o-n" in t and "exit /b %TN_RC%" in t and "tonight_log.txt" in t,
          "run_tonight.bat runs Run Now unchanged (run_now.bat, in a child cmd, from its own folder; no keyboard with "
          "'auto'), then pick_meta publish --all-missing and score, then the setup scan --all-missing (setups add-on), "
          "then tl_watch --all-missing; every step runs and is reported; one pause, none with 'auto'; logs every run")
    _tonight_exec(check, TMP, LAB)
    # tl_check shows what run_tonight.bat will start (read, never run)
    import tl_check as K
    big = TMP / "tonight_check" / "bigmove_deploy"
    shutil.rmtree(big.parent, ignore_errors=True)
    (big / "open_close").mkdir(parents=True)
    (big / "run_now.bat").write_bytes(b"@echo off\r\nREM the stand-in Run Now\r\ncall daily_run.bat\r\npause\r\n")
    (big / "env_daily.bat").write_bytes(b"@echo off\r\n")
    (big / "open_close" / "pick_meta.py").write_text("#\n", encoding="utf-8")
    (big / "open_close" / "run_pick_meta.bat").write_bytes(
        b'@echo off\r\npython pick_meta.py publish --root "%CACHE_DAILY_ROOT%"\r\n'
        b'python pick_meta.py score --root "%CACHE_DAILY_ROOT%"\r\npause\r\n')
    sul = big.parent / "setuplab"
    sul.mkdir(parents=True, exist_ok=True)
    (sul / "setuplab.py").write_text("#\n", encoding="utf-8")
    (sul / "FROZEN_SETUPS.json").write_text("{}\n", encoding="utf-8")
    l1, w1 = K.tonight_lines(LAB / "run_tonight.bat", str(big), str(sul))
    j1 = "\n".join(l1)
    l4, w4 = K.tonight_lines(LAB / "run_tonight.bat", str(big), str(big.parent / "no_setuplab"))
    (big / "run_now.bat").write_bytes(b'@echo off\r\nstart "nightly" cmd /k daily_run.bat\r\n')
    l3, w3 = K.tonight_lines(LAB / "run_tonight.bat", str(big), str(sul))
    (big / "open_close" / "run_pick_meta.bat").write_bytes(b"@echo off\r\npython pick_meta.py publish --root x\r\n"
                                                          b"python other_tool.py go\r\n")
    (big / "run_now.bat").unlink()
    l2, w2 = K.tonight_lines(LAB / "run_tonight.bat", str(big), str(sul))
    check(not w1 and "its commands (2): call daily_run.bat | pause" in j1 and "Run Now pauses" in j1 and
          "step 3 (setup scan)" in j1 and "freeze file found" in j1 and
          any("setuplab.py not found" in w for w in w4) and
          "python pick_meta.py publish" in j1 and any("another window (START)" in w for w in w3) and
          any("Run Now's file not found" in w for w in w2) and any("other_tool.py" in w for w in w2),
          "tl_check shows what run_tonight.bat will start: Run Now's file and its commands, run_pick_meta.bat's python "
          "lines; it warns when Run Now is missing, hands its work to another window (START: nothing could wait for "
          "it), or run_pick_meta.bat runs something step 2 does not")
    rw = (LAB / "run_watch.bat").read_bytes().decode("ascii")
    check("/o-n" in rw and "/o-d" not in rw, "run_watch.bat opens the newest DAY's page (by name), not the last file written")

    # --- the backtest: the state at every pick and in 'where it helps or hurts'
    wroot = TMP / "ctx_planted"
    fresh_modules(wroot)
    import tl_backtest as BT
    rc4, log4 = quiet(BT.main, ["--root", str(wroot), "--pm-run", "PM_TEST_001", "--out", str(TMP / "bt_v131"),
                                "--stage-e-any", "--strategy", str(LAB / "strategies" / "plan.py"), "--context", "indices",
                                "--no-portfolio"])
    bt = sorted((TMP / "bt_v131" / "backtest").glob("TLB_*"))
    ok = rc4 == 0 and len(bt) == 1
    if ok:
        A2 = pd.read_parquet(bt[0] / "trades.parquet")
        B2 = pd.read_csv(bt[0] / "context_breakdown.csv")
        rep = (bt[0] / "report.md").read_text(encoding="utf-8")
        cache = {}
        good = True
        rng = np.random.default_rng(3)
        for j in rng.choice(len(A2), size=min(25, len(A2)), replace=False):
            r = A2.iloc[j]
            sym = r["symbol"]
            if sym not in cache:
                cache[sym] = SW.series(pd.read_parquet(wroot / f"{sym}_daily.parquet"), sym)
            ss = cache[sym]
            i = ss.idx(np.datetime64(pd.Timestamp(r["signal_day"]).date()))
            exp = ss.pick_columns(i)
            good &= all(same([r[c]], [exp[c]]) for c in S.STATE_PICK_COLUMNS)
        ok = good and {"stock state at the pick", "state phase at the pick"} <= set(B2["dimension"]) and \
            "stock's state at the pick" in rep
    check(ok, "tl_backtest: every pick carries its state at the signal day (= tl_state, 25 picks by hand) and the "
              "paired table adds the state, phase, confidence, event, S05 and volatility dimensions")
    rc5, _ = quiet(BT.main, ["--root", str(wroot), "--pm-run", "PM_TEST_001", "--out", str(TMP / "bt_v131n"),
                             "--stage-e-any", "--strategy", str(LAB / "strategies" / "plan.py"), "--context", "none",
                             "--no-portfolio"])
    btn = sorted((TMP / "bt_v131n" / "backtest").glob("TLB_*"))
    check(rc5 == 0 and len(btn) == 1 and not any(c.startswith("pre_state") for c in
                                                 pd.read_parquet(btn[0] / "trades.parquet").columns),
          "--context none: no states (exactly the v1 tables)")

    # --- the simulator: the state at the pick and through the trade
    import tl_sim as SIM
    T0 = A2.sort_values(["signal_day", "rank"]).iloc[len(A2) // 2] if ok else None
    if T0 is not None:
        tid = T0["trade_id"]
        rc6, log6 = quiet(SIM.main, ["--root", str(wroot), "--pm-run", "PM_TEST_001", "--out", str(TMP / "sim_v131"),
                                     "--stage-e-any", "--trade", tid, "--context", "indices"])
        sim = sorted((TMP / "sim_v131" / "sim").glob("TLS_*"))
        story = (sim[0] / f"{tid}__plan_story.md").read_text(encoding="utf-8") if sim else ""
        sym = T0["symbol"]
        ss = SW.series(pd.read_parquet(wroot / f"{sym}_daily.parquet"), sym)
        i0 = ss.idx(np.datetime64(pd.Timestamp(T0["signal_day"]).date()))
        rows = [ln for ln in story.splitlines() if re.match(r"^\| [0-9]+ \| ", ln) and ln.count("|") == 10]
        exp_rows = [f"| {k} | {ss.day(i0 + k):%a %d %b %Y} | {ss.c[i0 + k]:,.2f} | {ss.state[i0 + k]} | {ss.raw[i0 + k]} |"
                    for k in range(0, 6) if i0 + k < ss.n]
        check(rc6 == 0 and "### The stock's state" in story and ss.row(i0)["headline"] in story and
              len(rows) >= len(exp_rows) and all(any(x.startswith(e) for x in rows) for e in exp_rows),
              f"tl_sim: the story shows the state at the pick (known before entry) and each session's state through the "
              f"trade (= tl_state, {len(exp_rows)} sessions)")
        rc7, _ = quiet(SIM.main, ["--root", str(wroot), "--pm-run", "PM_TEST_001", "--out", str(TMP / "sim_v131n"),
                                  "--stage-e-any", "--trade", tid, "--context", "none"])
        simn = sorted((TMP / "sim_v131n" / "sim").glob("TLS_*"))
        storyn = (simn[0] / f"{tid}__plan_story.md").read_text(encoding="utf-8") if simn else ""
        check(rc7 == 0 and "### The stock's state" not in storyn and storyn, "--context none: the story as in v1")

    # --- 'what would end it' never contradicts the state it describes (v1.3 printed the bare swing level: a close
    #     just under it - inside the 0.25 ATR tolerance - while the state held read as a contradiction)
    n_chk, bad, old_bad = 0, [], 0
    for f in sorted(wroot.glob("*_daily.parquet"))[:80]:
        sym = f.name[:-len("_daily.parquet")]
        ss = SW.series(pd.read_parquet(f), sym)
        for i in range(ss.n):
            st = ss.state[i]
            if st not in ("S01", "S02", "S08", "S09") or ss.raw[i] != st:
                continue
            m = re.search(r"closing (below|above) (-?[0-9,]+\.[0-9]+) \(.*?EMA50 (-?[0-9,]+\.[0-9]+)", ss.invalidation(i))
            if m is None:
                bad.append((sym, i, "unparsed"))
                continue
            lvl, e50 = float(m.group(2).replace(",", "")), float(m.group(3).replace(",", ""))
            c = ss.c[i]
            ok = (c >= lvl - 0.006) if m.group(1) == "below" else (c <= lvl + 0.006)
            if st in ("S01", "S02"):
                ok &= c > e50 - 0.006
            if st == "S08":
                ok &= c < e50 + 0.006
            n_chk += 1
            if not ok:
                bad.append((sym, i, st, c, lvl, e50))
            lo, hi = ss.A["last_lo"][i], ss.A["last_hi"][i]
            old_bad += int((st in ("S01", "S02") and c < lo) or (st in ("S08", "S09") and c > hi))
    check(n_chk > 1000 and not bad and old_bad > 0,
          f"'what would end it' never contradicts the state: on {n_chk:,} sessions where S01 / S02 / S08 / S09 was "
          f"re-read, the close is on the right side of every printed level (the swing level less / plus 0.25 ATR, "
          f"EMA50); v1.3's bare swing level was contradicted on {old_bad} of them {bad[:3]}")
    import tl_state as S2
    shipped = (LAB / "STATE_RULES.md").read_text(encoding="utf-8")
    check(shipped == S2.rules_md() and "closing below the last higher low less 0.25 ATR" in shipped and
          "2 sessions in a row" in shipped, "STATE_RULES.md as shipped = what tl_state.py rules writes (the tolerance "
                                            "and the 2-session confirmation in every invalidation)")


# ----------------------------------------------------------------------
TONIGHT_STUB = r"""import os, sys
sub = sys.argv[1] if len(sys.argv) > 1 else ""
rc = int(os.environ.get(("STUB_RC_PM_" + sub) if "pick_meta" in sys.argv[0] else
                        ("STUB_RC_SCAN" if "setuplab" in sys.argv[0] else "STUB_RC_WATCH"), "0") or 0)
with open(os.environ["STUB_LOG"], "a") as f:
    f.write("python " + " ".join("[%s]" % x for x in sys.argv) + " | cwd=%s | PYTHONPATH=%s | ROOT=%s | OUT=%s | LEAK=%s | rc=%d\n"
            % (os.getcwd(), os.environ.get("PYTHONPATH", ""), os.environ.get("CACHE_DAILY_ROOT", ""),
               os.environ.get("TRADELAB_OUT", ""), os.environ.get("LEAKVAR", ""), rc))
sys.exit(rc)
"""


def _tonight_exec(check, TMP: Path, LAB: Path) -> None:
    """run_tonight.bat and env_tradelab.bat as shipped (only their folders pointed at stand-ins), executed by cmd.exe:
    a stand-in Run Now (calls its daily_run.bat by a relative name, sets a variable, changes folder, pauses), stand-in
    env_daily.bat, pick_meta.py and tl_watch.py that record how they were called. Windows only (TL_TEST_WINE=<wine>
    runs it under wine)."""
    import os
    import subprocess
    wine = os.environ.get("TL_TEST_WINE", "")
    if os.name != "nt" and not wine:
        print("  skip  run_tonight.bat executed for real: Windows only - it runs when you run this suite on your PC")
        return

    def wp(x: Path) -> str:
        return str(x) if os.name == "nt" else "Z:" + str(x).replace("/", "\\")

    W = (TMP / "tonight").resolve()
    shutil.rmtree(W, ignore_errors=True)
    big, tl, out, cache = W / "bigmove_deploy", W / "tradelab", W / "out", W / "cache"
    su, su_out = W / "setuplab", W / "su_out"
    for d in (big / "open_close", tl, out, cache, su):
        d.mkdir(parents=True)
    calls = W / "calls.txt"

    def bat(path: Path, text: str) -> None:
        path.write_bytes(text.replace("\n", "\r\n").encode("ascii"))

    bat(big / "env_daily.bat", f'@echo off\nset "CACHE_DAILY_ROOT={wp(cache)}"\n')
    bat(big / "run_now.bat", '@echo off\nset /p "ANS=stand-in login prompt: "\n>>"%STUB_LOG%" echo run_now answer=[%ANS%]\n'
                             'call daily_run.bat\necho   (stand-in Run Now finished)\npause\n')
    bat(big / "daily_run.bat", '@echo off\n>>"%STUB_LOG%" echo daily_run cwd=%CD%\nset "LEAKVAR=from_run_now"\n'
                               'cd /d "%SystemRoot%"\nexit /b %STUB_RC_RUNNOW%\n')
    (big / "open_close" / "pick_meta.py").write_text(TONIGHT_STUB, encoding="utf-8")
    (tl / "tl_watch.py").write_text(TONIGHT_STUB, encoding="utf-8")
    (su / "setuplab.py").write_text(TONIGHT_STUB, encoding="utf-8")
    rt = (LAB / "run_tonight.bat").read_bytes().decode("ascii")       # bytes: keep the shipped CRLF line ends
    et = (LAB / "env_tradelab.bat").read_bytes().decode("ascii")
    pairs_rt = [("C:\\Users\\karanvsi\\PyCharmMiscProject\\bigmove_deploy", wp(big))]
    pairs_et = [('set "BIGMOVE_DIR=C:\\Users\\karanvsi\\PyCharmMiscProject\\bigmove_deploy"', f'set "BIGMOVE_DIR={wp(big)}"'),
                ('set "TRADELAB_DIR=C:\\Users\\karanvsi\\PyCharmMiscProject\\tradelab"', f'set "TRADELAB_DIR={wp(tl)}"'),
                ('set "TRADELAB_OUT=C:\\QuantData\\tradelab"', f'set "TRADELAB_OUT={wp(out)}"'),
                ('set "SETUPLAB_DIR=C:\\Users\\karanvsi\\PyCharmMiscProject\\setuplab"', f'set "SETUPLAB_DIR={wp(su)}"'),
                ('set "SETUPLAB_OUT=C:\\QuantData\\setuplab"', f'set "SETUPLAB_OUT={wp(su_out)}"')]
    ok = all(rt.count(a) == 1 for a, _ in pairs_rt) and all(et.count(a) == 1 for a, _ in pairs_et)
    for a, b in pairs_rt:
        rt = rt.replace(a, b)
    for a, b in pairs_et:
        et = et.replace(a, b)
    (tl / "run_tonight.bat").write_bytes(rt.encode("ascii"))
    (tl / "env_tradelab.bat").write_bytes(et.encode("ascii"))
    if not ok:
        check(False, "run_tonight.bat / env_tradelab.bat: the folders to point at the stand-ins were found once each")
        return

    def run(args, rcs, stdin=b""):
        if calls.exists():
            calls.unlink()
        env = dict(os.environ, STUB_LOG=wp(calls), STUB_RC_RUNNOW="0", STUB_RC_PM_publish="0", STUB_RC_PM_score="0",
                   STUB_RC_WATCH="0", STUB_RC_SCAN="0")
        env.update(rcs)
        for k in ("LEAKVAR", "CACHE_DAILY_ROOT", "PYTHONPATH", "TRADELAB_OUT", "SETUPLAB_DIR", "SETUPLAB_OUT"):
            env.pop(k, None)
        cmd = ([wine] if os.name != "nt" else []) + ["cmd", "/c", wp(tl / "run_tonight.bat")] + args
        if wine:
            env.update(WINEDEBUG="-all")
        p = subprocess.run(cmd, input=stdin, capture_output=True, env=env, cwd=str(W), timeout=300)
        txt = p.stdout.decode("latin-1").replace("\r", "")
        lines = calls.read_text(encoding="latin-1").replace("\r", "").splitlines() if calls.exists() else []
        return p.returncode, txt, lines

    root, pp_pm = wp(cache), wp(big)
    pp_tl = f"{wp(tl)};{wp(big / 'open_close')};{wp(big)}"
    rc, txt, L = run(["auto"], {}, stdin=b"NOT-FOR-RUN-NOW\r\n\r\n\r\n")
    want = ["run_now answer=[]", f"daily_run cwd={wp(big)}",
            f"python [pick_meta.py] [publish] [--root] [{root}] [--all-missing] | cwd={wp(big / 'open_close')} | "
            f"PYTHONPATH={pp_pm} | ROOT={root} | OUT= | LEAK= | rc=0",
            f"python [pick_meta.py] [score] [--root] [{root}] | cwd={wp(big / 'open_close')} | PYTHONPATH={pp_pm} | "
            f"ROOT={root} | OUT= | LEAK= | rc=0",
            f"python [setuplab.py] [scan] [--root] [{root}] [--out] [{wp(su_out)}] [--all-missing] | cwd={wp(su)} | "
            f"PYTHONPATH={pp_tl} | ROOT={root} | OUT={wp(out)} | LEAK= | rc=0",
            f"python [tl_watch.py] [--root] [{root}] [--all-missing] | cwd={wp(tl)} | PYTHONPATH={pp_tl} | ROOT={root} | "
            f"OUT={wp(out)} | LEAK= | rc=0"]
    tlog = (out / "tonight_log.txt").read_text(encoding="latin-1").splitlines() if (out / "tonight_log.txt").exists() else []
    after = txt[txt.find("RESULT"):] if "RESULT" in txt else txt
    check(rc == 0 and [x.strip() for x in L] == want and "RESULT: OK" in txt and "Press any key" not in after and
          len(tlog) == 1 and "run_now=0  pick_meta=0  setup_scan=0  tl_watch=0" in tlog[0],
          "run_tonight.bat executed (auto): Run Now from its own folder (its relative call works) with no keyboard "
          "(its prompt got nothing), then pick_meta publish / score in open_close with bigmove_deploy on PYTHONPATH, "
          "then the setup scan from setuplab's folder and tl_watch, both with env_tradelab.bat's settings; nothing Run "
          "Now set or its change of folder reached them; exit 0, one log line, no pause")
    if not (rc == 0 and [x.strip() for x in L] == want):
        print("        got:\n          " + "\n          ".join(L) + "\n        output:\n" + txt[-1500:])
    rc, txt, L = run(["auto"], {"STUB_RC_RUNNOW": "1", "STUB_RC_PM_publish": "2"})
    check(rc == 1 and len(L) == 6 and "RESULT: FAILED at [step 1 Run Now: code 1] [step 2 pick_meta: code 2]" in txt,
          "Run Now fails (1) and publish fails (2): score, the setup scan and tl_watch still run; RESULT names both "
          "steps; exit 1")
    rc, txt, L = run(["auto"], {"STUB_RC_SCAN": "3"})
    check(rc == 1 and len(L) == 6 and L[-1].startswith("python [tl_watch.py]") and
          "RESULT: FAILED at [step 3 setup scan: code 3]" in txt,
          "the setup scan fails (3): the watch page is still built; RESULT names the scan; exit 1")
    rc, txt, L = run([], {}, stdin=b"typed\r\n\r\n\r\n")
    k = next((j for j, x in enumerate(L) if x.startswith("daily_run cwd=")), len(L))
    check(rc == 0 and L[:1] != [] and L[0].startswith("run_now answer=[typed") and [x.strip() for x in L[k:]] == want[1:]
          and txt.count("Press any key") == 2,
          "double-click mode: the keyboard reaches Run Now (its prompt read what was typed); Run Now's own pause and "
          "the final pause wait for a key; the calls exactly as above")
