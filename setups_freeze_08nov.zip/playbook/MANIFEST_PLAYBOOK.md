# MANIFEST - playbook v1.1 (BMPB2, 1 Nov 2026, evening: panel selector, blind replay, dashboard, long-position boxes, paste split, journal) + pb_journal v1.1.1 (8 Nov: the frozen setups in the journal)

Folder: C:\Users\karanvsi\PyCharmMiscProject\playbook\ (next to v2engine\, tradelab\, pathlab\), replacing v1.0's
files. Needs: v2engine 0.3 (drop 3), tradelab v1.3.1, pathlab, bigmove_deploy's env_daily.bat; Python 3.12 / 3.13
with numpy and pandas. On TradingView: replace the whole script with BigMove_Playbook.pine (v1.1).
env_playbook.bat has CRLF line endings and labels no_v2, no_pb, v2_failed, no_root (no duplicates).
Outputs only under PB_OUT (C:\QuantData\playbook).

| file | lines | bytes | sha256 (first 16) |
|---|---|---|---|
| BigMove_Playbook.pine | 1584 | 112277 | 2eee4923bd94ccbc |
| README_PLAYBOOK.md | 173 | 13641 | afa7983d14268a68 |
| env_playbook.bat | 32 | 1436 | fc5b2d2f1856b7b3 |
| pb_core.py | 666 | 29484 | c4aed46449b8d421 |
| pb_journal.py | 350 | 19402 | 8db79d2fce7efe1e |
| playbook.py | 529 | 29236 | 85a9db807cad6427 |
| tests\data\NSE_IRCTC_1D.json | 5 | 11880 | ad7915077c26c2fe |
| tests\pb_mutate.py | 82 | 4550 | 0d1b88dafd95790e |
| tests\pine_lint.py | 383 | 18823 | 09b5f62b2a2cdc46 |
| tests\pine_twin.py | 267 | 10652 | 9640c4c9d4cd1109 |
| tests\test_playbook.py | 903 | 55479 | 14b041aecceb76f5 |

Verified 1 Nov 2026: 89 checks, 0 failed (full: 24,000 twin cases, the Pine linted with pynescript 0.3.0) on Python 3.13 / numpy 2.5.3 / pandas 3.0.5; 88 checks, 0 failed (quick) on Python 3.13 and on Python 3.12 / numpy 2.4.1 / pandas 2.3.3; 10 of 10 planted bugs caught (tests\pb_mutate.py); 4 of 4 planted Pine mistakes caught by the linter; the twin = pb_core on 3,740 cases on real NSE:IRCTC bars from TradingView. The Pine has not been compiled by TradingView.

Self-test: `python playbook.py --selftest quick` -> 92 checks, 0 failed, VERIFIED (playbook v1.1). The Pine is linted (0 errors) but not yet compiled by TradingView with the evening changes.

8 Nov 2026 (pb_journal v1.1.1): pb_journal.py, playbook.py (--setups), tests\test_playbook.py (p13e) and README_PLAYBOOK.md changed; everything else is v1.1 as shipped. Self-test: `python playbook.py --selftest quick` -> 93 checks, 0 failed, VERIFIED (playbook v1.1) (here: Python 3.13, with pathlab, tradelab + setups add-on and v2engine 0.3). The Pine is unchanged.
