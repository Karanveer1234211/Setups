# MANIFEST - setuplab v0.7 (8 Nov 2026: the frozen setups - freeze file, tags, nightly scan)

Folder: C:\Users\karanvsi\PyCharmMiscProject\setuplab\ (tests in setuplab\tests\). Replace the v0.6 files and add FROZEN_SETUPS.json (never edit it: a changed copy is refused). Writes only under --out (C:\QuantData\setuplab). The scan reads tradelab's readers (tradelab with the setups add-on v1.0 on PYTHONPATH: env_tradelab.bat or env_playbook.bat). Python with numpy, pandas, pyarrow.

| file | sha256 (first 16) | bytes | lines |
|---|---|---|---|
| setuplab.py | dc1c6c78a780f0b1 | 143558 | 2661 |
| FROZEN_SETUPS.json | bed8fd610cf686af | 24439 | 935 |
| features_final.txt | bcb6c16bdfd7513d | 1689 | 60 |
| README_SETUPLAB.md | 7721a68ff9609c9c | 17306 | 214 |
| tests\test_setuplab.py | 84940be058fafbd0 | 51397 | 834 |

FROZEN_SETUPS.json's own sha256 (inside the file): 483f1539324f3ae5... (`python setuplab.py frozen` prints FROZEN FILE OK).

Verified where it was built: 52 self-test checks, 0 failed (v0.6's 38 + v0.7's f1-f14: the scan evening by evening = the backtest on a planted world, none on an absent world, the ledger chain, the panel-lag refusal, the tag reconciliation, tradelab's reader on the real outputs).
