"""THE ENTRY TREE as a strategy (setups add-on v1.2): setuplab's TREE.json (frozen 9 Nov 2026), D's ranks 1-3.

The tree, per pick of ranks 1-3 (setuplab tree tags it day by day; tradelab only replays it):
  lane    CALM = the pick's 14-session ATR / close at or below its year's cut-off, JUMPY = above (known at the close)
  D       the best-ranked CALM pick whose D1 open is at or above its signal close: buy that open (one a day);
          every other pick only through its FIRST frozen setup (S1 S2 S3 C1 C2 C3 N1) on that setup's own day
  ENS     every CALM pick at the D1 open; JUMPY picks only through their first frozen setup
  never   ETFs; picks before the first cut-off year (2021); a pick no setup entered (not traded: 0 bp, cash)
  sells   the open buys and S1-S3 / C1-C3 at the pick's 5th close; N1 4 sessions after its entry (session 9 at most)
The entry {"tree": True} buys at the open the tree chose and the exit {"tree": True} sells at the close it chose.
'calm' alone can also be tested on any strategy: "picks": {..., "filter": "calm == 1"}.

    python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --strategy strategies\\tree.py
    python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --strategy strategies\\tree.py --engines ENS

Needs setuplab's tags and tree runs under SETUPLAB_OUT (env_tradelab.bat sets it): python setuplab.py tag ... and
python setuplab.py tree ... once. The comparison (auto) buys every pick of the same ranks at the D1 open; both go
through a Rs 5 L account with 3 positions (like setuplab's books; tradelab's account uses whole shares and breaks ties
by rank, then engine, so its rupees differ a little from TREE.md - TREE.md is the reference for the books).
How to read it: these years are the history the tree was declared on (descriptive, not new evidence); only the
forward record judges it (TREE.json forward_rule).
"""
STRATEGY = {
    "name": "tree",
    "description": "setuplab's entry tree: calm open buys and frozen-setup buys where the tree bought, its exits, 35 bp",
    "mode": "daily",
    "picks": {"engines": ["D"], "ranks": [1, 2, 3], "from": "2021-01-01"},
    "max_sessions": 9,
    "entries": [{"name": "tree", "size": 1.0, "tree": True}],
    "exits": [{"name": "tree", "type": "time", "tree": True}],
    "costs": {"model": "flat", "round_trip_bp": 35},
    "sizing": {"rule": "equal_slots", "slots": 3, "max_pct": 0.34},
    "portfolio": {"capital": 500000, "max_open": 3},
    "decision_rule": {"metric": "diff_mean_bp", "pass_if": "lower > 0"},
}
