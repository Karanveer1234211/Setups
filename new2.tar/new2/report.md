# tradelab backtest - tree

tl_backtest v1.3.1 (tradelab v1.3.1), 2026-11-09T18:03:56. pick_meta run PM_20261017_001. Strategy strategies\tree.py (sha b9d3159e5d8de78f, mode daily), compared with plan.
Tag: -. Declared rule: descriptive: D tree vs all D top-3 at the open, 2021-2026, the history the tree was declared on.

## Verdict first

- Per pick slot: strategy **+64.5 [+41.8, +88.1] bp**, plan +104.9 [+58.8, +150.6] bp, difference **-40.4 [-73.6, -6.7] bp -> WORSE (interval below 0)** (4,241 picks, 1,414 signal days).
- On the picks the strategy actually traded (1,903): difference +215.5 [+185.1, +247.4] bp.
- Picks the plan finished but the strategy could not trade (0, {}): the plan made n/a bp on them vs +104.9 [+58.8, +150.6] bp on the paired picks - a large gap means the pairing is not a fair sample.
- Entered 44.9% of picks; average size used 0.45 of the target; net on the money actually used +143.7 bp.

## Money view (one account, the strategy's sizing)

| | strategy | plan |
|---|---|---|
| CAGR | +97.40% | +53.23% |
| worst drawdown | -29.04% (2025-11-03 -> 2026-04-07) | -35.92% (2025-01-07 -> 2025-03-03) |
| Sharpe (daily x sqrt 252) | 2.03 | 1.31 |
| average exposure | 0.70 | 0.80 |
| trades opened | 829 | 844 |
| skipped (reason) | {'max_open': 1074} | {'max_open': 3397} |
| legs trimmed / skipped by cash | 253 / 0 | 249 / 0 |

Daily return difference: +10.05 [-1.55, +22.66] bp a day -> NOT SHOWN (interval spans 0).

## Detail

- Win rate: strategy 24.4%, plan 50.4%.
- Legs filled (share of entered picks): {'tree': 1.0}.
- Exit reasons: {'tree': 1903}.
- Median MFE +5.00%, median MAE -3.12% (from the first buy, while held).
- Average exit session 5.25; locked exits 79; bars where a stop and a target were both inside the bar (settled by the 'worst' policy): 0.
- Left out of the pairing: strategy {'not_entered': 1}, plan {'stuck': 1}.

### By year (bp per pick)

| year | picks | strategy | plan | difference |
|---|---|---|---|---|
| 2021 | 744 | +79.2 | +143.8 | -64.7 |
| 2022 | 744 | +96.4 | +100.6 | -4.3 |
| 2023 | 738 | +20.5 | +65.5 | -45.1 |
| 2024 | 746 | +88.7 | +215.6 | -126.9 |
| 2025 | 747 | +57.7 | +20.2 | +37.5 |
| 2026 | 522 | +35.3 | +73.9 | -38.6 |

### By engine and rank (bp per pick)

| engine | rank | picks | strategy | plan | difference |
|---|---|---|---|---|---|
| D | 1 | 1,414 | +80.2 | +105.4 | -25.1 |
| D | 2 | 1,413 | +66.9 | +118.9 | -52.0 |
| D | 3 | 1,414 | +46.2 | +90.3 | -44.1 |

## How much to trust this

- The tradelab ledger held 0 earlier backtests (0 distinct strategy files) before this one. With 20 variants tried on the same years, about one will look BETTER at the 95% level by luck alone.
- Same 2020-2026 history the engines were built and studied on. Treat any edge found here as a hypothesis: declare the rule (--declare, decision_rule) and judge it on the forward paper ledger.
- Costs: flat 35 bp round trip on entry notional (half at buy, half at sale); slippage 0.0 bp a side. Fills: next-bar opens, stop / limit levels from the previous bar, official open / close for 'at' orders, honest lower-circuit exits.
- Not modelled: upper-circuit buys that cannot fill, partial fills, market impact beyond the cost model.

## Decision rule: {'rule': {'metric': 'diff_mean_bp', 'pass_if': 'lower > 0'}, 'value': -73.63203298252311, 'verdict': 'FAIL'}

## Market context and stock state: where the strategy helps or hurts (v1.1, states v1.3.1)

### The money by environment (known at the previous close)

Each account's daily returns grouped by the environment known before the day began: mean day return (bp, 95% block-bootstrap interval), the worst drawdown inside that environment (its days chained), average exposure and the most positions open at once.

| account | environment | days | mean day bp | total | worst drawdown inside | worst day bp | avg exposure | max positions |
|---|---|---|---|---|---|---|---|---|
| tree | broad_bullish | 426 (30%) | +34.11 [+13.59, +57.16] | +288.44% | -18.14% | -797 | 0.73 | 3 |
| tree | narrow_bullish | 383 (27%) | +12.49 [-9.60, +32.97] | +47.00% | -41.21% | -734 | 0.71 | 3 |
| tree | mixed | 194 (14%) | +54.66 [+22.03, +90.17] | +172.40% | -16.47% | -551 | 0.67 | 3 |
| tree | broad_bearish | 224 (16%) | +27.03 [-10.20, +61.24] | +68.61% | -23.92% | -788 | 0.68 | 3 |
| tree | high_stress | 191 (13%) | +35.91 [-0.51, +68.94] | +85.74% | -22.51% | -675 | 0.68 | 3 |
| plan | broad_bullish | 426 (30%) | +22.13 [+5.08, +40.72] | +137.10% | -15.32% | -629 | 0.80 | 3 |
| plan | narrow_bullish | 383 (27%) | +18.66 [-1.36, +38.02] | +85.78% | -27.62% | -735 | 0.79 | 3 |
| plan | mixed | 194 (14%) | +25.82 [+0.42, +52.45] | +56.61% | -21.53% | -567 | 0.81 | 3 |
| plan | broad_bearish | 224 (16%) | -0.22 [-43.89, +44.66] | -10.27% | -48.49% | -1025 | 0.82 | 3 |
| plan | high_stress | 191 (13%) | +36.86 [-3.91, +75.88] | +85.04% | -26.47% | -853 | 0.81 | 3 |

### The paired picks by the market and by the stock's state at the pick

'difference' = strategy - plan on the same picks, bp, 95% block-bootstrap intervals over signal days. Many groups are shown: a single group 'BETTER' is a hypothesis to declare and test forward, not a finding. Nothing here filters trades.

#### engine D

**environment at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| broad_bullish | 1,278 | 30% | +24.6 [-4.2, +54.1] | +61.3 [+2.9, +121.1] | -36.7 [-83.5, +7.1] | 20% | 5.4% |
| narrow_bullish | 1,149 | 27% | +48.9 [+16.3, +82.2] | +105.3 [+39.0, +174.3] | -56.5 [-113.2, -1.1] | 24% | 7.0% |
| mixed | 576 | 14% | +71.4 [+5.8, +137.7] | +95.2 [-20.6, +201.2] | -23.7 [-102.5, +55.7] | 22% | 6.1% |
| broad_bearish | 665 | 16% | +103.6 [+33.9, +176.9] | +87.9 [-73.7, +247.5] | +15.7 [-93.9, +124.9] | 32% | 10.4% |
| high_stress | 573 | 14% | +132.1 [+64.6, +205.2] | +230.4 [+116.9, +349.7] | -98.3 [-185.3, -17.4] | 28% | 7.2% |

**high stress at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no | 3,668 | 86% | +53.9 [+32.4, +75.8] | +85.2 [+40.2, +133.3] | -31.4 [-68.2, +4.3] | 24% | 6.9% |
| yes | 573 | 14% | +132.1 [+64.6, +205.2] | +230.4 [+116.9, +349.7] | -98.3 [-185.3, -17.4] | 28% | 7.2% |

**direction at the pick (stress ignored)** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| broad_bullish | 1,365 | 32% | +24.8 [-3.2, +53.2] | +51.6 [-6.0, +108.8] | -26.9 [-71.2, +18.1] | 20% | 5.6% |
| narrow_bullish | 1,314 | 31% | +62.3 [+27.0, +98.8] | +125.0 [+53.0, +193.7] | -62.8 [-119.8, -5.2] | 24% | 6.8% |
| mixed | 657 | 15% | +79.0 [+18.8, +137.9] | +131.2 [+22.7, +226.9] | -52.2 [-123.0, +22.0] | 22% | 5.9% |
| broad_bearish | 905 | 21% | +117.0 [+45.5, +185.1] | +136.7 [+0.8, +270.7] | -19.7 [-107.0, +68.6] | 32% | 9.7% |

**breadth at the pick (10-day A/D)** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < 0.40 | 444 | 10% | +180.2 [+99.1, +257.3] | +292.7 [+129.5, +456.4] | -112.5 [-251.5, +16.0] | 34% | 7.9% |
| 0.40 - 0.50 | 2,048 | 48% | +61.7 [+27.7, +95.7] | +86.2 [+20.8, +150.9] | -24.5 [-71.0, +22.9] | 25% | 8.0% |
| 0.50 - 0.60 | 1,629 | 38% | +36.6 [+7.5, +65.4] | +76.3 [+24.5, +129.3] | -39.7 [-80.6, -0.7] | 20% | 5.3% |
| >= 0.60 | 120 | 3% | +61.2 [-40.5, +184.0] | +116.7 [-6.6, +240.3] | -55.5 [-133.1, +24.6] | 24% | 7.5% |

**VIX 5-day change at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < -10% | 504 | 12% | +75.7 [+24.8, +127.7] | +135.7 [+20.8, +251.6] | -59.9 [-146.6, +25.3] | 23% | 6.0% |
| -10% .. 0% | 1,734 | 41% | +31.8 [+5.2, +59.2] | +71.2 [+20.0, +124.2] | -39.4 [-85.5, +2.8] | 23% | 7.0% |
| 0% .. +10% | 1,368 | 32% | +77.7 [+43.1, +116.9] | +109.6 [+36.3, +183.3] | -31.9 [-85.8, +24.1] | 25% | 7.1% |
| +10% .. +25% | 539 | 13% | +117.3 [+63.7, +174.7] | +145.7 [+40.0, +253.5] | -28.3 [-101.9, +44.6] | 30% | 7.2% |
| >= +25% | 96 | 2% | +110.9 [-39.0, +220.0] | +255.9 [+32.2, +495.1] | -145.0 [-320.3, +16.0] | 27% | 7.3% |

**NIFTY minus Smallcap, 20 days, at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < -3 pts (small caps ahead) | 1,188 | 28% | +26.9 [-7.0, +57.8] | +43.9 [-22.4, +105.1] | -17.0 [-61.3, +29.9] | 21% | 6.7% |
| -3 .. 0 pts | 1,508 | 36% | +70.7 [+37.8, +107.0] | +119.3 [+53.8, +187.3] | -48.7 [-94.7, -3.5] | 24% | 5.6% |
| 0 .. +3 pts | 960 | 23% | +77.8 [+32.3, +122.5] | +135.5 [+48.5, +231.6] | -57.7 [-129.0, +11.0] | 27% | 7.9% |
| >= +3 pts (NIFTY ahead: narrow) | 585 | 14% | +102.9 [+40.2, +172.3] | +141.1 [-19.3, +319.1] | -38.2 [-189.4, +91.1] | 27% | 9.1% |

**size class (AMFI)** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no list | 4,241 | 100% | +64.5 [+41.8, +88.1] | +104.9 [+58.8, +150.6] | -40.4 [-73.6, -6.7] | 24% | 6.9% |

**home index** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| NIFTY 50 | 383 | 9% | +31.3 [-38.8, +89.7] | +47.2 [-78.1, +157.3] | -15.9 [-95.2, +54.5] | 19% | 4.7% |
| Midcap 150 | 863 | 20% | +49.6 [+7.1, +90.7] | +51.8 [-23.1, +126.5] | -2.3 [-55.0, +54.2] | 26% | 7.4% |
| Smallcap 250 | 2,995 | 71% | +73.0 [+47.1, +99.2] | +127.5 [+73.1, +182.1] | -54.5 [-98.1, -13.8] | 25% | 7.1% |

**stock state at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| S01 | 668 | 16% | +22.8 [-11.5, +54.2] | +61.6 [-25.8, +150.4] | -38.8 [-115.3, +37.2] | 20% | 6.6% |
| S02 | 368 | 9% | +66.6 [-1.3, +143.4] | +89.0 [-7.9, +184.5] | -22.4 [-98.7, +53.9] | 18% | 4.3% |
| S03 | 378 | 9% | +24.5 [-14.7, +68.4] | +68.6 [+9.2, +138.4] | -44.1 [-93.3, +2.3] | 21% | 5.8% |
| S06 | 122 | 3% | +83.2 [-26.7, +201.9] | +29.7 [-166.8, +220.4] | +53.4 [-89.0, +207.3] | 23% | 8.2% |
| S07 | 197 | 5% | +22.6 [-15.7, +65.0] | +27.7 [-56.5, +118.0] | -5.1 [-67.9, +54.5] | 19% | 4.6% |
| S08 | 426 | 10% | +133.6 [+70.8, +199.5] | +184.0 [+66.4, +322.4] | -50.4 [-179.8, +53.8] | 34% | 6.8% |
| S09 | 972 | 23% | +112.2 [+56.2, +167.6] | +145.4 [+45.4, +239.8] | -33.2 [-103.0, +36.4] | 31% | 8.8% |
| S12 | 2 | 0% | +0.0 | +757.3 | -757.3 | 0% | 0.0% |
| UNKNOWN | 1,108 | 26% | +39.6 [-5.6, +84.8] | +103.4 [+31.7, +172.1] | -63.9 [-114.5, -13.8] | 22% | 7.0% |

**state phase at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| EARLY | 1,008 | 24% | +60.6 [+22.6, +100.7] | +128.0 [+62.9, +191.5] | -67.3 [-119.5, -15.9] | 25% | 6.7% |
| MATURE | 1,617 | 38% | +95.2 [+61.6, +129.2] | +119.2 [+56.8, +186.7] | -24.0 [-72.0, +25.0] | 26% | 6.6% |
| DETERIORATING | 508 | 12% | +28.7 [-15.4, +73.7] | +16.5 [-62.2, +91.8] | +12.2 [-46.3, +71.2] | 21% | 8.3% |
| (blank) | 1,108 | 26% | +39.6 [-5.6, +84.8] | +103.4 [+31.7, +172.1] | -63.9 [-114.5, -13.8] | 22% | 7.0% |

**state confidence at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| HIGH | 1,493 | 35% | +91.0 [+55.4, +127.2] | +116.5 [+51.2, +189.1] | -25.5 [-83.6, +23.3] | 28% | 7.4% |
| MEDIUM | 1,132 | 27% | +69.9 [+36.8, +106.0] | +130.5 [+66.0, +193.3] | -60.6 [-110.6, -8.9] | 23% | 5.6% |
| LOW | 508 | 12% | +28.7 [-15.4, +73.7] | +16.5 [-62.2, +91.8] | +12.2 [-46.3, +71.2] | 21% | 8.3% |
| UNKNOWN | 1,108 | 26% | +39.6 [-5.6, +84.8] | +103.4 [+31.7, +172.1] | -63.9 [-114.5, -13.8] | 22% | 7.0% |

**event in the last 10 sessions** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| BREAKOUT:NEW | 457 | 11% | +96.7 [+37.6, +161.3] | +78.4 [-11.5, +172.4] | +18.3 [-42.6, +79.7] | 22% | 6.3% |
| BREAKOUT:CONFIRMED | 634 | 15% | +50.3 [+9.3, +93.1] | +147.2 [+69.2, +229.3] | -97.0 [-173.4, -30.2] | 20% | 4.9% |
| BREAKOUT:STALLED | 44 | 1% | -6.8 [-59.3, +44.9] | +92.5 [-135.9, +330.8] | -99.3 [-321.1, +131.6] | 14% | 4.5% |
| FAILED_BREAKOUT:FAILED | 458 | 11% | +40.8 [+1.9, +80.8] | +80.2 [-19.5, +180.8] | -39.5 [-139.2, +61.9] | 18% | 3.5% |
| BREAKDOWN:NEW | 1,056 | 25% | +124.6 [+69.4, +179.0] | +190.7 [+106.4, +274.5] | -66.1 [-122.1, -10.7] | 34% | 9.2% |
| BREAKDOWN:CONFIRMED | 537 | 13% | +62.4 [-33.7, +148.2] | +25.4 [-132.2, +179.7] | +37.0 [-67.6, +140.0] | 25% | 10.8% |
| BREAKDOWN:STALLED | 7 | 0% | -193.9 | -306.7 | +112.9 | 14% | 14.3% |
| FAILED_BREAKDOWN:FAILED | 156 | 4% | +9.0 [-41.1, +59.7] | +90.3 [-55.7, +244.9] | -81.3 [-216.2, +49.6] | 22% | 4.5% |
| (blank) | 892 | 21% | +15.5 [-16.6, +48.5] | +53.6 [-9.5, +114.4] | -38.1 [-82.7, +4.6] | 21% | 5.9% |

**S05 overextension at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no | 3,981 | 94% | +62.3 [+39.0, +86.7] | +109.0 [+61.3, +156.6] | -46.7 [-79.8, -12.1] | 25% | 7.0% |
| overextended | 198 | 5% | +128.8 [+34.9, +232.3] | +87.5 [-72.3, +240.1] | +41.3 [-72.6, +160.6] | 28% | 6.6% |
| extreme | 62 | 1% | -5.0 [-81.9, +62.5] | -106.3 [-246.3, -5.7] | +101.2 [+27.5, +209.6] | 6% | 3.2% |

**stock volatility at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| COMPRESSED | 525 | 12% | +38.3 [-8.8, +91.2] | +66.8 [+5.1, +131.9] | -28.5 [-61.2, +5.5] | 25% | 5.3% |
| NORMAL | 2,152 | 51% | +48.8 [+19.8, +79.2] | +74.3 [+20.4, +126.5] | -25.5 [-61.2, +14.8] | 24% | 7.3% |
| ELEVATED | 859 | 20% | +97.2 [+52.6, +142.5] | +129.3 [+46.6, +213.8] | -32.1 [-108.4, +40.0] | 24% | 5.8% |
| EXTREME | 705 | 17% | +91.9 [+30.4, +152.9] | +196.9 [+67.5, +323.1] | -105.0 [-199.4, -8.2] | 25% | 8.4% |

**Smallcap over the hold** - observed AFTER entry: explains, cannot select

| bucket | trades | share | strategy bp | plan bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < -3% | 205 | 5% | -507.4 [-594.9, -416.3] | -651.2 [-757.0, -532.8] | +143.7 [+81.5, +204.7] | 23% | 52.2% |
| -3% .. -1% | 279 | 7% | -103.5 [-176.4, -25.1] | -255.7 [-353.6, -157.6] | +152.2 [+96.0, +224.8] | 35% | 22.6% |
| -1% .. +1% | 680 | 16% | +136.9 [+79.8, +193.1] | -63.3 [-130.1, +0.4] | +200.2 [+162.3, +241.4] | 54% | 9.4% |
| +1% .. +3% | 531 | 13% | +278.7 [+213.1, +346.9] | +48.1 [-25.7, +118.9] | +230.6 [+169.1, +296.0] | 65% | 9.0% |
| >= +3% | 208 | 5% | +794.4 [+618.1, +956.7] | +411.6 [+241.3, +589.2] | +382.8 [+284.9, +484.0] | 86% | 5.8% |
| (blank) | 2,338 | 55% | +0.0 [+0.0, +0.0] | +248.7 [+201.0, +299.5] | -248.7 [-299.5, -201.0] | 0% | 0.0% |


## Frozen setups (setuplab tags)

Tags TAGS_20261108_001 (setuplab v0.7), freeze sha256 483f1539324f3ae5, signal days ['2020-01-16', '2026-09-15']; they cover 3,997 of this run's picks. Columns in trades.csv: setups (e.g. S2@D3 = setup S2 entered on watch day 3), n_setups, su_<ID>_day, setups_tagged.

This strategy enters on its own rules: for it the tags are hindsight (a setup is known only on its own entry day) - describe trades with them, never pick trades by them.

## Calm / jumpy lanes and the entry tree (setuplab tree)

Tree run TREE_20261109_001 (setuplab v1.1), TREE.json sha256 5cd4571765c2de80, freeze 483f1539324f3ae5, history window ['2021-01-01', '2026-09-22'], RECONCILED with the declaration; it covers 3,997 of this run's picks. Lane = the pick's 14-session ATR / close against its year's cut-off (the 2/3 quantile of earlier years' picks): 2021 5.77%, 2022 5.64%, 2023 5.75%, 2024 5.35%, 2025 5.49%, 2026 5.52%. CALM = at or below, JUMPY = above; picks before the first cut-off year have no lane. The lane is known at the pick's close (a pre-pick breakdown); trades.csv also carries the tree's action on each rank 1-3 pick (tree_action, tree_how, tree_net, opened_up - hindsight: the tree decides at the open and on each setup's own day).

This strategy IS the tree: it buys where the tree bought (tree_how: 'open' = the D1 open, 'S2@D3' = setup S2's own day-3 open) and sells where the tree sold (the 5th close; N1 4 sessions after its entry); a pick the tree skips is not entered (0 bp). The comparison buys every pick at the D1 open. The money view uses tradelab's account (integer shares, its tie order: rank, then engine); setuplab's TREE.md is the reference for the tree's own book numbers. These years are the history the tree was declared on (descriptive); only the forward record judges it.

Paired picks by lane: strategy, plan and the difference (strategy - plan), bp, 95% block-bootstrap intervals over signal days. Descriptive: one lane 'BETTER' is a hypothesis.

| engine | lane | picks | entered | strategy bp | plan bp | difference bp | verdict |
|---|---|---|---|---|---|---|---|
| D | CALM | 2,285 | 1,315 | +67.7 [+37.0, +98.3] | +86.5 [+42.7, +132.1] | -18.8 [-46.2, +9.6] | NOT SHOWN (interval spans 0) |
| D | JUMPY | 1,711 | 588 | +69.4 [+35.8, +103.7] | +145.8 [+66.1, +229.3] | -76.4 [-151.2, -6.2] | WORSE (interval below 0) |
| D | no lane | 245 | 0 | +0.0 [+0.0, +0.0] | -9.6 [-147.3, +102.5] | +9.6 [-102.5, +147.3] | NOT SHOWN (interval spans 0) |
