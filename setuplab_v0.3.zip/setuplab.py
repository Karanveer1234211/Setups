"""
setuplab.py - setuplab v0.1: entry setups for engine D's picks, compared trade by trade with the model's D1 entry.

    python setuplab.py run --data <folder with watchlist.parquet + calendar.parquet> --features <features.parquet>
                           --out <output folder> [--engine D] [--setups default|<setups.json>]
    python setuplab.py reproduce --data ... --features ... --ledgers <folder of delivered *.csv.gz>
    python setuplab.py --selftest

What it does (the rules of the ChatGPT backtester, backtest.pyz, re-implemented vectorised):
  * a setup = a list of conditions, ALL required, read at the open of watch day k (k = 1..5 after the pick):
      <feature>          the feature's value at the previous completed session (k-1; D0 = the signal day)
      <feature>_change   that value minus the session before (stored *_change column if the file has one)
      gap_pct            today's open vs the previous close, %
      pc_vs_d1           the previous close vs the D1 open, %          (known from D2 on; False on D1)
      pc_vs_d1_atr       the same in units of the pick's ATR14 at the signal (s_atr14)
      prev_intraday      the previous session's close vs its open, %   (D2 on)
      prev_ret           the previous session's close vs the close before, %  (D2 on)
      day                the watch day number (blind controls)
      weekday            the watch day's weekday, 0 = Monday (weekly features change on Mondays: their setups
                         can only fire on a Tuesday open - the TUE controls separate the feature from the weekday)
    numbers are rounded to 9 decimals before comparing; 0 does not pass > 0 or < 0
  * entry at the FIRST open whose conditions all hold; a False condition = not today; a missing value with no
    False = the trade is "Missing signal data" (as the original engine); no qualifying open = "No entry"
  * exits: original_d5 = the pick's D5 close; fresh = the close 4 sessions after the entry day (5 sessions held)
  * net % = exit / entry - 1 (in %) - 0.35 (cost)
  * the comparison is Karan's: each setup's OWN filled trades against the model's D1 entry (blind D1, same exit
    rule) on exactly those trade ids. 95% circular block bootstrap over signal days (10-day blocks, 2,000 draws).
    Under original_d5 both legs sell at the same D5 close, so the whole difference is the entry price; under
    fresh the exit moves with the entry, and "after-entry" = setup net minus the D1 trade held from the same
    entry-day open would be the same as the setup itself - so we report the entry discount beside the lift.
  * controls on the same ids: price-only dip entries and bounce markers (no indicators), to see whether a
    setup's conditions add anything beyond "buy after the price has come down"
"""
from __future__ import annotations

import argparse
import itertools
import json
import re
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "setuplab v0.3"
WATCH = 5               # watch days D1..D5
PATH = 10               # sessions of path in the watchlist (close_1..close_10)
COST = 0.35
EXITS = ("original_d5", "fresh")
OPS = {">": np.greater, "<": np.less, ">=": np.greater_equal, "<=": np.less_equal}
PRICE_FIELDS = ("gap_pct", "pc_vs_d1", "pc_vs_d1_atr", "prev_intraday", "prev_ret", "day", "weekday")


# ---------------------------------------------------------------------------------------------------- data
class Book:
    """Engine D's picks with their D1..D10 opens / closes and every feature at the previous session of each watch
    day. Arrays are (trades, PATH + 1) with column k = watch day k (column 0 unused for prices)."""

    def __init__(self, wl: pd.DataFrame, cal: pd.Series, feats: pd.DataFrame | None, engine="D", feature_cols=None):
        wl = wl[wl["engine"] == engine].copy() if "engine" in wl.columns else wl.copy()
        wl = wl.sort_values(["signal_day", "rank", "trade_id"]).reset_index(drop=True)
        self.wl = wl
        self.n = len(wl)
        self.ids = wl["trade_id"].astype(str).to_numpy()
        self.signal_day = pd.to_datetime(wl["signal_day"]).dt.normalize().to_numpy()
        self.ok = (wl["status"].astype(str) == "ok").to_numpy() & np.isfinite(wl["net_bp"].astype(float).to_numpy())
        cal = pd.to_datetime(pd.Series(cal)).dt.normalize().sort_values().drop_duplicates().reset_index(drop=True)
        self.cal = cal.to_numpy()
        pos = {d: i for i, d in enumerate(cal)}
        e1 = pd.to_datetime(wl["entry_day"]).dt.normalize()
        self.i1 = np.array([pos.get(d, -1) for d in e1], dtype=np.int64)
        if (self.i1 < 0).any():
            raise ValueError("%d entry days are not in the calendar" % int((self.i1 < 0).sum()))
        ent = wl["entry"].astype(float).to_numpy()
        sc = wl["signal_close"].astype(float).to_numpy()
        O = np.full((self.n, PATH + 1), np.nan)
        C = np.full((self.n, PATH + 1), np.nan)
        PC = np.full((self.n, PATH + 1), np.nan)
        for k in range(1, PATH + 1):
            C[:, k] = ent * (1 + wl["close_%d" % k].astype(float).to_numpy())
            PC[:, k] = sc if k == 1 else ent * (1 + wl["close_%d" % (k - 1)].astype(float).to_numpy())
            O[:, k] = ent if k == 1 else PC[:, k] * (1 + wl["overnight_%d" % k].astype(float).to_numpy())
        # a session past the calendar's end does not exist
        for k in range(1, PATH + 1):
            gone = self.i1 + k - 1 >= len(self.cal)
            O[gone, k] = C[gone, k] = PC[gone, k] = np.nan
        self.O, self.C, self.PC = O, C, PC
        self.sc, self.ent = sc, ent
        self.atr = wl["s_atr14"].astype(float).to_numpy() if "s_atr14" in wl.columns else np.full(self.n, np.nan)
        self.symbols = wl["symbol"].astype(str).str.strip().str.upper().to_numpy()
        self.state = wl["pre_state"].astype(str).to_numpy() if "pre_state" in wl.columns else np.array([""] * self.n)
        self.F = {}
        if feats is not None:
            self._join(feats, feature_cols)

    def _join(self, feats, feature_cols):
        f = feats.copy()
        if any(n is not None for n in f.index.names):                 # symbol / date stored as the index
            f = f.reset_index()
        f.columns = [str(c).lower() for c in f.columns]
        dk = "timestamp" if "timestamp" in f.columns else "date"
        if "symbol" not in f.columns or dk not in f.columns:
            raise ValueError("the feature file needs symbol and timestamp (or date) columns")
        f["symbol"] = f["symbol"].astype(str).str.strip().str.upper()
        t = pd.to_datetime(f[dk])
        if t.dt.tz is not None:                                         # a zoned clock -> Indian dates, no zone
            t = t.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
        f[dk] = t.dt.normalize()
        base = [c for c in (feature_cols or f.columns) if c not in ("symbol", dk) and not c.endswith("_change")]
        f = f[f["symbol"].isin(set(self.symbols))]
        if f.duplicated(["symbol", dk]).any():
            raise ValueError("duplicated symbol/date rows in the feature file")
        f = f.sort_values(["symbol", dk])
        for c in base:
            if c + "_change" not in f.columns:            # the change = this session minus the symbol's previous row
                f[c + "_change"] = f.groupby("symbol")[c].diff()
        cols = base + [c + "_change" for c in base]
        # previous-session date of each watch day k
        rows, ks, keys_s, keys_d = [], [], [], []
        for k in range(1, WATCH + 1):
            j = self.i1 + k - 2
            ok = (j >= 0) & (j < len(self.cal))
            rows.append(np.flatnonzero(ok))
            ks.append(np.full(ok.sum(), k))
            keys_s.append(self.symbols[ok])
            keys_d.append(self.cal[j[ok]])
        L = pd.DataFrame({"row": np.concatenate(rows), "k": np.concatenate(ks), "symbol": np.concatenate(keys_s),
                          dk: np.concatenate(keys_d)})
        M = L.merge(f[["symbol", dk] + cols], on=["symbol", dk], how="left")
        for c in cols:
            A = np.full((self.n, WATCH + 1), np.nan)
            A[M["row"].to_numpy(), M["k"].to_numpy()] = pd.to_numeric(M[c], errors="coerce").to_numpy(float)
            self.F[c] = A
        self.features = base

    def field(self, name):
        """(trades, WATCH + 1) values of a condition field at the open of each watch day (cached)."""
        if name in self.F:
            return self.F[name]
        cache = self.__dict__.setdefault("_cache", {})
        if name not in cache:
            cache[name] = self._field(name)
        return cache[name]

    def _field(self, name):
        A = np.full((self.n, WATCH + 1), np.nan)
        if name.startswith("snap:"):                  # the pick's snapshot at the signal close (watchlist pre_*)
            col = name[5:]
            if col not in self.wl.columns:
                raise KeyError("no column %s in the watchlist" % col)
            v = pd.to_numeric(self.wl[col], errors="coerce").astype(float).to_numpy()
            A[:, 1:] = v[:, None]
        elif name == "gap_pct":
            A[:, 1:] = (self.O[:, 1:WATCH + 1] / self.PC[:, 1:WATCH + 1] - 1) * 100
        elif name == "day":
            A[:, 1:] = np.arange(1, WATCH + 1)[None, :]
        elif name == "pc_vs_d1":
            A[:, 2:] = (self.C[:, 1:WATCH] / self.O[:, [1]] - 1) * 100
            A[:, 1] = 0.0                          # nothing to compare on D1: a dip test (< 0) is False there
        elif name == "weekday":
            for k in range(1, WATCH + 1):
                j = np.minimum(self.i1 + k - 1, len(self.cal) - 1)
                A[:, k] = pd.DatetimeIndex(self.cal[j]).weekday
        elif name == "pc_vs_d1_atr":
            A[:, 2:] = (self.C[:, 1:WATCH] / self.O[:, [1]] - 1) / self.atr[:, None]
            A[:, 1] = 0.0
        elif name == "prev_intraday":
            A[:, 2:] = (self.C[:, 1:WATCH] / self.O[:, 1:WATCH] - 1) * 100
            A[:, 1] = 0.0
        elif name == "prev_ret":
            prev = np.column_stack([self.sc, self.C[:, 1:WATCH]])
            A[:, 2:] = (self.C[:, 1:WATCH] / prev[:, :WATCH - 1] - 1) * 100
            A[:, 1] = 0.0
        else:
            raise KeyError("unknown field %s" % name)
        return A


# ---------------------------------------------------------------------------------------------------- replay
def trigger(book: Book, conds):
    """First watch day whose conditions all hold. Returns (day, status) arrays: day 0 = none.
    status: 'Filled' candidates (day > 0), 'No entry', 'Missing signal data'."""
    n = book.n
    day = np.zeros(n, dtype=np.int64)
    missing = np.zeros(n, dtype=bool)
    done = ~book.ok.copy()
    for k in range(1, WATCH + 1):
        sess = np.isfinite(book.O[:, k])
        newly_missing = ~done & ~sess                       # watch session unavailable
        missing |= newly_missing
        done |= newly_missing
        anyF = np.zeros(n, dtype=bool)
        anyN = np.zeros(n, dtype=bool)
        for fld, op, val in conds:
            a = book.field(fld)[:, k]
            nan = np.isnan(a)
            r = OPS[op](np.round(np.where(nan, 0, a), 9), round(float(val), 9))
            anyF |= ~nan & ~r
            anyN |= nan
        hit = ~done & ~anyF & ~anyN
        miss = ~done & ~anyF & anyN
        day[hit] = k
        missing |= miss
        done |= hit | miss
    status = np.where(~book.ok, "Unsettled",
                      np.where(missing, "Missing signal data", np.where(day > 0, "Filled", "No entry")))
    return day, status


def exits(book: Book, day, status, mode):
    a = exits_arr(book, day, status, mode)
    return pd.DataFrame({"trade_id": book.ids, "signal_day": book.signal_day, "pre_state": book.state,
                         "status": a["st"], "day": a["day"], "price": a["price"], "exit_day": a["exit_day"],
                         "ret": a["ret"], "trade_dd": a["dd"]})


def exits_arr(book: Book, day, status, mode):
    """Vectorised exit: buy at the entry day's open, sell at the exit close; drawdown over entry + closes.
    Returns plain arrays (compact: thousands of setups can be compared without holding their tables)."""
    n = book.n
    st = status.copy()
    f = status == "Filled"
    k = np.where(f, day, 1)
    e = np.where(f, 5 if mode == "original_d5" else day + 4, 1)
    rows = np.arange(n)
    kk, ee = np.clip(k, 1, PATH), np.clip(e, 1, PATH)
    Ok = book.O[rows, kk]
    j = np.arange(1, PATH + 1)[None, :]
    win = (j >= kk[:, None]) & (j <= ee[:, None])
    Cw = book.C[:, 1:]
    bad = (win & ~np.isfinite(Cw)).any(1) | ~np.isfinite(Ok) | (e > PATH)
    ok = f & ~bad
    st[f & bad] = "Missing exit data"
    with np.errstate(invalid="ignore", divide="ignore"):
        peak = np.maximum(np.maximum.accumulate(np.where(win, Cw, -np.inf), axis=1), Ok[:, None])
        ddj = np.where(win, 100 * (1 - Cw / peak), -np.inf).max(1)
        dd = np.where(ok, np.maximum(ddj, 0.0), np.nan)
        ret = np.where(ok, (book.C[rows, ee] / Ok - 1) * 100 - COST, np.nan)
    return {"st": st, "f": ok, "day": np.where(day > 0, day, np.nan).astype(float),
            "price": np.where(ok, Ok, np.nan), "exit_day": np.where(ok, e, 0), "ret": ret, "dd": dd}


def replay2(book, conds):
    """Both exits from one trigger pass, as arrays."""
    d, s = trigger(book, conds)
    return {m: exits_arr(book, d, s, m) for m in EXITS}


def arr_of(df):
    st = df["status"].to_numpy()
    return {"st": st, "f": st == "Filled", "day": df["day"].to_numpy(float), "price": df["price"].to_numpy(float),
            "ret": df["ret"].to_numpy(float), "dd": df["trade_dd"].to_numpy(float)}


def coverage(a, ok):
    st = a["st"][ok]
    return {"eligible": int(ok.sum()), "filled": int((st == "Filled").sum()), "no_entry": int((st == "No entry").sum()),
            "missing": int(np.char.startswith(st.astype(str), "Missing").sum())}


def replay(book, conds, mode):
    d, s = trigger(book, conds)
    return exits(book, d, s, mode)


# ---------------------------------------------------------------------------------------------------- setups
RULES = {"A": [("d_bb_bw_20_change", ">", 0), ("w_ret_13w_change", "<", 0)],
         "B": [("d_ema20_angle_deg_change", "<", 0), ("w_ret_13w_change", "<", 0)],
         "C": [("d_ema20_angle_deg_change", "<", 0), ("d_wq_44_change", ">", 0)]}
CONF = {"none": [], "positive_open_gap": [("gap_pct", ">", 0)],
        "positive_EMA_slope": [("d_ema20_angle_deg", ">", 0)], "declining_minus_DI": [("d_mdi14_diff1", "<", 0)]}


def abc_setups():
    out = {}
    for r in range(1, 4):
        for sub in itertools.combinations("ABC", r):
            for cn, extra in CONF.items():
                conds = list(dict.fromkeys(sum([RULES[x] for x in sub], []) + extra))
                out["+".join(sub) + "__" + cn] = conds
    return out


def control_setups():
    out = {"Blind_D%d" % k: [("day", "<=", k), ("day", ">=", k)] for k in (1, 2, 3)}
    for x in (0, 1, 2, 3, 5):                                    # price-only dip: prior close X% under the D1 open
        out["DIP_%d" % x] = [("pc_vs_d1", "<", -x if x else 0)] if x else [("pc_vs_d1", "<", 0)]
    out["BOUNCE_green"] = [("pc_vs_d1", "<", 0), ("prev_intraday", ">", 0)]      # down from D1, then a green day
    out["BOUNCE_upclose"] = [("pc_vs_d1", "<", 0), ("prev_ret", ">", 0)]         # down from D1, then an up close
    out["BOUNCE_dip2_green"] = [("pc_vs_d1", "<", -2), ("prev_intraday", ">", 0)]
    out["TUE"] = [("weekday", ">=", 1), ("weekday", "<=", 1)]                      # the first Tuesday open
    out["TUE_DIP_2"] = [("weekday", ">=", 1), ("weekday", "<=", 1), ("pc_vs_d1", "<", -2)]
    for x in (0.5, 1.0, 1.5):                                    # the dip in the stock's own ATR units
        out["DIPATR_%g" % x] = [("pc_vs_d1_atr", "<", -x)]
    return out


def combo_setups():
    """B / A+B with a price dip (the prior close x% under the D1 open) - added 7 Nov after the first run showed B
    ties a 2% dip on the same trades: an exploratory follow-up, not a pre-declared test."""
    ab = list(dict.fromkeys(RULES["A"] + RULES["B"]))
    out = {}
    for x in (1, 2, 3):
        out["B&DIP_%d" % x] = RULES["B"] + [("pc_vs_d1", "<", -x)]
        out["A+B&DIP_%d" % x] = ab + [("pc_vs_d1", "<", -x)]
    return out


def explore(book, v1, boot, log=print, di=None):
    """What adds most on top of a price dip (7 Nov, exploratory, chosen after the first run - a hypothesis search,
    not a test): every single feature condition, the 10 best pairs of the space and B / A+B, each AND a 2% dip
    (and B / A+B AND a 1-ATR dip); each compared on the same trades with the dip alone and with D1."""
    st = {"DIP_2": [("pc_vs_d1", "<", -2)], "DIPATR_1": [("pc_vs_d1_atr", "<", -1)],
          "Blind_D1": [("day", "<=", 1), ("day", ">=", 1)]}
    dip = ("pc_vs_d1", "<", -2)
    for f in book.features:
        for kind in ("", "_change"):
            for op in (">", "<"):
                st["X1|%s%s%s0" % (f, kind, op)] = [(f + kind, op, 0), dip]
    sp = v1[(v1.exit == "original_d5") & v1.setup.str.startswith("S2|")].sort_values("lift_pp", ascending=False)
    space = space_setups(book.features)
    for nm in sp.setup.head(10):
        st["X2|" + nm[3:]] = space[nm] + [dip]
    if all(c[0] in book.F for c in RULES["A"] + RULES["B"]):
        ab = list(dict.fromkeys(RULES["A"] + RULES["B"]))
        st["XA|B&DIPATR_1"] = RULES["B"] + [("pc_vs_d1_atr", "<", -1)]
        st["XA|A+B&DIPATR_1"] = ab + [("pc_vs_d1_atr", "<", -1)]
    di = boot.index(book.signal_day) if di is None else di
    bases = {k: replay2(book, st[k]) for k in ("DIP_2", "DIPATR_1", "Blind_D1")}
    rows = []
    for nm in st:
        if not nm.startswith("X"):
            continue
        base = "DIPATR_1" if "DIPATR" in nm else "DIP_2"
        R = replay2(book, st[nm])
        for mode in EXITS:
            r = paired_fast(R[mode], bases[base][mode], boot, di)
            r1 = paired_fast(R[mode], bases["Blind_D1"][mode], boot, di)
            if r and r1:
                rows.append({"setup": nm, "exit": mode, "vs": base, **r, "lift_vs_D1": r1["lift_pp"],
                             "lo_vs_D1": r1["lo"], "hi_vs_D1": r1["hi"]})
    X = pd.DataFrame(rows)
    log(" exploration: %d setups on top of a dip" % (len(st) - 3))
    return X


# ---------------------------------------------------------------------------------------------------- confluences
# Declared 7 Nov 2026, 10:30 IST, BEFORE any confluence run. Price confluences read the path known at that open;
# context confluences read the pick's snapshot at the signal close (watchlist pre_* columns). Median splits use
# the picks' own snapshot values (no outcomes).
PRICE_CONF = {"DIP1": [("pc_vs_d1", "<", -1)], "DIP2": [("pc_vs_d1", "<", -2)], "DIP3": [("pc_vs_d1", "<", -3)],
              "DIPATR1": [("pc_vs_d1_atr", "<", -1)], "GREEN": [("prev_intraday", ">", 0)],
              "UPCLOSE": [("prev_ret", ">", 0)], "GAPDOWN": [("gap_pct", "<", 0)], "GAPUP": [("gap_pct", ">", 0)]}


def context_conf(book):
    med = lambda c: float(np.nanmedian(pd.to_numeric(book.wl[c], errors="coerce"))) if c in book.wl else np.nan
    out = {"BEARSTATE": [("snap:pre_state_bearish", ">", 0.5)], "BULLSTATE": [("snap:pre_state_bullish", ">", 0.5)],
           "NIFTY_ABOVE_MA50": [("snap:pre_nifty_vs_ma50", ">", 0)],
           "NIFTY_BELOW_MA50": [("snap:pre_nifty_vs_ma50", "<", 0)],
           "MKT_BULLISH": [("snap:pre_env_code", "<=", 1)], "MKT_BEARISH": [("snap:pre_env_code", ">=", 3)],
           "VIX_LOW": [("snap:pre_vix_pct250", "<", med("pre_vix_pct250"))],
           "VIX_HIGH": [("snap:pre_vix_pct250", ">=", med("pre_vix_pct250"))],
           "BREADTH_WEAK": [("snap:pre_ad_ratio_10", "<", med("pre_ad_ratio_10"))],
           "NOT_OVEREXT": [("snap:pre_state_overextended", "<", 0.5)],
           "VOL_ELEVATED": [("snap:pre_state_vol_elevated", ">", 0.5)]}
    return {k: v for k, v in out.items() if all(f[5:] in book.wl.columns and np.isfinite(t) for f, _, t in v)}


def confluence(book, v1, boot, out, log=print, pool_n=10, di=None):
    """Setups x logical confluences. Pool = B, A+B, the pair space's top pool_n by lift over D1 and top pool_n by
    own net per trade (n >= 300, interval above 0, original_d5), and NONE (the confluence alone). Each setup x each
    confluence (single, or one price x one context), vs D1 and vs the confluence alone on the same trade ids."""
    space = space_setups(book.features)
    pool = {"NONE": []}
    if all(c[0] in book.F for c in RULES["A"] + RULES["B"]):
        pool["B"] = RULES["B"]
        pool["A+B"] = list(dict.fromkeys(RULES["A"] + RULES["B"]))
    sp = v1[(v1.exit == "original_d5") & v1.setup.str.startswith("S2|") & (v1.n >= 300) & (v1.lo > 0)]
    for nm in list(sp.sort_values("lift_pp", ascending=False).setup.head(pool_n)) + \
            list(sp.sort_values("setup_net", ascending=False).setup.head(pool_n)):
        if frozenset(space[nm]) not in {frozenset(v) for v in pool.values()}:     # B is also a pair: once only
            pool.setdefault(nm[3:], space[nm])
    ctx = context_conf(book)
    confs = {**PRICE_CONF, **ctx}
    for a, b in itertools.product(PRICE_CONF, ctx):
        confs[a + "&" + b] = PRICE_CONF[a] + ctx[b]
    st = {"Blind_D1": [("day", "<=", 1), ("day", ">=", 1)]}
    for pn, pc in pool.items():
        for cn, cc in confs.items():
            st["%s || %s" % (pn, cn)] = list(dict.fromkeys(pc + cc))
    log(" confluence: %d setups x %d confluences = %d combinations" % (len(pool), len(confs), len(st) - 1))
    di = boot.index(book.signal_day) if di is None else di
    yi = pd.DatetimeIndex(book.signal_day).year.to_numpy()
    yi = yi - yi.min()
    d1 = replay2(book, st["Blind_D1"])
    alone = {cn: replay2(book, st["NONE || " + cn]) for cn in confs}       # the confluences alone, kept
    rows = []
    t0 = time.time()
    for i, name in enumerate(st):
        if name == "Blind_D1":
            continue
        pn, cn = name.split(" || ")
        R = alone[cn] if pn == "NONE" else replay2(book, st[name])
        for mode in EXITS:
            r = paired_fast(R[mode], d1[mode], boot, di)
            if not r:
                continue
            row = {"setup": pn, "confluence": cn, "exit": mode, **r}
            if pn != "NONE":
                r2 = paired_fast(R[mode], alone[cn][mode], boot, di)
                if r2:
                    row.update({"adds_over_conf": r2["lift_pp"], "adds_lo": r2["lo"], "adds_hi": r2["hi"],
                                "adds_n": r2["n"]})
            f = R[mode]["f"]
            sm = np.bincount(yi[f], weights=R[mode]["ret"][f])
            ct = np.bincount(yi[f])
            row["years_net_pos"] = int(((ct > 0) & (sm > 0)).sum())
            row["years"] = int((ct > 0).sum())
            rows.append(row)
        if (i + 1) % 500 == 0:
            log(" confluence: %d of %d (%.0f s)" % (i + 1, len(st) - 1, time.time() - t0))
    X = pd.DataFrame(rows)
    X.to_csv(out / "confluence.csv", index=False)
    L = ["# setuplab - setups x logical confluences (%s)" % VERSION, "",
         "Pool: %s." % ", ".join(pool), "",
         "Confluences (declared before the run): price %s; context %s; and every price x context pair." % (
             ", ".join(PRICE_CONF), ", ".join(ctx)), "",
         "Each row: the combination's own trades vs the model's D1 entry on the same ids; 'adds' = the same "
         "combination vs the confluence ALONE on the same ids (what the indicator setup adds); years = signal years "
         "with net per trade above 0. Net %% after 0.35 pp; 95%% block bootstrap over signal days. Exploratory: "
         "%d combinations on the history the setups came from - expect some to look good by chance." % (len(st) - 1),
         ""]
    for mode in EXITS:
        m = X[(X.exit == mode) & (X.n >= 150)]
        best = m[(m.setup != "NONE") & (m.lo > 0)].sort_values("setup_net", ascending=False).head(25)
        L += ["## %s exit - top 25 combinations by net per trade (n >= 150, lift over D1 interval above 0)" % mode,
              "", "| setup | confluence | n | net | D1 | lift over D1 [95%] | adds over the confluence alone [95%] "
              "| years net > 0 |", "|---|---|---:|---:|---:|---|---|---:|"]
        for _, r in best.iterrows():
            L.append("| %s | %s | %d | %+.4f | %+.4f | %+.4f [%+.4f, %+.4f] | %s | %d/%d |" % (
                r.setup, r.confluence, r.n, r.setup_net, r.control_net, r.lift_pp, r.lo, r.hi,
                ("%+.4f [%+.4f, %+.4f]" % (r.adds_over_conf, r.adds_lo, r.adds_hi)) if pd.notna(
                    r.get("adds_over_conf")) else "-", r.years_net_pos, r.years))
        base = m[m.setup == "NONE"].sort_values("setup_net", ascending=False).head(15)
        L += ["", "### The confluences ALONE (no indicator setup) - top 15 by net per trade (n >= 150)", "",
              "| confluence | n | net | D1 | lift over D1 [95%] | years net > 0 |", "|---|---:|---:|---:|---|---:|"]
        for _, r in base.iterrows():
            L.append("| %s | %d | %+.4f | %+.4f | %+.4f [%+.4f, %+.4f] | %d/%d |" % (
                r.confluence, r.n, r.setup_net, r.control_net, r.lift_pp, r.lo, r.hi, r.years_net_pos, r.years))
        L.append("")
    (out / "CONFLUENCE.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    log(" confluence: wrote CONFLUENCE.md, confluence.csv")
    return X


def space_setups(features):
    """Every single-feature change direction and every pair of change directions (the A/B/C family)."""
    out = {}
    for f in features:
        for op in (">", "<"):
            out["S1|%s_change%s0" % (f, op)] = [(f + "_change", op, 0)]
    for f, g in itertools.combinations(features, 2):
        for a, b in itertools.product((">", "<"), repeat=2):
            out["S2|%s_change%s0&%s_change%s0" % (f, a, g, b)] = [(f + "_change", a, 0), (g + "_change", b, 0)]
    return out


# ---------------------------------------------------------------------------------------------------- statistics
class Boot:
    """Circular block bootstrap over signal days, shared index draws so every comparison uses the same resamples."""

    def __init__(self, days, B=2000, block=10, seed=7):
        self.days = np.sort(np.unique(days))
        self.pos = {d: i for i, d in enumerate(self.days)}
        n = len(self.days)
        rng = np.random.default_rng(seed)
        nb = int(np.ceil(n / block))
        st = rng.integers(0, n, size=(B, nb))
        self.ix = ((st[:, :, None] + np.arange(block)[None, None, :]) % n).reshape(B, -1)[:, :n]

    def ci(self, days, vals):
        return self.ci_idx(np.array([self.pos[d] for d in days]), vals)

    def index(self, days):
        return np.array([self.pos.get(d, -1) for d in days])

    def ci_idx(self, di, vals):
        s = np.bincount(di, weights=vals, minlength=len(self.days))
        c = np.bincount(di, minlength=len(self.days)).astype(float)
        S, Cn = s[self.ix].sum(1), c[self.ix].sum(1)
        m = S / np.where(Cn > 0, Cn, np.nan)
        return float(np.nanpercentile(m, 2.5)), float(np.nanpercentile(m, 97.5))


def paired(a: pd.DataFrame, b: pd.DataFrame, boot: Boot):
    """a's filled trades vs b's on exactly the ids both filled (a = setup, b = control)."""
    A = a[a.status == "Filled"].set_index("trade_id")
    Bf = b[b.status == "Filled"].set_index("trade_id")
    ids = A.index.intersection(Bf.index)
    if len(ids) == 0:
        return None
    x, y = A.loc[ids], Bf.loc[ids]
    lift = x["ret"].to_numpy() - y["ret"].to_numpy()
    lo, hi = boot.ci(x["signal_day"].to_numpy(), lift) if len(ids) > 1 else (np.nan, np.nan)
    disc = (y["price"].to_numpy() / x["price"].to_numpy() - 1) * 100     # % the setup bought under the control
    return {"n": len(ids), "control_net": float(y["ret"].mean()), "setup_net": float(x["ret"].mean()),
            "lift_pp": float(lift.mean()), "lo": lo, "hi": hi, "setup_better_pct": float(100 * (lift > 0).mean()),
            "entry_cheaper_pct": float(np.mean(disc)), "setup_dd": float(x["trade_dd"].mean()),
            "control_dd": float(y["trade_dd"].mean()), "setup_p5": float(np.percentile(x["ret"], 5)),
            "control_p5": float(np.percentile(y["ret"], 5)),
            "mean_entry_day": float(x["day"].mean())}


def paired_fast(a, b, boot, di):
    """paired() on aligned arrays from the same book (same numbers; no tables)."""
    m = a["f"] & b["f"]
    n = int(m.sum())
    if n == 0:
        return None
    x, y = a["ret"][m], b["ret"][m]
    lift = x - y
    lo, hi = boot.ci_idx(di[m], lift) if n > 1 else (np.nan, np.nan)
    disc = (b["price"][m] / a["price"][m] - 1) * 100
    return {"n": n, "control_net": float(np.mean(y)), "setup_net": float(np.mean(x)), "lift_pp": float(lift.mean()),
            "lo": lo, "hi": hi, "setup_better_pct": float(100 * (lift > 0).mean()),
            "entry_cheaper_pct": float(np.mean(disc)), "setup_dd": float(np.mean(a["dd"][m])),
            "control_dd": float(np.mean(b["dd"][m])), "setup_p5": float(np.percentile(x, 5)),
            "control_p5": float(np.percentile(y, 5)), "mean_entry_day": float(np.mean(a["day"][m]))}


# ---------------------------------------------------------------------------------------------------- commands
RAW_LEVEL = re.compile(r"^d_(sma|ema)\d+$|^d_atr(14|30)$|^d_cpr_(pivot|bc|tc)$|^d_(support|resistance)\d+$|vpoc|"
                       r"^d_breakout_(high|low)_\d+$|^d_obv$|^d_macd(_signal|_hist)?$|dollar_vol$|_code$|_trend$|"
                       r"^d_dow$|^comb_|prev_inside_day|ema_stack|^label_|(^|_)(open|high|low|close|vwap)$")


def pick_features(why_csv, top, panel, engine="D"):
    """The engine's top features by the WHY surrogate's importance (why_features.csv), skipping raw price levels /
    price-scaled values, categorical codes, the day of week, combined flags and anything not in the panel.
    Returns (chosen, skipped-with-reason)."""
    import pyarrow.parquet as pq
    W = pd.read_csv(why_csv)
    if "engine" in W.columns:
        W = W[W["engine"] == engine]
    W = W.sort_values("importance", ascending=False)
    have = {c.lower() for c in pq.read_schema(panel).names}
    chosen, skipped = [], []
    for f in W["feature"].astype(str):
        if len(chosen) >= top:
            break
        lf = f.lower()
        if RAW_LEVEL.search(lf):
            skipped.append((f, "raw level / code / flag"))
        elif lf not in have:
            skipped.append((f, "not in the panel"))
        else:
            chosen.append(f)
    return chosen, skipped


def load(data, features, engine="D", feature_cols=None):
    """feature_cols: read only these columns (+ symbol / date and any *_change twins) - for the big panel.parquet."""
    wl = pd.read_parquet(Path(data) / "watchlist.parquet")
    cal = pd.read_parquet(Path(data) / "calendar.parquet")["date"]
    F = None
    if features:
        if feature_cols:
            import pyarrow.parquet as pq
            names = pq.read_schema(features).names
            low = {c.lower(): c for c in names}
            key = [low[k] for k in ("symbol", "timestamp", "date") if k in low][:2]
            want = [c.lower() for c in feature_cols]
            miss = [c for c in want if c not in low]
            if miss:
                raise ValueError("not in the feature file: " + ", ".join(miss))
            cols = key + [low[c] for c in want] + [low[c + "_change"] for c in want if c + "_change" in low]
            syms = sorted(set(wl.loc[wl["engine"] == engine, "symbol"].astype(str).str.strip().str.upper())) \
                if "engine" in wl.columns else None
            F = None
            if syms and "symbol" in low:                  # only the picks' stocks: a fraction of the panel's memory
                try:
                    F = pq.read_table(features, columns=cols, filters=[(low["symbol"], "in", syms)]).to_pandas()
                    if len(F) == 0:
                        F = None
                except Exception:
                    F = None
            if F is None:
                F = pd.read_parquet(features, columns=cols)
            feature_cols = want
            if len(F) == 0:
                raise ValueError("the feature file has no rows")
        else:
            F = pd.read_parquet(features)
    return Book(wl, cal, F, engine, feature_cols)


def cmd_reproduce(book, ledgers):
    setups = {**abc_setups(), "Blind_D1": [("day", "<=", 1), ("day", ">=", 1)],
              "Blind_D3": [("day", "<=", 3), ("day", ">=", 3)]}
    worst = 0.0
    bad = []
    n = 0
    for name, conds in setups.items():
        for mode in EXITS:
            fn = Path(ledgers) / (("%s__%s.csv.gz" % (name, mode)) if not name.startswith("Blind")
                                  else ("%s_%s.csv.gz" % (name, mode)))
            if not fn.is_file():
                bad.append((name, mode, "no ledger"))
                continue
            L = pd.read_csv(fn).set_index("trade_id")
            R = replay(book, conds, mode).set_index("trade_id")
            ids = L.index.intersection(R.index)
            st_ok = (L.loc[ids, "status"].astype(str) == R.loc[ids, "status"].astype(str))
            f = ids[(L.loc[ids, "status"] == "Filled").to_numpy()]
            dret = np.abs(L.loc[f, "ret"].to_numpy(float) - R.loc[f, "ret"].to_numpy(float))
            dday = (L.loc[f, "day"].to_numpy(float) != R.loc[f, "day"].to_numpy(float)).sum()
            w = float(np.nanmax(dret)) if len(dret) else 0.0
            worst = max(worst, w)
            n += 1
            if (~st_ok).sum() or dday or w > 1e-6 or len(ids) != len(L):
                bad.append((name, mode, "status %d, day %d, ret %.2e, ids %d/%d" % (int((~st_ok).sum()), int(dday), w,
                                                                                  len(ids), len(L))))
    return n, bad, worst


def run_all(book, setups, boot):
    led = {}
    for name, conds in setups.items():
        for mode in EXITS:
            led[(name, mode)] = replay(book, conds, mode)
    return led


def compare(led, names, controls, boot):
    rows = []
    for name in names:
        for mode in EXITS:
            for ctl in controls:
                if ctl == name:
                    continue
                r = paired(led[(name, mode)], led[(ctl, mode)], boot)
                if r:
                    rows.append({"setup": name, "exit": mode, "control": ctl, **r})
    return pd.DataFrame(rows)


def cmd_run(book, out, log=print, with_confluence=False):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    have = lambda conds: all(f in book.F or f in PRICE_FIELDS for f, _, _ in conds)
    abc = {k: v for k, v in abc_setups().items() if have(v)}       # A/B/C only when their features are loaded
    ctl = control_setups()
    space = space_setups(book.features)
    combo = combo_setups() if all(c[0] in book.F for c in RULES["A"] + RULES["B"]) else {}
    setups = {**ctl, **abc, **combo}
    log("%s: %d trades, %d setups (%d A/B/C, %d controls, %d combos, %d feature-space), 2 exits" % (
        VERSION, book.n, len(setups) + len(space), len(abc), len(ctl), len(combo), len(space)))
    led = run_all(book, setups, None)
    boot = Boot(book.signal_day[book.ok])
    di = boot.index(book.signal_day)
    # 1. every setup vs the model's D1 entry on its own trades (the pair space streamed: compared, then dropped)
    v1 = compare(led, list(setups), ["Blind_D1"], boot)
    d1 = {m: arr_of(led[("Blind_D1", m)]) for m in EXITS}
    rows = []
    for i, (name, conds) in enumerate(space.items()):
        R = replay2(book, conds)
        for m in EXITS:
            r = paired_fast(R[m], d1[m], boot, di)
            if r:
                rows.append({"setup": name, "exit": m, "control": "Blind_D1", **r, **coverage(R[m], book.ok)})
        if (i + 1) % 1000 == 0:
            log(" pair space: %d of %d (%.0f s)" % (i + 1, len(space), time.time() - t0))
    log(" replayed in %.0f s" % (time.time() - t0))
    # 2. A/B/C and the best of the space vs the price-only controls on the same trades
    keys = [k for k in abc if k.endswith("__none")] + list(combo)
    v2 = compare(led, keys, [c for c in ctl if c != "Blind_D1"] + (["B__none"] if "B__none" in abc else []), boot)
    # by signal year: the key setups vs D1 and vs the 2% dip on the same trades
    yrs = []
    for name in [k for k in ("B__none", "A+B__none") if k in abc] + list(combo):
        for mode in EXITS:
            a = led[(name, mode)]
            a = a[a.status == "Filled"].set_index("trade_id")
            for c in ("Blind_D1", "DIP_2"):
                b = led[(c, mode)]
                b = b[b.status == "Filled"].set_index("trade_id")
                ids = a.index.intersection(b.index)
                z = pd.DataFrame({"year": pd.to_datetime(a.loc[ids, "signal_day"]).dt.year,
                                  "setup": a.loc[ids, "ret"], "lift": a.loc[ids, "ret"] - b.loc[ids, "ret"]})
                for y, g in z.groupby("year"):
                    yrs.append({"setup": name, "exit": mode, "control": c, "year": y, "n": len(g),
                                "setup_net": g.setup.mean(), "lift_pp": g.lift.mean()})
    yrs = pd.DataFrame(yrs)
    yrs.to_csv(out / "by_year.csv", index=False)
    sts = by_state(led, [k for k in ("B__none", "A+B__none") if k in abc] + list(combo) + ["DIP_2"], boot)
    sts.to_csv(out / "by_state.csv", index=False)
    # coverage per setup
    cov = []
    for (name, mode), d in led.items():
        s = d[d.status != "Unsettled"]
        cov.append({"setup": name, "exit": mode, "eligible": len(s), "filled": int((s.status == "Filled").sum()),
                    "no_entry": int((s.status == "No entry").sum()),
                    "missing": int(s.status.str.startswith("Missing").sum())})
    cov = pd.DataFrame(cov)
    v1 = v1.merge(cov, on=["setup", "exit"], how="left")
    if rows:
        v1 = pd.concat([v1, pd.DataFrame(rows)], ignore_index=True)
    # rank of each setup's lift inside the feature space (same exit)
    sp = v1[v1.setup.str.startswith("S2|")]
    for mode in EXITS:
        ref = np.sort(sp[sp.exit == mode]["lift_pp"].to_numpy())
        m = v1.exit == mode
        v1.loc[m, "pct_of_pair_space"] = [100 * np.searchsorted(ref, x, side="right") / max(1, len(ref))
                                          for x in v1.loc[m, "lift_pp"]]
    X = explore(book, v1, boot, log, di)
    X.to_csv(out / "explore_on_dip.csv", index=False)
    v1.to_csv(out / "vs_D1.csv", index=False)
    v2.to_csv(out / "vs_price_controls.csv", index=False)
    (out / "ledgers").mkdir(exist_ok=True)
    for (name, mode), d in led.items():
        if not name.startswith("S"):
            d.to_csv(out / "ledgers" / ("%s__%s.csv.gz" % (name, mode)), index=False)
    report(v1, v2, out, book, yrs, X, sts)
    if with_confluence:
        confluence(book, v1, boot, out, log, di=di)
    log(" wrote %s (%.0f s)" % (out, time.time() - t0))
    return v1, v2


def by_state(led, names, boot):
    """Each setup's own trades vs D1 (and vs the 2% dip) on the same ids, split by the pick's stock state at the
    signal (pre_state from the watchlist: nomination context, not the state on the entry day)."""
    rows = []
    for name in names:
        for mode in EXITS:
            a = led[(name, mode)]
            for ctl in ("Blind_D1", "DIP_2"):
                if ctl == name:
                    continue
                b = led[(ctl, mode)]
                for st in sorted(a.pre_state.astype(str).unique()):
                    r = paired(a[a.pre_state.astype(str) == st], b[b.pre_state.astype(str) == st], boot)
                    if r:
                        rows.append({"setup": name, "exit": mode, "control": ctl, "state": st, **r})
    return pd.DataFrame(rows)


def _fmt(r):
    return "%d | %+.4f | %+.4f | **%+.4f** | %+.4f .. %+.4f | %.1f | %.4f" % (
        r["n"], r["control_net"], r["setup_net"], r["lift_pp"], r["lo"], r["hi"], r["setup_better_pct"],
        r["entry_cheaper_pct"])


def report(v1, v2, out, book, yrs=None, X=None, sts=None):
    L = ["# setuplab - setups vs the model's D1 entry on the same trades (%s)" % VERSION, "",
         "Engine D, %d picks, %d settled. Net %% per trade after 0.35 pp. Each row: the setup's OWN filled trades "
         "against the model buying the same trade ids at the D1 open (same exit rule). 95%% circular block bootstrap "
         "over signal days (10-day blocks, 2,000 draws). 'Cheaper' = how far under the control's entry the setup "
         "bought, on average." % (book.n, int(book.ok.sum())), ""]
    hdr = "| setup | n | D1 net | setup net | lift pp | 95% interval | setup better % | entry cheaper % |"
    sep = "|---|---:|---:|---:|---:|---|---:|---:|"
    for mode in EXITS:
        L += ["## %s exit" % mode, "", "### A/B/C and the price-only controls", "", hdr, sep]
        sub = v1[(v1.exit == mode) & ~v1.setup.str.startswith("S")]
        for _, r in sub.sort_values("lift_pp", ascending=False).iterrows():
            L.append("| %s | %s |" % (r["setup"], _fmt(r)))
        sp = v1[(v1.exit == mode) & v1.setup.str.startswith("S2|")].sort_values("lift_pp", ascending=False)
        L += ["", "### The whole pair space of the %d features (%d setups; A/B/C's family) - top 15 and bottom 5" %
              (len(book.features), len(sp)), "", hdr, sep]
        for _, r in pd.concat([sp.head(15), sp.tail(5)]).iterrows():
            L.append("| %s | %s |" % (r["setup"][3:], _fmt(r)))
        L += ["", "Pair space: lift above 0 with the interval above 0 in %d of %d setups; median lift %+.4f pp." % (
            int((sp.lo > 0).sum()), len(sp), sp.lift_pp.median()), ""]
        own = sp[(sp.n >= 300) & (sp.lo > 0)].sort_values("setup_net", ascending=False).head(15)
        L += ["### Pair space - top 15 by net per trade (n >= 300, lift interval above 0)", "", hdr, sep]
        for _, r in own.iterrows():
            L.append("| %s | %s |" % (r["setup"][3:], _fmt(r)))
        L.append("")
        L += ["### A/B/C against the price-only controls (same trade ids, both filled)", "",
              "| setup | control | n | control net | setup net | lift pp | 95% interval | setup better % | entry cheaper % |",
              "|---|---|---:|---:|---:|---:|---|---:|---:|"]
        for _, r in (v2[v2.exit == mode] if len(v2) else v2).iterrows():
            L.append("| %s | %s | %s |" % (r["setup"], r["control"], _fmt(r)))
        L.append("")
        if yrs is not None and len(yrs):
            L += ["### By signal year (lift pp on the same trades; setup net in brackets)", ""]
            ys = sorted(yrs.year.unique())
            L += ["| setup | vs | " + " | ".join(str(y) for y in ys) + " |", "|---|---|" + "---:|" * len(ys)]
            for (nm, c), g in yrs[yrs.exit == mode].groupby(["setup", "control"], sort=False):
                g = g.set_index("year")
                L.append("| %s | %s | " % (nm, c) + " | ".join(
                    ("%+.2f (%+.2f, n %d)" % (g.loc[y, "lift_pp"], g.loc[y, "setup_net"], g.loc[y, "n"]))
                    if y in g.index else "-" for y in ys) + " |")
            L.append("")
    if sts is not None and len(sts):
        L += ["## By stock state at the signal (pre_state; nomination context)", "",
              "Each cell: lift over D1 on the setup's own trades [95% interval] / the setup's net per trade / trades. "
              "States with under 30 trades are noisy.", ""]
        for mode in EXITS:
            sub = sts[(sts.exit == mode) & (sts.control == "Blind_D1")]
            names = list(dict.fromkeys(sub.setup))
            L += ["### %s exit" % mode, "", "| state | " + " | ".join(names) + " |", "|---|" + "---|" * len(names)]
            for st in sorted(sub.state.unique()):
                cells = []
                for nm in names:
                    r = sub[(sub.setup == nm) & (sub.state == st)]
                    cells.append("-" if r.empty else "%+.2f [%+.2f, %+.2f] / %+.2f / %d" % (
                        r.lift_pp.iloc[0], r.lo.iloc[0], r.hi.iloc[0], r.setup_net.iloc[0], r.n.iloc[0]))
                L.append("| %s | " % st + " | ".join(cells) + " |")
            L.append("")
    if X is not None and len(X):
        L += ["## Exploration: what adds most on top of a price dip (hypotheses, chosen after looking)", "",
              "Each row: the condition AND the dip, its own trades vs the dip alone on the same ids (lift), and vs D1. "
              "Sorted by lift over the dip; n >= 150 only. X1 = one feature condition, X2 = one of the 10 best pairs "
              "of the space, XA = B / A+B with a 1-ATR dip.", ""]
        for mode in EXITS:
            sub = X[(X.exit == mode) & (X.n >= 150)].sort_values("lift_pp", ascending=False)
            L += ["### %s exit - top 15 of %d (interval above 0 over the dip: %d)" % (
                mode, len(sub), int((sub.lo > 0).sum())), "",
                  "| setup | over | n | dip net | setup net | lift over dip | 95% interval | lift over D1 | 95% interval |",
                  "|---|---|---:|---:|---:|---:|---|---:|---|"]
            for _, r in sub.head(15).iterrows():
                L.append("| %s | %s | %d | %+.4f | %+.4f | **%+.4f** | %+.4f .. %+.4f | %+.4f | %+.4f .. %+.4f |" % (
                    r.setup, r.vs, r.n, r.control_net, r.setup_net, r.lift_pp, r.lo, r.hi, r.lift_vs_D1, r.lo_vs_D1,
                    r.hi_vs_D1))
            L.append("")
    L += ["Controls: DIP_x = the first open D2..D5 after a close more than x% under the D1 open (DIP_0: any close under "
          "it); BOUNCE_green = under the D1 open, then a green day; BOUNCE_upclose = under it, then an up close; "
          "BOUNCE_dip2_green = more than 2% under it, then a green day; DIPATR_x = a close more than x ATR14 (at the "
          "signal) under the D1 open. No indicators in any control.",
          "Exploratory: the same history the setups were found on. Under original_d5 both legs sell at the same D5 "
          "close, so a lift there is entirely the entry price."]
    (out / "REPORT.md").write_text("\n".join(L) + "\n", encoding="utf-8")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="setuplab")
    ap.add_argument("command", nargs="?", choices=("run", "reproduce"))
    ap.add_argument("--data")
    ap.add_argument("--features")
    ap.add_argument("--ledgers")
    ap.add_argument("--out")
    ap.add_argument("--engine", default="D")
    ap.add_argument("--columns", default="", help="comma list of feature columns to test (default: every column)")
    ap.add_argument("--why", default="", help="why_features.csv: test the engine's top --top features by its importance")
    ap.add_argument("--top", type=int, default=50)
    ap.add_argument("--confluence", action="store_true", help="also run the setups x logical confluences stage")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args(argv)
    if a.selftest:
        sys.path.insert(0, str(Path(__file__).resolve().parent / "tests"))
        import test_setuplab
        return test_setuplab.main()
    if not a.command or not a.data or not a.features:
        print("ERROR: give a command, --data and --features (no default paths)")
        return 2
    cols = [c.strip() for c in a.columns.split(",") if c.strip()] or None
    if a.why:
        if not Path(a.why).is_file():
            print("REFUSED: no file %s" % a.why)
            return 3
        cols, skipped = pick_features(a.why, a.top, a.features, a.engine)
        print("%s: the top %d features by the WHY importance (%d skipped before reaching them: %s)" % (
            VERSION, len(cols), len(skipped), ", ".join("%s (%s)" % x for x in skipped[:40])))
        print("  " + ", ".join(cols))
    try:
        book = load(a.data, a.features, a.engine, cols)
    except ValueError as e:
        print("REFUSED: %s" % e)
        return 3
    if a.command == "reproduce":
        if not a.ledgers:
            print("ERROR: --ledgers <folder of the delivered *.csv.gz>")
            return 2
        n, bad, worst = cmd_reproduce(book, a.ledgers)
        print("%s reproduce: %d ledgers compared, %d differ, largest ret difference %.2e pp" % (
            VERSION, n, len(bad), worst))
        for b in bad:
            print("  DIFFERS", *b)
        print("REPRODUCED" if not bad else "NOT REPRODUCED")
        return 0 if not bad else 1
    if not a.out:
        print("ERROR: --out <folder>")
        return 2
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    if cols:
        (out / "features_tested.txt").write_text("\n".join(cols) + "\n", encoding="utf-8")
    cmd_run(book, out, with_confluence=a.confluence)
    return 0


if __name__ == "__main__":
    sys.exit(main())
