# setuplab v0.3 - entry setups for engine D's picks vs the model's D1 entry, on the same trades

Built 7 Nov 2026. Two files: `setuplab.py` and `tests\test_setuplab.py`. Reads ChatGPT's compact backtester data
(read only); writes only into the `--out` folder.

## What it does
- Re-implements the A/B/C backtester's rules (backtest.pyz) vectorised: first qualifying open D1..D5, conditions
  read at the previous session, exits original_d5 or fresh (5 sessions), 0.35 pp cost. **Reproduces all 60
  delivered ledgers exactly** (status, entry day, net; largest difference 7e-15 pp).
- Your comparison: each setup's own filled trades vs the model's D1 entry on exactly those trade ids, with 95%
  circular block-bootstrap intervals over signal days.
- Controls on the same ids (no indicators): blind D2 / D3, price dips (DIP_0..DIP_5 % under the D1 open, DIPATR_x
  ATR), bounce markers (down, then a green day / an up close), Tuesday entries (TUE, TUE_DIP_2 - the weekly
  feature changes on Mondays, so its setups can only fire on a Tuesday open).
- The whole pair space of the features (every pair of change directions = A/B/C's family), B / A+B with dips, and
  an exploration of what adds most on top of a 2% dip.

## Install and run (cmd)
Put the two files in `C:\Users\karanvsi\PyCharmMiscProject\setuplab\` (tests in `setuplab\tests\`). Set `ABC` to
the folder where you extracted BigMove_ABC_Compact (it holds `data\` and `behaviour_features.parquet`).

    cd /d C:\Users\karanvsi\PyCharmMiscProject\setuplab
    set ABC=C:\path\to\BigMove_ABC_Compact
    python setuplab.py --selftest
    python setuplab.py reproduce --data %ABC%\data --features %ABC%\behaviour_features.parquet --ledgers %ABC%\combination_runs\<hash>
    python setuplab.py run --data %ABC%\data --features %ABC%\behaviour_features.parquet --out C:\QuantData\setuplab\RUN_001

Expected: `25 checks, 0 failed` / `VERIFIED (setuplab v0.3)`; reproduce prints `REPRODUCED`; run takes about a
minute. Needs numpy, pandas, pyarrow (scipy not needed).

**Model features (after the engine D rebuild):** point `--features` at any parquet with symbol + timestamp (or
date) and feature columns, and list the columns to test (big panels are read column by column):

    python setuplab.py run --data %ABC%\data --features %CACHE_DAILY_ROOT%\panel\panel.parquet --columns f1,f2,f3 --out C:\QuantData\setuplab\RUN_002

A missing `<feature>_change` column is computed as the change from the symbol's previous row.

## Outputs
`REPORT.md`; `vs_D1.csv` (every setup vs D1, both exits, with coverage and its percentile in the pair space);
`vs_price_controls.csv` (A/B/C and the combos vs every control on the same ids); `by_year.csv`;
`explore_on_dip.csv`; `by_state.csv` (B, A+B, the combos and the 2% dip by the pick's stock state at the signal, vs D1 and vs the dip); `ledgers\` (every non-space setup's trade ledger).

## v0.3 (7 Nov) - top-N model features and logical confluences
- `--why <why_features.csv> --top 50`: tests the engine's top 50 features by the WHY surrogate's importance, skipping
  raw price levels / price-scaled values (SMA/EMA levels, ATR14/30, CPR, support/resistance, breakout levels, OBV,
  MACD), categorical codes, the weekday and combined flags; the list goes to `features_tested.txt`.
- The pair space is streamed (5,000 pairs x 2 exits in about 5 minutes, about 0.5 GB); only the picks' stocks are
  read from the panel.
- `--confluence`: setups x logical confluences, declared in the code before any run. Pool = B, A+B, the pair space's
  top 10 by lift and top 10 by net per trade (n >= 300, interval above 0), and NONE (the confluence alone). Price
  confluences: DIP1/2/3, DIPATR1, GREEN, UPCLOSE, GAPDOWN, GAPUP. Context at the signal: BEARSTATE, BULLSTATE,
  NIFTY above / below its MA50, market bullish / bearish, VIX low / high and weak breadth (median splits of the picks'
  own values), NOT_OVEREXT, VOL_ELEVATED. Every single confluence and every price x context pair. Each vs D1 and vs
  the confluence alone on the same ids, with the number of years net > 0. Writes CONFLUENCE.md, confluence.csv.
- Checks: 25 (snapshot fields, the feature picker, a planted world where the setup adds over a confluence alone).
  The streamed results equal v0.2's on every row; 60 ledgers still reproduced. Noise null: 3,120 pairs of pure
  noise features, none beat D1 with the interval above 0.

## v0.2 (7 Nov)
State-by-state view (report section + by_state.csv). The feature reader accepts a panel stored with symbol / date
as its index and zoned timestamps (checked: identical results to the plain file).

## Verified
21 checks: hand-computed trades (entry, gap, both exits, drawdown, zero changes, missing-data rules, dips, ATR dip,
Tuesday, bounce), and three planted worlds - a real setup is found and beats the dip control; in a fall-then-bounce
world noise setups beat D1 (the waiting trap) but NOT the dip control; in a random walk nothing beats D1.
Plus the 60-ledger reproduction on the real data.

## Read with care
Everything here is exploratory on the history the setups were found on (2020-2026, 2026 included). The combos and the
dip exploration were chosen after the first run. The forward paper ledger is the only clean test.
