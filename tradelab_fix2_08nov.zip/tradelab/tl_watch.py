"""
tl_watch.py - tradelab v1.3.1 (tl_watch v1.2.1, setups add-on): tonight's watchlist with the market around it, every
stock's state and the frozen entry setups, on one page.

    python tl_watch.py --root %CACHE_DAILY_ROOT%                    the latest watchlist the paper test recorded
    python tl_watch.py --root %CACHE_DAILY_ROOT% --date 2026-10-23   a given signal day (rewrite: add --force)
    python tl_watch.py --root %CACHE_DAILY_ROOT% --all-missing      v1.1: every recorded day without a page, oldest
                                                                     first, then the latest (LATE when built late)
    run_tonight.bat                                                  every night: Run Now, pick_meta, this page

READS (read only, never changed):
  paper\\ledger.jsonl                               D's and ENS's top 10 as the paper test recorded them
  research2\\pick_meta\\forward\\PM_cards_YYYYMMDD.csv  pick_meta's numbers for those picks (when published)
  paper\\watchlists\\WL_YYYYMMDD.md                    the paper test's Soul cards (when present; copied verbatim)
  daily bars of the stocks and of NIFTY 50, Midcap 150, Smallcap 250, India VIX; AMFI's lists (sectors\\amfi\\);
  sectors\\sector_map.csv (optional: symbol,index - a sector index in the cache, for sector relative strength)
WRITES (under TRADELAB_OUT only):
  watch\\WATCH_YYYYMMDD.html   the page: market banner, D and ENS tables, a card per stock
  watch\\WATCH_YYYYMMDD.md     the same as text;  WATCH_YYYYMMDD.csv  one row per pick, every column
  watch\\watch_YYYYMMDD.json   settings, versions, the inputs' SHA-256;  watch\\index.jsonl  one line per page written
  watch\\watch_all.csv        v1.1: every page's rows in one table, with when each page was written and if it was LATE
  (a page written at or after 09:00 of the next weekday is marked LATE - not forward evidence)

WHAT A ROW SAYS
  market      the environment at the signal day's close (broad bullish / narrow bullish / mixed / broad bearish,
              HIGH STRESS as a separate flag), breadth, VIX, NIFTY vs Midcap / Smallcap - tl_context's declared labels
  the stock   AMFI size class (membership, the list in force that day), the index it moves with most and its beta
              (sensitivity - a different thing from membership), 20 / 60-session return vs its size index, its home
              index and its sector index (when mapped)
  its state   tl_state: primary state, confidence, sessions in it, phase, event, risk flags, volatility
  pick_meta   P(+5%) / P(+10%) above entry, swing class and range, up-room / down-risk, P(-8%), P(stuck), with
              pick_meta's own marks (! failed its check, base = no skill, (raw) = not corrected)
  setups      v1.2: the frozen entry setups at the next open (setuplab's nightly scan, read only from
              SETUPLAB_OUT\\scan\\scan_YYYYMMDD.csv): on each of tonight's picks what fires / is armed, and a section
              with every pick of the last five sessions that a setup buys at the next open or already holds

Descriptive only. The paper test's picks, ranks and trades are unchanged; nothing here filters or re-ranks a pick.
"""
from __future__ import annotations

import argparse
import datetime as dt
import html
import json
import re
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from tl_common import TLError, VERSION, out_base, parse_day, require_root, say, sha256_file, sha256_text, to_day
import tl_context as C
import tl_research as RS
import tl_setups as SU
import tl_state as S
from tl_context import fin, ordinal, pct, pts

WATCH_VERSION = "tl_watch v1.2.1"
SUB = "watch"
ENGINE_ORDER = ("D", "ENS")
SIZE_INDEX = {"large": "nifty", "mid": "mid", "small": "small"}
PM_COLS = {"up5": ("up5_pct", "p_plus5_pct", "raw_up5_pct"), "up10": ("up10_pct", "raw_up10_pct"),
           "dip8": ("dip8_pct", "p_dip8_pct", "raw_dip8_pct"), "stuck": ("stuck_pct", "p_stuck_pct", "raw_stuck_pct")}
PM_MARK = {"MISCALIBRATED": " !", "NO SKILL": " base", "UNCORRECTED": " (raw)"}
LATE_HOUR = 9
TEXT_COLS = ("state", "state_name", "state_short", "side", "confidence", "phase", "prev_state", "pending", "event",
             "event_status", "event_text", "risks", "notes", "vol_regime", "headline", "invalidation", "state_began",
             "state_confirmed", "warnings", "warnings_unknown", "also_in", "size_class", "amfi_list", "home_index",
             "sector_index", "environment", "env_direction", "stress_reason", "setups")


# ======================================================================
# inputs
# ======================================================================
def read_ledger(root: Path) -> pd.DataFrame:
    """paper\\ledger.jsonl -> date, engine, rank, symbol, score, recorded_at (pick_meta's reader: a record needs date,
    engine, rank, symbol and score; a day's first record of each engine and rank is kept)."""
    p = Path(root) / "paper" / "ledger.jsonl"
    if not p.exists():
        raise TLError(f"paper ledger not found: {p} (the paper test's nightly run writes it)")
    recs, bad = [], 0
    for line in p.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            r = json.loads(line)
        except json.JSONDecodeError:
            bad += 1
            continue
        if isinstance(r, dict) and all(k in r for k in ("date", "engine", "rank", "symbol", "score")):
            recs.append({"date": str(r["date"])[:10], "engine": str(r["engine"]), "rank": int(r["rank"]),
                         "symbol": str(r["symbol"]).strip(), "score": float(r["score"]),
                         "recorded_at": str(r.get("recorded_at") or ""), "line": line.strip()})
    if not recs:
        raise TLError(f"{p} holds no watchlist records (date, engine, rank, symbol, score)")
    L = pd.DataFrame(recs)
    L["signal_day"] = pd.to_datetime(L["date"])
    L = L.drop_duplicates(["date", "engine", "rank"], keep="first").reset_index(drop=True)
    L.attrs["unreadable_lines"] = bad
    return L


def pm_card_path(root: Path, day: pd.Timestamp) -> Path:
    return Path(root) / "research2" / "pick_meta" / "forward" / f"PM_cards_{day:%Y%m%d}.csv"


def wl_path(root: Path, day: pd.Timestamp) -> Path:
    return Path(root) / "paper" / "watchlists" / f"WL_{day:%Y%m%d}.md"


def read_pm(root: Path, day: pd.Timestamp) -> Tuple[Optional[pd.DataFrame], dict]:
    p = pm_card_path(root, day)
    if not p.exists():
        return None, {"file": str(p), "found": False}
    df = pd.read_csv(p)
    need = {"engine", "rank", "symbol"}
    if not need <= set(df.columns):
        return None, {"file": str(p), "found": True, "error": f"columns {sorted(need - set(df.columns))} missing"}
    df["engine"] = df["engine"].astype(str)
    df["rank"] = pd.to_numeric(df["rank"], errors="coerce")
    df["symbol"] = df["symbol"].astype(str).str.strip()
    info = {"file": str(p), "found": True, "sha256": sha256_file(p), "rows": int(len(df)),
            "code": str(df["code"].iloc[0]) if "code" in df.columns and len(df) else "",
            "conf_run": str(df["conf_run"].iloc[0]) if "conf_run" in df.columns and len(df) else ""}
    return df, info


def pm_value(r: dict, ev: str) -> Tuple[float, str]:
    """The number pick_meta's own card shows (its {ev}_pct, else the raw one) and its mark."""
    v = np.nan
    for col in PM_COLS[ev]:
        x = r.get(col)
        if x is not None and fin(x):
            v = float(x)
            break
    marks = dict(x.split("=", 1) for x in str(r.get("conf_marks") or "").split("|") if "=" in x)
    return v, PM_MARK.get(marks.get(ev, ""), "")


def soul_sections(md: str, symbols) -> Dict[str, str]:
    """The paper watchlist's Soul card of each symbol, verbatim: from the heading that names the symbol (in the part
    after the first heading mentioning 'Soul') to the next heading of the same or a higher level."""
    lines = md.splitlines()
    start = next((i for i, x in enumerate(lines) if re.match(r"^#{1,6}\s", x) and "soul" in x.lower()), 0)
    heads = [(i, len(re.match(r"^(#{1,6})\s", x).group(1))) for i, x in enumerate(lines)
             if i >= start and re.match(r"^#{1,6}\s", x)]
    out = {}
    for sym in symbols:
        pat = re.compile(r"(?<![A-Za-z0-9&_-])" + re.escape(sym) + r"(?![A-Za-z0-9&_-])")
        hit = next(((i, lv) for i, lv in heads if i > start and pat.search(lines[i])), None)
        if hit is None:
            continue
        i0, lv = hit
        i1 = next((i for i, l2 in heads if i > i0 and l2 <= lv), len(lines))
        out[sym] = "\n".join(lines[i0:i1]).strip()
    return out


def read_sector_map(root: Path) -> Dict[str, str]:
    p = Path(root) / "sectors" / "sector_map.csv"
    if not p.exists():
        return {}
    try:
        M = pd.read_csv(p, dtype=str)
        cols = {c.strip().lower(): c for c in M.columns}
        if "symbol" in cols and "index" in cols:
            return {str(a).strip(): str(b).strip() for a, b in zip(M[cols["symbol"]], M[cols["index"]])
                    if str(a).strip() and str(b).strip()}
    except Exception:  # noqa: BLE001 - optional file
        return {}
    return {}


# ======================================================================
# assembling the night
# ======================================================================
def market_block(ctx: C.Context, day: pd.Timestamp, strip_n: int = 10) -> dict:
    F = ctx.frame
    p = ctx.ib.pos1(day)
    if p < 0:
        raise TLError(f"{day:%Y-%m-%d} is not a session in NIFTY 50's bars - is the cache updated?")
    r = F.iloc[p].to_dict()
    env = F["environment"].to_numpy(object)
    run = 0
    for j in range(p, -1, -1):
        if env[j] == env[p] and env[p]:
            run += 1
        else:
            break
    lo = max(0, p - strip_n + 1)
    strip = [(pd.Timestamp(F["date"].iat[j]), F["environment"].iat[j] or "", F["high_stress"].iat[j]) for j in range(lo, p + 1)]
    r60 = {}
    for k in C.BROAD:
        a = ctx.ib.a.get(k)
        r60[k] = float(a["close"][p] / a["close"][p - 60] - 1) if a is not None and p >= 60 and fin(a["close"][p]) and fin(a["close"][p - 60]) else np.nan
    return {"row": r, "pos": p, "env_run": run, "strip": strip, "ret60": r60, "sentence": C.day_sentence(r)}


def index_ret(ctx: C.Context, key: str, p: int, w: int) -> float:
    a = ctx.ib.a.get(key)
    if a is None or p - w < 0:
        return np.nan
    x, y = a["close"][p], a["close"][p - w]
    return float(x / y - 1) if fin(x) and fin(y) and y > 0 else np.nan


def series_ret(ds, day, w: int) -> float:
    if ds is None:
        return np.nan
    i = ds.idx(day)
    if i < w:
        return np.nan
    return float(ds.c[i] / ds.c[i - w] - 1) if ds.c[i - w] > 0 else np.nan


def prepare(root: Path, context: str = "full", base: Optional[Path] = None, stage_e_any: bool = False, log=say,
            market=None, cfg: Optional[dict] = None, setups: Optional[str] = None) -> dict:
    """What every day's page shares: the paper ledger, the bars, the market context (built once), the state engine."""
    import tl_data as D
    L = read_ledger(root)
    m = market or D.Market(root, D.Production(stage_e_any=stage_e_any))
    ws = SimpleNamespace(market=m, root=root)
    log(f"market context ({context}) ...")
    ctx = C.build_context(ws, context, base, log=log)
    if ctx is None:
        raise TLError("--context none is not available for the watch page (the market banner needs it)")
    return {"root": Path(root), "L": L, "m": m, "ctx": ctx, "book": S.StateBook(m, cfg), "smap": read_sector_map(root),
            "setups_base": SU.base_dir(setups)}


def ledger_day(L: pd.DataFrame, day=None) -> pd.Timestamp:
    days = sorted(L["signal_day"].unique())
    if day is None:
        return pd.Timestamp(days[-1]).normalize()
    if pd.Timestamp(day) not in set(pd.to_datetime(days)):
        near = [str(pd.Timestamp(d).date()) for d in days[-5:]]
        raise TLError(f"no watchlist recorded for {pd.Timestamp(day):%Y-%m-%d} in the paper ledger (latest: {', '.join(near)})")
    return pd.Timestamp(day).normalize()


def build(root: Path, day: Optional[pd.Timestamp] = None, context: str = "full", base: Optional[Path] = None,
          stage_e_any: bool = False, soul: bool = True, log=say, market=None, cfg: Optional[dict] = None) -> dict:
    """Everything for one signal day (nothing written). market: a tl_data.Market (tests pass their own)."""
    P = prepare(root, context, base, stage_e_any, log, market, cfg)
    return build_day(P, ledger_day(P["L"], day), soul, log)


def build_day(P: dict, day: pd.Timestamp, soul: bool = True, log=say) -> dict:
    root, L, m, ctx, book, smap = P["root"], P["L"], P["m"], P["ctx"], P["book"], P["smap"]
    day = ledger_day(L, day)
    W = L[L["signal_day"] == day].copy()
    W["engine_order"] = W["engine"].map({e: i for i, e in enumerate(ENGINE_ORDER)}).fillna(9)
    W = W.sort_values(["engine_order", "engine", "rank"]).drop(columns="engine_order").reset_index(drop=True)
    mk = market_block(ctx, day)
    T = W[["signal_day", "symbol"]].copy()
    X = ctx.pick_context(T)
    WARN = [(w, RS.flag_of(X, w), RS.known_of(X, w)) for w in RS.DECLARATION["warnings"]]
    log(f"{day:%Y-%m-%d}: stock states for {W['symbol'].nunique()} stocks ...")
    pm, pm_info = read_pm(root, day)
    wl = wl_path(root, day)
    souls, wl_info = {}, {"file": str(wl), "found": wl.exists()}
    if soul and wl.exists():
        txt = wl.read_text(encoding="utf-8", errors="replace")
        souls = soul_sections(txt, sorted(W["symbol"].unique()))
        wl_info.update({"sha256": sha256_file(wl), "soul_cards_found": len(souls)})
    p0 = mk["pos"]
    rows, cards = [], {}
    other = {(e, s): r for e, s, r in zip(W["engine"], W["symbol"], W["rank"])}
    for j, w in enumerate(W.to_dict("records")):
        sym = w["symbol"]
        x = X.iloc[j].to_dict()
        ss = book.series(sym)
        i = ss.idx(day) if ss is not None else -1
        st = ss.row(i) if i >= 0 else None
        ds = m.series(sym)
        size = x.get("pre_size_class") or ""
        sk = SIZE_INDEX.get(size)
        home_key = ""
        for k, nm in C.INDEX_NAME.items():
            if nm == x.get("pre_home_index_name"):
                home_key = k
        rec = {"date": f"{day:%Y-%m-%d}", "engine": w["engine"], "rank": int(w["rank"]), "symbol": sym,
               "score": w["score"], "recorded_at": w["recorded_at"],
               "also_in": ", ".join(f"{e} #{other[(e, sym)]}" for e in ENGINE_ORDER if e != w["engine"] and (e, sym) in other),
               "environment": mk["row"].get("environment", ""), "env_direction": mk["row"].get("env_direction", ""),
               "high_stress": mk["row"].get("high_stress"), "stress_reason": mk["row"].get("stress_reason", ""),
               "breadth": mk["row"].get("ad_ratio"), "breadth_10d": mk["row"].get("ad_ratio_10"), "vix": mk["row"].get("vix"),
               "vix_chg5": mk["row"].get("vix_chg5_pct"), "vix_pct250": mk["row"].get("vix_pct250"),
               "nifty_minus_small_20": mk["row"].get("nifty_minus_small_20"),
               "size_class": size, "amfi_rank": x.get("pre_amfi_rank"), "amfi_list": x.get("pre_amfi_list", ""),
               "home_index": x.get("pre_home_index_name", ""), "beta_home": x.get("pre_beta_home"),
               "corr_home": x.get("pre_corr_home"), "beta_nifty": x.get("pre_beta_nifty"), "beta_mid": x.get("pre_beta_mid"),
               "beta_small": x.get("pre_beta_small"), "stock_ret": x.get("pre_stock_ret"),
               "stock_minus_home": x.get("pre_stock_minus_home")}
        fired = [w[0] for w, f, k in WARN if f[j]]
        rec["warnings"] = ",".join(fired)
        rec["warnings_unknown"] = ",".join(w[0] for w, f, k in WARN if not k[j])
        r20, r60 = series_ret(ds, day, 20), series_ret(ds, day, 60)
        rec["ret20"], rec["ret60"] = r20, r60
        rec["rs20_size"] = r20 - index_ret(ctx, sk, p0, 20) if sk else np.nan
        rec["rs60_size"] = r60 - index_ret(ctx, sk, p0, 60) if sk else np.nan
        rec["rs20_home"] = r20 - index_ret(ctx, home_key, p0, 20) if home_key else np.nan
        rec["rs60_home"] = r60 - index_ret(ctx, home_key, p0, 60) if home_key else np.nan
        sec = smap.get(sym, "")
        sds = m.series(sec) if sec else None
        rec["sector_index"] = sec if sds is not None else ""
        rec["rs20_sector"] = r20 - series_ret(sds, day, 20) if sds is not None else np.nan
        rec["rs60_sector"] = r60 - series_ret(sds, day, 60) if sds is not None else np.nan
        if st is None:
            rec.update({"state": "", "state_name": "no bar on the signal day" if ss is not None else "no daily bars",
                        "headline": "no state (no bar on the signal day)" if ss is not None else "no daily bars"})
        else:
            for k in ("state", "state_name", "state_short", "side", "confidence", "phase", "age", "prev_state", "pending",
                      "pending_n", "support", "conflicts", "completeness", "event", "event_status", "event_age",
                      "event_text", "risks", "notes", "vol_regime", "headline", "invalidation", "d20", "d50", "d200",
                      "s20", "s50", "eff20", "rsi14", "macd_h", "acc", "r5", "atr_pct", "atr_rank", "vol_ratio", "rvol",
                      "vtrend", "flow20", "rng_cons", "pos20", "bull_age", "bear_age"):
                rec[k] = st.get(k)
            rec["state_began"] = f"{st['began']:%Y-%m-%d}" if st.get("began") is not None else ""
            rec["state_confirmed"] = f"{st['confirmed']:%Y-%m-%d}" if st.get("confirmed") is not None else ""
        if pm is not None:
            hit = pm[(pm["engine"] == w["engine"]) & (pm["rank"] == w["rank"]) & (pm["symbol"] == sym)]
            if len(hit):
                pr = hit.iloc[0].to_dict()
                for ev in ("up5", "up10", "dip8", "stuck"):
                    v, mkk = pm_value(pr, ev)
                    rec[f"pm_{ev}"], rec[f"pm_{ev}_mark"] = v, mkk.strip()
                for a, b in (("swing_class", "pm_class"), ("swing_p20_pct", "pm_swing_p20"), ("swing_p50_pct", "pm_swing_p50"),
                             ("swing_p80_pct", "pm_swing_p80"), ("mfe_q50_pct", "pm_up_room"), ("mae_q50_pct", "pm_down_risk"),
                             ("p_swing_lt5_pct", "pm_swing_lt5"), ("p_swing_ge10_pct", "pm_swing_ge10")):
                    rec[b] = pr.get(a, np.nan)
                rec["pm_found"] = True
            else:
                rec["pm_found"] = False
        else:
            rec["pm_found"] = False
        rec["soul_found"] = sym in souls
        rows.append(rec)
        if sym not in cards and st is not None:
            cards[sym] = {"row": st, "ss_index": i, "evidence": ss.evidence(i) if st["state"] in S.STATES else {},
                          "strip": [(ss.day(j2), ss.state[j2], ss.raw[j2]) for j2 in range(max(0, i - 19), i + 1)],
                          "history": ss.history(i), "levels": _levels(ss, i),
                          "events": [dict(e, day=ss.day(e["change"]), start_day=ss.day(e["start"])) for e in ss.events_recent(i)]}
    R = pd.DataFrame(rows)
    # setups add-on: the nightly scan of this evening (what fires / is armed at the next open)
    scan, scan_info = SU.read_scan(P.get("setups_base"), day)
    R["setups"] = [SU.pick_setups_text(scan, e, k, s_, day) for e, k, s_ in zip(R["engine"], R["rank"], R["symbol"])] \
        if len(R) else []
    # a stock without a state (no bar that day) has no state columns: text columns blank, never NaN ('nan' on a page)
    for c in TEXT_COLS:
        if c not in R.columns:
            R[c] = ""
        R[c] = R[c].astype(object).where(R[c].notna(), "")
    mk["warnings"] = [(w[0], w[1]) for w, f, k in WARN if w[0] != "W8" and len(f) and f[0]]
    mk["warnings_unknown"] = [w[0] for w, f, k in WARN if w[0] != "W8" and len(k) and not k[0]]
    return {"day": day, "rows": R, "market": mk, "cards": cards, "souls": souls, "pm_info": pm_info, "wl_info": wl_info,
            "ctx_meta": ctx.run_meta, "ledger": {"file": str(Path(root) / "paper" / "ledger.jsonl"),
                                                  "lines_sha256": sha256_text("\n".join(W["line"])),
                                                  "unreadable_lines": L.attrs.get("unreadable_lines", 0)},
            "cfg": book.cfg, "sector_map": len(smap),
            "setups": {"info": scan_info, "rows": SU.action_rows(scan)}}


def _levels(ss: S.StateSeries, i: int) -> dict:
    A = ss.A
    g = (lambda k: float(A[k][i]) if np.isfinite(A[k][i]) else np.nan)
    out = {k: g(k) for k in ("ema20", "ema50", "ema100", "ema200", "atr", "hi20", "lo20", "hi55", "lo55", "last_hi",
                             "prev_hi", "last_lo", "prev_lo", "cons_top", "cons_floor")}
    out["close"] = float(ss.c[i])
    for nm in ("last_hi", "prev_hi", "last_lo", "prev_lo"):
        p = A[f"{nm}_i"][i]
        out[f"{nm}_day"] = ss.day(int(p)) if np.isfinite(p) else None
    for nm in ("last_hi", "last_lo"):
        kn = A[f"{nm}_known"][i]
        out[f"{nm}_known"] = ss.day(int(kn)) if np.isfinite(kn) else None
    return out


# ======================================================================
# text helpers
# ======================================================================
def _n(x, f="{:.2f}") -> str:
    return f.format(float(x)) if fin(x) else "n/a"


def _pp(x, nd=0) -> str:
    return f"{float(x):.{nd}f}%" if fin(x) else "n/a"


ENV_CLASS = {"broad_bullish": "bb", "narrow_bullish": "nb", "mixed": "mx", "broad_bearish": "br", "high_stress": "hs", "": "na"}
SIDE_CLASS = {"bull": "bull", "turn": "turn", "flat": "flat", "bear": "bear", "wild": "wild", "none": "none"}


def env_words(r: dict) -> str:
    e = r.get("environment") or ""
    if not e:
        return "UNKNOWN (an input is missing)"
    t = C.ENV_TEXT.get(e, e).upper()
    if e == "high_stress" and r.get("env_direction"):
        t += f" (direction: {C.ENV_TEXT.get(r['env_direction'], r['env_direction'])})"
    return t


def market_lines(mk: dict) -> List[str]:
    r = mk["row"]
    hs = r.get("high_stress")
    out = [f"MARKET: {env_words(r)}" + (f" for {mk['env_run']} session{'s' if mk['env_run'] != 1 else ''}" if mk["env_run"] else "")
           + f" | High stress: {'YES - ' + str(r.get('stress_reason')) if hs == 1 else ('no' if hs == 0 else 'unknown')}"]
    idx = []
    for k, nm in (("nifty", "NIFTY 50"), ("mid", "Midcap 150"), ("small", "Smallcap 250")):
        up = r.get(f"{k}_up50")
        idx.append(f"{nm} {pct(r.get(f'{k}_ret'))} day, {pct(r.get(f'{k}_ret20'))} 20d, "
                   f"{'above' if up == 1 else ('below' if up == 0 else 'n/a vs')} its 50-day average")
    out.append("  " + " | ".join(idx))
    br = r.get("ad_ratio")
    out.append(f"  breadth {_n(br)} today ({int(r['adv']):,} up / {int(r['dec']):,} down of {int(r['ad_n']):,} cached stocks), "
               f"10-day {_n(r.get('ad_ratio_10'))} ({'strong' if fin(r.get('ad_ratio_10')) and r['ad_ratio_10'] >= C.AD_STRONG else 'weak'})"
               if fin(br) else "  breadth: n/a (no saved count for this day)")
    out.append(f"  VIX {_n(r.get('vix'), '{:.1f}')} (day {pct(r.get('vix_chg_pct'))}, 5-day {pct(r.get('vix_chg5_pct'), 0)}"
               + (f", {ordinal(round(r['vix_pct250'] * 100))} percentile of 250 sessions" if fin(r.get('vix_pct250')) else "")
               + f") | NIFTY minus Smallcap: day {pts(r.get('nifty_minus_small'))}, 20 days {pts(r.get('nifty_minus_small_20'))}")
    out.append("  last sessions: " + " > ".join(f"{d:%d %b} {C.ENV_TEXT.get(e, 'n/a') if e else 'n/a'}" for d, e, _ in mk["strip"][-6:]))
    out.append("  " + warn_line(mk))
    return out


WARN_TEXT = {w[0]: w[1] for w in RS.DECLARATION["warnings"]}


def warn_line(mk: dict) -> str:
    w = mk.get("warnings") or []
    u = mk.get("warnings_unknown") or []
    out = ("Declared warning signs at this close: " + "; ".join(f"{a} {b}" for a, b in w)) if w else \
        "Declared warning signs at this close: none of W1-W7"
    if u:
        out += f" (unknown: {', '.join(u)} - an input is missing)"
    return out + " - tl_research's signs (research-declaration-2), shown for information; nothing is filtered"


def risk_words(risks: str) -> str:
    return "; ".join(S.RISK_TEXT.get(x, x) for x in str(risks or "").split(",") if x)


def note_words(notes: str) -> str:
    return "; ".join(S.NOTE_TEXT.get(x, x) for x in str(notes or "").split(",") if x)


def event_short(r: dict) -> str:
    k = r.get("event") or ""
    if not k:
        return ""
    code, nm = S.EVENT_NAMES[k]
    st = r.get("event_status")
    age = r.get("event_age")
    when = "today" if age == 0 else f"{age}d ago"
    if k in ("BREAKOUT", "BREAKDOWN"):
        return f"{code} {nm} {st.lower()} ({when})"
    return f"{code + ' ' if code else ''}{nm} ({when})"


def state_short(r: dict) -> str:
    s = r.get("state") or ""
    if not s:
        return r.get("headline", "")
    if s in ("UNKNOWN", "INSUFFICIENT_DATA"):
        return S.SHORT[s]
    ph = (r.get("phase") or "").lower()
    return f"{s} {S.SHORT[s]} - {r.get('confidence')}, {r.get('age')}d {ph}" + (f" (-> {r['pending']}?)" if r.get("pending") else "")


# ======================================================================
# writers
# ======================================================================
def to_md(res: dict) -> str:
    R, mk, day = res["rows"], res["market"], res["day"]
    L = [f"# Watchlist for the open after {day:%a %d %b %Y}", "",
         f"{WATCH_VERSION} | {VERSION} | {S.STATE_VERSION} (settings {S.cfg_hash(res['cfg'])}) | {C.CTX_VERSION} | "
         f"written {res.get('written_at', '')}{' | LATE - not forward evidence' if res.get('late') else ''}", "",
         "Descriptive only: the paper test's picks and trades are unchanged; nothing here filters or re-ranks a pick.", "",
         "## Market", ""] + [x.strip() for x in market_lines(mk)] + ["", mk["sentence"], ""]
    for eng, G in R.groupby("engine", sort=False):
        L += [f"## {eng}", "", "| # | stock | size / moves with | state | event | risks | vol | P(+5%) | P(+10%) | swing class (6 in 10) | P(-8%) | P(stuck) | 20d vs size idx | setups at the next open |",
              "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
        for r in G.to_dict("records"):
            L.append(f"| {'**' + str(r['rank']) + '**' if r['rank'] <= 3 else r['rank']} | {r['symbol']}"
                     f"{' (' + r['also_in'] + ')' if r.get('also_in') else ''} | {_size_txt(r)}"
                     f"{' W8 high beta' if 'W8' in str(r.get('warnings') or '') else ''} | {state_short(r)} | "
                     f"{event_short(r)} | {risk_words(r.get('risks'))} | {(r.get('vol_regime') or '').lower()} | "
                     f"{_pm(r, 'up5')} | {_pm(r, 'up10')} | {_swing(r)} | {_pm(r, 'dip8')} | {_pm(r, 'stuck', 1)} | "
                     f"{pts(r.get('rs20_size'))} | {r.get('setups') or ''} |")
        L += ["", "Bold ranks 1-3: the paper test buys the first 3 not locked at the upper band at the open.", ""]
    L += setups_md(res)
    L += ["## Stock cards", ""]
    for sym, cd in res["cards"].items():
        L += card_md(sym, cd, R[R["symbol"] == sym], res["souls"].get(sym))
    L += _footer_md(res)
    return "\n".join(L) + "\n"


def setups_md(res: dict) -> List[str]:
    """The setups add-on's section: every pick of the last five sessions a frozen setup buys at the next open (or
    already holds), from setuplab's nightly scan."""
    su = res.get("setups") or {}
    info, rows = su.get("info") or {}, su.get("rows") or []
    L = ["## Frozen setups at the next open (picks of the last five sessions)", ""]
    if not info.get("found"):
        return L + [f"Setup scan: {info.get('why', 'not used')}.", ""]
    ot = info.get("on_time")
    L.append(f"setuplab's scan {Path(info['file']).name} (SHA-256 {info['sha256'][:16]})"
             + ("" if ot is None else f", recorded {'ON TIME' if ot else 'LATE - not forward evidence'}") + ".")
    L.append("")
    if not rows:
        return L + ["Nothing fires at the next open and no setup position is open.", ""]
    L += ["| setup | what | stock | engine / rank | signal day | watch day |", "|---|---|---|---|---|---|"]
    for r in rows:
        L.append(f"| {r.get('setup')} | {SU.scan_words(r)} | {r.get('symbol')} | {r.get('engine')} {r.get('rank')} | "
                 f"{r.get('signal_day')} | {('D' + SU.int_text(r.get('next_watch_day'))) if SU.int_text(r.get('next_watch_day')) else ''} |")
    return L + ["", "Descriptive only: the paper test's own trades are unchanged. FIRES = every condition holds at "
                    "tonight's close; ARMED = buy only if the open meets its rule (gap setups); ENTERED = held from an "
                    "earlier watch day.", ""]


def _size_txt(r: dict) -> str:
    sz = r.get("size_class") or ""
    sz = {"large": "large", "mid": "mid", "small": "small", "not in list": "not in AMFI list", "no list": "no AMFI list"}.get(sz, sz or "n/a")
    hm = r.get("home_index") or ""
    return f"{sz} / {hm}" + (f" b {r['beta_home']:.2f}" if fin(r.get("beta_home")) else "") if hm else f"{sz} / n/a"


def _pm(r: dict, ev: str, nd: int = 0) -> str:
    if not r.get("pm_found"):
        return "-"
    v = r.get(f"pm_{ev}")
    return (f"{float(v):.{nd}f}%" if fin(v) else "n/a") + (" " + r[f"pm_{ev}_mark"] if r.get(f"pm_{ev}_mark") else "")


def _swing(r: dict) -> str:
    if not r.get("pm_found") or not fin(r.get("pm_class")):
        return "-"
    return f"{int(r['pm_class'])}: {_n(r.get('pm_swing_p50'), '{:.1f}')}% ({_n(r.get('pm_swing_p20'), '{:.1f}')}-{_n(r.get('pm_swing_p80'), '{:.1f}')}%)"


def card_md(sym: str, cd: dict, rows: pd.DataFrame, soul: Optional[str]) -> List[str]:
    st, lv = cd["row"], cd["levels"]
    r0 = rows.iloc[0].to_dict()
    picks = ", ".join(f"{e} #{k}" for e, k in zip(rows["engine"], rows["rank"]))
    txt = {**S.cond_text(S.STATE_CFG), **S.EXTRA_TEXT}
    L = [f"### {sym} - {picks}", "", f"**State:** {st['headline']}", ""]
    if st["state"] in S.STATES:
        L.append(f"- {S.STATE_NAMES[st['state']]}: began {st['began']:%d %b %Y}, confirmed {st['confirmed']:%d %b %Y} "
                 f"(before it: {st['prev_state'] or '-'}); support {st['support']:.0%}, conflicts {st['conflicts']}, "
                 f"completeness {st['completeness']:.0%}")
        L.append(f"- Invalidation: {st['invalidation']}")
    elif st["state"] == "UNKNOWN":
        L.append(f"- Why unknown: {st['unknown_why']}")
    if st["event_text"]:
        L.append(f"- Event: {st['event_text']}")
    for e in cd["events"]:
        L.append(f"  - {event_line(e)}")
    if st["risks"]:
        L.append(f"- Risk flags: {risk_words(st['risks'])}")
    if st["notes"]:
        L.append(f"- Notes: {note_words(st['notes'])}")
    L.append(f"- Volatility: {(st['vol_regime'] or 'n/a').lower()} (10-session vol {_n(st['vol_ratio'])}x the 60-session; "
             f"ATR {_n(st['atr_pct'] * 100 if fin(st['atr_pct']) else np.nan)}% of price, {_n(st['atr_rank'], '{:.0%}')} rank in its year)")
    hist = cd["history"]
    if hist:
        L.append(f"- Transitions: {transition_chain(hist[-5:])}")
    if cd.get("strip"):
        L.append("- Last 20 sessions: " + " ".join(a2 if a2 in S.PRIMARY else ("?" if a2 == "UNKNOWN" else "-")
                                                   for d2, a2, r2 in cd["strip"]))
    L += ["", f"**Market around it:** {env_words(r0)}; {_size_txt(r0)}; stock {pct(r0.get('stock_ret'))} today "
          f"({pts(r0.get('stock_minus_home'))} vs its home index); 20 days {pct(r0.get('ret20'))} - vs size index "
          f"{pts(r0.get('rs20_size'))}, vs home index {pts(r0.get('rs20_home'))}"
          + (f", vs {r0['sector_index']} {pts(r0.get('rs20_sector'))}" if r0.get("sector_index") else "") +
          f"; 60 days {pct(r0.get('ret60'))} - vs size index {pts(r0.get('rs60_size'))}", ""]
    if r0.get("pm_found"):
        L += [f"**pick_meta:** P(+5%) {_pm(r0, 'up5')}, P(+10%) {_pm(r0, 'up10')}, swing class {_swing(r0)}, up-room "
              f"{_n(r0.get('pm_up_room'), '{:+.1f}')}%, down-risk {_n(r0.get('pm_down_risk'), '{:+.1f}')}%, P(-8%) "
              f"{_pm(r0, 'dip8')}, P(stuck) {_pm(r0, 'stuck', 1)}", ""]
    if cd["evidence"]:
        ev = cd["evidence"]
        mark = (lambda v, a, b: a if v == 1 else (b if v == 0 else "n/a"))
        L.append("**Why this state:** required - " + "; ".join(f"{txt.get(k, k)} [{mark(v, 'yes', 'NO')}]" for k, v in ev["required"]))
        L.append("supporting - " + "; ".join(f"{txt.get(k, k)} [{mark(v, 'holds', 'no')}]" for k, v in ev["supporting"]))
        L.append("conflicting - " + "; ".join(f"{txt.get(k, k)} [{mark(v, 'PRESENT', 'absent')}]" for k, v in ev["conflicting"]))
        L.append("")
    L.append(f"**Measurements:** close {_n(lv['close'], '{:,.2f}')}; EMA20 {_n(st['d20'], '{:+.2f}')} ATR, EMA50 "
             f"{_n(st['d50'], '{:+.2f}')}, EMA200 {_n(st['d200'], '{:+.2f}')}; slopes EMA20 {_n(st['s20'], '{:+.2f}')} / EMA50 "
             f"{_n(st['s50'], '{:+.2f}')} ATR; efficiency {_n(st['eff20'], '{:+.2f}')}; RSI {_n(st['rsi14'], '{:.0f}')}; "
             f"returns 5d {pct(st['r5'])}, 20d {pct(st['r20'])}, 60d {pct(st['r60'])}; relative volume {_n(st['rvol'])}, "
             f"volume flow {_n(st['flow20'], '{:+.2f}')}; last swing high {_n(lv['last_hi'], '{:,.2f}')} "
             f"({_d(lv['last_hi_day'])}, known {_d(lv['last_hi_known'])}), last swing low {_n(lv['last_lo'], '{:,.2f}')} "
             f"({_d(lv['last_lo_day'])}, known {_d(lv['last_lo_known'])})")
    L.append("")
    if soul:
        L += ["**Soul (the paper watchlist's card, verbatim):**", "", soul, ""]
    return L


def transition_chain(hist) -> str:
    """'S02 -> S07 (08 Nov) -> S02 (16 Nov)': the state before the first change, then each new state and the day
    it was confirmed."""
    if not hist:
        return ""
    return " -> ".join([hist[0][2]] + [f"{t} ({b:%d %b})" for a, b, f, t in hist])


def event_line(e: dict) -> str:
    code, nm = S.EVENT_NAMES.get(e["kind"], ("", e["kind"]))
    what = "high" if e["kind"] in ("BREAKOUT", "FAILED_BREAKOUT") else "low"
    st = {"NEW": "detected", "CONFIRMED": "confirmed (held 3 sessions)", "STALLED": "stalled",
          "FAILED": "failed - closed back through the level"}.get(e["status"], e["status"])
    return (f"{e['day']:%d %b}: {code + ' ' if code else ''}{nm} {st} - level {e['level']:,.2f} "
            f"({e['window']}-session {what}, set {e['start_day']:%d %b})")


def _d(x) -> str:
    return f"{pd.Timestamp(x):%d %b}" if x is not None and not pd.isna(x) else "n/a"


def _footer_md(res: dict) -> List[str]:
    pmi, wli = res["pm_info"], res["wl_info"]
    return ["## Sources and definitions", "",
            f"- Picks: {res['ledger']['file']} (this day's lines SHA-256 {res['ledger']['lines_sha256'][:16]})",
            f"- pick_meta: {pmi.get('file')} " + (f"(SHA-256 {pmi['sha256'][:16]}, {pmi.get('code', '')})" if pmi.get("sha256") else
                                                  "- not published for this day" if not pmi.get("found") else f"- {pmi.get('error')}"),
            f"- Soul: {wli.get('file')} " + (f"({wli.get('soul_cards_found', 0)} cards found)" if wli.get("found") else "- not found"),
            f"- Market: tl_context's declared labels ({C.DEFINITIONS['declared']}): " + "; ".join(
                f"{k} = {v}" for k, v in C.DEFINITIONS.items() if k in ("broad_bullish", "narrow_bullish", "broad_bearish",
                                                                        "mixed", "high_stress")),
            "- Size = AMFI membership (the list in force that day); 'moves with' = the index its returns correlate with "
            "most over 120 sessions (sensitivity, not membership); b = beta to it.",
            f"- States: {S.STATE_VERSION}, research defaults declared {S.STATE_CFG['declared']} (STATE_RULES.md). "
            "Confidence is evidence agreement, never a probability.",
            "- P(+5%) / P(+10%) etc.: pick_meta's own numbers and marks (! failed its check, base = no skill, (raw) = not corrected).",
            ""]


CSS = """
:root{--bg:#ffffff;--fg:#1f2328;--mut:#59636e;--line:#d1d9e0;--card:#f6f8fa;--bull:#1a7f37;--bullbg:#dafbe1;
--turn:#0969da;--turnbg:#ddf4ff;--flat:#59636e;--flatbg:#eaeef2;--bear:#cf222e;--bearbg:#ffebe9;--wild:#8250df;
--wildbg:#fbefff;--warn:#9a6700;--warnbg:#fff8c5;--hs:#bc4c00;--hsbg:#fff1e5}
@media (prefers-color-scheme: dark){:root{--bg:#0d1117;--fg:#e6edf3;--mut:#9198a1;--line:#30363d;--card:#161b22;
--bull:#3fb950;--bullbg:#12261e;--turn:#4493f8;--turnbg:#121d2f;--flat:#9198a1;--flatbg:#21262d;--bear:#f85149;
--bearbg:#2d1214;--wild:#ab7df8;--wildbg:#231537;--warn:#d29922;--warnbg:#2b2111;--hs:#db6d28;--hsbg:#2d1a0c}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.45 "Segoe UI",system-ui,
-apple-system,Arial,sans-serif}main{max-width:1280px;margin:0 auto;padding:20px 16px 60px;overflow-wrap:break-word}li,p{overflow-wrap:anywhere}
h1{font-size:21px;margin:0 0 4px}h2{font-size:17px;margin:26px 0 8px}h3{font-size:15px;margin:0}
.mut{color:var(--mut)}.small{font-size:12px}
.banner{border-radius:10px;padding:14px 16px;margin:14px 0;border:1px solid var(--line);background:var(--card)}
.banner .big{font-size:20px;font-weight:700;letter-spacing:.02em}
.banner.b-bb{border-left:8px solid var(--bull)}.banner.b-nb{border-left:8px solid #bf8700}.banner.b-mx{border-left:8px solid var(--flat)}
.banner.b-br{border-left:8px solid var(--bear)}.banner.b-hs{border-left:8px solid var(--hs);background:var(--hsbg)}
.banner.b-na{border-left:8px solid var(--line)}a{color:var(--turn)}.sub{font-size:12px;color:var(--mut);margin-top:3px}
@media (max-width:760px){.opt{display:none}}
.kv{display:flex;flex-wrap:wrap;gap:8px 18px;margin-top:8px}.kv div{min-width:150px}.kv b{display:block;font-size:12px;
color:var(--mut);font-weight:600}
.strip{display:flex;gap:4px;flex-wrap:wrap;margin-top:10px}.strip span{font-size:11px;padding:2px 6px;border-radius:4px;
border:1px solid var(--line)}
.wrap{overflow-x:auto;border:1px solid var(--line);border-radius:8px}table{border-collapse:collapse;width:100%;
font-variant-numeric:tabular-nums}th,td{padding:6px 8px;border-bottom:1px solid var(--line);text-align:left;
vertical-align:top;font-size:13px}th{background:var(--card);font-size:12px;color:var(--mut);white-space:nowrap}
td.num{text-align:right;white-space:nowrap}tr.top td:first-child{font-weight:700}
.chip{display:inline-block;padding:1px 7px;border-radius:10px;font-size:12px;font-weight:600;max-width:100%}
.bull{color:var(--bull);background:var(--bullbg)}.turn{color:var(--turn);background:var(--turnbg)}
.flat{color:var(--flat);background:var(--flatbg)}.bear{color:var(--bear);background:var(--bearbg)}
.wild{color:var(--wild);background:var(--wildbg)}.none{color:var(--mut);background:var(--flatbg)}
.warn{color:var(--warn);background:var(--warnbg)}.hs{color:var(--hs);background:var(--hsbg)}
.env-bb{color:var(--bull);background:var(--bullbg)}.env-nb{color:#9a6700;background:var(--warnbg)}
.env-mx{color:var(--flat);background:var(--flatbg)}.env-br{color:var(--bear);background:var(--bearbg)}
.env-hs{color:var(--hs);background:var(--hsbg)}.env-na{color:var(--mut)}
.card{border:1px solid var(--line);border-radius:10px;padding:14px 16px;margin:14px 0}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px;margin-top:10px}
.grid>div{background:var(--card);border-radius:8px;padding:10px 12px}.grid h4{margin:0 0 6px;font-size:13px;color:var(--mut)}
ul{margin:4px 0 0 18px;padding:0}li{margin:2px 0}.ev li.y::marker{content:"\\2713  ";color:var(--bull)}.ev li.n::marker{content:"\\2717  ";color:var(--bear)}
.ev li.o::marker{content:"\\2013  ";color:var(--mut)}.ev li.o{color:var(--mut)}.ev li.c::marker{content:"!  ";color:var(--bear)}
.ev li.c{color:var(--bear)}.ev li.u::marker{content:"?  ";color:var(--mut)}.ev li.u{color:var(--mut)}
details{margin-top:10px}summary{cursor:pointer;color:var(--turn)}.soul{border-left:3px solid var(--line);padding-left:10px}
.soul table{width:auto}.legend{font-size:12px;color:var(--mut);margin:6px 0}
.sstrip{display:flex;flex-wrap:wrap;gap:2px;margin-top:8px;align-items:center}.sstrip span{font-size:10px;padding:1px 3px;
border-radius:3px;min-width:26px;text-align:center}.sstrip span.mut{min-width:0;margin-left:6px;background:none}
"""


def _chip(text: str, cls: str) -> str:
    return f"<span class='chip {cls}'>{html.escape(text)}</span>"


def _e(x) -> str:
    return html.escape(str(x)) if x is not None else ""


def md_html(md: str) -> str:
    """Markdown of the Soul cards (headings, bold, italics, code, lists, tables, rules) as HTML."""
    out, tab, lst = [], False, None

    def inline(s: str) -> str:
        s = html.escape(s)
        s = re.sub(r"`([^`]+)`", r"<code>\1</code>", s)
        s = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", s)
        s = re.sub(r"(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])", r"<i>\1</i>", s)
        return s
    for line in md.splitlines():
        t = line.rstrip()
        if t.startswith("|"):
            if set(t.replace("|", "").strip()) <= set("-: "):
                continue
            cells = [inline(c.strip()) for c in t.strip("|").split("|")]
            if not tab:
                out.append("<div class='wrap'><table>")
                out.append("<tr>" + "".join(f"<th>{c}</th>" for c in cells) + "</tr>")
                tab = True
            else:
                out.append("<tr>" + "".join(f"<td>{c}</td>" for c in cells) + "</tr>")
            continue
        if tab:
            out.append("</table></div>")
            tab = False
        mm = re.match(r"^\s*([-*]|\d+\.)\s+(.*)$", t)
        if mm:
            kind = "ol" if mm.group(1)[0].isdigit() else "ul"
            if lst != kind:
                if lst:
                    out.append(f"</{lst}>")
                out.append(f"<{kind}>")
                lst = kind
            out.append(f"<li>{inline(mm.group(2))}</li>")
            continue
        if lst:
            out.append(f"</{lst}>")
            lst = None
        hm = re.match(r"^(#{1,6})\s+(.*)$", t)
        if hm:
            lv = min(6, len(hm.group(1)) + 2)
            out.append(f"<h{lv}>{inline(hm.group(2))}</h{lv}>")
        elif re.match(r"^\s*(-{3,}|\*{3,})\s*$", t):
            out.append("<hr>")
        elif t.strip():
            out.append(f"<p>{inline(t)}</p>")
    if tab:
        out.append("</table></div>")
    if lst:
        out.append(f"</{lst}>")
    return "\n".join(out)


def to_html(res: dict) -> str:
    R, mk, day = res["rows"], res["market"], res["day"]
    r = mk["row"]
    env = r.get("environment") or ""
    ec = ENV_CLASS.get(env, "na")
    hs = r.get("high_stress")
    title = f"Watchlist {day:%d %b %Y}"
    H = [f"<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,"
         f"initial-scale=1'><title>{_e(title)}</title><style>{CSS}</style></head><body><main>",
         f"<h1>Watchlist for the open after {day:%a %d %b %Y}</h1>",
         f"<div class='mut small'>{_e(WATCH_VERSION)} &middot; {_e(VERSION)} &middot; {_e(S.STATE_VERSION)} &middot; "
         f"{_e(C.CTX_VERSION)} &middot; written {_e(res.get('written_at', ''))}"
         + (" &middot; <b>LATE - not forward evidence</b>" if res.get("late") else "") +
         " &middot; descriptive only: the paper test's picks and trades are unchanged</div>"]
    # ---- market banner
    kv = []
    for k, nm in (("nifty", "NIFTY 50"), ("mid", "Midcap 150"), ("small", "Smallcap 250")):
        up = r.get(f"{k}_up50")
        kv.append(f"<div><b>{nm}</b>{pct(r.get(f'{k}_ret'))} day &middot; {pct(r.get(f'{k}_ret20'))} 20d &middot; "
                  f"{'above' if up == 1 else ('below' if up == 0 else 'n/a vs')} 50-day avg</div>")
    kv.append(f"<div><b>Breadth (A/D)</b>{_n(r.get('ad_ratio'))} today &middot; {_n(r.get('ad_ratio_10'))} 10-day "
              f"({'strong' if fin(r.get('ad_ratio_10')) and r['ad_ratio_10'] >= C.AD_STRONG else 'weak' if fin(r.get('ad_ratio_10')) else 'n/a'})</div>")
    kv.append(f"<div><b>India VIX</b>{_n(r.get('vix'), '{:.1f}')} &middot; 5-day {pct(r.get('vix_chg5_pct'), 0)}"
              + (f" &middot; {ordinal(round(r['vix_pct250'] * 100))} pct" if fin(r.get('vix_pct250')) else "") + "</div>")
    kv.append(f"<div><b>NIFTY minus Smallcap</b>{pts(r.get('nifty_minus_small'))} day &middot; "
              f"{pts(r.get('nifty_minus_small_20'))} 20d</div>")
    strip = "".join(f"<span class='env-{ENV_CLASS.get(e, 'na')}' title='{d:%a %d %b}'>{d:%d %b} "
                    f"{_e(C.ENV_TEXT.get(e, 'n/a') if e else 'n/a')}</span>" for d, e, _ in mk["strip"])
    H.append(f"<div class='banner b-{ec}'><div class='mut small'>MARKET at the close of {day:%a %d %b}</div>"
             f"<div class='big'>{_e(env_words(r))}</div><div>"
             + (f"in this environment for {mk['env_run']} session{'s' if mk['env_run'] != 1 else ''} &middot; " if mk["env_run"] else "")
             + ("High stress: " + (_chip("YES", "hs") + " " + _e(r.get("stress_reason")) if hs == 1 else
                                   ("no" if hs == 0 else "unknown"))) + "</div>"
             f"<div class='kv'>{''.join(kv)}</div><div class='strip'>{strip}</div>"
             f"<div style='margin-top:8px'>{_chip(warn_line(mk), 'warn') if mk.get('warnings') else _e(warn_line(mk))}</div>"
             f"<div class='small mut' style='margin-top:8px'>{_e(mk['sentence'])}</div></div>")
    H.append("<div class='legend'>States: " + " ".join(_chip(f"{s} {S.SHORT[s]}", SIDE_CLASS[S.SIDE[s]]) for s in
                                                      ("S01", "S02", "S03", "S06", "S07", "S09", "S08", "S12")) +
             " &middot; confidence HIGH / MEDIUM / LOW is evidence agreement, not a probability &middot; phase: early / "
             "mature / deteriorating</div>")
    # ---- tables
    for eng, G in R.groupby("engine", sort=False):
        H.append(f"<h2>{_e(eng)} - top {len(G)}</h2><div class='wrap'><table><tr><th>#</th><th>stock</th>"
                 "<th>stock state &middot; event &middot; risk flags</th><th>vol</th><th>P(+5%)</th><th>P(+10%)</th>"
                 "<th class='opt'>swing class (6 in 10)</th><th class='opt'>P(-8%)</th><th class='opt'>P(stuck)</th>"
                 "<th class='opt'>20d vs size index</th><th>setups at the next open</th></tr>")
        for x in G.to_dict("records"):
            side = SIDE_CLASS.get(x.get("side") or "none", "none")
            st = _chip(state_short(x), side) if x.get("state") else _e(x.get("headline"))
            ev, rk = event_short(x), risk_words(x.get("risks"))
            vr = (x.get("vol_regime") or "").lower()
            H.append(f"<tr class='{'top' if x['rank'] <= 3 else ''}'><td>{x['rank']}</td>"
                     f"<td><a href='#c-{_e(x['symbol'])}'><b>{_e(x['symbol'])}</b></a><div class='sub'>{_e(_size_txt(x))}</div>"
                     + (f"<div class='sub'>{_chip('W8 high beta', 'warn')}</div>" if "W8" in str(x.get("warnings") or "") else "")
                     + (f"<div class='sub'>also {_e(x['also_in'])}</div>" if x.get("also_in") else "") +
                     f"</td><td>{st}" + (f"<div class='sub'>{_e(ev)}</div>" if ev else "")
                     + (f"<div class='sub'>{_chip(rk, 'warn')}</div>" if rk else "") + "</td>"
                     f"<td>{_chip(vr, 'warn') if vr in ('elevated', 'extreme') else _e(vr)}</td>"
                     f"<td class='num'>{_e(_pm(x, 'up5'))}</td><td class='num'>{_e(_pm(x, 'up10'))}</td>"
                     f"<td class='num opt'>{_e(_swing(x))}</td><td class='num opt'>{_e(_pm(x, 'dip8'))}</td>"
                     f"<td class='num opt'>{_e(_pm(x, 'stuck', 1))}</td><td class='num opt'>{_e(pts(x.get('rs20_size')))}</td>"
                     f"<td>{_chip(x['setups'], 'turn') if x.get('setups') else ''}</td></tr>")
        H.append("</table></div><div class='small mut'>Bold ranks 1-3: the paper test buys the first 3 not locked at "
                 "the upper band at the open. Size = AMFI membership; the index after it is the one the stock moves "
                 "with most (b = beta). pick_meta marks: ! failed its check, base = no skill, (raw) = not corrected.</div>")
    # ---- setups add-on
    sl = setups_md(res)
    H.append(f"<h2>{_e(sl[0][3:])}</h2>" + md_html("\n".join(sl[1:])))
    # ---- cards
    H.append("<h2>Stock cards</h2>")
    txt = {**S.cond_text(S.STATE_CFG), **S.EXTRA_TEXT}
    for sym, cd in res["cards"].items():
        rows = R[R["symbol"] == sym]
        r0 = rows.iloc[0].to_dict()
        st, lv = cd["row"], cd["levels"]
        side = SIDE_CLASS.get(st["side"], "none")
        picks = ", ".join(f"{e} #{k}" for e, k in zip(rows["engine"], rows["rank"]))
        H.append(f"<div class='card' id='c-{_e(sym)}'><h3>{_e(sym)} <span class='mut small'>{_e(picks)}</span></h3>"
                 f"<div style='margin-top:6px'>{_chip(st['state'] + ' ' + S.STATE_NAMES.get(st['state'], ''), side)} "
                 + (f"{_chip(st['confidence'], 'none')} " if st["state"] in S.STATES else "")
                 + (f"<span class='mut small'>{st['age']} sessions, {st['phase'].lower()}"
                    + (f"; change to {st['pending']} pending ({st['pending_n']} of {S.STATE_CFG['confirm_n']})" if st["pending"] else "")
                    + "</span>" if st["state"] in S.STATES else "") + "</div>")
        if cd.get("strip"):
            H.append("<div class='sstrip' aria-label='state of the last 20 sessions'>" + "".join(
                f"<span class='{SIDE_CLASS.get(S.SIDE.get(a2, 'none'), 'none')}' title='{d2:%d %b}: {_e(a2)} (reading {_e(r2)})'>"
                f"{_e(a2 if a2 in S.PRIMARY else ('?' if a2 == 'UNKNOWN' else '-'))}</span>" for d2, a2, r2 in cd["strip"])
                + "<span class='mut small'>&larr; last 20 sessions</span></div>")
        g1 = ["<h4>State</h4><ul>"]
        if st["state"] in S.STATES:
            g1.append(f"<li>began {st['began']:%d %b %Y}, confirmed {st['confirmed']:%d %b %Y}; before it: "
                      f"{_e(st['prev_state'] or '-')}</li><li>support {st['support']:.0%}, conflicts {st['conflicts']}, "
                      f"completeness {st['completeness']:.0%}</li><li>invalidation: {_e(st['invalidation'])}</li>")
        elif st["state"] == "UNKNOWN":
            g1.append(f"<li>why unknown: {_e(st['unknown_why'])}</li>")
        if st["event_text"]:
            g1.append(f"<li>event: {_e(st['event_text'])}</li>")
        if st["risks"]:
            g1.append(f"<li>risk flags: {_chip(risk_words(st['risks']), 'warn')}</li>")
        if st["notes"]:
            g1.append(f"<li>notes: {_e(note_words(st['notes']))}</li>")
        g1.append(f"<li>volatility {(st['vol_regime'] or 'n/a').lower()}: 10-session vol {_n(st['vol_ratio'])}x the "
                  f"60-session; ATR {_n(st['atr_pct'] * 100 if fin(st['atr_pct']) else np.nan)}% of price, "
                  f"{_n(st['atr_rank'], '{:.0%}')} rank in its year</li>")
        if cd["history"]:
            g1.append(f"<li>transitions: {_e(transition_chain(cd['history'][-5:]))}</li>")
        g1.append("</ul>")
        g2 = [f"<h4>Market around it</h4><ul><li>{_chip(env_words(r0), 'env-' + ENV_CLASS.get(r0.get('environment') or '', 'na'))}</li>"
              f"<li>size: {_e(r0.get('size_class') or 'n/a')} ({_e(r0.get('amfi_list') or 'no AMFI list')}"
              + (f", rank {int(r0['amfi_rank'])}" if fin(r0.get("amfi_rank")) else "") + ")</li>"
              f"<li>moves with {_e(r0.get('home_index') or 'n/a')}: beta {_n(r0.get('beta_home'))}, correlation "
              f"{_n(r0.get('corr_home'))} (betas NIFTY {_n(r0.get('beta_nifty'))} / Mid {_n(r0.get('beta_mid'))} / Small "
              f"{_n(r0.get('beta_small'))})</li><li>today {pct(r0.get('stock_ret'))} ({pts(r0.get('stock_minus_home'))} vs home index)</li>"
              f"<li>20 days {pct(r0.get('ret20'))}: vs size index {pts(r0.get('rs20_size'))}, vs home {pts(r0.get('rs20_home'))}"
              + (f", vs {_e(r0['sector_index'])} {pts(r0.get('rs20_sector'))}" if r0.get("sector_index") else "") +
              f"</li><li>60 days {pct(r0.get('ret60'))}: vs size index {pts(r0.get('rs60_size'))}, vs home {pts(r0.get('rs60_home'))}</li></ul>"]
        g3 = ["<h4>pick_meta</h4>"]
        if r0.get("pm_found"):
            g3.append(f"<ul><li>P(+5%) {_e(_pm(r0, 'up5'))} &middot; P(+10%) {_e(_pm(r0, 'up10'))}</li><li>swing class "
                      f"{_e(_swing(r0))}</li><li>up-room {_n(r0.get('pm_up_room'), '{:+.1f}')}% &middot; down-risk "
                      f"{_n(r0.get('pm_down_risk'), '{:+.1f}')}%</li><li>P(-8%) {_e(_pm(r0, 'dip8'))} &middot; P(stuck) "
                      f"{_e(_pm(r0, 'stuck', 1))}</li></ul>")
        else:
            g3.append("<p class='mut'>no pick_meta card for this pick</p>")
        H.append(f"<div class='grid'><div>{''.join(g1)}</div><div>{''.join(g2)}</div><div>{''.join(g3)}</div></div>")
        if cd["evidence"]:
            ev = cd["evidence"]
            marks = {"required": ("y", "n"), "supporting": ("y", "o"), "conflicting": ("c", "o")}
            parts = []
            for part, nm in (("required", "required (all must hold)"), ("supporting", "supporting (&#10003; holds, "
                                                                                     "&ndash; does not)"),
                             ("conflicting", "conflicting (! present, &ndash; absent)")):
                yes, no = marks[part]
                parts.append(f"<div><h4>{nm}</h4><ul class='ev'>" + "".join(
                    f"<li class='{yes if v == 1 else (no if v == 0 else 'u')}'>{_e(txt.get(k, k))}"
                    f"{' (cannot be evaluated)' if not (v == 1 or v == 0) else ''}</li>" for k, v in ev[part]) + "</ul></div>")
            H.append(f"<details><summary>Why {st['state']}: the evidence</summary><div class='grid'>{''.join(parts)}</div></details>")
        meas = [("close", _n(lv["close"], "{:,.2f}")), ("ATR", f"{_n(lv['atr'], '{:,.2f}')} ({_n(st['atr_pct'] * 100 if fin(st['atr_pct']) else np.nan)}%)"),
                ("EMA20 / 50 / 200", f"{_n(lv['ema20'], '{:,.2f}')} / {_n(lv['ema50'], '{:,.2f}')} / {_n(lv['ema200'], '{:,.2f}')}"),
                ("close vs EMA20 / 50 / 200 (ATR)", f"{_n(st['d20'], '{:+.2f}')} / {_n(st['d50'], '{:+.2f}')} / {_n(st['d200'], '{:+.2f}')}"),
                ("EMA20 / EMA50 slope (ATR)", f"{_n(st['s20'], '{:+.2f}')} / {_n(st['s50'], '{:+.2f}')}"),
                ("efficiency 20d", _n(st["eff20"], "{:+.2f}")), ("RSI 14 / MACD hist (ATR)", f"{_n(st['rsi14'], '{:.0f}')} / {_n(st['macd_h'], '{:+.2f}')}"),
                ("returns 5 / 20 / 60d", f"{pct(st['r5'])} / {pct(st['r20'])} / {pct(st['r60'])}"),
                ("relative volume / flow 20d", f"{_n(st['rvol'])} / {_n(st['flow20'], '{:+.2f}')}"),
                ("20-session range", f"{_n(lv['lo20'], '{:,.2f}')} - {_n(lv['hi20'], '{:,.2f}')} (position {_n(st['pos20'], '{:.0%}')})"),
                ("55-session range", f"{_n(lv['lo55'], '{:,.2f}')} - {_n(lv['hi55'], '{:,.2f}')}"),
                ("last swing high", f"{_n(lv['last_hi'], '{:,.2f}')} on {_d(lv['last_hi_day'])}, known {_d(lv['last_hi_known'])}"
                                    f" (before: {_n(lv['prev_hi'], '{:,.2f}')} {_d(lv['prev_hi_day'])})"),
                ("last swing low", f"{_n(lv['last_lo'], '{:,.2f}')} on {_d(lv['last_lo_day'])}, known {_d(lv['last_lo_known'])}"
                                   f" (before: {_n(lv['prev_lo'], '{:,.2f}')} {_d(lv['prev_lo_day'])})")]
        H.append("<details><summary>Measurements</summary><div class='wrap'><table>" + "".join(
            f"<tr><td>{_e(a)}</td><td class='num'>{_e(b)}</td></tr>" for a, b in meas) + "</table></div></details>")
        if cd["events"]:
            H.append("<details><summary>Events of the last 20 sessions</summary><ul>" + "".join(
                f"<li>{_e(event_line(e))}</li>" for e in cd["events"]) + "</ul></details>")
        soul = res["souls"].get(sym)
        if soul:
            H.append(f"<details><summary>Soul (the paper watchlist's card, verbatim)</summary><div class='soul'>{md_html(soul)}</div></details>")
        H.append("</div>")
    H.append("<h2>Sources and definitions</h2><ul class='small'>" + "".join(f"<li>{_e(x[2:])}</li>" for x in _footer_md(res) if x.startswith("- ")) + "</ul>")
    H.append("</main></body></html>")
    return "\n".join(H)


def console(res: dict) -> str:
    R, mk, day = res["rows"], res["market"], res["day"]
    L = ["", "=" * 110, f"  WATCHLIST for the open after {day:%a %d %b %Y}  ({WATCH_VERSION}; descriptive - picks unchanged)", "=" * 110]
    L += ["  " + x for x in market_lines(mk)]
    for eng, G in R.groupby("engine", sort=False):
        L.append(f"\n  {eng}:  #  symbol        size   state                                     event                    risks / vol           P(+5%)  P(+10%)")
        for r in G.to_dict("records"):
            rk = risk_words(r.get("risks"))
            vr = (r.get("vol_regime") or "").lower()
            rv = ", ".join(x for x in (rk[:28], f"vol {vr}" if vr in ("elevated", "extreme") else "") if x)
            L.append(f"      {'*' if r['rank'] <= 3 else ' '}{r['rank']:>2}  {r['symbol']:<13} {str(r.get('size_class') or '-')[:5]:<6} "
                     f"{state_short(r)[:41]:<41} {event_short(r)[:24]:<24} {rv[:21]:<21} {_pm(r, 'up5'):>7} {_pm(r, 'up10'):>7}")
    L.append("  * = ranks 1-3 (the paper test buys the first 3 not locked at the upper band at the open)")
    return "\n".join(L)


def is_late(written: dt.datetime, day: pd.Timestamp) -> bool:
    nxt = day + pd.offsets.BDay(1)
    return pd.Timestamp(written) >= pd.Timestamp(nxt.date()) + pd.Timedelta(hours=LATE_HOUR)


def write(res: dict, base: Path, force: bool = False, now: Optional[dt.datetime] = None, log=say) -> Optional[Dict[str, Path]]:
    d = Path(base) / SUB
    d.mkdir(parents=True, exist_ok=True)
    day = res["day"]
    stem = f"{day:%Y%m%d}"
    files = {"html": d / f"WATCH_{stem}.html", "md": d / f"WATCH_{stem}.md", "csv": d / f"WATCH_{stem}.csv",
             "json": d / f"watch_{stem}.json"}
    rewrite = files["html"].exists()
    if rewrite and not force:
        log(f"already written: {files['html']} (rerun with --force to rewrite; the index keeps every version's line)")
        return None
    now = now or dt.datetime.now()
    res["written_at"] = now.isoformat(timespec="seconds")
    res["late"] = is_late(now, day)
    files["html"].write_text(to_html(res), encoding="utf-8")
    files["md"].write_text(to_md(res), encoding="utf-8")
    out = res["rows"].drop(columns=[c for c in ("line",) if c in res["rows"].columns])
    out.to_csv(files["csv"], index=False, float_format="%.10g")
    import tl_dictionary as DD
    DD.write(d, {"watch": list(out.columns)}, "Data dictionary - tradelab watch (WATCH_YYYYMMDD.csv)")
    meta = {"tool": WATCH_VERSION, "version": VERSION, "state_version": S.STATE_VERSION, "ctx_version": C.CTX_VERSION,
            "date": f"{day:%Y-%m-%d}", "written_at": res["written_at"], "late": res["late"], "rewrite": rewrite,
            "state_settings": res["cfg"], "state_settings_hash": S.cfg_hash(res["cfg"]), "ledger": res["ledger"],
            "pick_meta": res["pm_info"], "paper_watchlist": res["wl_info"], "context": {k: res["ctx_meta"].get(k) for k in
                                                                                      ("mode", "breadth_source", "missing_indices")},
            "sector_map_entries": res["sector_map"], "market": {k: (v if not isinstance(v, float) or np.isfinite(v) else None)
                                                                for k, v in res["market"]["row"].items() if k != "date"},
            "setups": (res.get("setups") or {}).get("info")}
    files["json"].write_text(json.dumps(meta, indent=2, default=str), encoding="utf-8")
    line = {"date": meta["date"], "written_at": meta["written_at"], "late": meta["late"], "rewrite": rewrite,
            "tool": WATCH_VERSION, "files": {p.name: sha256_file(p) for p in files.values()}}
    with open(d / "index.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(line) + "\n")
    return files


def missing_days(L: pd.DataFrame, base: Path) -> List[pd.Timestamp]:
    """Recorded days without a page yet, oldest first."""
    d = Path(base) / SUB
    return [pd.Timestamp(x).normalize() for x in sorted(L["signal_day"].unique())
            if not (d / f"WATCH_{pd.Timestamp(x):%Y%m%d}.html").exists()]


def write_all(base: Path) -> Optional[Path]:
    """watch_all.csv: every page's rows in one table (oldest first), with when each page was written and whether
    it was LATE. Rebuilt from the pages on every run."""
    d = Path(base) / SUB
    parts = []
    for f in sorted(d.glob("WATCH_*.csv")):
        if not re.fullmatch(r"WATCH_\d{8}\.csv", f.name):  # v1.2.1: Windows matches names case-insensitively, so
            continue                                          # watch_all.csv itself came back as a page (rows doubled)
        try:
            X = pd.read_csv(f)
        except Exception:  # noqa: BLE001 - an unreadable page is skipped, never fatal
            continue
        js = d / f"watch_{f.stem[len('WATCH_'):]}.json"
        meta = json.loads(js.read_text(encoding="utf-8")) if js.exists() else {}
        parts.append(X.assign(page_written_at=meta.get("written_at", ""), page_late=meta.get("late")))
    if not parts:
        return None
    A = pd.concat(parts, ignore_index=True)
    A = A.sort_values(["date", "engine", "rank"], kind="mergesort").reset_index(drop=True)
    fp = d / "watch_all.csv"
    A.to_csv(fp, index=False, float_format="%.10g")
    import tl_dictionary as DD
    DD.write(d, {"watch": [c for c in A.columns if not c.startswith("page_")], "watch_all": list(A.columns)},
             "Data dictionary - tradelab watch (WATCH_YYYYMMDD.csv, watch_all.csv)")
    return fp


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="tradelab: tonight's watchlist with market context and stock states")
    ap.add_argument("--root")
    ap.add_argument("--date", default=None, help="signal day YYYY-MM-DD (default: the latest in the paper ledger)")
    ap.add_argument("--out", default=None, help="output folder (default TRADELAB_OUT)")
    ap.add_argument("--context", default="full", choices=["full", "auto", "saved", "indices"],
                    help="breadth: full = recount when the saved count is older than the cache (about a minute)")
    ap.add_argument("--force", action="store_true", help="rewrite a day already written")
    ap.add_argument("--all-missing", action="store_true",
                    help="build a page for every recorded day that has none yet (oldest first; days built after 09:00 "
                         "of their next weekday are marked LATE), then the latest day")
    ap.add_argument("--no-soul", action="store_true", help="do not copy the paper watchlist's Soul cards")
    ap.add_argument("--stage-e-any", action="store_true")
    ap.add_argument("--quiet", action="store_true")
    ap.add_argument("--setups", default=None, help="setuplab's output folder (default: SETUPLAB_OUT) - the frozen setups "
                    "at the next open, from its nightly scan")
    a = ap.parse_args(argv)
    try:
        root = require_root(a.root)
        base = out_base(a.out, root)
        log = (lambda m: None) if a.quiet else say
        P = prepare(root, a.context, base, a.stage_e_any, log, setups=a.setups)
        latest = ledger_day(P["L"], None)
        failed: List[pd.Timestamp] = []
        if a.all_missing:
            todo = missing_days(P["L"], base)
            if a.force and latest not in todo:
                todo.append(latest)
            if todo:
                log(f"pages to build: {len(todo)} ({todo[0]:%Y-%m-%d} .. {todo[-1]:%Y-%m-%d})")
            res, files = None, None
            for d in todo:
                try:
                    r_ = build_day(P, d, not a.no_soul, log)
                    f_ = write(r_, base, a.force and d == latest, log=log)
                except TLError as e:
                    failed.append(d)
                    log(f"   {d:%Y-%m-%d}: NOT BUILT - {e}")
                    continue
                except Exception as e:  # noqa: BLE001 - an earlier day's page never stops tonight's; tonight's raises
                    if d == latest:
                        raise
                    failed.append(d)
                    log(f"   {d:%Y-%m-%d}: NOT BUILT - {type(e).__name__}: {e}")
                    continue
                if f_ is not None:
                    log(f"   {d:%Y-%m-%d}: {f_['html'].name}{' (LATE - not forward evidence)' if r_['late'] else ''}")
                if d == latest:
                    res, files = r_, f_
            fa = write_all(base)
            if fa is not None:
                log(f"all pages in one table: {fa}")
            if latest in failed:
                print(f"ERROR: the latest day {latest:%Y-%m-%d} could not be built (see above)")
                return 2
            if res is None:
                built = len(todo) - len(failed)
                print((f"built {built} missing page(s); " if built else "nothing new: ") +
                      f"the latest day {latest:%Y-%m-%d} already had its page: "
                      f"{Path(base) / SUB / f'WATCH_{latest:%Y%m%d}.html'}" +
                      (f"\n  note: {len(failed)} earlier day(s) could not be built: " +
                       ", ".join(f"{d:%Y-%m-%d}" for d in failed) if failed else ""))
                return 0
        else:
            res = build_day(P, parse_day(a.date) if a.date else latest, not a.no_soul, log)
            files = write(res, base, a.force, log=log)
            if files is None:
                return 0
            write_all(base)
        print(console(res))
        print(f"\n  page: {files['html']}\n  text: {files['md']}\n  table: {files['csv']}"
              + ("\n  LATE: written after 09:00 of the next weekday - not forward evidence" if res["late"] else ""))
        pmi = res["pm_info"]
        if not pmi.get("found"):
            print("  note: pick_meta's card for this day is not published yet (publish it, then run this again with --force)")
        if failed:
            print(f"  note: {len(failed)} earlier day(s) could not be built: " + ", ".join(f"{d:%Y-%m-%d}" for d in failed))
        return 0
    except TLError as e:
        print(f"ERROR: {e}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
