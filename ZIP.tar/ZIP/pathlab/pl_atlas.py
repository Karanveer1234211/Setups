"""
pl_atlas.py - pathlab v1.0: the conditional atlas.

For every state x regime cell (9 x 5 = 45), every state over all regimes, every regime over all states and the whole
universe (60 groups), in three periods (all, discovery, confirmation) and two datasets (daily paths; 3-minute
paths): support, family odds and the path measures, each with a 95% interval from the date-block bootstrap
(circular blocks of 10 consecutive T0 dates, every stock of a drawn date kept together, 2,000 resamples, seed 7).

Tests: each cell against (a) everything, (b) the same regime with all states (what the state adds), (c) the same
state in all regimes (what the regime adds); each margin against everything; each family against the random-walk
version. Benjamini-Hochberg at 5% over every test of a period. Labels (declared):
  verified     passes the false-discovery control in the discovery period AND its 95% interval in the confirmation
               period (families frozen) excludes zero in the same direction; supported in both periods
  hypothesis   passes in one period only
  inconclusive supported in both periods, passes in neither
  insufficient below the minimum support in either period
  unstable     a verified or hypothesis result whose yearly sign flips in more than a third of its supported years,
               or that is significant in both periods in opposite directions
"""
from __future__ import annotations

import time
from pathlib import Path
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

import pl_common as PC
import pl_build as PB
import pl_families as PF
import pl_paths as PP

ATLAS_VERSION = "pl_atlas v1.0"
NS, NR = len(PC.CELL_STATES), len(PC.REGIMES)
NG = NS * NR + NS + NR + 1                      # 45 cells + 9 state margins + 5 regime margins + everything = 60
G_ALL = NG - 1
SI_OF = {PC.STATE_CODES[s]: i for i, s in enumerate(PC.CELL_STATES)}


def g_state(si):
    return NS * NR + si


def g_regime(ri):
    return NS * NR + NS + ri


def group_label(g: int) -> Tuple[str, str, str]:
    """(kind, state, regime)."""
    if g < NS * NR:
        return "cell", PC.CELL_STATES[g // NR], PC.REGIMES[g % NR]
    if g < NS * NR + NS:
        return "state", PC.CELL_STATES[g - NS * NR], "all"
    if g < G_ALL:
        return "regime", "all", PC.REGIMES[g - NS * NR - NS]
    return "all", "all", "all"


def group_text(g: int) -> str:
    k, s, r = group_label(g)
    if k == "cell":
        return f"{s} {PC.STATE_SHORT[s]} x {PC.REGIME_TEXT[r]}"
    if k == "state":
        return f"{s} {PC.STATE_SHORT[s]} (all regimes)"
    if k == "regime":
        return f"{PC.REGIME_TEXT[r]} (all states)"
    return "Everything"


# ======================================================================
# the measures
# ======================================================================
class Measure:
    def __init__(self, name: str, kind: str, unit: str, text: str, fn: Callable[[pd.DataFrame], np.ndarray]):
        self.name, self.kind, self.unit, self.text, self.fn = name, kind, unit, text, fn


def _a(F, c, dtype=float):
    return F[c].to_numpy(dtype) if c in F.columns else np.full(len(F), np.nan)


def daily_registry(kf: int, D: dict, prefix: str = "F") -> List[Measure]:
    """kf = number of daily families (0 = none)."""
    M: List[Measure] = []

    def path(F):
        return (_a(F, "complete") == 1) & (_a(F, "ca") == 0)

    def mean(col, unit, text, scale=1.0, shift=0.0):
        M.append(Measure(col if shift == 0 else f"{col}_net", "mean", unit, text,
                         lambda F, c=col: np.where(path(F), _a(F, c) * scale + shift, np.nan)))

    def prob(name, text, cond, base=None):
        def fn(F, cond=cond, base=base):
            ok = path(F) if base is None else base(F)
            v = cond(F).astype(float)
            return np.where(ok, v, np.nan)
        M.append(Measure(name, "prob", "share", text, fn))

    def nanprob(col, text):                     # a 0/1/NaN column computed in the build (NaN = condition not met)
        M.append(Measure(col, "prob", "share", text, lambda F, c=col: np.where(path(F), _a(F, c), np.nan)))

    for j in range(kf):
        prob(f"fam:{prefix}{j + 1:02d}", f"share of paths in {'family' if prefix == 'F' else 'region'} {prefix}{j + 1:02d}",
             lambda F, j=j: _a(F, "fam") == j,
             base=lambda F: path(F) & (_a(F, "fam") >= 0))
    M.append(Measure("incomplete", "prob", "share", "window has a missing session (suspension, delisting)",
                     lambda F: (_a(F, "complete") != 1).astype(float)))
    M.append(Measure("ca_flag", "prob", "share", "corporate-action suspect in the window or the 60 sessions before T0",
                     lambda F: (_a(F, "ca") == 1).astype(float)))
    prob("r5_pos", "5-day close above C0", lambda F: _a(F, "r5_a") > 0)
    mean("r5_a", "ATR", "5-day close from C0")
    mean("r5o_p", "%", "BigMove's trade: session-1 open to session-5 close, before costs")
    M.append(Measure("r5o_net", "mean", "%", "the same after 35 bp round-trip costs",
                     lambda F: np.where(path(F), _a(F, "r5o_p") - 0.0035, np.nan)))
    mean("mfe_a", "ATR", "best high of the window from C0 (MFE)")
    mean("mae_a", "ATR", "worst low of the window from C0 (MAE)")
    mean("mfe_p", "%", "MFE in percent of C0")
    mean("mae_p", "%", "MAE in percent of C0")
    mean("gap_a", "ATR", "session-1 opening gap from C0")
    prob("gap_up", "gap of +0.5 ATR or more", lambda F: _a(F, "gap_a") >= 0.5)
    prob("gap_dn", "gap of -0.5 ATR or less", lambda F: _a(F, "gap_a") <= -0.5)
    for col, side, x, is_atr in PP.threshold_specs(D):
        lab = (f"{'+' if side == 'up' else '-'}{x:g} ATR" if is_atr else f"{'+' if side == 'up' else '-'}{x * 100:g}%")
        prob(col, f"reached {lab} at some point in the 5 sessions", lambda F, c=col: _a(F, c) > 0)
    for col, cu, cd in PP.order_specs(D):
        prob(f"{col}:tie", f"{col}: both reached in one session, order unknown at daily resolution", lambda F, c=col: _a(F, c) == 3)
        prob(f"{col}:none", f"{col}: neither reached", lambda F, c=col: _a(F, c) == 0)
        if col != "ord_a1_1":
            M.append(Measure(f"{col}:up", "prob", "share", f"{col}: the up level first (of those resolved)",
                             lambda F, c=col: np.where(path(F) & np.isin(_a(F, c), [1, 2]), (_a(F, c) == 1).astype(float), np.nan)))
    nanprob("up_first_a1", "+1 ATR before -1 ATR (of the paths where one came first)")
    nanprob("rec_d1_endup", "after -1 ATR came first: ended above C0")
    nanprob("rec_d1_backc0", "after -1 ATR came first: back to C0 later")
    nanprob("rec_d1_toup1", "after -1 ATR came first: went on to +1 ATR")
    nanprob("rec_d2_endup", "after reaching -2 ATR: ended above C0")
    nanprob("rec_p5_endup", "after reaching -5%: ended above C0")
    nanprob("cont_up", "after a session-1 close >= +0.5 ATR: session 5 closed higher still")
    nanprob("rev_up", "after a session-1 close >= +0.5 ATR: ended below C0")
    nanprob("cont_dn", "after a session-1 close <= -0.5 ATR: session 5 closed lower still")
    nanprob("rev_dn", "after a session-1 close <= -0.5 ATR: ended above C0")
    for s in range(1, 6):
        prob(f"high_s{s}", f"the window's high came in session {s}", lambda F, s=s: _a(F, "mfe_s") == s)
    for s in range(1, 6):
        prob(f"low_s{s}", f"the window's low came in session {s}", lambda F, s=s: _a(F, "mae_s") == s)
    for s in range(1, 6):
        prob(f"bestc_s{s}", f"the highest close came in session {s}", lambda F, s=s: _a(F, "best_close_s") == s)
    for s in range(1, 6):
        prob(f"worstc_s{s}", f"the lowest close came in session {s}", lambda F, s=s: _a(F, "worst_close_s") == s)
    mean("n_up", "sessions", "up closes out of 5")
    prob("all_up", "five up closes in a row", lambda F: _a(F, "sign_code") == 31)
    prob("all_down", "five down closes in a row", lambda F: _a(F, "sign_code") == 0)
    prob("vol_expand", "sessions 4-5 ranged more than sessions 1-2", lambda F: _a(F, "vol45_12") > 1)
    prob("rv_up", "window volatility above the 20 sessions before T0", lambda F: _a(F, "rv_ratio") > 1)
    for code, nm in PC.STAGE_NAMES.items():
        prob(f"stg1_{nm.lower()}", f"session 1 stage {nm}", lambda F, code=code: _a(F, "stg1") == code)
    for sq, txt in (("sq_dsr", "decline -> stabilisation -> recovery"), ("sq_ce", "compression -> expansion"),
                    ("sq_brc", "breakout -> rejection -> continuation"), ("sq_ree", "recovery -> exhaustion -> reversal")):
        prob(sq, f"sequence: {txt}", lambda F, c=sq: _a(F, c) > 0)
    prob("locked_any", "a session with no trading range (high = low)", lambda F: _a(F, "n_locked") > 0)
    prob("st_same5", "same tl_state state at the session-5 close as at T0", lambda F: _a(F, "st5") == _a(F, "state0"),
         base=lambda F: path(F) & (_a(F, "st5") > -2))
    prob("st_changed", "the state changed (confirmed) inside the window", lambda F: _a(F, "st_first_change") > 0)
    for v, nm in ((0, "held"), (1, "improved"), (2, "worsened")):
        prob(f"rg_{nm}", f"market regime at the session-5 close vs T0: {nm}", lambda F, v=v: _a(F, "rg_class") == v,
             base=lambda F: path(F) & (_a(F, "rg_class") >= 0))
    for col, txt in (("tu_a1", "+1 ATR"), ("td_a1", "-1 ATR")):
        M.append(Measure(f"{col}_sess", "mean", "session", f"session of the first touch of {txt} (of those touched)",
                         lambda F, c=col: np.where(path(F) & (_a(F, c) > 0), _a(F, c), np.nan)))
    mean("nifty_r5", "%", "NIFTY 50 over the same five sessions")
    return M


def intraday_registry(kf: int, D: Optional[dict] = None, prefix: str = "I") -> List[Measure]:
    M: List[Measure] = []

    def win(F):
        return (_a(F, "iok") == 1) & (_a(F, "ca") == 0)

    def s1(F):
        return (_a(F, "iu1") == 1) & (_a(F, "ca") == 0)

    def add(name, kind, unit, text, cond, base):
        M.append(Measure(name, kind, unit, text,
                         lambda F, cond=cond, base=base: np.where(base(F), cond(F).astype(float), np.nan)))

    for j in range(kf):
        add(f"ifam:{prefix}{j + 1:02d}", "prob", "share",
            f"share of 3-minute paths in intraday {'family' if prefix == 'I' else 'region'} {prefix}{j + 1:02d}",
            lambda F, j=j: _a(F, "ifam") == j, lambda F: win(F) & (_a(F, "ifam") >= 0))
    for col, txt in (("iup_first_a1", "+1 ATR before -1 ATR, 3-minute resolution (of those resolved)"),
                     ("irec_d1_backc0", "after -1 ATR came first: back to C0 later (3-minute)"),
                     ("irec_d1_toup1", "after -1 ATR came first: on to +1 ATR (3-minute)")):
        M.append(Measure(col, "prob", "share", txt, lambda F, c=col: np.where(win(F), _a(F, c), np.nan)))
    add("iord_a1_1:tie", "prob", "share", "+1 and -1 ATR first reached in the same 3-minute bar",
        lambda F: _a(F, "iord_a1_1") == 3, win)
    for h in range(13):
        a = 9 * 60 + 15 + 30 * h
        lab = f"{a // 60:02d}:{a % 60:02d}"
        add(f"ihigh_t{h:02d}", "prob", "share", f"the window's high fell in the half hour from {lab}",
            lambda F, h=h: (_a(F, "imfe_bar") % PP.NB) * 3 // 30 == h, win)
        add(f"ilow_t{h:02d}", "prob", "share", f"the window's low fell in the half hour from {lab}",
            lambda F, h=h: (_a(F, "imae_bar") % PP.NB) * 3 // 30 == h, win)
    for col, txt in (("m15_a", "first 15 minutes: move from the open"), ("m30_a", "first 30 minutes: move from the open"),
                     ("m60_a", "first hour: move from the open"), ("r15_a", "first 15 minutes: range"),
                     ("r30_a", "first 30 minutes: range"), ("r60_a", "first hour: range"),
                     ("vwp_a1", "session 1: close against the session VWAP"), ("lh_a1", "session 1: last-hour move")):
        add(col, "mean", "ATR", txt, lambda F, c=col: _a(F, c), s1)
    add("drive_up", "prob", "share", "session 1 opened with an up drive (+0.25 ATR in 30 minutes)",
        lambda F: _a(F, "drive") == 1, s1)
    add("drive_dn", "prob", "share", "session 1 opened with a down drive (-0.25 ATR in 30 minutes)",
        lambda F: _a(F, "drive") == -1, s1)
    for col, txt in (("rej_up", "session 1: rallied 0.5 ATR then gave 0.5 ATR back before 10:15"),
                     ("rej_dn", "session 1: fell 0.5 ATR then won 0.5 ATR back before 10:15"),
                     ("hif1", "session 1: the high came before the low")):
        M.append(Measure(col, "prob", "share", txt, lambda F, c=col: np.where(s1(F), _a(F, c), np.nan)))
    add("mdown_aup1", "prob", "share", "session 1: fell in the morning, rose in the afternoon",
        lambda F: (_a(F, "mstg1") == 2) & (_a(F, "astg1") == 1), s1)
    add("mup_adown1", "prob", "share", "session 1: rose in the morning, fell in the afternoon",
        lambda F: (_a(F, "mstg1") == 1) & (_a(F, "astg1") == 2), s1)
    for col, txt in (("itu_a1", "+1 ATR"), ("itd_a1", "-1 ATR")):
        M.append(Measure(f"{col}_min", "mean", "minutes", f"trading minutes to the first touch of {txt} (of those touched)",
                         lambda F, c=col: np.where(win(F) & (_a(F, c) >= 0), PP.bar_trading_minutes(np.where(
                             _a(F, c) >= 0, _a(F, c), 0).astype(np.int64)), np.nan)))
    return M


# ======================================================================
# the frames
# ======================================================================
DAILY_COLS = ["sym", "t0", "year", "cal_pos", "state0", "reg0", "liq", "eligible", "complete", "ca", "pk_D", "pk_ENS",
              "phase0", "overext0", "event0", "r5_a", "r5o_p", "mfe_a", "mae_a", "mfe_p", "mae_p", "gap_a", "up_first_a1",
              "rec_d1_endup", "rec_d1_backc0", "rec_d1_toup1", "rec_d2_endup", "rec_p5_endup", "cont_up", "rev_up",
              "cont_dn", "rev_dn", "mfe_s", "mae_s", "best_close_s", "worst_close_s", "n_up", "sign_code", "vol45_12",
              "rv_ratio", "stg1", "stg2", "stg3", "stg4", "stg5", "sq_dsr", "sq_ce", "sq_brc", "sq_ree", "n_locked",
              "st1", "st2", "st3", "st4", "st5", "st_first_change", "rg_class", "rg_first_change", "nifty_r5",
              "mid_r5", "small_r5", "n_present"]
INTRA_COLS = ["sym", "t0", "year", "cal_pos", "state0", "reg0", "liq", "eligible", "complete", "ca", "pk_D", "pk_ENS",
              "iok", "iu1", "iup_first_a1", "irec_d1_backc0", "irec_d1_toup1", "iord_a1_1", "imfe_bar", "imae_bar",
              "m15_a", "m30_a", "m60_a", "r15_a", "r30_a", "r60_a", "drive", "rej_up", "rej_dn", "hif1", "mstg1",
              "astg1", "vwp_a1", "lh_a1", "itu_a1", "itd_a1", "vi44"]


def _thr_cols(D: dict) -> List[str]:
    return [c for c, _, _, _ in PP.threshold_specs(D)] + [c for c, _, _ in PP.order_specs(D)]


def load_frames(cdir: Path, run_dir: Path, D: dict, kind: str, log) -> Tuple[pd.DataFrame, pd.DataFrame, int, str]:
    """Atlas rows (eligible, a known regime, a cell state) and their null rows, with the frozen family of each."""
    cols = (DAILY_COLS + _thr_cols(D)) if kind == "daily" else INTRA_COLS
    R = PB.load_rows(cdir, "rows", cols)
    if len(R) == 0:
        return R, pd.DataFrame(), 0, ""
    R["t0"] = pd.to_datetime(R["t0"]).astype("datetime64[ns]")
    if kind == "intraday":
        for c in ("iok", "iu1"):
            if c not in R.columns:
                R[c] = 0
            R[c] = R[c].fillna(0).astype(np.int8)
    n0 = len(R)
    R = R[(R["eligible"] == 1)].copy()
    si = R["state0"].map(SI_OF)
    R["si"] = si.fillna(-1).astype(np.int8).to_numpy()
    R["ri"] = R["reg0"].astype(np.int8)
    R = R[(R["si"] >= 0) & (R["ri"] >= 0)].reset_index(drop=True)
    log(f"   {kind}: {len(R):,} atlas rows (of {n0:,} built; eligible, a cell state and a known regime)")
    fam_col = "fam" if kind == "daily" else "ifam"
    res = PF.load_result(run_dir, kind)
    kf = int(res.get("k") or 0)
    prefix = str(res.get("prefix") or ("F" if kind == "daily" else "I"))
    fdir = Path(run_dir) / "families" / kind
    if kf and (fdir / "assign.parquet").exists():
        A = pd.read_parquet(fdir / "assign.parquet")
        A["t0"] = pd.to_datetime(A["t0"]).astype("datetime64[ns]")
        R = R.merge(A.rename(columns={"fam": fam_col}), on=["sym", "t0"], how="left")
        R[fam_col] = R[fam_col].fillna(-1).astype(np.int8)
    else:
        R[fam_col] = np.int8(-1)
    sub = "null" if kind == "daily" else "inull"
    ncols = ["sym", "t0"] + [c for c in cols if c not in ("sym", "t0", "year", "cal_pos", "state0", "reg0", "liq",
                                                         "eligible", "complete", "ca", "pk_D", "pk_ENS", "phase0",
                                                         "overext0", "event0", "st1", "st2", "st3", "st4", "st5",
                                                         "st_first_change", "rg_class", "rg_first_change", "nifty_r5",
                                                         "mid_r5", "small_r5", "n_present", "iok", "iu1")]
    ncols += (["iok", "iu1"] if kind == "intraday" else [])
    N = PB.load_rows(cdir, sub, ncols)
    if len(N):
        N["t0"] = pd.to_datetime(N["t0"]).astype("datetime64[ns]")
        keyc = ["sym", "t0", "year", "si", "ri", "state0", "reg0", "liq", "pk_D", "pk_ENS"]
        N = N.merge(R[keyc], on=["sym", "t0"], how="inner")
        N["complete"], N["ca"] = np.int8(1), np.int8(0)
        if kind == "intraday":
            for c in ("iok", "iu1"):
                N[c] = N[c].fillna(0).astype(np.int8) if c in N.columns else np.int8(0)
        if kf and (fdir / "assign_null.parquet").exists():
            AN = pd.read_parquet(fdir / "assign_null.parquet")
            AN["t0"] = pd.to_datetime(AN["t0"]).astype("datetime64[ns]")
            N = N.merge(AN.rename(columns={"fam": fam_col}), on=["sym", "t0"], how="left")
            N[fam_col] = N[fam_col].fillna(-1).astype(np.int8)
        else:
            N[fam_col] = np.int8(-1)
    return R, N, kf, prefix


# ======================================================================
# the engine: per-date sums by group, bootstrap ratios
# ======================================================================
class Engine:
    def __init__(self, t0: np.ndarray, si: np.ndarray, ri: np.ndarray, D: dict, seed_shift: int = 0,
                 dates: Optional[np.ndarray] = None):
        A = D["atlas"]
        self.dates = np.unique(t0) if dates is None else dates
        self.dcode = np.searchsorted(self.dates, t0)
        self.nd = len(self.dates)
        si = np.asarray(si, np.int64)
        ri = np.asarray(ri, np.int64)
        self.codes = [si * NR + ri, NS * NR + si, NS * NR + NS + ri, np.full(len(si), G_ALL)]
        self.block = int(A["boot_block"])
        self.W = PC.block_weights(self.nd, int(A["boot_B"]), self.block, int(A["boot_seed"]) + seed_shift)

    def sums(self, v: np.ndarray, rows: Optional[np.ndarray] = None) -> Tuple[np.ndarray, np.ndarray]:
        v = np.asarray(v, float)
        ok = np.isfinite(v)
        if rows is not None:
            ok &= rows
        S = np.zeros(self.nd * NG)
        Nn = np.zeros(self.nd * NG)
        dc = self.dcode[ok] * NG
        vv = v[ok]
        for c in self.codes:
            idx = dc + c[ok]
            S += np.bincount(idx, weights=vv, minlength=self.nd * NG)
            Nn += np.bincount(idx, minlength=self.nd * NG)
        return S.reshape(self.nd, NG), Nn.reshape(self.nd, NG)

    def stats(self, values: Dict[str, np.ndarray], rows: Optional[np.ndarray] = None, keep: Sequence[str] = ()) -> dict:
        """values: {measure: (n,) array, NaN = not applicable} -> {measure: point, lo, hi, sd, n, nd (each NG),
        boot (B x NG) for the measures in `keep`}."""
        out = {}
        names = list(values)
        for a in range(0, len(names), 24):
            chunk = names[a:a + 24]
            Ss, Ns = [], []
            for m in chunk:
                S, Nn = self.sums(values[m], rows)
                Ss.append(S)
                Ns.append(Nn)
            S = np.concatenate(Ss, axis=1)
            Nn = np.concatenate(Ns, axis=1)
            boot = PC.ratio_boot(S, Nn, self.W)
            lo, hi, sd = PC.interval(boot)
            tot_s, tot_n = S.sum(axis=0), Nn.sum(axis=0)
            with np.errstate(divide="ignore", invalid="ignore"):
                point = np.where(tot_n > 0, tot_s / np.where(tot_n > 0, tot_n, 1), np.nan)
            nd = (Nn > 0).sum(axis=0)
            blk = np.arange(self.nd) // self.block
            nblk = np.array([np.unique(blk[Nn[:, j] > 0]).size for j in range(Nn.shape[1])])
            for t, m in enumerate(chunk):
                sl = slice(t * NG, (t + 1) * NG)
                out[m] = {"point": point[sl], "lo": lo[sl], "hi": hi[sl], "sd": sd[sl], "n": tot_n[sl], "nd": nd[sl],
                          "nblk": nblk[sl]}
                if m in keep:
                    out[m]["boot"] = boot[:, sl].copy()
        return out


# ======================================================================
# tests
# ======================================================================
def test_pairs() -> List[Tuple[int, int, str]]:
    out = []
    for s in range(NS):
        for r in range(NR):
            g = s * NR + r
            out += [(g, G_ALL, "everything"), (g, g_regime(r), "same regime, all states"),
                    (g, g_state(s), "same state, all regimes")]
    out += [(g_state(s), G_ALL, "everything") for s in range(NS)]
    out += [(g_regime(r), G_ALL, "everything") for r in range(NR)]
    return out


def run_tests(st: dict, tested: Sequence[str], support: np.ndarray, period: str, ds: str) -> pd.DataFrame:
    pairs = test_pairs()
    gs = np.array([p[0] for p in pairs])
    bs = np.array([p[1] for p in pairs])
    rows = []
    for m in tested:
        if m not in st or "boot" not in st[m]:
            continue
        b = st[m]["boot"]
        Dd = b[:, gs] - b[:, bs]
        lo, hi, sd = PC.interval(Dd)
        diff = st[m]["point"][gs] - st[m]["point"][bs]
        with np.errstate(divide="ignore", invalid="ignore"):
            z = np.where(sd > 0, diff / sd, np.nan)
        p = PC.p_two_sided(z)
        for t, (g, bb, nm) in enumerate(pairs):
            rows.append({"dataset": ds, "period": period, "group": int(g), "group_text": group_text(int(g)),
                         "kind": group_label(int(g))[0], "measure": m, "baseline": nm, "base_group": int(bb),
                         "value": st[m]["point"][g], "base_value": st[m]["point"][bb], "diff": diff[t], "lo": lo[t],
                         "hi": hi[t], "se": sd[t], "z": z[t], "p": p[t], "supported": bool(support[g])})
    T = pd.DataFrame(rows)
    if len(T):
        T.loc[~T["supported"], "p"] = np.nan
    return T


def support_of(st: dict, base_measure: str, min_dates: int, min_obs: int, min_stretches: int = 0) -> np.ndarray:
    s = st[base_measure]
    return (s["nd"] >= min_dates) & (s["n"] >= min_obs) & (s["nblk"] >= min_stretches)


def minimums(A: dict, ds: str, period: str) -> Tuple[int, int, int]:
    """(dates, observations, separate 10-session stretches): the whole span describes a cell, each period labels it."""
    pre = "" if ds == "daily" else "intraday_"
    if period == "all":
        return int(A[f"{pre}min_dates"]), int(A[f"{pre}min_obs"]), 0
    return int(A[f"{pre}period_min_dates"]), int(A[f"{pre}period_min_obs"]), int(A[f"{pre}period_min_stretches"])


# ======================================================================
# mutual information: does knowing the state (regime) narrow the outcome?
# ======================================================================
def mi_tests(t0: np.ndarray, si: np.ndarray, ri: np.ndarray, y: np.ndarray, ky: int, R: int, shift_min: int,
             seed: int) -> dict:
    ok = (y >= 0)
    t0, si, ri, y = t0[ok], si[ok].astype(np.int64), ri[ok].astype(np.int64), y[ok].astype(np.int64)
    n = len(y)
    if n < 100 or ky < 2:
        return {"n": int(n), "ok": False}
    dates, dcode = np.unique(t0, return_inverse=True)
    cell = si * NR + ri
    obs = {"state": PC.mutual_info(si, y, NS, ky), "regime": PC.mutual_info(ri, y, NR, ky),
           "cell": PC.mutual_info(cell, y, NS * NR, ky)}
    rng = np.random.default_rng(seed)
    grp = np.argsort(dcode, kind="stable")
    reg_d = np.full(len(dates), -1, np.int64)
    reg_d[dcode] = ri
    nulls = {"state": [], "regime": [], "cell": []}
    nd = len(dates)
    for _ in range(R):
        order = np.lexsort((rng.random(n), dcode))
        s_p = np.empty(n, np.int64)
        s_p[grp] = si[order]
        sh = int(rng.integers(shift_min, max(shift_min + 1, nd - shift_min)))
        r_p = np.roll(reg_d, sh)[dcode]
        r_p = np.where(r_p < 0, ri, r_p)
        nulls["state"].append(PC.mutual_info(s_p, y, NS, ky))
        nulls["regime"].append(PC.mutual_info(r_p, y, NR, ky))
        nulls["cell"].append(PC.mutual_info(s_p * NR + r_p, y, NS * NR, ky))
    out = {"n": int(n), "dates": int(nd), "outcomes": int(ky), "ok": True, "permutations": int(R)}
    import math
    for k in obs:
        a = np.array(nulls[k])
        mu, sd = float(a.mean()), float(a.std(ddof=1))
        z = (obs[k] - mu) / sd if sd > 0 else float("nan")
        out[k] = {"mi_bits": obs[k], "null_mean": mu, "null_sd": sd, "null_p95": float(np.percentile(a, 95)),
                  "excess_bits": obs[k] - mu, "z": z,
                  "p_normal": 0.5 * math.erfc(z / math.sqrt(2)) if np.isfinite(z) else float("nan"),
                  "p_perm": float((1 + (a >= obs[k]).sum()) / (R + 1))}
    return out


# ======================================================================
# the stage
# ======================================================================
def run_atlas(cdir: Path, run_dir: Path, D: dict, log) -> dict:
    t_start = time.time()
    adir = Path(run_dir) / "atlas"
    adir.mkdir(parents=True, exist_ok=True)
    done = PC.read_json(adir / "DONE.json")
    if done:
        log(f"[atlas] already done ({adir})")
        return done
    integ = PC.read_json(Path(cdir) / "integrity.json")
    if not integ or integ.get("status") != "passed":
        raise PC.PLStop("the integrity check against the TLX export has not passed for this build - run the build "
                        "with --tlx <TLX export folder> first")
    log(f"[atlas] {ATLAS_VERSION}")
    M = pd.read_parquet(Path(cdir) / "market.parquet")
    cal = PC.to_day(M["date"])
    A = D["atlas"]
    summary = {"version": ATLAS_VERSION, "datasets": {}}
    all_tests = []
    for ds in ("daily", "intraday"):
        sec = adir / ds
        sec.mkdir(exist_ok=True)
        if PC.read_json(sec / "DONE.json"):
            summary["datasets"][ds] = PC.read_json(sec / "DONE.json")
            T = pd.read_parquet(sec / "tests.parquet") if (sec / "tests.parquet").exists() else pd.DataFrame()
            all_tests.append(T)
            log(f"   {ds}: already done")
            continue
        out, T = atlas_dataset(cdir, run_dir, sec, ds, D, cal, log)
        summary["datasets"][ds] = out
        all_tests.append(T)
    # one false-discovery family per period over every test of the run (both datasets, families vs null)
    T = pd.concat([t for t in all_tests if len(t)], ignore_index=True) if any(len(t) for t in all_tests) else pd.DataFrame()
    if len(T):
        q = float(A["fdr_q"])
        T["bh"] = False
        T["q"] = np.nan
        for per in T["period"].unique():
            m = (T["period"] == per).to_numpy()
            rej, qv = PC.bh(T.loc[m, "p"].to_numpy(float), q)
            T.loc[m, "bh"] = rej
            T.loc[m, "q"] = qv
        L = labels(T, adir, D)
        PC.write_table(T, adir / "tests")
        PC.write_table(L, adir / "labels")
        cnt = {}
        for per in ("discovery", "confirmation", "all"):
            m = T["period"] == per
            n_t = int(T.loc[m, "p"].notna().sum())
            n_r = int(T.loc[m, "bh"].sum())
            cnt[per] = {"tests": n_t, "passed_fdr": n_r, "expected_false_among_passed": round(q * n_r, 1)}
        summary["fdr"] = cnt
        summary["labels"] = L["label"].value_counts().to_dict() if len(L) else {}
        log("   false-discovery control (5%): " + "; ".join(f"{k}: {v['passed_fdr']:,} of {v['tests']:,} tests pass, "
                                                         f"about {v['expected_false_among_passed']:g} of those expected false"
                                                         for k, v in cnt.items()))
        log("   labels: " + ", ".join(f"{k} {v:,}" for k, v in summary["labels"].items()))
    summary["seconds"] = round(time.time() - t_start, 1)
    PC.write_json_atomic(summary, adir / "atlas_summary.json")
    PC.write_json_atomic({"status": "done", "seconds": summary["seconds"]}, adir / "DONE.json")
    log(f"[atlas] done in {summary['seconds']:,.0f} s")
    return summary


def labels(T: pd.DataFrame, adir: Path, D: dict) -> pd.DataFrame:
    """One label per (dataset, group, measure, baseline) from the discovery and confirmation tests and the years."""
    A = D["atlas"]
    key = ["dataset", "group", "measure", "baseline"]
    d = T[T["period"] == "discovery"].set_index(key)
    c = T[T["period"] == "confirmation"].set_index(key)
    a = T[T["period"] == "all"].set_index(key)
    idx = d.index.union(c.index)
    L = pd.DataFrame(index=idx)
    for nm, src in (("disc", d), ("conf", c), ("all", a)):
        for col in ("value", "base_value", "diff", "lo", "hi", "p", "q", "bh", "supported"):
            L[f"{col}_{nm}"] = src[col].reindex(idx)
    L = L.reset_index()
    L["group_text"] = [group_text(int(g)) for g in L["group"]]
    Y = []
    for ds in ("daily", "intraday"):
        p = adir / ds / "years_tests.parquet"
        if p.exists():
            Y.append(pd.read_parquet(p))
    flips = pd.DataFrame(columns=key + ["years_supported", "years_flipped"])
    if Y:
        Yt = pd.concat(Y, ignore_index=True)
        Yt = Yt.merge(L[key + ["diff_all"]], on=key, how="left")
        Yt = Yt[Yt["supported"]]
        Yt["flip"] = np.sign(Yt["diff"]) != np.sign(Yt["diff_all"])
        flips = Yt.groupby(key).agg(years_supported=("flip", "size"), years_flipped=("flip", "sum")).reset_index()
    L = L.merge(flips, on=key, how="left")
    L["years_supported"] = L["years_supported"].fillna(0).astype(int)
    L["years_flipped"] = L["years_flipped"].fillna(0).astype(int)
    sup = (L["supported_disc"].astype("boolean").fillna(False) & L["supported_conf"].astype("boolean").fillna(False)).to_numpy(bool)
    bd = L["bh_disc"].astype("boolean").fillna(False).to_numpy(bool)
    bc = L["bh_conf"].astype("boolean").fillna(False).to_numpy(bool)
    excl_c = ((L["lo_conf"] > 0) | (L["hi_conf"] < 0)).to_numpy(bool)
    excl_d = ((L["lo_disc"] > 0) | (L["hi_disc"] < 0)).to_numpy(bool)
    same = (np.sign(L["diff_conf"]) == np.sign(L["diff_disc"])).to_numpy(bool)
    contra = (bd & excl_c & ~same) | (bc & excl_d & ~same)
    verified = bd & excl_c & same
    hypo = (bd | bc) & ~verified & ~contra
    unstable_years = ((L["years_supported"] >= 3) &
                      (L["years_flipped"] > float(A["unstable_share"]) * L["years_supported"])).to_numpy(bool)
    lab = np.where(~sup, "insufficient", np.where(verified, "verified", np.where(hypo, "hypothesis", "inconclusive")))
    lab = np.where(sup & (contra | ((verified | hypo) & unstable_years)), "unstable", lab)
    L["label"] = lab
    return L


def atlas_dataset(cdir: Path, run_dir: Path, sec: Path, ds: str, D: dict, cal: np.ndarray, log) -> Tuple[dict, pd.DataFrame]:
    t0 = time.time()
    A = D["atlas"]
    R, N, kf, prefix = load_frames(cdir, run_dir, D, ds, log)
    out: dict = {"rows": int(len(R)), "null_rows": int(len(N)), "families": kf, "prefix": prefix}
    if len(R) == 0:
        PC.write_json_atomic(out, sec / "DONE.json")
        return out, pd.DataFrame()
    reg = daily_registry(kf, D, prefix) if ds == "daily" else intraday_registry(kf, D, prefix)
    names = [m.name for m in reg]
    fam_names = [m.name for m in reg if m.name.startswith(("fam:", "ifam:"))]
    head = list(A["headline_daily"] if ds == "daily" else A["headline_intraday"])
    tested = fam_names + [h for h in head if h in names]
    base = "r5_a" if ds == "daily" else "m30_a"          # the measure behind the effective sample size
    mind, mino, _ = minimums(A, ds, "all")
    per = PF.periods(cal, D, ds)
    t = PC.to_day(R["t0"])
    vals = {m.name: np.asarray(m.fn(R), dtype=np.float32) for m in reg}      # float32 halves the memory
    # the support measure: a path that exists (daily: complete, no suspect; intraday: all five sessions usable)
    supp_name = "_support"
    vals[supp_name] = np.where(((R["complete"] == 1) & (R["ca"] == 0)).to_numpy() if ds == "daily" else
                               ((R["iok"] == 1) & (R["ca"] == 0)).to_numpy(), 1.0, np.nan)
    tests = []
    stats_rows = []
    keep_all = None
    for pname in ("all", "discovery", "confirmation"):
        lo_, hi_ = per[pname]
        rows = (t >= lo_) & (t <= hi_)
        if rows.sum() == 0:
            continue
        E = Engine(t[rows], R["si"].to_numpy()[rows], R["ri"].to_numpy()[rows], D)
        st = E.stats({k: v[rows] for k, v in vals.items()}, keep=tested + [base])
        sup = support_of(st, supp_name, *minimums(A, ds, pname))
        for m in names + [supp_name]:
            s = st[m]
            for g in range(NG):
                stats_rows.append({"dataset": ds, "period": pname, "group": g, "measure": m, "value": s["point"][g],
                                   "lo": s["lo"][g], "hi": s["hi"][g], "se": s["sd"][g], "n": int(s["n"][g]),
                                   "dates": int(s["nd"][g]), "supported": bool(sup[g])})
        T = run_tests(st, tested, sup, pname, ds)
        tests.append(T)
        if pname == "all":
            keep_all = (E, st, sup, rows)
            # effective sample size: what the group is worth in independent observations (5-day close)
            v = vals[base][rows] if base in vals else None
            if v is not None:
                neff = []
                for g in range(NG):
                    sd_b = st[base]["sd"][g]
                    vv = _group_values(E, v, g)
                    neff.append(float(np.nanvar(vv) / sd_b ** 2) if (np.isfinite(sd_b) and sd_b > 0 and len(vv) > 1) else np.nan)
                out["n_eff_measure"] = base
                PC.write_table(pd.DataFrame({"group": np.arange(NG), "group_text": [group_text(g) for g in range(NG)],
                                             "n_eff": neff}), sec / "n_eff")
        log(f"   {ds}/{pname}: {int(rows.sum()):,} rows, {E.nd:,} dates; {int(sup.sum())} of {NG} groups supported "
            f"({time.time() - t0:,.0f} s)")
    S = pd.DataFrame(stats_rows)
    S["group_text"] = [group_text(int(g)) for g in S["group"]]
    PC.write_table(S, sec / "stats")
    units = pd.DataFrame([{"measure": m.name, "kind": m.kind, "unit": m.unit, "text": m.text} for m in reg])
    PC.write_table(units, sec / "measures")
    # ---------------- support table (counts, stocks) ----------------
    E, st_all, sup_all, rows_all = keep_all
    sym_code = pd.factorize(R["sym"])[0]
    sv = vals[supp_name][rows_all]
    okr = np.isfinite(sv)
    stocks = []
    for g in range(NG):
        m = okr & _in_group(E, g)
        stocks.append(int(np.unique(sym_code[rows_all][m]).size))
    SUP = pd.DataFrame({"group": np.arange(NG), "group_text": [group_text(g) for g in range(NG)],
                        "kind": [group_label(g)[0] for g in range(NG)], "observations": st_all[supp_name]["n"].astype(int),
                        "dates": st_all[supp_name]["nd"].astype(int), "stocks": stocks, "supported_all": sup_all})
    for pname in ("discovery", "confirmation"):
        sp = S[(S["period"] == pname) & (S["measure"] == supp_name)].set_index("group")
        SUP[f"observations_{pname}"] = sp["n"].reindex(SUP["group"]).fillna(0).astype(int).to_numpy()
        SUP[f"dates_{pname}"] = sp["dates"].reindex(SUP["group"]).fillna(0).astype(int).to_numpy()
        SUP[f"supported_{pname}"] = sp["supported"].reindex(SUP["group"]).fillna(False).astype(bool).to_numpy()
    PC.write_table(SUP, sec / "support")
    # ---------------- quantiles (all period): point = sample quantile, interval = inverted bootstrap CDF ----------------
    if ds == "daily":
        qrows = quantile_table(E, vals, rows_all, A, D)
        PC.write_table(pd.DataFrame(qrows), sec / "quantiles")
        if kf:
            PC.write_table(family_quantiles(R, rows_all, kf, A, prefix), sec / "family_quantiles")
    # ---------------- years ----------------
    Y, YT = years_section(R, vals, tested + [supp_name], ds, D, t, per["all"], supp_name)
    PC.write_table(Y, sec / "years")
    PC.write_parquet_atomic(YT, sec / "years_tests.parquet")
    # ---------------- liquidity tiers ----------------
    PC.write_table(tiers_section(R, vals, tested + [supp_name], D, t, per["all"], supp_name, mind, mino), sec / "tiers")
    # ---------------- random walk ----------------
    TN = pd.DataFrame()
    if len(N):
        TN = null_section(R, N, reg, tested, ds, D, per, sec, log, vals)
        tests.append(TN)
    # ---------------- mutual information ----------------
    out["mi"] = mi_section(R, N, kf, ds, D, per, log)
    PC.write_json_atomic(out["mi"], sec / "mutual_information.json")
    # ---------------- overlap check (daily) ----------------
    if ds == "daily":
        out["overlap_check"] = overlap_check(R, vals, [h for h in head if h in names], D, per["all"], t, mind, mino)
        PC.write_json_atomic(out["overlap_check"], sec / "overlap_check.json")
        log(f"   overlap check (every 5th T0 per stock): the main estimate sits inside the non-overlapping sample's "
            f"interval for {out['overlap_check']['share_inside']:.1%} of {out['overlap_check']['pairs']} supported "
            f"group x measure pairs (declared minimum {out['overlap_check']['required']:.0%}) -> "
            f"{'PASS' if out['overlap_check']['pass'] else 'FAIL'}")
        transitions_section(R, N, D, sec, per["all"], t)
    # ---------------- picks against the universe ----------------
    picks_section(R, vals, reg, tested, ds, D, per["all"], t, sec)
    TT = pd.concat([x for x in tests if len(x)], ignore_index=True) if tests else pd.DataFrame()
    PC.write_parquet_atomic(TT, sec / "tests.parquet")
    out["seconds"] = round(time.time() - t0, 1)
    PC.write_json_atomic(out, sec / "DONE.json")
    return out, TT


def _in_group(E: Engine, g: int) -> np.ndarray:
    if g < NS * NR:
        return E.codes[0] == g
    if g < NS * NR + NS:
        return E.codes[1] == g
    if g < G_ALL:
        return E.codes[2] == g
    return np.ones(len(E.codes[0]), bool)


def _group_values(E: Engine, v: np.ndarray, g: int) -> np.ndarray:
    x = v[_in_group(E, g)]
    return x[np.isfinite(x)]


def quantile_table(E: Engine, vals: dict, rows: np.ndarray, A: dict, D: dict) -> List[dict]:
    qs = [float(x) for x in A["quantiles"]]
    g0, g1, gs = (float(x) for x in A["cdf_grid"])
    grid = np.round(np.arange(g0, g1 + gs / 2, gs), 10)
    out = []
    for m in A.get("quantile_measures_daily", ["r5_a", "mfe_a", "mae_a"]):
        if m not in vals:
            continue
        v = vals[m][rows]
        num = np.zeros((E.nd, NG, len(grid)))
        Ss, Nn = E.sums(v)
        ok = np.isfinite(v)
        for k, gv in enumerate(grid):
            ind = np.where(ok, (v <= gv).astype(float), np.nan)
            s, _ = E.sums(ind)
            num[:, :, k] = s
        bnum = (E.W @ num.reshape(E.nd, NG * len(grid))).reshape(-1, NG, len(grid))
        bden = E.W @ Nn
        with np.errstate(divide="ignore", invalid="ignore"):
            cdf = bnum / bden[:, :, None]
        bq = PC.quantiles_from_cdf(grid, cdf, qs)                      # B x NG x nq
        lo = PC.nanpct(bq, 2.5, axis=0)
        hi = PC.nanpct(bq, 97.5, axis=0)
        for g in range(NG):
            x = _group_values(E, v, g)
            pts = np.quantile(x, qs) if len(x) else np.full(len(qs), np.nan)
            for j, q in enumerate(qs):
                out.append({"measure": m, "group": g, "group_text": group_text(g), "q": q, "value": float(pts[j]),
                            "lo": float(lo[g, j]), "hi": float(hi[g, j]), "n": int(len(x)),
                            "interval_note": f"grid {gs:g} ATR from {g0:g} to {g1:g}; values beyond the grid sit at its ends"})
    return out


def family_quantiles(R: pd.DataFrame, rows: np.ndarray, kf: int, A: dict, prefix: str = "F") -> pd.DataFrame:
    """Inside each family (all period, every cell): 5-day close, MFE, MAE quantiles - point estimates only."""
    qs = [float(x) for x in A["quantiles"]]
    F = R[rows & (R["fam"].to_numpy() >= 0) & (R["complete"] == 1).to_numpy() & (R["ca"] == 0).to_numpy()]
    out = []
    for gk in ("cell", "all"):
        if gk == "cell":
            keys = F["si"].astype(int) * NR + F["ri"].astype(int)
        else:
            keys = pd.Series(np.full(len(F), G_ALL), index=F.index)
        for (g, f), sub in F.groupby([keys, F["fam"]]):
            for m in ("r5_a", "mfe_a", "mae_a"):
                x = sub[m].to_numpy(float)
                x = x[np.isfinite(x)]
                if len(x) < 20:
                    continue
                qv = np.quantile(x, qs)
                rec = {"group": int(g), "group_text": group_text(int(g)), "family": f"{prefix}{int(f) + 1:02d}", "measure": m,
                       "n": int(len(x)), "mean": float(x.mean())}
                rec.update({f"q{int(round(q * 100)):02d}": float(v) for q, v in zip(qs, qv)})
                out.append(rec)
    return pd.DataFrame(out)


def years_section(R, vals, measures, ds, D, t, span, supp_name) -> Tuple[pd.DataFrame, pd.DataFrame]:
    A = D["atlas"]
    yr = R["year"].to_numpy()
    rows_out, tests_out = [], []
    for y in sorted(np.unique(yr)):
        m = (yr == y) & (t >= span[0]) & (t <= span[1])
        if m.sum() == 0:
            continue
        E = Engine(t[m], R["si"].to_numpy()[m], R["ri"].to_numpy()[m], D)
        st = E.stats({k: vals[k][m] for k in measures}, keep=measures)
        sup = support_of(st, supp_name, int(A["year_min_dates"]), int(A["year_min_obs"]))
        for k in measures:
            s = st[k]
            for g in range(NG):
                rows_out.append({"dataset": ds, "year": int(y), "group": g, "group_text": group_text(g), "measure": k,
                                 "value": s["point"][g], "lo": s["lo"][g], "hi": s["hi"][g], "n": int(s["n"][g]),
                                 "dates": int(s["nd"][g]), "supported": bool(sup[g])})
        T = run_tests(st, [k for k in measures if k != supp_name], sup, str(y), ds)
        if len(T):
            tests_out.append(T[["dataset", "group", "measure", "baseline", "diff", "supported"]].assign(year=int(y)))
    Y = pd.DataFrame(rows_out)
    YT = pd.concat(tests_out, ignore_index=True) if tests_out else pd.DataFrame(
        columns=["dataset", "group", "measure", "baseline", "diff", "supported", "year"])
    return Y, YT


def tiers_section(R, vals, measures, D, t, span, supp_name, mind, mino) -> pd.DataFrame:
    A = D["atlas"]
    m0 = (t >= span[0]) & (t <= span[1])
    nt = int(D["universe"]["liquidity_tiers"])
    liq = R["liq"].to_numpy(float)
    tier = np.full(len(R), -1)
    df = pd.DataFrame({"t": t, "liq": liq})
    rk = df.groupby("t")["liq"].rank(ascending=False, pct=True, method="first").to_numpy()
    ok = np.isfinite(liq) & np.isfinite(rk)
    tier[ok] = np.minimum((rk[ok] * nt - 1e-12).astype(int), nt - 1) + 1     # 1 = most liquid third
    rows_out = []
    for k in range(1, nt + 1):
        m = m0 & (tier == k)
        if m.sum() == 0:
            continue
        E = Engine(t[m], R["si"].to_numpy()[m], R["ri"].to_numpy()[m], D)
        st = E.stats({x: vals[x][m] for x in measures})
        sup = support_of(st, supp_name, mind, mino)
        for x in measures:
            s = st[x]
            for g in range(NG):
                rows_out.append({"tier": k, "group": g, "group_text": group_text(g), "measure": x, "value": s["point"][g],
                                 "lo": s["lo"][g], "hi": s["hi"][g], "n": int(s["n"][g]), "dates": int(s["nd"][g]),
                                 "supported": bool(sup[g])})
    return pd.DataFrame(rows_out)


def null_section(R, N, reg, tested, ds, D, per, sec, log, vals=None) -> pd.DataFrame:
    """Real paths against their random-walk versions (the same stock-days, each session replaced by a random other
    session of the same stock). Paired by date: the same resampled dates for both."""
    A = D["atlas"]
    names = [m.name for m in reg]
    vr = vals if vals is not None else {m.name: np.asarray(m.fn(R), dtype=np.float32) for m in reg}
    vn = {m.name: np.asarray(m.fn(N), dtype=np.float32) for m in reg}
    tR, tN = PC.to_day(R["t0"]), PC.to_day(N["t0"])
    rows, tests = [], []
    for pname in ("all", "discovery", "confirmation"):
        lo_, hi_ = per[pname]
        mr = (tR >= lo_) & (tR <= hi_)
        mn = (tN >= lo_) & (tN <= hi_)
        if mr.sum() == 0 or mn.sum() == 0:
            continue
        dates = np.unique(np.concatenate([tR[mr], tN[mn]]))
        ER = Engine(tR[mr], R["si"].to_numpy()[mr], R["ri"].to_numpy()[mr], D, dates=dates)
        EN = Engine(tN[mn], N["si"].to_numpy()[mn], N["ri"].to_numpy()[mn], D, dates=dates)
        keep = [n for n in names if n in vn and np.isfinite(vn[n]).any()]
        sr = ER.stats({k: vr[k][mr] for k in keep}, keep=keep)
        sn = EN.stats({k: vn[k][mn] for k in keep}, keep=keep)
        for k in keep:
            dboot = sr[k]["boot"] - sn[k]["boot"]
            lo, hi, sd = PC.interval(dboot)
            diff = sr[k]["point"] - sn[k]["point"]
            with np.errstate(divide="ignore", invalid="ignore"):
                z = np.where(sd > 0, diff / sd, np.nan)
            p = PC.p_two_sided(z)
            for g in range(NG):
                rows.append({"dataset": ds, "period": pname, "group": g, "group_text": group_text(g), "measure": k,
                             "real": sr[k]["point"][g], "null": sn[k]["point"][g], "diff": diff[g], "lo": lo[g],
                             "hi": hi[g], "p": p[g], "n_real": int(sr[k]["n"][g]), "n_null": int(sn[k]["n"][g])})
                if g == G_ALL and k in tested:
                    tests.append({"dataset": ds, "period": pname, "group": g, "group_text": group_text(g),
                                  "kind": "vs random walk", "measure": k, "baseline": "random walk", "base_group": g,
                                  "value": sr[k]["point"][g], "base_value": sn[k]["point"][g], "diff": diff[g],
                                  "lo": lo[g], "hi": hi[g], "se": sd[g], "z": z[g], "p": p[g],
                                  "supported": bool(sr[k]["n"][g] > 0)})
    PC.write_table(pd.DataFrame(rows), sec / "vs_random_walk")
    log(f"   {ds}: real paths against their random-walk versions written ({len(rows):,} rows)")
    return pd.DataFrame(tests)


def mi_section(R, N, kf, ds, D, per, log) -> dict:
    A = D["atlas"]
    fam_col = "fam" if ds == "daily" else "ifam"
    out = {"outcome": None}
    t = PC.to_day(R["t0"])
    if kf:
        y = R[fam_col].to_numpy(np.int64)
        ky = kf
        out["outcome"] = f"the {kf} frozen {ds} families"
        yN = N[fam_col].to_numpy(np.int64) if len(N) else None
    else:
        col = "r5_a" if ds == "daily" else "vi44"
        x = R[col].to_numpy(float) if col in R.columns else np.full(len(R), np.nan)
        dm = (t >= per["discovery"][0]) & (t <= per["discovery"][1]) & np.isfinite(x)
        if dm.sum() < 100:
            return {"ok": False, "reason": "too few rows"}
        cuts = np.quantile(x[dm], [0.2, 0.4, 0.6, 0.8])
        y = np.where(np.isfinite(x), np.digitize(x, cuts), -1)
        ky = 5
        out["outcome"] = f"5-day close quintile ({col}, discovery cut points {np.round(cuts, 3).tolist()}): no stable families"
        yN = None
        if len(N) and col in N.columns:
            xn = N[col].to_numpy(float)
            yN = np.where(np.isfinite(xn), np.digitize(xn, cuts), -1)
    valid = ((R["complete"] == 1) & (R["ca"] == 0)).to_numpy() if ds == "daily" else ((R["iok"] == 1) & (R["ca"] == 0)).to_numpy()
    y = np.where(valid, y, -1)
    Rn = int(A["mi_permutations"])
    for pname in ("all", "discovery", "confirmation"):
        m = (t >= per[pname][0]) & (t <= per[pname][1])
        out[pname] = mi_tests(t[m], R["si"].to_numpy()[m], R["ri"].to_numpy()[m], y[m], ky, Rn,
                              int(A["mi_shift_min"]), int(A["boot_seed"]))
    if yN is not None and len(N):
        tN = PC.to_day(N["t0"])
        m = (tN >= per["all"][0]) & (tN <= per["all"][1])
        out["random_walk_all"] = mi_tests(tN[m], N["si"].to_numpy()[m], N["ri"].to_numpy()[m], yN[m], ky, Rn,
                                          int(A["mi_shift_min"]), int(A["boot_seed"]))
    for pname in ("all", "discovery", "confirmation"):
        r = out.get(pname, {})
        if r.get("ok"):
            log(f"   {ds}/{pname} mutual information with {out['outcome'].split(':')[0]}: state {r['state']['mi_bits']:.5f} bits "
                f"(shuffled within dates {r['state']['null_mean']:.5f}, z {r['state']['z']:.1f}); regime "
                f"{r['regime']['mi_bits']:.5f} (shifted {r['regime']['null_mean']:.5f}, z {r['regime']['z']:.1f})")
    return out


def overlap_check(R, vals, head, D, span, t, mind, mino) -> dict:
    """Keep every 5th T0 of each stock (no two kept windows overlap) and check that the main estimate sits inside the
    non-overlapping sample's own 95% interval."""
    A = D["atlas"]
    step = int(A["nonoverlap_step"])
    m0 = (t >= span[0]) & (t <= span[1])
    order = np.lexsort((t, R["sym"].to_numpy()))
    pos = np.empty(len(R), np.int64)
    k = pd.Series(R["sym"].to_numpy()[order]).groupby(R["sym"].to_numpy()[order]).cumcount().to_numpy()
    pos[order] = k
    sub = m0 & (pos % step == 0)
    E1 = Engine(t[m0], R["si"].to_numpy()[m0], R["ri"].to_numpy()[m0], D)
    E2 = Engine(t[sub], R["si"].to_numpy()[sub], R["ri"].to_numpy()[sub], D)
    vv = {h: vals[h] for h in head}
    vv["_support"] = vals.get("_support", np.where(np.isfinite(vals[head[0]]), 1.0, np.nan))
    s1 = E1.stats({h: v[m0] for h, v in vv.items()})
    s2 = E2.stats({h: v[sub] for h, v in vv.items()})
    sup2 = support_of(s2, "_support", mind, mino)
    inside, pairs, rows = 0, 0, []
    for h in head:
        for g in range(NG):
            if not sup2[g]:
                continue
            a, lo, hi = s1[h]["point"][g], s2[h]["lo"][g], s2[h]["hi"][g]
            if not (np.isfinite(a) and np.isfinite(lo) and np.isfinite(hi)):
                continue
            pairs += 1
            ins = bool(lo <= a <= hi)
            inside += ins
            w1 = s1[h]["hi"][g] - s1[h]["lo"][g]
            rows.append({"measure": h, "group": g, "main": a, "sub_lo": lo, "sub_hi": hi, "inside": ins,
                         "width_ratio": float((hi - lo) / w1) if w1 > 0 else np.nan})
    share = inside / pairs if pairs else float("nan")
    wr = float(np.median([r["width_ratio"] for r in rows if np.isfinite(r["width_ratio"])])) if rows else float("nan")
    return {"rows_main": int(m0.sum()), "rows_subsample": int(sub.sum()), "pairs": pairs, "inside": inside,
            "share_inside": share, "required": float(A["nonoverlap_min_share"]),
            "pass": bool(pairs > 0 and share >= float(A["nonoverlap_min_share"])),
            "median_interval_width_ratio": float(wr),
            "note": "about sqrt(5) = 2.24 if overlapping windows were independent; less means the main intervals already "
                    "carry the overlap"}


def transitions_section(R, N, D, sec, span, t):
    """Where each T0 state is by the session-5 close (per regime and overall), when it first changed, the commonest
    state sequences, and the named stage sequences against the random walk (in vs_random_walk)."""
    m = (t >= span[0]) & (t <= span[1]) & (R["complete"] == 1).to_numpy() & (R["ca"] == 0).to_numpy()
    F = R[m]
    st5 = F["st5"].to_numpy()
    rows = []
    for ri in list(range(NR)) + [-1]:
        sub = F if ri < 0 else F[F["ri"] == ri]
        tab = pd.crosstab(sub["state0"].map(PC.STATE_FROM_CODE), sub["st5"].map(lambda x: PC.STATE_FROM_CODE.get(int(x), "missing")))
        for s0 in tab.index:
            tot = tab.loc[s0].sum()
            for s5 in tab.columns:
                rows.append({"regime": "all" if ri < 0 else PC.REGIMES[ri], "state_t0": s0, "state_s5": s5,
                             "n": int(tab.loc[s0, s5]), "share": float(tab.loc[s0, s5] / tot) if tot else np.nan})
    PC.write_table(pd.DataFrame(rows), sec / "transitions_state")
    fc = F.groupby(F["state0"].map(PC.STATE_FROM_CODE))["st_first_change"].value_counts(normalize=True).rename("share").reset_index()
    PC.write_table(fc, sec / "transitions_first_change")
    seqs = []
    S = F[["state0", "st1", "st2", "st3", "st4", "st5"]].to_numpy()
    lab = []
    for r in S:
        out = [PC.STATE_FROM_CODE.get(int(r[0]), "?")]
        for x in r[1:]:
            nm = PC.STATE_FROM_CODE.get(int(x), "missing")
            if nm != out[-1]:
                out.append(nm)
        lab.append(" > ".join(out))
    vc = pd.Series(lab).groupby(F["state0"].map(PC.STATE_FROM_CODE).to_numpy()).value_counts()
    for (s0, sq), n in vc.items():
        seqs.append({"state_t0": s0, "sequence": sq, "n": int(n)})
    Q = pd.DataFrame(seqs)
    if len(Q):
        Q["share"] = Q["n"] / Q.groupby("state_t0")["n"].transform("sum")
        Q = Q.sort_values(["state_t0", "n"], ascending=[True, False]).groupby("state_t0").head(12)
    PC.write_table(Q, sec / "transitions_sequences")
    # regime held / improved / worsened: path measures by T0 regime and the change class
    G = F[F["rg_class"] >= 0]
    agg = G.groupby([G["ri"].map(lambda x: PC.REGIMES[int(x)]), G["rg_class"].map({0: "held", 1: "improved", 2: "worsened"})]).agg(
        n=("r5_a", "size"), r5_a=("r5_a", "mean"), r5_pos=("r5_a", lambda x: float((x > 0).mean())),
        mfe_a=("mfe_a", "mean"), mae_a=("mae_a", "mean")).reset_index()
    agg.columns = ["regime_t0", "regime_change", "n", "r5_a", "r5_pos", "mfe_a", "mae_a"]
    PC.write_table(agg, sec / "transitions_regime")


def picks_section(R, vals, reg, tested, ds, D, span, t, sec):
    """D's and ENS's picks against the universe: their own odds, and against the stocks not picked on the same date
    in the same cell (descriptive)."""
    m0 = (t >= span[0]) & (t <= span[1])
    cell = (R["si"].to_numpy().astype(np.int64) * NR + R["ri"].to_numpy().astype(np.int64))
    dates = np.unique(t[m0])
    dcode = np.searchsorted(dates, t)
    W = PC.block_weights(len(dates), int(D["atlas"]["boot_B"]), int(D["atlas"]["boot_block"]), int(D["atlas"]["boot_seed"]))
    groups = {"D top 3": ("pk_D", 3), "ENS top 3": ("pk_ENS", 3), "D top 10": ("pk_D", 10), "ENS top 10": ("pk_ENS", 10)}
    rows = []
    for gname, (col, kmax) in groups.items():
        pk = R[col].to_numpy()
        isp = m0 & (pk >= 1) & (pk <= kmax)
        if isp.sum() == 0:
            continue
        nonp = m0 & ~((pk >= 1) & (pk <= kmax))
        for mname in tested:
            v = vals[mname]
            ok_n = nonp & np.isfinite(v)
            key = dcode * (NS * NR) + cell
            sn = np.bincount(key[ok_n], weights=v[ok_n], minlength=len(dates) * NS * NR)
            nn = np.bincount(key[ok_n], minlength=len(dates) * NS * NR)
            with np.errstate(divide="ignore", invalid="ignore"):
                base = np.where(nn > 0, sn / np.where(nn > 0, nn, 1), np.nan)
            ok_p = isp & np.isfinite(v)
            dv = v[ok_p] - base[key[ok_p]]
            okd = np.isfinite(dv)
            dc = dcode[ok_p][okd]
            S1 = np.bincount(dc, weights=dv[okd], minlength=len(dates))
            N1 = np.bincount(dc, minlength=len(dates)).astype(float)
            S0 = np.bincount(dcode[ok_p], weights=v[ok_p], minlength=len(dates))
            N0 = np.bincount(dcode[ok_p], minlength=len(dates)).astype(float)
            b = PC.ratio_boot(np.column_stack([S0, S1]), np.column_stack([N0, N1]), W)
            lo, hi, _ = PC.interval(b)
            with np.errstate(divide="ignore", invalid="ignore"):
                rows.append({"dataset": ds, "picks": gname, "measure": mname, "n_picks": int(N0.sum()),
                             "value": float(S0.sum() / N0.sum()) if N0.sum() else np.nan, "lo": lo[0], "hi": hi[0],
                             "vs_same_day_same_cell": float(S1.sum() / N1.sum()) if N1.sum() else np.nan,
                             "vs_lo": lo[1], "vs_hi": hi[1], "n_matched": int(N1.sum())})
    PC.write_table(pd.DataFrame(rows), sec / "picks")
