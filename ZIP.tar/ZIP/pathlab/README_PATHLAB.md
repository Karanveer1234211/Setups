# pathlab v1.0 (coverage release, 25 Oct 2026)

Phase 1 of the BigMove behavioural path research: the Behavioural Path Atlas. Protocol (revised 25 Oct with nine
changes): https://claude.ai/artifact/9a5iVGtt17kYLjshR8mHXG

**This release runs two commands only: `audit` and `coverage`.** Neither reads any outcome. The rest of the pipeline
(build, families, atlas, report) is refused until you freeze the revised protocol; it ships with the revised code.

## Install

1. Copy the whole `pathlab` folder to `C:\Users\karanvsi\PyCharmMiscProject\pathlab\` (beside `tradelab`).
2. Nothing else changes: tradelab v1.3.1 stays as it is in `C:\Users\karanvsi\PyCharmMiscProject\tradelab\`.
3. Libraries: numpy, pandas, pyarrow and scipy (scipy comes with scikit-learn, already installed).

## Commands (cmd)

```
call C:\Users\karanvsi\PyCharmMiscProject\pathlab\env_pathlab.bat
python tests\test_pathlab.py quick
python pathlab.py audit --root %CACHE_DAILY_ROOT%
python pathlab.py coverage --root %CACHE_DAILY_ROOT%
```

- The quick tests take about 2 minutes and must end with `ALL 7 TESTS PASSED`.
- `audit` prints what exists and what is missing (its report: `C:\QuantData\pathlab\runs\PL_...\audit\audit.md`).
- `coverage` takes about 5-10 minutes (an estimate). It writes `C:\QuantData\pathlab\coverage\COV_YYYYMMDD_NNN\`.

## What to send back

Zip the coverage folder without the parquet copies and attach it:

```
cd /d C:\QuantData\pathlab\coverage
tar -a -c -f COV.zip --exclude=*.parquet COV_YYYYMMDD_NNN
```

(replace `COV_YYYYMMDD_NNN` with the folder name the command printed). Also paste the last 20 lines the audit printed.

## ETFs (optional, better)

Without NSE's ETF list, ETFs are found by name (symbols ending in BEES, ETF or IETF). That misses ETFs with other
names (GOLD1, BANKNIFTY1, and DSP's ETFs, renamed ...ETF -> ...ADD in Feb 2024, such as SILVERADD); the coverage report
says so and lists every name it flagged (`etf_list.csv`). Two ways to make it complete:

- open https://nsearchives.nseindia.com/content/equities/eq_etfseclist.csv in your browser and save it as
  `C:\QuantData\pathlab\ref\eq_etfseclist.csv` (it needs a `Symbol` column). pathlab joins it with the name rule,
  because NSE's list holds today's names only and the cache can hold an ETF under an older name;
- write `C:\QuantData\pathlab\ref\etf_corrections.csv` with two columns `symbol,is_etf` (1 = ETF, 0 = not), one line
  per correction. Corrections apply last.

Then run `coverage` again. A file pathlab cannot read stops the run with the reason (it is never skipped silently):
fix the file, or delete it to fall back to the name rule.

## What pathlab never does

It reads the cache, the panel, pick_meta's run, the 3-minute bars and tradelab's code READ ONLY. It writes only under
`PATHLAB_OUT` (`C:\QuantData\pathlab`) and refuses an output folder inside the cache, bigmove_deploy, tradelab or
tradelab's outputs. It never changes `CACHE_HISTORY_ANCHOR`, never uses a default cache path (`--root` is required),
and never touches production's `research_ledger.jsonl` (its own ledger is `C:\QuantData\pathlab\pathlab_ledger.jsonl`).
