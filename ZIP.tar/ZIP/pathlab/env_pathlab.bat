@echo off
rem env_pathlab.bat - pathlab v1.0: start a pathlab session in cmd.
rem   call C:\Users\karanvsi\PyCharmMiscProject\pathlab\env_pathlab.bat
rem Reads production (the cache, pick_meta's run, the panel, the 3-minute bars, stage E and intraday_cache code)
rem and tradelab READ ONLY. Writes only under PATHLAB_OUT. Edit the five paths below if your folders differ.
set "BIGMOVE_DIR=C:\Users\karanvsi\PyCharmMiscProject\bigmove_deploy"
set "TRADELAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\tradelab"
set "PATHLAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\pathlab"
set "TRADELAB_OUT=C:\QuantData\tradelab"
set "PATHLAB_OUT=C:\QuantData\pathlab"
if not exist "%BIGMOVE_DIR%\env_daily.bat" goto :no_env
if not exist "%TRADELAB_DIR%\tl_common.py" goto :no_tradelab
if not exist "%PATHLAB_DIR%\pathlab.py" goto :no_pathlab
call "%BIGMOVE_DIR%\env_daily.bat"
if "%CACHE_DAILY_ROOT%"=="" goto :no_root
set "PYTHONPATH=%PATHLAB_DIR%;%TRADELAB_DIR%;%BIGMOVE_DIR%\open_close;%BIGMOVE_DIR%"
if not exist "%PATHLAB_OUT%" mkdir "%PATHLAB_OUT%"
cd /d "%PATHLAB_DIR%"
echo pathlab ready: CACHE_DAILY_ROOT=%CACHE_DAILY_ROOT%   PATHLAB_OUT=%PATHLAB_OUT%
goto :eof
:no_env
echo ERROR: %BIGMOVE_DIR%\env_daily.bat not found - edit BIGMOVE_DIR at the top of env_pathlab.bat
exit /b 1
:no_tradelab
echo ERROR: tradelab not found at %TRADELAB_DIR% - edit TRADELAB_DIR at the top of env_pathlab.bat
exit /b 1
:no_pathlab
echo ERROR: pathlab.py not found in %PATHLAB_DIR% - edit PATHLAB_DIR at the top of env_pathlab.bat
exit /b 1
:no_root
echo ERROR: env_daily.bat ran but CACHE_DAILY_ROOT is empty
exit /b 1
