"""
pl_paths.py - pathlab v1.0: the five-day path measures (pure functions on arrays, no I/O).

Units. ATR units = price distance from the T0 close C0 divided by ATR(T0) in rupees (tl_state's Wilder ATR 14);
percent = price / C0 - 1. One ATR is an ordinary day's range for that stock at T0.

The same functions measure the real paths and the random-walk ("null") paths, so nothing about a measure can
differ between the two. A session's prices enter through an affine map  price -> a + g * price  (real paths:
a = 0, g = 1; null paths: the donor session's prices mapped so that its previous close lands on the null path's
previous close and its moves are rescaled by ATR%(T0) / ATR%(donor's previous session)).
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

NB = 125                      # 3-minute bars a session (09:15 + 3k, k = 0..124)
NS = 5                        # sessions in the window
STAGE_UP, STAGE_DOWN, STAGE_QUIET, STAGE_CHURN, STAGE_FLAT = 1, 2, 3, 4, 5


# ----------------------------------------------------------------------
# names
# ----------------------------------------------------------------------
def tag_atr(x: float) -> str:
    return "a" + ("05" if abs(x - 0.5) < 1e-9 else f"{x:g}".replace(".", ""))


def tag_pct(x: float) -> str:
    return "p" + f"{round(x * 100, 6):g}".replace(".", "")


def threshold_specs(D: dict) -> List[Tuple[str, str, float, bool]]:
    """(column, side, value, is_atr): tu_a1 = first session whose high reached C0 + 1 ATR, td_p5 = first session whose
    low reached C0 x (1 - 5%) ..."""
    out = []
    for x in D["thresholds_atr"]:
        out.append((f"tu_{tag_atr(x)}", "up", float(x), True))
        out.append((f"td_{tag_atr(x)}", "dn", float(x), True))
    for x in D["thresholds_pct_up"]:
        out.append((f"tu_{tag_pct(x)}", "up", float(x), False))
    for x in D["thresholds_pct_down"]:
        out.append((f"td_{tag_pct(x)}", "dn", float(x), False))
    return out


def order_specs(D: dict) -> List[Tuple[str, str, str]]:
    """(column, up threshold column, down threshold column)."""
    out = []
    for u, d in D["order_pairs_atr"]:
        out.append((f"ord_{tag_atr(u)}_{tag_atr(d)[1:]}", f"tu_{tag_atr(u)}", f"td_{tag_atr(d)}"))
    for u, d in D["order_pairs_pct"]:
        out.append((f"ord_{tag_pct(u)}_{tag_pct(d)[1:]}", f"tu_{tag_pct(u)}", f"td_{tag_pct(d)}"))
    return out


def level_of(C0: np.ndarray, A0: np.ndarray, side: str, x: float, is_atr: bool) -> np.ndarray:
    if is_atr:
        return C0 + x * A0 if side == "up" else C0 - x * A0
    return C0 * (1 + x) if side == "up" else C0 * (1 - x)


def daily_vector_names() -> List[str]:
    return [f"vd{k:02d}" for k in range(16)]


def intraday_vector_names() -> List[str]:
    return [f"vi{k:02d}" for k in range(45)]


# ----------------------------------------------------------------------
# stages
# ----------------------------------------------------------------------
def stage_code(move: np.ndarray, rng: np.ndarray, S: dict, factor: float = 1.0) -> np.ndarray:
    """Up / Down by the close-to-close move, else Quiet / Churn / Flat by the range (all in ATR units)."""
    move = np.asarray(move, float)
    rng = np.asarray(rng, float)
    out = np.full(move.shape, STAGE_FLAT, dtype=np.int8)
    with np.errstate(invalid="ignore"):
        up = move >= S["up"] * factor
        dn = move <= S["down"] * factor
        quiet = ~up & ~dn & (rng < S["quiet_range"] * factor)
        churn = ~up & ~dn & (rng >= S["churn_range"] * factor)
    out[quiet] = STAGE_QUIET
    out[churn] = STAGE_CHURN
    out[up] = STAGE_UP
    out[dn] = STAGE_DOWN
    out[~(np.isfinite(move) & np.isfinite(rng))] = 0
    return out


def sequences(stg: np.ndarray, rng: np.ndarray, S: dict) -> Dict[str, np.ndarray]:
    """First start session (1..3) of each named 3-session sequence, 0 = none. stg, rng: (n, 5)."""
    n = stg.shape[0]
    qf = (stg == STAGE_QUIET) | (stg == STAGE_FLAT)
    out = {k: np.zeros(n, np.int8) for k in ("sq_dsr", "sq_ce", "sq_brc", "sq_ree")}
    for s in range(3):
        a, b, c = stg[:, s], stg[:, s + 1], stg[:, s + 2]
        with np.errstate(invalid="ignore"):
            hits = {"sq_dsr": (a == STAGE_DOWN) & qf[:, s + 1] & (c == STAGE_UP),
                    "sq_ce": (a == STAGE_QUIET) & (b == STAGE_QUIET) & ((c == STAGE_UP) | (c == STAGE_DOWN)) &
                             (rng[:, s + 2] >= S["churn_range"]),
                    "sq_brc": (a == STAGE_UP) & (b == STAGE_DOWN) & (c == STAGE_UP),
                    "sq_ree": (a == STAGE_UP) & qf[:, s + 1] & (c == STAGE_DOWN)}
        for k, h in hits.items():
            sel = h & (out[k] == 0)
            out[k][sel] = s + 1
    return out


# ----------------------------------------------------------------------
# first touches and their order
# ----------------------------------------------------------------------
def first_true(hit: np.ndarray) -> np.ndarray:
    """Index of the first True along axis 1, -1 when none."""
    anyh = hit.any(axis=1)
    return np.where(anyh, hit.argmax(axis=1), -1)


def order_code(iu: np.ndarray, idn: np.ndarray, open_at: np.ndarray, up_lvl: np.ndarray, dn_lvl: np.ndarray) -> np.ndarray:
    """1 = the up level came first, 2 = the down level first, 3 = both first reached in the same unit (session or bar)
    and its open settles nothing (a tie, never guessed), 0 = neither. iu / idn = first index (-1 none); open_at =
    the open of the unit where both were first reached (NaN otherwise)."""
    code = np.zeros(len(iu), np.int8)
    u, d = iu >= 0, idn >= 0
    code[u & (~d | (iu < idn))] = 1
    code[d & (~u | (idn < iu))] = 2
    same = u & d & (iu == idn)
    with np.errstate(invalid="ignore"):
        code[same & (open_at >= up_lvl)] = 1
        code[same & (open_at <= dn_lvl)] = 2
    code[same & ~(open_at >= up_lvl) & ~(open_at <= dn_lvl)] = 3
    return code


# ----------------------------------------------------------------------
# daily measures (complete windows only; the caller leaves the rest blank)
# ----------------------------------------------------------------------
def daily_measures(C0, A0, O, H, L, C, D: dict, V=None, v50=None, rv20=None) -> Dict[str, np.ndarray]:
    """C0, A0 (ATR in rupees): (n,); O, H, L, C (and V): (n, 5) with every value present. Returns {column: (n,)}."""
    C0 = np.asarray(C0, float)
    A0 = np.asarray(A0, float)
    O, H, L, C = (np.asarray(x, float) for x in (O, H, L, C))
    n = len(C0)
    out: Dict[str, np.ndarray] = {}
    rows = np.arange(n)
    with np.errstate(divide="ignore", invalid="ignore"):
        # the 16-number daily path: O1, then H, L, C of sessions 1-5, from C0 in ATR units
        out["vd00"] = (O[:, 0] - C0) / A0
        for j in range(NS):
            out[f"vd{1 + 3 * j:02d}"] = (H[:, j] - C0) / A0
            out[f"vd{2 + 3 * j:02d}"] = (L[:, j] - C0) / A0
            out[f"vd{3 + 3 * j:02d}"] = (C[:, j] - C0) / A0
        prevC = np.column_stack([C0, C[:, :NS - 1]])
        out["gap_a"] = (O[:, 0] - C0) / A0
        out["gap_p"] = O[:, 0] / C0 - 1
        for j in range(NS):
            s = j + 1
            out[f"o2h_a{s}"] = (H[:, j] - O[:, j]) / A0
            out[f"o2l_a{s}"] = (L[:, j] - O[:, j]) / A0
            out[f"o2c_a{s}"] = (C[:, j] - O[:, j]) / A0
            out[f"c2c_a{s}"] = (C[:, j] - prevC[:, j]) / A0
            out[f"c2c_p{s}"] = C[:, j] / prevC[:, j] - 1
            rg = H[:, j] - L[:, j]
            out[f"rng_a{s}"] = rg / A0
            out[f"clv{s}"] = np.where(rg > 0, (C[:, j] - L[:, j]) / np.where(rg > 0, rg, 1.0), np.nan)
            out[f"rvol{s}"] = (np.asarray(V, float)[:, j] / v50) if (V is not None and v50 is not None) else np.full(n, np.nan)
            out[f"co_p{s}"] = C[:, j] / O[:, 0] - 1           # close of session s / session-1 open - 1 (TLX close_ret_s)
        out["r5_a"] = (C[:, 4] - C0) / A0
        out["r5_p"] = C[:, 4] / C0 - 1
        out["r5_pos"] = (C[:, 4] > C0).astype(np.float64)
        out["r5o_p"] = C[:, 4] / O[:, 0] - 1                  # BigMove's trade (session-1 open to session-5 close), before costs
        out["r5o_a"] = (C[:, 4] - O[:, 0]) / A0
        hmax, lmin = H.max(axis=1), L.min(axis=1)
        out["mfe_a"] = (hmax - C0) / A0
        out["mae_a"] = (lmin - C0) / A0
        out["mfe_p"] = hmax / C0 - 1
        out["mae_p"] = lmin / C0 - 1
        out["mfe_s"] = (H.argmax(axis=1) + 1).astype(np.int8)
        out["mae_s"] = (L.argmin(axis=1) + 1).astype(np.int8)
        out["mfeo_p"] = hmax / O[:, 0] - 1                   # pick_meta / TLX definition (from the entry = session-1 open)
        out["maeo_p"] = lmin / O[:, 0] - 1
        # first touches (session 1..5, 0 = never)
        lv = {}
        for col, side, x, is_atr in threshold_specs(D):
            lvl = level_of(C0, A0, side, x, is_atr)
            lv[col] = lvl
            hit = (H >= lvl[:, None]) if side == "up" else (L <= lvl[:, None])
            out[col] = (first_true(hit) + 1).astype(np.int8)
        for col, cu, cd in order_specs(D):
            iu, idn = out[cu].astype(np.int64) - 1, out[cd].astype(np.int64) - 1
            same = (iu >= 0) & (iu == idn)
            op = np.full(n, np.nan)
            op[same] = O[rows[same], iu[same]]
            out[col] = order_code(iu, idn, op, lv[cu], lv[cd])
        # recovery
        o11 = out["ord_a1_1"] if "ord_a1_1" in out else None
        r5up = (C[:, 4] > C0).astype(np.float64)
        if o11 is not None:
            down_first = o11 == 2
            out["up_first_a1"] = np.where((o11 == 1) | (o11 == 2), (o11 == 1).astype(np.float64), np.nan)
            out["rec_d1_endup"] = np.where(down_first, r5up, np.nan)
            s = out["td_a1"].astype(np.int64)                  # 1..5 where touched
            back = np.zeros(n, bool)
            toup = np.zeros(n, bool)
            dn1 = lv["td_a1"]
            for k in range(NS):
                at = down_first & (s == k + 1)
                if not at.any():
                    continue
                later = H[:, k + 1:].max(axis=1) >= C0 if k + 1 < NS else np.zeros(n, bool)
                same_sess = (C[:, k] >= C0) | ((O[:, k] <= dn1) & (H[:, k] >= C0))
                back[at] = (later | same_sess)[at]
            tu1 = out["tu_a1"].astype(np.int64)
            toup = down_first & (tu1 > 0) & (tu1 >= s)
            out["rec_d1_backc0"] = np.where(down_first, back.astype(np.float64), np.nan)
            out["rec_d1_toup1"] = np.where(down_first, toup.astype(np.float64), np.nan)
        if "td_a2" in out:
            out["rec_d2_endup"] = np.where(out["td_a2"] > 0, r5up, np.nan)
        if "td_p5" in out:
            out["rec_p5_endup"] = np.where(out["td_p5"] > 0, r5up, np.nan)
        # continuation and reversal after a strong / weak session 1
        k_ = float(D.get("continuation_atr", 0.5))
        c1 = (C[:, 0] - C0) / A0
        strong, weak = c1 >= k_, c1 <= -k_
        out["cont_up"] = np.where(strong, (C[:, 4] > C[:, 0]).astype(np.float64), np.nan)
        out["rev_up"] = np.where(strong, (C[:, 4] < C0).astype(np.float64), np.nan)
        out["cont_dn"] = np.where(weak, (C[:, 4] < C[:, 0]).astype(np.float64), np.nan)
        out["rev_dn"] = np.where(weak, (C[:, 4] > C0).astype(np.float64), np.nan)
        # momentum
        ups = C > prevC
        out["sign_code"] = (ups * (1 << np.arange(NS))[None, :]).sum(axis=1).astype(np.int8)
        out["n_up"] = ups.sum(axis=1).astype(np.int8)
        out["best_close_s"] = (C.argmax(axis=1) + 1).astype(np.int8)
        out["worst_close_s"] = (C.argmin(axis=1) + 1).astype(np.int8)
        # volatility
        rgs = H - L
        den = rgs[:, 0] + rgs[:, 1]
        out["vol45_12"] = np.where(den > 0, (rgs[:, 3] + rgs[:, 4]) / np.where(den > 0, den, 1.0), np.nan)
        lr = np.log(C / prevC)
        rvw = np.sqrt(np.mean(lr ** 2, axis=1))
        out["rv_ratio"] = rvw / np.asarray(rv20, float) if rv20 is not None else np.full(n, np.nan)
        # stages and named sequences
        S = D["stages"]
        mv = np.column_stack([out[f"c2c_a{s}"] for s in range(1, NS + 1)])
        rr = np.column_stack([out[f"rng_a{s}"] for s in range(1, NS + 1)])
        stg = stage_code(mv, rr, S)
        for j in range(NS):
            out[f"stg{j + 1}"] = stg[:, j]
        out.update(sequences(stg, rr, S))
        # sessions with no trading range (high == low): circuit-locked sessions
        lk = H == L
        out["n_locked"] = lk.sum(axis=1).astype(np.int8)
        out["lock_up"] = (lk & (C > prevC)).any(axis=1).astype(np.int8)
        out["lock_dn"] = (lk & (C < prevC)).any(axis=1).astype(np.int8)
    return out


# ----------------------------------------------------------------------
# 3-minute: one table per stock-day (rupees, minutes), then rows by gathering sessions
# ----------------------------------------------------------------------
def session_table(O3, H3, L3, C3, V3, present, dclose, D: dict) -> Dict[str, np.ndarray]:
    """Per session (dense row): the quantities every measure needs, in rupees, from the 3-minute bars and the
    daily close. Missing bars inside a usable session: a checkpoint takes the last bar before it."""
    nd = O3.shape[0]
    I = D["intraday"]
    sl = np.arange(NB)[None, :]
    last = np.where(present, sl, -1)
    last = np.maximum.accumulate(last, axis=1)
    Cff = np.take_along_axis(np.where(present, C3, np.nan), np.maximum(last, 0), axis=1)
    Cff[last < 0] = np.nan
    Hn = np.where(present & np.isfinite(H3), H3, -np.inf)
    Ln = np.where(present & np.isfinite(L3), L3, np.inf)
    t = {"open": O3[:, 0].astype(float), "close": np.asarray(dclose, float)}
    for s in sorted(set(int(x) for x in I["checkpoint_slots"] if int(x) >= 0) |
                    set(int(x) for x in I["opening_slots"]) | {int(I["last_hour_slot"]), int(I["morning_last_slot"])}):
        t[f"p{s}"] = Cff[:, s]
    t["hi_bar"] = Hn.argmax(axis=1).astype(np.int16)
    t["lo_bar"] = Ln.argmin(axis=1).astype(np.int16)
    t["hi"] = Hn.max(axis=1)
    t["lo"] = Ln.min(axis=1)
    m = int(I["morning_last_slot"])
    t["hm"], t["lm"] = Hn[:, :m + 1].max(axis=1), Ln[:, :m + 1].min(axis=1)
    t["ha"], t["la"] = Hn[:, m + 1:].max(axis=1), Ln[:, m + 1:].min(axis=1)
    for s in I["opening_slots"]:
        s = int(s)
        t[f"h_0_{s}"], t[f"l_0_{s}"] = Hn[:, :s + 1].max(axis=1), Ln[:, :s + 1].min(axis=1)
    tp = (np.where(present, H3, 0) + np.where(present, L3, 0) + np.where(present, C3, 0)) / 3.0
    vv = np.where(present & np.isfinite(V3) & (V3 > 0), V3, 0.0)
    num = np.nansum(tp * vv, axis=1)
    den = vv.sum(axis=1)
    with np.errstate(divide="ignore", invalid="ignore"):
        t["vwap"] = np.where(den > 0, num / np.where(den > 0, den, 1.0), np.nan)
    for k in ("hi", "lo", "hm", "lm", "ha", "la"):
        t[k] = np.where(np.isfinite(t[k]), t[k], np.nan)
    for s in I["opening_slots"]:
        for k in (f"h_0_{int(s)}", f"l_0_{int(s)}"):
            t[k] = np.where(np.isfinite(t[k]), t[k], np.nan)
    return t


def intraday_measures(C0, A0, dr, aff_a, aff_g, prevC, T: Dict[str, np.ndarray], bars: Tuple[np.ndarray, ...],
                      D: dict) -> Dict[str, np.ndarray]:
    """C0, A0: (n,). dr: (n, 5) dense rows of the window's sessions (-1 = not usable). aff_a, aff_g: (n, 5) the
    price map of each session (real: 0 and 1). prevC: (n, 5) the previous close of each session on the path (real:
    C0, then the daily closes). T: session_table. bars: (O3, H3, L3, C3) dense arrays (n_days x 125).
    Session measures exist wherever that session is usable; window measures only when all five are."""
    C0 = np.asarray(C0, float)
    A0 = np.asarray(A0, float)
    n = len(C0)
    I = D["intraday"]
    S = D["stages"]
    out: Dict[str, np.ndarray] = {}
    ok = dr >= 0
    nanv = np.full(n, np.nan)

    def g(key, j):
        v = nanv.copy()
        m = ok[:, j]
        v[m] = T[key][dr[m, j]]
        return v

    def px(key, j):          # mapped price of a session quantity
        return aff_a[:, j] + aff_g[:, j] * g(key, j)

    with np.errstate(divide="ignore", invalid="ignore"):
        hf = float(S["half_factor"])
        for j in range(NS):
            s = j + 1
            m = ok[:, j]
            out[f"iu{s}"] = m.astype(np.int8)
            hb, lb = g("hi_bar", j), g("lo_bar", j)
            out[f"thi{s}"] = hb * 3.0
            out[f"tlo{s}"] = lb * 3.0
            out[f"hif{s}"] = np.where(m & (hb != lb), (hb < lb).astype(np.float64), np.nan)
            cl = px("close", j)
            out[f"vwp_a{s}"] = (cl - px("vwap", j)) / A0
            out[f"lh_a{s}"] = (cl - px(f"p{int(I['last_hour_slot'])}", j)) / A0
            mid = px(f"p{int(I['morning_last_slot'])}", j)
            mm = (mid - prevC[:, j]) / A0
            mr = aff_g[:, j] * (g("hm", j) - g("lm", j)) / A0
            am = (cl - mid) / A0
            ar = aff_g[:, j] * (g("ha", j) - g("la", j)) / A0
            ms, as_ = stage_code(mm, mr, S, hf), stage_code(am, ar, S, hf)
            out[f"mstg{s}"] = np.where(m, ms, 0).astype(np.int8)
            out[f"astg{s}"] = np.where(m, as_, 0).astype(np.int8)
        # opening (session 1)
        o1 = px("open", 0)
        names = {4: "15", 9: "30", 19: "60"}
        for s in I["opening_slots"]:
            s = int(s)
            nm = names.get(s, str((s + 1) * 3))
            out[f"m{nm}_a"] = (px(f"p{s}", 0) - o1) / A0
            out[f"r{nm}_a"] = aff_g[:, 0] * (g(f"h_0_{s}", 0) - g(f"l_0_{s}", 0)) / A0
        m30 = out.get("m30_a", nanv)
        dthr = float(I["drive_atr"])
        drv = np.where(m30 >= dthr, 1, np.where(m30 <= -dthr, -1, 0)).astype(np.float64)
        out["drive"] = np.where(ok[:, 0], drv, np.nan)
        s60 = int(I["opening_slots"][-1])
        h1, l1, p1015 = px(f"h_0_{s60}", 0), px(f"l_0_{s60}", 0), px(f"p{s60}", 0)
        rj = float(I["rejection_atr"])
        out["rej_up"] = np.where(ok[:, 0], (((h1 - o1) / A0 >= rj) & ((h1 - p1015) / A0 >= rj)).astype(np.float64), np.nan)
        out["rej_dn"] = np.where(ok[:, 0], (((o1 - l1) / A0 >= rj) & ((p1015 - l1) / A0 >= rj)).astype(np.float64), np.nan)
        # ---- window measures (all five sessions usable) ----
        full = ok.all(axis=1)
        out["iok"] = full.astype(np.int8)
        vi = np.full((n, 45), np.nan)
        cps = [int(x) for x in I["checkpoint_slots"]]
        for j in range(NS):
            for c, sl in enumerate(cps):
                key = "open" if sl == -1 else ("close" if sl == -2 else f"p{sl}")
                vi[:, 9 * j + c] = (px(key, j) - C0) / A0
        vi[~full] = np.nan
        for k in range(45):
            out[f"vi{k:02d}"] = vi[:, k]
        specs = threshold_specs(D)
        for col, side, x, is_atr in specs:
            out["i" + col] = np.full(n, -1, np.int16)
        for col, cu, cd in order_specs(D):
            out["i" + col] = np.zeros(n, np.int8)
        for k in ("imfe_bar", "imae_bar"):
            out[k] = np.full(n, -1, np.int16)
        out["iup_first_a1"] = nanv.copy()
        out["irec_d1_backc0"] = nanv.copy()
        out["irec_d1_toup1"] = nanv.copy()
        rows = np.flatnonzero(full)
        if len(rows):
            O3, H3, L3, C3 = bars
            idx = dr[rows]                                    # (m, 5)
            a = aff_a[rows][:, :, None]
            gg = aff_g[rows][:, :, None]
            Hb = (a + gg * H3[idx]).reshape(len(rows), NS * NB)
            Lb = (a + gg * L3[idx]).reshape(len(rows), NS * NB)
            Ob = (a + gg * O3[idx]).reshape(len(rows), NS * NB)
            Cb = (a + gg * C3[idx]).reshape(len(rows), NS * NB)
            Hf = np.where(np.isfinite(Hb), Hb, -np.inf)
            Lf = np.where(np.isfinite(Lb), Lb, np.inf)
            out["imfe_bar"][rows] = Hf.argmax(axis=1)
            out["imae_bar"][rows] = Lf.argmin(axis=1)
            c0, a0 = C0[rows], A0[rows]
            lv = {}
            for col, side, x, is_atr in specs:
                lvl = level_of(c0, a0, side, x, is_atr)
                lv[col] = lvl
                hit = (Hf >= lvl[:, None]) if side == "up" else (Lf <= lvl[:, None])
                out["i" + col][rows] = first_true(hit)
            rr = np.arange(len(rows))
            for col, cu, cd in order_specs(D):
                iu, idn = out["i" + cu][rows].astype(np.int64), out["i" + cd][rows].astype(np.int64)
                same = (iu >= 0) & (iu == idn)
                op = np.full(len(rows), np.nan)
                op[same] = Ob[rr[same], iu[same]]
                out["i" + col][rows] = order_code(iu, idn, op, lv[cu], lv[cd])
            if "iord_a1_1" in out:
                o11 = out["iord_a1_1"][rows]
                out["iup_first_a1"][rows] = np.where((o11 == 1) | (o11 == 2), (o11 == 1).astype(np.float64), np.nan)
                dfirst = o11 == 2
                b = out["itd_a1"][rows].astype(np.int64)
                bsafe = np.maximum(b, 0)
                suf = np.maximum.accumulate(Hf[:, ::-1], axis=1)[:, ::-1]      # suf[:, t] = max(H[:, t:])
                nxt = np.minimum(bsafe + 1, NS * NB - 1)
                after = (bsafe + 1 < NS * NB) & (suf[rr, nxt] >= c0)
                same_bar = (Cb[rr, bsafe] >= c0) | ((Ob[rr, bsafe] <= lv["td_a1"]) & (Hb[rr, bsafe] >= c0))
                back = after | same_bar
                tu = out["itu_a1"][rows].astype(np.int64)
                toup = (tu >= 0) & (tu >= b)
                out["irec_d1_backc0"][rows] = np.where(dfirst, back.astype(np.float64), np.nan)
                out["irec_d1_toup1"][rows] = np.where(dfirst, toup.astype(np.float64), np.nan)
    return out


def bar_session(bar: np.ndarray) -> np.ndarray:
    """Global window bar 0..624 -> session 1..5 (0 for -1)."""
    b = np.asarray(bar, np.int64)
    return np.where(b >= 0, b // NB + 1, 0)


def bar_minute(bar: np.ndarray) -> np.ndarray:
    """Global window bar -> minutes after 09:15 of its session (NaN for -1)."""
    b = np.asarray(bar, np.int64)
    return np.where(b >= 0, (b % NB) * 3.0, np.nan)


def bar_trading_minutes(bar: np.ndarray) -> np.ndarray:
    """Global window bar -> trading minutes after the session-1 open (375 a session; NaN for -1)."""
    b = np.asarray(bar, np.int64)
    return np.where(b >= 0, (b // NB) * 375.0 + (b % NB) * 3.0, np.nan)
