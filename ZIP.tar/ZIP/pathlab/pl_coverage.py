"""
pl_coverage.py - pathlab v1.0: the coverage audit (outcome-blind; Phase 1 revision of 25 Oct, change 2).

Before any training choice is frozen: for every state x regime cell (and each state, each regime, everything), year
by year and in each candidate training / validation window, how many stock-days, stocks, market dates and separate
10-session stretches exist, and what they are worth in independent observations. Equities and ETFs are counted
apart; stocks that stop trading inside the cache and stocks that list after 2020 are listed (survivorship).

NOTHING AFTER T0 IS READ. The effective sample uses a value known at T0 - the stock's move over the five sessions
up to T0, in ATR units - so it shows how much the cell's rows cluster (overlapping windows, stocks moving together
on a date) without looking at any outcome. Output: PATHLAB_OUT\\coverage\\COV_YYYYMMDD_NNN\\ (coverage.md + tables).
"""
from __future__ import annotations

import re
import time
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

import pl_common as PC
import pl_build as PB
import pl_atlas as PA

COV_VERSION = "pl_coverage v1.0"
WINDOWS = [  # (name, first T0, last T0) - candidate windows for the revised protocol; every year is added too
    ("train 2020-2022", "2020-01-01", "2022-12-31"), ("train 2020-2023", "2020-01-01", "2023-12-31"),
    ("train 2020-2024", "2020-01-01", "2024-12-31"), ("validate 2023", "2023-01-01", "2023-12-31"),
    ("validate 2024", "2024-01-01", "2024-12-31"), ("validate 2025", "2025-01-01", "2025-12-31"),
    ("validate 2023-2025", "2023-01-01", "2025-12-31"), ("development 2020-2025", "2020-01-01", "2025-12-31"),
    ("final 2026", "2026-01-01", "2026-09-15"), ("all 2020-2026", "2020-01-01", "2026-09-15")]
CANDIDATES = [("50 dates, 250 rows, 8 stretches", 50, 250, 8), ("100 dates, 500 rows, 10 stretches", 100, 500, 10),
              ("200 dates, 1,000 rows", 200, 1000, 0)]
ETF_SUFFIX = re.compile(r"(BEES|IETF|ETF)$")


def etf_symbols(root: Path, base: Path, syms: Sequence[str]) -> Tuple[set, str]:
    """The ETFs among the panel's symbols.

    NSE's ETF list (eq_etfseclist.csv, a 'Symbol' column) when present, JOINED with the name rule (symbol ends in
    BEES, ETF or IETF): NSE's list holds today's names only, and the cache can hold an ETF under a name it later
    dropped (DSP renamed its ETFs ...ETF -> ...ADD in Feb 2024). Without the list, the name rule alone - incomplete,
    and the returned text says so. Corrections from PATHLAB_OUT\\ref\\etf_corrections.csv (columns symbol,is_etf;
    1 = ETF, 0 = not) apply last. A file that cannot be read is an error, never silently skipped."""
    syms = {str(s) for s in syms}
    by_name = {s for s in syms if ETF_SUFFIX.search(s.upper())}
    listed, source = None, ""
    for p in (Path(root) / "sectors" / "eq_etfseclist.csv", Path(base) / "ref" / "eq_etfseclist.csv"):
        if not p.exists():
            continue
        try:
            E = pd.read_csv(p, dtype=str)
        except Exception as e:  # noqa: BLE001
            raise PC.PLError(f"{p} could not be read as a csv ({type(e).__name__}: {e}) - save NSE's file again or "
                             f"remove it")
        col = next((c for c in E.columns if str(c).strip().lower() == "symbol"), None)
        if col is None:
            raise PC.PLError(f"{p} has no 'Symbol' column (its columns: {', '.join(map(str, E.columns))}) - is it "
                             f"NSE's ETF list?")
        listed = {str(s).strip().upper() for s in E[col].dropna() if str(s).strip()}
        n_in = sum(1 for s in syms if s.upper() in listed)
        source = (f"NSE's ETF list {p} ({len(listed):,} names, {n_in:,} of them in the panel) plus the name rule "
                  f"(BEES / ETF / IETF endings: ETFs the cache holds under an older name)")
        break
    if listed is None:
        out = set(by_name)
        source = ("the name rule alone (symbol ends in BEES, ETF or IETF) - INCOMPLETE: ETFs with other names (GOLD1, "
                  "BANKNIFTY1, DSP's ...ADD names such as SILVERADD) are missed. Save NSE's eq_etfseclist.csv as "
                  "%PATHLAB_OUT%\\ref\\eq_etfseclist.csv and run again")
    else:
        out = {s for s in syms if s.upper() in listed} | by_name
    corr = Path(base) / "ref" / "etf_corrections.csv"
    if corr.exists():
        try:
            C = pd.read_csv(corr, dtype=str)
        except Exception as e:  # noqa: BLE001
            raise PC.PLError(f"{corr} could not be read as a csv ({type(e).__name__}: {e})")
        cols = {str(c).strip().lower(): c for c in C.columns}
        if "symbol" not in cols or "is_etf" not in cols:
            raise PC.PLError(f"{corr} needs two columns, symbol,is_etf (its columns: {', '.join(map(str, C.columns))})")
        upper = {s.upper(): s for s in syms}
        applied, unknown, bad = 0, [], []
        for s_raw, v_raw in zip(C[cols["symbol"]], C[cols["is_etf"]]):
            if pd.isna(s_raw) or not str(s_raw).strip():
                continue
            s, v = str(s_raw).strip().upper(), str(v_raw).strip()
            if v not in ("1", "0"):
                bad.append(f"{s}={v}")
            elif s not in upper:
                unknown.append(s)
            else:
                (out.add if v == "1" else out.discard)(upper[s])
                applied += 1
        if bad:
            raise PC.PLError(f"{corr}: is_etf must be 1 or 0 - fix {', '.join(bad[:10])}")
        source += (f"; {applied:,} corrections from {corr}" +
                   (f" ({len(unknown):,} not in the panel, ignored: {', '.join(unknown[:10])})" if unknown else ""))
    return out, source


def coverage_rows(world, M: pd.DataFrame, U: Dict[str, np.ndarray], etf: set, decl: dict, log=None,
                  only: Optional[Sequence[str]] = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """One row per panel stock-day in the span: state and regime at T0, filters, liquidity, the move over the five
    sessions UP TO T0 (the effective-sample proxy). Uses bars up to T0 only."""
    t0 = time.time()
    cal = world.cal
    env = M["env"].to_numpy()
    Ucfg = decl["universe"]
    parts, stocks = [], []
    syms = sorted(U) if only is None else [s for s in sorted(U) if s in set(only)]
    for b0 in range(0, len(syms), 50):
        chunk = syms[b0:b0 + 50]
        world.market.load(chunk)
        for s in chunk:
            ds = world.market.series(s)
            if ds is None or len(ds) < 2:
                continue
            ss = world.TS.StateSeries(s, ds.dates, ds.o, ds.h, ds.l, ds.c, ds.v)
            days = U[s]
            ipos = np.searchsorted(ds.dates, days)
            ok = ipos < len(ds.dates)
            ok[ok] = ds.dates[ipos[ok]] == days[ok]
            ppos = np.searchsorted(cal, days)
            okp = ppos < len(cal)
            okp[okp] = cal[ppos[okp]] == days[okp]
            ok &= okp
            days, ipos, ppos = days[ok], ipos[ok], ppos[ok]
            A = ss.A
            atr0 = A["atr"][ipos]
            st0 = np.array([PC.STATE_CODES.get(x, 0) for x in ss.state[ipos]], dtype=np.int8)
            insuff = (st0 == -1) | (ipos + 1 < int(Ucfg["min_history_sessions"])) | ~(atr0 > 0)
            with np.errstate(divide="ignore", invalid="ignore"):
                rng_ = (ds.h - ds.l) / ds.c
                prior5 = np.where(ipos >= 5, (ds.c[ipos] - ds.c[np.maximum(ipos - 5, 0)]) / atr0, np.nan)
            med = PB.rolling_median_at(rng_, ipos, int(Ucfg["cash_like_window"]))
            cash = np.isfinite(med) & (med < float(Ucfg["cash_like_max_median_range"]))
            liq = PB.rolling_median_at(ds.c * ds.v, ipos, int(Ucfg["turnover_window"]))
            parts.append(pd.DataFrame({"sym": s, "t0": days.astype("datetime64[ns]"), "state0": st0,
                                       "reg0": env[ppos].astype(np.int8), "insuff": insuff, "cash_like": cash,
                                       "etf": s in etf, "liq": liq, "prior5": prior5}))
            stocks.append({"symbol": s, "first_bar": str(ds.dates[0]), "last_bar": str(ds.dates[-1]), "etf": s in etf,
                           "panel_rows_in_span": int(len(days))})
            world.market.daily.pop(s, None)
        if log and ((b0 // 50) % 10 == 9 or b0 + 50 >= len(syms)):
            log(f"   {min(b0 + 50, len(syms)):,} of {len(syms):,} stocks ({time.time() - t0:,.0f} s)")
    R = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()
    if len(R):
        R["year"] = pd.DatetimeIndex(R["t0"]).year
        R["eligible"] = ~R["insuff"] & ~R["cash_like"]
    return R, pd.DataFrame(stocks)


def run_coverage(root: Path, decl: dict, base: Path, log=None, stage_e_any=False, tradelab_any=False) -> Path:
    t0 = time.time()
    cdir = _cov_dir(base)
    log = PC.Log(cdir / "log.txt")
    log(f"[coverage] {COV_VERSION}: counts only - nothing after T0 is read ({cdir})")
    world = PB.World(root, decl, stage_e_any, tradelab_any, log)
    M = world.market_info(base)
    U = world.universe()
    etf, etf_src = etf_symbols(root, base, list(U))
    log(f"   universe: {sum(len(v) for v in U.values()):,} panel rows, {len(U):,} stocks; ETFs: {len(etf):,} by {etf_src}")
    R, S = coverage_rows(world, M, U, etf, decl, log)
    S["stopped_inside_cache"] = pd.to_datetime(S["last_bar"]) < pd.Timestamp(world.last_window_day)
    S["listed_after_2019"] = pd.to_datetime(S["first_bar"]) > pd.Timestamp("2019-10-01")
    PC.write_table(S, cdir / "stocks")
    PC.write_table(S[S["etf"]], cdir / "etf_list")
    out = coverage_tables(R, decl, cdir, log)
    out.update({"version": COV_VERSION, "etf_source": etf_src, "etfs": int(len(etf)), "stocks": int(len(S)),
                "stopped_inside_cache": int(S["stopped_inside_cache"].sum()),
                "listed_after_2019": int(S["listed_after_2019"].sum()), "seconds": round(time.time() - t0, 1),
                "breadth": world.ctx_meta.get("breadth_source"), "provenance": PC.provenance()})
    PC.write_json_atomic(out, cdir / "coverage.json")
    write_md(cdir, out, R, S, etf_src)
    PC.write_outputs_sha(cdir)
    PC.ledger_append(base, {"event": "coverage", "folder": cdir.name, "rows": int(len(R))})
    log(f"[coverage] done in {out['seconds']:,.0f} s -> {cdir / 'coverage.md'}")
    return cdir


def _cov_dir(base: Path) -> Path:
    import datetime as dt
    d = Path(base) / "coverage"
    d.mkdir(parents=True, exist_ok=True)
    stamp = dt.datetime.now().strftime("%Y%m%d")
    n = 1
    while (d / f"COV_{stamp}_{n:03d}").exists():
        n += 1
    p = d / f"COV_{stamp}_{n:03d}"
    p.mkdir()
    return p


def coverage_tables(R: pd.DataFrame, decl: dict, cdir: Path, log) -> dict:
    """Per window x universe (equities / ETFs) x group: rows, stocks, dates, stretches, effective n (from prior5)."""
    D2 = {"atlas": dict(decl["atlas"])}
    D2["atlas"]["boot_B"] = int(decl["atlas"].get("coverage_boot_B", 500))
    t = PC.to_day(R["t0"])
    si = R["state0"].map(PA.SI_OF).fillna(-1).astype(int).to_numpy()
    ri = R["reg0"].astype(int).to_numpy()
    base_ok = R["eligible"].to_numpy() & (si >= 0) & (ri >= 0)
    sym = pd.factorize(R["sym"])[0]
    wins = list(WINDOWS) + [(f"year {y}", f"{y}-01-01", f"{y}-12-31") for y in sorted(R["year"].unique())]
    rows = []
    days_rows = []
    for uni, um in (("equities", ~R["etf"].to_numpy()), ("ETFs", R["etf"].to_numpy())):
        for wname, a, b in wins:
            m = base_ok & um & (t >= PC.day(a)) & (t <= PC.day(b))
            if m.sum() == 0:
                continue
            E = PA.Engine(t[m], si[m], ri[m], D2)
            st = E.stats({"x": R["prior5"].to_numpy(float)[m], "_one": np.ones(int(m.sum()))})
            x = st["x"]
            xs = R["prior5"].to_numpy(float)[m]
            for g in range(PA.NG):
                ing = PA._in_group(E, g)
                vv = xs[ing]
                vv = vv[np.isfinite(vv)]
                sd = x["sd"][g]
                neff = float(np.var(vv) / sd ** 2) if (len(vv) > 1 and np.isfinite(sd) and sd > 0) else np.nan
                kind, s_, r_ = PA.group_label(g)
                rows.append({"universe": uni, "window": wname, "group": g, "group_text": PA.group_text(g), "kind": kind,
                             "state": s_, "regime": r_, "rows": int(st["_one"]["n"][g]), "dates": int(st["_one"]["nd"][g]),
                             "stretches": int(st["_one"]["nblk"][g]),
                             "stocks": int(np.unique(sym[m][ing]).size) if ing.any() else 0, "n_eff": neff,
                             "n_eff_per_row": neff / st["_one"]["n"][g] if st["_one"]["n"][g] > 0 else np.nan})
            if uni == "equities":
                dd = pd.DataFrame({"t": t[m], "r": ri[m]}).drop_duplicates()
                for r_, c_ in dd["r"].value_counts().items():
                    days_rows.append({"window": wname, "regime": PC.REGIMES[int(r_)], "dates": int(c_)})
        log(f"   {uni}: counted in {len(wins)} windows")
    C = pd.DataFrame(rows)
    PC.write_table(C, cdir / "coverage_groups")
    Dd = pd.DataFrame(days_rows)
    PC.write_table(Dd, cdir / "regime_days")
    # how many of the 45 cells meet each candidate minimum, per window (equities)
    cells = C[(C["universe"] == "equities") & (C["kind"] == "cell")]
    meet = []
    for wname, _, _ in wins:
        w = cells[cells["window"] == wname]
        rec = {"window": wname}
        for nm, md, mo, ms in CANDIDATES:
            rec[nm] = int(((w["dates"] >= md) & (w["rows"] >= mo) & (w["stretches"] >= ms)).sum())
        meet.append(rec)
    Mt = pd.DataFrame(meet)
    PC.write_table(Mt, cdir / "cells_meeting_minimums")
    return {"windows": [w[0] for w in wins], "cells_meeting": Mt.to_dict(orient="records"),
            "rows_eligible_equities": int((base_ok & ~R["etf"].to_numpy()).sum()),
            "rows_eligible_etfs": int((base_ok & R["etf"].to_numpy()).sum()),
            "rows_cash_like": int(R["cash_like"].sum()), "rows_insufficient": int(R["insuff"].sum())}


def write_md(cdir: Path, out: dict, R: pd.DataFrame, S: pd.DataFrame, etf_src: str) -> None:
    C = pd.read_parquet(cdir / "coverage_groups.parquet")
    Dd = pd.read_parquet(cdir / "regime_days.parquet")
    L = [f"# pathlab coverage audit ({COV_VERSION})", "",
         "Counts only: nothing after T0 is read. Effective n = what a group's rows are worth in independent "
         "observations, from the date-block bootstrap of the move over the five sessions up to T0 (known at T0).", "",
         f"- Eligible rows: equities {out['rows_eligible_equities']:,}, ETFs {out['rows_eligible_etfs']:,}; cash-like rows "
         f"removed {out['rows_cash_like']:,}; under 60 sessions of bars {out['rows_insufficient']:,}.",
         f"- ETFs: {out['etfs']:,} by {etf_src} (full list: etf_list.csv).",
         f"- Survivorship: {out['stopped_inside_cache']:,} of {out['stocks']:,} stocks stop trading before the last window "
         f"ends (delisted, suspended, or renamed on NSE - a symbol change shows as one name stopping and another "
         f"starting; kept, listed in stocks.csv); {out['listed_after_2019']:,} list after 2019. Stocks delisted before "
         f"the cache was built are absent and cannot be counted from this data.", "",
         "## Market dates per regime (equities)", ""]
    piv = Dd.pivot_table(index="window", columns="regime", values="dates", aggfunc="sum").reindex(columns=list(PC.REGIMES))
    order = [w for w in out["windows"] if w in piv.index]
    piv = piv.reindex(order).fillna(0).astype(int)
    L.append("| window | " + " | ".join(PC.REGIME_TEXT[r] for r in PC.REGIMES) + " |")
    L.append("|---|" + "---|" * len(PC.REGIMES))
    for w, r in piv.iterrows():
        L.append(f"| {w} | " + " | ".join(f"{int(v):,}" for v in r.to_numpy()) + " |")
    L += ["", "## State x regime cells meeting candidate minimums (of 45, equities)", ""]
    Mt = pd.DataFrame(out["cells_meeting"])
    L.append("| window | " + " | ".join(Mt.columns[1:]) + " |")
    L.append("|---|" + "---|" * (len(Mt.columns) - 1))
    for r in Mt.itertuples(index=False):
        L.append("| " + " | ".join(str(x) for x in r) + " |")
    for wname in ("train 2020-2022", "validate 2023-2025", "final 2026", "all 2020-2026"):
        w = C[(C["universe"] == "equities") & (C["window"] == wname) & (C["kind"] == "cell")]
        if not len(w):
            continue
        L += ["", f"## {wname}: dates / rows / effective n per cell (equities)", "",
              "| state | " + " | ".join(PC.REGIME_TEXT[r] for r in PC.REGIMES) + " |", "|---|" + "---|" * 5]
        for s in PC.CELL_STATES:
            cells = []
            for r in PC.REGIMES:
                x = w[(w["state"] == s) & (w["regime"] == r)]
                cells.append("-" if not len(x) else f"{int(x['dates'].iloc[0]):,} / {int(x['rows'].iloc[0]):,} / "
                                                    f"{x['n_eff'].iloc[0]:,.0f}")
            L.append(f"| {s} {PC.STATE_SHORT[s]} | " + " | ".join(cells) + " |")
    L += ["", "Full tables: coverage_groups.csv (every window x universe x group), regime_days.csv, "
          "cells_meeting_minimums.csv, stocks.csv, etf_list.csv.", ""]
    (cdir / "coverage.md").write_text("\n".join(L), encoding="utf-8")
