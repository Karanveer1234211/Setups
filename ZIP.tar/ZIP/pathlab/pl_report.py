"""
pl_report.py - pathlab v1.0: the report (ATLAS.md, ATLAS.html with charts, summary.json, outputs.sha256, a ledger
line). Everything here reads finished tables; nothing is computed that the tables do not already hold.
"""
from __future__ import annotations

import datetime as dt
import html
import json
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

import pl_common as PC
import pl_atlas as PA

REPORT_VERSION = "pl_report v1.0"


# ======================================================================
# formatting
# ======================================================================
def pct(x, nd=1, sign=False) -> str:
    try:
        v = float(x)
    except (TypeError, ValueError):
        return "n/a"
    if not np.isfinite(v):
        return "n/a"
    return f"{v * 100:+.{nd}f}%" if sign else f"{v * 100:.{nd}f}%"


def pp(x, nd=1) -> str:
    """percentage points, signed"""
    try:
        v = float(x)
    except (TypeError, ValueError):
        return "n/a"
    return "n/a" if not np.isfinite(v) else f"{v * 100:+.{nd}f} pp"


def num(x, nd=2, sign=False) -> str:
    try:
        v = float(x)
    except (TypeError, ValueError):
        return "n/a"
    if not np.isfinite(v):
        return "n/a"
    return f"{v:+.{nd}f}" if sign else f"{v:.{nd}f}"


def val(x, kind: str, unit: str, sign=False) -> str:
    if kind == "prob" or unit == "share":
        return pct(x, 1, sign)
    if unit == "%":
        return pct(x, 2, sign)
    if unit == "minutes":
        return num(x, 0, sign)
    return num(x, 2, sign)


def ci(v, lo, hi, kind, unit, sign=False) -> str:
    a = val(v, kind, unit, sign)
    if lo is None or hi is None:
        return a
    try:
        if not (np.isfinite(float(lo)) and np.isfinite(float(hi))):
            return a
    except (TypeError, ValueError):
        return a
    return f"{a} [{val(lo, kind, unit, sign)}, {val(hi, kind, unit, sign)}]"


def dci(d, lo, hi, kind, unit) -> str:
    """a difference with its interval: percentage points for shares"""
    f = (lambda x: pp(x)) if (kind == "prob" or unit == "share") else (lambda x: val(x, kind, unit, True))
    try:
        ok = np.isfinite(float(lo)) and np.isfinite(float(hi))
    except (TypeError, ValueError):
        ok = False
    return f"{f(d)} [{f(lo)}, {f(hi)}]" if ok else f(d)


# ======================================================================
# blocks -> markdown / html
# ======================================================================
class Doc:
    def __init__(self):
        self.b: List[tuple] = []

    def h(self, level: int, text: str):
        self.b.append(("h", level, text))

    def p(self, text: str):
        self.b.append(("p", text))

    def bullets(self, items: Sequence[str]):
        self.b.append(("ul", list(items)))

    def table(self, header: Sequence[str], rows: Sequence[Sequence], note: str = ""):
        self.b.append(("table", list(header), [list(r) for r in rows], note))

    def svg(self, svg: str, caption: str = ""):
        self.b.append(("svg", svg, caption))

    def md(self) -> str:
        out = []
        for blk in self.b:
            k = blk[0]
            if k == "h":
                out += ["#" * blk[1] + " " + blk[2], ""]
            elif k == "p":
                out += [blk[1], ""]
            elif k == "ul":
                out += [f"- {x}" for x in blk[1]] + [""]
            elif k == "table":
                hd, rows, note = blk[1], blk[2], blk[3]
                out.append("| " + " | ".join(str(x) for x in hd) + " |")
                out.append("|" + "|".join("---" for _ in hd) + "|")
                for r in rows:
                    out.append("| " + " | ".join(str(x).replace("|", "/") for x in r) + " |")
                out.append("")
                if note:
                    out += [f"_{note}_", ""]
            elif k == "svg":
                if blk[2]:
                    out += [f"_(chart in ATLAS.html: {blk[2]})_", ""]
        return "\n".join(out)

    def html(self, title: str) -> str:
        body = []
        for blk in self.b:
            k = blk[0]
            if k == "h":
                lv = min(blk[1], 4)
                body.append(f"<h{lv}>{html.escape(blk[2])}</h{lv}>")
            elif k == "p":
                body.append(f"<p>{_inline(blk[1])}</p>")
            elif k == "ul":
                body.append("<ul>" + "".join(f"<li>{_inline(x)}</li>" for x in blk[1]) + "</ul>")
            elif k == "table":
                hd, rows, note = blk[1], blk[2], blk[3]
                t = ["<div class='tw'><table><thead><tr>" + "".join(f"<th>{html.escape(str(x))}</th>" for x in hd) +
                     "</tr></thead><tbody>"]
                for r in rows:
                    t.append("<tr>" + "".join(f"<td>{_inline(str(x))}</td>" for x in r) + "</tr>")
                t.append("</tbody></table></div>")
                if note:
                    t.append(f"<p class='note'>{_inline(note)}</p>")
                body.append("".join(t))
            elif k == "svg":
                body.append(f"<figure>{blk[1]}<figcaption>{html.escape(blk[2])}</figcaption></figure>")
        return HTML_HEAD.replace("{TITLE}", html.escape(title)) + "\n".join(body) + "</main></body></html>"


def _inline(s: str) -> str:
    s = html.escape(s)
    import re
    s = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"`(.+?)`", r"<code>\1</code>", s)
    return s


HTML_HEAD = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{TITLE}</title>
<style>
:root{color-scheme:light;--page:#f9f9f7;--surface:#fcfcfb;--ink:#0b0b0b;--ink2:#52514e;--muted:#898781;
--grid:#e1e0d9;--axis:#c3c2b7;--s1:#2a78d6;--s1band:#cde2fb;--border:rgba(11,11,11,0.10);--neg:#e34948;--mid:#f0efec}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){color-scheme:dark;--page:#0d0d0d;--surface:#1a1a19;
--ink:#f0efec;--ink2:#c3c2b7;--muted:#898781;--grid:#2c2c2a;--axis:#383835;--s1:#3987e5;--s1band:#1c3a5e;
--border:rgba(255,255,255,0.10);--neg:#e66767;--mid:#383835}}
:root[data-theme="dark"]{color-scheme:dark;--page:#0d0d0d;--surface:#1a1a19;--ink:#f0efec;--ink2:#c3c2b7;
--muted:#898781;--grid:#2c2c2a;--axis:#383835;--s1:#3987e5;--s1band:#1c3a5e;--border:rgba(255,255,255,0.10);
--neg:#e66767;--mid:#383835}
html,body{margin:0;background:var(--page);color:var(--ink);font:15px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}
main{max-width:1080px;margin:0 auto;padding:24px 16px 64px}
h1{font-size:26px;margin:0 0 4px}h2{font-size:20px;margin:36px 0 8px;border-top:1px solid var(--grid);padding-top:20px}
h3{font-size:16px;margin:22px 0 6px}h4{font-size:14px;margin:16px 0 4px;color:var(--ink2)}
p,li{color:var(--ink)}.note{color:var(--ink2);font-size:13px}code{font-size:13px}
.tw{overflow-x:auto;margin:8px 0 4px}table{border-collapse:collapse;font-size:13px;font-variant-numeric:tabular-nums;
background:var(--surface)}th,td{border-bottom:1px solid var(--grid);padding:4px 8px;text-align:left;white-space:nowrap}
th{color:var(--ink2);font-weight:600}figure{margin:12px 0;background:var(--surface);border:1px solid var(--border);
border-radius:8px;padding:12px;overflow-x:auto}figcaption{color:var(--ink2);font-size:13px;margin-top:6px}
svg text{fill:var(--ink2);font:11px system-ui,-apple-system,"Segoe UI",sans-serif}svg .t1{fill:var(--ink);font-weight:600}
svg .grid{stroke:var(--grid);stroke-width:1}svg .axis{stroke:var(--axis);stroke-width:1}
svg .line{stroke:var(--s1);stroke-width:2;fill:none}svg .band{stroke:var(--s1);stroke-width:4;stroke-linecap:round;opacity:.35}
svg .dot{fill:var(--s1);stroke:var(--surface);stroke-width:2}svg .bar{fill:var(--s1)}
svg .hm{fill:var(--cl)}svg .hm-na{fill:var(--mid)}svg .hm-ink{fill:var(--ink)}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]) svg .hm{fill:var(--cd)}}
:root[data-theme="dark"] svg .hm{fill:var(--cd)}
svg .ver{fill:none;stroke:var(--ink);stroke-width:2}
</style></head><body><main>
"""


# ======================================================================
# charts (inline SVG; hover = native <title> tooltips)
# ======================================================================
def _mix(a: str, b: str, t: float) -> str:
    a_ = [int(a[i:i + 2], 16) for i in (1, 3, 5)]
    b_ = [int(b[i:i + 2], 16) for i in (1, 3, 5)]
    c = [round(x + (y - x) * t) for x, y in zip(a_, b_)]
    return "#" + "".join(f"{v:02x}" for v in c)


def _lum(h: str) -> float:
    r, g, b = (int(h[i:i + 2], 16) / 255 for i in (1, 3, 5))
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)


def div_color(v: float, vmax: float, dark: bool) -> str:
    """Diverging: blue = more often than the baseline, red = less often, gray = no difference."""
    mid = "#383835" if dark else "#f0efec"
    pos = "#3987e5" if dark else "#2a78d6"
    neg = "#e66767" if dark else "#e34948"
    if not np.isfinite(v) or vmax <= 0:
        return mid
    t = min(1.0, abs(v) / vmax)
    return _mix(mid, pos if v > 0 else neg, t)


def svg_family_paths(fams: List[dict], kind: str) -> str:
    """Small multiples: each family's centre path (ATR units from C0), one panel each, one shared y scale."""
    if not fams:
        return ""
    n = len(fams)
    cols = 4 if n > 6 else 3
    rows = int(np.ceil(n / cols))
    W, H = 240, 170
    pad_l, pad_r, pad_t, pad_b = 34, 10, 34, 22
    allv = np.concatenate([np.asarray(f["centre_capped"], float) for f in fams])
    lo, hi = float(np.nanmin(allv)), float(np.nanmax(allv))
    lo, hi = min(lo, -0.5), max(hi, 0.5)
    span = hi - lo
    lo -= 0.08 * span
    hi += 0.08 * span
    out = [f"<svg viewBox='0 0 {cols * W} {rows * H}' width='{cols * W}' height='{rows * H}' role='img' "
           f"aria-label='centre paths of the {kind} families'>"]
    for i, f in enumerate(fams):
        ox, oy = (i % cols) * W, (i // cols) * H
        pw, ph = W - pad_l - pad_r, H - pad_t - pad_b
        y = lambda v: oy + pad_t + (hi - v) / (hi - lo) * ph
        v = np.asarray(f["centre_capped"], float)
        out.append(f"<text x='{ox + 6}' y='{oy + 14}' class='t1'>{html.escape(f['id'])} "
                   f"{f['share_discovery_sample'] * 100:.1f}%</text>")
        nm = f["name"] if len(f["name"]) <= 38 else f["name"][:36] + "..."
        out.append(f"<text x='{ox + 6}' y='{oy + 27}'>{html.escape(nm)}</text>")
        for tv in (np.ceil(lo), 0.0, np.floor(hi)):
            if lo <= tv <= hi:
                out.append(f"<line x1='{ox + pad_l}' x2='{ox + W - pad_r}' y1='{y(tv):.1f}' y2='{y(tv):.1f}' "
                           f"class='{'axis' if tv == 0 else 'grid'}'/>")
                out.append(f"<text x='{ox + pad_l - 4}' y='{y(tv) + 4:.1f}' text-anchor='end'>{tv:+.0f}</text>")
        if kind == "daily":
            xs = lambda s: ox + pad_l + s / 5.0 * pw
            pts = [(xs(0), y(0.0))]
            for s in range(5):
                hh, ll, cc = v[1 + 3 * s], v[2 + 3 * s], v[3 + 3 * s]
                out.append(f"<line x1='{xs(s + 1):.1f}' x2='{xs(s + 1):.1f}' y1='{y(hh):.1f}' y2='{y(ll):.1f}' class='band'>"
                           f"<title>session {s + 1}: high {hh:+.2f}, low {ll:+.2f}, close {cc:+.2f} ATR</title></line>")
                pts.append((xs(s + 1), y(cc)))
            out.append("<polyline class='line' points='" + " ".join(f"{a:.1f},{b:.1f}" for a, b in pts) + "'/>")
            for s, (a, b) in enumerate(pts[1:]):
                out.append(f"<circle cx='{a:.1f}' cy='{b:.1f}' r='4' class='dot'><title>close of session {s + 1}: "
                           f"{v[3 + 3 * s]:+.2f} ATR</title></circle>")
            out.append(f"<text x='{xs(0):.1f}' y='{oy + H - 6}' text-anchor='middle'>T0</text>")
            out.append(f"<text x='{xs(5):.1f}' y='{oy + H - 6}' text-anchor='middle'>S5</text>")
        else:
            xs = lambda k: ox + pad_l + k / 44.0 * pw
            pts = [(xs(k), y(v[k])) for k in range(45)]
            for s in range(1, 5):
                out.append(f"<line x1='{xs(9 * s - 0.5):.1f}' x2='{xs(9 * s - 0.5):.1f}' y1='{oy + pad_t}' "
                           f"y2='{oy + H - pad_b}' class='grid'/>")
            out.append("<polyline class='line' points='" + " ".join(f"{a:.1f},{b:.1f}" for a, b in pts) + "'>"
                       f"<title>{html.escape(f['id'])}: 9 checkpoints a session x 5 sessions (ATR from C0)</title></polyline>")
            out.append(f"<text x='{xs(0):.1f}' y='{oy + H - 6}'>S1</text><text x='{xs(44):.1f}' y='{oy + H - 6}' "
                       f"text-anchor='end'>S5 close</text>")
    out.append("</svg>")
    return "".join(out)


def svg_heatmap(title: str, M: np.ndarray, flags: np.ndarray, vmax: float, kind_unit=("prob", "share")) -> str:
    """9 states x 5 regimes, the difference from everything; a black ring = verified."""
    cw, ch = 74, 24
    lw, top = 150, 40
    Wd, Hd = lw + cw * 5 + 10, top + ch * 9 + 10
    out = [f"<svg viewBox='0 0 {Wd} {Hd}' width='{Wd}' height='{Hd}' role='img' aria-label='{html.escape(title)}'>",
           f"<text x='0' y='14' class='t1'>{html.escape(title)}</text>"]
    for r, nm in enumerate(PC.REGIMES):
        out.append(f"<text x='{lw + r * cw + cw / 2}' y='{top - 6}' text-anchor='middle'>{html.escape(PC.REGIME_TEXT[nm])}</text>")
    for s, st in enumerate(PC.CELL_STATES):
        out.append(f"<text x='{lw - 6}' y='{top + s * ch + 16}' text-anchor='end'>{st} {html.escape(PC.STATE_SHORT[st])}</text>")
        for r in range(5):
            v = M[s, r]
            x0, y0 = lw + r * cw, top + s * ch
            tip = f"{st} x {PC.REGIME_TEXT[PC.REGIMES[r]]}: " + (pp(v) if np.isfinite(v) else "insufficient support")
            if np.isfinite(v):
                cl, cd = div_color(v, vmax, False), div_color(v, vmax, True)
                ink = "#ffffff" if _lum(cl) < 0.35 else "#0b0b0b"
                inkd = "#ffffff" if _lum(cd) < 0.35 else "#0b0b0b"
                out.append(f"<rect x='{x0 + 1}' y='{y0 + 1}' width='{cw - 2}' height='{ch - 2}' rx='3' class='hm' "
                           f"style='--cl:{cl};--cd:{cd}'><title>{html.escape(tip)}</title></rect>")
                out.append(f"<text x='{x0 + cw / 2}' y='{y0 + 16}' text-anchor='middle' style='fill:{ink}'>"
                           f"{v * 100:+.1f}</text>")
                if flags[s, r]:
                    out.append(f"<rect x='{x0 + 2}' y='{y0 + 2}' width='{cw - 4}' height='{ch - 4}' rx='3' class='ver'/>")
            else:
                out.append(f"<rect x='{x0 + 1}' y='{y0 + 1}' width='{cw - 2}' height='{ch - 2}' rx='3' class='hm-na'>"
                           f"<title>{html.escape(tip)}</title></rect><text x='{x0 + cw / 2}' y='{y0 + 16}' "
                           f"text-anchor='middle'>-</text>")
    out.append("</svg>")
    return "".join(out)


def svg_bars(title: str, labels: Sequence[str], values: Sequence[float], los=None, his=None, w=520, h=190) -> str:
    n = len(values)
    pad_l, pad_b, pad_t = 40, 34, 26
    vmax = max([v for v in values if np.isfinite(v)] + ([x for x in (his or []) if np.isfinite(x)]) + [0.01])
    bw = (w - pad_l - 10) / n
    y = lambda v: pad_t + (1 - v / vmax) * (h - pad_t - pad_b)
    out = [f"<svg viewBox='0 0 {w} {h}' width='{w}' height='{h}' role='img' aria-label='{html.escape(title)}'>",
           f"<text x='0' y='14' class='t1'>{html.escape(title)}</text>",
           f"<line x1='{pad_l}' x2='{w - 10}' y1='{y(0):.1f}' y2='{y(0):.1f}' class='axis'/>"]
    for tv in np.linspace(0, vmax, 3)[1:]:
        out.append(f"<line x1='{pad_l}' x2='{w - 10}' y1='{y(tv):.1f}' y2='{y(tv):.1f}' class='grid'/>"
                   f"<text x='{pad_l - 4}' y='{y(tv) + 4:.1f}' text-anchor='end'>{tv * 100:.0f}%</text>")
    for i, (lab, v) in enumerate(zip(labels, values)):
        if not np.isfinite(v):
            continue
        x0 = pad_l + i * bw + 2
        tip = f"{lab}: {v * 100:.1f}%" + (f" [{los[i] * 100:.1f}%, {his[i] * 100:.1f}%]" if los is not None and np.isfinite(los[i]) else "")
        out.append(f"<rect x='{x0:.1f}' y='{y(v):.1f}' width='{max(bw - 4, 1):.1f}' height='{max(y(0) - y(v), 0):.1f}' "
                   f"rx='3' class='bar'><title>{html.escape(tip)}</title></rect>")
        out.append(f"<text x='{x0 + (bw - 4) / 2:.1f}' y='{h - pad_b + 14}' text-anchor='middle'>{html.escape(lab)}</text>")
    out.append("</svg>")
    return "".join(out)


# ======================================================================
# the report
# ======================================================================
def _read(p: Path) -> pd.DataFrame:
    return pd.read_parquet(p) if Path(p).exists() else pd.DataFrame()


def run_report(cdir: Path, run_dir: Path, D: dict, base: Path, decl_fp: str, log) -> dict:
    run_dir = Path(run_dir)
    adir = run_dir / "atlas"
    if not PC.read_json(adir / "DONE.json"):
        raise PC.PLError("the atlas stage has not finished for this run")
    B = PC.read_json(Path(cdir) / "BUILD_DONE.json", {}) or {}
    integ = PC.read_json(Path(cdir) / "integrity.json", {}) or {}
    bmeta = PC.read_json(Path(cdir) / "build_meta.json", {}) or {}
    S = PC.read_json(adir / "atlas_summary.json", {}) or {}
    fams = {ds: PC.read_json(run_dir / "families" / ds / "families.json", {}) or {} for ds in ("daily", "intraday")}
    L = _read(adir / "labels.parquet")
    T = _read(adir / "tests.parquet")
    st = {ds: _read(adir / ds / "stats.parquet") for ds in ("daily", "intraday")}
    meas = {ds: _read(adir / ds / "measures.parquet") for ds in ("daily", "intraday")}
    mtext = {}
    for ds in meas:
        for r in meas[ds].itertuples(index=False):
            mtext[r.measure] = (r.text, r.kind, r.unit)
    mi = {ds: PC.read_json(adir / ds / "mutual_information.json", {}) or {} for ds in ("daily", "intraday")}
    ov = PC.read_json(adir / "daily" / "overlap_check.json", {}) or {}
    amends = PC.amendments(base)
    A = D["atlas"]
    doc = Doc()
    title = "Behavioural Path Atlas - Phase 1"
    doc.h(1, title)
    doc.p(f"pathlab {PC.VERSION.split()[-1]} run {run_dir.name}, report built {dt.datetime.now():%Y-%m-%d %H:%M}. T0 from "
          f"{D['span']['t0_first']} to {D['span']['t0_last']}; discovery {D['span']['t0_first']} to {D['span']['discovery_last']}, "
          f"confirmation after a {D['span']['embargo_sessions']}-session gap to {D['span']['t0_last']}. Declaration "
          f"`{decl_fp}`" + ("" if not amends else f" (amended {len(amends)} time(s): " +
                             "; ".join(f"{a.get('old')} -> {a.get('new')}: {a.get('reason')}" for a in amends) + ")") + ".")
    # ---------------- verdict ----------------
    doc.h(2, "Verdict first")
    doc.bullets(verdict_lines(fams, mi, L, S, integ, ov, A))
    doc.p("Every number below comes from the tables in this run folder. A figure marked **verified** passed the 5% "
          "false-discovery control in 2020-2022 and its 95% interval excluded zero in the same direction in 2023-2026 "
          "with the families frozen. **hypothesis** = one period only; **inconclusive** = enough data, no clear "
          "difference; **insufficient** = too little data; **unstable** = flips sign in more than a third of its years or "
          "contradicts itself across periods. Associations, not causes.")
    # ---------------- coverage ----------------
    coverage_section(doc, B, integ, bmeta)
    # ---------------- families ----------------
    for ds in ("daily", "intraday"):
        families_section(doc, ds, fams[ds], L, st[ds])
    # ---------------- information ----------------
    mi_section(doc, mi, A)
    # ---------------- the atlas ----------------
    for ds in ("daily", "intraday"):
        atlas_tables(doc, ds, st[ds], L, mtext, fams[ds], adir)
    findings_section(doc, L, mtext)
    detail_section(doc, adir, st["daily"], mtext)
    intraday_detail(doc, st["intraday"], mtext)
    transitions_report(doc, adir, mtext)
    picks_report(doc, adir, mtext)
    validation_section(doc, integ, ov, S, A, D)
    limits_section(doc, B, fams, D)
    files_section(doc)
    (run_dir / "ATLAS.md").write_text(doc.md(), encoding="utf-8")
    (run_dir / "ATLAS.html").write_text(doc.html(title), encoding="utf-8")
    summ = {"version": PC.VERSION, "report": REPORT_VERSION, "run": run_dir.name, "declaration": decl_fp,
            "amendments": amends, "families": {ds: {k: fams[ds].get(k) for k in ("status", "k", "unit")} for ds in fams},
            "labels": S.get("labels"), "fdr": S.get("fdr"), "integrity": {k: integ.get(k) for k in ("status", "match_share", "comparable")},
            "overlap_check": {k: ov.get(k) for k in ("pass", "share_inside", "pairs")},
            "mutual_information": {ds: {p: ({k: mi[ds][p][k] for k in ("state", "regime", "cell")} if mi[ds].get(p, {}).get("ok") else None)
                                        for p in ("discovery", "confirmation", "all")} for ds in mi},
            "provenance": PC.provenance()}
    PC.write_json_atomic(summ, run_dir / "summary.json")
    PC.write_outputs_sha(run_dir)
    PC.ledger_append(base, {"event": "report", "run": run_dir.name, "declaration": decl_fp,
                            "labels": S.get("labels"), "families": summ["families"]})
    log(f"[report] {run_dir / 'ATLAS.html'} and ATLAS.md written; outputs.sha256 covers the run folder")
    return summ


def verdict_lines(fams, mi, L, S, integ, ov, A) -> List[str]:
    out = []
    for ds in ("daily", "intraday"):
        f = fams.get(ds) or {}
        stt = f.get("status")
        if stt == "families found":
            out.append(f"{ds.capitalize()} paths: **{f['k']} separated path families** (stable, reproduced in 2023-2026 "
                       f"and separated from their neighbours).")
        elif stt == "regions only":
            out.append(f"{ds.capitalize()} paths: **no separated families**; the paths form a continuum. They are described "
                       f"by **{f['k']} path regions** (a stable, reproduced partition of that continuum), not as distinct behaviours.")
        elif stt:
            out.append(f"{ds.capitalize()} paths: **{stt}** - cells are described by the path measures alone.")
        vs = L[(L["dataset"] == ds) & (L["baseline"] == "random walk")] if len(L) else pd.DataFrame()
        if len(vs):
            nv = int((vs["label"] == "verified").sum())
            out.append(f"   {nv} of {len(vs)} {ds} families / regions occur more or less often than in the random-walk "
                       f"version of the same stock-days, verified in both periods.")
    for ds in ("daily", "intraday"):
        m = mi.get(ds) or {}
        d_, c_ = m.get("discovery", {}), m.get("confirmation", {})
        if d_.get("ok") and c_.get("ok"):
            thr = 0.05 / 6
            for v in ("state", "regime"):
                pd_, pc_ = d_[v]["p_normal"], c_[v]["p_normal"]
                ok = pd_ < thr and pc_ < thr
                out.append(f"Does the {v} at T0 tell us about the {ds} path? **{'yes, in both periods' if ok else 'not shown'}**: "
                           f"{d_[v]['excess_bits']:.5f} bits beyond the null in 2020-2022 (z {d_[v]['z']:.1f}), "
                           f"{c_[v]['excess_bits']:.5f} in 2023-2026 (z {c_[v]['z']:.1f}).")
    if len(L):
        cells = L[L["baseline"] != "random walk"]
        vc = cells["label"].value_counts()
        out.append("Cell comparisons (" + f"{len(cells):,}): " + ", ".join(f"{k} {int(vc.get(k, 0)):,}" for k in
                                                                         ("verified", "hypothesis", "inconclusive", "unstable", "insufficient")) + ".")
    fd = (S.get("fdr") or {}).get("discovery") or {}
    if fd:
        out.append(f"False-discovery control: {fd.get('passed_fdr', 0):,} of {fd.get('tests', 0):,} discovery-period tests pass "
                   f"at 5%; about {fd.get('expected_false_among_passed', 0):g} of those are expected to be false - the "
                   f"confirmation period is what separates them.")
    out.append(f"Integrity: the picks' paths match tradelab's export on {pct(integ.get('match_share'), 2)} of "
               f"{integ.get('comparable', 0):,} comparable picks ({integ.get('status')}).")
    if ov:
        out.append(f"Overlap check (every 5th T0 per stock): {pct(ov.get('share_inside'))} of {ov.get('pairs')} estimates "
                   f"consistent -> {'PASS' if ov.get('pass') else 'FAIL'}.")
    return out


def coverage_section(doc: Doc, B: dict, integ: dict, bmeta: dict):
    doc.h(2, "Data and coverage")
    cov = B.get("coverage_by_year") or []
    if cov:
        doc.table(["year", "T0 rows", "cash-like out", "under 60 sessions out", "eligible", "complete windows",
                   "corporate-action suspects", "all 5 sessions in 3-minute bars", "D picks", "ENS picks"],
                  [[r["year"], f"{r['rows']:,}", f"{r['cash_like']:,}", f"{r['insufficient_history']:,}", f"{r['eligible']:,}",
                    f"{r['eligible_complete']:,}", f"{r['eligible_ca_suspect']:,}", f"{r['eligible_intraday_full']:,}",
                    f"{r['picks_D']:,}", f"{r['picks_ENS']:,}"] for r in cov],
                  "T0 rows = panel_oc stock-days in the span plus every pick. Eligible = in the panel, not cash-like, 60+ "
                  "sessions of bars. Complete = a bar on all five window sessions.")
    doc.bullets([f"Stocks: {B.get('stocks', 0):,} built, {B.get('eligible_stocks', 0):,} with eligible rows; "
                 f"{B.get('stocks_with_3m', 0):,} with a 3-minute file.",
                 f"3-minute sessions by the usable test: " + ", ".join(f"{k} {v:,}" for k, v in (B.get("sessions_3m_by_reason") or {}).items()),
                 f"Corporate actions: {B.get('ca_suspect_sessions', 0):,} suspect sessions from the cache's ok.json files; "
                 f"{B.get('ca_fallback_stocks', 0):,} stocks without a usable ok.json used the 35% move fallback.",
                 f"Breadth for the regime labels: {(bmeta.get('ctx') or {}).get('breadth_source', 'n/a')}.",
                 "Eligible rows by state at T0: " + ", ".join(f"{k} {v:,}" for k, v in (B.get("eligible_rows_by_state") or {}).items()),
                 "Eligible rows by regime at T0: " + ", ".join(f"{k} {v:,}" for k, v in (B.get("eligible_rows_by_regime") or {}).items())])


def families_section(doc: Doc, ds: str, f: dict, L: pd.DataFrame, st: pd.DataFrame):
    doc.h(2, f"Path families - {ds}")
    if not f:
        doc.p("Not run.")
        return
    if f.get("status") in ("no data", "too few rows"):
        doc.p(f"{f.get('status')}: discovery rows {f.get('rows_discovery', 0):,}, confirmation rows {f.get('rows_confirmation', 0):,}.")
        return
    pc = f.get("pca") or {}
    doc.p(f"{f.get('rows', 0):,} paths ({f.get('rows_discovery', 0):,} in the discovery period, {f.get('rows_confirmation', 0):,} "
          f"in the confirmation period); the search used a year-balanced sample of {f.get('sample_discovery', 0):,}. "
          f"{pc.get('components')} principal components keep {pct(pc.get('variance_kept'))} of the variation.")
    sc = f.get("scan") or []
    if sc:
        doc.table(["k", "stability ARI (mean / min)", "reproduced", "worst valley", "explains", "smallest group", "result"],
                  [[r["k"], f"{r['stability_mean_ari']:.3f} / {r['stability_min_ari']:.3f}", f"{r['families_reproduced']}/{r['k']}",
                    num(r.get("separation_worst_valley")), pct(r["explained"]), pct(r["smallest_share"], 2),
                    "families" if r.get("qualifies") else ("regions" if r.get("stable_reproduced") else "-")] for r in sc],
                  "Stable = mean ARI >= 0.75 over the date-block refits; reproduced = every centre found again in "
                  "2023-2026 within half its spread; separated = between every group and its nearest neighbour the "
                  "density dips to at most half the lower peak (worst valley <= 0.5; about 1 = no valley).")
    mm = f.get("multimodality_pcs") or []
    if mm:
        doc.p("Is there any separation at all along the main directions? " + "; ".join(
            f"component {m['pc']}: two-peak D {num(m.get('ashman_d'))}" for m in mm if m.get("ok")) +
              " (D >= 2 would mean two clean peaks).")
    if f.get("k") is None:
        doc.p(f"**{f.get('status')}**.")
        return
    rw = f.get("random_walk_at_k") or {}
    if rw:
        doc.p(f"The same search on the random-walk paths at k = {rw.get('k')}: worst valley {num(rw.get('separation_worst_valley'))}, "
              f"partition explains {pct(rw.get('explained'))}.")
    vs = L[(L["dataset"] == ds) & (L["baseline"] == "random walk")].set_index("measure") if len(L) else pd.DataFrame()
    pre = "fam:" if ds == "daily" else "ifam:"
    rows = []
    for g in f.get("families", []):
        key = pre + g["id"]
        r = vs.loc[key] if key in getattr(vs, "index", []) else None
        rows.append([g["id"], g["name"], pct(g["share_discovery_sample"]), num(g["valley_ratio"]), num(g["repro_ratio"]),
                     pct(g["gmm_agreement"], 0), g["method"],
                     dci(r["diff_disc"], r["lo_disc"], r["hi_disc"], "prob", "share") if r is not None else "n/a",
                     dci(r["diff_conf"], r["lo_conf"], r["hi_conf"], "prob", "share") if r is not None else "n/a",
                     r["label"] if r is not None else "n/a"])
    unit = "families" if f.get("unit") == "family" else "regions"
    doc.table(["id", "name (from the centre)", "share (2020-22 sample)", "valley ratio", "reproduction ratio",
               "mixture agreement", "found by", "vs random walk 2020-22", "vs random walk 2023-26", "label"], rows,
              f"Names follow the declared rules on each centre path; the data decides membership. 'vs random walk' = share "
              f"minus the share of the same stock-days' random-walk paths in that group.")
    doc.svg(svg_family_paths(f.get("families", []), ds),
            f"centre path of each {ds} {unit[:-1]} in ATR units from the T0 close (one shared scale; hover for values)")
    two = [s_ for s_ in f.get("subfamilies", []) if s_.get("two_peaks")]
    doc.p(f"Two peaks inside a group's 5-day close (a minority behaviour hiding in a group): "
          f"{', '.join(f.get('families')[s_['family']]['id'] for s_ in two) if two else 'none found'}.")


def mi_section(doc: Doc, mi: dict, A: dict):
    doc.h(2, "Do state and regime tell us anything?")
    doc.p("Mutual information between what was known at T0 and which group the path fell in, against a null: states "
          "shuffled among the stocks of the same date (keeps each date's market), regimes shifted in time (keeps their run "
          "lengths). Excess = observed minus the null's mean. The random-walk row shows how much survives when every "
          "session is replaced by a random other session of the same stock: that part comes from WHICH stocks are in a "
          "state, not from WHEN.")
    rows = []
    for ds in ("daily", "intraday"):
        m = mi.get(ds) or {}
        for p in ("discovery", "confirmation", "all", "random_walk_all"):
            r = m.get(p) or {}
            if not r.get("ok"):
                continue
            rows.append([ds, p.replace("_", " "), f"{r['n']:,}", f"{r['state']['mi_bits']:.5f}", f"{r['state']['excess_bits']:+.5f}",
                         num(r["state"]["z"], 1), f"{r['regime']['mi_bits']:.5f}", f"{r['regime']['excess_bits']:+.5f}",
                         num(r["regime"]["z"], 1), f"{r['cell']['excess_bits']:+.5f}", num(r["cell"]["z"], 1)])
    if rows:
        doc.table(["paths", "period", "rows", "state MI (bits)", "state excess", "z", "regime MI", "regime excess", "z",
                   "cell excess", "z"], rows,
                  f"Outcome: {(mi.get('daily') or {}).get('outcome')} (daily); {(mi.get('intraday') or {}).get('outcome')} (intraday). "
                  f"{A['mi_permutations']} shuffles / shifts each. Present = one-sided p under 0.05/6 in both periods.")


def _stat(st: pd.DataFrame, period: str, measure: str) -> pd.DataFrame:
    if not len(st):
        return pd.DataFrame()
    return st[(st["period"] == period) & (st["measure"] == measure)].set_index("group")


def atlas_tables(doc: Doc, ds: str, st: pd.DataFrame, L: pd.DataFrame, mtext: dict, f: dict, adir: Path):
    doc.h(2, f"The atlas - {ds} paths, 2020-2026")
    if not len(st):
        doc.p("No rows.")
        return
    sup = _read(adir / ds / "support.parquet").set_index("group")
    neff = _read(adir / ds / "n_eff.parquet")
    neff = neff.set_index("group")["n_eff"] if len(neff) else pd.Series(dtype=float)
    keys = (["r5_pos", "r5_a", "mfe_a", "mae_a", "up_first_a1", "rec_d1_endup", "r5o_net"] if ds == "daily" else
            ["iup_first_a1", "m30_a", "rej_up", "rej_dn", "hif1", "mdown_aup1"])
    cols = [mtext.get(k, (k, "mean", ""))[0] for k in keys]
    for ri, rg in enumerate(PC.REGIMES):
        doc.h(3, f"{PC.REGIME_TEXT[rg]} ({ds})")
        rows = []
        for si in range(len(PC.CELL_STATES)):
            g = si * len(PC.REGIMES) + ri
            s_ = sup.loc[g] if g in sup.index else None
            row = [PA.group_text(g).split(" x ")[0], f"{int(s_['observations']):,}" if s_ is not None else 0,
                   f"{int(s_['dates']):,}" if s_ is not None else 0, f"{int(s_['stocks']):,}" if s_ is not None else 0,
                   num(neff.get(g, np.nan), 0)]
            described = bool(s_["supported_all"]) if s_ is not None else False
            for k in keys:
                x = _stat(st, "all", k)
                if not described or g not in x.index:
                    row.append("insufficient" if not described else "n/a")
                    continue
                kind, unit = mtext.get(k, ("", "mean", ""))[1:]
                row.append(ci(x.loc[g, "value"], x.loc[g, "lo"], x.loc[g, "hi"], kind, unit))
            rows.append(row)
        doc.table(["state at T0", "observations", "dates", "stocks", "effective n"] + cols, rows)
    # family odds heatmaps: difference from everything
    if f and f.get("k"):
        pre = "fam:" if ds == "daily" else "ifam:"
        allg = _stat(st, "all", "_support")
        Lc = L[(L["dataset"] == ds) & (L["baseline"] == "everything")] if len(L) else pd.DataFrame()
        diffs = []
        for g_ in f.get("families", []):
            x = _stat(st, "all", pre + g_["id"])
            if not len(x):
                continue
            base = x.loc[PA.G_ALL, "value"]
            M = np.full((9, 5), np.nan)
            V = np.zeros((9, 5), bool)
            for si in range(9):
                for ri in range(5):
                    g = si * 5 + ri
                    if g in x.index and g in allg.index and bool(allg.loc[g, "supported"]):
                        M[si, ri] = x.loc[g, "value"] - base
                    if len(Lc):
                        hit = Lc[(Lc["group"] == g) & (Lc["measure"] == pre + g_["id"])]
                        V[si, ri] = bool(len(hit) and hit["label"].iloc[0] == "verified")
            diffs.append((g_, M, V))
        if diffs:
            vmax = np.nanmax([np.nanmax(np.abs(M)) if np.isfinite(M).any() else 0 for _, M, _ in diffs]) or 0.01
            doc.h(3, f"Where each {ds} {'family' if f.get('unit') == 'family' else 'region'} is more or less common")
            doc.p("Each cell: the group's share in that state x regime minus its share in everything (percentage points, "
                  "2020-2026). Blue = more often, red = less often, a ring = verified against everything. '-' = below the "
                  "minimum support.")
            for g_, M, V in diffs:
                doc.svg(svg_heatmap(f"{g_['id']} {g_['name']} (overall {pct(_stat(st, 'all', pre + g_['id']).loc[PA.G_ALL, 'value'])})",
                                    M, V, float(vmax)), f"{g_['id']}: share by cell minus overall share")


def findings_section(doc: Doc, L: pd.DataFrame, mtext: dict):
    doc.h(2, "Verified findings")
    if not len(L):
        doc.p("No tests.")
        return
    X = L[(L["label"] == "verified")].copy()
    X["absd"] = X["diff_conf"].abs()
    X = X.sort_values(["dataset", "absd"], ascending=[True, False])
    if not len(X):
        doc.p("None. Nothing passed the false-discovery control in 2020-2022 and held in 2023-2026.")
    else:
        rows = []
        for r in X.head(150).itertuples(index=False):
            t_, kind, unit = mtext.get(r.measure, (r.measure, "mean", ""))
            rows.append([r.dataset, r.group_text, t_, r.baseline, val(r.value_all, kind, unit),
                         dci(r.diff_disc, r.lo_disc, r.hi_disc, kind, unit), dci(r.diff_conf, r.lo_conf, r.hi_conf, kind, unit),
                         f"{r.years_flipped}/{r.years_supported}"])
        doc.table(["paths", "group", "measure", "against", "value 2020-26", "difference 2020-22 [95%]",
                   "difference 2023-26 [95%]", "years against the sign"], rows,
                  f"{len(X):,} verified" + (" (first 150 shown; all in labels.csv)" if len(X) > 150 else "") +
                  ". A strong effect in one state also shifts the 'everything' and 'same regime' baselines, so small "
                  "opposite differences in the other states are its mirror image, not separate findings.")
    H = L[L["label"] == "hypothesis"].sort_values("q_disc")
    doc.h(3, "Hypotheses (one period only)")
    if len(H):
        rows = []
        for r in H.head(40).itertuples(index=False):
            t_, kind, unit = mtext.get(r.measure, (r.measure, "mean", ""))
            rows.append([r.dataset, r.group_text, t_, r.baseline, dci(r.diff_disc, r.lo_disc, r.hi_disc, kind, unit),
                         dci(r.diff_conf, r.lo_conf, r.hi_conf, kind, unit)])
        doc.table(["paths", "group", "measure", "against", "2020-22", "2023-26"], rows,
                  f"{len(H):,} hypotheses (first 40 by discovery q-value). Not findings: candidates for the forward test only.")
    else:
        doc.p("None.")
    U = L[L["label"] == "unstable"]
    doc.p(f"Unstable: {len(U):,} (flip sign across years or contradict each other across periods; listed in labels.csv).")


def detail_section(doc: Doc, adir: Path, st: pd.DataFrame, mtext: dict):
    doc.h(2, "Daily paths in detail (margins)")
    if not len(st):
        return
    Q = _read(adir / "daily" / "quantiles.parquet")
    if len(Q):
        doc.h(3, "Distributions (ATR units from C0, 2020-2026)")
        rows = []
        for g in [PA.G_ALL] + [PA.g_regime(r) for r in range(5)] + [PA.g_state(s) for s in range(9)]:
            q = Q[Q["group"] == g]
            if not len(q):
                continue
            for m in ("r5_a", "mfe_a", "mae_a"):
                qq = q[q["measure"] == m].set_index("q")
                if not len(qq) or qq["n"].iloc[0] == 0:
                    continue
                rows.append([PA.group_text(g), {"r5_a": "5-day close", "mfe_a": "MFE", "mae_a": "MAE"}[m]] +
                            [f"{qq.loc[q_, 'value']:+.2f} [{qq.loc[q_, 'lo']:+.2f}, {qq.loc[q_, 'hi']:+.2f}]"
                             for q_ in (0.05, 0.25, 0.5, 0.75, 0.95) if q_ in qq.index])
        doc.table(["group", "measure", "5th", "25th", "median", "75th", "95th"], rows,
                  "Intervals: the bootstrap distribution of each group's CDF on a 0.1 ATR grid, inverted at each quantile.")
    doc.h(3, "Timing of the window's high and low (everything)")
    hi = [_stat(st, "all", f"high_s{s}") for s in range(1, 6)]
    lo = [_stat(st, "all", f"low_s{s}") for s in range(1, 6)]
    if all(len(x) for x in hi + lo):
        g = PA.G_ALL
        doc.svg(svg_bars("Session of the window's high", [f"S{s}" for s in range(1, 6)], [x.loc[g, "value"] for x in hi],
                         [x.loc[g, "lo"] for x in hi], [x.loc[g, "hi"] for x in hi]), "share of paths whose 5-day high came in each session")
        doc.svg(svg_bars("Session of the window's low", [f"S{s}" for s in range(1, 6)], [x.loc[g, "value"] for x in lo],
                         [x.loc[g, "lo"] for x in lo], [x.loc[g, "hi"] for x in lo]), "share of paths whose 5-day low came in each session")
    doc.h(3, "Excursions, order, recovery, continuation by state (all regimes)")
    keys = ["tu_a1", "td_a1", "tu_a2", "td_a2", "ord_a1_1:tie", "up_first_a1", "rec_d1_backc0", "rec_d1_toup1",
            "rec_d2_endup", "cont_up", "rev_up", "cont_dn", "rev_dn"]
    rows = []
    for g in [PA.G_ALL] + [PA.g_state(s) for s in range(9)]:
        row = [PA.group_text(g)]
        for k in keys:
            x = _stat(st, "all", k)
            kind, unit = mtext.get(k, ("", "prob", "share"))[1:]
            row.append(val(x.loc[g, "value"], kind, unit) if g in x.index else "n/a")
        rows.append(row)
    doc.table(["group"] + [mtext.get(k, (k,))[0] for k in keys], rows, "Point estimates; intervals for every cell are in "
              "atlas/daily/stats.csv. Daily resolution cannot order two levels reached in the same session (the tie column); "
              "the 3-minute atlas resolves most of them.")


def intraday_detail(doc: Doc, st: pd.DataFrame, mtext: dict):
    doc.h(2, "Intraday detail (3-minute bars)")
    if not len(st):
        doc.p("No intraday rows.")
        return
    keys = ["m15_a", "m30_a", "m60_a", "r60_a", "drive_up", "drive_dn", "rej_up", "rej_dn", "hif1", "mdown_aup1",
            "mup_adown1", "iup_first_a1", "iord_a1_1:tie", "itu_a1_min", "itd_a1_min"]
    rows = []
    for g in [PA.G_ALL] + [PA.g_regime(r) for r in range(5)] + [PA.g_state(s) for s in range(9)]:
        row = [PA.group_text(g)]
        for k in keys:
            x = _stat(st, "all", k)
            kind, unit = mtext.get(k, ("", "mean", ""))[1:]
            row.append(val(x.loc[g, "value"], kind, unit) if g in x.index else "n/a")
        rows.append(row)
    doc.table(["group"] + [mtext.get(k, (k,))[0] for k in keys], rows)
    hs = [_stat(st, "all", f"ihigh_t{h:02d}") for h in range(13)]
    ls = [_stat(st, "all", f"ilow_t{h:02d}") for h in range(13)]
    if all(len(x) for x in hs + ls):
        labs = []
        for h in range(13):
            a = 9 * 60 + 15 + 30 * h
            labs.append(f"{a // 60}:{a % 60:02d}")
        g = PA.G_ALL
        doc.svg(svg_bars("Time of day of the window's high", labs, [x.loc[g, "value"] for x in hs], w=760),
                "half-hour of the day in which the 5-session high fell (all sessions pooled)")
        doc.svg(svg_bars("Time of day of the window's low", labs, [x.loc[g, "value"] for x in ls], w=760),
                "half-hour of the day in which the 5-session low fell")


def transitions_report(doc: Doc, adir: Path, mtext: dict):
    doc.h(2, "Transitions inside the window (description only)")
    T = _read(adir / "daily" / "transitions_state.parquet")
    if len(T):
        a = T[(T["regime"] == "all") & (T["state_t0"] == T["state_s5"])]
        doc.p("Share of paths whose tl_state state at the session-5 close equals the state at T0 (all regimes): " +
              ", ".join(f"{r.state_t0} {r.share * 100:.0f}%" for r in a.itertuples(index=False)) + ".")
    Q = _read(adir / "daily" / "transitions_sequences.parquet")
    if len(Q):
        rows = [[r.state_t0, r.sequence, f"{r.n:,}", pct(r.share)] for r in
                Q.sort_values(["state_t0", "n"], ascending=[True, False]).groupby("state_t0").head(4).itertuples(index=False)]
        doc.table(["state at T0", "state sequence over the window (repeats collapsed)", "paths", "share"], rows)
    V = _read(adir / "daily" / "vs_random_walk.parquet")
    if len(V):
        x = V[(V["period"] == "all") & (V["group"] == PA.G_ALL) & V["measure"].isin(["sq_dsr", "sq_ce", "sq_brc", "sq_ree", "all_up", "all_down"])]
        rows = [[mtext.get(r.measure, (r.measure,))[0], pct(r.real), pct(r.null), dci(r.diff, r.lo, r.hi, "prob", "share")]
                for r in x.itertuples(index=False)]
        if rows:
            doc.table(["sequence", "real paths", "random-walk paths", "difference [95%]"], rows,
                      "A sequence counts as behaviour only where it occurs more often than in the random-walk version; "
                      "otherwise it is what chance produces.")
    R = _read(adir / "daily" / "transitions_regime.parquet")
    if len(R):
        doc.table(["regime at T0", "regime by session 5", "paths", "mean 5-day close (ATR)", "5-day close up", "mean MFE", "mean MAE"],
                  [[r.regime_t0, r.regime_change, f"{r.n:,}", num(r.r5_a, 2, True), pct(r.r5_pos), num(r.mfe_a), num(r.mae_a, 2, True)]
                   for r in R.itertuples(index=False)],
                  "The regime change is observed after T0 (it explains what happened; it is never a classifier).")


def picks_report(doc: Doc, adir: Path, mtext: dict):
    doc.h(2, "BigMove's picks against the universe (descriptive)")
    rows = []
    for ds in ("daily", "intraday"):
        P = _read(adir / ds / "picks.parquet")
        for r in P.itertuples(index=False):
            t_, kind, unit = mtext.get(r.measure, (r.measure, "mean", ""))
            rows.append([ds, r.picks, t_, f"{r.n_picks:,}", ci(r.value, r.lo, r.hi, kind, unit),
                         dci(r.vs_same_day_same_cell, r.vs_lo, r.vs_hi, kind, unit)])
    if rows:
        doc.table(["paths", "picks", "measure", "picks", "picks' value [95%]", "vs same-day same-cell non-picks [95%]"], rows,
                  "What the model adds beyond state and regime, measured on the same dates and cells. No labels here: "
                  "the picks are judged by the forward paper test, not by this table.")


def validation_section(doc: Doc, integ: dict, ov: dict, S: dict, A: dict, D: dict):
    doc.h(2, "Validation")
    fdr = S.get("fdr") or {}
    doc.bullets([
        f"Point in time: states (tl_state) and regimes (tl_context) use bars up to the T0 close only; path values use only "
        f"sessions after T0. pathlab's test suite scrambles every bar after T0 and checks that every T0 value is unchanged.",
        f"Overlapping windows: intervals from circular blocks of {A['boot_block']} consecutive T0 dates, all stocks of a "
        f"drawn date together, {A['boot_B']:,} resamples, seed {A['boot_seed']}. Non-overlapping check: "
        f"{pct(ov.get('share_inside'))} of {ov.get('pairs')} estimates inside the every-5th-T0 sample's interval "
        f"(need {pct(ov.get('required'), 0)}) -> {'PASS' if ov.get('pass') else 'FAIL'}; median interval width ratio "
        f"{num(ov.get('median_interval_width_ratio'))} ({ov.get('note', '')}).",
        "Many comparisons: Benjamini-Hochberg 5% over every test of a period: " + "; ".join(
            f"{k}: {v['passed_fdr']:,} of {v['tests']:,} pass, about {v['expected_false_among_passed']:g} expected false"
            for k, v in fdr.items()) + ".",
        f"Walk-forward: families fitted on 2020-2022 only and frozen; labels need the confirmation period "
        f"(after a {D['span']['embargo_sessions']}-session gap) to agree.",
        f"Minimum support: described with {A['min_dates']} dates and {A['min_obs']:,} paths over 2020-2026 (intraday "
        f"{A['intraday_min_dates']} / {A['intraday_min_obs']}); labelled only with {A['period_min_dates']} dates, "
        f"{A['period_min_obs']} paths and {A['period_min_stretches']} separate 10-session stretches in EACH period "
        f"(intraday {A['intraday_period_min_dates']} / {A['intraday_period_min_obs']} / {A['intraday_period_min_stretches']}).",
        f"Integrity against tradelab's export: {integ.get('matching', 0):,} of {integ.get('comparable', 0):,} comparable "
        f"picks match ({pct(integ.get('match_share'), 2)}; required {pct(integ.get('required'), 1)}).",
        "Absent world from your own data: the random-walk version of every path goes through the same code. What state or "
        "regime information survives there comes from which stocks sit in a state (composition), not from timing.",
    ])


def limits_section(doc: Doc, B: dict, fams: dict, D: dict):
    doc.h(2, "Limitations and open questions")
    doc.bullets([
        "Survivorship: stocks delisted before the cache was built are missing, so paths that ended in delisting are "
        "under-represented (likely fewer persistent declines - an inference, not measured).",
        "No AMFI lists: liquidity tiers (60-session median turnover at T0) stand in for market-cap segments.",
        "3-minute bars start 2021-10-01 and cover only the stocks with a 3-minute file; the intraday atlas is a subset, and "
        "covered stocks may differ from the rest.",
        "Breadth counts the cached survivors, not NSE's official advance/decline; the regime labels carry this.",
        "States and regimes are research defaults (declared 24-25 Oct); the atlas tests whether they carry information, it "
        "does not assume it.",
        "Families from k-means are groups of similar shapes; 'separated' requires two modes between neighbours. Regions "
        "are a partition of a continuum and must not be read as distinct behaviours.",
        "Nothing here is a trading rule. Phase 2 (what predicts a path) does not start until this atlas is reviewed.",
    ])


def files_section(doc: Doc):
    doc.h(2, "Files in this run")
    doc.table(["file", "what it holds"], [
        ["atlas/labels.csv", "every comparison with its discovery, confirmation and all-period values and its label"],
        ["atlas/tests.csv", "every test: difference, interval, p, q, false-discovery pass"],
        ["atlas/daily/stats.csv, atlas/intraday/stats.csv", "every measure x group x period: value, 95% interval, n, dates"],
        ["atlas/*/support.csv, n_eff.csv", "observations, dates, stocks, effective sample size per group"],
        ["atlas/daily/quantiles.csv, family_quantiles.csv", "distribution quantiles (with intervals) and inside each family"],
        ["atlas/*/years.csv, tiers.csv", "year-by-year and liquidity-tier values with intervals"],
        ["atlas/*/vs_random_walk.csv", "every measure against its random-walk version"],
        ["atlas/*/mutual_information.json", "the headline information tests"],
        ["atlas/daily/transitions_*.csv", "state transitions, sequences, regime changes"],
        ["atlas/*/picks.csv", "D and ENS picks against the universe"],
        ["families/*/families.json, k_scan_table.csv", "the family search, chosen k, centres, names, checks"],
        ["audit/audit.md", "what the audit found"], ["summary.json, outputs.sha256", "the run in one file; every file's hash"],
    ])
