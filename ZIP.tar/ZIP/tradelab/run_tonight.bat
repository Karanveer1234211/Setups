@echo off
rem run_tonight.bat - tradelab v1.3.1: the whole evening in ONE double-click. It replaces pressing Run Now, then
rem run_pick_meta.bat, then run_watch.bat:
rem   1  Run Now exactly as you double-click it: bigmove_deploy\run_now.bat, unchanged, started from its own folder
rem      in a child cmd - nothing inside it can end this script
rem   2  pick_meta: publish the cards (every recorded day still without one) and score the tracker - the commands of
rem      open_close\run_pick_meta.bat, in the same environment
rem   3  tradelab: the watch page for tonight and for every recorded day still without one; opens tonight's page
rem Every step runs even when an earlier one failed: each works only on what production has already recorded, so a
rem failed or partial Run Now gives at worst nothing new - never a wrong card or page. RESULT names each failed step.
rem Start it when you would press Run Now, never while another run is going. If Run Now asks for a key at its end,
rem press it once and the rest carries on.
rem Nothing in bigmove_deploy is changed; tradelab writes only under TRADELAB_OUT.
rem Task Scheduler (no clicks): program run_tonight.bat, argument  auto  - no pause, no browser, and Run Now gets no
rem keyboard, so a prompt inside it fails at once instead of waiting all night.
rem Every run adds one line to TRADELAB_OUT\tonight_log.txt: when, and each step's exit code.
setlocal
set "BIGMOVE_DIR=C:\Users\karanvsi\PyCharmMiscProject\bigmove_deploy"
set "TN_RUN_NOW=%BIGMOVE_DIR%\run_now.bat"
set "TN_TL_DIR=%~dp0"
set "TN_AUTO="
if /i "%~1"=="auto" set "TN_AUTO=1"
set "TN_FAILED="
set "TN_RC1=skipped"
set "TN_RC2=skipped"
set "TN_RC3=skipped"
title tonight - Run Now, pick_meta, tradelab

rem where tradelab writes - read from env_tradelab.bat in a scope of its own, so Run Now starts in a clean environment
setlocal
call "%TN_TL_DIR%env_tradelab.bat" >nul
endlocal & set "TN_OUT=%TRADELAB_OUT%"
if "%TN_OUT%"=="" set "TN_OUT=C:\QuantData\tradelab"
if not exist "%TN_OUT%" mkdir "%TN_OUT%"

echo.
echo   ==== STEP 1 of 3: Run Now - started %DATE% %TIME% ====
if exist "%TN_RUN_NOW%" goto :run_now
echo   NOT FOUND: %TN_RUN_NOW%
echo   Edit TN_RUN_NOW at the top of run_tonight.bat: the file you double-click as Run Now.
set "TN_RC1=9"
goto :step2
:run_now
for %%I in ("%TN_RUN_NOW%") do set "TN_RUN_NOW_DIR=%%~dpI"
pushd "%TN_RUN_NOW_DIR%"
if defined TN_AUTO goto :run_now_auto
cmd /c ""%TN_RUN_NOW%""
set "TN_RC1=%ERRORLEVEL%"
popd
goto :step2
:run_now_auto
cmd /c ""%TN_RUN_NOW%"" <nul
set "TN_RC1=%ERRORLEVEL%"
popd

:step2
if not "%TN_RC1%"=="0" set "TN_FAILED=%TN_FAILED% [step 1 Run Now: code %TN_RC1%]"
echo.
echo   ==== STEP 2 of 3: pick_meta - publish the cards, score the tracker - %TIME% ====
setlocal
call "%BIGMOVE_DIR%\env_daily.bat"
if "%CACHE_DAILY_ROOT%"=="" goto :pm_noenv
pushd "%BIGMOVE_DIR%\open_close"
set "PYTHONPATH=%BIGMOVE_DIR%"
python pick_meta.py publish --root "%CACHE_DAILY_ROOT%" --all-missing
set "TN_R=%ERRORLEVEL%"
python pick_meta.py score --root "%CACHE_DAILY_ROOT%"
if "%TN_R%"=="0" set "TN_R=%ERRORLEVEL%"
popd
goto :pm_done
:pm_noenv
echo   CACHE_DAILY_ROOT is empty after env_daily.bat - pick_meta skipped
set "TN_R=9"
:pm_done
endlocal & set "TN_RC2=%TN_R%"
if not "%TN_RC2%"=="0" set "TN_FAILED=%TN_FAILED% [step 2 pick_meta: code %TN_RC2%]"

echo.
echo   ==== STEP 3 of 3: tradelab - the watch page - %TIME% ====
setlocal
call "%TN_TL_DIR%env_tradelab.bat"
if "%CACHE_DAILY_ROOT%"=="" goto :tl_noenv
pushd "%TN_TL_DIR%"
python tl_watch.py --root "%CACHE_DAILY_ROOT%" --all-missing
set "TN_R=%ERRORLEVEL%"
popd
goto :tl_done
:tl_noenv
echo   CACHE_DAILY_ROOT is empty after env_tradelab.bat - the watch page skipped
set "TN_R=9"
:tl_done
endlocal & set "TN_RC3=%TN_R%"
if not "%TN_RC3%"=="0" set "TN_FAILED=%TN_FAILED% [step 3 tl_watch: code %TN_RC3%]"
if not defined TN_AUTO if "%TN_RC3%"=="0" call :open_latest

echo.
if defined TN_FAILED goto :result_failed
echo   RESULT: OK - Run Now, pick_meta's cards and the watch page are done
echo   Pages: %TN_OUT%\watch
set "TN_RC=0"
goto :result_log
:result_failed
echo   RESULT: FAILED at%TN_FAILED%
echo   Read that step's own lines above. The steps after it still ran on what production had already recorded.
set "TN_RC=1"
:result_log
>>"%TN_OUT%\tonight_log.txt" echo %DATE% %TIME%  run_now=%TN_RC1%  pick_meta=%TN_RC2%  tl_watch=%TN_RC3%%TN_FAILED%
if not defined TN_AUTO pause
endlocal & exit /b %TN_RC%

:open_latest
for /f "delims=" %%F in ('dir /b /o-n "%TN_OUT%\watch\WATCH_*.html" 2^>nul') do (
    start "" "%TN_OUT%\watch\%%F"
    goto :eof
)
goto :eof
