"""
tl_backtest.py - tradelab v1.3.1: run a strategy on the frozen engines' picks and compare it with the plan.

    python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --strategy strategies\\scale_20_80_vwap.py
        [--compare auto | strategies\\open6.py]   auto = the plan, run on the same picks and the same clock
        [--engines D ENS] [--ranks 1-3] [--from 2021-10-01] [--to 2026-09-15]   (override the strategy's picks)
        [--capital 1000000] [--no-portfolio] [--timeline D-20240425-2,ENS-20250102-1]
        [--tag "what I am trying"] [--declare "PASS if the paired difference's lower bound > 0"]
        [--list-names]    print every value / function a rule can use, and exit
        [--context auto|full|saved|indices|none]   v1.1 market context (default auto: the saved copy, else build once)

What it reports (report.md, summary.json):
  - per pick slot: the strategy's mean net (bp, after costs, measured on the trade's full target size so an
    unfilled leg counts as cash), the plan's mean on the SAME picks, and the paired difference - each with a 95%
    circular block bootstrap over signal days (blocks of 10, 2,000 resamples, seed 7) and a verdict
    BETTER / WORSE / NOT SHOWN for the difference;
  - win rates, how often each leg filled, exit reasons, MFE / MAE, by year / engine / rank;
  - the money view (unless --no-portfolio): both through one account with the strategy's sizing - CAGR, worst
    drawdown with dates, Sharpe, exposure, skipped trades, and the paired difference of daily returns.
Every run is logged in <out>\\tradelab_ledger.jsonl BEFORE it starts (with --declare: your decision rule) and again
with its result. The report says how many backtests the ledger holds: every extra variant you try on the same
years makes a 'BETTER' easier to get by luck. A result here is exploratory until a declared rule passes on
trades it has not seen (the forward paper ledger).

Writes <out>\\backtest\\TLB_YYYYMMDD_NNN\\: trades, fills, trade_days (.csv + .parquet), portfolio_daily.csv,
portfolio_trades.csv, timelines\\<trade>.csv (with --timeline), the strategy files, report.md, summary.json,
outputs.sha256; v1.1: context_breakdown.csv (the paired difference by the market at the pick), DATA_DICTIONARY.md,
data_dictionary.csv. Strategies may use the market at the pick as pick attributes (filter: "pick_day_small_ret > -0.01")
and the index values in rules (small_prev_ret, vix, regime_up, ...): python tl_backtest.py --list-names.
v1.3.1: with the market context on, every pick also carries the stock's state at the signal-day close (pre_state_*,
tl_state) in trades.csv, and context_breakdown.csv / the report add the paired difference by that state, its phase,
confidence, event, S05 overextension and the stock's volatility (about a minute more for a thousand stocks).
"""
from __future__ import annotations

import argparse
import copy
import json
import shutil
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from tl_common import (BOOT, StopRun, TLError, VERSION, bootstrap_daily, bootstrap_mean_by_day, fmt_bp,
                       ledger_append, ledger_read, new_run_dir, out_base, parse_ranks, provenance, require_root, say,
                       sha256_text, verdict_from_interval, write_outputs_sha, write_table)
import tl_data as D
import tl_engine as E
import tl_rules as R
import tl_context as CX
import tl_state as ST
import tl_dictionary as DD
import tl_research as RS
from tl_portfolio import run_portfolio
from tl_run import Workspace, fills_frame, path_frame

TOOL = "tl_backtest v1.3.1"
EVALUABLE_S = ("ok", "not_entered", "filtered")


def parse_args(argv):
    ap = argparse.ArgumentParser(description="tradelab backtest: a strategy on the frozen picks, paired with the plan")
    ap.add_argument("--root")
    ap.add_argument("--pm-run")
    ap.add_argument("--strategy")
    ap.add_argument("--compare", default="auto")
    ap.add_argument("--engines", nargs="+", default=None)
    ap.add_argument("--ranks", default=None)
    ap.add_argument("--from", dest="d_from", default=None)
    ap.add_argument("--to", dest="d_to", default=None)
    ap.add_argument("--capital", type=float, default=None)
    ap.add_argument("--no-portfolio", action="store_true")
    ap.add_argument("--timeline", default="")
    ap.add_argument("--tag", default="")
    ap.add_argument("--declare", default="")
    ap.add_argument("--list-names", action="store_true")
    ap.add_argument("--values", default="", help="extra values recorded in the timelines, e.g. vwap,rvol,clv,D_rsi14")
    ap.add_argument("--panel", default="panel_oc")
    ap.add_argument("--out", default=None)
    ap.add_argument("--stage-e-any", action="store_true")
    ap.add_argument("--context", default="auto", help="market context: auto (default) | full | saved | indices | none")
    ap.add_argument("--split-date", default=None, help="chronological out-of-sample view: report the comparison and the "
                    "money before and from this date separately (declare it before you run)")
    return ap.parse_args(argv)


def plan_like(s: E.Strategy, pick_attrs) -> E.Strategy:
    """The plan on the same picks and the same clock as strategy s (so the comparison is paired)."""
    raw = {"name": "plan" if s.mode == "daily" else "plan_intraday", "mode": s.mode, "picks": copy.deepcopy(s.picks),
           "max_sessions": 5, "warmup_sessions": s.warmup,
           "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}],
           "exits": [{"name": "time", "type": "time", "at": "close", "session": 5}],
           "costs": copy.deepcopy(s.raw.get("costs") or {"model": "flat", "round_trip_bp": 35}),
           "slippage_bp": s.slippage_bp,
           "sizing": copy.deepcopy(s.sizing), "portfolio": copy.deepcopy(s.portfolio)}
    raw["picks"]["filter"] = None
    return E.Strategy(raw, None, pick_attrs)


def main(argv=None) -> int:
    a = parse_args(sys.argv[1:] if argv is None else argv)
    t0 = time.time()
    try:
        if a.list_names:
            names = R.catalog_text()
            if a.root and a.pm_run:
                root = require_root(a.root)
                ws = Workspace(root, a.pm_run, stage_e_any=a.stage_e_any, panel=a.panel, quiet=True)
                T = ws.picks(["D", "ENS"], "1-10")
                feats = ws.market.panel(a.panel).allowed
                names = R.catalog_text(ws.pick_attrs(T), feats)
            say(names)
            return 0
        if not a.strategy:
            raise TLError("--strategy is required (e.g. --strategy strategies\\scale_20_80_vwap.py)")
        root = require_root(a.root)
        base = out_base(a.out, root)
        ws = Workspace(root, a.pm_run, stage_e_any=a.stage_e_any, panel=a.panel)
        raw0, _ = E.read_strategy(a.strategy)          # first pass: only the picks to load
        pk0 = dict(raw0.get("picks") or {})
        picks = {"engines": list(pk0.get("engines", ["D"])), "ranks": list(pk0.get("ranks", [1, 2, 3])),
                 "from": pk0.get("from"), "to": pk0.get("to"), "filter": pk0.get("filter")}
        if a.engines:
            picks["engines"] = a.engines
        if a.ranks:
            picks["ranks"] = parse_ranks(a.ranks)
        if a.d_from:
            picks["from"] = a.d_from
        if a.d_to:
            picks["to"] = a.d_to
        T = ws.picks(picks["engines"], picks["ranks"], picks["from"], picks["to"])
        ctx = ws.context(a.context, base) if a.context != "none" else None
        if ctx is not None:
            T = ws.add_pick_context(T, states=True)          # v1.3.1: + the stock's state at every pick
        S = ws.strategy(a.strategy, T)
        S.picks.update({k: picks[k] for k in ("engines", "ranks", "from", "to")})
        if a.capital:
            S.portfolio["capital"] = a.capital
        extra_vals = [x.strip() for x in a.values.split(",") if x.strip()]
        if extra_vals:
            allowed = ws.market.panel(a.panel).allowed if any(
                x not in R.MARKET_VARS and x not in R.PLUGIN_VARS for x in extra_vals) else []
            S.observe(extra_vals, allowed)
        C = plan_like(S, ws.pick_attrs(T)) if a.compare == "auto" else ws.strategy(a.compare, T)
        if a.compare != "auto":
            C.picks.update({k: picks[k] for k in ("engines", "ranks", "from", "to")})
            if C.mode != S.mode and S.mode == "intraday":
                say("note: the comparison runs in daily mode; picks without 3-minute bars are left out of the "
                    "pairing anyway (the strategy cannot trade them)")
        prior = [r for r in ledger_read(base) if r.get("tool") == TOOL and r.get("event") == "backtest_run"]
        n_prior = len(prior)
        distinct = len({r.get("strategy_sha") for r in prior})
        declared = {"tool": TOOL, "event": "backtest_declared", "strategy": S.name, "strategy_sha": S.sha,
                    "compare": C.name, "compare_sha": C.sha, "pm_run": a.pm_run, "picks": S.picks,
                    "tag": a.tag, "declared_rule": a.declare or None, "decision_rule": S.decision_rule}
        ledger_append(base, declared)
        say(f"{TOOL} ({VERSION}) | {S.name} ({S.mode}, sha {S.sha}) vs {C.name} | picks {len(T):,} | "
            f"engines {S.picks['engines']} ranks {S.picks['ranks']} | ledger: {n_prior} earlier backtests "
            f"({distinct} distinct strategies)")
        tl_ids = [x.strip() for x in a.timeline.split(",") if x.strip()]
        bad = [x for x in tl_ids if x not in set(T["trade_id"])]
        if bad:
            raise TLError(f"--timeline: unknown trade ids {bad[:5]}")
        res, extra = ws.simulate([S, C] if C.name != S.name else [S], T, timeline_ids=tl_ids)
        rS, rC = res[S.name], res[C.name]
        run_dir = new_run_dir(base, "backtest", "TLB")
        A = pd.DataFrame([r.row() for r in rS])
        B = pd.DataFrame([r.row() for r in rC])
        ev = paired_eval(T, A, B)
        port = None
        if not a.no_portfolio:
            say("money view: both through one account ...")
            pS = run_portfolio([r for r, ok in zip(rS, ev["mask"]) if ok], S, ws.market)
            pC = run_portfolio([r for r, ok in zip(rC, ev["mask"]) if ok], C, ws.market)
            port = portfolio_compare(pS, pC)
        decision = decide(S.decision_rule, ev, port)
        mbe = money_by_environment(ctx, pS, pC, S.name, C.name) if (ctx is not None and port is not None) else None
        spl = split_eval(T, A, B, ev["mask"], a.split_date, pS if port is not None else None,
                         pC if port is not None else None) if a.split_date else None
        # outputs
        A2 = A.copy()
        A2["net_bp_compare"] = B["net_bp"].values
        A2["status_compare"] = B["status"].values
        A2["diff_bp"] = np.where(ev["mask"], A2["net_bp"] - A2["net_bp_compare"], np.nan)
        A2["paired"] = ev["mask"]
        for c in ("signal_day",):
            A2[c] = T[c].values
        brk = None
        if ctx is not None:
            A2 = add_bt_context(ctx, ws, T, A2, rS)
            brk = CX.breakdown(A2[A2["paired"]], ["net_bp", "net_bp_compare", "diff_bp"], "engine", dims=BT_DIMS)
        FL = fills_frame(rS + rC)
        PF = path_frame(rS)
        written = write_table(A2, run_dir / "trades")
        written += write_table(FL, run_dir / "fills")
        written += write_table(PF, run_dir / "trade_days")
        tables = {"backtest_trades": list(A2.columns), "fills": list(FL.columns),
                  "backtest_trade_days": list(PF.columns)}
        if port is not None:
            dd = port["daily"]
            dd.to_csv(run_dir / "portfolio_daily.csv", index=False)
            port["trades"].to_csv(run_dir / "portfolio_trades.csv", index=False)
            written += ["portfolio_daily.csv", "portfolio_trades.csv"]
            tables["portfolio_daily"] = list(dd.columns)
            tables["portfolio_trades"] = list(port["trades"].columns)
        if brk is not None and len(brk):
            brk.to_csv(run_dir / "context_breakdown.csv", index=False, float_format="%.10g")
            written.append("context_breakdown.csv")
            tables["context_breakdown"] = list(brk.columns)
        if mbe is not None and len(mbe):
            mbe.to_csv(run_dir / "money_by_environment.csv", index=False, float_format="%.10g")
            written.append("money_by_environment.csv")
            tables["money_by_environment"] = list(mbe.columns)
        written += DD.write(run_dir, tables, f"Data dictionary - tradelab backtest {run_dir.name}")
        if tl_ids:
            (run_dir / "timelines").mkdir()
            for r in rS:
                if r.timeline is not None:
                    r.timeline.to_csv(run_dir / "timelines" / f"{r.pick['trade_id']}.csv", index=False)
                    written.append(f"timelines/{r.pick['trade_id']}.csv")
        for src, nm in ((S.path, "strategy"), (C.path, "compare")):
            if src is not None:
                shutil.copy2(src, run_dir / f"{nm}_{Path(src).name}")
        summ = {"tool": TOOL, "version": VERSION, "pm_run": a.pm_run, "strategy": S.summary(), "compare": C.summary(),
                "picks": len(T), "picks_info": ws.picks_info, "paired": ev["summary"], "portfolio": port["stats"] if port
                else None, "decision": decision, "tag": a.tag, "declared_rule": a.declare or None,
                "ledger": {"earlier_backtests": n_prior, "distinct_strategies": distinct},
                "simulation": extra["info"], "production": ws.prod.describe(), "provenance": provenance(),
                "files": written, "seconds": round(time.time() - t0, 1), "bootstrap": BOOT,
                "context": ({"mode": a.context, "breadth_source": ctx.run_meta.get("breadth_source"),
                             "indices_missing": ctx.run_meta.get("missing_indices"),
                             "definitions": ctx.run_meta.get("definitions")} if ctx is not None else None),
                "split": spl}
        (run_dir / "summary.json").write_text(json.dumps(summ, indent=2, default=str), encoding="utf-8")
        (run_dir / "report.md").write_text(report_md(summ, ev, port) + split_md(spl, summ["compare"]["name"]) +
                                           bt_context_md(brk, summ["compare"]["name"], mbe),
                                           encoding="utf-8")
        write_outputs_sha(run_dir)
        ledger_append(base, {"tool": TOOL, "event": "backtest_run", "run": run_dir.name, "strategy": S.name,
                             "strategy_sha": S.sha, "compare": C.name, "picks": S.picks, "tag": a.tag,
                             "paired_diff_bp": ev["summary"]["diff"], "decision": decision,
                             "seconds": round(time.time() - t0, 1)})
        for line in headline_lines(summ, ev, port):
            say(line)
        say(f"DONE {run_dir}  ({time.time() - t0:,.0f} s)")
        return 0
    except StopRun as e:
        say(f"STOPPED: {e}")
        return 3
    except TLError as e:
        say(f"ERROR: {e}")
        return 2


# ----------------------------------------------------------------------
BT_DIMS = tuple(d for d in CX.BREAKDOWN_DIMS if d[3] == "before") + tuple(ST.STATE_DIMS) + tuple(
    d for d in CX.BREAKDOWN_DIMS if d[1] == "post_hold_small_ret")


def add_bt_context(ctx: CX.Context, ws: Workspace, T: pd.DataFrame, A2: pd.DataFrame, rS) -> pd.DataFrame:
    """pre_* (known at each pick, from T) + post_hold_* index returns over each strategy trade's actual hold (from its
    first buy to its last sale)."""
    X = A2.copy()
    add = {c: T[c].values for c in T.columns if c.startswith("pre_") and c not in X.columns}
    hr = {f"post_hold_{k}_ret": [] for k in CX.BROAD}
    hr["post_hold_home_ret"] = []
    for r in rS:
        buys = [f for f in r.fills if f.side == "buy"]
        sells = [f for f in r.fills if f.side == "sell"]
        ds = ws.market.series(r.pick["symbol"])
        w = {k: np.nan for k in CX.BROAD}
        if buys and sells and ds is not None:
            sig = ds.idx(np.datetime64(pd.Timestamp(r.pick["signal_day"]).date(), "D"))
            bj, sj = sig + int(buys[0].session), sig + int(sells[-1].session)
            if sig >= 0 and 0 <= bj < len(ds) and 0 <= sj < len(ds):
                w = ctx.window_returns(ds.dates[bj], "close" if buys[0].kind == "close" else "open", ds.dates[sj],
                                       "close" if sells[-1].kind == "close" else "open", CX.BROAD)
        for k in CX.BROAD:
            hr[f"post_hold_{k}_ret"].append(w[k])
        h = r.pick.get("pre_home_index") or ""
        hr["post_hold_home_ret"].append(w.get(h, np.nan) if h else np.nan)
    for c, v in hr.items():
        if c in X.columns:
            X[c] = v
        else:
            add[c] = v
    # v1.3.1: the new columns joined at once (one at a time fragmented the frame: pandas PerformanceWarnings)
    return pd.concat([X, pd.DataFrame(add, index=X.index)], axis=1) if add else X


def money_by_environment(ctx: CX.Context, pS, pC, s_name: str, c_name: str) -> pd.DataFrame:
    """Both accounts' daily returns grouped by the environment known at the previous close: return, worst drawdown
    inside the environment, exposure and simultaneous positions."""
    envp = RS.env_prev_map(ctx.frame)
    parts = []
    for res, nm in ((pS, s_name), (pC, c_name)):
        d = getattr(res, "daily", None)
        if d is None or not len(d) or "day_ret" not in d:
            continue
        parts.append(RS.by_environment(d.assign(account=nm), envp, "day_ret", "n_open", "account", "exposure",
                                       additive=False))
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()


def split_eval(T: pd.DataFrame, A: pd.DataFrame, B: pd.DataFrame, mask: np.ndarray, split: str, pS=None, pC=None) -> dict:
    """The paired comparison and the money view before / from a declared split date (chronological out of sample)."""
    d0 = pd.Timestamp(split)
    days = pd.to_datetime(T["signal_day"]).to_numpy()
    a, b = A["net_bp"].to_numpy(float), B["net_bp"].to_numpy(float)
    out = {"split_date": str(d0.date())}
    for nm, mk in (("before", mask & (days < np.datetime64(d0))), ("from", mask & (days >= np.datetime64(d0)))):
        rec = {"picks": int(mk.sum())}
        rec["strategy"] = list(bootstrap_mean_by_day(days[mk], a[mk])[:3])
        rec["compare"] = list(bootstrap_mean_by_day(days[mk], b[mk])[:3])
        md, lo, hi, nd = bootstrap_mean_by_day(days[mk], (a - b)[mk])
        rec["diff"], rec["signal_days"], rec["verdict"] = [md, lo, hi], nd, verdict_from_interval(lo, hi)
        for res, who in ((pS, "money_strategy"), (pC, "money_compare")):
            dd = getattr(res, "daily", None)
            if dd is None or not len(dd) or "day_ret" not in dd:
                continue
            x = dd.copy()
            x["date"] = pd.to_datetime(x["date"])
            x = x[(x["date"] < d0) if nm == "before" else (x["date"] >= d0)]
            r = x["day_ret"].astype(float).fillna(0.0)
            if len(r):
                eq = (1 + r).cumprod()
                tot = float(eq.iloc[-1] - 1)
                rec[who] = {"days": int(len(r)), "total_return": tot,
                            "cagr": float((1 + tot) ** (252 / max(1, len(r))) - 1) if tot > -1 else -1.0,
                            "max_drawdown": float((eq / eq.cummax().clip(lower=1.0) - 1).min()),
                            "avg_exposure": float(x["exposure"].mean()) if "exposure" in x else np.nan,
                            "max_open": float(x["n_open"].max()) if "n_open" in x else np.nan}
        out[nm] = rec
    return out


def split_md(spl: Optional[dict], c_name: str) -> str:
    if not spl:
        return ""
    L = ["", f"## Chronological out-of-sample view (split {spl['split_date']})", "",
         "The same paired comparison and money view before and from the split date. Declare the date before the run; "
         "the 'from' half is the out-of-sample part only if nothing about the strategy was chosen by looking at it.", "",
         f"| part | picks | strategy bp | {c_name} bp | difference bp | verdict | money: total / CAGR / worst drawdown |",
         "|---|---|---|---|---|---|---|"]
    for nm in ("before", "from"):
        r = spl.get(nm) or {}
        ms = r.get("money_strategy") or {}
        mo = (f"{ms.get('total_return', np.nan):+.1%} / {ms.get('cagr', np.nan):+.1%} / {ms.get('max_drawdown', np.nan):+.1%}"
              if ms else "n/a")
        L.append(f"| {nm} | {r.get('picks', 0):,} | {fmt_bp(*r.get('strategy', [np.nan] * 3))} | "
                 f"{fmt_bp(*r.get('compare', [np.nan] * 3))} | {fmt_bp(*r.get('diff', [np.nan] * 3))} | "
                 f"{r.get('verdict', '')} | {mo} |")
    return "\n".join(L) + "\n"


def bt_context_md(brk: Optional[pd.DataFrame], C_name: str, mbe: Optional[pd.DataFrame] = None) -> str:
    if (brk is None or not len(brk)) and (mbe is None or not len(mbe)):
        return ""
    L = ["", "## Market context and stock state: where the strategy helps or hurts (v1.1, states v1.3.1)", ""]
    if mbe is not None and len(mbe):
        L += ["### The money by environment (known at the previous close)", "",
              "Each account's daily returns grouped by the environment known before the day began: mean day return "
              "(bp, 95% block-bootstrap interval), the worst drawdown inside that environment (its days chained), "
              "average exposure and the most positions open at once.", "",
              "| account | environment | days | mean day bp | total | worst drawdown inside | worst day bp | avg exposure | max positions |",
              "|---|---|---|---|---|---|---|---|---|"]
        for r in mbe.to_dict("records"):
            L.append(f"| {r['group']} | {r['environment']} | {r['days']:,} ({r['share_of_days']:.0%}) | "
                     f"{fmt_bp(r['mean_day_bp'], r['lo'], r['hi'], nd=2)} | {r['total_return']:+.2%} | "
                     f"{r['max_drawdown_inside']:+.2%} | {r['worst_day_bp']:+.0f} | {r.get('avg_exposure', np.nan):.2f} | "
                     f"{r.get('max_positions', np.nan):.0f} |")
        L.append("")
    if brk is not None and len(brk):
        L += ["### The paired picks by the market and by the stock's state at the pick", "",
              f"'difference' = strategy - {C_name} on the same picks, bp, 95% block-bootstrap intervals over signal "
              f"days. Many groups are shown: a single group 'BETTER' is a hypothesis to declare and test forward, not a "
              f"finding. Nothing here filters trades.", ""]
        L += CX.breakdown_md(brk, [("net_bp", "strategy bp"), ("net_bp_compare", f"{C_name} bp"),
                                  ("diff_bp", "difference bp")], "engine")
    return "\n".join(L) + "\n"


def paired_eval(T: pd.DataFrame, A: pd.DataFrame, B: pd.DataFrame) -> dict:
    mask = (A["status"].isin(EVALUABLE_S) & (B["status"] == "ok")).to_numpy()
    days = T["signal_day"].to_numpy()
    a = A["net_bp"].to_numpy(float)
    b = B["net_bp"].to_numpy(float)
    ms, los, his, nd = bootstrap_mean_by_day(days[mask], a[mask])
    mc, loc, hic, _ = bootstrap_mean_by_day(days[mask], b[mask])
    md, lod, hid, _ = bootstrap_mean_by_day(days[mask], (a - b)[mask])
    ent = A["entered"].to_numpy(bool) & mask
    traded = A["status"].isin(("ok",)).to_numpy() & mask
    mt, lot, hit, _ = bootstrap_mean_by_day(days[traded], (a - b)[traded])
    left = (~mask) & (B["status"] == "ok").to_numpy()          # the plan finished but the strategy could not trade
    ml, lol, hil, _ = bootstrap_mean_by_day(days[left], b[left]) if left.any() else (np.nan, np.nan, np.nan, 0)
    summ = {"picks_paired": int(mask.sum()), "picks_total": int(len(T)), "signal_days": nd,
            "left_out_plan": {"picks": int(left.sum()), "plan_mean_bp": [ml, lol, hil],
                              "reasons": A.loc[left, "status"].value_counts().to_dict()},
            "excluded": A.loc[~mask, "status"].value_counts().to_dict(),
            "compare_excluded": B.loc[~mask, "status"].value_counts().to_dict(),
            "strategy": [ms, los, his], "compare": [mc, loc, hic], "diff": [md, lod, hid],
            "verdict": verdict_from_interval(lod, hid),
            "diff_on_traded": [mt, lot, hit], "traded": int(traded.sum()),
            "entered_share": float(ent.sum() / max(1, mask.sum())),
            "avg_deployed": float(A.loc[mask, "deployed"].mean()),
            "win_strategy": float((a[mask] > 0).mean()) if mask.any() else np.nan,
            "win_compare": float((b[mask] > 0).mean()) if mask.any() else np.nan,
            "net_on_deployed_bp": float(np.nanmean(A.loc[ent, "net_deployed_bp"])) if ent.any() else np.nan,
            "median_mfe": float(A.loc[ent, "mfe"].median()) if ent.any() else np.nan,
            "median_mae": float(A.loc[ent, "mae"].median()) if ent.any() else np.nan,
            "exit_reasons": A.loc[ent, "exit_reason"].value_counts().to_dict(),
            "legs": _leg_rates(A, ent), "ambiguous_bars": int(A.loc[mask, "ambiguous_bars"].sum()),
            "locked_exits": int(A.loc[mask, "locked_exit"].sum()),
            "avg_exit_session": float(A.loc[ent, "exit_session"].mean()) if ent.any() else np.nan}
    yrs = pd.DatetimeIndex(days).year
    by_year = []
    for y in sorted(set(yrs[mask])):
        m = mask & (yrs == y)
        by_year.append({"year": int(y), "picks": int(m.sum()), "strategy": float(a[m].mean()),
                        "compare": float(b[m].mean()), "diff": float((a - b)[m].mean())})
    summ["by_year"] = by_year
    by = []
    for (e, rk), g in A[mask].assign(diff=(a - b)[mask], cmp=b[mask]).groupby(["engine", "rank"]):
        by.append({"engine": e, "rank": int(rk), "picks": int(len(g)), "strategy": float(g["net_bp"].mean()),
                   "compare": float(g["cmp"].mean()), "diff": float(g["diff"].mean())})
    summ["by_engine_rank"] = by
    return {"mask": mask, "summary": summ}


def _leg_rates(A: pd.DataFrame, ent: np.ndarray) -> Dict[str, float]:
    out: Dict[str, int] = {}
    for s in A.loc[ent, "legs_filled"].fillna(""):
        for leg in [x for x in s.split(";") if x]:
            out[leg] = out.get(leg, 0) + 1
    n = max(1, int(ent.sum()))
    return {k: v / n for k, v in out.items()}


def portfolio_compare(pS, pC) -> dict:
    d = pS.daily.merge(pC.daily[["date", "day_ret", "equity"]], on="date", how="outer", suffixes=("", "_compare"))
    d = d.sort_values("date").reset_index(drop=True)
    diff = (d["day_ret"] - d["day_ret_compare"]).to_numpy(float)
    m, lo, hi = bootstrap_daily(diff)
    stats = {"strategy": pS.stats, "compare": pC.stats,
             "daily_ret_diff_bp": [m * 1e4, lo * 1e4 if np.isfinite(lo) else lo, hi * 1e4 if np.isfinite(hi) else hi],
             "daily_ret_diff_verdict": verdict_from_interval(lo, hi)}
    return {"daily": d, "trades": pS.trades, "stats": stats}


def decide(rule, ev: dict, port: Optional[dict]) -> Optional[dict]:
    """Strategy file's decision_rule: {"metric": "diff_mean_bp" | "strategy_mean_bp", "pass_if": "lower > 0"}."""
    if not rule:
        return None
    s = ev["summary"]
    metric = rule.get("metric", "diff_mean_bp")
    vals = {"diff_mean_bp": s["diff"], "strategy_mean_bp": s["strategy"]}.get(metric)
    if vals is None:
        return {"rule": rule, "verdict": f"UNKNOWN METRIC {metric}"}
    m, lo, hi = vals
    cond = str(rule.get("pass_if", "lower > 0")).strip()
    try:
        side, op, x = cond.split()
        x = float(x)
        v = {"lower": lo, "upper": hi, "mean": m}[side]
        ok = {">": v > x, ">=": v >= x, "<": v < x, "<=": v <= x}[op]
    except Exception:
        return {"rule": rule, "verdict": f"UNREADABLE pass_if '{cond}' (use e.g. 'lower > 0')"}
    if not np.isfinite(v):
        return {"rule": rule, "verdict": "NO INTERVAL"}
    return {"rule": rule, "value": v, "verdict": "PASS" if ok else "FAIL"}


def headline_lines(summ, ev, port) -> List[str]:
    s = ev["summary"]
    L = [f"paired picks: {s['picks_paired']:,} of {s['picks_total']:,} over {s['signal_days']:,} signal days "
         f"(left out: {s['excluded']})",
         f"strategy {fmt_bp(*s['strategy'])} bp per pick | {summ['compare']['name']} {fmt_bp(*s['compare'])} bp | "
         f"difference {fmt_bp(*s['diff'])} bp -> {s['verdict']}",
         f"entered {s['entered_share']:.1%} of picks, average size used {s['avg_deployed']:.2f}, legs {s['legs']}"]
    if port is not None:
        ps, pc = port["stats"]["strategy"], port["stats"]["compare"]
        if "cagr" in ps and "cagr" in pc:
            L.append(f"money: strategy CAGR {ps['cagr']:+.1%}, worst drawdown {ps['max_drawdown']:+.1%} | "
                     f"{summ['compare']['name']} CAGR {pc['cagr']:+.1%}, worst drawdown {pc['max_drawdown']:+.1%}")
    if summ.get("decision"):
        L.append(f"decision rule: {summ['decision']}")
    L.append(f"ledger: {summ['ledger']['earlier_backtests']} earlier backtests, "
             f"{summ['ledger']['distinct_strategies']} distinct strategies - exploratory unless declared and forward-tested")
    return L


def report_md(summ, ev, port) -> str:
    s = ev["summary"]
    S, C = summ["strategy"], summ["compare"]
    L = [f"# tradelab backtest - {S['name']}", "",
         f"{summ['tool']} ({summ['version']}), {summ['provenance']['created']}. pick_meta run {summ['pm_run']}. "
         f"Strategy {S['path']} (sha {S['sha16']}, mode {S['mode']}), compared with {C['name']}.",
         f"Tag: {summ['tag'] or '-'}. Declared rule: {summ['declared_rule'] or '-'}.", "",
         "## Verdict first", "",
         f"- Per pick slot: strategy **{fmt_bp(*s['strategy'])} bp**, {C['name']} {fmt_bp(*s['compare'])} bp, "
         f"difference **{fmt_bp(*s['diff'])} bp -> {s['verdict']}** ({s['picks_paired']:,} picks, "
         f"{s['signal_days']:,} signal days).",
         f"- On the picks the strategy actually traded ({s['traded']:,}): difference {fmt_bp(*s['diff_on_traded'])} bp.",
         f"- Picks the plan finished but the strategy could not trade ({s['left_out_plan']['picks']:,}, "
         f"{s['left_out_plan']['reasons']}): the plan made {fmt_bp(*s['left_out_plan']['plan_mean_bp'])} bp on them vs "
         f"{fmt_bp(*s['compare'])} bp on the paired picks - a large gap means the pairing is not a fair sample.",
         f"- Entered {s['entered_share']:.1%} of picks; average size used {s['avg_deployed']:.2f} of the target; "
         f"net on the money actually used {s['net_on_deployed_bp']:+.1f} bp.", ""]
    if port is not None and "cagr" in port["stats"]["strategy"]:
        ps, pc = port["stats"]["strategy"], port["stats"]["compare"]
        L += ["## Money view (one account, the strategy's sizing)", "",
              "| | strategy | " + C["name"] + " |", "|---|---|---|",
              f"| CAGR | {ps['cagr']:+.2%} | {pc['cagr']:+.2%} |",
              f"| worst drawdown | {ps['max_drawdown']:+.2%} ({ps['dd_peak']} -> {ps['dd_trough']}) | "
              f"{pc['max_drawdown']:+.2%} ({pc['dd_peak']} -> {pc['dd_trough']}) |",
              f"| Sharpe (daily x sqrt 252) | {ps['sharpe']:.2f} | {pc['sharpe']:.2f} |",
              f"| average exposure | {ps['avg_exposure']:.2f} | {pc['avg_exposure']:.2f} |",
              f"| trades opened | {ps['trades_opened']:,} | {pc['trades_opened']:,} |",
              f"| skipped (reason) | {ps['trades_skipped']} | {pc['trades_skipped']} |",
              f"| legs trimmed / skipped by cash | {ps['legs_trimmed_by_cash']} / {ps['legs_skipped_by_cash']} | "
              f"{pc['legs_trimmed_by_cash']} / {pc['legs_skipped_by_cash']} |", "",
              f"Daily return difference: {fmt_bp(*port['stats']['daily_ret_diff_bp'], nd=2)} bp a day -> "
              f"{port['stats']['daily_ret_diff_verdict']}.", ""]
    L += ["## Detail", "", f"- Win rate: strategy {s['win_strategy']:.1%}, {C['name']} {s['win_compare']:.1%}.",
          f"- Legs filled (share of entered picks): {s['legs']}.", f"- Exit reasons: {s['exit_reasons']}.",
          f"- Median MFE {s['median_mfe']:+.2%}, median MAE {s['median_mae']:+.2%} (from the first buy, while held).",
          f"- Average exit session {s['avg_exit_session']:.2f}; locked exits {s['locked_exits']}; bars where a stop and "
          f"a target were both inside the bar (settled by the '{S['intrabar']}' policy): {s['ambiguous_bars']}.",
          f"- Left out of the pairing: strategy {s['excluded']}, {C['name']} {s['compare_excluded']}.", "",
          "### By year (bp per pick)", "", "| year | picks | strategy | " + C["name"] + " | difference |",
          "|---|---|---|---|---|"]
    for y in s["by_year"]:
        L.append(f"| {y['year']} | {y['picks']:,} | {y['strategy']:+.1f} | {y['compare']:+.1f} | {y['diff']:+.1f} |")
    L += ["", "### By engine and rank (bp per pick)", "", "| engine | rank | picks | strategy | " + C["name"] +
          " | difference |", "|---|---|---|---|---|---|"]
    for r in s["by_engine_rank"]:
        L.append(f"| {r['engine']} | {r['rank']} | {r['picks']:,} | {r['strategy']:+.1f} | {r['compare']:+.1f} | "
                 f"{r['diff']:+.1f} |")
    lg = summ["ledger"]
    L += ["", "## How much to trust this", "",
          f"- The tradelab ledger held {lg['earlier_backtests']} earlier backtests ({lg['distinct_strategies']} distinct "
          f"strategy files) before this one. With 20 variants tried on the same years, about one will look BETTER at "
          f"the 95% level by luck alone.",
          "- Same 2020-2026 history the engines were built and studied on. Treat any edge found here as a hypothesis: "
          "declare the rule (--declare, decision_rule) and judge it on the forward paper ledger.",
          f"- Costs: {S['costs']}; slippage {S['slippage_bp']} bp a side. Fills: next-bar opens, stop / limit "
          "levels from the previous bar, official open / close for 'at' orders, honest lower-circuit exits.",
          "- Not modelled: upper-circuit buys that cannot fill, partial fills, market impact beyond the cost model."]
    if summ.get("decision"):
        L += ["", f"## Decision rule: {summ['decision']}"]
    return "\n".join(L) + "\n"


if __name__ == "__main__":
    raise SystemExit(main())
