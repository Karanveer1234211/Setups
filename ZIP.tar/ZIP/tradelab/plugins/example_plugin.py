"""Example tradelab plugin: your own values and functions for rules.

    @variable(name, help, mode)   fn(ctx) -> numpy array, one value per bar of the trade's clock
    @function(name, min_args, max_args, help)   fn(x, ...) -> numpy array (series in, series out)

ctx gives: ctx.open / high / low / close / volume (arrays), ctx.session, ctx.bar_in_session, ctx.n,
ctx.var("vwap") (any built-in value), ctx.daily (daily bars up to the last COMPLETED session: .dates .o .h .l .c .v)
and ctx.day_pos (each bar's position in ctx.daily's arrays, the current session included).
Rule of the game: a value at bar t may use bars up to t only. tradelab re-computes every plugin value with the
bars after t removed and refuses the run if anything before t changes.
List a plugin in a strategy with "plugins": ["example_plugin.py"] (looked up next to the strategy, then here).
"""
import numpy as np
import pandas as pd

from tl_rules import function, variable


@variable("vol_surge", "bar volume / mean volume of the previous 20 bars")
def vol_surge(ctx):
    v = pd.Series(ctx.volume)
    base = v.shift(1).rolling(20, min_periods=20).mean()
    return (v / base).to_numpy(float)


@variable("range_pos20", "close location inside the high-low range of the last 20 bars (0 = low, 1 = high)")
def range_pos20(ctx):
    h = pd.Series(ctx.high).rolling(20, min_periods=20).max()
    l = pd.Series(ctx.low).rolling(20, min_periods=20).min()
    rng = (h - l).replace(0, np.nan)
    return ((pd.Series(ctx.close) - l) / rng).to_numpy(float)


@function("above_for", 3, 3, "above_for(x, level, n): x above level on each of the last n bars")
def above_for(x, level, n):
    a = np.asarray(x, float) > np.asarray(level, float)
    return (pd.Series(a.astype(float)).rolling(int(n), min_periods=int(n)).sum() >= int(n)).to_numpy(float)
