"""Sell at the 6th session's open instead of the 5th close (the shadow-lane lever). A locked open moves to the
first unlocked open within 20 sessions."""
STRATEGY = {
    "name": "open6",
    "mode": "daily",
    "picks": {"engines": ["D"], "ranks": [1, 2, 3]},
    "max_sessions": 6,
    "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}],
    "exits": [{"name": "open6", "type": "time", "at": "open", "session": 6}],
}
