"""The plain plan run on the 3-minute clock (same trades as any intraday strategy, so comparisons are paired).
Buy the official open of session 1, sell the official close of session 5; must equal the daily plan exactly."""
STRATEGY = {
    "name": "plan_intraday",
    "mode": "intraday",
    "picks": {"engines": ["D"], "ranks": [1, 2, 3]},
    "max_sessions": 5,
    "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}],
    "exits": [{"name": "time", "type": "time", "at": "close", "session": 5}],
}
