"""Daily bars: sell half at +5% above the average entry, stop everything at -8%, the rest at the 5th close.
A day whose range holds both the stop and the target is settled by 'intrabar': worst = stop first (default);
'intraday' reads that day's 3-minute bars to see which came first."""
STRATEGY = {
    "name": "half_target_stop",
    "mode": "daily",
    "picks": {"engines": ["D"], "ranks": [1, 2, 3]},
    "max_sessions": 5,
    "intrabar": "worst",
    "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}],
    "exits": [
        {"name": "target5", "type": "target", "level": "avg_entry * 1.05", "size": 0.5},
        {"name": "stop8", "type": "stop", "level": "avg_entry * 0.92"},
        {"name": "time", "type": "time", "at": "close", "session": 5},
    ],
}
