"""Daily bars, hold up to 10 sessions: once the best high since entry is 5% above it, trail a stop 4% under the
highest high; otherwise exit at the 10th close."""
STRATEGY = {
    "name": "trail_after_5pct",
    "mode": "daily",
    "picks": {"engines": ["D"], "ranks": [1, 2, 3]},
    "max_sessions": 10,
    "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}],
    "exits": [
        {"name": "trail4", "type": "trail", "pct": 0.04, "activate": "mfe_sofar >= 0.05"},
        {"name": "time", "type": "time", "at": "close", "session": 10},
    ],
}
