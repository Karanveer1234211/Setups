"""3-minute bars: try to buy 1% below the session-1 open with a limit order until 11:00; if it has not filled by
then, buy at the next bar's open instead (the fallback is cancelled once the dip leg fills). Exit at the 5th
close. Entry sizes add up to 2.0 on purpose: buys are clipped so the position never exceeds the target.
The dip order starts at 09:18: a level is computed at the previous bar's close, so a level built on today's open
is only valid from the second bar."""
STRATEGY = {
    "name": "dip_or_fallback",
    "mode": "intraday",
    "picks": {"engines": ["D"], "ranks": [1, 2, 3]},
    "max_sessions": 5,
    "entries": [
        {"name": "dip", "size": 1.0, "fill": "limit", "level": "session_open * 0.99", "sessions": [1, 1],
         "time": ["09:18", "10:57"]},
        {"name": "fallback", "size": 1.0, "when": "hhmm >= 1057", "sessions": [1, 1], "time": ["11:00", "15:27"],
         "cancel_if": "filled_dip"},
    ],
    "exits": [{"name": "time", "type": "time", "at": "close", "session": 5}],
}
