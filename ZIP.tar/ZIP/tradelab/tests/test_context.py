"""
tests/test_context.py - tradelab v1.1: the market intelligence layer, checked (sections 10-13 of the suite).

Run it through tests/test_tradelab.py (which prints VERIFIED (tradelab v1.3.1)). Synthetic worlds only
(tests/tl_ctx_world.py, tests/tl_world.py) with stand-in production modules - nothing on your cache is read or written.
  10 by hand      index values, divergence, breadth (A/D), environment and stress labels recomputed independently;
                  a missing VIX file stays missing (never filled); AMFI lists from CSV / Excel (one- or two-row
                  header) / PDF, point in time, a missing half-year left blank (never carried on), a renamed company
                  found via ISIN, a list without NSE symbols refused, no proxy anywhere; beta / correlation (BETA15 =
                  exactly 1.5 x Smallcap); the market / stock split
  11 point in time  every bar after a date scrambled: market_days and every pre_* value up to it unchanged; post_*
                  refused in rules; pre_* usable in a filter; rule values read the right day
  12 research     outcome groups, warning-sign counts, drawdown, the environment book and the walk-forward by hand;
                  a planted warning sign becomes a CANDIDATE, an absent one does not; qualification uses earlier
                  years only; the planted world's sign shows, the absent world's does not
  13 integration  every column documented; cards / diary / research readable (no 'nan'); tl_cards, tl_research and
                  tl_backtest (split date, money by environment, open positions by hand) commands; the example
                  hypothesis strategy; a world without Midcap / Smallcap / VIX; --context none = v1's files; tl_check;
                  tl_context check / build / diary
"""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import tl_world as W  # noqa: E402
import tl_ctx_world as CW  # noqa: E402

IST = "Asia/Kolkata"
EXOG = {"NIFTY50", "NIFTYBANK", "NIFTY500", "NIFTYMIDCAP150", "NIFTYSMLCAP250", "INDIAVIX", "NIFTYIT"}


# ----------------------------------------------------------------------
# independent calculations (plain pandas on the world's files - no tradelab code)
# ----------------------------------------------------------------------
def _days(df: pd.DataFrame) -> pd.DatetimeIndex:
    t = pd.to_datetime(df["timestamp"])
    if getattr(t.dt, "tz", None) is not None:
        t = t.dt.tz_convert(IST).dt.tz_localize(None)
    return pd.DatetimeIndex(t.dt.normalize())


def indep_index(root: Path, sym: str) -> pd.DataFrame:
    df = pd.read_parquet(root / f"{sym}_daily.parquet")
    c, o = df["close"].astype(float).to_numpy(), df["open"].astype(float).to_numpy()
    out = pd.DataFrame(index=_days(df))
    cs = pd.Series(c, index=out.index)
    out["close"] = c
    out["ret"] = cs / cs.shift(1) - 1
    out["gap"] = o / cs.shift(1).to_numpy() - 1
    out["intraday"] = c / o - 1
    out["ret20"] = cs / cs.shift(20) - 1
    out["vs_ma50"] = cs / cs.rolling(50, min_periods=50).mean() - 1
    out["up50"] = np.where(out["vs_ma50"].notna(), (out["vs_ma50"] >= 0).astype(float), np.nan)
    sd = out["ret"].rolling(60, min_periods=40).std().shift(1)
    out["ret_z"] = out["ret"] / sd
    return out


def indep_pct(x: np.ndarray, w: int = 250, minp: int = 60) -> np.ndarray:
    out = np.full(len(x), np.nan)
    for i in range(len(x)):
        a = x[max(0, i - w + 1):i + 1]
        a = a[np.isfinite(a)]
        if np.isfinite(x[i]) and len(a) >= minp:
            out[i] = np.mean(a <= x[i])
    return out


def indep_breadth(root: Path) -> pd.DataFrame:
    adv, dec, unch = {}, {}, {}
    for f in sorted(root.glob("*_daily.parquet")):
        sym = f.name[:-len("_daily.parquet")]
        if sym in EXOG:
            continue
        df = pd.read_parquet(f)
        d = _days(df)
        c = df["close"].astype(float).to_numpy()
        r = c[1:] / c[:-1] - 1
        for day, x in zip(d[1:], r):
            if not np.isfinite(x):
                continue
            tgt = adv if x > 1e-9 else (dec if x < -1e-9 else unch)
            tgt[day] = tgt.get(day, 0) + 1
    idx = sorted(set(adv) | set(dec) | set(unch))
    B = pd.DataFrame({"adv": [adv.get(d, 0) for d in idx], "dec": [dec.get(d, 0) for d in idx],
                      "unch": [unch.get(d, 0) for d in idx]}, index=pd.DatetimeIndex(idx))
    B["ad_n"] = B["adv"] + B["dec"] + B["unch"]
    B["ad_ratio"] = B["adv"] / (B["adv"] + B["dec"])
    return B


def scramble_after(src: Path, dst: Path, cut: pd.Timestamp, seed: int = 3) -> None:
    """Copy a world and multiply every daily bar AFTER `cut` by a random factor (the same for its O / H / L / C)."""
    shutil.copytree(src, dst)
    rng = np.random.default_rng(seed)
    for f in dst.glob("*_daily.parquet"):
        df = pd.read_parquet(f)
        m = np.asarray(_days(df) > cut)
        k = np.exp(rng.normal(0, 0.05, m.sum()))
        for col in ("open", "high", "low", "close"):
            v = df[col].to_numpy(float).copy()
            v[m] = v[m] * k
            df[col] = v
        df.to_parquet(f, index=False)


def frames_equal(A: pd.DataFrame, B: pd.DataFrame, cols) -> bool:
    for c in cols:
        a, b = A[c].to_numpy(), B[c].to_numpy()
        if a.dtype == object or b.dtype == object:
            if not all((x == y) or (pd.isna(x) and pd.isna(y)) for x, y in zip(a, b)):
                return False
        elif not np.allclose(a.astype(float), b.astype(float), rtol=0, atol=1e-12, equal_nan=True):
            return False
    return True


def tstat(m, lo, hi) -> float:
    return abs(m) / ((hi - lo) / 3.92) if np.isfinite(lo) and np.isfinite(hi) and hi > lo else 0.0


# ======================================================================
def run_all(check, quiet, fresh_modules, TMP: Path, LAB: Path) -> None:
    print("10. market context by hand: indices, breadth, environment, stress, AMFI, beta, split")
    wp = CW.make_ctx_world(TMP / "ctx_planted", "planted", 1)
    root = wp["root"]
    fresh_modules(root)
    import tl_context as C
    import tl_export as X
    out = TMP / "out_ctx"
    rc, log = quiet(X.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                             "--features", "none", "--cards", "2"])
    ex = sorted((out / "export").glob("TLX_*"))[-1]
    check(rc == 0 and (ex / "market_days.parquet").exists() and (ex / "research" / "research_report.md").exists(),
          "v1.1 export runs with the market context and the research report")
    M = pd.read_parquet(ex / "market_days.parquet")
    M["date"] = pd.to_datetime(M["date"]).dt.normalize()
    M = M.set_index("date")
    T = pd.read_parquet(ex / "trades.parquet")
    T["signal_day"] = pd.to_datetime(T["signal_day"])
    Dd = pd.read_parquet(ex / "trade_days.parquet")

    # --- index values ---
    ok = True
    for k, sym in (("nifty", "NIFTY50"), ("mid", "NIFTYMIDCAP150"), ("small", "NIFTYSMLCAP250")):
        I = indep_index(root, sym).reindex(M.index)
        for f in ("close", "ret", "gap", "intraday", "ret20", "vs_ma50", "up50", "ret_z"):
            ok &= np.allclose(M[f"{k}_{f}"].to_numpy(float), I[f].to_numpy(float), rtol=0, atol=1e-12, equal_nan=True)
    check(ok, "index values = an independent calculation (return, gap, open-to-close, 20-day, vs 50-day average, "
              "up / down, move in sd)")
    V = pd.read_parquet(root / "INDIAVIX_daily.parquet")
    vs = pd.Series(V["close"].astype(float).to_numpy(), index=_days(V))
    vp = pd.Series(indep_pct(vs.to_numpy()), index=vs.index)
    ok = np.allclose(M["vix"], vs.reindex(M.index), atol=1e-12) and \
        np.allclose(M["vix_chg5_pct"], (vs / vs.shift(5) - 1).reindex(M.index), atol=1e-12, equal_nan=True) and \
        np.allclose(M["vix_chg_pct"], (vs / vs.shift(1) - 1).reindex(M.index), atol=1e-12, equal_nan=True) and \
        np.allclose(M["vix_pct250"], vp.reindex(M.index), atol=1e-12, equal_nan=True)
    check(ok, "VIX level, day change, 5-day change and 250-session percentile = independent")
    ok = np.allclose(M["nifty_minus_small"], M["nifty_ret"] - M["small_ret"], atol=1e-15, equal_nan=True) and \
        np.allclose(M["nifty_minus_mid_20"], M["nifty_ret20"] - M["mid_ret20"], atol=1e-15, equal_nan=True)
    check(ok, "divergence = NIFTY minus Midcap / Smallcap (day and 20 days)")
    # --- breadth ---
    B = indep_breadth(root)
    B["ad_ratio_10"] = B["ad_ratio"].rolling(10, min_periods=10).mean()
    Bm = B.reindex(M.index)
    ok = all(np.allclose(M[c].to_numpy(float), Bm[c].to_numpy(float), atol=1e-12, equal_nan=True)
             for c in ("adv", "dec", "unch", "ad_n", "ad_ratio", "ad_ratio_10"))
    check(ok and M["ad_n"].min() >= 55, f"breadth = advancers / (advancers + decliners) over every cached stock, "
                                         f"recomputed independently (ad_n {int(M['ad_n'].min())}-{int(M['ad_n'].max())})")
    # --- environment ---
    up = {k: indep_index(root, s).reindex(M.index)["up50"] for k, s in (("n", "NIFTY50"), ("m", "NIFTYMIDCAP150"),
                                                                        ("s", "NIFTYSMLCAP250"))}
    b10 = Bm["ad_ratio_10"]
    exp = []
    for n_, m_, s_, b_ in zip(up["n"], up["m"], up["s"], b10):
        if any(pd.isna(x) for x in (n_, m_, s_, b_)):
            exp.append("")
        elif n_ == 1 and m_ == 1 and s_ == 1 and b_ >= 0.5:
            exp.append("broad_bullish")
        elif n_ == 1:
            exp.append("narrow_bullish")
        elif m_ == 0 and s_ == 0 and b_ < 0.5:
            exp.append("broad_bearish")
        else:
            exp.append("mixed")
    got = M["env_direction"].fillna("").astype(object).tolist()
    cnt = pd.Series(exp).value_counts().to_dict()
    check(got == exp and sum(1 for k in ("broad_bullish", "narrow_bullish", "mixed", "broad_bearish") if cnt.get(k)) >= 3,
          f"environment labels = the declared rules recomputed independently ({cnt})")
    # --- stress ---
    z = {k: indep_index(root, s).reindex(M.index)["ret_z"] for k, s in (("n", "NIFTY50"), ("s", "NIFTYSMLCAP250"))}
    v5 = (vs / vs.shift(5) - 1).reindex(M.index)
    vpp = vp.reindex(M.index)
    flag = []
    for a_, b_, c_, d_ in zip(vpp, v5, z["n"], z["s"]):
        fired = (np.isfinite(a_) and a_ >= 0.9) or (np.isfinite(b_) and b_ >= 0.25) or \
            (np.isfinite(c_) and abs(c_) >= 2.5) or (np.isfinite(d_) and abs(d_) >= 2.5)
        flag.append(1.0 if fired else (0.0 if all(np.isfinite(x) for x in (a_, b_, c_, d_)) else np.nan))
    flag = np.array(flag)
    fm = M["high_stress"].to_numpy(float)
    reasons_ok = all((r != "") == (f == 1) for r, f in zip(M["stress_reason"].fillna(""), fm))
    env5_ok = all((e5 == "high_stress") if f == 1 else (e5 == ed) for e5, ed, f in
                  zip(M["environment"].fillna(""), M["env_direction"].fillna(""), fm))
    check(np.array_equal(fm, flag, equal_nan=True) and reasons_ok and env5_ok and np.nansum(fm == 1) > 0,
          f"high-stress flag = the declared rule (VIX >= 90th pct, VIX +25% in 5 days, 2.5 sd day) independently; "
          f"reasons given exactly when it fires; the five-label view = stress else direction ({int(np.nansum(fm == 1))} "
          f"stress days)")
    # --- a missing VIX file stays missing ---
    nv = TMP / "ctx_novix"
    shutil.copytree(root, nv)
    (nv / "INDIAVIX_daily.parquet").unlink()
    fresh_modules(nv)
    import tl_context as C2
    from tl_run import Workspace
    ws_nv = Workspace(nv, "PM_TEST_001", stage_e_any=True, quiet=True)
    c_nv = C2.build_context(ws_nv, "full", TMP / "out_novix", log=lambda *_: None)
    F2 = c_nv.frame.set_index("date").reindex(M.index)
    zf = (np.abs(F2["nifty_ret_z"]) >= 2.5) | (np.abs(F2["small_ret_z"]) >= 2.5)
    ok = F2["vix"].isna().all() and (F2["env_direction"].fillna("") == M["env_direction"].fillna("")).all() and \
        np.array_equal(F2["high_stress"].to_numpy(float), np.where(zf, 1.0, np.nan), equal_nan=True) and \
        F2["missing"].str.contains("vix").all()
    check(ok, "VIX file missing: VIX blank, direction unchanged, stress 1 only where a 2.5 sd day fired else unknown "
              "(never 0), 'missing' names it - nothing filled")
    fresh_modules(root)
    import tl_context as C
    # --- AMFI lists ---
    amfi = C.read_amfi_dir(root)
    rep = {r["file"]: r["status"] for r in amfi.report}
    ok = len(amfi.lists) == 4 and sum(str(v).startswith("REFUSED") for v in rep.values()) == 1 and \
        {L.how for L in amfi.lists} == {"csv", "excel", "pypdf"}
    ends = {"2022-06-30": 1, "2022-12-31": 2, "2023-06-30": 3, "2023-12-31": 4}
    for L in amfi.lists:
        tr = CW.amfi_truth(ends[str(L.period_end)])
        ok &= all(L.map.get(s, (None,))[0] == r for s, r in tr.items())
    check(ok, "AMFI lists read from CSV (title row), Excel and two PDFs (wrapped names, NSE-only rows): every world "
              "symbol's rank exact; a list whose categories disagree with its ranks is refused")
    import pdfplumber
    pdfp = root / "sectors" / "amfi" / "AverageMarketCapitalizationoflistedcompaniesduringthesixmonthsended31Dec2023.pdf"
    with pdfplumber.open(str(pdfp)) as pdf:
        lines = [x for pg in pdf.pages for x in (pg.extract_text() or "").splitlines()]
    R2 = C.parse_amfi_lines(lines)
    ok = C.validate_amfi(R2)[0] and dict(zip(R2["rank"], R2["category"])) == \
        dict(zip(amfi.lists[-1].rows["rank"], amfi.lists[-1].rows["category"]))
    check(ok, "a PDF read one row per line (pdfplumber) gives the same list as one cell per line (pypdf)")
    mv = T[T["symbol"] == CW.MOVER]
    eff3 = pd.Timestamp("2023-08-01")
    ok = len(mv) > 0 and (mv.loc[mv["signal_day"] < eff3, "pre_size_class"] == "small").all() and \
        (mv.loc[mv["signal_day"] >= eff3, "pre_size_class"] == "large").all() and (mv["signal_day"] >= eff3).any() \
        and (mv["signal_day"] < eff3).any()
    fz = T[T["symbol"].isin(CW.FRENZY)]
    qt = T[T["symbol"].isin(CW.QUIET)]
    ok &= (fz["pre_size_class"] == "small").all() and (qt["pre_size_class"] == "large").all()
    ok &= C.read_amfi_dir(root).lookup("ZZZNOTLISTED", "2023-08-01")[0] == "not in list" and \
        C.read_amfi_dir(root).lookup("L00", "2022-07-31")[0] == "no list" and \
        C.read_amfi_dir(root).lookup("L00", "2022-08-01")[0] == "large"
    ok &= not any("proxy" in c.lower() for c in T.columns)
    check(ok, "size class point in time (each list used from 1 Feb / 1 Aug): MOVER small before 1 Aug 2023 and large from it; heavily traded small caps "
              "stay small, a quiet large cap stays large; 'no list' before the first list, 'not in list' for an "
              "unlisted symbol; no proxy column anywhere")
    gap = TMP / "ctx_amfi_gap"
    shutil.copytree(root, gap)
    (gap / "sectors" / "amfi" / "Average Market Capitalisation of Listed Companies during Jan - Jun 2023.pdf").unlink()
    bk = C.read_amfi_dir(gap)
    full = C.read_amfi_dir(root)
    # list 2 (half-year ended 31 Dec 2022) is in force from 1 Feb 2023 to 31 Jul 2023; list 3 is missing, so until list 4
    # starts (1 Feb 2024) there is NO list - list 2 is never carried on; list 4 itself expires on 1 Aug 2024
    ok = bk.lookup("L00", "2023-07-31")[0] == "large" and bk.lookup("L00", "2023-08-01")[0] == "no list" and \
        bk.lookup("L00", "2024-01-31")[0] == "no list" and bk.lookup("L00", "2024-02-01")[0] == "large" and \
        bk.lookup(CW.MOVER, "2023-07-31")[0] == "small" and bk.lookup(CW.MOVER, "2024-02-01")[0] == "large" and \
        full.lookup("L00", "2024-07-31")[0] == "large" and full.lookup("L00", "2024-08-01")[0] == "no list"
    from tl_run import Workspace
    lines_g, warn_g = C.check_lines(Workspace(gap, "PM_TEST_001", stage_e_any=True, quiet=True))
    ok &= any("AMFI list missing between the half-years ending 2022-12-31 and 2023-12-31" in w for w in warn_g)
    check(ok, "a missing AMFI half-year leaves the size class blank ('no list') for that half-year - the older list is "
              "never carried on - and tl_check warns about the gap")
    # Excel with a two-row header, a list whose NSE symbol column is not recognisable, and a renamed company
    import openpyxl
    md = TMP / "amfi_more"
    md.mkdir()
    r3, r4, r2 = CW.amfi_rows(3), CW.amfi_rows(4), CW.amfi_rows(2)
    for rows_, rk, sym in ((r3, 52, "OLDNAME"), (r4, 121, "NEWNAME")):
        rows_[rk - 1][2], rows_[rk - 1][3], rows_[rk - 1][5] = "INE999Z01019", sym, sym
    top = ["Sr. No.", "Company name", "ISIN", "BSE", "", "NSE", "", "MSEI", "", "Average of All Exchanges (Rs. Cr.)",
           "Categorization as per SEBI Circular dated Oct 6, 2017"]
    sub = ["", "", "", "Symbol", "6 month Avg Total Market Cap in (Rs. Crs.)", "Symbol",
           "6 month Avg Total Market Cap (Rs. Crs.)", "Symbol", "6 month Avg Total Market Cap in (Rs Crs.)", "", ""]
    wb = openpyxl.Workbook()
    sh = wb.active
    sh.append(["Average Market Capitalization of listed companies during the six months ended 30 June 2023"])
    sh.append(top)
    sh.append(sub)
    for r_ in r3:
        sh.append(r_)
    wb.save(md / "AverageMarketCapitalization30Jun2023.xlsx")
    import csv
    for name_, rows_, hdr_ in (("AverageMarketCapitalization31Dec2023.csv", r4, CW.HEADER),
                               ("AverageMarketCapitalization31Dec2022.csv", r2,
                                [h if h != "NSE Symbol" else "Exchange code" for h in CW.HEADER])):
        with open(md / name_, "w", encoding="utf-8", newline="") as f:
            w_ = csv.writer(f)
            w_.writerow(hdr_)
            w_.writerows(rows_)
    (md / "amfi_published.csv").write_text("file,published\nAverageMarketCapitalization30Jun2023.xlsx,2023-07-05\n",
                                           encoding="utf-8")
    bk = C.read_amfi_dir(root, md)
    st_ = {r_["file"]: r_["status"] for r_ in bk.report}
    n3, n4 = bk.lookup("NEWNAME", "2023-08-01"), bk.lookup("NEWNAME", "2024-02-01")
    o4 = bk.lookup("OLDNAME", "2024-02-01")
    tm_ = {r_["file"]: r_.get("timing", "") for r_ in bk.report}
    ok = bk.lookup("L00", "2023-07-05")[0] == "no list" and bk.lookup("L00", "2023-07-06")[0] == "large" and \
        tm_["AverageMarketCapitalization30Jun2023.xlsx"].startswith("published 2023-07-05") and \
        tm_["AverageMarketCapitalization31Dec2023.csv"].startswith("assumed") and "amfi_published.csv" not in st_ and \
        st_["AverageMarketCapitalization30Jun2023.xlsx"] == "ok" and \
        st_["AverageMarketCapitalization31Dec2022.csv"].startswith("REFUSED: an NSE symbol was found for only") and \
        bk.lookup("L00", "2023-08-01")[0] == "large" and bk.lookup(CW.MOVER, "2023-08-01")[0] == "large" and \
        n3[0] == "large" and n3[2] == 52 and "via ISIN INE999Z01019" in n3[3] and \
        n4[0] == "mid" and n4[2] == 121 and "via ISIN" not in n4[3] and o4[0] == "mid" and "via ISIN" in o4[3] and \
        bk.lookup("NOSUCHCO", "2024-02-01")[0] == "not in list"
    check(ok, "AMFI: an actual publication date (amfi_published.csv) moves a list's start to the next day, others use "
              "the assumed 1 Feb / 1 Aug; Excel with a two-row header is read; a list without NSE symbols is refused; "
              "a renamed company (OLDNAME -> NEWNAME, same ISIN) takes its class from the list in force, found via ISIN")
    empty = TMP / "no_amfi"
    empty.mkdir()
    from tl_run import Workspace
    ws = Workspace(root, "PM_TEST_001", stage_e_any=True, quiet=True)
    cx = C.build_context(ws, "indices", amfi_dir=empty, log=lambda *_: None)
    Xe = cx.pick_context(ws.picks(["D"], "1-3").head(40))
    check((Xe["pre_size_class"] == "no list").all() and Xe["pre_size_class_num"].isna().all(),
          "without AMFI lists the size class is 'no list' / blank on every pick (never filled)")
    # --- exposure ---
    bt = T[T["symbol"] == "BETA15"].iloc[0]
    ok = abs(bt["pre_beta_small"] - 1.5) < 1e-9 and abs(bt["pre_corr_small"] - 1.0) < 1e-9 and bt["pre_home_index"] == "small"
    grp = T["symbol"].str[0]
    reg = T["symbol"].str.match(r"^[LMS]\d\d$")
    acc = {g: float((T.loc[reg & (grp == g), "pre_home_index"] == h).mean()) for g, h in (("L", "nifty"), ("M", "mid"),
                                                                                         ("S", "small"))}
    check(ok and min(acc.values()) >= 0.9, f"beta / correlation: BETA15 (1.5 x Smallcap) -> beta 1.5, correlation 1, "
                                           f"home Smallcap; planted groups found their index {acc}")
    # --- a gap in a stock's bars must not enter beta (v1.2.1: AVALON showed beta 1,152.5 on real data) ---
    from types import SimpleNamespace
    from tl_run import Workspace as WSg
    wsg = WSg(root, "PM_TEST_001", stage_e_any=True, quiet=True)
    cg = C.build_context(wsg, "indices", log=lambda *_: None)
    dsb = wsg.market.series("BETA15")
    # BETA15's bars 130-189, then a 10-session hole, then bars 200-250 at 50x the price: one 50x 'return' across the
    # hole inside the window (BETA15 = exactly 1.5 x Smallcap before its planted drift starts at session 261)
    fake = SimpleNamespace(sym="GAPPY", dates=np.concatenate([dsb.dates[130:190], dsb.dates[200:251]]),
                           c=np.concatenate([dsb.c[130:190], dsb.c[200:251] * 50.0]))
    xg = cg.exposure.of(fake, len(fake.c) - 1) if hasattr(cg, "exposure") else C.Exposure(cg.ib).of(fake, len(fake.c) - 1)
    check(abs(xg["beta_small"] - 1.5) < 1e-9 and abs(xg["corr_small"] - 1.0) < 1e-9 and xg["exposure_days"] == 109,
          f"a 50x jump across a 10-session hole in a stock's bars is left out of beta: beta {xg['beta_small']:.6f}, "
          f"correlation {xg['corr_small']:.6f} from the {xg['exposure_days']} consecutive-session returns (v1.2 let "
          f"such a jump in: AVALON showed beta 1,152.5 on real data)")
    # --- the split by hand (BETA15) ---
    d0 = bt["signal_day"]
    df = pd.read_parquet(root / "BETA15_daily.parquet")
    df.index = _days(df)
    sm = pd.read_parquet(root / "NIFTYSMLCAP250_daily.parquet")
    sm.index = _days(sm)
    pos = list(df.index).index(d0)
    e_day, x_day = df.index[pos + 1], df.index[pos + 5]
    entry, exitp = df.loc[e_day, "open"], df.loc[x_day, "close"]
    hold = sm.loc[x_day, "close"] / sm.loc[e_day, "open"] - 1
    g = exitp / entry - 1
    mkt = bt["pre_beta_home"] * hold
    ok = abs(bt["post_gross_ret"] - g) < 1e-12 and abs(bt["post_hold_small_ret"] - hold) < 1e-12 and \
        abs(bt["post_mkt_part_bp"] - mkt * 1e4) < 1e-6 and abs(bt["post_stock_part_bp"] - (g - mkt) * 1e4) < 1e-6
    held = Dd[np.isfinite(Dd["held_ret"].to_numpy(float)) & np.isfinite(Dd["mkt_part_day_bp"].to_numpy(float))]
    ok2 = np.allclose(held["mkt_part_day_bp"] + held["stock_part_day_bp"], held["held_ret"] * 1e4, atol=1e-8)
    bd = Dd[Dd["trade_id"] == bt["trade_id"]].set_index("session")
    ok3 = abs(bd.loc[1, "held_ret"] - (df.loc[e_day, "close"] / entry - 1)) < 1e-12 and \
        abs(bd.loc[2, "held_ret"] - (df.iloc[pos + 2]["close"] / df.iloc[pos + 1]["close"] - 1)) < 1e-12
    check(ok and ok2 and ok3, f"the split by hand (BETA15): gross {g:+.4%} = market {mkt:+.4%} (1.5 x Smallcap "
                              f"{hold:+.4%} over the same hold) + stock {g - mkt:+.4%} (planted +0.5% a day); each held "
                              f"day's parts add up to the held move")

    # ==================================================================
    print("11. point in time: later bars scrambled; post_* refused; pre_* in filters; rule values by the right day")
    cut = pd.Timestamp(wp["days"][300])
    sc = TMP / "ctx_scrambled"
    scramble_after(root, sc, cut)
    fresh_modules(sc)
    import tl_context as C3
    from tl_run import Workspace as WS3
    ws3 = WS3(sc, "PM_TEST_001", stage_e_any=True, quiet=True)
    c3 = C3.build_context(ws3, "full", TMP / "out_scr", log=lambda *_: None)
    fresh_modules(root)
    import tl_context as C
    from tl_run import Workspace
    ws = Workspace(root, "PM_TEST_001", stage_e_any=True, quiet=True)
    c1 = C.build_context(ws, "full", TMP / "out_pit", log=lambda *_: None)
    F1, F3 = c1.frame.set_index("date"), c3.frame.set_index("date")
    cols = [c for c in F1.columns if c != "weekday"]
    before = F1.index <= cut
    same_before = frames_equal(F1[before], F3[before], cols)
    num = [c for c in cols if F1[c].dtype != object]
    diff_after = not frames_equal(F1[~before], F3[~before], num)
    Tp = ws.picks(["D", "ENS"], "1-10")
    Tp3 = ws3.picks(["D", "ENS"], "1-10")
    X1, X3 = c1.pick_context(Tp), c3.pick_context(Tp3)
    pre = [c for c in X1.columns if c.startswith("pre_")]
    mk = (pd.to_datetime(Tp["signal_day"]) <= cut).to_numpy()
    pre_same = frames_equal(X1[mk].reset_index(drop=True), X3[mk].reset_index(drop=True), pre)
    pre_teeth = not frames_equal(X1[~mk].reset_index(drop=True), X3[~mk].reset_index(drop=True),
                                 [c for c in pre if X1[c].dtype != object])
    need = {"pre_nifty_ret", "pre_small_ret", "pre_nifty_minus_small_20", "pre_ad_ratio_10", "pre_vix_chg5_pct",
            "pre_environment", "pre_high_stress", "pre_prev_environment", "pre_size_class", "pre_amfi_rank",
            "pre_beta_small", "pre_corr_home", "pre_home_index", "pre_stock_minus_home"}
    check(same_before and diff_after and pre_same and pre_teeth and need <= set(pre),
          f"every bar after {cut.date()} scrambled (indices, VIX, every stock): market_days up to it and all {len(pre)} "
          f"pre_* values of the {int(mk.sum()):,} picks up to it unchanged; later ones changed")
    import tl_dictionary as DDc
    tim = {c: (DDc.lookup("trades", c) or ("", "", "", "?"))[3] for c in T.columns}
    ok = all(tim[c] == "pick" for c in T.columns if c.startswith("pre_")) and \
        all(tim[c] == "after" for c in T.columns if c.startswith("post_"))
    check(ok, "the data dictionary marks every pre_* column 'known at the pick' and every post_* column 'after'")
    import tl_backtest as BT
    import tl_sim as SIM
    s1 = TMP / "ctx_filter.py"
    s1.write_text('STRATEGY = {"name": "skip_selloff", "mode": "daily", "max_sessions": 5, "picks": {"engines": ["D"], '
                  '"ranks": [1, 2, 3], "filter": "pre_small_ret > -0.015"}, "entries": [{"name": "open", "size": 1.0, '
                  '"at": "open", "session": 1}], "exits": [{"name": "time", "type": "time", "at": "close", "session": 5}]}\n')
    rc, log = quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                              "--strategy", str(s1), "--no-portfolio"])
    bt_dir = sorted((out / "backtest").glob("TLB_*"))[-1]
    A = pd.read_parquet(bt_dir / "trades.parquet")
    TD = T[(T["engine"] == "D") & T["traded"]]
    exp_f = int((~(TD["pre_small_ret"] > -0.015)).sum())
    check(rc == 0 and int((A["status"] == "filtered").sum()) == exp_f and exp_f > 0,
          f"a filter on pre_small_ret skips exactly the {exp_f} picks whose Smallcap fell 1.5% or more (or is unknown)")
    s2 = TMP / "post_filter.py"
    s2.write_text('STRATEGY = {"name": "cheat", "mode": "daily", "max_sessions": 5, "picks": {"engines": ["D"], '
                  '"ranks": [1], "filter": "post_hold_small_ret > 0"}, "entries": [{"name": "open", "size": 1.0, '
                  '"at": "open", "session": 1}]}\n')
    rc, log = quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                              "--strategy", str(s2)])
    s3 = TMP / "post_rule.py"
    s3.write_text('STRATEGY = {"name": "cheat2", "mode": "daily", "max_sessions": 5, "picks": {"engines": ["D"], '
                  '"ranks": [1]}, "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}], "exits": '
                  '[{"name": "x", "type": "signal", "when": "post_gross_ret > 0.02"}]}\n')
    rc2, log2 = quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                                "--strategy", str(s3)])
    check(rc == 2 and "AFTER the entry" in log and rc2 == 2 and "AFTER the entry" in log2,
          "post_* names (observed after entry) are refused in a filter and in a rule")
    tid = bt["trade_id"]
    rc, log = quiet(SIM.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                               "--trade", tid, "--values", "ad_ratio,env_code,high_stress,vix_chg5_pct,small_prev_ret,"
                               "nifty_minus_small_20,small_day_ret"])
    sim_dir = sorted((out / "sim").glob("TLS_*"))[-1]
    TL = pd.read_csv(sim_dir / f"{tid}__plan_timeline.csv")
    TL["d"] = pd.to_datetime(TL["time"].astype(str).str[:10])
    Mi = M.reset_index()
    prev = dict(zip(Mi["date"].iloc[1:], Mi["small_ret"].iloc[:-1]))
    ok = rc == 0
    for r in TL.to_dict("records"):
        d = r["d"]
        if d not in M.index:
            continue
        mrow = M.loc[d]
        for c, mc in (("ad_ratio", "ad_ratio"), ("env_code", "env_code"), ("high_stress", "high_stress"),
                      ("vix_chg5_pct", "vix_chg5_pct"), ("nifty_minus_small_20", "nifty_minus_small_20"),
                      ("small_day_ret", "small_ret")):
            a_, b_ = float(r[c]), float(mrow[mc])
            ok &= (np.isnan(a_) and np.isnan(b_)) or abs(a_ - b_) < 1e-9
        ok &= abs(float(r["small_prev_ret"]) - prev[d]) < 1e-9
    check(ok and len(TL) >= 6, "rule values in daily mode read the bar's own session (small_prev_ret the session "
                               "before) - recorded bar by bar with --values")
    story = (sim_dir / f"{tid}__plan_story.md").read_text(encoding="utf-8")
    html = (sim_dir / f"{tid}_chart.html").read_text(encoding="utf-8")
    check("The market around the trade" in story and "Split (on the money used)" in story and "Smallcap 250" in html,
          "tl_sim: the story opens with the market around the trade and the split; the chart adds the index panel")

    # ==================================================================
    print("12. research by hand, planted and absent")
    import tl_research as RS
    o = RS.outcome_of(np.array([-500.0, -499.99, 0.0, 0.01, np.nan]))
    check(list(o) == ["severe_loser", "loser", "loser", "winner", ""], "outcome groups: net <= -500 bp severe, <= 0 "
                                                                         "loser, > 0 winner, unknown blank")
    days = np.repeat(np.arange(30), 2)
    vals = np.tile([10.0, -30.0], 30)
    flag = np.tile([False, True], 30)
    d, lo, hi, pv = RS.boot_diff_by_day(days, vals, flag)
    check(abs(d - (-40.0)) < 1e-12 and abs(lo + 40) < 1e-9 and abs(hi + 40) < 1e-9 and pv == 0.0,
          "flagged - unflagged mean net with a block bootstrap: -40 exactly on a constant hand-made set (p = 0)")
    days3 = np.repeat(np.arange(30), 3)
    vals3 = np.tile([10.0, -30.0, -500.0], 30)
    flag3 = np.tile([False, True, False], 30)
    known3 = np.tile([True, True, False], 30)
    d3 = RS.boot_diff_by_day(days3, vals3, flag3, known3)[0]
    d3_old = RS.boot_diff_by_day(days3, vals3, flag3)[0]
    check(abs(d3 - (-40.0)) < 1e-12 and abs(d3_old - (-30.0 + 245.0)) < 1e-9,
          f"blank inputs are left out of the comparison: flagged - known unflagged = {d3:+.0f} bp; counting the blanks "
          f"(all -500 bp) as unflagged, as v1.1 did, would have shown {d3_old:+.0f} bp")
    r = pd.Series([0.01, -0.02, -0.01, 0.03, -0.05, 0.01],
                  index=pd.to_datetime(["2024-01-01", "2024-01-02", "2024-01-03", "2024-01-04", "2024-01-05",
                                        "2024-01-08"]))
    dd, pk, tr = RS.max_dd(r)
    check(abs(dd - (-0.05)) < 1e-12 and str(pk.date()) == "2024-01-04" and str(tr.date()) == "2024-01-05",
          "worst drawdown of the additive book by hand: -5% from 4 Jan to 5 Jan")
    daily = pd.DataFrame({"date": pd.to_datetime(["2024-01-02", "2024-01-03", "2024-01-04", "2024-01-05"]),
                          "ret": [0.01, -0.02, 0.005, -0.01], "pos": [3, 6, 9, 12], "engine": "D"})
    envp = pd.Series(["broad_bullish", "high_stress", "high_stress", "broad_bullish"], index=daily["date"])
    BE = RS.by_environment(daily, envp, "ret", "pos", "engine", additive=True).set_index("environment")
    ok = BE.loc["high_stress", "days"] == 2 and abs(BE.loc["high_stress", "total_return"] - (-0.015)) < 1e-12 and \
        abs(BE.loc["high_stress", "max_drawdown_inside"] - (-0.02)) < 1e-12 and \
        BE.loc["high_stress", "max_positions"] == 9 and abs(BE.loc["broad_bullish", "avg_positions"] - 7.5) < 1e-12
    em = RS.env_prev_map(pd.DataFrame({"date": pd.to_datetime(["2024-01-01", "2024-01-02", "2024-01-03"]),
                                       "environment": ["high_stress", "mixed", ""]}))
    ok &= em.tolist() == ["(unknown)", "high_stress", "mixed"]
    check(ok, "the book by environment by hand (days, total, worst drawdown inside, positions); a day takes the "
              "environment known at the PREVIOUS close")
    # synthetic trade sets: W1 planted (flagged trades lose ~900 bp) vs absent
    rng = np.random.default_rng(5)

    def synth(planted: bool):
        rows, drows = [], []
        days_ = pd.bdate_range("2020-01-01", "2023-12-31")
        for i, d_ in enumerate(days_):
            for k in range(3):
                f = rng.uniform() < 0.15
                net = rng.normal(-900 if (planted and f) else 100, 250)
                tid_ = f"D-{d_:%Y%m%d}-{k + 1}"
                rows.append({"engine": "D", "trade_id": tid_, "signal_day": d_, "net_bp": net,
                             "exit_day": d_ + pd.Timedelta(days=7),
                             "pre_high_stress": 1.0 if f else 0.0, "status": "ok", "traded": True})
                drows.append({"engine": "D", "trade_id": tid_, "date": days_[min(i + 1, len(days_) - 1)],
                              "day_pnl_bp": net})
        T_ = pd.DataFrame(rows)
        T_["outcome"] = RS.outcome_of(T_["net_bp"].to_numpy(float))
        return T_, pd.DataFrame(drows)

    def add_money(Dx):
        """A stand-in money view for these unit tests: the trades' day P&L / 15, compounded from 1."""
        def money(ids, skip=frozenset()):
            X = Dx[Dx["trade_id"].isin(set(ids) - set(skip))]
            if X.empty:
                return None, {}
            r = (X.groupby("date")["day_pnl_bp"].sum() / 1e4 / 15).sort_index()
            eq = (1 + r).cumprod().to_numpy()
            dd = float((eq / np.maximum.accumulate(np.maximum(eq, 1.0)) - 1).min())
            return pd.DataFrame({"date": r.index, "equity": eq}), {"total_return": float(eq[-1] - 1),
                                                                   "max_drawdown": dd}
        return money

    Tp_, Dp_ = synth(True)
    Ta_, Da_ = synth(False)
    WFp = RS.walk_forward(Tp_, add_money(Dp_))
    WVp = RS.walk_verdicts(WFp).set_index("warning")
    WFa = RS.walk_forward(Ta_, add_money(Da_))
    WVa = RS.walk_verdicts(WFa).set_index("warning")
    w1p, w1a = WVp.loc["W1"], WVa.loc["W1"]
    ok = w1p["qualified_years"] == 3 and w1p["verdict"].startswith("CANDIDATE") and w1p["pnl_change_bp"] > 0 and \
        w1p["dd_improved_years"] == 3 and not w1a["verdict"].startswith("CANDIDATE") and \
        (WVp.drop(index=["W1", "ANY"])["verdict"] == "NEVER QUALIFIED").all()
    check(ok, f"walk-forward: a planted sign (flagged trades lose) qualifies in all 3 test years and is a CANDIDATE "
              f"(P&L {w1p['pnl_change_bp']:+,.0f} bp, drawdown better 3/3); the same sign without the effect: "
              f"{w1a['verdict']} ({int(w1a['qualified_years'])}/3); signs without data never qualify")
    T2_ = Tp_.copy()
    m2 = pd.DatetimeIndex(T2_["signal_day"]).year == 2023
    T2_.loc[m2, "net_bp"] = -T2_.loc[m2, "net_bp"]
    T2_["outcome"] = RS.outcome_of(T2_["net_bp"].to_numpy(float))
    WF2 = RS.walk_forward(T2_, add_money(Dp_))
    a_ = WFp[(WFp["test_year"] == 2023) & (WFp["warning"] == "W1")].iloc[0]
    b_ = WF2[(WF2["test_year"] == 2023) & (WF2["warning"] == "W1")].iloc[0]
    check(a_["train_diff_bp"] == b_["train_diff_bp"] and a_["qualified"] == b_["qualified"] and
          a_["test_pnl_change_bp"] != b_["test_pnl_change_bp"],
          "qualification for a year uses earlier years only (flipping that year's outcomes changes its test result, "
          "not its qualification)")
    # purge: trades signalled in December 2022 that exit in January 2023 must not inform 2023's qualification
    cross = (pd.DatetimeIndex(Tp_["signal_day"]).year < 2023) & (pd.DatetimeIndex(Tp_["exit_day"]) >= "2023-01-01")
    T3_ = Tp_.copy()
    T3_.loc[cross, "net_bp"] = -5000.0
    T3_["outcome"] = RS.outcome_of(T3_["net_bp"].to_numpy(float))
    WF3 = RS.walk_forward(T3_, add_money(Dp_))
    c_ = WF3[(WF3["test_year"] == 2023) & (WF3["warning"] == "W1")].iloc[0]
    tr_all = Tp_[pd.DatetimeIndex(Tp_["signal_day"]).year < 2023]
    tr3_all = T3_[pd.DatetimeIndex(T3_["signal_day"]).year < 2023]
    unp = [RS.boot_diff_by_day(X["signal_day"].values, X["net_bp"].to_numpy(float),
                               X["pre_high_stress"].to_numpy() == 1)[0] for X in (tr_all, tr3_all)]
    check(int(cross.sum()) > 0 and a_["train_purged"] == int(cross.sum()) and
          c_["train_diff_bp"] == a_["train_diff_bp"] and c_["train_p"] == a_["train_p"] and unp[0] != unp[1],
          f"purge: the {int(cross.sum())} trades signalled in late Dec 2022 that exit in Jan 2023 are left out of 2023's "
          f"qualification - making them -5,000 bp changes nothing (without the purge, as in v1.1, the training "
          f"difference would move from {unp[0]:+.1f} to {unp[1]:+.1f} bp)")
    rule_ok = all(bool(r_["qualified"]) == bool(r_["train_flagged"] >= 30 and r_["train_flag_days"] >= 20 and
                                               r_["train_p"] <= 0.05 / 8)
                  for r_ in pd.concat([WFp, WFa]).to_dict("records") if r_["warning"] != "ANY")
    check(rule_ok and (WFp.loc[WFp["warning"] != "ANY", "p_needed"] == 0.05 / 8).all(),
          "qualification = >= 30 flagged trades on >= 20 days and a one-sided bootstrap p <= 0.05 / 8 (Bonferroni over "
          "the 8 signs, 10,000 resamples), on every training fold")
    WT = RS.warning_table(Tp_, add_money(Dp_)).set_index("warning")
    w = WT.loc["W1"]
    f = Tp_["pre_high_stress"] == 1
    sev = Tp_["outcome"] == "severe_loser"
    win = Tp_["outcome"] == "winner"
    ok = w["flagged"] == f.sum() and w["severe_caught"] == (f & sev).sum() and w["winners_flagged"] == (f & win).sum() \
        and abs(w["pnl_change_if_skipped_bp"] - (-Tp_.loc[f, "net_bp"].sum())) < 1e-6 and w["book_dd_change"] > 0
    check(ok, "warning-sign table by hand: flagged, severe losers caught, winners flagged, P&L if skipped; skipping "
              "a losing sign shrinks the book's worst drawdown")
    WTx = pd.read_csv(ex / "research" / "warning_signs.csv").set_index(["engine", "warning"])
    w6 = [WTx.loc[(e, "W6")] for e in ("D", "ENS")]
    BK = pd.read_csv(ex / "context_breakdown.csv")
    bk = BK[(BK["dimension"] == "VIX 5-day change at the pick")]
    ok = all(x["diff_hi"] < 0 for x in w6)
    check(ok, f"planted world (drift -0.4%/day after picks made on a Smallcap fall): W6 'Smallcap fell 1.5%' shows in "
              f"both engines (difference D {w6[0]['diff_bp']:+.0f} [{w6[0]['diff_lo']:+.0f}, {w6[0]['diff_hi']:+.0f}] bp)")
    wa = CW.make_ctx_world(TMP / "ctx_absent", "absent", 2, amfi=False)
    fresh_modules(wa["root"])
    import tl_export as Xa
    rc, log = quiet(Xa.main, ["--root", str(wa["root"]), "--pm-run", "PM_TEST_001", "--out", str(TMP / "out_abs"),
                              "--stage-e-any", "--features", "none", "--cards", "0"])
    exa = sorted((TMP / "out_abs" / "export").glob("TLX_*"))[-1]
    WTa = pd.read_csv(exa / "research" / "warning_signs.csv").set_index(["engine", "warning"])
    ts = [tstat(WTa.loc[(e, "W6"), "diff_bp"], WTa.loc[(e, "W6"), "diff_lo"], WTa.loc[(e, "W6"), "diff_hi"])
          for e in ("D", "ENS")]
    Ta = pd.read_parquet(exa / "trades.parquet")
    check(rc == 0 and max(ts) < 3.5 and (Ta["pre_size_class"] == "no list").all(),
          f"absent world (no drift): W6 shows nothing (|t| {max(ts):.2f} < 3.5); no AMFI files -> size 'no list' "
          f"everywhere")

    # ==================================================================
    print("13. integration: dictionary, cards, diary, commands, a world without Midcap / Smallcap / VIX")
    fresh_modules(root)
    import tl_dictionary as DD
    und = pd.read_csv(ex / "data_dictionary.csv")
    undb = pd.read_csv(bt_dir / "data_dictionary.csv")
    check((und["meaning"] != "UNDOCUMENTED").all() and (undb["meaning"] != "UNDOCUMENTED").all() and
          {"trades", "trade_days", "market_days", "context_breakdown", "warning_signs", "walk_forward",
           "book_by_environment"} <= set(und["table"]),
          f"every column of every table is documented ({len(und):,} export + {len(undb):,} backtest columns: meaning, "
          f"unit, when known)")
    cmd = (ex / "cards" / "cards_sample.md").read_text(encoding="utf-8")
    sl = (ex / "research" / "severe_losers.md").read_text(encoding="utf-8")
    diary = (ex / "market_diary.md").read_text(encoding="utf-8")
    rr = (ex / "research" / "research_report.md").read_text(encoding="utf-8")
    import re
    nan_re = re.compile(r"\bnan\b|nan%", re.I)
    check("1. The market before entry" in cmd and "4. Verdict" in cmd and (ex / "cards" / "cards_sample.html").exists()
          and "Warning signs that fired before entry" in sl and not nan_re.search(cmd + sl + rr)
          and diary.count("\n- ") == len(M) and not nan_re.search(diary),
          "cards, severe-loser cards, research report and diary are readable: sections present, one diary line per "
          "session, no 'nan' anywhere")
    rep_md = (ex / "report.md").read_text(encoding="utf-8")
    check("Market context (v1.1)" in rep_md and "Environment labels (declared 24 Oct 2026" in rep_md and
          "known BEFORE entry" in rep_md and "severe" in rep_md,
          "the export report: indices / breadth / AMFI status, the declared definitions, the chain tables")
    import tl_cards as TCd
    rc, log = quiet(TCd.main, ["--export", str(ex), "--worst", "3", "--engine", "D"])
    rc2, log2 = quiet(TCd.main, ["--export", str(ex), "--diary", str(M.index[5].date()), str(M.index[15].date())])
    check(rc == 0 and rc2 == 0 and (ex / "cards" / "cards_worst3.md").exists() and
          len(list((ex / "cards").glob("diary_*.md"))) == 1,
          "tl_cards: --worst 3 writes cards; --diary writes the diary for a date range")
    s0 = json.loads((ex / "research" / "research_summary.json").read_text(encoding="utf-8"))
    rc, log = quiet(RS.main, ["--export", str(ex), "--out", str(out), "--cards", "0", "--root", str(root),
                              "--pm-run", "PM_TEST_001", "--stage-e-any"])
    s1j = json.loads((ex / "research" / "research_summary.json").read_text(encoding="utf-8"))
    check(rc == 0 and s0["verdicts"] == s1j["verdicts"] and s0["declaration"] == s1j["declaration"],
          "tl_research on the export folder reproduces the same verdicts (deterministic, declared definitions)")
    led = [json.loads(x) for x in (out / "tradelab_ledger.jsonl").read_text(encoding="utf-8").splitlines() if x.strip()]
    ev = [x.get("event") for x in led if x.get("tool", "").startswith("tl_research")]
    check(ev[:3] == ["research_declared", "state_research_declared", "research_run"],
          "both research declarations (warning signs; v1.3 stock states) are logged before the result")
    import hashlib
    rec_ = dict(reversed(x.split("  ", 1)) for x in (ex / "outputs.sha256").read_text(encoding="utf-8").splitlines()
                if x.strip())
    now_ = {p.relative_to(ex).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in ex.rglob("*")
            if p.is_file() and p.name != "outputs.sha256"}
    check(rec_ == now_ and "cards/cards_worst3.md" in now_,
          f"after tl_cards and tl_research add or rewrite files, outputs.sha256 still fingerprints all {len(now_)} files")
    s4 = TMP / "plan_dup.py"
    s4.write_text('STRATEGY = {"name": "plan_tiny", "mode": "daily", "max_sessions": 5, "picks": {"engines": ["D", "ENS"],'
                  ' "ranks": [1, 2, 3]}, "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}], '
                  '"exits": [{"name": "time", "type": "time", "at": "close", "session": 5}], '
                  '"portfolio": {"capital": 30000, "allow_duplicates": False}}\n')
    fresh_modules(root)
    import tl_backtest as BT
    rc, log = quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                              "--strategy", str(s4), "--split-date", "2023-09-01"])
    b2 = sorted((out / "backtest").glob("TLB_*"))[-1]
    pdl = pd.read_csv(b2 / "portfolio_daily.csv")
    ptr = pd.read_csv(b2 / "portfolio_trades.csv")
    fl = pd.read_csv(b2 / "fills.csv")
    brp = (b2 / "report.md").read_text(encoding="utf-8")
    mbe = pd.read_csv(b2 / "money_by_environment.csv")
    ok = rc == 0 and "Chronological out-of-sample view (split 2023-09-01)" in brp and \
        set(mbe["environment"]) >= {"broad_bullish"} and "The money by environment" in brp
    check(ok, "backtest: --split-date writes the before / from view; the money by environment is written and reported")
    # open positions by hand: a trade that bought shares is open from its buy day to the day before its sell day
    # (the plan: one buy at the session-1 open, one sell at the session-5 close); one that never bought is never open
    fl = fl[fl["strategy"] == "plan_tiny"].copy()
    fl["day"] = pd.to_datetime(fl["ts"].astype(str).str[:10])
    buy_d = fl[fl["side"] == "buy"].groupby("trade_id")["day"].min()
    sell_d = fl[fl["side"] == "sell"].groupby("trade_id")["day"].max()
    pdays = pd.DatetimeIndex(pd.to_datetime(pdl["date"]))
    exp_open = np.zeros(len(pdays), dtype=int)
    occ: dict = {}
    for r_ in ptr[ptr["bought_rupees"] > 0].itertuples():
        b_, s_ = buy_d[r_.trade_id], sell_d.get(r_.trade_id, pd.NaT)
        m_ = np.asarray(pdays >= b_) & (np.asarray(pdays < s_) if pd.notna(s_) else True)
        exp_open += m_.astype(int)
        occ[r_.symbol] = occ.get(r_.symbol, np.zeros(len(pdays), dtype=int)) + m_.astype(int)
    unf = ptr[(ptr["legs_skipped"] > 0) & (ptr["bought_rupees"] <= 0)]
    ok = np.array_equal(pdl["n_open"].to_numpy(int), exp_open) and max(v.max() for v in occ.values()) <= 1 and \
        len(unf) > 0 and (~unf["opened"].astype(bool)).all() and (unf["skip_reason"] == "cash").all() and \
        ((pdl["invested"] > 0) | (pdl["n_open"] == 0)).all()
    check(ok, f"portfolio with tiny capital and no duplicates: open positions each day = the trades holding shares, "
              f"counted by hand (max {int(exp_open.max())}); no symbol held twice; the {len(unf)} trades cash could not "
              f"fund are 'skipped: cash', never open (v1 kept them open with no shares; fixed)")
    hyp = LAB / "strategies" / "hypo_skip_smallcap_fall.py"
    rc, log = quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                              "--strategy", str(hyp), "--no-portfolio", "--split-date", "2023-09-01"])
    b3 = sorted((out / "backtest").glob("TLB_*"))[-1]
    A3 = pd.read_parquet(b3 / "trades.parquet")
    exp3 = int((TD["pre_small_ret"] <= -0.015).sum())
    check(rc == 0 and int((A3["status"] == "filtered").sum()) == exp3 and exp3 > 0,
          f"the example hypothesis strategy skips exactly the {exp3} D picks flagged by W6 (Smallcap fell 1.5%+)")
    # a world without Midcap / Smallcap / VIX (tradelab v1's test world)
    wv = W.make_world(TMP / "ctx_v1world", "absent", 11)
    fresh_modules(wv["root"])
    import tl_export as Xv
    ov = TMP / "out_v1w"
    rc, log = quiet(Xv.main, ["--root", str(wv["root"]), "--pm-run", "PM_TEST_001", "--out", str(ov), "--stage-e-any",
                              "--features", "none"])
    exv = sorted((ov / "export").glob("TLX_*"))[-1]
    Mv = pd.read_parquet(exv / "market_days.parquet")
    rv = (exv / "report.md").read_text(encoding="utf-8")
    check(rc == 0 and "Missing: Midcap 150, Smallcap 250, India VIX" in rv and
          Mv["missing"].str.contains("mid,small,vix").all() and (Mv["env_direction"].fillna("") == "").all() and
          (exv / "research" / "research_report.md").exists(),
          "a cache without Midcap / Smallcap / VIX: the export still runs; those values and the labels are blank and "
          "named in 'missing' (nothing filled); the research report still writes")
    rc, log = quiet(Xv.main, ["--root", str(wv["root"]), "--pm-run", "PM_TEST_001", "--out", str(ov), "--stage-e-any",
                              "--features", "none", "--context", "none"])
    exn = sorted((ov / "export").glob("TLX_*"))[-1]
    names = {p.name for p in exn.iterdir()}
    Tn = pd.read_parquet(exn / "trades.parquet")
    check(rc == 0 and not (names & {"market_days.parquet", "research", "cards", "context_breakdown.csv"}) and
          not any(c.startswith(("pre_", "post_")) for c in Tn.columns),
          "--context none writes v1's files only (no market columns, no research)")
    import tl_backtest as BTv
    rc, log = quiet(BTv.main, ["--root", str(wv["root"]), "--pm-run", "PM_TEST_001", "--out", str(ov), "--stage-e-any",
                               "--strategy", str(hyp), "--no-portfolio"])
    bv = sorted((ov / "backtest").glob("TLB_*"))[-1]
    Av = pd.read_parquet(bv / "trades.parquet")
    check(rc == 0 and int((Av["status"] == "filtered").sum()) == 0 and Av["pre_small_ret"].isna().all(),
          "without a Smallcap file the same strategy skips nothing: an unknown value is kept, never treated as a fall")
    import tl_sim as SIMv
    tidv = Tn[Tn["traded"] & (Tn["status"] == "ok")]["trade_id"].iloc[40]
    rc, log = quiet(SIMv.main, ["--root", str(wv["root"]), "--pm-run", "PM_TEST_001", "--out", str(ov), "--stage-e-any",
                                "--trade", tidv, "--strategy", str(LAB / "strategies" / "plan_intraday.py"),
                                "--values", "ad_ratio,nifty_prev_ret,small_day_ret"])
    sdv = sorted((ov / "sim").glob("TLS_*"))[-1]
    TLv = pd.read_csv(sdv / f"{tidv}__plan_intraday_timeline.csv")
    TLv["d"] = pd.to_datetime(TLv["time"].astype(str).str[:10])
    Mv["date"] = pd.to_datetime(Mv["date"]).dt.normalize()
    prev_ad = dict(zip(Mv["date"].iloc[1:], Mv["ad_ratio"].iloc[:-1]))
    prev_n = dict(zip(Mv["date"].iloc[1:], Mv["nifty_ret"].iloc[:-1]))
    ok = rc == 0 and len(TLv) > 125 and TLv["small_day_ret"].isna().all()
    for rr_ in TLv.to_dict("records"):
        d = rr_["d"]
        if d in prev_ad:
            ok &= abs(float(rr_["ad_ratio"]) - prev_ad[d]) < 1e-12 and abs(float(rr_["nifty_prev_ret"]) - prev_n[d]) < 1e-12
    check(ok, "intraday mode: breadth and the previous session's NIFTY are those of the session BEFORE each bar's "
              "day; Smallcap's day return is blank intraday (no 3-minute Smallcap index) - never the same day's close")
    import tl_check as K
    rc, log = quiet(K.main, ["--root", str(wv["root"]), "--pm-run", "PM_TEST_001", "--stage-e-any"])
    check(rc == 0 and "CHECK OK" in log and "market context (v1.1)" in log and "NIFTYSMLCAP250   MISSING" in log
          and "WARNINGS" in log, "tl_check lists the index files, the breadth stock count and the AMFI lists; missing "
                                 "indices are warnings, not failures")
    fresh_modules(root)
    import tl_context as Cc
    oc = TMP / "out_ctx_cli"
    r1, l1 = quiet(Cc.main, ["check", "--root", str(root), "--stage-e-any"])
    r2, l2 = quiet(Cc.main, ["build", "--root", str(root), "--out", str(oc), "--stage-e-any"])
    r3, l3 = quiet(Cc.main, ["diary", "--root", str(root), "--out", str(oc), "--stage-e-any", "--from", "2023-03-01",
                             "--to", "2023-03-10"])
    dd_ = sorted((oc / "context").glob("TLD_*"))
    Md = pd.read_parquet(dd_[-1] / "market_days.parquet") if dd_ else pd.DataFrame()
    check(r1 == 0 and "CONTEXT WARNINGS" in l1 and "broken_list" in l1 and r2 == 0 and
          (oc / "context" / "breadth.parquet").exists() and r3 == 0 and len(Md) == 8 and
          "Wed 01 Mar 2023: NIFTY" in l3, "tl_context check / build / diary: inputs listed (a refused list is a warning), "
                                           "breadth saved, an 8-session diary for 1-10 Mar 2023")
    # v1.2: the money view's drawdown starts from the starting capital; research uses the money view
    import tl_portfolio as PF
    dsr = PF.drawdown_series([90.0, 95.0, 100.0, 80.0, 120.0], 100.0)
    Td = pd.DataFrame({"opened": [True], "skip_reason": [""], "legs_trimmed": [0], "legs_skipped": [0],
                       "still_open": [False], "pnl_rupees": [-5.0]})
    dly = pd.DataFrame({"date": ["2024-01-01", "2024-01-02", "2024-01-03"], "equity": [90.0, 85.0, 95.0],
                        "exposure": [0.5, 0.5, 0.5], "day_ret": [-0.10, -0.05556, 0.11765]})
    dly["drawdown"] = PF.drawdown_series(dly["equity"], 100.0)
    st_ = PF._stats(dly, 100.0, Td)
    check(np.allclose(dsr, [-0.10, -0.05, 0.0, -0.20, 0.0]) and abs(st_["max_drawdown"] + 0.15) < 1e-12 and
          st_["dd_peak"] == "start" and st_["dd_recovered"] is None,
          "money-view drawdown starts from the starting capital: Rs 100 -> 90 on day 1 is -10% (v1 / v1.1 showed 0%); "
          "worst -15% from the start, not recovered")
    WTx2 = pd.read_csv(ex / "research" / "warning_signs.csv")
    WFx2 = pd.read_csv(ex / "research" / "walk_forward.csv")
    rr2 = (ex / "research" / "research_report.md").read_text(encoding="utf-8")
    check({"unknown", "diff_p", "book_return", "book_max_dd"} <= set(WTx2.columns) and WTx2["book_max_dd"].notna().all()
          and (WFx2.loc[WFx2["test_year"] == 2024, "train_purged"] == 15).all() and "NOT stage E's execution" in rr2
          and "stage E replay" in rr2 and "test_return_change" in WFx2.columns,
          "export research (v1.2): drawdowns and returns from the plan's money view, blanks counted, 15 trades per "
          "engine purged from 2024's training, the report says it is not stage E's simulator")
