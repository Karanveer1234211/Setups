"""
tests/tl_ctx_world.py - synthetic worlds for tradelab v1.1's market-context tests (nothing here is shipped to
production; nothing on your cache is read or written).

make_ctx_world(root, kind, seed) writes a fake cache with a PLANTED factor structure:
  stocks in three true size groups - L (15), M (20), S (25) - whose daily returns are
      beta x market + loading x (small minus big) + a sector factor (some) + own noise;
  NIFTY50 = equal-weight mean of the L stocks, NIFTYMIDCAP150 = of the M stocks, NIFTYSMLCAP250 = of the S stocks,
  NIFTY500 = all of them, NIFTYBANK / NIFTYIT = sector subsets; INDIAVIX = a mean-reverting level that rises when
  the market falls. Traded value by group, except two 'frenzy' small caps (S03, S07) that trade like large caps and
  one quiet large cap (L14): the traded-value proxy gets these wrong, AMFI's lists get them right.
  BETA15: its daily close-to-close return is exactly 1.5 x Smallcap 250's (beta 1.5, R2 1 by construction); it is
  picked once (D rank 1 on BETA_DAY) and gains a planted +0.5% a day while held.
  MOVER (S20): small cap in the first two AMFI lists, large cap in the last two (point-in-time size test).
  LATE1: listed from session 200 (exposure / size need history).
Also: pick_meta predictions (D and ENS ranks 1-10 from session 130) with the honest plan outcome computed by hand
(tl_world.hand_plan), the panel (the universe), NIFTY 50's 3-minute bars, AMFI lists as CSV / Excel / two PDFs, and
one corrupt list that must be refused.
kind:
  'planted' - after a pick (ranks 1-3 of either engine) the stock drifts +A a day (open to close) for 5 sessions when
              Smallcap's pick-day return was > -0.5%, and -A a day otherwise
  'absent'  - no drift after picks
"""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import tl_world as W  # noqa: E402

IST = "Asia/Kolkata"
NB = 125
GROUPS = {"L": 15, "M": 20, "S": 25}
FRENZY = ("S03", "S07")
QUIET = ("L14",)
MOVER = "S20"
BETA_DAY = 260
A_DRIFT = 0.004
LATE_START = 200
PICK_FROM = 130
PROXY_TOPS = (15, 35)          # the tests shrink the proxy's cut-offs (100 / 250) to this world's 62 stocks


def _ohlc(rng, P, r, gap, sig):
    o = P * (1 + gap)
    c = P * (1 + r)
    h = np.maximum(o, c) * (1 + np.abs(rng.normal(0, 0.3 * sig, np.shape(P))))
    l = np.minimum(o, c) * (1 - np.abs(rng.normal(0, 0.3 * sig, np.shape(P))))
    return o, h, l, c


def make_ctx_world(root, kind: str = "planted", seed: int = 1, n_days: int = 420, amfi: bool = True,
                   extra_amfi: bool = True) -> dict:
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    W.write_mods(root)
    rng = np.random.default_rng(seed)
    days = pd.bdate_range("2022-07-01", periods=n_days)
    names = [f"{g}{k:02d}" for g, n in GROUPS.items() for k in range(n)]
    group = {s: s[0] for s in names}
    allsyms = names + ["BETA15", "LATE1"]
    ns = len(allsyms)
    col = {s: j for j, s in enumerate(allsyms)}
    bm = np.array([{"L": 1.0, "M": 1.0, "S": 1.1}.get(group.get(s, "S"), 1.0) for s in allsyms])
    ls = np.array([{"L": 0.0, "M": 0.5, "S": 1.0}.get(group.get(s, "S"), 1.0) for s in allsyms])
    se = np.array([{"L": 0.008, "M": 0.012, "S": 0.016}.get(group.get(s, "S"), 0.016) for s in allsyms])
    bank = [col[s] for s in ("L00", "L01", "L02", "L03", "L04")]
    itg = [col[s] for s in ("M00", "M01", "M02", "M03")]
    mem = {g: [col[s] for s in names if group[s] == g] for g in GROUPS}
    C = np.full((n_days, ns), np.nan)
    O, H, L_, V = (np.full((n_days, ns), np.nan) for _ in range(4))
    alpha = np.zeros((n_days + 10, ns))
    idx = {k: np.full((n_days, 4), np.nan) for k in ("NIFTY50", "NIFTYMIDCAP150", "NIFTYSMLCAP250", "NIFTY500",
                                                    "NIFTYBANK", "NIFTYIT")}
    lvl = {"NIFTY50": 18000.0, "NIFTYMIDCAP150": 11000.0, "NIFTYSMLCAP250": 9000.0, "NIFTY500": 15000.0,
           "NIFTYBANK": 42000.0, "NIFTYIT": 30000.0}
    vix = np.full(n_days, np.nan)
    v_prev = 15.0
    P = rng.uniform(80, 1500, ns)
    tvmu = np.array([{"L": 23.0, "M": 21.0, "S": 19.0}.get(group.get(s, "S"), 19.0) for s in allsyms])
    for s in FRENZY:
        tvmu[col[s]] = 23.5
    for s in QUIET:
        tvmu[col[s]] = 19.5
    picks = []
    small_ret = np.full(n_days, np.nan)
    pool = [s for s in names + ["LATE1"]]
    for t in range(n_days):
        fm, fs = rng.normal(0.0004, 0.009), rng.normal(0.0, 0.006)
        fb, fi = rng.normal(0, 0.006), rng.normal(0, 0.007)
        e = rng.normal(0, 1, ns) * se
        r = bm * fm + ls * fs + e
        r[bank] += fb
        r[itg] += fi
        gap = 0.4 * r + rng.normal(0, 0.2, ns) * se          # the overnight part of the day's move
        a = alpha[t]
        live = np.ones(ns, dtype=bool)
        live[col["LATE1"]] = t >= LATE_START
        # indices: equal-weight means of their members' (pre-drift) day returns and gaps
        gm = {"NIFTY50": mem["L"], "NIFTYMIDCAP150": mem["M"], "NIFTYSMLCAP250": mem["S"],
              "NIFTY500": mem["L"] + mem["M"] + mem["S"], "NIFTYBANK": bank, "NIFTYIT": itg}
        ir = {}
        for k, m_ in gm.items():
            rr = float(np.mean(r[m_] + a[m_]))
            gg = float(np.mean(gap[m_]))
            Pk = lvl[k]
            o_, c_ = Pk * (1 + gg), Pk * (1 + rr)
            h_ = max(o_, c_) * (1 + abs(rng.normal(0, 0.002)))
            l_ = min(o_, c_) * (1 - abs(rng.normal(0, 0.002)))
            idx[k][t] = (o_, h_, l_, c_)
            lvl[k] = c_
            ir[k] = rr
        small_ret[t] = ir["NIFTYSMLCAP250"]
        # BETA15: exactly 1.5 x Smallcap's close-to-close return (+ its planted drift while held)
        jb = col["BETA15"]
        r[jb] = 1.5 * small_ret[t]
        gap[jb] = 1.5 * float(np.mean(gap[mem["S"]]))
        o, h, l, c = _ohlc(rng, P, r + a, gap, se)
        O[t], H[t], L_[t], C[t] = o, h, l, c
        V[t] = np.exp(rng.normal(tvmu, 0.25)) / c
        for j in np.flatnonzero(~live):
            O[t, j] = H[t, j] = L_[t, j] = C[t, j] = V[t, j] = np.nan
        P = np.where(live, c, P)
        v_prev = max(9.0, 15 + 0.95 * (v_prev - 15) - 150 * fm + rng.normal(0, 0.4))
        vix[t] = v_prev
        # picks made at this close
        if PICK_FROM <= t < n_days - 3:
            for eng in ("D", "ENS"):
                cand = [s for s in pool if s != "LATE1" or t >= LATE_START + 130]
                ch = list(rng.choice(cand, size=10, replace=False))
                if eng == "D" and t == BETA_DAY:
                    ch[0] = "BETA15"
                for rk, s in enumerate(ch, start=1):
                    picks.append((eng, t, s, rk))
                    if rk <= 3 and (s != "BETA15") and kind == "planted":
                        sgn = 1.0 if small_ret[t] > -0.005 else -1.0
                        alpha[t + 1:t + 6, col[s]] += sgn * A_DRIFT
            if t == BETA_DAY:
                alpha[t + 1:t + 6, col["BETA15"]] += 0.005
    daily: Dict[str, pd.DataFrame] = {}
    for s, j in col.items():
        df = pd.DataFrame({"open": O[:, j], "high": H[:, j], "low": L_[:, j], "close": C[:, j], "volume": V[:, j]})
        df["timestamp"] = days.tz_localize(IST)
        df = df[["timestamp", "open", "high", "low", "close", "volume"]].dropna(subset=["close"]).reset_index(drop=True)
        daily[s] = df
    for k, a4 in idx.items():
        df = pd.DataFrame({"timestamp": days.tz_localize(IST), "open": a4[:, 0], "high": a4[:, 1], "low": a4[:, 2],
                           "close": a4[:, 3], "volume": np.nan})
        daily[k] = df
    daily["INDIAVIX"] = pd.DataFrame({"timestamp": days.tz_localize(IST), "open": vix * 1.01, "high": vix * 1.03,
                                      "low": vix * 0.97, "close": vix, "volume": np.nan})
    for s, df in daily.items():
        df.to_parquet(root / f"{s}_daily.parquet", index=False)
    # NIFTY 50 3-minute bars (from its daily bars: low first on odd days, high first on even days)
    n = daily["NIFTY50"]
    Ob = np.empty((n_days, NB)); Hb = np.empty((n_days, NB)); Lb = np.empty((n_days, NB)); Cb = np.empty((n_days, NB))
    for i in range(n_days):
        o, h, l, c = n.loc[i, ["open", "high", "low", "close"]]
        knots = [o, l, h, c] if i % 2 else [o, h, l, c]
        path = np.interp(np.linspace(0, 1, NB + 1), [0, 0.3, 0.6, 1.0], knots)
        Ob[i], Cb[i] = path[:-1], path[1:]
        Hb[i], Lb[i] = np.maximum(Ob[i], Cb[i]), np.minimum(Ob[i], Cb[i])
    idir = root / "intraday_3m"
    idir.mkdir(exist_ok=True)
    offs = pd.to_timedelta(9 * 60 + 15 + 3 * np.arange(NB), unit="m")
    ts = (days.values[:, None] + offs.values[None, :]).reshape(-1)
    pd.DataFrame({"timestamp": pd.DatetimeIndex(ts).tz_localize(IST), "open": Ob.reshape(-1), "high": Hb.reshape(-1),
                  "low": Lb.reshape(-1), "close": Cb.reshape(-1), "volume": 0.0}).to_parquet(
        idir / "NIFTY 50_3m.parquet", index=False)
    _predictions(root, days, picks, daily)
    _panel(root, days, allsyms, daily)
    files = []
    if amfi:
        files = write_amfi(root / "sectors" / "amfi", extra=extra_amfi)
    return {"root": root, "days": days, "names": names, "allsyms": allsyms, "daily": daily, "picks": picks,
            "kind": kind, "small_ret": small_ret, "group": group, "amfi_files": files}


def _predictions(root: Path, days, picks, daily) -> None:
    ns_: dict = {}
    import textwrap
    exec(textwrap.dedent(W.STAGE_E_STANDIN), ns_)
    lock = ns_["lower_locked"]
    rows = []
    pos = {s: {d: i for i, d in enumerate(pd.DatetimeIndex(df["timestamp"]).tz_convert(IST).tz_localize(None).normalize())}
           for s, df in daily.items()}
    for eng, t, s, rk in picks:
        d = days[t]
        df = daily[s].reset_index(drop=True)
        i = pos[s].get(d)
        hp = W.hand_plan(df, i, lock) if i is not None else {"status": "pending", "net": np.nan, "mfe": np.nan,
                                                              "mae": np.nan}
        rows.append({"engine": eng, "signal_day": d, "symbol": s, "rank": rk, "score": 1 - rk / 20,
                     "fold": float(d.year), "status": hp["status"], "net": hp["net"], "mfe": hp["mfe"],
                     "mae": hp["mae"], "s_atr14": 0.03, "prob_big": 0.5,
                     "entry_day": days[min(t + 1, len(days) - 1)], "exit_day": days[min(t + 5, len(days) - 1)]})
    Pm = pd.DataFrame(rows)
    rdir = root / "research2" / "pick_meta" / "PM_TEST_001"
    rdir.mkdir(parents=True, exist_ok=True)
    Pm.to_parquet(rdir / "predictions.parquet", index=False)
    sha = hashlib.sha256((rdir / "predictions.parquet").read_bytes()).hexdigest()
    (rdir / "outputs.sha256").write_text(f"{sha}  predictions.parquet\n", encoding="utf-8")


def _panel(root: Path, days, syms, daily) -> None:
    parts = []
    for s in syms:
        df = daily[s]
        t = pd.DatetimeIndex(df["timestamp"])
        parts.append(pd.DataFrame({"timestamp": t, "symbol": s, "D_rsi14": 50.0 + np.tanh(df["close"].pct_change().fillna(0) * 30) * 20,
                                   "D_atr_pct": 2.0, "close": df["close"].to_numpy(float), "label_exit_ret": 0.0}))
    Pn = pd.concat(parts, ignore_index=True)
    d = root / "panel_oc"
    d.mkdir(exist_ok=True)
    Pn.to_parquet(d / "panel.parquet", index=False)


# ----------------------------------------------------------------------
# AMFI lists
# ----------------------------------------------------------------------
TITLE = "Average Market Capitalization of listed companies during the six months ended {d}"
HEADER = ["Sr. No.", "Company name", "ISIN", "BSE Symbol", "BSE 6 month Avg Total Market Cap in (Rs. Crs.)",
          "NSE Symbol", "NSE 6 month Avg Total Market Cap (Rs. Crs.)", "MSEI Symbol",
          "MSEI 6 month Avg Total Market Cap in (Rs Crs.)", "Average of All Exchanges (Rs. Cr.)",
          "Categorization as per SEBI Circular dated Oct 6, 2017"]


def amfi_truth(list_no: int) -> Dict[str, int]:
    """symbol -> AMFI rank in list 1..4 of the world (true groups; MOVER is small in lists 1-2, large in 3-4)."""
    out = {}
    for k in range(GROUPS["L"]):
        out[f"L{k:02d}"] = 3 + 6 * k                     # ranks 3..87  (large)
    for k in range(GROUPS["M"]):
        out[f"M{k:02d}"] = 105 + 7 * k                   # ranks 105..238 (mid)
    for k in range(GROUPS["S"]):
        out[f"S{k:02d}"] = 255 + k                       # ranks 255..279 (small)
    out["BETA15"] = 290
    if list_no >= 3:
        out[MOVER] = 50                                  # promoted to large cap
        out["LATE1"] = 143                               # listed: mid cap
    return out


def amfi_rows(list_no: int, n: int = 300, corrupt: bool = False) -> List[list]:
    truth = amfi_truth(list_no)
    by_rank = {r: s for s, r in truth.items()}
    rows = []
    for r in range(1, n + 1):
        s = by_rank.get(r, f"FILL{list_no}{r:04d}")
        cat = "Large Cap" if r <= 100 else ("Mid Cap" if r <= 250 else "Small Cap")
        if corrupt and r % 3 == 0:
            cat = "Small Cap" if cat != "Small Cap" else "Large Cap"
        mc = 900000.0 / r
        name = f"{s.title()} Industries Ltd" if r % 17 else f"{s.title()} Very Long Name Holdings And Investments Ltd"
        isin = f"INE{list_no:01d}{r:05d}01{r % 10}"
        bse = "" if r % 23 == 0 else s                  # some companies are NSE-only
        rows.append([r, name, isin, bse, f"{mc * 1.001:,.2f}" if bse else "", s, f"{mc:,.2f}", "", "", f"{mc:,.2f}", cat])
    return rows


def write_amfi(d: Path, extra: bool = True) -> List[str]:
    d.mkdir(parents=True, exist_ok=True)
    files = []
    # list 1: CSV with a title row (half-year ended 30 June 2022)
    rows = amfi_rows(1)
    with open(d / "amfi_list_A.csv", "w", encoding="utf-8", newline="") as f:
        import csv
        w = csv.writer(f)
        w.writerow([TITLE.format(d="30 June 2022")])
        w.writerow([])
        w.writerow(HEADER)
        w.writerows(rows)
    files.append("amfi_list_A.csv")
    # list 2: Excel (half-year ended 31 December 2022, from the file name)
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["Average Market Capitalization of listed companies"])
    ws.append([])
    ws.append(HEADER)
    for r in amfi_rows(2):
        ws.append(r)
    wb.save(d / "AverageMarketCapitalization31Dec2022.xlsx")
    files.append("AverageMarketCapitalization31Dec2022.xlsx")
    # lists 3 and 4: PDF (title in the text; list 4's period only in the file name style AMFI uses)
    _pdf(d / "Average Market Capitalisation of Listed Companies during Jan - Jun 2023.pdf", amfi_rows(3),
         "Average Market Capitalisation of Listed Companies during Jan - Jun 2023")
    files.append("Average Market Capitalisation of Listed Companies during Jan - Jun 2023.pdf")
    _pdf(d / "AverageMarketCapitalizationoflistedcompaniesduringthesixmonthsended31Dec2023.pdf", amfi_rows(4),
         TITLE.format(d="31 December 2023"))
    files.append("AverageMarketCapitalizationoflistedcompaniesduringthesixmonthsended31Dec2023.pdf")
    if extra:
        rows = amfi_rows(1, corrupt=True)
        with open(d / "broken_list_ended_30_June_2021.csv", "w", encoding="utf-8", newline="") as f:
            import csv
            w = csv.writer(f)
            w.writerow([TITLE.format(d="30 June 2021")])
            w.writerow(HEADER)
            w.writerows(rows)
        files.append("broken_list_ended_30_June_2021.csv")
    return files


def _pdf(path: Path, rows: List[list], title: str) -> None:
    """A PDF laid out like AMFI's: a title, the header on each page, one row per line (long names wrap)."""
    from reportlab.lib.pagesizes import landscape, A4
    from reportlab.pdfgen import canvas
    cv = canvas.Canvas(str(path), pagesize=landscape(A4))
    Wd, Ht = landscape(A4)
    xs = [20, 50, 230, 310, 380, 450, 520, 590, 640, 700, 770]
    y = Ht - 30

    def header():
        nonlocal y
        cv.setFont("Helvetica-Bold", 8)
        cv.drawString(20, y, title)
        y -= 14
        cv.setFont("Helvetica", 5)
        for x, h in zip(xs, HEADER):
            cv.drawString(x, y, h[:18])
        y -= 10
        cv.setFont("Helvetica", 6)

    header()
    for r in rows:
        name = str(r[1])
        wrap = len(name) > 34
        cells = [str(c) for c in r]
        if wrap and int(r[0]) % 2 == 0:
            # the name wraps BEFORE the ISIN: rank + first part on one line, the rest of the row on the next
            cv.drawString(xs[0], y, cells[0])
            cv.drawString(xs[1], y, name[:34])
            y -= 8
            cv.drawString(xs[1], y, name[34:])
            for x, c in zip(xs[2:], cells[2:]):
                if c:
                    cv.drawString(x, y, c)
        else:
            cells[1] = name[:34] if wrap else name
            for x, c in zip(xs, cells):
                if c:
                    cv.drawString(x, y, c)
            if wrap:                                       # the name's tail on the next line, after the row
                y -= 8
                cv.drawString(xs[1], y, name[34:])
        y -= 9
        if y < 30:
            cv.showPage()
            y = Ht - 30
            header()
    cv.save()
