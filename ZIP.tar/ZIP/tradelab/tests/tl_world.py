"""
tests/tl_world.py - synthetic worlds for tradelab's tests (nothing here is shipped to production).

make_world(root, kind, seed) writes a fake cache under `root`:
  <SYM>_daily.parquet (+ NIFTY50), intraday_3m\\<SYM>_3m.parquet (125 bars a session, Kite-style IST stamps),
  panel_oc\\panel.parquet (features + labels + raw levels, to test the firewall),
  research2\\pick_meta\\PM_TEST_001\\predictions.parquet + outputs.sha256 (D and ENS top 10 per day, the recorded
  honest plan outcome computed by an INDEPENDENT hand implementation below).
and stand-in production modules (stage_e_execution, intraday_cache, data_quality) under root\\_mods.

kind:
  'planted'  - 3-minute drift +mu while the last close is above the session VWAP, -mu while below
               (a VWAP reclaim is followed by gains): '20% at open + 80% on a VWAP cross' must beat the plan
  'absent'   - no drift (a martingale): no entry timing can help on average (fill fairness)
  'reverse'  - drift -mu above VWAP, +mu below (reclaims fail): the VWAP strategy must lose to the plan
Bars are built from sub-steps (Brownian-bridge highs and lows), never straight lines (the BIGMOVE lesson).
Special symbols with hand-built paths: LOCKSYM (5th close locked, 6th open locked, 7th open free), STUCKSYM
(locked for 25 sessions), GAPSYM (opens below a stop), AMBSYM (a stop and a target inside one daily bar; the
3-minute bars reach the target first).
"""
from __future__ import annotations

import json
import sys
import textwrap
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd

IST = "Asia/Kolkata"
NB = 125
COST = 0.0035

STAGE_E_STANDIN = '''
"""TEST STAND-IN for stage_e_execution (load_bars, lower_locked) - NOT the production file."""
from pathlib import Path
import numpy as np
import pandas as pd
CODE_VERSION = "stage_e_execution TEST STAND-IN"
BANDS = (0.02, 0.05, 0.10, 0.20)
UTC_STAMPS = False


class Bars:
    def __init__(self, ts, o, h, l, c, v, extra=None):
        self.ts, self.o, self.h, self.l, self.c, self.v = ts, o, h, l, c, v
        self.extra = extra or {}


def load_bars(root, syms):
    out = {}
    for s in syms:
        p = Path(root) / f"{s}_daily.parquet"
        if not p.exists():
            continue
        df = pd.read_parquet(p)
        t = pd.to_datetime(df["timestamp"])
        if UTC_STAMPS:
            ts = t.dt.tz_convert("UTC").dt.tz_localize(None).values.astype("datetime64[ns]")
        else:
            ts = t.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None).values.astype("datetime64[ns]")
        out[s] = Bars(ts, *(df[k].to_numpy(float) for k in ("open", "high", "low", "close", "volume")))
    return out


def band_down(price, prev):
    for b in BANDS:
        if abs(price - round(prev * (1 - b), 2)) <= 0.011:
            return True
    return False


def lower_locked(b, j, side):
    if j <= 0:
        return False
    prev = b.c[j - 1]
    if side == "close":
        return bool(band_down(b.c[j], prev) and b.c[j] <= b.l[j] * (1 + 1e-9))
    return bool(band_down(b.o[j], prev) and b.o[j] <= b.l[j] * (1 + 1e-9))
'''

INTRADAY_STANDIN = '''
"""TEST STAND-IN for intraday_cache (store, BAR_MIN, path_for) - NOT the production file."""
from pathlib import Path
CODE_VERSION = "intraday_cache TEST STAND-IN"
BAR_MIN = 3


def store(root):
    return Path(root) / "intraday_3m"


def path_for(root, sym):
    return store(root) / f"{sym}_3m.parquet"
'''

DQ_STANDIN = '''
"""TEST STAND-IN for data_quality._paths - NOT the production file."""
from pathlib import Path
CACHE_SUFFIX = "_daily"


def _paths(root, symbol):
    root = Path(root)
    return (root / f"{symbol}{CACHE_SUFFIX}.parquet", root / f"{symbol}{CACHE_SUFFIX}.ok.json")
'''


def write_mods(root: Path) -> Path:
    d = Path(root) / "_mods"
    d.mkdir(parents=True, exist_ok=True)
    (d / "stage_e_execution.py").write_text(textwrap.dedent(STAGE_E_STANDIN), encoding="utf-8")
    (d / "intraday_cache.py").write_text(textwrap.dedent(INTRADAY_STANDIN), encoding="utf-8")
    (d / "data_quality.py").write_text(textwrap.dedent(DQ_STANDIN), encoding="utf-8")
    return d


def use_mods(root: Path) -> None:
    """Put the stand-ins first on sys.path and forget any previously imported copies."""
    d = str(Path(root) / "_mods")
    for m in ("stage_e_execution", "intraday_cache", "data_quality"):
        sys.modules.pop(m, None)
    if d in sys.path:
        sys.path.remove(d)
    sys.path.insert(0, d)


# ----------------------------------------------------------------------
# path generation
# ----------------------------------------------------------------------
def _sessions_3m(rng, n_sess: int, p0: float, kind: str, mu: float, sig: float, sub: int = 6):
    """3-minute OHLCV for n_sess sessions of one stock. Sessions are simulated in parallel in relative terms
    (the VWAP state is scale-free), then chained: each open = previous close x an overnight gap.
    planted: drift -mu until the session's first VWAP reclaim (a close crossing above the VWAP from 09:30), +mu after.
    reverse: +mu before the first reclaim, -mu after. absent: no drift."""
    V = rng.lognormal(10, 0.5, size=(n_sess, NB))
    O = np.empty((n_sess, NB)); H = np.empty((n_sess, NB)); L = np.empty((n_sess, NB)); C = np.empty((n_sess, NB))
    rel = np.ones(n_sess)
    pvs = np.zeros(n_sess); vvs = np.zeros(n_sess)
    crossed = np.zeros(n_sess, dtype=bool)
    prev_c = prev_vw = None
    sign = 1.0 if kind == "planted" else -1.0
    for b in range(NB):
        if kind == "absent":
            drift = np.zeros(n_sess)
        else:
            drift = np.where(crossed, mu, -mu) * sign
        steps = rng.normal(0.0, sig / np.sqrt(sub), (n_sess, sub)) + (drift / sub)[:, None]
        path = rel[:, None] * np.exp(np.cumsum(steps, axis=1))
        bo = rel
        bh = np.maximum(bo, path.max(axis=1))
        bl = np.minimum(bo, path.min(axis=1))
        bc = path[:, -1]
        O[:, b], H[:, b], L[:, b], C[:, b] = bo, bh, bl, bc
        tp = (bh + bl + bc) / 3
        pvs += tp * V[:, b]
        vvs += V[:, b]
        vw = pvs / vvs
        if prev_c is not None and b >= 5:
            crossed |= (bc > vw) & (prev_c <= prev_vw)
        prev_c, prev_vw = bc, vw
        rel = bc
    gaps = rng.normal(0, 0.012, n_sess)
    log_o = np.log(p0) + np.cumsum(gaps) + np.r_[0.0, np.cumsum(np.log(C[:-1, -1]))]
    scale = np.exp(log_o)[:, None]
    return O * scale, H * scale, L * scale, C * scale, V


def make_world(root, kind: str = "absent", seed: int = 1, n_syms: int = 16, n_days: int = 260,
               mu: float = 0.0004, sig: float = 0.003, with_special: bool = True) -> dict:
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    write_mods(root)
    rng = np.random.default_rng(seed)
    days = pd.bdate_range("2023-01-02", periods=n_days)
    names = [f"S{k:02d}" for k in range(n_syms)]
    bars3: Dict[str, tuple] = {}
    daily: Dict[str, pd.DataFrame] = {}
    for s in names:
        O, H, L, C, V = _sessions_3m(rng, n_days, float(rng.uniform(80, 900)), kind, mu, sig)
        bars3[s] = (O, H, L, C, V)
        daily[s] = pd.DataFrame({"open": O[:, 0], "high": H.max(1), "low": L.min(1), "close": C[:, -1],
                                 "volume": V.sum(1)})
    # NIFTY50: daily only (plus a 3-minute file to test the intraday NIFTY values)
    On, Hn, Ln, Cn, Vn = _sessions_3m(rng, n_days, 18000.0, "absent", 0.0, 0.0015)
    daily["NIFTY50"] = pd.DataFrame({"open": On[:, 0], "high": Hn.max(1), "low": Ln.min(1), "close": Cn[:, -1],
                                     "volume": np.nan})
    bars3["NIFTY 50"] = (On, Hn, Ln, Cn, Vn * 0)
    special = {}
    if with_special:
        special = _special(rng, days, daily, bars3)
    # write daily files
    for s, df in daily.items():
        out = df.copy()
        out.insert(0, "timestamp", days.tz_localize(IST))
        out.to_parquet(root / f"{s}_daily.parquet", index=False)
    # 3-minute files
    idir = root / "intraday_3m"
    idir.mkdir(exist_ok=True)
    offs = pd.to_timedelta(9 * 60 + 15 + 3 * np.arange(NB), unit="m")
    for s, (O, H, L, C, V) in bars3.items():
        ts = (days.values[:, None] + offs.values[None, :]).reshape(-1)
        df = pd.DataFrame({"timestamp": pd.DatetimeIndex(ts).tz_localize(IST), "open": O.reshape(-1),
                           "high": H.reshape(-1), "low": L.reshape(-1), "close": C.reshape(-1),
                           "volume": V.reshape(-1)})
        df.to_parquet(idir / f"{s}_3m.parquet", index=False)
    picks = _picks(rng, days, names + list(special), daily, root)
    _panel(rng, days, names + list(special), daily, root)
    return {"root": root, "days": days, "names": names, "special": special, "daily": daily, "bars3": bars3,
            "picks": picks, "kind": kind}


def _special(rng, days, daily, bars3) -> dict:
    """Hand-built symbols. Each is a flat-ish walk with planted features at known sessions after a signal day."""
    n = len(days)
    out = {}

    def base(p0):
        c = p0 * np.exp(np.cumsum(rng.normal(0, 0.004, n)))
        o = np.r_[p0, c[:-1]] * np.exp(rng.normal(0, 0.001, n))
        h = np.maximum(o, c) * (1 + rng.uniform(0.002, 0.01, n))
        l = np.minimum(o, c) * (1 - rng.uniform(0.002, 0.01, n))
        return pd.DataFrame({"open": o, "high": h, "low": l, "close": c, "volume": rng.lognormal(12, 0.3, n)})

    def bars_from_daily(df):
        """3-minute bars consistent with each daily bar: open first, then the high and low, close last."""
        O = np.empty((n, NB)); H = np.empty((n, NB)); L = np.empty((n, NB)); C = np.empty((n, NB))
        for i in range(n):
            o, h, l, c = df.iloc[i][["open", "high", "low", "close"]]
            path = np.interp(np.linspace(0, 1, NB + 1), [0, 0.3, 0.6, 1.0], [o, h, l, c]) if (i % 2) else \
                np.interp(np.linspace(0, 1, NB + 1), [0, 0.3, 0.6, 1.0], [o, l, h, c])
            O[i] = path[:-1]
            C[i] = path[1:]
            H[i] = np.maximum(O[i], C[i])
            L[i] = np.minimum(O[i], C[i])
        return O, H, L, C, np.full((n, NB), 1000.0)

    # LOCKSYM: signal day index 100; session 5 close locked, session 6 open locked, session 7 open free
    s0 = 100
    d = base(500.0)
    prev = d.loc[s0 + 4, "close"]
    lock_c = round(prev * 0.95, 2)
    d.loc[s0 + 5, ["low", "close"]] = [lock_c, lock_c]
    d.loc[s0 + 5, "open"] = max(d.loc[s0 + 5, "open"], lock_c)
    d.loc[s0 + 5, "high"] = max(d.loc[s0 + 5, "high"], d.loc[s0 + 5, "open"])
    lock_o = round(lock_c * 0.95, 2)
    d.loc[s0 + 6, ["open", "low"]] = [lock_o, lock_o]
    d.loc[s0 + 6, "close"] = lock_o * 1.01
    d.loc[s0 + 6, "high"] = lock_o * 1.02
    d.loc[s0 + 7, "open"] = d.loc[s0 + 6, "close"] * 1.003
    d.loc[s0 + 7, "high"] = max(d.loc[s0 + 7, "high"], d.loc[s0 + 7, "open"])
    d.loc[s0 + 7, "low"] = min(d.loc[s0 + 7, "low"], d.loc[s0 + 7, "open"])
    daily["LOCKSYM"] = d
    bars3["LOCKSYM"] = bars_from_daily(d)
    out["LOCKSYM"] = {"signal": s0}
    # STUCKSYM: locked from session 5 for 25 sessions (each close and open on the band)
    d = base(300.0)
    for k in range(5, 31):
        prev = d.loc[s0 + k - 1, "close"]
        v = round(prev * 0.98, 2)
        d.loc[s0 + k, ["open", "high", "low", "close"]] = [v, v, v, v]
    daily["STUCKSYM"] = d
    bars3["STUCKSYM"] = bars_from_daily(d)
    out["STUCKSYM"] = {"signal": s0}
    # GAPSYM: entry at 1000; session 2 opens at 930 (below a 5% stop at 950)
    s1 = 140
    d = base(1000.0)
    d.loc[s1 + 1, ["open", "high", "low", "close"]] = [1000.0, 1012.0, 992.0, 1000.0]
    d.loc[s1 + 2, ["open", "high", "low", "close"]] = [930.0, 940.0, 920.0, 935.0]
    daily["GAPSYM"] = d
    bars3["GAPSYM"] = bars_from_daily(d)
    out["GAPSYM"] = {"signal": s1}
    # AMBSYM: entry 100; session 2 range 94..108 (both a 95 stop and a 106 target); 3-minute bars reach 108 first
    d = base(100.0)
    d.loc[s1 + 1, ["open", "high", "low", "close"]] = [100.0, 101.5, 99.0, 100.5]
    d.loc[s1 + 2, ["open", "high", "low", "close"]] = [100.5, 108.0, 94.0, 97.0]
    daily["AMBSYM"] = d
    O, H, L, C, V = bars_from_daily(d)
    i = s1 + 2
    path = np.interp(np.linspace(0, 1, NB + 1), [0, 0.3, 0.6, 1.0], [100.5, 108.0, 94.0, 97.0])   # high first
    O[i], C[i] = path[:-1], path[1:]
    H[i], L[i] = np.maximum(O[i], C[i]), np.minimum(O[i], C[i])
    bars3["AMBSYM"] = (O, H, L, C, V)
    out["AMBSYM"] = {"signal": s1}
    # HANDSYM: every price around signal index 180 written by hand (see HAND below) for exact checks
    s2 = 180
    d = base(100.0)
    for k, (o_, h_, l_, c_) in HAND.items():
        d.loc[s2 + k, ["open", "high", "low", "close"]] = [o_, h_, l_, c_]
    daily["HANDSYM"] = d
    bars3["HANDSYM"] = bars_from_daily(d)
    out["HANDSYM"] = {"signal": s2}
    return out


# session -> (open, high, low, close) around HANDSYM's signal day
HAND = {0: (99.0, 100.5, 98.5, 100.0), 1: (100.0, 104.0, 99.0, 103.0), 2: (103.0, 107.0, 102.0, 106.0),
        3: (105.0, 108.0, 103.5, 104.0), 4: (104.0, 104.5, 103.0, 103.2), 5: (103.0, 104.0, 102.0, 103.5),
        6: (103.4, 104.2, 102.8, 103.9), 7: (104.0, 105.0, 103.0, 104.4), 8: (104.5, 105.5, 104.0, 105.0),
        9: (105.0, 106.0, 104.5, 105.5), 10: (105.6, 106.4, 105.0, 106.0)}


# ----------------------------------------------------------------------
# the recorded plan outcome: an independent hand implementation
# ----------------------------------------------------------------------
def hand_plan(df: pd.DataFrame, sig: int, lock_fn, hold: int = 5, search: int = 20) -> dict:
    o, h, l, c = (df[k].to_numpy(float) for k in ("open", "high", "low", "close"))
    n = len(c)
    B = type("B", (), {})()
    B.o, B.h, B.l, B.c = o, h, l, c
    if sig + hold >= n:
        return {"status": "pending", "net": np.nan, "mfe": np.nan, "mae": np.nan}
    e = sig + 1
    x = sig + hold
    entry = o[e]
    mfe = h[e:x + 1].max() / entry - 1
    mae = l[e:x + 1].min() / entry - 1
    if lock_fn(B, x, "close"):
        for q in range(x + 1, min(x + search, n - 1) + 1):
            if not lock_fn(B, q, "open"):
                return {"status": "ok", "net": o[q] / entry - 1 - COST, "mfe": mfe, "mae": mae, "exit_px": o[q],
                        "locked": True}
        if x + search <= n - 1:
            return {"status": "stuck", "net": np.nan, "mfe": mfe, "mae": mae}
        return {"status": "pending", "net": np.nan, "mfe": mfe, "mae": mae}
    return {"status": "ok", "net": c[x] / entry - 1 - COST, "mfe": mfe, "mae": mae, "exit_px": c[x], "locked": False}


def _picks(rng, days, names, daily, root) -> pd.DataFrame:
    sys.path.insert(0, str(Path(root) / "_mods"))
    ns: dict = {}
    exec(textwrap.dedent(STAGE_E_STANDIN), ns)
    lock = ns["lower_locked"]
    rows = []
    regular = [s for s in names if s[:1] == "S" and s[1:].isdigit()]
    special_days = {100: ["LOCKSYM", "STUCKSYM"], 140: ["GAPSYM", "AMBSYM"], 180: ["HANDSYM"]}
    for i in range(40, len(days) - 3):
        for eng in ("D", "ENS"):
            pool = list(rng.choice(regular, size=10, replace=False))
            if i in special_days and eng == "D":
                for z, sp in enumerate(special_days[i]):
                    if sp in daily:
                        pool[z] = sp
            for r, s in enumerate(pool, start=1):
                hp = hand_plan(daily[s], i, lock)
                rows.append({"engine": eng, "signal_day": days[i], "symbol": s, "rank": r,
                             "score": float(1 - r / 20 + rng.normal(0, 0.01)), "fold": float(days[i].year),
                             "status": hp["status"], "net": hp["net"], "mfe": hp["mfe"], "mae": hp["mae"],
                             "trap": float(hp.get("locked", False)) if hp["status"] == "ok" else np.nan,
                             "pred_mfe_q50": float(rng.uniform(0.02, 0.1)), "prob_big": float(rng.uniform(0.2, 0.8)),
                             "prob_trap": float(rng.uniform(0, 0.2)), "prob_win": float(rng.uniform(0.4, 0.6)),
                             "s_atr14": float(rng.uniform(0.02, 0.06)),
                             "entry_day": days[i + 1], "exit_day": days[min(i + 5, len(days) - 1)],
                             "win": float(hp["net"] > 0) if hp["status"] == "ok" else np.nan})
    P = pd.DataFrame(rows)
    rdir = Path(root) / "research2" / "pick_meta" / "PM_TEST_001"
    rdir.mkdir(parents=True, exist_ok=True)
    P.to_parquet(rdir / "predictions.parquet", index=False)
    import hashlib
    sha = hashlib.sha256((rdir / "predictions.parquet").read_bytes()).hexdigest()
    (rdir / "outputs.sha256").write_text(f"{sha}  predictions.parquet\n", encoding="utf-8")
    return P


def rewrite_predictions(root, P: pd.DataFrame, fix_hash: bool = True) -> None:
    rdir = Path(root) / "research2" / "pick_meta" / "PM_TEST_001"
    P.to_parquet(rdir / "predictions.parquet", index=False)
    if fix_hash:
        import hashlib
        sha = hashlib.sha256((rdir / "predictions.parquet").read_bytes()).hexdigest()
        (rdir / "outputs.sha256").write_text(f"{sha}  predictions.parquet\n", encoding="utf-8")


def _panel(rng, days, names, daily, root) -> None:
    rows = []
    for s in names:
        df = daily[s]
        c = df["close"].to_numpy(float)
        rsi = 50 + 20 * np.tanh(np.r_[0, np.diff(np.log(c))] * 50)
        for i, d in enumerate(days):
            rows.append({"timestamp": d, "symbol": s, "D_rsi14": rsi[i], "D_atr_pct": float(rng.uniform(1, 5)),
                         "D_ema20_angle_deg": float(rng.normal(0, 10)), "close": c[i], "X_turnover_med": 1e8,
                         "label_exit_ret": float(rng.normal()), "ret_5d_close_pct": float(rng.normal()),
                         "s_own_mfe_hist": float(rng.uniform()), "name_str": "x", "D_flag": bool(i % 2)})
    P = pd.DataFrame(rows)
    P["timestamp"] = pd.DatetimeIndex(P["timestamp"]).tz_localize(IST)
    d = Path(root) / "panel_oc"
    d.mkdir(exist_ok=True)
    P.to_parquet(d / "panel.parquet", index=False)
