"""
tests/tl_state_world.py - tradelab v1.3: price paths with PLANTED stock states (nothing here is shipped to production;
nothing on your cache is read or written).

Each path is built from straight segments (plus a little noise) so the state it should show is known by construction:
  UP         flat, then 30 cycles of 8 sessions up / 4 down          -> S02, then S01 (strong bullish continuation)
  DOWN       the mirror                                              -> S09, then S08
  RANGE      flat, then a triangle wave 6 up / 6 down                -> S07 (neutral range), never S01 / S08
  REVERSAL   20 down cycles, then 25 up cycles                       -> S08 -> S06 -> S02 -> S01, in that order
  CONSOL     15 up cycles, then 32 sessions moving +-0.3             -> S03 (bullish consolidation)
  BREAKOUT   a quiet range, then a close above it that holds         -> S04 NEW, CONFIRMED 3 sessions later
  TRAP       a quiet range, a close above it, back below in 3        -> S11 failed breakout
  BREAKDOWN  a quiet range, then a close below it that holds         -> S10 NEW, then CONFIRMED
  WILD       a quiet walk, then alternating 4-point swings           -> S12 (unstable / disorderly)
  PARABOLIC  a quiet walk, then an accelerating rise                 -> S05 extreme overextension (risk flag)
Absent: the established UP path never shows S12, S05 extreme or a breakdown; RANGE never shows S01 / S08 / S05.
"""
from __future__ import annotations

from typing import Dict, Tuple

import numpy as np
import pandas as pd

IST = "Asia/Kolkata"


def segs(start: float, spec, noise: float = 0.05, seed: int = 1) -> np.ndarray:
    rng = np.random.default_rng(seed)
    c = [start]
    for nb, step in spec:
        for _ in range(nb):
            c.append(c[-1] + step + noise * rng.normal())
    return np.array(c[1:], float)


def zig(cycles: int, up: float, dn: float, ub: int = 8, db: int = 4):
    return [(ub, up), (db, -dn)] * cycles


def ohlc(c: np.ndarray, wick: float = 0.4, seed: int = 2, start: str = "2020-01-01", vol: bool = True) -> pd.DataFrame:
    """Daily bars: open = previous close (+ a tiny gap), high / low = the body +- a wick; volume around 1e5."""
    rng = np.random.default_rng(seed)
    c = np.asarray(c, float)
    o = np.r_[c[0], c[:-1]] + rng.normal(0, 0.01, len(c))
    h = np.maximum(o, c) + wick
    l = np.minimum(o, c) - wick
    v = np.exp(rng.normal(np.log(1e5), 0.2, len(c))) if vol else np.full(len(c), np.nan)
    ts = pd.bdate_range(start, periods=len(c)).tz_localize(IST)
    return pd.DataFrame({"timestamp": ts, "open": o, "high": h, "low": l, "close": c, "volume": v})


def paths() -> Dict[str, Tuple[pd.DataFrame, dict]]:
    """name -> (bars, facts about where the planted things are)."""
    out = {}
    out["UP"] = (ohlc(segs(100, [(70, 0.0)] + zig(30, 1.0, 1.0))), {})
    out["DOWN"] = (ohlc(segs(400, [(70, 0.0)] + [(8, -1.0), (4, 1.0)] * 30)), {})
    out["RANGE"] = (ohlc(segs(100, [(70, 0.0)] + [(6, 1.0), (6, -1.0)] * 30)), {})
    out["REVERSAL"] = (ohlc(segs(300, [(70, 0.0)] + [(8, -1.0), (4, 1.0)] * 20 + [(4, -1.0), (8, 1.0)] * 25)), {})
    out["CONSOL"] = (ohlc(segs(100, [(70, 0.0)] + zig(15, 1.0, 1.0) + [(2, 0.3), (2, -0.3)] * 8)), {})
    rng = np.random.default_rng(5)
    base = 100 + 2 * np.sin(np.arange(120) / 2.0) + 0.1 * rng.normal(size=120)
    hold = np.r_[base, [104.5, 105.2, 105.8, 106.3, 106.9, 107.2, 107.8, 108.1, 108.6, 109.0]]
    out["BREAKOUT"] = (ohlc(hold, wick=0.3), {"cross": 120})
    trap = np.r_[base, [104.5, 105.0, 104.8, 101.0, 100.5, 100.2, 100.4, 100.1, 100.3, 100.0]]
    out["TRAP"] = (ohlc(trap, wick=0.3), {"cross": 120, "fail": 123})
    down = np.r_[base, [95.5, 94.8, 94.2, 93.7, 93.1, 92.8, 92.2, 91.9, 91.4, 91.0]]
    out["BREAKDOWN"] = (ohlc(down, wick=0.3), {"cross": 120})
    rng = np.random.default_rng(7)
    quiet = 100 + np.cumsum(0.2 * rng.normal(size=150))
    wild = quiet[-1] + np.cumsum(np.tile([4.0, -4.5, 3.8, -4.0, 4.2, -3.9], 6))
    out["WILD"] = (ohlc(np.r_[quiet, wild], wick=0.3), {"wild_from": 150})
    para = quiet[-1] + np.cumsum(np.linspace(0.5, 3.0, 25))
    out["PARABOLIC"] = (ohlc(np.r_[quiet, para], wick=0.3), {"para_from": 150})
    return out


def series(df: pd.DataFrame, sym: str = "X", cfg=None):
    import tl_state as S
    t = pd.to_datetime(df["timestamp"]).dt.tz_convert(IST).dt.tz_localize(None).dt.normalize()
    return S.StateSeries(sym, t.values.astype("datetime64[D]"), df["open"].to_numpy(float), df["high"].to_numpy(float),
                         df["low"].to_numpy(float), df["close"].to_numpy(float), df["volume"].to_numpy(float), cfg)
