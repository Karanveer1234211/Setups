"use strict";
const $=id=>document.getElementById(id);
const esc=v=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const opt=(v,label,sel)=>'<option value="'+esc(v)+'" '+(v===sel?'selected':'')+'>'+esc(label)+'</option>';
const pct=v=>v==null?'—':(v>0?'+':'')+v.toFixed(2)+'%';
let meta,cfg,last,historyRows=[],journalNotes={};
function setForm(c){
 cfg=structuredClone(c);
 for(const k of ['engine','name','window','hold','rank','market','tp','sl','cost','size','unit'])$(k).value=cfg[k]??'';
 const states=c.states|| (c.state?[c.state]:[]);
 document.querySelectorAll('#statebox input').forEach(x=>x.checked=states.includes(x.value));
 $('one').checked=!!cfg.one;stepsUI();$('err').textContent='';
}
function readForm(){
 for(const k of ['window','hold','rank','tp','sl','cost','size'])cfg[k]=Number($(k).value);
 for(const k of ['engine','name','market','unit'])cfg[k]=$(k).value;
 cfg.states=[...document.querySelectorAll('#statebox input:checked')].map(x=>x.value);cfg.state='';cfg.one=$('one').checked;return structuredClone(cfg);
}
function available(phase){return Object.entries(meta.fields).filter(([,v])=>v[1]==='snapshot'||v[1]==='open'||v[1]===phase);}
function stepsUI(){
 const root=$('steps');root.innerHTML='';
 cfg.steps.forEach((s,i)=>{
 const el=document.createElement('div');el.className='step';
 const fields=available(s.phase), options=sel=>fields.map(([v,[title]])=>opt(v,title,sel)).join('');
 el.innerHTML='<div class="row"><b>Event '+(i+1)+'</b><div><button data-up title="Move earlier">↑</button> <button data-down title="Move later">↓</button> <button data-remove>Remove event</button></div></div><div class="pair"><label>Observe at<select data-phase>'+[['open','Session open'],['close','Session close'],['intraday','Intraday bar close']].map(([v,l])=>opt(v,l,s.phase)).join('')+'</select></label><label>Conditions<select data-logic>'+opt('all','All must match',s.logic)+opt('any','Any may match',s.logic)+'</select></label></div>';
 for(const [sel,delta] of [['[data-up]',-1],['[data-down]',1]]){
 const b=el.querySelector(sel);if(!b)continue;b.disabled=i+delta<0||i+delta>=cfg.steps.length;b.onclick=()=>{[cfg.steps[i],cfg.steps[i+delta]]=[cfg.steps[i+delta],cfg.steps[i]];stepsUI()};
 }
 el.querySelector('[data-remove]').onclick=()=>{cfg.steps.splice(i,1);stepsUI()};
 el.querySelector('[data-phase]').onchange=e=>{s.phase=e.target.value;const a=available(s.phase).map(([v])=>v);for(const r of s.rules){if(!a.includes(r.field))r.field='day';if(r.rhs&&!a.includes(r.rhs))delete r.rhs;}stepsUI()};
 el.querySelector('[data-logic]').onchange=e=>s.logic=e.target.value;
 s.rules.forEach((r,j)=>{
 const box=document.createElement('div');box.className='rule';
 box.innerHTML='<div class="rulegrid"><label>Feature<select data-key="field">'+options(r.field)+'</select></label><label>Test<select data-key="op">'+['>','>=','<','<=','=','!='].map(x=>opt(x,x,r.op)).join('')+'</select></label><label>Compare to<select data-mode>'+opt('v','Value',r.rhs?'f':'v')+opt('f','Feature',r.rhs?'f':'v')+'</select></label></div>'+
 (r.rhs?'<div class="pair"><label>Other feature<select data-key="rhs">'+options(r.rhs)+'</select></label><label>Multiplier<input data-key="factor" type="number" step="any" value="'+esc(r.factor??1)+'"></label></div>':'<label>Threshold or category<input data-key="value" value="'+esc(r.value??'')+'"></label>')+'<button data-del>Remove condition</button>';
 box.querySelectorAll('[data-key]').forEach(n=>n.oninput=()=>r[n.dataset.key]=n.value);
 box.querySelector('[data-mode]').onchange=e=>{if(e.target.value==='f'){r.rhs='prev_close';r.factor=1}else{delete r.rhs;delete r.factor;r.value=0}stepsUI()};
 box.querySelector('[data-del]').onclick=()=>{s.rules.splice(j,1);stepsUI()};el.append(box);
 });
 const mark=document.createElement('label');mark.textContent='Save a numeric level for later events (optional)';
 const sel=document.createElement('select');sel.innerHTML=opt('','No level',s.capture||'')+options(s.capture);sel.onchange=()=>s.capture=sel.value;mark.append(sel);el.append(mark);
 const b=document.createElement('button');b.textContent='+ Condition';b.onclick=()=>{s.rules.push({field:'gap_pct',op:'>',value:2});stepsUI()};el.append(b);root.append(el);
 });
}
function download(name,text,type){const url=URL.createObjectURL(new Blob([text],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function ledgerCSV(rows){
 const cols=['trade_id','symbol','rank','pre_state','signal_day','status','trace','date','day','time','price','exit_day','exit','ret','baseline','pnl','reason','ambiguous'];
 const quote=v=>'"'+String(v??'').replace(/"/g,'""')+'"';
 download('bigmove_trade_ledger.csv',[cols.join(','),...rows.map(r=>cols.map(c=>quote(r[c])).join(','))].join('\n'),'text/csv');
}
function ledger(){
 if(!last)return;
 const filter=$('statusFilter').value,search=$('search').value.toUpperCase();
 const rows=last.rows.filter(r=>(!filter||r.status===filter)&&r.symbol.includes(search));
 $('ledgerRows').innerHTML='<p class="hint">'+rows.length+' matching rows · showing first 100</p><div class="scroll"><table><tr><th>Signal date</th><th>Symbol</th><th>Rank</th><th>Status</th><th>Entry date/time</th><th>Net</th><th>Event trace / reason</th></tr>'+rows.slice(0,100).map(r=>'<tr>'+[r.signal_day,r.symbol,r.rank,r.status,r.time||'—',pct(r.ret),[r.trace,r.reason].filter(Boolean).join(' / ')].map(v=>'<td>'+esc(v)+'</td>').join('')+'</tr>').join('')+'</table></div>';
}
function render(c,result){
 const groups=Object.entries(result.diagnostics||{});
 $('insight').innerHTML=groups.length?'<h2>What changed against BigMove?</h2><p class="hint">Percentage points per eligible pick. Execution change + losses skipped − gains skipped = lift. Missing outcomes suppress lift.</p><div class="scroll"><table><tr><th>State</th><th>Eligible / filled</th><th>Entry &amp; exit change</th><th>Losses skipped</th><th>Gains skipped</th><th>Lift</th></tr>'+groups.map(([s,v])=>'<tr>'+[s,v.n+' / '+v.fills,pct(v.execution),pct(v.avoided),pct(v.foregone),pct(v.lift)].map(t=>'<td>'+esc(t)+'</td>').join('')+'</tr>').join('')+'</table></div>':'';
 last=result;$('rtitle').textContent=c.name;$('note').textContent='Run '+result.id+' · '+result.eligible.toLocaleString()+' settled watchlist candidates · '+result.missing+' with incomplete signal or exit data.';
 const tiles=[['Trades filled',result.n],['Mean net / fill',pct(result.mean)],['Median net / fill',pct(result.median)],['Win rate',pct(result.win)],['Original on same fills',pct(result.baseline)],['Net / eligible pick',pct(result.per_pick)],['Total flat-size P&L','₹'+Math.round(result.pnl).toLocaleString('en-IN')],['Losses ≤ −5%',result.severe],['Ambiguous stop/TP bars',result.rows.filter(r=>r.ambiguous).length]];
 $('kpis').innerHTML='<div class="tiles">'+tiles.map(([l,v])=>'<div class="tile"><span>'+esc(l)+'</span><b>'+esc(v)+'</b></div>').join('')+'</div>';
 const annual=Object.entries(result.annual),max=Math.max(.01,...annual.map(([,v])=>Math.abs(v[1])));
 $('annual').innerHTML='<h2>Mean return by entry year</h2>'+annual.map(([y,[n,m]])=>'<div class="barrow"><span>'+y+'</span><div class="track" title="'+n+' fills"><div class="bar '+(m<0?'neg':'')+'" style="width:'+Math.abs(m)*100/max+'%"></div></div><b>'+pct(m)+'</b></div>').join('');
 $('annual').innerHTML+=yearTable(result.consolidated?.year_report?{[result.consolidated.scope]:result.consolidated}:{},'Consolidated · same eligible picks')+yearTable(result.diagnostics,'State by state · same eligible picks');
 $('counts').innerHTML='<h2>Coverage</h2>'+Object.entries(result.counts).map(([s,n])=>'<span class="chip">'+esc(s)+' · '+n+'</span>').join('');
 const group=new Map();
 for(const r of result.rows.filter(x=>x.status==='Filled')){
 const key=r.pre_state+' / '+r.market,a=group.get(key)||[0,0,0,0];a[0]++;a[1]+=r.ret;a[2]+=r.baseline;a[3]+=Number(r.ret>0);group.set(key,a)
 }
 $('counts').innerHTML+='<details><summary>Stock state × market direction</summary><div class="scroll"><table><tr><th>Group</th><th>Fills</th><th>Mean</th><th>Original</th><th>Wins</th></tr>'+[...group].sort((a,b)=>b[1][0]-a[1][0]).map(([k,[n,m,base,w]])=>'<tr><td>'+esc(k)+'</td><td>'+n+'</td><td>'+pct(m/n)+'</td><td>'+pct(base/n)+'</td><td>'+pct(100*w/n)+'</td></tr>').join('')+'</table></div></details>';
 $('ledger').innerHTML='<div class="row"><h2>Trade ledger</h2><button id="csv">Export all rows</button></div><div class="pair"><label>Status<select id="statusFilter">'+opt('','All statuses','')+Object.keys(result.counts).map(s=>opt(s,s,'x')).join('')+'</select></label><label>Symbol<input id="search" placeholder="Filter by symbol"></label></div><div id="ledgerRows"></div>';
 $('csv').onclick=()=>ledgerCSV(result.rows);$('search').oninput=ledger;$('statusFilter').onchange=ledger;ledger();
}
async function request(path,settings){const res=await fetch(path,settings);const data=await res.json();if(!res.ok)throw Error(data.error||'Request failed');return data}
async function historyUI(){
 [historyRows,journalNotes]=await Promise.all([request('/history'),request('/notes')]);$('history').innerHTML='<div class="scroll"><table><tr><th>Run / setup</th><th>Fills</th><th>Mean</th><th>Per pick</th><th>Source</th></tr>'+historyRows.map((r,i)=>'<tr><td><button data-load="'+i+'">#'+r.id+' '+esc(r.config.name)+'</button></td><td>'+r.metrics.n+'</td><td>'+pct(r.metrics.mean)+'</td><td>'+pct(r.metrics.per_pick)+'</td><td>'+esc(r.source.panel?'Panel':'Archive')+(r.source.intraday?' + intraday':'')+'</td></tr>').join('')+'</table></div>';
 $('yexport').onclick=()=>{const rows=historyRows.flatMap(h=>annualLines({...h.metrics.diagnostics,...(h.metrics.consolidated?.year_report?{[h.metrics.consolidated.scope]:h.metrics.consolidated}:{})}).map(r=>({run:h.id,strategy_name:h.config.name,engine:h.config.engine,...r}))).filter(r=>(r.state+' '+r.strategy_name).toLowerCase().includes($('jfilter').value.toLowerCase()));if(rows.length){const keys=Object.keys(rows[0]),quote=x=>'"'+String(x??'').replaceAll('"','""')+'"';download('annual_state_journal.csv',[keys,...rows.map(r=>keys.map(k=>r[k]))].map(r=>r.map(quote).join(',')).join('\n'),'text/csv')}};
 drawJournal();$('jfilter').oninput=drawJournal;$('jexport').onclick=exportJournal;
 $('history').querySelectorAll('[data-load]').forEach(b=>b.onclick=async()=>{try{const item=historyRows[b.dataset.load];setForm(item.config);$('preset').value='';render(item.config,await request('/result/'+item.id))}catch(e){$('err').textContent=e.message}});
}
async function execute(configs){
 $('err').textContent='';$('run').disabled=true;$('sweep').disabled=true;$('matrix').disabled=true;
 try{for(const [i,c] of configs.entries()){
 $('run').textContent='Running '+(i+1)+' / '+configs.length+'…';
 const r=await request('/run',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(c)});
 render(c,r);
 }await historyUI()}catch(e){$('err').textContent=e.message;await historyUI()}finally{$('run').textContent='Run backtest →';$('run').disabled=false;$('sweep').disabled=false;$('matrix').disabled=false}
}
async function init(preview=true){
 meta=await request('/meta');$('source').textContent='● LOCAL WORKSPACE';
 $('coverage').textContent=meta.count.toLocaleString()+' master picks · '+meta.dates.toLocaleString()+' signal dates · '+(meta.panel?'Daily OHLCV panel connected':'Bundled ten-session paths')+' · '+(meta.intraday?'Intraday bars connected':'Daily clocks available')+'.';
 $('panelpath').value=meta.source.panel||'';$('barpath').value=meta.source.intraday||'';$('minutes').value=meta.source.minutes;$('extra').value=meta.source.extras.join(', ');
 $('connect').onclick=async()=>{
 $('connect').disabled=true;$('dataStatus').textContent='Reading and validating the data…';
 try{await request('/source',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({panel:$('panelpath').value.trim(),intraday:$('barpath').value.trim(),minutes:Number($('minutes').value),extras:$('extra').value})});const saved=readForm();await init(false);setForm(saved);$('dataStatus').textContent='Data sources connected.'}
 catch(e){$('dataStatus').textContent=e.message}finally{$('connect').disabled=false}
 };
 $('preset').innerHTML=opt('','Custom scenario','x')+meta.presets.map((p,i)=>opt(i,p.name,'x')).join('');
 for(const [id,values] of [['market',meta.markets]])$(id).innerHTML=opt('','All','')+values.map(v=>opt(v,v,'x')).join('');
 $('statebox').innerHTML=meta.states.map(s=>'<label><input type="checkbox" value="'+esc(s)+'"> '+esc(s)+'</label>').join('');
 $('preset').value='0';setForm(meta.presets[0]);$('preset').onchange=e=>{if(e.target.value!=='')setForm(meta.presets[Number(e.target.value)])};
 $('addstep').onclick=()=>{cfg.steps.push({phase:'open',logic:'all',rules:[{field:'day',op:'>=',value:1}]});stepsUI()};
 $('sweep').onclick=()=>{
 const base=readForm(),key=$('vary').value,parts=$('values').value.split(',');
 if(parts.some(v=>!v.trim()||!Number.isFinite(Number(v)))){ $('err').textContent='Enter comma-separated numeric values.';return }
 if(key==='threshold'&&(!base.steps[0]?.rules[0]||base.steps[0].rules[0].rhs)){ $('err').textContent='The first condition must compare with a value.';return }
 execute(parts.map(v=>{const c=structuredClone(base);if(key==='threshold')c.steps[0].rules[0].value=Number(v);else c[key]=Number(v);c.name=base.name+' · '+key+' '+v;return c}));
 };
 $('allstates').onclick=()=>execute([{...readForm(),states:[],state:''}]);
 $('matrix').onclick=()=>{const base=readForm();execute((base.states.length?base.states:meta.states).map(s=>({...base,states:[s]})))};
 $('run').onclick=()=>execute([readForm()]);$('export').onclick=()=>download('scenario.json',JSON.stringify(readForm(),null,2),'application/json');
 $('import').onclick=()=>$('file').click();$('file').onchange=async e=>{try{const val=JSON.parse(await e.target.files[0].text());if(Array.isArray(val)){if(!val.length)throw Error('Empty batch');setForm(val[0]);await execute(val)}else{setForm(val);$('preset').value=''}}catch(err){$('err').textContent=err.message}finally{e.target.value=''}};
 await historyUI();
 if(preview){
   if(historyRows.length){const r=historyRows[0];setForm(r.config);render(r.config,await request('/result/'+r.id));$('preset').value=''}
   else{await execute([readForm()])}
 }
}
init().catch(e=>$('err').textContent=e.message);

function journalRows(){
 const filter=$('jfilter').value.toLowerCase();
 return historyRows.flatMap(h=>Object.entries(h.metrics.diagnostics||{}).filter(([s])=>(s+' '+h.config.name).toLowerCase().includes(filter)).map(([s,v])=>({run:h.id,date_utc:h.created,strategy:h.config.name,engine:h.config.engine,state:s,selected_states:(h.config.states||[]).join('|')||h.config.state||'ALL',market:h.config.market||'ALL',...v,year_report:JSON.stringify(v.year_report||{}),years:JSON.stringify(v.years||{}),positive_years:Object.values(v.years||{}).filter(x=>x>0).length,measured_years:Object.keys(v.years||{}).length,note:journalNotes[h.id+'/'+s]||'',finding:v.missing?'Incomplete coverage':!v.fills?'No fills':v.lift>0?'Higher net per eligible pick':v.lift<0?'Lower net per eligible pick':'Matched original'})));
}
function drawJournal(){
 const rows=journalRows();$('journal').innerHTML='<p>'+rows.length+' state findings · showing latest 200</p><div class="scroll"><table><tr><th>Run</th><th>Strategy</th><th>State</th><th>Fills / eligible</th><th>Lift</th><th>Finding</th><th>Positive years</th><th>Research note</th></tr>'+rows.slice(0,200).map(r=>'<tr>'+[r.run,r.strategy,r.state,r.fills+' / '+r.n,pct(r.lift),r.finding,r.positive_years+' / '+r.measured_years].map(t=>'<td>'+esc(t)+'</td>').join('')+'<td><button data-note-run="'+r.run+'" data-note-state="'+esc(r.state)+'">'+esc(r.note||'Add note')+'</button></td></tr>').join('')+'</table></div>';
}
function noteClick(e){const b=e.target.closest('[data-note-run]');if(!b)return;
 const r=b.dataset.noteRun,s=b.dataset.noteState;const v=prompt('Research note for run '+r+' · '+s,journalNotes[r+'/'+s]||'');if(v===null)return;
 request('/note',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({run:r,state:s,body:v})}).then(()=>{journalNotes[r+'/'+s]=v;drawJournal()}).catch(err=>$('err').textContent=err.message);
}
$('journal').onclick=noteClick;
function exportJournal(){const rows=journalRows();if(!rows.length)return;const cols=Object.keys(rows[0]);const quote=x=>'"'+String(x??'').replace(/"/g,'""')+'"';download('strategy_state_journal.csv',[cols,...rows.map(r=>cols.map(c=>r[c]))].map(row=>row.map(quote).join(',')).join('\n'),'text/csv')}

function annualLines(diagnostics){
 return Object.entries(diagnostics||{}).flatMap(([state,g])=>Object.entries(g.year_report||{}).map(([year,v])=>({year,state,...v}))).sort((a,b)=>a.year.localeCompare(b.year)||a.state.localeCompare(b.state));
}
function yearTable(diagnostics,title){
 const rows=annualLines(diagnostics);if(!rows.length)return '';
 return '<h2>'+esc(title)+'</h2><p class="hint">Strategy, original and difference are net percentage points per eligible nomination. Skips earn zero. Missing outcomes suppress strategy and difference.</p><div class="scroll"><table><tr><th>Year</th><th>State</th><th>Fills / eligible</th><th>Strategy / fill</th><th>Original / same fills</th><th>Win rate</th><th>Strategy / eligible</th><th>Original / same eligible</th><th>Difference</th><th>Missing</th></tr>'+rows.map(r=>'<tr>'+[r.year,r.state,r.fills+' / '+r.eligible,pct(r.mean),pct(r.filled_original),pct(r.win),pct(r.strategy),pct(r.original),pct(r.lift),r.missing].map(x=>'<td>'+esc(x)+'</td>').join('')+'</tr>').join('')+'</table></div>';
}
