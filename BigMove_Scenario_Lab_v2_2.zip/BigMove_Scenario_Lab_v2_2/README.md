# BigMove Scenario Lab

Extract the ZIP to a new research folder on your personal Windows machine. Double-click **START_LAB.bat**. It uses the Windows Python launcher to create a local virtual environment, installs the three dependencies on first run, and opens the app at **http://127.0.0.1:8787**. Use Python 3.10–3.12. First-run installation needs internet access. Close the console to stop the server. The app can run offline once the dependencies are installed.

## A first experiment

Choose **First gap above 2%** and click **Run backtest**. It scans days 1–5 for the first qualifying open, then holds five sessions counting entry day. With Engine D, ranks 1–3 and 35 bp research cost, expect 1,683 filled trades, +0.9460% per fill and +0.3207% per eligible pick. Day 1 counts. The initial preview runs this genuine backtest.

Change the entry window to **1**, profit-target unit to **%**, and target to **5**. Expect 420 fills and +0.2103% mean. Try unit **ATR**, target **2**, with the same window and no stop. Expect +1.5236%. The target is a distance in rupees from the entry, using the ATR available before that open.

## Build and compare

* Choose D or ENS, maximum rank, stock state and market direction. States and market direction come from the nomination snapshot. These filters do not reclassify the stock each evening.
* An event contains one or more comparisons. Choose **All** or **Any**. Compare with a value, or another feature times a multiplier. Percent fields use percentage points (type 2 for 2%). Source-native signal fields keep their original units.
* **Add next event** creates a sequence. Steps must match in order at strictly later observation times. A false step keeps waiting. This implements ordered occurrence, not a requirement for consecutive sessions. Use the arrows to change order.
* An event can save a numeric level (such as its bar high or session close). Later steps can compare against **Level saved by an earlier event**, optionally multiplied by a factor. The saved level stays frozen until another matched event captures a replacement.
* Open conditions use only snapshots, previous completed data and the auction price. Filling at the reported auction open is an idealized scenario. A close condition uses that day's completed data and enters at the next open. All triggers AND entry must fit inside the watch window. A day-5 close with a five-day watch window cannot lead to a day-6 entry.
* For a single step evaluated at the open, use **Signal · RSI 14 > 50**, **Signal · volume / prior 50-session median ≥ 3**, and **Opening gap % > 2**, joined by All. These signal features stay fixed. For *newly occurring* 3× volume during the watch window, use daily **Volume / previous 20-session mean ≥ 3** at the close, then an open step for **Opening gap % > 2**. The following morning can satisfy the second event.
* Intraday events evaluate completed bars from 09:30 IST onwards. The first 15 minutes define ORH/ORL. Entry is the next bar open. A final session bar can enter only on the following session while the watch window is active. A breakout + retest uses distinct bars.
* Add a take-profit, stop, flat round-trip cost and position size. Zero disables a barrier. Use the **parameter sweep** to vary a numeric threshold, window, holding period, TP or SL across a comma-separated list. Each result is saved independently before the next runs.
* Export scenarios as JSON. Import a single object to edit it, or a JSON array to execute a batch in sequence. History stores the configuration, data-source settings, metrics and compressed ledger in **local_history.db**. Click a run to reopen its actual results. Export the trade ledger to CSV, including skipped and unresolved candidates.
* Results include filled and skipped counts, unmatched data, mean, median, wins, losses of 5% or worse, rupee P&L, year-by-year results and stock-state × market-direction breakdowns. The original comparison uses the journal outcome on exactly the same filled picks, adjusted to the scenario cost. The original journal may delay locked exits; a time-exit simulation marks the specified closing price.

## Data included

The package includes actual frozen Engine D and ENS rank 1–3 nominations: 4,965 per engine across 1,655 signal dates, with recorded selection-time features. Research excludes original unsettled rows before simulation. Selecting the two engines separately keeps overlaps explicit.

Bundled paths use journal opens/closes for the first five sessions and the original ten-session D export for later prices where present. ENS can reuse an identical symbol/date/entry path. Later unmatched ENS closes remain missing. The calendar ends on the source's final available session. No synthetic forward prices are supplied. The bundled five-session high excursion also supports a day-1 entry with five-session hold and a single profit target. For this case the system can establish whether the target was touched, but cannot assign the exact touch date.

## Connect local data

Use **Data sources** at the top. Start with your known daily panel path:

    C:\QuantData\cache_daily\panel\panel.parquet

The daily input needs **symbol, date or timestamp, open, high, low, close and volume**, one row per symbol and exchange session. Supported inputs are a combined Parquet/CSV, or a folder of SYMBOL.parquet or SYMBOL_1d.parquet daily files. Symbol can be inferred from these filenames. A feature-only panel is insufficient for price replay; use an OHLCV panel or a daily-cache folder. The application reports missing columns. You can include extra point-in-time numeric columns in the same daily dataset, list them under **Trusted daily numeric columns**, and compare them visually after that session closes. Forward-looking field names are screened; the researcher must verify the provenance of each custom feature. Signal-day BigMove features keep their original definitions. New RSI/ATR use Wilder smoothing with a 14-session seed. Dynamic relative volume uses the previous 20 completed sessions' mean.

Connecting a panel uses that panel's prices for the scenario. Use consistently adjusted bars across the whole trade, and check symbol identity, coverage and opening prices against the journal. Prices from different vendors can differ. The original model comparison remains based on its recorded prices. In panel mode, supply adequate warm-up history and future dates through the last required exit. Missing prices or indicator history are shown explicitly. No automatic data download is required.

For intraday rules add a combined OHLCV Parquet/CSV with start timestamps, or the project cache folder containing **SYMBOL_3m.parquet** or **SYMBOL_5m.parquet**. Choose the actual bar length. Naive timestamps are treated as IST; timezone-aware inputs are converted to IST. Regular NSE sessions 09:15–15:30 are supported. Intraday-trigger sessions require a complete bar grid and an opening price within 0.5% of the daily open. Sparse sessions, special short sessions and missing prices are reported as unavailable. Intraday input can accompany a daily panel or the bundled daily paths.

Alternative launch:

    START_LAB.bat --panel "C:\QuantData\cache_daily\panel\panel.parquet"
    START_LAB.bat --panel "C:\QuantData\cache_daily\panel\panel.parquet" --intraday "C:\your\intraday_cache" --minutes 5

Data source choices made in the UI apply to the running session. Every saved run records its paths. Keep a copy of the input version if you need to reproduce results after changing external data.

## Refresh the watchlist

After first launch, from the app's folder:

    .venv\Scripts\python.exe import_watchlist.py --journal "C:\exports\outp.tar" --paths "C:\exports\ssj.tar" --out "C:\QuantResearch\datasets\run_002"
    START_LAB.bat --dataset "C:\QuantResearch\datasets\run_002"

The importer also accepts extracted export folders and preserves existing datasets. The ten-session paths argument is optional. Without it, use daily OHLCV for longer horizons.

## Fill conventions and scope

A target is filled at the target, including favorable gaps. Stops through a later opening price fill at that worse open. If a bar touches both barriers, the stop wins and the ledger counts the ambiguity. A trade entered intraday uses only bars from entry onward for that session. Daily bars are used for subsequent sessions when a daily panel is attached. Bars indicate prices touched, not fillable liquidity. There is no partial-fill, price-band, queue or financing model.

One-new-trade-per-day mode selects the earliest qualifying entry across currently active nominations. Ties use original rank, then earlier nomination, then trade ID. Capacity is allocated before exit outcomes are consulted. The engine can hold overlapping positions and independent repeat nominations. Aggregate flat-size P&L is a sum at constant notional, not compounded portfolio equity or drawdown. No balance, MTF, cash or concurrent-open-position constraint is simulated. Missing candidates can affect selection under a daily cap. Missing returns suppress the per-pick metric. The historical baseline is exploratory; use unseen dates for a prospective decision.

## Verify

    .venv\Scripts\python.exe verify.py

Checks cover known master replay results, timing of a close signal, ordered intraday confirmation, the daily cap, missing bars and conservative same-bar exits. Input archives and production code are read-only. The app stores history only in its own folder.

## State research journal (v2)

Tick any combination of nomination states. **Run backtest** evaluates their union as one strategy, sharing the daily cap if enabled. **Run separately for each eligible state** writes an independent run for each selected state (all states if none are selected); each independent run has its own cap. For different rules in different states, save separate configurations or import an array of scenarios.

The journal keeps strategy name, configuration, run ID, state, market, coverage, generated finding, year-by-year differences and your editable research note. Filter by strategy or state and export CSV. Percentage-point lift is the difference in net return per eligible settled pick against buying the original BigMove picks in that state. Its three parts are the changed result on filled trades, losses avoided by skipping original losers, and gains forgone by skipping original winners. Missing outcomes suppress overall lift. Positive years are descriptive counts by signal year including partial years. Thin groups are visible via eligible and filled counts.

Upgrade in a new folder. To keep prior history, stop the old server and copy **local_history.db** from the old app folder into the new one before launching. Legacy runs remain in Run History; rerun their configurations to generate the new state findings.
