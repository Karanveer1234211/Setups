# MANIFEST - setuplab v0.6 (7 Nov 2026)

Folder: C:\Users\karanvsi\PyCharmMiscProject\setuplab\ (tests in setuplab\tests\). Replace the v0.5 files; nothing else changes (playbook, v2engine, tradelab, bigmove_deploy untouched). Python with numpy, pandas, pyarrow.

| file | sha256 (first 16) | bytes | lines |
|---|---|---|---|
| setuplab.py | 12ce29feb2ece92f | 101329 | 1847 |
| features_final.txt | bcb6c16bdfd7513d | 1689 | 60 |
| README_SETUPLAB.md | ea61ee3b4dd22f2e | 12669 | 158 |
| tests\test_setuplab.py | 6aa2a23551f4a564 | 29625 | 471 |

Verified where it was built: 38 self-test checks; the 60 ChatGPT ledgers reproduced (7.11e-15 pp); a synthetic run at Karan's scale (35,000 picks, 53 features, both engines) in 8.5 minutes, peak memory 1.6 GB.
