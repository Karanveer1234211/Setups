"""
setuplab.py - setuplab v0.1: entry setups for engine D's picks, compared trade by trade with the model's D1 entry.

    python setuplab.py run --data <folder with watchlist.parquet + calendar.parquet> --features <features.parquet>
                           --out <output folder> [--engine D] [--setups default|<setups.json>]
    python setuplab.py reproduce --data ... --features ... --ledgers <folder of delivered *.csv.gz>
    python setuplab.py --selftest

What it does (the rules of the ChatGPT backtester, backtest.pyz, re-implemented vectorised):
  * a setup = a list of conditions, ALL required, read at the open of watch day k (k = 1..5 after the pick):
      <feature>          the feature's value at the previous completed session (k-1; D0 = the signal day)
      <feature>_change   that value minus the session before (stored *_change column if the file has one)
      gap_pct            today's open vs the previous close, %
      pc_vs_d1           the previous close vs the D1 open, %          (known from D2 on; False on D1)
      pc_vs_d1_atr       the same in units of the pick's ATR14 at the signal (s_atr14)
      prev_intraday      the previous session's close vs its open, %   (D2 on)
      prev_ret           the previous session's close vs the close before, %  (D2 on)
      day                the watch day number (blind controls)
      weekday            the watch day's weekday, 0 = Monday (weekly features change on Mondays: their setups
                         can only fire on a Tuesday open - the TUE controls separate the feature from the weekday)
    numbers are rounded to 9 decimals before comparing; 0 does not pass > 0 or < 0
  * entry at the FIRST open whose conditions all hold; a False condition = not today; a missing value with no
    False = the trade is "Missing signal data" (as the original engine); no qualifying open = "No entry"
  * exits: original_d5 = the pick's D5 close; fresh = the close 4 sessions after the entry day (5 sessions held)
  * net % = exit / entry - 1 (in %) - 0.35 (cost)
  * the comparison is Karan's: each setup's OWN filled trades against the model's D1 entry (blind D1, same exit
    rule) on exactly those trade ids. 95% circular block bootstrap over signal days (10-day blocks, 2,000 draws).
    Under original_d5 both legs sell at the same D5 close, so the whole difference is the entry price; under
    fresh the exit moves with the entry, and "after-entry" = setup net minus the D1 trade held from the same
    entry-day open would be the same as the setup itself - so we report the entry discount beside the lift.
  * controls on the same ids: price-only dip entries and bounce markers (no indicators), to see whether a
    setup's conditions add anything beyond "buy after the price has come down"
"""
from __future__ import annotations

import argparse
import itertools
import json
import re
import sys
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "setuplab v0.6"
WATCH = 5               # watch days D1..D5
PATH = 10               # sessions of path in the watchlist (close_1..close_10)
COST = 0.35
EXITS = ("original_d5", "fresh")
OPS = {">": np.greater, "<": np.less, ">=": np.greater_equal, "<=": np.less_equal}
PRICE_FIELDS = ("gap_pct", "pc_vs_d1", "pc_vs_d1_atr", "prev_intraday", "prev_ret", "day", "weekday")


# ---------------------------------------------------------------------------------------------------- data
class Book:
    """Engine D's picks with their D1..D10 opens / closes and every feature at the previous session of each watch
    day. Arrays are (trades, PATH + 1) with column k = watch day k (column 0 unused for prices)."""

    def __init__(self, wl: pd.DataFrame, cal: pd.Series, feats: pd.DataFrame | None, engine="D", feature_cols=None,
                 ranks=None):
        wl = wl[wl["engine"] == engine].copy() if engine and "engine" in wl.columns else wl.copy()
        self.engine = engine or "ALL"
        if ranks:
            wl = wl[wl["rank"].isin(ranks)]
        wl = wl.sort_values(["signal_day", "rank", "trade_id"]).reset_index(drop=True)
        self.wl = wl
        self.n = len(wl)
        self.ids = wl["trade_id"].astype(str).to_numpy()
        self.signal_day = pd.to_datetime(wl["signal_day"]).dt.normalize().to_numpy()
        self.ok = (wl["status"].astype(str) == "ok").to_numpy() & np.isfinite(wl["net_bp"].astype(float).to_numpy())
        cal = pd.to_datetime(pd.Series(cal)).dt.normalize().sort_values().drop_duplicates().reset_index(drop=True)
        self.cal = cal.to_numpy()
        pos = {d: i for i, d in enumerate(cal)}
        e1 = pd.to_datetime(wl["entry_day"]).dt.normalize()
        self.i1 = np.array([pos.get(d, -1) for d in e1], dtype=np.int64)
        if (self.i1 < 0).any():
            raise ValueError("%d entry days are not in the calendar" % int((self.i1 < 0).sum()))
        ent = wl["entry"].astype(float).to_numpy()
        sc = wl["signal_close"].astype(float).to_numpy()
        O = np.full((self.n, PATH + 1), np.nan)
        C = np.full((self.n, PATH + 1), np.nan)
        PC = np.full((self.n, PATH + 1), np.nan)
        for k in range(1, PATH + 1):
            C[:, k] = ent * (1 + wl["close_%d" % k].astype(float).to_numpy())
            PC[:, k] = sc if k == 1 else ent * (1 + wl["close_%d" % (k - 1)].astype(float).to_numpy())
            O[:, k] = ent if k == 1 else PC[:, k] * (1 + wl["overnight_%d" % k].astype(float).to_numpy())
        # a session past the calendar's end does not exist
        for k in range(1, PATH + 1):
            gone = self.i1 + k - 1 >= len(self.cal)
            O[gone, k] = C[gone, k] = PC[gone, k] = np.nan
        self.O, self.C, self.PC = O, C, PC
        self.sc, self.ent = sc, ent
        self.atr = wl["s_atr14"].astype(float).to_numpy() if "s_atr14" in wl.columns else np.full(self.n, np.nan)
        self.symbols = wl["symbol"].astype(str).str.strip().str.upper().to_numpy()
        self.state = wl["pre_state"].astype(str).to_numpy() if "pre_state" in wl.columns else np.array([""] * self.n)
        self.rank = wl["rank"].astype(int).to_numpy()
        self.engine_arr = wl["engine"].astype(str).to_numpy() if "engine" in wl.columns else \
            np.array([self.engine] * self.n)
        # year index and the two halves of the period (split at the median signal day of the settled picks)
        yrs = pd.DatetimeIndex(self.signal_day).year.to_numpy()
        self.yi = (yrs - yrs.min()) if self.n else yrs
        okd = self.signal_day[self.ok] if self.ok.any() else self.signal_day
        self.split_day = np.sort(okd)[len(okd) // 2] if len(okd) else None
        self.half = (self.signal_day > self.split_day).astype(int) if len(okd) else np.zeros(self.n, int)
        self.span_years = max(1e-9, (okd.max() - okd.min()) / np.timedelta64(365, "D")) if len(okd) else 1.0
        self.features = []
        self.F = {}
        if feats is not None:
            self._join(feats, feature_cols)

    PER_TRADE = ("ids", "signal_day", "ok", "i1", "O", "C", "PC", "sc", "ent", "atr", "symbols", "state", "rank",
                 "engine_arr", "yi", "half")

    def take(self, mask, engine=None):
        """The same book restricted to some picks (e.g. one engine); shares the split day and the span."""
        b = object.__new__(Book)
        b.__dict__.update({k: v for k, v in self.__dict__.items() if k != "_cache"})
        for k in self.PER_TRADE:
            setattr(b, k, getattr(self, k)[mask])
        b.F = {k: v[mask] for k, v in self.F.items()}
        b.wl = self.wl[mask].reset_index(drop=True)
        b.n = int(np.sum(mask))
        b.engine = engine or self.engine
        return b

    def attach(self, path, cols, chunk=8, log=lambda *a: None):
        """Read the feature columns from a big panel a few at a time, only the picks' stocks and only the dates the
        watch windows need (+ 120 days for the changes): memory stays small whatever the panel's size.
        Returns (attached, missing)."""
        import pyarrow.parquet as pq
        names = pq.read_schema(path).names
        low = {c.lower(): c for c in names}
        dk = low.get("timestamp") or low.get("date")
        if "symbol" not in low or not dk:
            raise ValueError("the feature file needs symbol and timestamp (or date) columns")
        want, miss = [], []
        for c in cols:
            (want if c.lower() in low else miss).append(c.lower())
        want = list(dict.fromkeys(want))
        syms = sorted(set(self.symbols))
        first = pd.Timestamp(self.cal[max(0, int(self.i1.min()) - 2)]) - pd.Timedelta(days=120) if self.n else None
        for i in range(0, len(want), chunk):
            part = want[i:i + chunk]
            rc = [low["symbol"], dk] + [low[c] for c in part] + [low[c + "_change"] for c in part
                                                                 if c + "_change" in low]
            F = None
            try:
                F = pq.read_table(path, columns=rc, filters=[(low["symbol"], "in", syms)]).to_pandas()
            except Exception:
                F = None
            if F is None or len(F) == 0:
                F = pd.read_parquet(path, columns=rc)
            self._join(F, part, append=True, min_date=first)
            del F
            log(" features: %d of %d attached" % (min(i + chunk, len(want)), len(want)))
        return want, miss

    def _join(self, feats, feature_cols, append=False, min_date=None):
        f = feats.copy()
        if any(n is not None for n in f.index.names):                 # symbol / date stored as the index
            f = f.reset_index()
        f.columns = [str(c).lower() for c in f.columns]
        dk = "timestamp" if "timestamp" in f.columns else "date"
        if "symbol" not in f.columns or dk not in f.columns:
            raise ValueError("the feature file needs symbol and timestamp (or date) columns")
        f["symbol"] = f["symbol"].astype(str).str.strip().str.upper()
        t = pd.to_datetime(f[dk])
        if t.dt.tz is not None:                                         # a zoned clock -> Indian dates, no zone
            t = t.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
        f[dk] = t.dt.normalize()
        base = [c for c in (feature_cols or f.columns) if c not in ("symbol", dk) and not c.endswith("_change")]
        f = f[f["symbol"].isin(set(self.symbols))]
        if min_date is not None:
            f = f[f[dk] >= min_date]
        if f.duplicated(["symbol", dk]).any():
            raise ValueError("duplicated symbol/date rows in the feature file")
        f = f.sort_values(["symbol", dk])
        for c in base:
            if c + "_change" not in f.columns:            # the change = this session minus the symbol's previous row
                f[c + "_change"] = f.groupby("symbol")[c].diff()
        cols = base + [c + "_change" for c in base]
        # previous-session date of each watch day k
        rows, ks, keys_s, keys_d = [], [], [], []
        for k in range(1, WATCH + 1):
            j = self.i1 + k - 2
            ok = (j >= 0) & (j < len(self.cal))
            rows.append(np.flatnonzero(ok))
            ks.append(np.full(ok.sum(), k))
            keys_s.append(self.symbols[ok])
            keys_d.append(self.cal[j[ok]])
        L = pd.DataFrame({"row": np.concatenate(rows), "k": np.concatenate(ks), "symbol": np.concatenate(keys_s),
                          dk: np.concatenate(keys_d)})
        M = L.merge(f[["symbol", dk] + cols], on=["symbol", dk], how="left")
        for c in cols:
            A = np.full((self.n, WATCH + 1), np.nan)
            A[M["row"].to_numpy(), M["k"].to_numpy()] = pd.to_numeric(M[c], errors="coerce").to_numpy(float)
            self.F[c] = A
        self.features = (list(self.features) if append else []) + [c for c in base if c not in
                                                                   (self.features if append else [])]

    def field(self, name):
        """(trades, WATCH + 1) values of a condition field at the open of each watch day (cached)."""
        if name in self.F:
            return self.F[name]
        cache = self.__dict__.setdefault("_cache", {})
        if name not in cache:
            cache[name] = self._field(name)
        return cache[name]

    def _field(self, name):
        A = np.full((self.n, WATCH + 1), np.nan)
        if name.startswith("snap:"):                  # the pick's snapshot at the signal close (watchlist pre_*)
            col = name[5:]
            if col not in self.wl.columns:
                raise KeyError("no column %s in the watchlist" % col)
            v = pd.to_numeric(self.wl[col], errors="coerce").astype(float).to_numpy()
            A[:, 1:] = v[:, None]
        elif name == "gap_pct":
            A[:, 1:] = (self.O[:, 1:WATCH + 1] / self.PC[:, 1:WATCH + 1] - 1) * 100
        elif name == "day":
            A[:, 1:] = np.arange(1, WATCH + 1)[None, :]
        elif name == "pc_vs_d1":
            A[:, 2:] = (self.C[:, 1:WATCH] / self.O[:, [1]] - 1) * 100
            A[:, 1] = 0.0                          # nothing to compare on D1: a dip test (< 0) is False there
        elif name == "weekday":
            for k in range(1, WATCH + 1):
                j = np.minimum(self.i1 + k - 1, len(self.cal) - 1)
                A[:, k] = pd.DatetimeIndex(self.cal[j]).weekday
        elif name == "pc_vs_d1_atr":
            A[:, 2:] = (self.C[:, 1:WATCH] / self.O[:, [1]] - 1) / self.atr[:, None]
            A[:, 1] = 0.0
        elif name == "prev_intraday":
            A[:, 2:] = (self.C[:, 1:WATCH] / self.O[:, 1:WATCH] - 1) * 100
            A[:, 1] = 0.0
        elif name == "prev_ret":
            prev = np.column_stack([self.sc, self.C[:, 1:WATCH]])
            A[:, 2:] = (self.C[:, 1:WATCH] / prev[:, :WATCH - 1] - 1) * 100
            A[:, 1] = 0.0
        else:
            raise KeyError("unknown field %s" % name)
        return A


# ---------------------------------------------------------------------------------------------------- replay
def trigger(book: Book, conds):
    """First watch day whose conditions all hold. Returns (day, status) arrays: day 0 = none.
    status: 'Filled' candidates (day > 0), 'No entry', 'Missing signal data'."""
    n = book.n
    day = np.zeros(n, dtype=np.int64)
    missing = np.zeros(n, dtype=bool)
    done = ~book.ok.copy()
    for k in range(1, WATCH + 1):
        sess = np.isfinite(book.O[:, k])
        newly_missing = ~done & ~sess                       # watch session unavailable
        missing |= newly_missing
        done |= newly_missing
        anyF = np.zeros(n, dtype=bool)
        anyN = np.zeros(n, dtype=bool)
        for fld, op, val in conds:
            a = book.field(fld)[:, k]
            nan = np.isnan(a)
            r = OPS[op](np.round(np.where(nan, 0, a), 9), round(float(val), 9))
            anyF |= ~nan & ~r
            anyN |= nan
        hit = ~done & ~anyF & ~anyN
        miss = ~done & ~anyF & anyN
        day[hit] = k
        missing |= miss
        done |= hit | miss
    status = np.where(~book.ok, "Unsettled",
                      np.where(missing, "Missing signal data", np.where(day > 0, "Filled", "No entry")))
    return day, status


def exits(book: Book, day, status, mode):
    a = exits_arr(book, day, status, mode)
    return pd.DataFrame({"trade_id": book.ids, "signal_day": book.signal_day, "pre_state": book.state,
                         "rank": book.rank, "status": a["st"], "day": a["day"], "price": a["price"], "exit_day": a["exit_day"],
                         "ret": a["ret"], "trade_dd": a["dd"]})


def exits_arr(book: Book, day, status, mode):
    """Vectorised exit: buy at the entry day's open, sell at the exit close; drawdown over entry + closes.
    Returns plain arrays (compact: thousands of setups can be compared without holding their tables)."""
    n = book.n
    st = status.copy()
    f = status == "Filled"
    k = np.where(f, day, 1)
    e = np.where(f, 5 if mode == "original_d5" else day + 4, 1)
    rows = np.arange(n)
    kk, ee = np.clip(k, 1, PATH), np.clip(e, 1, PATH)
    Ok = book.O[rows, kk]
    j = np.arange(1, PATH + 1)[None, :]
    win = (j >= kk[:, None]) & (j <= ee[:, None])
    Cw = book.C[:, 1:]
    bad = (win & ~np.isfinite(Cw)).any(1) | ~np.isfinite(Ok) | (e > PATH)
    ok = f & ~bad
    st[f & bad] = "Missing exit data"
    with np.errstate(invalid="ignore", divide="ignore"):
        peak = np.maximum(np.maximum.accumulate(np.where(win, Cw, -np.inf), axis=1), Ok[:, None])
        ddj = np.where(win, 100 * (1 - Cw / peak), -np.inf).max(1)
        dd = np.where(ok, np.maximum(ddj, 0.0), np.nan)
        ret = np.where(ok, (book.C[rows, ee] / Ok - 1) * 100 - COST, np.nan)
    return {"st": st, "f": ok, "day": np.where(day > 0, day, np.nan).astype(float),
            "price": np.where(ok, Ok, np.nan), "exit_day": np.where(ok, e, 0), "ret": ret, "dd": dd}


def replay2(book, conds):
    """Both exits from one trigger pass, as arrays."""
    d, s = trigger(book, conds)
    return {m: exits_arr(book, d, s, m) for m in EXITS}


def arr_of(df):
    st = df["status"].to_numpy()
    return {"st": st, "f": st == "Filled", "day": df["day"].to_numpy(float), "price": df["price"].to_numpy(float),
            "ret": df["ret"].to_numpy(float), "dd": df["trade_dd"].to_numpy(float)}


def coverage(a, ok):
    st = a["st"][ok]
    return {"eligible": int(ok.sum()), "filled": int((st == "Filled").sum()), "no_entry": int((st == "No entry").sum()),
            "missing": int(np.char.startswith(st.astype(str), "Missing").sum())}


def replay(book, conds, mode):
    d, s = trigger(book, conds)
    return exits(book, d, s, mode)


# ---------------------------------------------------------------------------------------------------- setups
RULES = {"A": [("d_bb_bw_20_change", ">", 0), ("w_ret_13w_change", "<", 0)],
         "B": [("d_ema20_angle_deg_change", "<", 0), ("w_ret_13w_change", "<", 0)],
         "C": [("d_ema20_angle_deg_change", "<", 0), ("d_wq_44_change", ">", 0)]}
CONF = {"none": [], "positive_open_gap": [("gap_pct", ">", 0)],
        "positive_EMA_slope": [("d_ema20_angle_deg", ">", 0)], "declining_minus_DI": [("d_mdi14_diff1", "<", 0)]}


def abc_setups():
    out = {}
    for r in range(1, 4):
        for sub in itertools.combinations("ABC", r):
            for cn, extra in CONF.items():
                conds = list(dict.fromkeys(sum([RULES[x] for x in sub], []) + extra))
                out["+".join(sub) + "__" + cn] = conds
    return out


def control_setups():
    out = {"Blind_D%d" % k: [("day", "<=", k), ("day", ">=", k)] for k in (1, 2, 3)}
    for x in (0, 1, 2, 3, 5):                                    # price-only dip: prior close X% under the D1 open
        out["DIP_%d" % x] = [("pc_vs_d1", "<", -x if x else 0)] if x else [("pc_vs_d1", "<", 0)]
    out["BOUNCE_green"] = [("pc_vs_d1", "<", 0), ("prev_intraday", ">", 0)]      # down from D1, then a green day
    out["BOUNCE_upclose"] = [("pc_vs_d1", "<", 0), ("prev_ret", ">", 0)]         # down from D1, then an up close
    out["BOUNCE_dip2_green"] = [("pc_vs_d1", "<", -2), ("prev_intraday", ">", 0)]
    out["TUE"] = [("weekday", ">=", 1), ("weekday", "<=", 1)]                      # the first Tuesday open
    out["TUE_DIP_2"] = [("weekday", ">=", 1), ("weekday", "<=", 1), ("pc_vs_d1", "<", -2)]
    for x in (0.5, 1.0, 1.5):                                    # the dip in the stock's own ATR units
        out["DIPATR_%g" % x] = [("pc_vs_d1_atr", "<", -x)]
    return out


def labels():
    """The six distinct A/B/C labels (A+B+C has exactly A+C's conditions: A+C implies B)."""
    out = {}
    for r in range(1, 4):
        for sub in itertools.combinations("ABC", r):
            conds = list(dict.fromkeys(sum([RULES[x] for x in sub], [])))
            if frozenset(conds) not in {frozenset(v) for v in out.values()}:
                out["+".join(sub)] = conds
    return out


DIPS = {"DIP_1": [("pc_vs_d1", "<", -1)], "DIP_2": [("pc_vs_d1", "<", -2)], "DIP_3": [("pc_vs_d1", "<", -3)],
        "DIPATR_1": [("pc_vs_d1_atr", "<", -1)]}


def combo_setups(have=lambda c: True):
    """EVERY A/B/C label with each price dip (v0.5, 7 Nov: v0.2-v0.4 paired dips with B and A+B only)."""
    out = {}
    for ln, lc in labels().items():
        if have(lc):
            for dn, dc in DIPS.items():
                out["%s&%s" % (ln, dn)] = lc + dc
    return out


def explore(book, v1, boot, log=print, di=None, d1=None):
    """What adds most on top of a price dip (7 Nov, exploratory, chosen after the first run - a hypothesis search,
    not a test): every single feature condition, the 10 best pairs of the space and B / A+B, each AND a 2% dip
    (and B / A+B AND a 1-ATR dip); each compared on the same trades with the dip alone and with D1."""
    st = {"DIP_2": [("pc_vs_d1", "<", -2)], "DIPATR_1": [("pc_vs_d1_atr", "<", -1)],
          "Blind_D1": [("day", "<=", 1), ("day", ">=", 1)]}
    dip = ("pc_vs_d1", "<", -2)
    for f in book.features:
        for kind in ("", "_change"):
            for op in (">", "<"):
                st["X1|%s%s%s0" % (f, kind, op)] = [(f + kind, op, 0), dip]
    sp = v1[(v1.exit == "original_d5") & v1.setup.str.startswith("S2|")].sort_values("lift_pp", ascending=False)
    space = space_setups(book.features)
    for nm in sp.setup.head(10):
        st["X2|" + nm[3:]] = space[nm] + [dip]
    if all(c[0] in book.F for c in RULES["A"] + RULES["B"]):
        ab = list(dict.fromkeys(RULES["A"] + RULES["B"]))
        st["XA|B&DIPATR_1"] = RULES["B"] + [("pc_vs_d1_atr", "<", -1)]
        st["XA|A+B&DIPATR_1"] = ab + [("pc_vs_d1_atr", "<", -1)]
    di = boot.index(book.signal_day) if di is None else di
    bases = {k: replay2(book, st[k]) for k in ("DIP_2", "DIPATR_1", "Blind_D1")}
    d1 = d1 or bases["Blind_D1"]
    rows, srows = [], []
    fam = {"X1": "feature+dip", "X2": "pair+dip", "XA": "label+dip"}
    for nm in st:
        if not nm.startswith("X"):
            continue
        base = "DIPATR_1" if "DIPATR" in nm else "DIP_2"
        R = replay2(book, st[nm])
        for mode in EXITS:
            r = paired_fast(R[mode], bases[base][mode], boot, di)
            r1 = paired_fast(R[mode], bases["Blind_D1"][mode], boot, di)
            if r and r1:
                rows.append({"setup": nm, "exit": mode, "vs": base, **r, "lift_vs_D1": r1["lift_pp"],
                             "lo_vs_D1": r1["lo"], "hi_vs_D1": r1["hi"]})
            q = stats(R[mode], d1[mode], boot, di, book, bases[base][mode])
            if q:
                srows.append({"family": fam[nm[:2]], "setup": nm, "conds": canon(st[nm]), "twin": base,
                              "twin_conds": canon(st[base]), "exit": mode, **q})
    X = pd.DataFrame(rows)
    log(" exploration: %d setups on top of a dip" % (len(st) - 3))
    return X, srows


# ---------------------------------------------------------------------------------------------------- confluences
# Declared 7 Nov 2026, 10:30 IST, BEFORE any confluence run. Price confluences read the path known at that open;
# context confluences read the pick's snapshot at the signal close (watchlist pre_* columns). Median splits use
# the picks' own snapshot values (no outcomes).
PRICE_CONF = {"DIP1": [("pc_vs_d1", "<", -1)], "DIP2": [("pc_vs_d1", "<", -2)], "DIP3": [("pc_vs_d1", "<", -3)],
              "DIPATR1": [("pc_vs_d1_atr", "<", -1)], "GREEN": [("prev_intraday", ">", 0)],
              "UPCLOSE": [("prev_ret", ">", 0)], "GAPDOWN": [("gap_pct", "<", 0)], "GAPUP": [("gap_pct", ">", 0)]}


def context_conf(book):
    med = lambda c: float(np.nanmedian(pd.to_numeric(book.wl[c], errors="coerce"))) if c in book.wl else np.nan
    out = {"BEARSTATE": [("snap:pre_state_bearish", ">", 0.5)], "BULLSTATE": [("snap:pre_state_bullish", ">", 0.5)],
           "NIFTY_ABOVE_MA50": [("snap:pre_nifty_vs_ma50", ">", 0)],
           "NIFTY_BELOW_MA50": [("snap:pre_nifty_vs_ma50", "<", 0)],
           "MKT_BULLISH": [("snap:pre_env_code", "<=", 1)], "MKT_BEARISH": [("snap:pre_env_code", ">=", 3)],
           "VIX_LOW": [("snap:pre_vix_pct250", "<", med("pre_vix_pct250"))],
           "VIX_HIGH": [("snap:pre_vix_pct250", ">=", med("pre_vix_pct250"))],
           "BREADTH_WEAK": [("snap:pre_ad_ratio_10", "<", med("pre_ad_ratio_10"))],
           "NOT_OVEREXT": [("snap:pre_state_overextended", "<", 0.5)],
           "VOL_ELEVATED": [("snap:pre_state_vol_elevated", ">", 0.5)],
           "TOP3": [("snap:rank", "<=", 3)]}                    # v0.6: the ranks traded today (declared 7 Nov 13:00)
    return {k: v for k, v in out.items() if all(f[5:] in book.wl.columns and np.isfinite(t) for f, _, t in v)
            and not (k == "TOP3" and len(set(book.rank)) < 2)}


def make_pool(book, v1s, pool_n=10):
    """The setups that meet the confluences: NONE (the confluence alone), every A/B/C label, and from EACH engine's
    pair space its top pool_n by lift over D1 and top pool_n by net per trade (n >= 300, interval above 0,
    original_d5) - the union, so every engine tests exactly the same combinations."""
    space = space_setups(book.features)
    pool = {"NONE": []}
    for ln, lc in labels().items():                       # every A/B/C label, equally (v0.5)
        if all(c[0] in book.F for c in lc):
            pool[ln] = lc
    for v1 in v1s:
        sp = v1[(v1.exit == "original_d5") & v1.setup.str.startswith("S2|") & (v1.n >= 300) & (v1.lo > 0)]
        for nm in list(sp.sort_values("lift_pp", ascending=False).setup.head(pool_n)) + \
                list(sp.sort_values("setup_net", ascending=False).setup.head(pool_n)):
            if nm in space and frozenset(space[nm]) not in {frozenset(v) for v in pool.values()}:
                pool.setdefault(nm[3:], space[nm])
    return pool


def confluence(book, v1, boot, out, log=print, pool_n=10, di=None, pool=None):
    """Setups x logical confluences. Pool: make_pool (shared across engines in a multi-engine run). Each setup x
    each confluence (single, or one price x one context), vs D1 and vs the confluence alone on the same trade ids."""
    pool = make_pool(book, [v1], pool_n) if pool is None else pool
    ctx = context_conf(book)
    confs = {**PRICE_CONF, **ctx}
    for a, b in itertools.product(PRICE_CONF, ctx):
        confs[a + "&" + b] = PRICE_CONF[a] + ctx[b]
    st = {"Blind_D1": [("day", "<=", 1), ("day", ">=", 1)]}
    for pn, pc in pool.items():
        for cn, cc in confs.items():
            st["%s || %s" % (pn, cn)] = list(dict.fromkeys(pc + cc))
    log(" confluence: %d setups x %d confluences = %d combinations" % (len(pool), len(confs), len(st) - 1))
    di = boot.index(book.signal_day) if di is None else di
    d1 = replay2(book, st["Blind_D1"])
    alone = {cn: replay2(book, st["NONE || " + cn]) for cn in confs}       # the confluences alone, kept
    # a context filter (the pick's snapshot) only chooses WHICH trades: test it as keeps-vs-drops on its parent
    # (the same setup and price confluence without the filter)
    pick_mask = {}
    for cx, cc in ctx.items():
        msk = np.ones(book.n, bool)
        for f, op, v in cc:
            a = book.field(f)[:, 1]
            msk &= np.isfinite(a) & OPS[op](np.round(np.where(np.isfinite(a), a, 0), 9), round(float(v), 9))
        pick_mask[cx] = msk
    parents = {}

    def parent_of(pn, cn):
        if cn in ctx:
            pc, cx = [], cn
        elif "&" in cn and cn.split("&", 1)[1] in ctx:
            pc, cx = PRICE_CONF[cn.split("&", 1)[0]], cn.split("&", 1)[1]
        else:
            return None, None
        conds = list(dict.fromkeys(pool[pn] + pc)) or D1_CONDS
        k = canon(conds)
        if k not in parents:
            parents[k] = replay2(book, conds)
        return parents[k], cx
    rows, srows = [], []
    t0 = time.time()
    for i, name in enumerate(st):
        if name == "Blind_D1":
            continue
        pn, cn = name.split(" || ")
        R = alone[cn] if pn == "NONE" else replay2(book, st[name])
        for mode in EXITS:
            r = stats(R[mode], d1[mode], boot, di, book, None if pn == "NONE" else alone[cn][mode])
            if not r:
                continue
            par, cx = parent_of(pn, cn)
            if par is not None:
                pa = par[mode]
                keep = pa["f"] & pick_mask[cx]
                drop = pa["f"] & ~pick_mask[cx]
                if keep.sum() > 1 and drop.sum() > 1:
                    lo95, hi95, sd = boot.ci_diff(di[keep], pa["ret"][keep], di[drop], pa["ret"][drop])
                    r.update({"filter_gain": float(pa["ret"][keep].mean() - pa["ret"][drop].mean()),
                              "filter_lo": lo95, "filter_hi": hi95, "filter_sd": sd, "filter_kept": int(keep.sum()),
                              "filter_dropped": int(drop.sum())})
            row = {"setup": pn, "confluence": cn, "exit": mode, **r}
            if "adds" in r:
                row.update({"adds_over_conf": r["adds"]})
            rows.append(row)
            srows.append({"family": "confluence-alone" if pn == "NONE" else "confluence", "setup": name,
                          "conds": canon(st[name]), "twin": "" if pn == "NONE" else "NONE || " + cn,
                          "twin_conds": "" if pn == "NONE" else canon(st["NONE || " + cn]), "exit": mode, **r})
        if (i + 1) % 500 == 0:
            log(" confluence: %d of %d (%.0f s)" % (i + 1, len(st) - 1, time.time() - t0))
    X = pd.DataFrame(rows)
    SR = pd.DataFrame(srows)
    if "filter_gain" in X:
        # every filter test of the run counts: one-sided p from the bootstrap, Benjamini-Hochberg q over all of them
        X["filter_p"] = filter_p(X["filter_gain"], X["filter_sd"])
        X["filter_q"] = bh_q(X["filter_p"])
        SR["filter_p"], SR["filter_q"] = X["filter_p"].to_numpy(), X["filter_q"].to_numpy()
        m = X["filter_p"].notna()
        log(" confluence: %d context-filter tests; %d keep clearly better trades (false discovery rate %.0f%%)" % (
            int(m.sum()), int((X["filter_q"] <= LB_FDR).sum()), 100 * LB_FDR))
    X.to_csv(out / "confluence.csv", index=False)
    L = ["# setuplab - setups x logical confluences (%s) - engine %s, ranks %d-%d, %d picks" % (
        VERSION, book.engine, min(book.rank), max(book.rank), book.n), "",
         "Pool: %s." % ", ".join(pool), "",
         "Confluences (declared before the run): price %s; context %s; and every price x context pair." % (
             ", ".join(PRICE_CONF), ", ".join(ctx)), "",
         "Each row: the combination's own trades vs the model's D1 entry on the same ids; 'adds' = the same "
         "combination vs the confluence ALONE on the same ids (what the indicator setup adds); years = signal years "
         "with net per trade above 0. Net %% after 0.35 pp; 95%% block bootstrap over signal days. Exploratory: "
         "%d combinations on the history the setups came from - expect some to look good by chance." % (len(st) - 1),
         ""]
    for mode in EXITS:
        m = X[(X.exit == mode) & (X.n >= 150)]
        best = m[(m.setup != "NONE") & (m.lo > 0)].sort_values("setup_net", ascending=False).head(25)
        L += ["## %s exit - top 25 combinations by net per trade (n >= 150, lift over D1 interval above 0)" % mode,
              "", "| setup | confluence | n | net | D1 | lift over D1 [95%] | adds over the confluence alone [95%] "
              "| years net > 0 |", "|---|---|---:|---:|---:|---|---|---:|"]
        for _, r in best.iterrows():
            L.append("| %s | %s | %d | %+.4f | %+.4f | %+.4f [%+.4f, %+.4f] | %s | %d/%d |" % (
                r.setup, r.confluence, r.n, r.setup_net, r.control_net, r.lift_pp, r.lo, r.hi,
                ("%+.4f [%+.4f, %+.4f]" % (r.adds_over_conf, r.adds_lo, r.adds_hi)) if pd.notna(
                    r.get("adds_over_conf")) else "-", r.years_net_pos, r.years))
        base = m[m.setup == "NONE"].sort_values("setup_net", ascending=False).head(15)
        L += ["", "### The confluences ALONE (no indicator setup) - top 15 by net per trade (n >= 150)", "",
              "| confluence | n | net | D1 | lift over D1 [95%] | years net > 0 |", "|---|---:|---:|---:|---|---:|"]
        for _, r in base.iterrows():
            L.append("| %s | %d | %+.4f | %+.4f | %+.4f [%+.4f, %+.4f] | %d/%d |" % (
                r.confluence, r.n, r.setup_net, r.control_net, r.lift_pp, r.lo, r.hi, r.years_net_pos, r.years))
        L.append("")
    (out / "CONFLUENCE.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    SR.to_csv(out / "setups_confluence.csv", index=False)
    (out / "confluence.done").write_text(time.strftime("%Y-%m-%d %H:%M:%S") + "\n", encoding="utf-8")
    log(" confluence: wrote CONFLUENCE.md, confluence.csv, setups_confluence.csv")
    return X


def filter_p(gain, sd):
    """One-sided p-value of 'the filter keeps better trades than it drops' (normal approximation, bootstrap sd)."""
    g, s_ = np.asarray(gain, float), np.asarray(sd, float)
    with np.errstate(invalid="ignore", divide="ignore"):
        z = np.where(s_ > 0, g / s_, np.nan)
    return np.array([0.5 * math.erfc(v / math.sqrt(2)) if np.isfinite(v) else np.nan for v in z])


def bh_q(p):
    """Benjamini-Hochberg q-values (the false discovery rate at which each test would pass)."""
    p = np.asarray(p, float)
    q = np.full(p.shape, np.nan)
    ok = np.isfinite(p)
    m = int(ok.sum())
    if m:
        o = np.argsort(p[ok])
        r = p[ok][o] * m / np.arange(1, m + 1)
        r = np.minimum(np.minimum.accumulate(r[::-1])[::-1], 1.0)
        qq = np.empty(m)
        qq[o] = r
        q[ok] = qq
    return q


def space_setups(features):
    """Every single-feature change direction and every pair of change directions (the A/B/C family)."""
    out = {}
    for f in features:
        for op in (">", "<"):
            out["S1|%s_change%s0" % (f, op)] = [(f + "_change", op, 0)]
    for f, g in itertools.combinations(features, 2):
        for a, b in itertools.product((">", "<"), repeat=2):
            out["S2|%s_change%s0&%s_change%s0" % (f, a, g, b)] = [(f + "_change", a, 0), (g + "_change", b, 0)]
    return out


# ---------------------------------------------------------------------------------------------------- statistics
class Boot:
    """Circular block bootstrap over signal days, shared index draws so every comparison uses the same resamples."""

    def __init__(self, days, B=2000, block=10, seed=7):
        self.days = np.sort(np.unique(days))
        self.pos = {d: i for i, d in enumerate(self.days)}
        n = len(self.days)
        rng = np.random.default_rng(seed)
        nb = int(np.ceil(n / block))
        st = rng.integers(0, n, size=(B, nb))
        self.ix = ((st[:, :, None] + np.arange(block)[None, None, :]) % n).reshape(B, -1)[:, :n]
        # M[b, d] = how often day d is in resample b: a resample's sum = M @ per-day sums (same draws, faster)
        flat = (np.arange(B)[:, None] * n + self.ix).ravel()
        self.M = np.bincount(flat, minlength=B * n).reshape(B, n).astype(float)

    def ci(self, days, vals):
        return self.ci_idx(np.array([self.pos[d] for d in days]), vals)

    def index(self, days):
        return np.array([self.pos.get(d, -1) for d in days])

    def ci_diff(self, da, va, db, vb):
        """mean(va) - mean(vb), both groups resampled with the same days (dependence kept): the 95% percentile
        interval and the bootstrap standard deviation (for a widened interval)."""
        n = len(self.days)
        X = self.M @ np.column_stack([np.bincount(da, weights=va, minlength=n), np.bincount(da, minlength=n),
                                      np.bincount(db, weights=vb, minlength=n), np.bincount(db, minlength=n)])
        with np.errstate(invalid="ignore", divide="ignore"):
            d = X[:, 0] / np.where(X[:, 1] > 0, X[:, 1], np.nan) - X[:, 2] / np.where(X[:, 3] > 0, X[:, 3], np.nan)
        return float(np.nanpercentile(d, 2.5)), float(np.nanpercentile(d, 97.5)), float(np.nanstd(d))

    def ci_idx(self, di, vals):
        s = np.bincount(di, weights=vals, minlength=len(self.days))
        c = np.bincount(di, minlength=len(self.days)).astype(float)
        S, Cn = self.M @ s, self.M @ c
        m = S / np.where(Cn > 0, Cn, np.nan)
        return float(np.nanpercentile(m, 2.5)), float(np.nanpercentile(m, 97.5))


def paired(a: pd.DataFrame, b: pd.DataFrame, boot: Boot):
    """a's filled trades vs b's on exactly the ids both filled (a = setup, b = control)."""
    A = a[a.status == "Filled"].set_index("trade_id")
    Bf = b[b.status == "Filled"].set_index("trade_id")
    ids = A.index.intersection(Bf.index)
    if len(ids) == 0:
        return None
    x, y = A.loc[ids], Bf.loc[ids]
    lift = x["ret"].to_numpy() - y["ret"].to_numpy()
    lo, hi = boot.ci(x["signal_day"].to_numpy(), lift) if len(ids) > 1 else (np.nan, np.nan)
    disc = (y["price"].to_numpy() / x["price"].to_numpy() - 1) * 100     # % the setup bought under the control
    return {"n": len(ids), "control_net": float(y["ret"].mean()), "setup_net": float(x["ret"].mean()),
            "lift_pp": float(lift.mean()), "lo": lo, "hi": hi, "setup_better_pct": float(100 * (lift > 0).mean()),
            "entry_cheaper_pct": float(np.mean(disc)), "setup_dd": float(x["trade_dd"].mean()),
            "control_dd": float(y["trade_dd"].mean()), "setup_p5": float(np.percentile(x["ret"], 5)),
            "control_p5": float(np.percentile(y["ret"], 5)),
            "mean_entry_day": float(x["day"].mean())}


def paired_fast(a, b, boot, di):
    """paired() on aligned arrays from the same book (same numbers; no tables)."""
    m = a["f"] & b["f"]
    n = int(m.sum())
    if n == 0:
        return None
    x, y = a["ret"][m], b["ret"][m]
    lift = x - y
    lo, hi = boot.ci_idx(di[m], lift) if n > 1 else (np.nan, np.nan)
    disc = (b["price"][m] / a["price"][m] - 1) * 100
    return {"n": n, "control_net": float(np.mean(y)), "setup_net": float(np.mean(x)), "lift_pp": float(lift.mean()),
            "lo": lo, "hi": hi, "setup_better_pct": float(100 * (lift > 0).mean()),
            "entry_cheaper_pct": float(np.mean(disc)), "setup_dd": float(np.mean(a["dd"][m])),
            "control_dd": float(np.mean(b["dd"][m])), "setup_p5": float(np.percentile(x, 5)),
            "control_p5": float(np.percentile(y, 5)), "mean_entry_day": float(np.mean(a["day"][m]))}


def stats(a, base, boot, di, book, twin=None):
    """Everything the comparison and the leaderboard need for one setup and one exit, on aligned arrays:
    the setup's own filled trades vs D1 (base) on the same ids - n, net and its 95% interval, the lift and its
    interval, years with net > 0, the two halves of the period, coverage; and, when the setup has an
    indicator-free twin (the same dip / confluence without the indicator conditions), what the indicators add."""
    m = a["f"] & base["f"]
    n = int(m.sum())
    if n == 0:
        return None
    x, y = a["ret"][m], base["ret"][m]
    lift = x - y
    lo, hi = boot.ci_idx(di[m], lift) if n > 1 else (np.nan, np.nan)
    nlo, nhi = boot.ci_idx(di[m], x) if n > 1 else (np.nan, np.nan)
    disc = (base["price"][m] / a["price"][m] - 1) * 100
    r = {"n": n, "control_net": float(np.mean(y)), "setup_net": float(np.mean(x)), "lift_pp": float(lift.mean()),
         "lo": lo, "hi": hi, "net_lo": nlo, "net_hi": nhi, "setup_better_pct": float(100 * (lift > 0).mean()),
         "entry_cheaper_pct": float(np.mean(disc)), "setup_dd": float(np.mean(a["dd"][m])),
         "control_dd": float(np.mean(base["dd"][m])), "setup_p5": float(np.percentile(x, 5)),
         "control_p5": float(np.percentile(y, 5)), "mean_entry_day": float(np.mean(a["day"][m]))}
    ys = book.yi[m]
    sm, ct = np.bincount(ys, weights=x), np.bincount(ys)
    r["years_net_pos"] = int(((ct > 0) & (sm > 0)).sum())
    r["years"] = int((ct > 0).sum())
    for h in (0, 1):
        hm = book.half[m] == h
        r["half%d_n" % (h + 1)] = int(hm.sum())
        r["half%d_net" % (h + 1)] = float(x[hm].mean()) if hm.any() else np.nan
    r.update(coverage(a, book.ok))
    r["fill_pct"] = 100.0 * r["filled"] / max(1, r["eligible"])
    r["trades_per_year"] = n / book.span_years
    if twin is not None:
        m2 = a["f"] & twin["f"]
        n2 = int(m2.sum())
        if n2:
            d = a["ret"][m2] - twin["ret"][m2]
            alo, ahi = boot.ci_idx(di[m2], d) if n2 > 1 else (np.nan, np.nan)
            r.update({"adds": float(d.mean()), "adds_lo": alo, "adds_hi": ahi, "adds_n": n2,
                      "twin_net": float(np.mean(twin["ret"][m2]))})
    return r


def canon(conds):
    """A setup's identity: its conditions, sorted (the same rule found by two routes counts once)."""
    return json.dumps(sorted([[f, op, float(v)] for f, op, v in dict.fromkeys(conds)]))


def uncanon(text):
    return [(f, op, v) for f, op, v in json.loads(text)]


# ---------------------------------------------------------------------------------------------------- build
def watchlist_rows(picks, bars, cal_days):
    """The watchlist (ChatGPT's format) from each stock's own daily bars.
    picks: rows with trade_id, engine, rank, symbol, signal_day, j (the signal bar's index in the stock's own bars);
    bars: symbol -> (o, c, cal_index of each own bar); cal_days: the session calendar.
    entry = the next own bar's open (D1); close_k = own bar j+k's close / entry - 1; overnight_k (k >= 2) = own bar
    j+k's open / own bar j+k-1's close - 1; missing bars past the data's end are NaN."""
    out = []
    for p in picks:
        o, c, ci = bars[p["symbol"]]
        j = int(p["j"])
        n = len(c)
        if j + 1 >= n:
            continue
        ent, sc = float(o[j + 1]), float(c[j])
        row = {"trade_id": p["trade_id"], "engine": p["engine"], "rank": int(p["rank"]), "symbol": p["symbol"],
               "signal_day": pd.Timestamp(p["signal_day"]), "entry_day": str(pd.Timestamp(cal_days[ci[j + 1]]).date()),
               "signal_close": sc, "entry": ent}
        for k in range(1, PATH + 1):
            row["close_%d" % k] = float(c[j + k]) / ent - 1 if j + k < n else np.nan
            row["overnight_%d" % k] = (0.0 if k == 1 else (float(o[j + k]) / float(c[j + k - 1]) - 1)
                                       if j + k < n else np.nan)
        out.append(row)
    return pd.DataFrame(out)


def check_watchlists(W, ref_path):
    """The built watchlist vs ChatGPT's (ranks 1-3): entry, signal close, the ten closes and gaps."""
    C = pd.read_parquet(ref_path)
    C["trade_id"] = C["trade_id"].astype(str)
    W = W.copy()
    W["trade_id"] = W["trade_id"].astype(str)
    M = W.merge(C, on="trade_id", suffixes=("", "_ref"))
    cols = ["entry", "signal_close"] + ["close_%d" % k for k in range(1, PATH + 1)] + \
           ["overnight_%d" % k for k in range(2, PATH + 1)]
    cols = [c for c in cols if c in M and c + "_ref" in M]
    diff = np.column_stack([(M[c].astype(float) - M[c + "_ref"].astype(float)).abs().to_numpy() for c in cols]) \
        if cols and len(M) else np.zeros((0, 1))
    same = np.all(np.isnan(diff) | (diff < 1e-6), axis=1) if len(M) else np.zeros(0, bool)
    verdict = "MATCHED" if len(M) and same.mean() >= 0.995 else "DIFFERS"
    text = ("check vs %s: %d of its %d picks are in this watchlist, %d identical on entry / closes / gaps (%.2f%%), "
            "largest difference %.2e -> %s" % (Path(ref_path).name, len(M), len(C), int(same.sum()),
                                                100 * same.mean() if len(M) else 0,
                                                np.nanmax(diff) if diff.size and len(M) else np.nan, verdict))
    return {"common": int(len(M)), "reference": int(len(C)), "identical": int(same.sum()), "verdict": verdict,
            "text": text}


def cmd_build(a, log=print):
    """picks (pick_meta, any ranks) + each stock's bars (the daily cache, through playbook's reader = v2engine's
    adapter, READ ONLY) + the context (tradelab's export trades.parquet: status, net_bp, s_atr14, pre_*)."""
    try:
        import playbook as PB
    except ImportError:
        print("REFUSED: playbook is not importable - run  call ...\\playbook\\env_playbook.bat  first")
        return 3
    ex = Path(a.export)
    if not (ex / "trades.parquet").is_file():
        print("REFUSED: no trades.parquet in %s" % ex)
        return 3
    T = pd.read_parquet(ex / "trades.parquet")
    T["trade_id"] = T["trade_id"].astype(str)
    ranks = a.ranks_list or list(range(1, 11))
    engines = [e.strip() for e in a.engines.split(",") if e.strip()]
    d_from = str(pd.to_datetime(T["signal_day"]).min().date())
    d_to = a.to or str(pd.to_datetime(T["signal_day"]).max().date())
    log("%s build: engines %s, ranks %s, signal days %s .. %s" % (VERSION, engines, ranks, d_from, d_to))
    picks, own, data = PB.load(a.root, a.pm_run, engines, ranks, d_from, d_to, log=log,
                               stage_e_any=a.stage_e_any, costs=a.costs)
    cal_days = np.asarray(data.cal.days)
    bars = {s: (ob.o, ob.c, idx) for s, (idx, ob) in own.items()}
    P = [{"trade_id": p.id, "engine": p.engine, "rank": p.rank, "symbol": p.symbol, "signal_day": p.T, "j": p.t_own}
         for p in picks]
    W = watchlist_rows(P, bars, cal_days)
    keep = [c for c in T.columns if c.startswith("pre_") or c in ("status", "net_bp", "s_atr14", "entry", "score",
                                                                    "open6_status", "open6_net_bp")]
    W = W.merge(T[["trade_id"] + keep].rename(columns={"entry": "export_entry"}), on="trade_id", how="left")
    W["status"] = W["status"].fillna("not in the export")
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    W.to_parquet(out / "watchlist.parquet", index=False)
    first = W["signal_day"].min() - pd.Timedelta(days=10)
    pd.DataFrame({"date": pd.to_datetime(cal_days[cal_days >= np.datetime64(first)])}).to_parquet(
        out / "calendar.parquet", index=False)
    d = (W["entry"] / W["export_entry"] - 1).abs()
    log(" %d picks (%s); entry vs the export's recorded entry: %d of %d within 1e-6, largest difference %.2e" % (
        len(W), ", ".join("%s %d" % kv for kv in W.groupby("engine").size().items()), int((d < 1e-6).sum()),
        int(d.notna().sum()), float(d.max()) if d.notna().any() else np.nan))
    if a.check:
        res = check_watchlists(W, a.check)
        log(" " + res["text"])
        print("BUILD CHECK " + res["verdict"])
    log(" wrote %s" % out)
    return 0


# ---------------------------------------------------------------------------------------------------- commands
RAW_LEVEL = re.compile(r"^d_(sma|ema)\d+$|^d_atr(14|30)$|^d_cpr_(pivot|bc|tc)$|^d_(support|resistance)\d+$|vpoc|"
                       r"^d_breakout_(high|low)_\d+$|^d_obv$|macd|midpoint_slope|dollar_vol$|_code$|_trend$|"
                       r"^d_dow$|^comb_|prev_inside_day|ema_stack|^label_|(^|_)(open|high|low|close|vwap)$")


def pick_features(why_csv, top, panel, engine="D"):
    """The engine's top features by the WHY surrogate's importance (why_features.csv), skipping raw price levels /
    price-scaled values, categorical codes, the day of week, combined flags and anything not in the panel.
    Returns (chosen, skipped-with-reason)."""
    import pyarrow.parquet as pq
    W = pd.read_csv(why_csv)
    if "engine" in W.columns:
        W = W[W["engine"] == engine]
    W = W.sort_values("importance", ascending=False)
    have = {c.lower() for c in pq.read_schema(panel).names}
    chosen, skipped = [], []
    for f in W["feature"].astype(str):
        if len(chosen) >= top:
            break
        lf = f.lower()
        if RAW_LEVEL.search(lf):
            skipped.append((f, "raw level / code / flag"))
        elif lf not in have:
            skipped.append((f, "not in the panel"))
        else:
            chosen.append(f)
    return chosen, skipped


REQUIRED = ("d_ema20_angle_deg", "w_ret_13w", "d_bb_bw_20", "d_wq_44", "d_mdi14_diff1")   # A/B/C + confirmations


def read_columns_file(path):
    """One feature name per line; '#' starts a comment."""
    out = []
    for ln in Path(path).read_text(encoding="utf-8").splitlines():
        ln = ln.split("#", 1)[0].strip()
        if ln:
            out.append(ln)
    return list(dict.fromkeys(out))


def load(data, features, engine="D", feature_cols=None, ranks=None, log=lambda *a: None, chunk=8):
    """engine None = every engine in the watchlist (split later with Book.take). feature_cols: read only these
    columns, a few at a time (the big panel); a missing column is skipped and listed, except the A/B/C ones."""
    wl = pd.read_parquet(Path(data) / "watchlist.parquet")
    cal = pd.read_parquet(Path(data) / "calendar.parquet")["date"]
    if features and feature_cols:
        book = Book(wl, cal, None, engine, None, ranks)
        want, miss = book.attach(features, feature_cols, chunk, log)
        book.missing_features = miss
        need = [c for c in REQUIRED if c in [x.lower() for x in feature_cols] and c not in book.features]
        if need:
            raise ValueError("the A/B/C features are not in the feature file: " + ", ".join(need))
        if not book.features:
            raise ValueError("none of the feature columns is in the feature file")
        return book
    F = pd.read_parquet(features) if features else None
    book = Book(wl, cal, F, engine, feature_cols, ranks)
    book.missing_features = []
    return book


def cmd_reproduce(book, ledgers):
    setups = {**abc_setups(), "Blind_D1": [("day", "<=", 1), ("day", ">=", 1)],
              "Blind_D3": [("day", "<=", 3), ("day", ">=", 3)]}
    worst = 0.0
    bad = []
    n = 0
    for name, conds in setups.items():
        for mode in EXITS:
            fn = Path(ledgers) / (("%s__%s.csv.gz" % (name, mode)) if not name.startswith("Blind")
                                  else ("%s_%s.csv.gz" % (name, mode)))
            if not fn.is_file():
                bad.append((name, mode, "no ledger"))
                continue
            L = pd.read_csv(fn).set_index("trade_id")
            R = replay(book, conds, mode).set_index("trade_id")
            ids = L.index.intersection(R.index)
            st_ok = (L.loc[ids, "status"].astype(str) == R.loc[ids, "status"].astype(str))
            f = ids[(L.loc[ids, "status"] == "Filled").to_numpy()]
            dret = np.abs(L.loc[f, "ret"].to_numpy(float) - R.loc[f, "ret"].to_numpy(float))
            dday = (L.loc[f, "day"].to_numpy(float) != R.loc[f, "day"].to_numpy(float)).sum()
            w = float(np.nanmax(dret)) if len(dret) else 0.0
            worst = max(worst, w)
            n += 1
            if (~st_ok).sum() or dday or w > 1e-6 or len(ids) != len(L):
                bad.append((name, mode, "status %d, day %d, ret %.2e, ids %d/%d" % (int((~st_ok).sum()), int(dday), w,
                                                                                  len(ids), len(L))))
    return n, bad, worst


def run_all(book, setups, boot):
    led = {}
    for name, conds in setups.items():
        for mode in EXITS:
            led[(name, mode)] = replay(book, conds, mode)
    return led


def compare(led, names, controls, boot):
    rows = []
    for name in names:
        for mode in EXITS:
            for ctl in controls:
                if ctl == name:
                    continue
                r = paired(led[(name, mode)], led[(ctl, mode)], boot)
                if r:
                    rows.append({"setup": name, "exit": mode, "control": ctl, **r})
    return pd.DataFrame(rows)


def family_twin(name):
    """The family of a setup of the small set and its indicator-free twin (None when it has none)."""
    if name.startswith("Blind_"):
        return "control", None
    if name in control_setups():
        return "price-only", None
    if "&" in name and name.split("&", 1)[1] in DIPS:
        return "label+dip", name.split("&", 1)[1]
    return ("label", None) if name.endswith("__none") else ("label+confirmation", None)


def stage1(book, out, log=print):
    """Every setup except the confluences: controls, A/B/C labels (+ confirmations, + dips), the pair space, the
    dip exploration. Writes the report files and setups_stage1.csv (one row per setup and exit, for the
    leaderboard). Returns v1, v2, the rows, the bootstrap and the day index."""
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    have = lambda conds: all(f in book.F or f in PRICE_FIELDS for f, _, _ in conds)
    abc = {k: v for k, v in abc_setups().items() if have(v)}       # A/B/C only when their features are loaded
    ctl = control_setups()
    space = space_setups(book.features)
    combo = combo_setups(have)
    setups = {**ctl, **abc, **combo}
    log("%s: engine %s, %d trades, %d setups (%d A/B/C, %d controls, %d combos, %d feature-space), 2 exits" % (
        VERSION, book.engine, book.n, len(setups) + len(space), len(abc), len(ctl), len(combo), len(space)))
    led = run_all(book, setups, None)
    boot = Boot(book.signal_day[book.ok])
    di = boot.index(book.signal_day)
    arrs = {k: {m: arr_of(led[(k, m)]) for m in EXITS} for k in setups}
    d1 = arrs["Blind_D1"]
    v1rows, srows = [], []

    def add(name, family, conds, R, twin=None):
        for m in EXITS:
            r = stats(R[m], d1[m], boot, di, book, arrs[twin][m] if twin else None)
            if r:
                v1rows.append({"setup": name, "exit": m, "control": "Blind_D1", **r})
                srows.append({"family": family, "setup": name, "conds": canon(conds), "twin": twin or "",
                              "twin_conds": canon(setups[twin]) if twin else "", "exit": m, **r})
    # 1. every setup vs the model's D1 entry on its own trades (the pair space streamed: compared, then dropped)
    for k, c in setups.items():
        fam, tw = family_twin(k)
        add(k, fam, c, arrs[k], tw)
    for i, (name, conds) in enumerate(space.items()):
        add(name, "single" if name.startswith("S1|") else "pair", conds, replay2(book, conds))
        if (i + 1) % 1000 == 0:
            log(" pair space: %d of %d (%.0f s)" % (i + 1, len(space), time.time() - t0))
    v1 = pd.DataFrame(v1rows)
    log(" replayed in %.0f s" % (time.time() - t0))
    # 2. A/B/C and the combos vs the price-only controls on the same trades
    keys = [k for k in abc if k.endswith("__none")] + list(combo)
    v2 = compare(led, keys, [c for c in ctl if c != "Blind_D1"], boot)
    # by signal year: the key setups vs D1 and vs the 2% dip on the same trades
    yrs = []
    key_names = [k + "__none" for k in labels() if k + "__none" in abc] + [k for k in combo if k.endswith("&DIP_2")]
    for name in key_names:
        for mode in EXITS:
            a = led[(name, mode)]
            a = a[a.status == "Filled"].set_index("trade_id")
            for c in ("Blind_D1", "DIP_2"):
                b = led[(c, mode)]
                b = b[b.status == "Filled"].set_index("trade_id")
                ids = a.index.intersection(b.index)
                z = pd.DataFrame({"year": pd.to_datetime(a.loc[ids, "signal_day"]).dt.year,
                                  "setup": a.loc[ids, "ret"], "lift": a.loc[ids, "ret"] - b.loc[ids, "ret"]})
                for y, g in z.groupby("year"):
                    yrs.append({"setup": name, "exit": mode, "control": c, "year": y, "n": len(g),
                                "setup_net": g.setup.mean(), "lift_pp": g.lift.mean()})
    yrs = pd.DataFrame(yrs)
    yrs.to_csv(out / "by_year.csv", index=False)
    sts = by_state(led, key_names + ["DIP_2"], boot)
    sts.to_csv(out / "by_state.csv", index=False)
    rks = None
    if len(set(book.rank)) > 1:
        rks = by_rank(led, key_names + ["DIP_2"], boot)
        rks.to_csv(out / "by_rank.csv", index=False)
    # rank of each setup's lift inside the feature space (same exit)
    sp = v1[v1.setup.str.startswith("S2|")]
    for mode in EXITS:
        ref = np.sort(sp[sp.exit == mode]["lift_pp"].to_numpy())
        m = v1.exit == mode
        v1.loc[m, "pct_of_pair_space"] = [100 * np.searchsorted(ref, x, side="right") / max(1, len(ref))
                                          for x in v1.loc[m, "lift_pp"]]
    X, xrows = explore(book, v1, boot, log, di, d1)
    srows += xrows
    X.to_csv(out / "explore_on_dip.csv", index=False)
    v1.to_csv(out / "vs_D1.csv", index=False)
    v2.to_csv(out / "vs_price_controls.csv", index=False)
    (out / "ledgers").mkdir(exist_ok=True)
    for (name, mode), d in led.items():
        if not name.startswith("S"):
            d.to_csv(out / "ledgers" / ("%s__%s.csv.gz" % (name, mode)), index=False)
    report(v1, v2, out, book, yrs, X, sts, rks)
    S1 = pd.DataFrame(srows)
    S1.to_csv(out / "setups_stage1.csv", index=False)
    (out / "stage1.done").write_text(time.strftime("%Y-%m-%d %H:%M:%S") + "\n", encoding="utf-8")
    log(" stage 1 written (%.0f s)" % (time.time() - t0))
    return v1, v2, S1, boot, di


def cmd_run(book, out, log=print, with_confluence=False):
    """One engine: stage 1 (+ the confluences with its own pool), files in out."""
    t0 = time.time()
    out = Path(out)
    v1, v2, S1, boot, di = stage1(book, out, log)
    if with_confluence:
        confluence(book, v1, boot, out, log, di=di)
    log(" wrote %s (%.0f s)" % (out, time.time() - t0))
    return v1, v2


def cmd_run_multi(books, out, log=print, with_confluence=True):
    """Several engines in one run: stage 1 for each (resumed when its stage1.done exists), ONE confluence pool for
    all (the union of each engine's choice, POOL.json), the confluences for each (resumed likewise), then the
    leaderboard across engines."""
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    res = {}
    for e, b in books.items():
        d = out / e
        if (d / "stage1.done").is_file() and (d / "vs_D1.csv").is_file():
            log(" %s: stage 1 already done - resumed from %s" % (e, d))
            boot = Boot(b.signal_day[b.ok])
            res[e] = (pd.read_csv(d / "vs_D1.csv"), boot, boot.index(b.signal_day))
        else:
            v1, v2, S1, boot, di = stage1(b, d, log)
            res[e] = (v1, boot, di)
    if with_confluence:
        pf = out / "POOL.json"
        if pf.is_file():
            pool = {k: [tuple(c) for c in v] for k, v in json.loads(pf.read_text(encoding="utf-8")).items()}
            log(" confluence pool: %d setups (from POOL.json)" % len(pool))
        else:
            pool = make_pool(next(iter(books.values())), [r[0] for r in res.values()])
            pf.write_text(json.dumps(pool, indent=1), encoding="utf-8")
            log(" confluence pool: %d setups, the same for every engine (POOL.json)" % len(pool))
        for e, b in books.items():
            d = out / e
            if (d / "confluence.done").is_file():
                log(" %s: confluences already done - resumed" % e)
                continue
            v1, boot, di = res[e]
            confluence(b, v1, boot, d, log, di=di, pool=pool)
    return leaderboard(books, out, log)


# ---------------------------------------------------------------------------------------------------- leaderboard
LB_MIN_N = 300
LB_MIN_YEARS = 6
LB_OVERLAP = 0.70
LB_TOP = 3
LB_FDR = 0.05
FAMILY_ORDER = ("label", "label+dip", "label+confirmation", "price-only", "control", "single", "pair", "feature+dip",
                "pair+dip", "confluence", "confluence-alone")
LB_RULE = [
    "Declared 7 Nov 2026 (13:00 IST) before the final run, applied by the code - nobody picks by eye.",
    "Universe: every setup of the run - controls and price-only rules, the A/B/C labels (with and without "
    "confirmations and dips), every single feature and pair, the dip exploration, every setup x confluence and every "
    "confluence alone - each counted once by its conditions, and only if it was tested in every engine of the run.",
    "ELIGIBLE (for one exit) when in EVERY engine: (1) at least %d trades; (2) the lift over the model's D1 entry on its "
    "own trades has a 95%% interval above 0 (Karan's comparison); (3) when it has an indicator-free twin (the same dip "
    "/ confluence without the indicator conditions), the indicators add with a 95%% interval above 0; (4) trades in at "
    "least %d signal years and net per trade above 0 in all but at most one; (5) net per trade above 0 in both halves "
    "of the period." % (LB_MIN_N, LB_MIN_YEARS),
    "(6) A context filter (a condition on the pick's snapshot at the signal: state, market, NIFTY, VIX, breadth, the "
    "volatility flag, the rank) only chooses WHICH trades to take: it must keep better trades than it drops - the same "
    "setup's trades with the filter minus those without it - and pass after counting EVERY filter test of the run "
    "(thousands: each setup meets every context filter, alone and with each price confluence): a false discovery "
    "rate of at most 5% (Benjamini-Hochberg), in every engine. Otherwise a filter that kept a lucky subset would "
    "float a setup to the top: a filtered setup gets no more chances to pass by luck than a plain one.",
    "SCORE = the lower end of the 95% interval of net per trade (after 0.35 pp) in the worst engine: money per trade, "
    "marked down for small samples and for disagreement between the engines.",
    "Lists: BOTH EXITS (eligible under original_d5 AND fresh; score = the lower of the two) is the main list; each "
    "exit on its own follows.",
    "Top %d = the best scores, skipping VERSIONS of a setup already chosen: a setup whose rule (leaving out the "
    "context filters) contains the other's rule or is contained in it, or whose trades overlap %d%% or more with it "
    "(of the smaller set, first engine). Different setups, not versions of one." % (LB_TOP, int(LB_OVERLAP * 100)),
]
D1_CONDS = [("day", "<=", 1), ("day", ">=", 1)]


def lb_table(out, engines):
    """One row per setup (by its conditions) and exit, with every engine's numbers side by side (engine:field)."""
    per = {}
    for e in engines:
        parts = [pd.read_csv(Path(out) / e / f) for f in ("setups_stage1.csv", "setups_confluence.csv")
                 if (Path(out) / e / f).is_file()]
        T = pd.concat(parts, ignore_index=True)
        for c in ("twin", "twin_conds"):
            T[c] = T[c].fillna("").astype(str)
        T["_fam"] = T["family"].map({f: i for i, f in enumerate(FAMILY_ORDER)}).fillna(99)
        per[e] = T.sort_values("_fam", kind="stable").drop_duplicates(["conds", "exit"], keep="first")
    keys, meta = ["conds", "exit"], ["family", "setup", "twin", "twin_conds", "_fam"]
    W = per[engines[0]][keys + meta[:-1]].copy()
    for e in engines:
        T = per[e].set_index(keys)
        W = W.join(T[[c for c in T.columns if c not in meta]].add_prefix(e + ":"), on=keys, how="inner")
    return W.reset_index(drop=True)


def rank_rows(W, engines, min_n=LB_MIN_N, min_years=LB_MIN_YEARS):
    """The declared eligibility (with the reasons a setup fails) and the score."""
    W = W.copy()
    twin = W["twin_conds"].fillna("").astype(str).to_numpy() != ""
    filt = W["conds"].astype(str).str.contains('"snap:', regex=False).to_numpy()
    ok = np.ones(len(W), bool)
    why = [[] for _ in range(len(W))]

    def flag(bad, text):
        bad = np.asarray(bad, bool)
        ok[bad] = False
        for i in np.flatnonzero(bad):
            why[i].append(text)
    for e in engines:
        g = lambda c: pd.to_numeric(W["%s:%s" % (e, c)], errors="coerce").to_numpy(float) if \
            "%s:%s" % (e, c) in W else np.full(len(W), np.nan)
        flag(~(g("n") >= min_n), "%s: fewer than %d trades" % (e, min_n))
        flag(~(g("lo") > 0), "%s: lift over D1 not clearly above 0" % e)
        flag(twin & ~(g("adds_lo") > 0), "%s: the indicators add nothing clear over the same entry without them" % e)
        flag(~(g("years") >= min_years), "%s: trades in fewer than %d years" % (e, min_years))
        flag(~(g("years_net_pos") >= g("years") - 1), "%s: net <= 0 in more than one year" % e)
        flag(~((g("half1_net") > 0) & (g("half2_net") > 0)), "%s: net <= 0 in one half of the period" % e)
        flag(filt & ~(g("filter_q") <= LB_FDR), "%s: the context filter does not clearly keep better trades" % e)
    W["eligible"] = ok
    W["why_not"] = ["; ".join(x) for x in why]
    W["score"] = np.nanmin(np.vstack([pd.to_numeric(W["%s:net_lo" % e], errors="coerce") for e in engines]), axis=0)
    W["min_net"] = np.nanmin(np.vstack([pd.to_numeric(W["%s:setup_net" % e], errors="coerce") for e in engines]),
                             axis=0)
    return W


def both_exits(R):
    """Main list: eligible under both exits; score = the lower of the two."""
    o = R[R.exit == "original_d5"].set_index("conds")
    f = R[R.exit == "fresh"].set_index("conds")
    j = o[["setup", "family", "twin_conds", "eligible", "score", "why_not"]].join(
        f[["eligible", "score", "why_not"]], rsuffix="_fresh", how="inner")
    j["eligible_both"] = j["eligible"] & j["eligible_fresh"]
    j["score_both"] = np.minimum(j["score"], j["score_fresh"])
    return j.reset_index()


def overlap(a, b):
    return len(a & b) / max(1, min(len(a), len(b)))


def core(key):
    """A setup's rule without its context filters (the conditions that decide the entry)."""
    try:
        return frozenset(tuple(c) for c in json.loads(key) if not str(c[0]).startswith("snap:"))
    except (TypeError, ValueError):
        return frozenset([key])


def is_version(a, b, ids, thr=LB_OVERLAP):
    ca, cb = core(a), core(b)
    return ca <= cb or cb <= ca or overlap(ids(a), ids(b)) >= thr


def versions_skipped(chosen, order, ids, limit=200, k=5):
    """For each chosen setup, the best-placed setups (of the first `limit`) skipped as its versions."""
    out = {c: [] for c in chosen}
    for key in order[:limit]:
        if key in out:
            continue
        for c in chosen:
            if is_version(key, c, ids):
                if len(out[c]) < k:
                    out[c].append(key)
                break
    return out


def pick_diverse(order, ids, thr=LB_OVERLAP, k=LB_TOP):
    """Walk down the ranking; keep a setup unless it is a version of one already kept."""
    chosen = []
    for key in order:
        if ids(key) and not any(is_version(key, c, ids, thr) for c in chosen):
            chosen.append(key)
        if len(chosen) == k:
            break
    return chosen


WORDS = {"pre_state_bearish": "a bearish state at the pick (S08/S09)",
         "pre_state_bullish": "a bullish state at the pick (S01-S03)",
         "pre_state_overextended": "overextended at the pick", "pre_state_vol_elevated": "volatility elevated at the pick",
         "pre_nifty_vs_ma50": "NIFTY vs its 50-day average at the pick", "pre_env_code": "the market environment code",
         "pre_vix_pct250": "VIX's 250-day percentile at the pick", "pre_ad_ratio_10": "10-day breadth at the pick",
         "rank": "the model's rank"}


def describe(conds):
    """The conditions in words (an A/B/C label is named when all its conditions are there)."""
    conds = list(dict.fromkeys(conds))
    out, used = [], set()
    labs = sorted(labels().items(), key=lambda kv: -len(kv[1]))
    for ln, lc in labs:
        if set(lc) <= set(conds) and not set(lc) <= used:
            out.append("%s (%s)" % (ln, " and ".join(describe_one(c) for c in lc)))
            used |= set(lc)
            break
    for c in conds:
        if c not in used:
            out.append(describe_one(c))
    return "; ".join(out)


def describe_one(c):
    f, op, v = c
    v = float(v)
    if f == "pc_vs_d1":
        return "yesterday's close below the D1 open" if v == 0 else "yesterday's close more than %g%% below the D1 " \
            "open" % -v
    if f == "pc_vs_d1_atr":
        return "yesterday's close more than %g ATR below the D1 open" % -v
    if f == "gap_pct":
        return "opens below yesterday's close (gap down)" if op == "<" else "opens above yesterday's close (gap up)"
    if f == "prev_intraday":
        return "yesterday closed above its open"
    if f == "prev_ret":
        return "yesterday closed up"
    if f == "day":
        return "watch day %s %g" % (op, v)
    if f == "weekday":
        return "weekday %s %g (1 = Tuesday)" % (op, v)
    if f.startswith("snap:"):
        k = f[5:]
        if k in ("pre_state_bearish", "pre_state_bullish", "pre_state_vol_elevated"):
            return WORDS[k]
        if k == "pre_state_overextended":
            return "not overextended at the pick"
        if k == "rank":
            return "the model's rank %s %g" % (op, v)
        return "%s %s %.4g" % (WORDS.get(k, k), op, v)
    if f.endswith("_change"):
        return "%s %s on the previous session" % (f[:-7], "rose" if op == ">" else "fell")
    return "%s %s %g on the previous session" % (f, "above" if op == ">" else "below", v)


def _sub(a, mask):
    b = dict(a)
    b["f"] = a["f"] & mask
    return b


def positions(b, a):
    """Open positions per market session (entry open to exit close): the average over the sessions from the first
    entry to the last exit, the maximum, and the most entries on one session."""
    k = np.flatnonzero(a["f"])
    if not len(k):
        return {}
    s = b.i1[k] + a["day"][k].astype(int) - 1
    x = b.i1[k] + a["exit_day"][k].astype(int) - 1
    lo = int(s.min())
    d = np.zeros(int(x.max()) - lo + 2)
    np.add.at(d, s - lo, 1)
    np.add.at(d, x - lo + 1, -1)
    op = np.cumsum(d)[:-1]
    return {"pos_avg": float(op.mean()), "pos_max": int(op.max()), "entries_max_day": int(np.bincount(s - lo).max())}


def finalist_ledger(b, R, D):
    """Every trade of a chosen setup (both exits) next to the model's D1 entry on the same trade. Dates are market
    sessions counted from D1 (a stock that skipped a session in its watch window is off by the skipped days)."""
    cal = pd.DatetimeIndex(b.cal)
    parts = []
    for m in EXITS:
        a, d = R[m], D[m]
        k = np.flatnonzero(a["f"])
        ed, xd = a["day"][k].astype(int), a["exit_day"][k].astype(int)
        dd = lambda off: cal[np.clip(b.i1[k] + off - 1, 0, len(cal) - 1)].strftime("%Y-%m-%d")
        parts.append(pd.DataFrame({
            "exit_mode": m, "trade_id": b.ids[k], "engine": b.engine_arr[k], "symbol": b.symbols[k], "rank": b.rank[k],
            "pre_state": b.state[k], "signal_day": pd.DatetimeIndex(b.signal_day[k]).strftime("%Y-%m-%d"),
            "d1_date": dd(1), "entry_watch_day": ed, "entry_date": dd(ed), "entry_price": a["price"][k],
            "exit_date": dd(xd), "exit_price": b.C[k, xd], "net_pct": a["ret"][k], "trade_dd_pct": a["dd"][k],
            "d1_entry_price": d["price"][k], "d1_net_pct": np.where(d["f"][k], d["ret"][k], np.nan),
            "lift_pp": np.where(d["f"][k], a["ret"][k] - d["ret"][k], np.nan)}))
    return pd.concat(parts, ignore_index=True)


def finalist(books, conds, twin_conds, cache):
    """A chosen setup in every engine and exit: all trades, rank bands, bearish vs other states, each year."""
    out = {}
    for e, b in books.items():
        if e not in cache:
            boot = Boot(b.signal_day[b.ok])
            cache[e] = (boot, boot.index(b.signal_day), replay2(b, D1_CONDS))
        boot, di, D = cache[e]
        R = replay2(b, conds)
        T = replay2(b, twin_conds) if twin_conds else None
        years = pd.DatetimeIndex(b.signal_day).year.to_numpy()
        bear = np.isin(b.state, ["S08", "S09"])
        out[(e, "ledger")] = finalist_ledger(b, R, D)
        for m in EXITS:
            groups = {"ranks 1-3": b.rank <= 3, "ranks 4-10": b.rank > 3, "bearish state": bear, "other states": ~bear}
            out[(e, m)] = {"all": stats(R[m], D[m], boot, di, b, T[m] if T else None), "positions": positions(b, R[m]),
                           "groups": {g: stats(_sub(R[m], k), D[m], boot, di, b) for g, k in groups.items()},
                           "years": {int(y): stats(_sub(R[m], years == y), D[m], boot, di, b)
                                     for y in sorted(set(years))}}
    return out


def _f(x, nd=4):
    return "-" if x is None or not np.isfinite(x) else ("%+." + str(nd) + "f") % x


def leaderboard(books, out, log=print):
    """The declared rule over every setup of the run, across the engines. Writes LEADERBOARD.md,
    leaderboard.csv and FREEZE_CANDIDATES.json."""
    out = Path(out)
    engines = list(books)
    R = rank_rows(lb_table(out, engines), engines)
    B = both_exits(R)
    first = books[engines[0]]
    ids_cache = {}

    def ids(conds):
        if conds not in ids_cache:
            a = replay2(first, uncanon(conds))["original_d5"]
            ids_cache[conds] = set(first.ids[a["f"]])
        return ids_cache[conds]
    lists = {}
    elig_b = B[B.eligible_both].sort_values(["score_both", "score"], ascending=False)
    lists["both exits"] = (elig_b, pick_diverse(list(elig_b.conds), ids), "score_both")
    for m in EXITS:
        el = R[(R.exit == m) & R.eligible].sort_values(["score", "min_net"], ascending=False)
        lists[m] = (el, pick_diverse(list(el.conds), ids), "score")
    cache = {}
    (out / "FINALISTS").mkdir(exist_ok=True)

    def row(conds, m):
        x = R[(R.conds == conds) & (R.exit == m)]
        return x.iloc[0] if len(x) else pd.Series(dtype=object)
    L = ["# setuplab leaderboard - the declared rule over every setup (%s)" % VERSION, "",
         "Engines %s; %s. %d setups x 2 exits tested in every engine; eligible: both exits %d, original_d5 %d, "
         "fresh %d." % (", ".join(engines), ", ".join("%s %d picks" % (e, books[e].n) for e in engines),
                        R.conds.nunique(), int(B.eligible_both.sum()), int(R[(R.exit == "original_d5")].eligible.sum()),
                        int(R[(R.exit == "fresh")].eligible.sum())), "", "## The rule", ""] + \
        ["- " + t for t in LB_RULE] + [""]
    freeze = {"version": VERSION, "rule": LB_RULE, "engines": engines, "lists": {}}
    for lname, (el, chosen, sc) in lists.items():
        order = list(el.conds)
        skipped = versions_skipped(chosen, order, ids)
        eli = el.drop_duplicates("conds").set_index("conds")
        L += ["## %s - the top %d" % (lname.upper() if lname == "both exits" else lname + " exit", LB_TOP), ""]
        if not chosen:
            L += ["No setup meets the rule.", ""]
        freeze["lists"][lname] = []
        for rk, conds in enumerate(chosen, 1):
            r0 = row(conds, "original_d5")
            r0 = r0 if len(r0) else row(conds, "fresh")
            det = finalist(books, uncanon(conds), uncanon(r0.twin_conds) if r0.twin_conds else None, cache)
            title = "### %d. %s  (%s)" % (rk, r0.setup, r0.family)
            L += [title, "", "**Rule:** %s. Watch D1-D5 after the pick, buy at the first open where all hold; "
                  "exit original_d5 = the pick's D5 close, fresh = the close 4 sessions after entry; 0.35 pp costs." %
                  describe(uncanon(conds)), "",
                  "| engine | exit | trades | per year | fill % | net | net 95% | D1 same trades | lift over D1 [95%] "
                  "| indicators add [95%] | years net > 0 | 1st / 2nd half | open positions avg / max (entries one day) |",
                  "|---|---|---:|---:|---:|---:|---|---:|---|---|---:|---|---|"]
            item = {"rank": rk, "setup": r0.setup, "family": r0.family, "conds": uncanon(conds),
                    "description": describe(uncanon(conds)), "twin_conds": uncanon(r0.twin_conds) if
                    r0.twin_conds else None, "stats": {}}
            for e in engines:
                for m in EXITS:
                    a = det[(e, m)]["all"]
                    if not a:
                        continue
                    item["stats"]["%s %s" % (e, m)] = {k: (float(v) if isinstance(v, (int, float, np.floating,
                                                                                       np.integer)) else v)
                                                       for k, v in a.items()}
                    po = det[(e, m)]["positions"]
                    item["stats"]["%s %s" % (e, m)].update(po)
                    L.append("| %s | %s | %d | %.0f | %.1f | %s | %s .. %s | %s | %s [%s, %s] | %s | %d/%d | %s / %s | %s |" % (
                        e, m, a["n"], a["trades_per_year"], a["fill_pct"], _f(a["setup_net"]), _f(a["net_lo"]),
                        _f(a["net_hi"]), _f(a["control_net"]), _f(a["lift_pp"]), _f(a["lo"]), _f(a["hi"]),
                        ("%s [%s, %s]" % (_f(a["adds"]), _f(a["adds_lo"]), _f(a["adds_hi"]))) if "adds" in a else "-",
                        a["years_net_pos"], a["years"], _f(a["half1_net"], 2), _f(a["half2_net"], 2),
                        ("%.1f / %d (%d)" % (po["pos_avg"], po["pos_max"], po["entries_max_day"])) if po else "-"))
            if any(str(c[0]).startswith("snap:") for c in uncanon(conds)):
                fx = []
                for e in engines:
                    for m in EXITS:
                        q = row(conds, m)
                        g = lambda c: float(pd.to_numeric(pd.Series([q.get("%s:%s" % (e, c))]), errors="coerce").iloc[0])
                        fx.append("%s %s %s [%s, %s], q %s (kept %s, dropped %s)" % (
                            e, m, _f(g("filter_gain")), _f(g("filter_lo")), _f(g("filter_hi")),
                            "-" if not np.isfinite(g("filter_q")) else "%.4f" % g("filter_q"),
                            "-" if not np.isfinite(g("filter_kept")) else "%d" % g("filter_kept"),
                            "-" if not np.isfinite(g("filter_dropped")) else "%d" % g("filter_dropped")))
                        item.setdefault("filter", {})["%s %s" % (e, m)] = {
                            k: float(g(k)) for k in ("filter_gain", "filter_lo", "filter_hi", "filter_p", "filter_q",
                                                     "filter_kept", "filter_dropped")}
                L += ["", "**Context filter (rule 6)** - the parent setup's trades WITH the filter minus those "
                      "WITHOUT it, net per trade [95%%], q = the false discovery rate over all the run's filter tests "
                      "(passes at <= %.2f): " % LB_FDR + "; ".join(fx) + "."]
            if skipped.get(conds):
                L += ["", "**Versions skipped** (eligible, but the same rule with conditions or context filters added "
                      "or removed, or 70%%+ the same trades): %s." % "; ".join(
                          "%s (place %d, score %s)" % (eli.loc[v, "setup"], order.index(v) + 1, _f(eli.loc[v, sc]))
                          for v in skipped[conds])]
                item["versions_skipped"] = [eli.loc[v, "setup"] for v in skipped[conds]]
            slug = "%s_%d" % (lname.replace(" ", "_"), rk)
            for e in engines:
                det[(e, "ledger")].to_csv(out / "FINALISTS" / ("%s__%s.csv" % (slug, e)), index=False)
            item["ledgers"] = ["FINALISTS/%s__%s.csv" % (slug, e) for e in engines]
            L += ["", "Every trade (both exits, with the D1 entry on the same trade): %s." % ", ".join(
                "`%s`" % x for x in item["ledgers"])]
            L += ["", "| engine | exit | ranks 1-3 | ranks 4-10 | bearish state | other states | by year (net, trades) |",
                  "|---|---|---|---|---|---|---|"]
            for e in engines:
                for m in EXITS:
                    g = det[(e, m)]["groups"]
                    cell = lambda x: "-" if not x else "%s (%d)" % (_f(x["setup_net"], 2), x["n"])
                    yy = ", ".join("%d %s (%d)" % (y, _f(v["setup_net"], 2), v["n"]) for y, v in
                                   det[(e, m)]["years"].items() if v)
                    L.append("| %s | %s | %s | %s | %s | %s | %s |" % (e, m, cell(g["ranks 1-3"]), cell(g["ranks 4-10"]),
                                                                       cell(g["bearish state"]),
                                                                       cell(g["other states"]), yy))
            L.append("")
            freeze["lists"][lname].append(item)
        # the table of the leading eligible setups (no overlap rule)
        L += ["#### The 20 best eligible scores, %s (before the overlap rule)" % lname, "",
              "| # | setup | family | score | %s |" % " | ".join("%s net (%s)" % (e, "orig / fresh" if lname ==
                                                                                "both exits" else lname)
                                                                for e in engines), "|---:|---|---|---:|" +
              "---:|" * len(engines)]
        for i, (_, r) in enumerate(el.head(20).iterrows(), 1):
            nets = []
            for e in engines:
                if lname == "both exits":
                    o, f = row(r.conds, "original_d5"), row(r.conds, "fresh")
                    nets.append("%s / %s" % (_f(o["%s:setup_net" % e], 2), _f(f["%s:setup_net" % e], 2)))
                else:
                    nets.append(_f(r["%s:setup_net" % e], 2))
            L.append("| %d | %s%s | %s | %s | %s |" % (i, r.setup, " *" if r.conds in chosen else "", r.family,
                                                        _f(r[sc], 4), " | ".join(nets)))
        L.append("")
    # where the setups discussed so far stand
    refs = {"A": labels()["A"], "B": labels()["B"], "C": labels()["C"], "A+B": labels()["A+B"],
            "A+C (= A+B+C)": labels()["A+C"], "B+C": labels()["B+C"]}
    for ln in ("A", "B", "C", "A+B", "A+C", "B+C"):
        refs["%s & 2%% dip" % ln] = labels()[ln] + DIPS["DIP_2"]
    refs["2% dip alone"] = DIPS["DIP_2"]
    refs["WQ_44 up & 13w down + gap down + vol elevated"] = [("d_wq_44_change", ">", 0), ("w_ret_13w_change", "<", 0),
                                                            ("gap_pct", "<", 0), ("snap:pre_state_vol_elevated", ">", 0.5)]
    refs["B + 1-ATR dip + bearish"] = labels()["B"] + DIPS["DIPATR_1"] + [("snap:pre_state_bearish", ">", 0.5)]
    refs["B + 3% dip + bearish"] = labels()["B"] + DIPS["DIP_3"] + [("snap:pre_state_bearish", ">", 0.5)]
    L += ["## Where the setups discussed so far stand", "",
          "| setup | both exits: eligible / score / place | why not (first reasons) |", "|---|---|---|"]
    order_b = list(elig_b.conds)
    for name, c in refs.items():
        k = canon(c)
        r = B[B.conds == k]
        if r.empty:
            L.append("| %s | not tested in every engine | - |" % name)
            continue
        r = r.iloc[0]
        place = (order_b.index(k) + 1) if k in order_b else None
        why = "; ".join(dict.fromkeys(y for x in (r.why_not, r.why_not_fresh) if isinstance(x, str) and x
                                      for y in x.split("; ")))[:300]
        L.append("| %s | %s / %s / %s | %s |" % (name, "yes" if r.eligible_both else "no", _f(r.score_both),
                                                 place or "-", why or "-"))
    L += ["", "Families (eligible both exits / tested): " + ", ".join(
        "%s %d/%d" % (f, int(g.eligible_both.sum()), len(g)) for f, g in B.groupby("family")), "",
          "Read with care: this ranks thousands of rules on the history they were found on; the winners' numbers "
          "will shrink going forward. The forward paper ledger is the test."]
    (out / "LEADERBOARD.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    R.to_csv(out / "leaderboard.csv", index=False)
    B.to_csv(out / "leaderboard_both_exits.csv", index=False)
    (out / "FREEZE_CANDIDATES.json").write_text(json.dumps(freeze, indent=1, default=str), encoding="utf-8")
    log(" leaderboard: %d eligible in both exits; wrote LEADERBOARD.md, FREEZE_CANDIDATES.json" %
        int(B.eligible_both.sum()))
    return R, B


def by_group(led, names, boot, key, label):
    """Like by_state, for any grouping of the trades (key: ledger -> group labels)."""
    rows = []
    for name in names:
        for mode in EXITS:
            a = led[(name, mode)]
            ga = key(a)
            for ctl in ("Blind_D1", "DIP_2"):
                if ctl == name:
                    continue
                b = led[(ctl, mode)]
                gb = key(b)
                for g in sorted(pd.unique(ga)):
                    r = paired(a[ga == g], b[gb == g], boot)
                    if r:
                        rows.append({"setup": name, "exit": mode, "control": ctl, label: g, **r})
    return pd.DataFrame(rows)


def by_rank(led, names, boot):
    one = by_group(led, names, boot, lambda d: d["rank"].map(lambda r: "rank %02d" % r).to_numpy(), "group")
    band = by_group(led, names, boot, lambda d: np.where(d["rank"].to_numpy() <= 3, "ranks 1-3", "ranks 4-10"),
                    "group")
    return pd.concat([band, one], ignore_index=True)


def by_state(led, names, boot):
    """Each setup's own trades vs D1 (and vs the 2% dip) on the same ids, split by the pick's stock state at the
    signal (pre_state from the watchlist: nomination context, not the state on the entry day)."""
    rows = []
    for name in names:
        for mode in EXITS:
            a = led[(name, mode)]
            for ctl in ("Blind_D1", "DIP_2"):
                if ctl == name:
                    continue
                b = led[(ctl, mode)]
                for st in sorted(a.pre_state.astype(str).unique()):
                    r = paired(a[a.pre_state.astype(str) == st], b[b.pre_state.astype(str) == st], boot)
                    if r:
                        rows.append({"setup": name, "exit": mode, "control": ctl, "state": st, **r})
    return pd.DataFrame(rows)


def _fmt(r):
    return "%d | %+.4f | %+.4f | **%+.4f** | %+.4f .. %+.4f | %.1f | %.4f" % (
        r["n"], r["control_net"], r["setup_net"], r["lift_pp"], r["lo"], r["hi"], r["setup_better_pct"],
        r["entry_cheaper_pct"])


def report(v1, v2, out, book, yrs=None, X=None, sts=None, rks=None):
    L = ["# setuplab - setups vs the model's D1 entry on the same trades (%s)" % VERSION, "",
         "Engine %s, ranks %s, %d picks, %d settled. Net %% per trade after 0.35 pp. Each row: the setup's OWN filled trades "
         "against the model buying the same trade ids at the D1 open (same exit rule). 95%% circular block bootstrap "
         "over signal days (10-day blocks, 2,000 draws). 'Cheaper' = how far under the control's entry the setup "
         "bought, on average." % (book.engine, "%d-%d" % (min(book.rank), max(book.rank)) if book.n else "-",
                                   book.n, int(book.ok.sum())), ""]
    hdr = "| setup | n | D1 net | setup net | lift pp | 95% interval | setup better % | entry cheaper % |"
    sep = "|---|---:|---:|---:|---:|---|---:|---:|"
    for mode in EXITS:
        L += ["## %s exit" % mode, "", "### A/B/C and the price-only controls", "", hdr, sep]
        sub = v1[(v1.exit == mode) & ~v1.setup.str.startswith("S")]
        for _, r in sub.sort_values("lift_pp", ascending=False).iterrows():
            L.append("| %s | %s |" % (r["setup"], _fmt(r)))
        sp = v1[(v1.exit == mode) & v1.setup.str.startswith("S2|")].sort_values("lift_pp", ascending=False)
        L += ["", "### The whole pair space of the %d features (%d setups; A/B/C's family) - top 15 and bottom 5" %
              (len(book.features), len(sp)), "", hdr, sep]
        for _, r in pd.concat([sp.head(15), sp.tail(5)]).iterrows():
            L.append("| %s | %s |" % (r["setup"][3:], _fmt(r)))
        L += ["", "Pair space: lift above 0 with the interval above 0 in %d of %d setups; median lift %+.4f pp." % (
            int((sp.lo > 0).sum()), len(sp), sp.lift_pp.median()), ""]
        own = sp[(sp.n >= 300) & (sp.lo > 0)].sort_values("setup_net", ascending=False).head(15)
        L += ["### Pair space - top 15 by net per trade (n >= 300, lift interval above 0)", "", hdr, sep]
        for _, r in own.iterrows():
            L.append("| %s | %s |" % (r["setup"][3:], _fmt(r)))
        L.append("")
        L += ["### A/B/C against the price-only controls (same trade ids, both filled)", "",
              "| setup | control | n | control net | setup net | lift pp | 95% interval | setup better % | entry cheaper % |",
              "|---|---|---:|---:|---:|---:|---|---:|---:|"]
        for _, r in (v2[v2.exit == mode] if len(v2) else v2).iterrows():
            L.append("| %s | %s | %s |" % (r["setup"], r["control"], _fmt(r)))
        L.append("")
        if yrs is not None and len(yrs):
            L += ["### By signal year (lift pp on the same trades; setup net in brackets)", ""]
            ys = sorted(yrs.year.unique())
            L += ["| setup | vs | " + " | ".join(str(y) for y in ys) + " |", "|---|---|" + "---:|" * len(ys)]
            for (nm, c), g in yrs[yrs.exit == mode].groupby(["setup", "control"], sort=False):
                g = g.set_index("year")
                L.append("| %s | %s | " % (nm, c) + " | ".join(
                    ("%+.2f (%+.2f, n %d)" % (g.loc[y, "lift_pp"], g.loc[y, "setup_net"], g.loc[y, "n"]))
                    if y in g.index else "-" for y in ys) + " |")
            L.append("")
    labs = [ln for ln in labels() if ln + "__none" in set(v1.setup)]
    if labs:
        L += ["## Every A/B/C label, treated the same (A+B+C = A+C: identical conditions)", "",
              "Net % per trade on the label's own trades (original_d5 / fresh), its lift over D1 on those trades "
              "[95%], and what the label adds over the same dip ALONE on the same trades [95%].", ""]
        for mode in EXITS:
            L += ["### %s exit" % mode, "", "| label | entry | n | net | lift over D1 [95%] | adds over the dip alone [95%] |",
                  "|---|---|---:|---:|---|---|"]
            for ln in labs:
                for dn in [None] + list(DIPS):
                    nm = ln + "__none" if dn is None else "%s&%s" % (ln, dn)
                    r = v1[(v1.setup == nm) & (v1.exit == mode)]
                    if r.empty:
                        continue
                    r = r.iloc[0]
                    a = v2[(v2.setup == nm) & (v2.exit == mode) & (v2.control == dn)] if dn and len(v2) else []
                    adds = ("%+.4f [%+.4f, %+.4f]" % (a.lift_pp.iloc[0], a.lo.iloc[0], a.hi.iloc[0])) if len(a) else "-"
                    L.append("| %s | %s | %d | %+.4f | %+.4f [%+.4f, %+.4f] | %s |" % (
                        ln, dn or "no dip", r.n, r.setup_net, r.lift_pp, r.lo, r.hi, adds))
            L.append("")
    if rks is not None and len(rks):
        L += ["## By rank (the model's rank on the signal day)", "",
              "Each cell: lift over D1 on the setup's own trades [95% interval] / net per trade / trades.", ""]
        for mode in EXITS:
            sub = rks[(rks.exit == mode) & (rks.control == "Blind_D1")]
            names = list(dict.fromkeys(sub.setup))
            L += ["### %s exit" % mode, "", "| group | " + " | ".join(names) + " |", "|---|" + "---|" * len(names)]
            for g in list(dict.fromkeys(sub.group)):
                cells = []
                for nm in names:
                    r = sub[(sub.setup == nm) & (sub.group == g)]
                    cells.append("-" if r.empty else "%+.2f [%+.2f, %+.2f] / %+.2f / %d" % (
                        r.lift_pp.iloc[0], r.lo.iloc[0], r.hi.iloc[0], r.setup_net.iloc[0], r.n.iloc[0]))
                L.append("| %s | " % g + " | ".join(cells) + " |")
            L.append("")
    if sts is not None and len(sts):
        L += ["## By stock state at the signal (pre_state; nomination context)", "",
              "Each cell: lift over D1 on the setup's own trades [95% interval] / the setup's net per trade / trades. "
              "States with under 30 trades are noisy.", ""]
        for mode in EXITS:
            sub = sts[(sts.exit == mode) & (sts.control == "Blind_D1")]
            names = list(dict.fromkeys(sub.setup))
            L += ["### %s exit" % mode, "", "| state | " + " | ".join(names) + " |", "|---|" + "---|" * len(names)]
            for st in sorted(sub.state.unique()):
                cells = []
                for nm in names:
                    r = sub[(sub.setup == nm) & (sub.state == st)]
                    cells.append("-" if r.empty else "%+.2f [%+.2f, %+.2f] / %+.2f / %d" % (
                        r.lift_pp.iloc[0], r.lo.iloc[0], r.hi.iloc[0], r.setup_net.iloc[0], r.n.iloc[0]))
                L.append("| %s | " % st + " | ".join(cells) + " |")
            L.append("")
    if X is not None and len(X):
        L += ["## Exploration: what adds most on top of a price dip (hypotheses, chosen after looking)", "",
              "Each row: the condition AND the dip, its own trades vs the dip alone on the same ids (lift), and vs D1. "
              "Sorted by lift over the dip; n >= 150 only. X1 = one feature condition, X2 = one of the 10 best pairs "
              "of the space, XA = B / A+B with a 1-ATR dip.", ""]
        for mode in EXITS:
            sub = X[(X.exit == mode) & (X.n >= 150)].sort_values("lift_pp", ascending=False)
            L += ["### %s exit - top 15 of %d (interval above 0 over the dip: %d)" % (
                mode, len(sub), int((sub.lo > 0).sum())), "",
                  "| setup | over | n | dip net | setup net | lift over dip | 95% interval | lift over D1 | 95% interval |",
                  "|---|---|---:|---:|---:|---:|---|---:|---|"]
            for _, r in sub.head(15).iterrows():
                L.append("| %s | %s | %d | %+.4f | %+.4f | **%+.4f** | %+.4f .. %+.4f | %+.4f | %+.4f .. %+.4f |" % (
                    r.setup, r.vs, r.n, r.control_net, r.setup_net, r.lift_pp, r.lo, r.hi, r.lift_vs_D1, r.lo_vs_D1,
                    r.hi_vs_D1))
            L.append("")
    L += ["Controls: DIP_x = the first open D2..D5 after a close more than x% under the D1 open (DIP_0: any close under "
          "it); BOUNCE_green = under the D1 open, then a green day; BOUNCE_upclose = under it, then an up close; "
          "BOUNCE_dip2_green = more than 2% under it, then a green day; DIPATR_x = a close more than x ATR14 (at the "
          "signal) under the D1 open. No indicators in any control.",
          "Exploratory: the same history the setups were found on. Under original_d5 both legs sell at the same D5 "
          "close, so a lift there is entirely the entry price."]
    (out / "REPORT.md").write_text("\n".join(L) + "\n", encoding="utf-8")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="setuplab")
    ap.add_argument("command", nargs="?", choices=("run", "reproduce", "build"))
    ap.add_argument("--ranks", default="", help="run: only these ranks (e.g. 1-3, 4-10); build: default 1-10")
    ap.add_argument("--root", help="build: the daily cache root (%%CACHE_DAILY_ROOT%%)")
    ap.add_argument("--export", help="build: tradelab's export folder (TLX_...)")
    ap.add_argument("--pm-run", default="PM_20261017_001")
    ap.add_argument("--engines", default="D,ENS")
    ap.add_argument("--to", default="")
    ap.add_argument("--stage-e-any", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--costs", default="stage_e", help=argparse.SUPPRESS)
    ap.add_argument("--check", default="", help="build: ChatGPT's watchlist.parquet - the ranks 1-3 must match")
    ap.add_argument("--data")
    ap.add_argument("--features")
    ap.add_argument("--ledgers")
    ap.add_argument("--out")
    ap.add_argument("--engine", default="D", help="D, ENS, or several: D,ENS (one run, a leaderboard across them)")
    ap.add_argument("--columns-file", default="", help="a file of feature names, one per line (# = comment)")
    ap.add_argument("--chunk", type=int, default=8, help=argparse.SUPPRESS)
    ap.add_argument("--columns", default="", help="comma list of feature columns to test (default: every column)")
    ap.add_argument("--why", default="", help="why_features.csv: test the engine's top --top features by its importance")
    ap.add_argument("--top", type=int, default=50)
    ap.add_argument("--confluence", action="store_true", help="also run the setups x logical confluences stage")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args(argv)
    if a.selftest:
        sys.path.insert(0, str(Path(__file__).resolve().parent / "tests"))
        import test_setuplab
        return test_setuplab.main()
    a.ranks_list = []
    if a.ranks:
        lo, _, hi = a.ranks.partition("-")
        a.ranks_list = list(range(int(lo), int(hi or lo) + 1))
    if a.command == "build":
        if not a.root or not Path(a.root).is_dir() or not a.export or not a.out:
            print("ERROR: build needs --root <cache root>, --export <tradelab export folder> and --out (no defaults)")
            return 2
        return cmd_build(a)
    if not a.command or not a.data or not a.features:
        print("ERROR: give a command, --data and --features (no default paths)")
        return 2
    cols = [c.strip() for c in a.columns.split(",") if c.strip()] or None
    if a.columns_file:
        if not Path(a.columns_file).is_file():
            print("REFUSED: no file %s" % a.columns_file)
            return 3
        cols = list(dict.fromkeys((cols or []) + read_columns_file(a.columns_file)))
    if a.why:
        if not Path(a.why).is_file():
            print("REFUSED: no file %s" % a.why)
            return 3
        cols, skipped = pick_features(a.why, a.top, a.features, a.engine.split(",")[0])
        print("%s: the top %d features by the WHY importance (%d skipped before reaching them: %s)" % (
            VERSION, len(cols), len(skipped), ", ".join("%s (%s)" % x for x in skipped[:40])))
        print("  " + ", ".join(cols))
    engines = [e.strip() for e in a.engine.split(",") if e.strip()]
    if a.command == "reproduce":
        try:
            book = load(a.data, a.features, engines[0], cols, a.ranks_list or None)
        except ValueError as e:
            print("REFUSED: %s" % e)
            return 3
        if not a.ledgers:
            print("ERROR: --ledgers <folder of the delivered *.csv.gz>")
            return 2
        n, bad, worst = cmd_reproduce(book, a.ledgers)
        print("%s reproduce: %d ledgers compared, %d differ, largest ret difference %.2e pp" % (
            VERSION, n, len(bad), worst))
        for b in bad:
            print("  DIFFERS", *b)
        print("REPRODUCED" if not bad else "NOT REPRODUCED")
        return 0 if not bad else 1
    if not a.out:
        print("ERROR: --out <folder>")
        return 2
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    # the same command again resumes a stopped run; different settings in the same folder are refused
    st = lambda f: [str(Path(f).resolve()), Path(f).stat().st_size, int(Path(f).stat().st_mtime)] if f else None
    settings = {"version": VERSION, "engines": engines, "ranks": a.ranks_list, "columns": cols,
                "confluence": bool(a.confluence), "watchlist": st(Path(a.data) / "watchlist.parquet"),
                "features": st(a.features)}
    sf = out / "RUN_SETTINGS.json"
    if sf.is_file():
        old = json.loads(sf.read_text(encoding="utf-8"))
        if old != json.loads(json.dumps(settings)):
            print("REFUSED: %s holds a run with other settings (or another version / data) - use a new --out" % out)
            return 3
        print("resuming the run in %s (finished parts are kept)" % out)
    sf.write_text(json.dumps(settings, indent=1), encoding="utf-8")
    logf = open(out / "run.log", "a", encoding="utf-8")

    def log(*x):
        line = time.strftime("%H:%M:%S ") + " ".join(str(y) for y in x)
        print(line, flush=True)
        logf.write(line + "\n")
        logf.flush()
    t0 = time.time()
    try:
        book = load(a.data, a.features, None if len(engines) > 1 else engines[0], cols, a.ranks_list or None, log,
                    a.chunk)
    except ValueError as e:
        print("REFUSED: %s" % e)
        return 3
    info = {"version": VERSION, "started": time.strftime("%Y-%m-%d %H:%M:%S"), "args": vars(a),
            "features_attached": book.features, "features_missing": getattr(book, "missing_features", []),
            "python": sys.version.split()[0], "numpy": np.__version__, "pandas": pd.__version__}
    if book.missing_features:
        log(" NOTE: %d feature columns are not in the panel and were skipped: %s" % (
            len(book.missing_features), ", ".join(book.missing_features)))
    if a.check:
        res = check_watchlists(book.wl, a.check)
        info["watchlist_check"] = res
        log(" " + res["text"])
    if cols:
        (out / "features_tested.txt").write_text("\n".join(book.features) + "\n", encoding="utf-8")
    if len(engines) == 1:
        cmd_run(book, out, log=log, with_confluence=a.confluence)
    else:
        books = {}
        for e in engines:
            mask = book.engine_arr == e
            if not mask.any():
                print("REFUSED: no picks of engine %s in the watchlist" % e)
                return 3
            books[e] = book.take(mask, e)
        info["picks"] = {e: b.n for e, b in books.items()}
        del book
        cmd_run_multi(books, out, log=log, with_confluence=a.confluence)
    info["minutes"] = round((time.time() - t0) / 60, 1)
    (out / "RUN.json").write_text(json.dumps(info, indent=1, default=str), encoding="utf-8")
    log(" DONE in %.1f minutes - %s" % (info["minutes"], out))
    return 0


if __name__ == "__main__":
    sys.exit(main())
