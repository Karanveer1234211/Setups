# MANIFEST - setuplab v0.8 (8 Nov 2026: the frozen setups, their zones, the whole market, the TradingView indicator)

Folder: C:\Users\karanvsi\PyCharmMiscProject\setuplab\ (tests in setuplab\tests\). Replace the v0.6 / v0.7 files; FROZEN_SETUPS.json is the freeze (never edit it: a changed copy is refused). Writes only under --out (C:\QuantData\setuplab). The scan and the zones read tradelab's readers (tradelab with the setups add-on on PYTHONPATH: env_tradelab.bat or env_playbook.bat); the self-test also reads production's features_daily.py (bigmove_deploy on PYTHONPATH). Python with numpy, pandas, pyarrow. BigMove_Setups.pine goes into TradingView's Pine Editor.

| file | sha256 (first 16) | bytes | lines |
|---|---|---|---|
| setuplab.py | e4d4a9802510c573 | 193498 | 3630 |
| FROZEN_SETUPS.json | bed8fd610cf686af | 24439 | 935 |
| BigMove_Setups.pine | 1904f972378eb49c | 24113 | 588 |
| features_final.txt | bcb6c16bdfd7513d | 1689 | 60 |
| README_SETUPLAB.md | 790b0aae88347666 | 23538 | 290 |
| tests\test_setuplab.py | 47b668c80c828e60 | 73266 | 1191 |
| tests\pine_mirror.py | 326cb336f1c7e96c | 13337 | 337 |

FROZEN_SETUPS.json's own sha256 (inside the file): 483f1539324f3ae5... (`python setuplab.py frozen` prints FROZEN FILE OK).

Verified where it was built: 61 self-test checks, 0 failed (v0.6's 38; v0.7's f1-f14; v0.8's z1-z6 and p1-p3: the zone measures = the Pine's bar-by-bar mirror; the whole-market engine = setuplab's own replay on every stock-day; the search finds a planted zone that holds out of sample and an absent one that does not, and qualifies only on the 95% intervals; the zones command end to end; the scan's IN / OUT by hand; a zone failure never stops the scan; the mirror's features = production's features_daily on 3 x 900 sessions and its marks = the engine; the Pine's setups and measures = the freeze and the code, parsed and linted with pynescript). Planted bugs caught: 5 of 5 (engine, zone values, EWM, weeks, the 95% rule). The same 61 checks pass with pandas 2.3.3 / numpy 2.4.1 (Karan's versions) and pandas 3.0.5 / numpy 2.5.3. S1's ATR wherever it is not recorded = pick_meta's simple ATR14 / close (v0.8 fix after TAGS.md). The Pine has not been compiled by TradingView.
