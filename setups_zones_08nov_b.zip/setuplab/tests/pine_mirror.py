"""
tests/pine_mirror.py - BigMove_Setups.pine, bar by bar, in Python (the indicator itself cannot run here).

Every block below is the Pine's own block, in its order, with its state variables: the self-test compares this
mirror with production's features_daily (the setup features), with setuplab's stock_dims / market_dims (the zones)
and with setuplab's market_entries (the marks). The Pine is a line-by-line transliteration of this file: when one
changes, the other must.
"""
import bisect
import math

import numpy as np

NAN = float("nan")
WARMUP = 312            # production's panel drops each stock's first 312 bars (features_daily WARMUP_BARS)
FEATS = ("d_wq_16", "d_mdi14_diff5", "d_wq_40", "d_mdi14", "d_ema20_angle_deg", "d_bb_bw_20", "d_wq_44",
         "w_ret_13w", "d_bb_pctb_20")


def fin(x):
    return x is not None and not (isinstance(x, float) and math.isnan(x))


class XRank:
    """Expanding percentile rank (average for ties), blank until 60 values - features_daily._expand_rank_pct."""

    def __init__(self, minp=60):
        self.a, self.minp = [], minp

    def push(self, x):
        if not fin(x):
            return NAN
        lo = bisect.bisect_left(self.a, x)
        self.a.insert(lo, x)
        if len(self.a) < self.minp:
            return NAN
        hi = bisect.bisect_right(self.a, x)
        return ((lo + 1) + hi) / 2.0 / len(self.a)


def ewm_step(state, x, alpha):
    """pandas ewm(adjust=False): the first value seeds it; then y = (1 - a) * y + a * x. state = [y, count]."""
    if not fin(x):
        return state
    if state[1] == 0:
        return [x, 1]
    return [(1 - alpha) * state[0] + alpha * x, state[1] + 1]


def win(series, i, w):
    return series[max(0, i - w + 1):i + 1]


def cov_pairs(a, b, minp):
    p = [(x, y) for x, y in zip(a, b) if fin(x) and fin(y)]
    if len(p) < minp:
        return NAN
    n = len(p)
    ma = sum(x for x, _ in p) / n
    mb = sum(y for _, y in p) / n
    return sum((x - ma) * (y - mb) for x, y in p) / (n - 1)


def corr_pairs(a, b, minp):
    p = [(x, y) for x, y in zip(a, b) if fin(x) and fin(y)]
    if len(p) < minp:
        return NAN
    if max(x for x, _ in p) == min(x for x, _ in p) or max(y for _, y in p) == min(y for _, y in p):
        return NAN                                 # no variance: blank (pandas: inf / NaN, production: blank)
    n = len(p)
    ma = sum(x for x, _ in p) / n
    mb = sum(y for _, y in p) / n
    sab = sum((x - ma) * (y - mb) for x, y in p)
    saa = sum((x - ma) ** 2 for x, _ in p)
    sbb = sum((y - mb) ** 2 for _, y in p)
    return sab / math.sqrt(saa * sbb)


def std_sample(a, minp):
    v = [x for x in a if fin(x)]
    if len(v) < minp:
        return NAN
    m = sum(v) / len(v)
    return math.sqrt(sum((x - m) ** 2 for x in v) / (len(v) - 1))


def week_end(day_num):
    """IST day number since 1970-01-01 (a Thursday) -> the day number of the Friday ending its week (W-FRI)."""
    wd = (day_num + 3) % 7                    # Monday = 0
    return day_num + ((4 - wd) % 7 + 7) % 7


def features(days, o, h, l, c, v):
    """The setup features and the stock's zone values at every bar's close. days: IST day numbers."""
    n = len(c)
    F = {k: [NAN] * n for k in FEATS + ("d_atr_pct", "s_atr", "ATRP", "ATRX", "TREND", "RET20", "RSI14", "DD52", "RVOL")}
    atr_s, pdm_s, mdm_s = [0.0, 0], [0.0, 0], [0.0, 0]
    e20, e50, e200 = [0.0, 0], [0.0, 0], [0.0, 0]
    ag, al = [0.0, 0], [0.0, 0]
    rH, rV, rC, rS = XRank(), XRank(), XRank(), XRank()
    rh, rv, cov5 = [NAN] * n, [NAN] * n, [NAN] * n
    std10 = [NAN] * n
    wcl, cur_we, cur_close = [], None, NAN
    mdi, ema20 = [NAN] * n, [NAN] * n
    trs = [NAN] * n
    for i in range(n):
        # true range, ATR, -DI (features_daily._adx)
        tr = h[i] - l[i] if i == 0 else max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1]))
        atr_s = ewm_step(atr_s, tr, 1 / 14)
        up = h[i] - h[i - 1] if i > 0 else NAN
        dn = l[i - 1] - l[i] if i > 0 else NAN
        pdm = up if (fin(up) and fin(dn) and up > dn and up > 0) else 0.0
        mdm = dn if (fin(up) and fin(dn) and dn > up and dn > 0) else 0.0
        pdm_s = ewm_step(pdm_s, pdm, 1 / 14)
        mdm_s = ewm_step(mdm_s, mdm, 1 / 14)
        atr = atr_s[0] if atr_s[1] >= 14 else NAN
        mdi[i] = 100 * mdm_s[0] / atr if (mdm_s[1] >= 14 and fin(atr) and atr != 0) else NAN
        F["d_mdi14"][i] = mdi[i]
        F["d_mdi14_diff5"][i] = mdi[i] - mdi[i - 5] if i >= 5 else NAN
        F["d_atr_pct"][i] = atr / c[i] * 100 if fin(atr) and c[i] != 0 else NAN
        F["ATRP"][i] = F["d_atr_pct"][i]
        # pick_meta's s_atr14: a SIMPLE 14-session mean of the true range from the second bar, / close
        if i >= 1:
            trs[i] = max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1]))
        if i >= 14 and c[i] != 0:
            F["s_atr"][i] = (sum(trs[i - 13:i + 1]) / 14) / c[i]
        # EMA20 angle
        e20 = ewm_step(e20, c[i], 2 / 21)
        ema20[i] = e20[0] if e20[1] >= 20 else NAN
        if i > 0 and fin(ema20[i]) and fin(ema20[i - 1]) and ema20[i - 1] != 0:
            F["d_ema20_angle_deg"][i] = math.degrees(math.atan((ema20[i] - ema20[i - 1]) / ema20[i - 1]))
        # Bollinger 20 (sample standard deviation)
        if i >= 19:
            wv = c[i - 19:i + 1]
            m = sum(wv) / 20
            sd = math.sqrt(sum((x - m) ** 2 for x in wv) / 19)
            width = 4 * sd if max(wv) != min(wv) else 0.0
            if width != 0:
                F["d_bb_pctb_20"][i] = min(5.0, max(-5.0, (c[i] - (m - 2 * sd)) / width))
            if m != 0:
                F["d_bb_bw_20"][i] = width / m
        # weekly 13-week return of the last completed week (W-FRI weeks)
        we = week_end(days[i])
        if cur_we is not None and we != cur_we:
            wcl.append(cur_close)
        cur_we, cur_close = we, c[i]
        if len(wcl) >= 14:
            F["w_ret_13w"][i] = (wcl[-1] / wcl[-14] - 1) * 100
        # WorldQuant 16 / 40 / 44 (expanding ranks from the first bar)
        rh[i] = rH.push(h[i])
        rv[i] = rV.push(v[i])
        cov5[i] = cov_pairs(win(rh, i, 5), win(rv, i, 5), 3)
        F["d_wq_16"][i] = -rC.push(cov5[i]) if fin(cov5[i]) else NAN
        std10[i] = std_sample(win(h, i, 10), 5)
        rs = rS.push(std10[i])
        cr = corr_pairs(win(h, i, 10), win(v, i, 10), 5)
        F["d_wq_40"][i] = -rs * cr if fin(rs) and fin(cr) else NAN
        c44 = corr_pairs(win(h, i, 5), win(rv, i, 5), 5)
        F["d_wq_44"][i] = -c44 if fin(c44) else NAN
        # zones: ATR expansion, trend, 20-session return, RSI, distance from the 252-session high, volume
        if i >= 49 and all(fin(x) for x in F["ATRP"][i - 49:i + 1]):
            F["ATRX"][i] = F["ATRP"][i] / (sum(F["ATRP"][i - 49:i + 1]) / 50)
        e50 = ewm_step(e50, c[i], 2 / 51)
        e200 = ewm_step(e200, c[i], 2 / 201)
        if e50[1] >= 50 and e200[1] >= 200:
            F["TREND"][i] = 2.0 if (c[i] > e50[0] and c[i] > e200[0]) else (
                0.0 if (c[i] < e50[0] and c[i] < e200[0]) else 1.0)
        F["RET20"][i] = (c[i] / c[i - 20] - 1) * 100 if i >= 20 else NAN
        if i >= 1:
            d = c[i] - c[i - 1]
            ag = ewm_step(ag, max(d, 0.0), 1 / 14)
            al = ewm_step(al, max(-d, 0.0), 1 / 14)
            if ag[1] >= 14:
                if al[0] == 0:
                    F["RSI14"][i] = 100.0 if ag[0] > 0 else 50.0
                elif ag[0] == 0:
                    F["RSI14"][i] = 0.0
                else:
                    F["RSI14"][i] = 100 - 100 / (1 + ag[0] / al[0])
        if i >= 251:
            F["DD52"][i] = (c[i] / max(c[i - 251:i + 1]) - 1) * 100
        if i >= 20:
            vm = sum(v[i - 20:i]) / 20
            F["RVOL"][i] = v[i] / vm if vm != 0 else NAN
    return {k: np.array(x, float) for k, x in F.items()}


def index_dims(close, kind):
    """One index's own measures at each of its bars: 'up' (close at or above its 50-session mean), 'ret20',
    'vix5', 'vixp' (share of the last 250 values, today included, at or below today; 60 needed)."""
    n = len(close)
    out = {k: [NAN] * n for k in ("up", "ret20", "vix5", "vixp")}
    for i in range(n):
        if i >= 49:
            m = sum(close[i - 49:i + 1]) / 50
            out["up"][i] = 1.0 if close[i] >= m else 0.0
        if i >= 20:
            out["ret20"][i] = (close[i] / close[i - 20] - 1) * 100
        if i >= 5:
            out["vix5"][i] = (close[i] / close[i - 5] - 1) * 100
        w = [x for x in close[max(0, i - 249):i + 1] if fin(x)]
        if len(w) >= 60:
            out["vixp"][i] = sum(1 for x in w if x <= close[i]) / len(w) * 100
    return {k: np.array(x, float) for k, x in out.items()}


def bucket(dim_edges, ncat, x):
    """The Pine's bucket(): -1 unknown; a code dimension = its value; else how many edges are at or below x."""
    if not fin(x):
        return -1
    if dim_edges is None:
        return int(min(max(round(x), 0), ncat - 1))
    return sum(1 for e in dim_edges if e <= x)


# ---------------------------------------------------------------------------------------------- the marks
def field(F, name, x, e, d1, dsig, o, c, k_j):
    """A condition field for watch day j of a pseudo-pick: x = decision bar, e = entry bar, d1 = its D1 bar,
    dsig = its signal bar."""
    if name.endswith("_change"):
        base = name[:-7]
        if x - 1 < 0 or x - 1 < WARMUP:              # the first panel row has no change
            return NAN
        return F[base][x] - F[base][x - 1]
    if name in F:
        return F[name][x] if x >= WARMUP else NAN
    if name == "gap_pct":
        return (o[e] / c[e - 1] - 1) * 100
    if name == "pc_vs_d1":
        return 0.0 if k_j == 1 else (c[x] / o[d1] - 1) * 100
    if name == "pc_vs_d1_atr":
        return 0.0 if k_j == 1 else (c[x] / o[d1] - 1) / F["s_atr"][dsig]
    raise KeyError(name)


OPS = {">": lambda a, b: a > b, "<": lambda a, b: a < b, ">=": lambda a, b: a >= b, "<=": lambda a, b: a <= b}


def day_result(F, conds, d, j, o, c, pending_gap=False):
    """Watch day j of the pseudo-pick on bar d: 1 = all hold, 0 = a condition fails, -1 = unknown (the pick stops),
    2 = all known hold and the open's gap rule is still to come (tonight only)."""
    e, x, d1 = d + j, d + j - 1, d + 1
    anyF = anyN = pend = False
    for name, op, val in conds:
        if pending_gap and name == "gap_pct":
            pend = True
            continue
        a = field(F, name, x, e, d1, d, o, c, j)
        if not fin(a):
            anyN = True
            continue
        if not OPS[op](round(a, 9), round(float(val), 9)):
            anyF = True
    if anyF:
        return 0
    if anyN:
        return -1
    return 2 if pend else 1


def marks(F, setups, o, c):
    """{setup: [entry bars]}: bar t is marked when, for some pseudo-pick d = t - k (k = 1..5, d past the warm-up),
    t is d's FIRST qualifying open."""
    n = len(c)
    out = {s: [] for s in setups}
    for t in range(1, n):
        for s, conds in setups.items():
            for k in range(1, 6):
                d = t - k
                if d < WARMUP:
                    continue
                first = False
                for j in range(1, k + 1):
                    r = day_result(F, conds, d, j, o, c)
                    if r == 0:
                        continue
                    if r == -1:
                        break
                    first = j == k
                    break
                if first:
                    out[s].append(t)
                    break
    return out


def tonight(F, setups, o, c):
    """After the last bar's close: per setup FIRES / ARMED (the gap rule waits for the open) or ''."""
    n = len(c)
    t = n                                          # the next session
    res = {}
    for s, conds in setups.items():
        res[s] = ""
        for k in range(1, 6):
            d = t - k
            if d < WARMUP or d >= n:
                continue
            ok = True
            for j in range(1, k):
                r = day_result(F, conds, d, j, o, c)
                if r == 0:
                    continue
                ok = False                         # an earlier day qualified or the pick stopped
                break
            if not ok:
                continue
            r = day_result_tonight(F, conds, d, k, o, c)
            if r in (1, 2):
                res[s] = "FIRES" if r == 1 else "ARMED"
                break
    return res


def day_result_tonight(F, conds, d, k, o, c):
    """Watch day k = the next session: features at the last bar, the gap rule pending."""
    x, d1 = d + k - 1, d + 1
    anyF = anyN = pend = False
    for name, op, val in conds:
        if name == "gap_pct":
            pend = True
            continue
        if k == 1 and name in ("pc_vs_d1", "pc_vs_d1_atr"):
            a = 0.0
        elif name in ("pc_vs_d1", "pc_vs_d1_atr"):
            a = (c[x] / o[d1] - 1) * 100 if name == "pc_vs_d1" else (c[x] / o[d1] - 1) / F["s_atr"][d]
        else:
            a = field(F, name, x, x + 1, d1, d, o, c, k)
        if not fin(a):
            anyN = True
            continue
        if not OPS[op](round(a, 9), round(float(val), 9)):
            anyF = True
    if anyF:
        return 0
    if anyN:
        return -1
    return 2 if pend else 1
