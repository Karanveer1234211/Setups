"""
test_setuplab.py - setuplab's checks: hand-computed trades, the engine's edge cases, and three planted worlds.

  world R ("real setup"): every pick falls for 1-3 days then bounces; feature x turns down exactly on the last
          falling day, feature y is noise. x must beat D1 AND beat the price-only dip entry on the same trades;
          y must not beat the dip entry.
  world W ("waiting world"): the same fall-then-bounce prices, x and y both noise. Noise setups DO beat D1 here
          (just by waiting) - the trap - but must NOT beat the price-only dip entry.
  world N ("null"): random-walk prices, noise features: nothing beats D1.
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import setuplab as S  # noqa: E402

FAILS = []
COUNT = [0]


def check(name, ok, detail=""):
    COUNT[0] += 1
    print(("  ok    " if ok else "  FAIL  ") + name + ("" if ok else "   <- %s" % (detail,)))
    if not ok:
        FAILS.append(name)


def make_world(kind, n_days=520, per_day=3, seed=1):
    """kind R / W / N. Each pick its own symbol; features given per symbol-date with explicit *_change."""
    rng = np.random.default_rng(seed)
    cal = pd.bdate_range("2021-01-01", periods=n_days + 15)
    wl, fe = [], []
    t = 0
    for d in range(2, n_days):
        for r in range(1, per_day + 1):
            t += 1
            sym = "S%05d" % t
            sc = 100.0
            ent = sc * (1 + rng.normal(0, 0.005))
            b = int(rng.integers(1, 4))                      # last falling day
            lr = rng.normal(0, 0.012, 10)
            if kind in ("R", "W"):
                lr[:b] -= 0.02
                lr[b:b + 4] += 0.015
            # closes relative to the D1 open; D1 open = entry; opens of later days = previous close (no gap) + noise
            C = np.empty(11)
            O = np.empty(11)
            O[1] = ent
            C[1] = ent * np.exp(lr[0])
            for k in range(2, 11):
                O[k] = C[k - 1] * (1 + rng.normal(0, 0.002))
                C[k] = O[k] * np.exp(lr[k - 1])
            row = {"trade_id": "D-%s-%d" % (cal[d].strftime("%Y%m%d"), r), "symbol": sym, "rank": r,
                   "signal_day": cal[d], "entry_day": cal[d + 1].strftime("%Y-%m-%d"), "signal_close": sc,
                   "status": "ok", "entry": ent, "net_bp": 0.0, "engine": "D", "pre_state": "S01",
                   "s_atr14": 0.02, "pre_state_bearish": int(rng.integers(0, 2)), "pre_state_bullish": 0,
                   "pre_nifty_vs_ma50": float(rng.normal()), "pre_env_code": int(rng.integers(0, 4)),
                   "pre_vix_pct250": float(rng.random()), "pre_ad_ratio_10": float(rng.random()),
                   "pre_state_overextended": 0, "pre_state_vol_elevated": int(rng.integers(0, 2))}
            for k in range(1, 11):
                row["close_%d" % k] = C[k] / ent - 1
                row["overnight_%d" % k] = (O[k] / (sc if k == 1 else C[k - 1]) - 1) if k > 1 else 0.0
            wl.append(row)
            # features on the signal day (D0) and D1..D6 dates: change at the date of day k is read at day k+1's open
            for k in range(0, 8):
                date = cal[d + k]
                if kind == "R":
                    xc = -1.0 if k == b else 1.0
                else:
                    xc = float(rng.choice([-1.0, 1.0]))
                yc = float(rng.choice([-1.0, 1.0]))
                fe.append({"symbol": sym, "timestamp": date, "x": xc, "x_change": xc, "y": yc, "y_change": yc})
    W = pd.DataFrame(wl)
    F = pd.DataFrame(fe)
    return S.Book(W, pd.Series(cal), F, "D"), W, F


def t_hand():
    """A three-pick hand world: every number below computed by hand."""
    cal = pd.bdate_range("2024-01-01", periods=20)
    rows = []

    def pick(i, closes, over, sc=100.0, ent=100.0):
        r = {"trade_id": "D-T-%d" % i, "symbol": "H%d" % i, "rank": 1, "signal_day": cal[2],
             "entry_day": cal[3].strftime("%Y-%m-%d"), "signal_close": sc, "status": "ok", "entry": ent,
             "net_bp": 0.0, "engine": "D", "pre_state": "S01", "s_atr14": 0.02,
             "pre_state_bearish": {1: 1, 2: 0, 3: np.nan}[i]}
        for k in range(1, 11):
            r["close_%d" % k] = closes[k - 1] / ent - 1
            r["overnight_%d" % k] = over[k - 1]
        return r
    cl = [98, 96, 97, 99, 101, 102, 103, 104, 105, 106]
    rows.append(pick(1, cl, [0] * 10))
    rows.append(pick(2, cl, [0, 0.01, 0, 0, 0, 0, 0, 0, 0, 0]))
    rows.append(pick(3, cl, [0] * 10))
    W = pd.DataFrame(rows)
    fe = []
    # feature f: change sequence by date index cal[2+k] (k = 0 is D0): pick 1 turns down at D2 (read at D3's open)
    seq = {1: [1, 1, -1, 1, 1, 1, 1], 2: [1, -1, 1, 1, 1, 1, 1], 3: [1, 0, 0, np.nan, 1, -1, 1]}
    for i, sq in seq.items():
        for k, v in enumerate(sq):
            fe.append({"symbol": "H%d" % i, "timestamp": cal[2 + k], "f": v, "f_change": v})
    book = S.Book(W, pd.Series(cal), pd.DataFrame(fe), "D")
    c = [("f_change", "<", 0)]
    L = S.replay(book, c, "original_d5").set_index("trade_id")
    Lf = S.replay(book, c, "fresh").set_index("trade_id")
    # pick 1: f falls at D2 -> enter D3 open = D2 close 96 (no gap) -> original exit D5 close 101
    check("h1 entry at the first open after the condition (D3 open = 96)", L.loc["D-T-1", "day"] == 3 and
          abs(L.loc["D-T-1", "price"] - 96) < 1e-9, L.loc["D-T-1"].to_dict())
    check("h2 original_d5 net = 101/96 - 1 - 0.35 pp", abs(L.loc["D-T-1", "ret"] - ((101 / 96 - 1) * 100 - 0.35)) < 1e-9)
    check("h3 fresh net = the close 4 sessions after entry (D7 = 103)",
          abs(Lf.loc["D-T-1", "ret"] - ((103 / 96 - 1) * 100 - 0.35)) < 1e-9 and Lf.loc["D-T-1", "exit_day"] == 7)
    # pick 2: f falls at D1 -> D2 open = D1 close 98 x 1.01 (gap) = 98.98
    check("h4 a gap is in the entry price (D2 open = 98 x 1.01)", abs(L.loc["D-T-2", "price"] - 98.98) < 1e-9)
    dd = 100 * (1 - 96 / 98.98)
    check("h5 trade drawdown = peak-to-trough over entry and closes", abs(L.loc["D-T-2", "trade_dd"] - dd) < 1e-9,
          (L.loc["D-T-2", "trade_dd"], dd))
    # pick 3: zero changes do not pass, then a missing value with no False -> Missing signal data
    check("h6 a zero change does not pass; a missing value then makes the trade 'Missing signal data'",
          L.loc["D-T-3", "status"] == "Missing signal data", L.loc["D-T-3", "status"])
    # condition with a False beside the missing value -> skip that day, not missing
    c2 = [("f_change", "<", 0), ("gap_pct", ">", 5)]
    L2 = S.replay(book, c2, "original_d5").set_index("trade_id")
    check("h7 a False beside a missing value = just not today (No entry, not Missing)",
          L2.loc["D-T-3", "status"] == "No entry", L2.loc["D-T-3", "status"])
    # blind D5 under original_d5: enter and exit the same session (open -> close)
    L3 = S.replay(book, [("day", ">=", 5), ("day", "<=", 5)], "original_d5").set_index("trade_id")
    check("h8 entry on D5 under original_d5 = D5 open to D5 close",
          abs(L3.loc["D-T-1", "ret"] - ((101 / 99 - 1) * 100 - 0.35)) < 1e-9)
    # fresh exit past D10 -> Missing exit data
    L4 = S.replay(book, [("day", ">=", 5), ("day", "<=", 5)], "fresh").set_index("trade_id")
    check("h9 fresh exit inside the 10-session path (D5 entry -> D9 close)",
          L4.loc["D-T-1", "status"] == "Filled" and L4.loc["D-T-1", "exit_day"] == 9)
    # dip control: pc_vs_d1 on D1 is never a dip; D2 open after D1 close 98 < 100 -> DIP_0 enters D2
    L5 = S.replay(book, S.control_setups()["DIP_0"], "original_d5").set_index("trade_id")
    L6 = S.replay(book, S.control_setups()["DIP_3"], "original_d5").set_index("trade_id")
    check("h10 price-only dip: DIP_0 enters D2 (98 < 100), DIP_3 waits for a close under 97 (D2 close 96 -> D3)",
          L5.loc["D-T-1", "day"] == 2 and L6.loc["D-T-1", "day"] == 3, (L5.loc["D-T-1", "day"], L6.loc["D-T-1", "day"]))
    L7 = S.replay(book, S.control_setups()["BOUNCE_upclose"], "original_d5").set_index("trade_id")
    L8 = S.replay(book, S.control_setups()["DIPATR_1"], "original_d5").set_index("trade_id")
    check("h12 ATR dip: ATR 2%%; D1 close 98 = exactly -1 ATR does not pass '< -1'; D2 close 96 (-2 ATR) -> enter D3",
          L8.loc["D-T-1", "day"] == 3, L8.loc["D-T-1", "day"])
    L9 = S.replay(book, S.control_setups()["TUE"], "original_d5").set_index("trade_id")
    exp = next((k for k in range(1, 6) if cal[3 + k - 1].weekday() == 1), 0)      # sessions, not calendar days
    check("h13 TUE control enters the first Tuesday open of D1..D5 (D1 = %s)" % cal[3].day_name(),
          (L9.loc["D-T-1", "day"] if L9.loc["D-T-1", "status"] == "Filled" else 0) == exp, (L9.loc["D-T-1", "day"], exp))
    L10 = S.replay(book, [("snap:pre_state_bearish", ">", 0.5)], "original_d5").set_index("trade_id")
    check("h14 snapshot field (the pick's state at the signal): 1 -> enter D1, 0 -> No entry, missing -> Missing",
          L10.loc["D-T-1", "day"] == 1 and L10.loc["D-T-2", "status"] == "No entry" and
          L10.loc["D-T-3", "status"] == "Missing signal data", L10["status"].to_dict())
    check("h11 bounce marker: under the D1 open, then an up close (D3 close 97 > 96 -> enter D4)",
          L7.loc["D-T-1", "day"] == 4, L7.loc["D-T-1", "day"])


def t_worlds():
    res = {}
    for kind in ("R", "W", "N"):
        book, _, _ = make_world(kind, seed={"R": 3, "W": 4, "N": 5}[kind])
        boot = S.Boot(book.signal_day[book.ok])
        setups = {"X": [("x_change", "<", 0)], "Y": [("y_change", "<", 0)], **S.control_setups()}
        led = S.run_all(book, setups, boot)
        res[kind] = {}
        for nm in ("X", "Y"):
            for ctl in ("Blind_D1", "DIP_0"):
                res[kind][(nm, ctl)] = S.paired(led[(nm, "original_d5")], led[(ctl, "original_d5")], boot)
                res[kind][(nm, ctl, "fresh")] = S.paired(led[(nm, "fresh")], led[(ctl, "fresh")], boot)
    R, Wd, N = res["R"], res["W"], res["N"]
    f = lambda r: "lift %+.3f [%+.3f, %+.3f] n %d" % (r["lift_pp"], r["lo"], r["hi"], r["n"])
    check("w1 world R: the planted setup beats D1 on its own trades (interval above 0)", R[("X", "Blind_D1")]["lo"] > 0,
          f(R[("X", "Blind_D1")]))
    check("w2 world R: the planted setup beats the price-only dip entry on the same trades (both exits)",
          R[("X", "DIP_0")]["lo"] > 0 and R[("X", "DIP_0", "fresh")]["lo"] > 0,
          (f(R[("X", "DIP_0")]), f(R[("X", "DIP_0", "fresh")])))
    check("w3 world R: the noise feature does not beat the dip entry", not R[("Y", "DIP_0")]["lo"] > 0,
          f(R[("Y", "DIP_0")]))
    check("w4 world W (fall-then-bounce, noise features): noise setups DO beat D1 - waiting alone pays (the trap)",
          Wd[("X", "Blind_D1")]["lo"] > 0 and Wd[("Y", "Blind_D1")]["lo"] > 0,
          (f(Wd[("X", "Blind_D1")]), f(Wd[("Y", "Blind_D1")])))
    check("w5 world W: ... but they do NOT beat the price-only dip entry (the control catches the trap)",
          not Wd[("X", "DIP_0")]["lo"] > 0 and not Wd[("Y", "DIP_0")]["lo"] > 0,
          (f(Wd[("X", "DIP_0")]), f(Wd[("Y", "DIP_0")])))
    check("w6 world N (random walk, noise): no setup beats D1", all(not (N[(k, "Blind_D1")]["lo"] > 0) and
                                                                   not (N[(k, "Blind_D1")]["hi"] < 0) for k in "XY"),
          (f(N[("X", "Blind_D1")]), f(N[("Y", "Blind_D1")])))


def t_space():
    book, _, _ = make_world("N", n_days=200, seed=9)
    sp = S.space_setups(["x", "y"])
    check("s1 the pair space of 2 features = 4 singles... (2 x 2 singles + 1 pair x 4 directions = 8 setups)",
          len(sp) == 8, len(sp))
    abc = S.abc_setups()
    check("s2 A/B/C x 4 confirmations = 28 setups; A+C and A+B+C identical conditions",
          len(abc) == 28 and set(abc["A+C__none"]) == set(abc["A+B+C__none"]))


def t_confluence():
    import tempfile
    tmp = Path(tempfile.mkdtemp(prefix="sl_conf_"))
    pd.DataFrame({"engine": ["D"] * 6, "feature": ["D_sma200", "D_ema20_angle_deg", "Comb_X", "D_missing",
                                                   "W_ret_13w", "D_rsi14"],
                  "importance": [6, 5, 4, 3, 2, 1]}).to_csv(tmp / "why.csv", index=False)
    pd.DataFrame({"symbol": ["A"], "timestamp": [pd.Timestamp("2024-01-01")], "D_sma200": [1.0],
                  "D_ema20_angle_deg": [1.0], "Comb_X": [1.0], "W_ret_13w": [1.0], "D_rsi14": [1.0]}).to_parquet(
        tmp / "panel.parquet")
    ch, sk = S.pick_features(tmp / "why.csv", 2, tmp / "panel.parquet")
    check("c1 feature picker: by importance, skipping raw levels (D_sma200), combined flags and absent features",
          ch == ["D_ema20_angle_deg", "W_ret_13w"] and [x[0] for x in sk] == ["D_sma200", "Comb_X", "D_missing"],
          (ch, sk))
    book, _, _ = make_world("R", n_days=300, seed=21)
    import io
    from contextlib import redirect_stdout
    with redirect_stdout(io.StringIO()):
        v1, _ = S.cmd_run(book, tmp / "run", log=lambda *a: None, with_confluence=True)
    X = pd.read_csv(tmp / "run" / "confluence.csv")
    r = X[(X.setup == "x_change<0") & (X.confluence == "BEARSTATE") & (X.exit == "original_d5")] if \
        "x_change<0" in set(X.setup) else X.iloc[0:0]
    if r.empty:      # the pool names pairs only; the planted single x lives inside a pair with y
        r = X[X.setup.str.contains("x_change<0") & (X.confluence == "BEARSTATE") & (X.exit == "original_d5")]
    check("c2 confluence stage runs: NONE baselines, every context confluence, price x context pairs, 'adds' column",
          (X.setup == "NONE").any() and {"BEARSTATE", "DIP2&BEARSTATE", "MKT_BEARISH"} <= set(X.confluence) and
          X["adds_over_conf"].notna().any() and (tmp / "run" / "CONFLUENCE.md").is_file(), X.shape)
    check("c3 world R: a setup built on the planted feature adds over the confluence alone (BEARSTATE)",
          len(r) > 0 and (r.adds_lo > 0).all(), r[["setup", "adds_over_conf", "adds_lo", "adds_hi"]].to_dict("records")
          if len(r) else "no row")
    # c4-c5 (v0.6 rule 6): a context filter is judged by the trades it keeps vs those it drops on its parent setup.
    # Planted: picks flagged bearish earn +3% on every exit (closes D5-D10 raised; entries and signals read D1-D4
    # only, so they do not move). VOL_ELEVATED stays a coin flip. Absent: the same world unplanted.
    _, W0, F0 = make_world("R", n_days=300, seed=21)
    W1 = W0.copy()
    bear = W1["pre_state_bearish"].to_numpy() == 1
    for k in range(5, 11):
        W1.loc[bear, "close_%d" % k] = (1 + W1.loc[bear, "close_%d" % k]) * 1.03 - 1
    cal = pd.Series(pd.bdate_range("2021-01-01", periods=300 + 15))
    pool = {"NONE": [], "x_change<0": [("x_change", "<", 0)]}
    got, why = {}, {}
    for nm, W_ in (("planted", W1), ("absent", W0)):
        bk = S.Book(W_, cal, F0, "D")
        (tmp / nm / "D").mkdir(parents=True)
        with redirect_stdout(io.StringIO()):
            got[nm] = S.confluence(bk, None, S.Boot(bk.signal_day[bk.ok]), tmp / nm / "D", log=lambda *a: None,
                                   pool=pool)
        RR = S.rank_rows(S.lb_table(tmp / nm, ["D"]), ["D"], min_n=50, min_years=1).set_index(["setup", "exit"])
        why[nm] = {c: "context filter" in RR.loc[("x_change<0 || %s" % c, "original_d5"), "why_not"]
                   for c in ("BEARSTATE", "VOL_ELEVATED", "DIP1&BEARSTATE")}
    P, A = got["planted"], got["absent"]
    pb = P[(P.confluence == "BEARSTATE")]
    pp = P[P.confluence.str.endswith("&BEARSTATE") & (P.filter_kept >= 30) & (P.filter_dropped >= 30)]
    po = P[~P.confluence.str.endswith("BEARSTATE") & P.filter_q.notna()]
    an = A[A.filter_q.notna()]
    check("c4 rule 6, planted: the bearish filter keeps better trades (+3%) on its parents (alone and with each "
          "price confluence) at a 5% false discovery rate; the coin-flip filters do not; the leaderboard agrees",
          len(pb) == 4 and (pb.filter_q <= 0.05).all() and pb.filter_gain.between(2.0, 4.0).all() and
          (pb.filter_lo > 0).all() and len(pp) >= 8 and (pp.filter_q <= 0.05).mean() >= 0.9 and
          (po.filter_q <= 0.05).mean() <= 0.02 and
          why["planted"] == {"BEARSTATE": False, "VOL_ELEVATED": True, "DIP1&BEARSTATE": False},
          (pb[["setup", "exit", "filter_gain", "filter_q"]].to_dict("records"), len(pp),
           (pp.filter_q <= 0.05).mean() if len(pp) else None, (po.filter_q <= 0.05).mean(), why["planted"]))
    check("c5 rule 6, absent: no context filter passes the false discovery rate (the plain 95% interval lets "
          "about 2.5% through by luck) and the leaderboard flags the bearish filter",
          len(an) > 100 and (an.filter_q <= 0.05).sum() == 0 and why["absent"]["BEARSTATE"] and
          why["absent"]["DIP1&BEARSTATE"], (len(an), int((an.filter_q <= 0.05).sum()), (an.filter_lo > 0).mean(),
                                            why["absent"]))
    pv = np.array([0.001, 0.008, 0.039, 0.041, 0.042, 0.06, 0.074, 0.205, 0.212, 0.216])   # a textbook example
    check("c6 Benjamini-Hochberg q-values on a hand example; p from the bootstrap sd (z = 1.96 -> 0.025)",
          np.allclose(S.bh_q(pv), [0.01, 0.04, 0.084, 0.084, 0.084, 0.1, 0.10571429, 0.216, 0.216, 0.216]) and
          abs(S.filter_p([1.96], [1.0])[0] - 0.025) < 1e-3 and np.isnan(S.bh_q([np.nan, 0.01])[0]),
          S.bh_q(pv))


def t_build():
    # b1: hand bars with a missing session and a pick near the data's end
    cal = pd.bdate_range("2024-01-01", periods=20)
    o = np.array([10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21], float)
    c = o + 0.5
    ci = np.array([0, 1, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12])          # session 3 missing for this stock
    W = S.watchlist_rows([{"trade_id": "D-X-1", "engine": "D", "rank": 4, "symbol": "Q", "signal_day": cal[1], "j": 1},
                          {"trade_id": "D-X-2", "engine": "D", "rank": 9, "symbol": "Q", "signal_day": cal[10], "j": 8}],
                         {"Q": (o, c, ci)}, cal.to_numpy()).set_index("trade_id")
    r = W.loc["D-X-1"]
    check("b1 build from own bars: entry = next bar's open, close_k / entry - 1, gaps, the entry day after a missing "
          "session, NaN past the data's end",
          r.entry == 12 and r.signal_close == 11.5 and abs(r.close_1 - (12.5 / 12 - 1)) < 1e-12 and
          abs(r.overnight_2 - (13 / 12.5 - 1)) < 1e-12 and r.entry_day == str(cal[2].date()) and
          W.loc["D-X-2", "entry_day"] == str(cal[10].date()) and np.isfinite(W.loc["D-X-2", "close_3"]) and
          np.isnan(W.loc["D-X-2", "close_4"]), W.T.to_dict())
    # b2: a world rebuilt through watchlist_rows replays identically (the build's format = the backtester's)
    book, W0, F = make_world("R", n_days=150, seed=31)
    P, bars = [], {}
    for i in range(book.n):
        sym = "Z%05d" % i
        oo = np.concatenate([[book.sc[i]], book.O[i, 1:]])
        cc = np.concatenate([[book.sc[i]], book.C[i, 1:]])
        bars[sym] = (oo, cc, book.i1[i] - 1 + np.arange(len(oo)))
        P.append({"trade_id": book.ids[i], "engine": "D", "rank": int(book.rank[i]), "symbol": sym,
                  "signal_day": book.signal_day[i], "j": 0})
    W1 = S.watchlist_rows(P, bars, book.cal)
    keep = W0.set_index("trade_id")[["status", "net_bp", "pre_state", "s_atr14", "symbol"]]
    W1 = W1.drop(columns="symbol").join(keep, on="trade_id")
    b2 = S.Book(W1, pd.Series(book.cal), F, "D")
    same = True
    for conds in ([("x_change", "<", 0)], S.control_setups()["DIP_2"], [("day", "<=", 1), ("day", ">=", 1)]):
        for m in S.EXITS:
            x, y = S.replay(book, conds, m), S.replay(b2, conds, m)
            same &= (x.status.values == y.status.values).all() and np.allclose(x.ret, y.ret, equal_nan=True,
                                                                                 atol=1e-9)
    check("b2 a watchlist rebuilt from bars replays identically (setups, dips, D1; both exits)", bool(same))
    # b3: ranks filter and the by-rank view
    bk = S.Book(W0, pd.Series(book.cal), F, "D", ranks=[1, 2])
    import tempfile, io
    from contextlib import redirect_stdout
    tmp = Path(tempfile.mkdtemp(prefix="sl_rank_"))
    with redirect_stdout(io.StringIO()):
        S.cmd_run(book, tmp, log=lambda *a: None)
    rk = pd.read_csv(tmp / "by_rank.csv") if (tmp / "by_rank.csv").is_file() else pd.DataFrame()
    check("b3 --ranks keeps only those ranks; the by-rank view has the 1-3 band and each rank",
          set(bk.rank) == {1, 2} and len(rk) > 0 and {"ranks 1-3", "rank 01", "rank 03"} <= set(rk.group),
          (set(bk.rank), sorted(set(rk.group)) if len(rk) else None))


def t_v06():
    import io
    import json
    import tempfile
    from contextlib import redirect_stdout
    rng = np.random.default_rng(5)
    # v1: the count-matrix bootstrap = the index bootstrap
    days = pd.bdate_range("2021-01-01", periods=400).to_numpy()
    bt = S.Boot(days)
    di = rng.integers(0, 400, 3000)
    v = rng.normal(size=3000)
    s_ = np.bincount(di, weights=v, minlength=400)
    c_ = np.bincount(di, minlength=400).astype(float)
    old = s_[bt.ix].sum(1) / c_[bt.ix].sum(1)
    lo, hi = bt.ci_idx(di, v)
    check("v1 the count-matrix bootstrap gives the index bootstrap's interval",
          abs(lo - np.percentile(old, 2.5)) < 1e-9 and abs(hi - np.percentile(old, 97.5)) < 1e-9, (lo, hi))
    # v2: stats = paired_fast + years / halves / twin, computed by hand
    book, W0, F = make_world("R", n_days=400, seed=41)
    boot = S.Boot(book.signal_day[book.ok])
    di = boot.index(book.signal_day)
    X = S.replay2(book, [("x_change", "<", 0)])
    D1 = S.replay2(book, [("day", "<=", 1), ("day", ">=", 1)])
    DIP = S.replay2(book, [("pc_vs_d1", "<", -2)])
    q = S.stats(X["fresh"], D1["fresh"], boot, di, book, DIP["fresh"])
    pf = S.paired_fast(X["fresh"], D1["fresh"], boot, di)
    pt = S.paired_fast(X["fresh"], DIP["fresh"], boot, di)
    m = X["fresh"]["f"] & D1["fresh"]["f"]
    yrs = pd.DatetimeIndex(book.signal_day[m]).year
    ynet = pd.Series(X["fresh"]["ret"][m]).groupby(yrs).mean()
    h2 = X["fresh"]["ret"][m & (book.signal_day > book.split_day)].mean()
    check("v2 stats(): the paired numbers, net interval around net, years, halves, what the indicators add",
          all(abs(q[k] - pf[k]) < 1e-12 for k in ("n", "setup_net", "lift_pp", "lo", "hi")) and
          q["net_lo"] < q["setup_net"] < q["net_hi"] and q["years"] == len(ynet) and
          q["years_net_pos"] == int((ynet > 0).sum()) and abs(q["half2_net"] - h2) < 1e-12 and
          abs(q["adds"] - pt["lift_pp"]) < 1e-12 and abs(q["adds_lo"] - pt["lo"]) < 1e-12, (q, pf, pt))
    # v3: one book of every engine, split by engine = each engine's own book; the chunked reader = the in-memory join
    tmp = Path(tempfile.mkdtemp(prefix="sl_v06_"))
    W2 = W0.copy()
    W2["engine"] = "ENS"
    W2["trade_id"] = "E" + W2["trade_id"].str[1:]
    WL = pd.concat([W0, W2], ignore_index=True)
    allb = S.Book(WL, pd.Series(book.cal), F, None)
    eb = allb.take(allb.engine_arr == "ENS", "ENS")
    ens = S.Book(WL, pd.Series(book.cal), F, "ENS")
    a1, a2 = S.replay(eb, [("x_change", "<", 0)], "fresh"), S.replay(ens, [("x_change", "<", 0)], "fresh")
    F.to_parquet(tmp / "f.parquet", index=False)
    ck = S.Book(W0, pd.Series(book.cal), None, "D")
    ck.attach(tmp / "f.parquet", ["x", "y"], chunk=1)
    same_f = all(np.array_equal(ck.F[k], book.F[k], equal_nan=True) for k in book.F)
    check("v3 Book.take(engine) = the engine's own book; the chunked panel reader = the in-memory join",
          eb.n == ens.n and (a1.status.values == a2.status.values).all() and
          np.allclose(a1.ret, a2.ret, equal_nan=True) and same_f and ck.features == ["x", "y"], (eb.n, ens.n, same_f))
    # v4: the declared eligibility and score, on a crafted table
    base = {"n": 400, "lo": 0.5, "adds_lo": 0.2, "years": 7, "years_net_pos": 6, "half1_net": 1, "half2_net": 1,
            "net_lo": 0.8, "setup_net": 1.2}
    rows = []
    for name, chg, twin in (("good", {}, "t"), ("small", {"E2:n": 250}, ""), ("noadd", {"E1:adds_lo": -0.1}, "t"),
                            ("noadd-notwin", {"E1:adds_lo": -0.1}, ""), ("twoyears", {"E2:years_net_pos": 5}, ""),
                            ("half", {"E1:half2_net": -0.2}, ""), ("weak", {"E2:net_lo": 0.1}, ""),
                            ('[["snap:pre_state_bearish", ">", 0.5]]', {"E2:filter_q": 0.2}, ""),
                            ('[["snap:rank", "<=", 3.0]]', {}, "")):
        r = {"conds": name, "exit": "fresh", "family": "x", "setup": name, "twin": twin, "twin_conds": twin}
        for e in ("E1", "E2"):
            r.update({"%s:%s" % (e, k): v for k, v in base.items()})
            r["%s:filter_q" % e] = 0.01
        r.update(chg)
        rows.append(r)
    RR = S.rank_rows(pd.DataFrame(rows), ["E1", "E2"]).set_index("conds")
    check("v4 the rule: n, lift, indicators-add (only with a twin), years, halves; score = the worse engine's low end",
          list(RR.index[RR.eligible]) == ["good", "noadd-notwin", "weak", '[["snap:rank", "<=", 3.0]]'] and
          RR.loc["weak", "score"] == 0.1 and "filter does not" in RR.loc['[["snap:pre_state_bearish", ">", 0.5]]', "why_not"] and
          RR.loc["good", "score"] == 0.8 and "E2: fewer than 300" in RR.loc["small", "why_not"],
          RR[["eligible", "why_not", "score"]].to_dict())
    sets = {"a": set(range(100)), "b": set(range(10, 110)), "c": set(range(200, 260)), "d": set(range(300, 340))}
    j = lambda *cs: json.dumps(sorted([list(c) for c in cs]))
    p1 = j(["x_change", "<", 0], ["pc_vs_d1", "<", -2])
    p2 = j(["x_change", "<", 0], ["pc_vs_d1", "<", -2], ["snap:pre_state_bearish", ">", 0.5])   # + a filter
    p3 = j(["x_change", "<", 0], ["pc_vs_d1", "<", -2], ["y_change", ">", 0])                   # + a condition
    p4 = j(["y_change", "<", 0])
    ids2 = {p1: set(range(0, 50)), p2: set(range(100, 130)), p3: set(range(200, 230)), p4: set(range(300, 400))}
    check("v5 versions: 70%-shared trades, a rule that only adds conditions or context filters to a chosen one",
          S.pick_diverse(["a", "b", "c", "d"], sets.get) == ["a", "c", "d"] and
          S.overlap({1, 2}, {1, 2, 3, 4, 5}) == 1.0 and S.pick_diverse([p1, p2, p3, p4], ids2.get) == [p1, p4])
    # v6: a full two-engine run from the command line: union pool, leaderboard, freeze file, resume, refusals
    book6, W6, F6 = make_world("R", n_days=1650, per_day=1, seed=61)
    W7 = W6.copy()
    W7["engine"] = "ENS"
    W7["trade_id"] = "E" + W7["trade_id"].str[1:]
    d = tmp / "data"
    d.mkdir()
    pd.concat([W6, W7], ignore_index=True).to_parquet(d / "watchlist.parquet", index=False)
    pd.DataFrame({"date": pd.to_datetime(book6.cal)}).to_parquet(d / "calendar.parquet", index=False)
    F6.to_parquet(tmp / "f6.parquet", index=False)
    (tmp / "cols.txt").write_text("# test\nx\ny  # both\nzz_not_there\n", encoding="utf-8")
    cmd = ["run", "--data", str(d), "--features", str(tmp / "f6.parquet"), "--columns-file", str(tmp / "cols.txt"),
           "--engine", "D,ENS", "--confluence", "--check", str(d / "watchlist.parquet"), "--out", str(tmp / "run")]
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = S.main(cmd)
    o = tmp / "run"
    fz = json.loads((o / "FREEZE_CANDIDATES.json").read_text()) if (o / "FREEZE_CANDIDATES.json").is_file() else {}
    sd = set(pd.read_csv(o / "D" / "setups_confluence.csv").conds) if (o / "D" / "setups_confluence.csv").is_file() \
        else set()
    se = set(pd.read_csv(o / "ENS" / "setups_confluence.csv").conds) if (o / "ENS" / "setups_confluence.csv").is_file() \
        else {1}
    top = fz.get("lists", {}).get("both exits", [])
    has_x = bool(top) and any(c[0] == "x_change" and c[1] == "<" for c in top[0]["conds"]) and \
        not any(str(c[0]).startswith("snap:") for c in top[0]["conds"])      # the world's contexts are noise
    info = json.loads((o / "RUN.json").read_text()) if (o / "RUN.json").is_file() else {}
    check("v6 two engines in one run: the same confluence combinations in both, a leaderboard, the freeze file; "
          "the planted feature leads; a missing column is skipped and listed; the watchlist check runs",
          rc == 0 and sd == se and (o / "LEADERBOARD.md").is_file() and (o / "POOL.json").is_file() and has_x and
          1 <= len(top) <= 3 and info.get("features_missing") == ["zz_not_there"] and
          info.get("watchlist_check", {}).get("verdict") == "MATCHED",
          (rc, len(sd), len(se), top[:1], info.get("features_missing"), buf.getvalue()[-600:]))
    lb1 = (o / "LEADERBOARD.md").read_text()
    buf2 = io.StringIO()
    with redirect_stdout(buf2):
        rc2 = S.main(cmd)
    lb2 = (o / "LEADERBOARD.md").read_text()
    with redirect_stdout(io.StringIO()):
        rc3 = S.main(cmd[:-1] + [str(o)] if False else [x if x != "D,ENS" else "D" for x in cmd])
    check("v7 the same command again resumes (stage 1 and the confluences kept, the same leaderboard); other settings "
          "in the same folder are refused", rc2 == 0 and "already done" in buf2.getvalue() and lb1 == lb2 and rc3 == 3,
          (rc2, rc3, buf2.getvalue()[-400:]))


# ======================================================================================== v0.7: frozen setups
DAILY_F = ["d_wq_16", "d_mdi14_diff5", "d_wq_40", "d_mdi14", "d_ema20_angle_deg", "d_bb_bw_20", "d_wq_44"]


class FakeLive:
    """Stands in for tradelab's readers in the scan (bars, calendar, panel path, cache root)."""

    def __init__(self, root, cal, bars, panel):
        self.root, self.cal, self._bars, self.panel = Path(root), cal, bars, Path(panel)

    def bars(self, symbols):
        return {s: self._bars[s] for s in symbols if s in self._bars}

    def ohlcv(self, symbols):
        out = {}
        for s in symbols:
            if s in self._bars:
                d, o, c = self._bars[s]
                h, lo = _hl(o, c)
                out[s] = (d, o, h, lo, c, 1e6 + (np.arange(len(c)) % 5) * 1e5)
        return out


def _hl(o, c):
    """The test worlds' highs and lows (the bars only carry opens and closes)."""
    return np.maximum(o, c) * 1.004, np.minimum(o, c) * 0.996


def live_world(tmp, kind="planted", seed=5, n_sess=48):
    """A cache-like world: own bars for every session, a paper ledger (D ranks 1-3, ENS ranks 1-2 a day) and a
    panel with every feature the frozen setups read. 'planted': dips after the pick, random gaps, the weekly
    13-week return falling on some Mondays (posted on the week's first session only) - every setup fires somewhere.
    'absent': prices only rise, opens gap up, the 13-week return never falls, %b > 0 - no setup can fire."""
    rng = np.random.default_rng(seed)
    cal = pd.bdate_range("2026-01-05", periods=n_sess)          # a Monday; no holidays
    days = cal.to_numpy().astype("datetime64[D]")
    mondays = np.array([d.weekday() == 0 for d in cal])
    led, bars, rows = [], {}, []
    names = ["M&M", "BAJAJ-AUTO"]
    t = 0
    for d in range(3, n_sess - 11):
        for eng, nr in (("D", 3), ("ENS", 2)):
            for r in range(1, nr + 1):
                t += 1
                sym = names[t - 1] if t <= len(names) else "Q%04d" % t
                if kind == "planted":
                    lr = rng.normal(0, 0.012, n_sess)
                    lr[d + 1:d + 4] -= rng.uniform(0, 0.03)
                    o = np.empty(n_sess)
                    c = 100 * np.exp(np.cumsum(lr))
                    o[0] = 100.0
                    o[1:] = c[:-1] * (1 + rng.normal(0, 0.006, n_sess - 1))
                    wstep = rng.choice([-1.0, 1.0], n_sess)
                    pctb = rng.uniform(-1, 1, n_sess)
                else:
                    lr = np.abs(rng.normal(0, 0.004, n_sess)) + 0.002
                    c = 100 * np.exp(np.cumsum(lr))
                    o = np.empty(n_sess)
                    o[0] = 100.0
                    o[1:] = c[:-1] * (1 + np.abs(rng.normal(0, 0.002, n_sess - 1)) + 1e-4)
                    wstep = np.ones(n_sess)
                    pctb = rng.uniform(0.1, 1, n_sess)
                bars[sym] = (days.copy(), o, c)
                led.append({"date": str(cal[d].date()), "engine": eng, "rank": r, "symbol": sym,
                            "score": float(rng.random()), "recorded_at": "2026-01-01T20:00:00+05:30"})
                w = np.cumsum(np.where(mondays, wstep, 0.0)) + 50.0
                F = {f: np.cumsum(rng.choice([-1.0, 1.0], n_sess)) for f in DAILY_F}
                for i in range(n_sess):
                    rows.append({"symbol": sym, "timestamp": cal[i], "w_ret_13w": w[i], "d_bb_pctb_20": pctb[i],
                                 "d_atr_pct": 2.0, **{f: F[f][i] for f in DAILY_F}})
    root = Path(tmp) / ("root_" + kind)
    (root / "paper").mkdir(parents=True, exist_ok=True)
    lines = [json.dumps(x) for x in led]
    lines.insert(1, "not json")                                             # an unreadable line is skipped
    lines.append(json.dumps(dict(led[0], symbol="DUPLICATE")))              # a later duplicate is ignored
    (root / "paper" / "ledger.jsonl").write_text("\n".join(lines) + "\n", encoding="utf-8")
    panel = root / "panel_live" / "panel.parquet"
    panel.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_parquet(panel, index=False)
    # the backtest's watchlist of the same picks, built from the same bars (the research route)
    P, wb = [], {}
    for x in led:
        sd = np.datetime64(x["date"], "D")
        j = int(np.flatnonzero(days == sd)[0])
        P.append({"trade_id": "%s-%s-%d" % (x["engine"], x["date"].replace("-", ""), x["rank"]),
                  "engine": x["engine"], "rank": x["rank"], "symbol": x["symbol"], "signal_day": pd.Timestamp(sd),
                  "j": j})
        o, c = bars[x["symbol"]][1], bars[x["symbol"]][2]
        wb[x["symbol"]] = (o, c, np.arange(n_sess))
    W = S.watchlist_rows(P, wb, days)
    W["status"], W["net_bp"], W["pre_state"] = "ok", 0.0, ""
    # s_atr14 as pick_meta records it: the simple 14-session ATR / close at the signal day (blank in the first 14)
    W["s_atr14"] = [float(S.atr_simple(*_hl(*bars[p["symbol"]][1:]), bars[p["symbol"]][2])[p["j"]]) for p in P]
    data = root / "wl"
    data.mkdir(exist_ok=True)
    W.to_parquet(data / "watchlist.parquet", index=False)
    pd.DataFrame({"date": cal}).to_parquet(data / "calendar.parquet", index=False)
    return {"root": root, "cal": days, "bars": bars, "panel": panel, "data": data, "led": led}


def test_freeze(doc, final_from=None):
    """A copy of the freeze with other setups / numbers, hashed like the real one (for the tests only)."""
    d = json.loads(json.dumps(doc))
    d.pop("sha256", None)
    if final_from is not None:
        for s in d["setups"]:
            s["final_001"] = final_from[s["id"]]
    d["sha256"] = S.frozen_hash(d)
    return d


def t_v07():
    import io
    import tempfile
    from contextlib import redirect_stdout
    tmp = Path(tempfile.mkdtemp(prefix="sl_v07_"))
    # ---- the freeze file
    fp, doc = S.load_frozen()
    ids = [x["id"] for x in doc["setups"]]
    bad = json.loads(fp.read_text(encoding="utf-8"))
    bad["setups"][0]["conds"][1][2] = -2.0
    (tmp / "bad.json").write_text(json.dumps(bad), encoding="utf-8")
    bad2 = json.loads(fp.read_text(encoding="utf-8"))
    bad2["setups"][2]["conds"][0][2] = 0.5
    bad2["sha256"] = S.frozen_hash(bad2)                    # file hash redone, the setup's own hash not
    (tmp / "bad2.json").write_text(json.dumps(bad2), encoding="utf-8")
    ref = []
    for f in ("bad.json", "bad2.json"):
        try:
            S.load_frozen(tmp / f)
            ref.append(False)
        except ValueError:
            ref.append(True)
    check("f1 the freeze file: 7 setups S1 S2 S3 C1 C2 C3 N1 with their sha256; a changed threshold is refused, and "
          "so is a re-hashed file whose setup no longer matches its own hash",
          ids == ["S1", "S2", "S3", "C1", "C2", "C3", "N1"] and all(ref) and
          [x["primary_exit"] for x in doc["setups"]] == ["original_d5"] * 6 + ["fresh"] and
          sorted(S.frozen_features(doc)) == sorted(DAILY_F + ["w_ret_13w", "d_bb_pctb_20"]), (ids, ref))
    conds, feats = S.frozen_conds(doc), S.frozen_features(doc)
    # ---- the planted world: the nightly scan, evening by evening, against the backtest on the full data
    w = live_world(tmp, "planted")
    data = FakeLive(w["root"], w["cal"], w["bars"], w["panel"])
    L = S.read_paper_ledger(w["root"])
    check("f2 the paper ledger reader: unreadable lines skipped, the first record of a day / engine / rank kept",
          len(L) == len(w["led"]) and "DUPLICATE" not in set(L.symbol), (len(L), len(w["led"])))
    truth = {}
    for e in ("D", "ENS"):
        with redirect_stdout(io.StringIO()):
            book = S.load(w["data"], w["panel"], e, feats + ["d_atr_pct"], None)
        for sid, cc in conds.items():
            day, st = S.trigger(book, cc)
            for i in np.flatnonzero(st == "Filled"):
                truth[(book.ids[i], sid)] = (int(day[i]), float(book.O[i, day[i]]))
    ann, entered, statuses, tonight_dip = {}, {}, set(), []
    pos = {d: i for i, d in enumerate(w["cal"])}
    out = tmp / "scan_planted"
    for T in w["cal"][3:]:
        Sx, P = S.scan_day(T, doc, conds, feats, L, data, out)
        statuses |= set(Sx.status)
        for r in Sx.itertuples(index=False):
            if r.status in ("FIRES", "ARMED"):
                ann.setdefault((r.trade_id, r.setup), []).append((T, r.status, int(r.next_watch_day),
                                                                  float(r.open_threshold)))
                if int(r.next_watch_day) == 1 and any(f.startswith("pc_vs_d1") for f, _, _ in conds[r.setup]):
                    tonight_dip.append(r)
            if r.status == "ENTERED":
                entered[(r.trade_id, r.setup)] = (int(r.entered_day), float(r.entry))
    # every backtest entry was named the evening before, with its watch day
    sig = {}
    for x in w["led"]:
        sig["%s-%s-%d" % (x["engine"], x["date"].replace("-", ""), x["rank"])] = (pos[np.datetime64(x["date"], "D")],
                                                                                  x["symbol"])
    miss_named, false_fires, armed_bad, armed_n = [], [], [], 0
    for key, (k, px) in truth.items():
        si = sig[key[0]][0]
        ok = any(pos[T] == si + k - 1 and wd == k for T, stt, wd, thr in ann.get(key, []))
        if not ok:
            miss_named.append(key)
    for key, lst in ann.items():
        for T, stt, wd, thr in lst:
            si, sym = sig[key[0]]
            t_open = w["bars"][sym][1][pos[T] + 1]
            if stt == "FIRES" and truth.get(key, (None,))[0] != wd:
                false_fires.append((key, T))
            if stt == "ARMED":
                armed_n += 1
                hit = truth.get(key, (None,))[0] == wd
                if hit != (t_open < thr):
                    armed_bad.append((key, T, t_open, thr))
    check("f3 the scan, evening by evening, names EVERY backtest entry of every setup the evening before it, with the "
          "same watch day (%d entries in both engines, all 7 setups)" % len(truth),
          len(truth) > 100 and not miss_named and {k[1] for k in truth} == set(ids), miss_named[:5])
    check("f4 no false FIRES: every FIRES became the backtest's entry on that watch day", not false_fires,
          false_fires[:5])
    check("f5 ARMED (gap-down setup S2): entered exactly when the next open was below tonight's close (%d named)"
          % armed_n, armed_n > 5 and not armed_bad, armed_bad[:5])
    same_ent = all(entered.get(k) is not None and entered[k][0] == v[0] and abs(entered[k][1] - v[1]) < 1e-9
                   for k, v in truth.items() if sig[k[0]][0] + v[0] - 1 < len(w["cal"]) - 1)
    check("f6 ENTERED on later evenings shows the backtest's entry day and price; no dip setup ever fires at D1",
          same_ent and not tonight_dip and {"FIRES", "ARMED", "ENTERED", "WATCHING", "EXPIRED"} <= statuses,
          (same_ent, len(tonight_dip), statuses))
    # forward record: every evening recorded on time -> the named entries = the backtest's trades and nets
    lp = tmp / "fwd_ledger.jsonl"
    for T in w["cal"][3:]:
        Sx, _ = S.scan_day(T, doc, conds, feats, L, data, out)
        named = [{"setup": r.setup, "status": r.status, "trade_id": r.trade_id, "symbol": r.symbol,
                  "watch_day": int(r.next_watch_day), "close_tonight": float(r.close_tonight),
                  "rule_at_open": r.rule_at_open} for r in Sx[Sx.status.isin(["FIRES", "ARMED"])].itertuples()]
        S.ledger_append(lp, {"event": "scan", "scan_date": str(pd.Timestamp(T).date()), "on_time": True,
                             "named": named})
    Fw = S.forward_record(L, data, doc, conds, feats, lp, w["cal"][-1], since="2026-01-01")
    nets = {}
    for e in ("D", "ENS"):
        with redirect_stdout(io.StringIO()):
            book = S.load(w["data"], w["panel"], e, feats + ["d_atr_pct"], None)
        for sid, cc in conds.items():
            R = S.replay2(book, cc)
            for i in np.flatnonzero(R["original_d5"]["f"]):
                nets[(book.ids[i], sid)] = (R["original_d5"]["ret"][i], R["fresh"]["ret"][i])
    E = Fw[Fw.entered]
    fwd_ok = len(E) == len(truth) and all(
        abs(r.net_d5 - nets[(r.trade_id, r.setup)][0]) < 1e-9 and
        (np.isnan(r.net_fresh) or abs(r.net_fresh - nets[(r.trade_id, r.setup)][1]) < 1e-9)
        for r in E.itertuples() if (r.trade_id, r.setup) in nets)
    check("f7 the forward record (on-time names only) = the backtest's trades, with the same net on both exits",
          fwd_ok and int((~Fw.entered).sum()) == sum(1 for v in ann.values() for x in v if x[1] == "ARMED") -
          sum(1 for k, v in ann.items() for x in v if x[1] == "ARMED" and truth.get(k, (0,))[0] == x[2]),
          (len(E), len(truth)))
    # ---- the absent world: nothing can fire
    a = live_world(tmp, "absent", seed=6)
    da = FakeLive(a["root"], a["cal"], a["bars"], a["panel"])
    La = S.read_paper_ledger(a["root"])
    st_a = set()
    for T in a["cal"][3:]:
        Sx, _ = S.scan_day(T, doc, conds, feats, La, da, tmp / "scan_absent")
        st_a |= set(Sx.status)
    n_bt = 0
    for e in ("D", "ENS"):
        with redirect_stdout(io.StringIO()):
            book = S.load(a["data"], a["panel"], e, feats + ["d_atr_pct"], None)
        n_bt += sum(int((S.trigger(book, cc)[1] == "Filled").sum()) for cc in conds.values())
    check("f8 absent world (no weekly drop, no dip, %b > 0): no backtest entry and the scan never names one",
          n_bt == 0 and st_a <= {"WATCHING", "EXPIRED"}, (n_bt, st_a))
    # ---- the ledger: hash chain, on-time deadline
    ed = lp.read_text(encoding="utf-8").splitlines()
    rec = json.loads(ed[2])
    rec["named"] = []
    ed[2] = json.dumps(rec, sort_keys=True)
    lp2 = tmp / "edited.jsonl"
    lp2.write_text("\n".join(ed) + "\n", encoding="utf-8")
    try:
        S.ledger_append(lp2, {"event": "scan", "scan_date": "x"})
        chain = False
    except ValueError:
        chain = True
    fri = np.datetime64("2026-01-09", "D")
    d1 = S.on_time_deadline(fri, w["cal"][w["cal"] <= fri])
    d2 = S.on_time_deadline(np.datetime64("2026-01-06", "D"), w["cal"])
    check("f9 the setup ledger is hash-chained (an edited record is refused); on time = before 09:00 IST of the next "
          "session (Friday -> Monday; a late scan uses the known next session)",
          chain and d1.isoformat() == "2026-01-12T09:00:00+05:30" and d2.isoformat() == "2026-01-07T09:00:00+05:30",
          (chain, d1, d2))
    # ---- TradingView import text
    Sx, _ = S.scan_day(w["cal"][6], doc, conds, feats, L, data, out)
    tv = S.tv_text(pd.DataFrame([{"setup": "S2", "status": "ARMED", "symbol": "M&M"},
                                 {"setup": "S2", "status": "ARMED", "symbol": "M&M"},
                                 {"setup": "C1", "status": "FIRES", "symbol": "BAJAJ-AUTO"},
                                 {"setup": "C1", "status": "ENTERED", "symbol": "ABC"}]))
    check("f10 TradingView import: one section per setup and action, NSE tickers (M&M -> NSE:M_M), no duplicates",
          tv == "###C1 buy at open,NSE:BAJAJ_AUTO,###S2 buy if the open meets its rule,NSE:M_M,"
                "###Entered (open setup positions),NSE:ABC", tv)
    # ---- tag: the whole history, reconciled against the freeze's numbers
    fin = {}
    for e in ("D", "ENS"):
        with redirect_stdout(io.StringIO()):
            book = S.load(w["data"], w["panel"], e, feats + ["d_atr_pct"], None)
        d1 = S.replay2(book, S.D1_CONDS)
        for sid, cc in conds.items():
            R = S.replay2(book, cc)
            for m in S.EXITS:
                mm = R[m]["f"] & d1[m]["f"]
                fin.setdefault(sid, {})["%s %s" % (e, m)] = {"n": float(mm.sum()),
                                                              "setup_net": round(float(R[m]["ret"][mm].mean()), 6)}
    tf = tmp / "freeze_world.json"
    tf.write_text(json.dumps(test_freeze(doc, fin), indent=1), encoding="utf-8")
    rcs = []
    for frz in (str(tf), None):
        args = ["tag", "--data", str(w["data"]), "--features", str(w["panel"]), "--out", str(tmp / "tags")]
        if frz:
            args += ["--frozen", frz]
        buf = io.StringIO()
        with redirect_stdout(buf):
            rcs.append((S.main(args), buf.getvalue()))
    runs = sorted((tmp / "tags" / "TAGS").glob("TAGS_*"))
    Wt = pd.read_parquet(runs[0] / "setup_tags.parquet")
    Lt = pd.read_parquet(runs[0] / "setup_trades.parquet")
    js = json.loads((runs[0] / "TAGS.json").read_text(encoding="utf-8"))
    hashes_ok = all(__import__("hashlib").sha256((runs[0] / ln.split("  ")[1]).read_bytes()).hexdigest() ==
                    ln.split("  ")[0] for ln in (runs[0] / "outputs.sha256").read_text().splitlines())
    tag_same = set(zip(Lt.trade_id, Lt.setup)) == set(truth) and all(
        int(Wt.set_index("trade_id").at[t, "su_%s_day" % s]) == truth[(t, s)][0] for t, s in truth)
    txt_ok = all(set(x.split()) == {"%s@D%d" % (s, d) for (t, s), (d, _) in truth.items() if t == tid}
                 for tid, x in zip(Wt.trade_id, Wt.setups.fillna("")))
    check("f11 tag: every past pick's setups (watch day, price, both exits) = the backtest's; the 'setups' text, the "
          "long table and the hashes agree; RECONCILED against matching numbers, DIFFERS against FINAL_001's",
          rcs[0][0] == 0 and "TAGS RECONCILED" in rcs[0][1] and rcs[1][0] == 0 and "TAGS WRITTEN" in rcs[1][1] and
          js["reconciled_with_final_001"] and tag_same and txt_ok and hashes_ok and len(js["atr_check"]) == 2,
          (rcs[0][1][-200:], tag_same, txt_ok, hashes_ok, js.get("atr_check")))
    # ---- the command: outputs, a second run skipped, --force rescans but the ledger keeps its first record
    real = S.LiveData
    S.LiveData = lambda root, any_=False, panel="panel_live": FakeLive(w["root"], w["cal"], w["bars"], w["panel"])
    try:
        d = str(pd.Timestamp(w["cal"][10]).date())
        o = tmp / "cmd"
        r1 = S.main(["scan", "--root", str(w["root"]), "--out", str(o), "--date", d])
        n1 = len((o / "scan" / "setup_ledger.jsonl").read_text().splitlines())
        buf = io.StringIO()
        with redirect_stdout(buf):
            r2 = S.main(["scan", "--root", str(w["root"]), "--out", str(o), "--date", d])
        r3 = S.main(["scan", "--root", str(w["root"]), "--out", str(o), "--date", d, "--force"])
        n3 = len((o / "scan" / "setup_ledger.jsonl").read_text().splitlines())
        tag = d.replace("-", "")
        files = all((o / "scan" / f).is_file() for f in ("SCAN_%s.md" % tag, "scan_%s.csv" % tag, "tv_%s.txt" % tag))
        page = (o / "scan" / ("SCAN_%s.md" % tag)).read_text(encoding="utf-8")
        rec = json.loads((o / "scan" / "setup_ledger.jsonl").read_text().splitlines()[0])
    finally:
        S.LiveData = real
    # the nightly panel not yet updated for the evening: refused (retried by --all-missing), never NO DATA guesses
    cut = w["cal"][20]
    pp = pd.read_parquet(w["panel"])
    pp[pd.to_datetime(pp["timestamp"]) <= pd.Timestamp(cut)].to_parquet(tmp / "panel_cut.parquet", index=False)
    try:
        S.scan_day(w["cal"][21], doc, conds, feats, L, FakeLive(w["root"], w["cal"], w["bars"], tmp / "panel_cut.parquet"),
                   tmp / "scan_cut")
        cut_ok = False
    except ValueError as e:
        cut_ok = "has no row for 2026-02-03" in str(e)
    check("f13 an evening the nightly panel has not reached yet is refused (the scan never decides on missing features)",
          cut_ok)
    check("f12 the scan command: page, CSV, TradingView file and a ledger record (late: the evening was long past); "
          "the same evening again is skipped; --force rescans and the ledger keeps the first record",
          r1 == 0 and r2 == 0 and r3 == 0 and files and n1 == 1 and n3 == 1 and "already scanned" in buf.getvalue()
          and rec["on_time"] is False and "## At the next open" in page and "Forward record" in page,
          (r1, r2, r3, files, n1, n3, rec.get("on_time")))
    # ---- tradelab's reader (tl_setups, setups add-on) on the REAL outputs written above: the tags and the scan
    try:
        import tl_setups as SU
    except ImportError as e:
        check("f14 tradelab's tl_setups reads these tags and this scan", False,
              "tradelab's tl_setups is not importable (%s) - run the self-test after env_playbook.bat or "
              "env_tradelab.bat (tradelab with the setups add-on on PYTHONPATH)" % e)
        return
    Tt, ti = SU.load_tags(tmp / "tags", need=True)
    Lt2 = pd.read_parquet(Path(ti["folder"]) / "setup_trades.parquet")
    lp = {(str(t), s): int(dd) for t, s, dd in zip(Lt2.trade_id, Lt2.setup, Lt2.watch_day)}
    sp = {(t, s): dd for t, m in SU.setup_days(Tt, ti["setups"]).items() for s, dd in m.items()}
    tids = list(Tt.trade_id) + ["D-20990101-1"]
    X = SU.tag_columns(pd.DataFrame({"trade_id": tids}), Tt, ti["setups"], ti["primary_exit"], nets=True)
    Ti = Tt.set_index("trade_id")
    nets_ok = all(np.allclose(X["su_%s_net" % s].to_numpy(float)[:-1], Ti["su_%s_net_%s" % (
        s, "d5" if ti["primary_exit"][s] == "original_d5" else "fresh")].to_numpy(float), equal_nan=True)
        for s in ti["setups"])
    Sx, si = SU.read_scan(o, d)
    sc = pd.read_csv(o / "scan" / ("scan_%s.csv" % tag), dtype={"trade_id": str})
    act = SU.action_rows(Sx)
    words_ok = all(SU.scan_words(r) and SU.scan_words(r) in SU.pick_setups_text(
        Sx, r["engine"], int(r["rank"]), r["symbol"], r["signal_day"]) for r in act if r["status"] != "ENTERED")
    check("f14 tradelab's tl_setups reads these tags and this scan: the 7 setups and their primary exits, every "
          "entry's watch day (= the long table), each pick's net at its primary exit, an uncovered pick left blank; "
          "the scan's rows, its ledger record (LATE) and every action worded on its pick",
          ti["setups"] == ids and ti["primary_exit"]["N1"] == "fresh" and sp == lp and len(lp) == len(truth) and
          nets_ok and not bool(X.iloc[-1]["setups_tagged"]) and si["found"] and si["on_time"] is False and
          len(Sx) == len(sc) and len(act) == int(sc.status.isin(["FIRES", "ARMED", "ENTERED"]).sum()) > 0 and
          words_ok, (ti["setups"], len(lp), len(truth), nets_ok, si, len(act)))


# ======================================================================================== v0.8: zones and the chart
def _syn_stock(seed, n=900, flat=False):
    """A synthetic daily stock from 2015 (a holiday, continuous volumes; flat=True adds a 40-day stuck stretch)."""
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2015-01-05", periods=n)
    dates = dates[~((dates.month == 8) & (dates.day == 15))]
    n = len(dates)
    lr = rng.normal(0, 0.02, n)
    if flat:
        lr[300:340] = 0.0
    c = 100 * np.exp(np.cumsum(lr))
    o = c * (1 + rng.normal(0, 0.008, n))
    h = np.maximum(o, c) * (1 + np.abs(rng.normal(0, 0.01, n)))
    lo = np.minimum(o, c) * (1 - np.abs(rng.normal(0, 0.01, n)))
    if flat:
        o[300:340] = h[300:340] = lo[300:340] = c[300:340]
    v = np.round(rng.lognormal(13, 0.6, n))
    return dates, o, h, lo, c, v


def _idx_series(seed, n=900):
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2015-01-05", periods=n)
    return dates.to_numpy().astype("datetime64[D]"), 1000 * np.exp(np.cumsum(rng.normal(0, 0.012, n)))


def _fx():
    """Production's features_daily (bigmove_deploy, on PYTHONPATH through env_tradelab.bat / env_playbook.bat)."""
    try:
        import features_daily as FX
        return FX
    except ImportError:
        return None


class FakeZoneLive(FakeLive):
    """FakeLive with the v0.8 readers: index closes (synthetic, on the world's calendar), forget."""

    def __init__(self, w):
        super().__init__(w["root"], w["cal"], w["bars"], w["panel"])
        rng = np.random.default_rng(3)
        self._idx = {k: (w["cal"], 100 * np.exp(np.cumsum(rng.normal(0, 0.01, len(w["cal"])))))
                     for k, _ in S.ZONE_INDEX}

    def index_closes(self, names):
        return {k: self._idx[k] for k in names}

    def forget(self, symbols):
        pass


def t_v08():
    import io
    import tempfile
    from contextlib import redirect_stdout
    sys.path.insert(0, str(HERE))
    import pine_mirror as PM
    tmp = Path(tempfile.mkdtemp(prefix="sl_v08_"))
    fp, doc = S.load_frozen()
    conds, feats = S.frozen_conds(doc), S.frozen_features(doc)
    # ---- z1 the zone values: setuplab's vectorised code = the Pine's bar-by-bar mirror (stock and index measures)
    worst = 0.0
    for seed in (1, 2, 3):
        dates, o, h, lo, c, v = _syn_stock(seed)
        days = ((dates.to_numpy().astype("datetime64[D]") - np.datetime64("1970-01-01")).astype(int)).tolist()
        M = PM.features(days, list(o), list(h), list(lo), list(c), list(v))
        sd = S.stock_dims(o, h, lo, c, v)
        sd["s_atr"] = S.atr_simple(h, lo, c)
        for k in ("ATRP", "ATRX", "TREND", "RET20", "RSI14", "DD52", "RVOL", "s_atr"):
            if not np.array_equal(np.isnan(sd[k]), np.isnan(M[k])):
                worst = np.inf
            else:
                worst = max(worst, float(np.nanmax(np.abs(sd[k] - M[k]))))
    idx = {k: _idx_series(10 + i) for i, (k, _) in enumerate(S.ZONE_INDEX)}
    MD = S.market_dims(idx)
    mi = {k: PM.index_dims(list(cl), k) for k, (_, cl) in idx.items()}
    up = np.array([mi[k]["up"] for k in ("nifty", "mid", "small")])
    idx_ok = (np.allclose(MD["IDX"].to_numpy(), np.where(np.isnan(up).any(0), np.nan, up.sum(0)), equal_nan=True) and
              np.allclose(MD["VIXP"].to_numpy(), mi["vix"]["vixp"], equal_nan=True) and
              np.allclose(MD["VIX5"].to_numpy(), mi["vix"]["vix5"], equal_nan=True) and
              np.allclose(MD["NIFTY20"].to_numpy(), mi["nifty"]["ret20"], equal_nan=True) and
              np.allclose(MD["SMALL20"].to_numpy(), mi["small"]["ret20"], equal_nan=True))
    bk = S.zone_buckets({d[0]: np.array([1.99, 2.0, 4.5, np.nan] if d[0] == "ATRP" else [0, 1, 2, np.nan]
                                        if d[0] in ("TREND", "IDX") else [np.nan] * 4) for d in S.ZONE_DIMS})
    check("z1 the zone values: setuplab's vectorised measures = the Pine's bar-by-bar mirror on 3 stocks of 900 "
          "sessions (largest difference %.1e), pick_meta's simple ATR for S1 too, and on the four indices (IDX, VIX percentile, VIX 5-day, NIFTY and "
          "Smallcap 20-day); buckets: an edge counts upward (ATR%% 2.0 -> '2-3'), unknown = -1" % worst,
          worst < 1e-9 and idx_ok and list(bk["ATRP"]) == [0, 1, 3, -1] and list(bk["TREND"]) == [0, 1, 2, -1],
          (worst, idx_ok, list(bk["ATRP"])))
    # ---- z2 the whole-market engine = setuplab's own replay with every stock-day as a pick
    w = live_world(tmp, "planted", seed=5, n_sess=48)
    P = pd.read_parquet(w["panel"])
    P.columns = [x.lower() for x in P.columns]
    P["date"] = pd.to_datetime(P["timestamp"]).dt.normalize().to_numpy().astype("datetime64[D]")
    want = list(dict.fromkeys([f.lower() for f in feats] + ["d_atr_pct"]))
    picks, wb = [], {}
    for s_, (dd, o, c) in w["bars"].items():
        wb[s_] = (o, c, np.arange(len(c)))
        for j in range(len(c) - 1):
            picks.append({"trade_id": "X-%s-%d" % (s_, j), "engine": "X", "rank": 1, "symbol": s_,
                          "signal_day": pd.Timestamp(dd[j]), "j": j})
    W = S.watchlist_rows(picks, wb, w["cal"])
    W["status"], W["net_bp"], W["pre_state"] = "ok", 0.0, ""
    W["s_atr14"] = [float(S.atr_simple(*_hl(*w["bars"][p_["symbol"]][1:]), w["bars"][p_["symbol"]][2])[p_["j"]])
                    for p_ in picks]
    (tmp / "allwl").mkdir()
    W.to_parquet(tmp / "allwl" / "watchlist.parquet", index=False)
    pd.DataFrame({"date": pd.DatetimeIndex(w["cal"])}).to_parquet(tmp / "allwl" / "calendar.parquet", index=False)
    with redirect_stdout(io.StringIO()):
        book = S.load(tmp / "allwl", w["panel"], "X", feats + ["d_atr_pct"], None)
    ref = {}
    for sid, cc in conds.items():
        R = S.replay2(book, cc)["fresh"]
        for i in np.flatnonzero(R["f"]):
            j = int(book.wl["trade_id"].iloc[i].rsplit("-", 1)[1])
            ref.setdefault((sid, book.symbols[i], j + int(R["day"][i])), set()).add(round(float(R["ret"][i]), 9))
    mine = {}
    for s_, (dd, o, c) in w["bars"].items():
        F, have = S.align_panel(P[P["symbol"] == s_].sort_values("date"), want, dd)
        for sid, e in S.market_entries(dd, o, c, F, S.atr_simple(*_hl(o, c), c), conds, have).items():
            for x in e[e + 4 < len(c)]:
                mine[(sid, s_, int(x))] = round((c[x + 4] / o[x] - 1) * 100 - S.COST, 9)
    check("z2 the whole market: every stock-day as a pseudo-pick gives exactly setuplab's own replay (every stock-day "
          "as a pick in a Book): %d entries, the same entry day and the same net held 5 sessions" % len(mine),
          set(ref) == set(mine) and all(len(x) == 1 and abs(next(iter(x)) - mine[k]) < 1e-7 for k, x in ref.items())
          and len(mine) > 500, (len(ref), len(mine)))
    # ---- z3 the search: a planted zone is found and holds out of sample; an absent one does not hold
    def zworld(effect, seed, n=4000):
        rng = np.random.default_rng(seed)
        cal = pd.bdate_range("2020-01-01", "2026-09-30").to_numpy().astype("datetime64[D]")
        pops = []
        for nm in ("D", "ENS"):
            day = np.sort(rng.choice(cal[:-10], n))
            B = {d[0]: rng.integers(0, len(d[3]), n).astype(np.int8) for d in S.ZONE_DIMS}
            net = rng.normal(0.5, 6.0, n) + rng.normal(0, 2, len(cal))[np.searchsorted(cal, day)]
            if effect:
                net += np.where(B["ATRP"] >= 2, 2.5, -0.5)
            pops.append(S._pop(nm, day, day + np.timedelta64(7, "D"), net, net + 3.0, B))
        return pops
    zp, evp, Tp, _ = S.choose_zone(zworld(True, 3))
    _, wrp = S.walk_forward(zworld(True, 3))
    za, eva, Ta, _ = S.choose_zone(zworld(False, 3))
    _, wra = S.walk_forward(zworld(False, 3))
    atr_in = zp is not None and any(r[0] == "ATRP" and r[1] >= 2 and r[2] == 3 for r in zp)
    # qualifying = the 95% intervals, not the point estimates: absent-world finalists with inside > outside whose
    # interval reaches 0 exist and do not qualify; every interval brackets its estimate
    rule = all(bool(r["qualifies"]) == all(r["%s_diff_lo" % p_] > 0 and r["%s_chk_lo" % p_] > 0 for p_ in ("D", "ENS"))
               for r in Ta.to_dict("records") if all(r["%s_n" % p_] >= 40 * 6.0 for p_ in ("D", "ENS")))
    wide = bool(((Ta["D_diff"] > 0) & (Ta["D_diff_lo"] <= 0) & ~Ta["qualifies"]).any())
    brackets = bool(((Ta["D_diff_lo"] <= Ta["D_diff"]) & (Ta["D_diff"] <= Ta["D_diff_hi"]) &
                     (Ta["D_lo"] <= Ta["D_net"]) & (Ta["D_net"] <= Ta["D_hi"])).all())
    check("z3 the zone search: planted (net +2.5 when ATR%% >= 3, else -0.5; noise and day shocks) -> '%s', out of "
          "sample %s; absent (no effect) -> %s with %d qualifying finalists in sample (luck) - out of sample %s, so it "
          "does not hold" % (S.zone_text(zp), "/".join(v["verdict"] for v in wrp.values()), S.zone_text(za),
                             int(Ta["qualifies"].sum()) if len(Ta) else 0,
                             "/".join(v["verdict"] for v in wra.values())),
          atr_in and all(v["verdict"] == "HOLDS" for v in wrp.values()) and
          not all(v["verdict"] == "HOLDS" for v in wra.values()) and rule and wide and brackets,
          (zp, wrp, za, wra, rule, wide, brackets))
    # ---- z4 the command end to end (planted world: picks from a tag run + the whole market)
    out = tmp / "out"
    with redirect_stdout(io.StringIO()):
        rc_tag = S.main(["tag", "--data", str(w["data"]), "--features", str(w["panel"]), "--out", str(out)])
    a = type("A", (), {"frozen": None, "out": str(out), "features": str(w["panel"]), "picks_only": False,
                       "root": str(w["root"]), "stage_e_any": False, "data": str(w["data"])})()
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = S.cmd_zones(a, data=FakeZoneLive(w))
    zrun, zdoc = S.load_zones(out)
    files = all((zrun / f).is_file() for f in ("ZONES.md", "SETUP_ZONES.json", "PINE_ZONE_CODE.txt",
                                              "zone_finalists.csv", "walk_forward.csv", "market_zone_trades.parquet"))
    code = (zrun / "PINE_ZONE_CODE.txt").read_text().strip()
    bad = json.loads((zrun / "SETUP_ZONES.json").read_text())
    bad["setups"]["S1"]["picks"]["zone"] = "ATRP:3:3"
    (zrun / "SETUP_ZONES.json").write_text(json.dumps(bad))
    try:
        S.load_zones(out)
        tamper = False
    except ValueError:
        tamper = True
    (zrun / "SETUP_ZONES.json").write_text(json.dumps(zdoc, indent=1))
    MT = pd.read_parquet(zrun / "market_zone_trades.parquet")
    check("z4 the zones command: the tag run's picks and the whole market (%d trades) searched, ZONES.md, "
          "SETUP_ZONES.json (hash-checked: an edited zone is refused), the finalists, the walk-forward and the Pine "
          "code '%s...'" % (len(MT), code[:40]),
          rc_tag == 0 and rc == 0 and files and tamper and code.startswith("BMSZ1|S1=") and code.count("|") == 7 and
          "ZONES WRITTEN" in buf.getvalue() and len(MT) > 300 and np.isfinite(MT["chk"]).all() and
          "WARNING" not in zdoc["atr_check"] and "= the simple ATR14" in zdoc["atr_check"],
          (rc_tag, rc, files, tamper, code, buf.getvalue()[-300:]))
    # ---- z5 the nightly scan with zones: IN / OUT at the close before the entry, in the ledger, the forward record,
    #      the page and tradelab's wording
    zd = json.loads(json.dumps(zdoc))
    for sid in zd["setups"]:
        zd["setups"][sid]["picks"] = {"zone": "RET20:0:1", "text": S.zone_text(S.zone_parse("RET20:0:1")),
                                      "out_of_sample": {"D": {"verdict": "NOT SHOWN"}, "ENS": {"verdict": "NOT SHOWN"}}}
    zd.pop("sha256")
    zd["sha256"] = S.zones_hash(zd)
    zr2 = S.new_run_dir(out / "ZONES", "ZONES")
    (zr2 / S.ZONES_FILE).write_text(json.dumps(zd, indent=1))
    real = S.LiveData
    fz = FakeZoneLive(w)
    S.LiveData = lambda root, any_=False, panel="panel_live": fz
    try:
        d = str(pd.Timestamp(w["cal"][30]).date())
        with redirect_stdout(io.StringIO()):
            r1 = S.main(["scan", "--root", str(w["root"]), "--out", str(out), "--date", d])
    finally:
        S.LiveData = real
    Sx = pd.read_csv(out / "scan" / ("scan_%s.csv" % d.replace("-", "")), dtype={"trade_id": str})
    act = Sx[Sx["status"].isin(["FIRES", "ARMED", "ENTERED"])]
    bars = fz.ohlcv(sorted(act["symbol"].unique()))
    Mz = S.market_dims(fz.index_closes(dict(S.ZONE_INDEX)))
    hand = []
    for r in act.itertuples(index=False):
        dd, o, h, lo, c, v = bars[r.symbol]
        z = S.zone_buckets(S.zone_values(dd, o, h, lo, c, v, Mz))
        j = (int(np.searchsorted(dd, np.datetime64(r.entry_date, "D"))) - 1 if r.status == "ENTERED" else
             int(np.flatnonzero(dd == np.datetime64(d, "D"))[0]))
        hand.append("IN" if 0 <= z["RET20"][j] <= 1 else "OUT")
    rec = [json.loads(x) for x in (out / "scan" / "setup_ledger.jsonl").read_text().splitlines()][-1]
    page = (out / "scan" / ("SCAN_%s.md" % d.replace("-", ""))).read_text(encoding="utf-8")
    try:
        import tl_setups as SU
        words = [SU.scan_words(r) for r in act.to_dict("records")]
        words_ok = all(("in its zone" in wd) == (r["zone"] == "IN") and ("outside its zone" in wd) ==
                       (r["zone"] == "OUT") for wd, r in zip(words, act.to_dict("records")))
    except ImportError:
        words_ok = False
    check("z5 the scan with zones: every FIRES / ARMED / ENTERED row IN or OUT exactly as the zone at the close before "
          "its entry, by hand (%d rows, %d IN); the ledger keeps each named entry's zone and the zones file's hash; "
          "the page says IN / OUT; tradelab's watch page words it ('in its zone' / 'outside its zone')" % (
              len(act), sum(x == "IN" for x in hand)),
          r1 == 0 and len(act) > 0 and list(act["zone"]) == hand and 0 < sum(x == "IN" for x in hand) < len(hand) and
          rec.get("zones_sha256") == zd["sha256"] and all("zone" in x for x in rec["named"]) and "| zone |" in page
          and words_ok, (r1, list(act["zone"]), hand, rec.get("zones_sha256"), words_ok))
    # ---- z6 a zone problem (an index file missing) never stops the nightly scan: rows without a zone, said in the log
    class Broken(FakeZoneLive):
        def index_closes(self, names):
            raise ValueError("INDIAVIX daily bars are not in the cache")
    fb = Broken(w)
    S.LiveData = lambda root, any_=False, panel="panel_live": fb
    try:
        d2 = str(pd.Timestamp(w["cal"][31]).date())
        buf = io.StringIO()
        with redirect_stdout(buf):
            r2 = S.main(["scan", "--root", str(w["root"]), "--out", str(out), "--date", d2])
    finally:
        S.LiveData = real
    S2 = pd.read_csv(out / "scan" / ("scan_%s.csv" % d2.replace("-", "")), dtype={"trade_id": str})
    check("z6 a zone problem (an index file missing) never stops the nightly scan: the evening is scanned, its rows "
          "have no zone and the log says why",
          r2 == 0 and S2["zone"].isna().all() and "zones not applied" in buf.getvalue() and
          (out / "scan" / ("SCAN_%s.md" % d2.replace("-", ""))).is_file(), (r2, buf.getvalue()[-300:]))
    # ---- p1 the Pine mirror's features = production's features_daily on the same bars
    FX = _fx()
    pairs = {"d_mdi14": "D_mdi14", "d_mdi14_diff5": "D_mdi14_diff5", "d_ema20_angle_deg": "D_ema20_angle_deg",
             "d_bb_bw_20": "D_bb_bw_20", "d_bb_pctb_20": "D_bb_pctB_20", "w_ret_13w": "W_ret_13w",
             "d_wq_16": "D_WQ_16", "d_wq_40": "D_WQ_40", "d_wq_44": "D_WQ_44", "d_atr_pct": "D_atr_pct",
             "RSI14": "D_rsi14"}
    worst, nan_ok, n_cmp, mk_ok, tn_ok, n_marks, n_tn = 0.0, True, 0, True, True, 0, 0
    if FX is not None:
        for seed in (1, 2, 3):
            dates, o, h, lo, c, v = _syn_stock(seed)
            X = FX.compute_daily_indicators(pd.DataFrame({"timestamp": dates, "open": o, "high": h, "low": lo,
                                                          "close": c, "volume": v}))
            days = ((dates.to_numpy().astype("datetime64[D]") - np.datetime64("1970-01-01")).astype(int)).tolist()
            M = PM.features(days, list(o), list(h), list(lo), list(c), list(v))
            for a_, b_ in pairs.items():
                x, y = M[a_], X[b_].to_numpy(float)
                nan_ok &= np.array_equal(np.isnan(x), np.isnan(y))
                worst = max(worst, float(np.nanmax(np.abs(x - y) / np.maximum(1, np.abs(y)))))
                n_cmp += int(np.isfinite(y).sum())
            # p2 the marks: the mirror on its own features = market_entries on production's (panel rows from 312)
            have = np.arange(len(c)) >= PM.WARMUP
            F = {}
            for f in PM.FEATS + ("d_atr_pct",):
                vv = np.where(have, X[pairs[f]].to_numpy(float), np.nan)
                F[f] = vv
                F[f + "_change"] = np.concatenate([[np.nan], vv[1:] - vv[:-1]])
            ent = S.market_entries(dates.to_numpy().astype("datetime64[D]"), o, c, F, S.atr_simple(h, lo, c), conds,
                                   have)
            mk = PM.marks(M, conds, list(o), list(c))
            mk_ok &= all(list(ent[s_]) == mk[s_] for s_ in conds)
            n_marks += sum(len(x) for x in mk.values())
            # tonight at every cut: FIRES -> marked the next session; ARMED -> marked iff the next open met the gap
            for t in range(PM.WARMUP + 2, len(c) - 1, 7):
                Mt = {k: x[:t] for k, x in M.items()}
                tn = PM.tonight(Mt, conds, list(o[:t]), list(c[:t]))
                for s_ in conds:
                    nxt = t in mk[s_]
                    if tn[s_] == "FIRES":
                        tn_ok &= nxt
                    elif tn[s_] == "ARMED":
                        tn_ok &= nxt == bool(o[t] < c[t - 1])
                    else:
                        tn_ok &= not nxt
                    n_tn += 1
    check("p1 the Pine's features (its bar-by-bar mirror) = production's features_daily on 3 stocks of 900 sessions: "
          "-DI 14 and its 5-day change, EMA20 angle, Bollinger width and %%b, the 13-week return of the last week, "
          "WorldQuant 16 / 40 / 44, ATR %%, RSI (%d values; largest relative difference %.1e)" % (n_cmp, worst),
          FX is not None and nan_ok and worst < 1e-9,
          "features_daily not importable: run the self-test after env_tradelab.bat (bigmove_deploy on PYTHONPATH)"
          if FX is None else (nan_ok, worst))
    check("p2 the Pine's marks = the whole-market engine on production's features (%d marks: the first qualifying open "
          "of every pseudo-pick past the 312-session warm-up); its next-open table = the next session's marks at %d "
          "cuts (FIRES -> marked; ARMED -> marked exactly when the open was below the close)" % (n_marks, n_tn),
          FX is not None and mk_ok and tn_ok and n_marks > 100, (mk_ok, tn_ok, n_marks))
    # ---- p3 the Pine file: its setups, dimensions, features and warm-up = the freeze, ZONE_DIMS and the mirror
    pine = (HERE.parent / "BigMove_Setups.pine").read_text(encoding="utf-8")
    line = lambda k: next(x for x in pine.splitlines() if x.startswith(k + " = ")).split(" = ", 1)[1].strip('"')
    want_s = "|".join("%s:%s" % (s_["id"], ",".join("%s%s%s" % (f, op, ("%g" % v)) for f, op, v in s_["conds"]))
                      for s_ in doc["setups"])
    want_d = "|".join("%s:%s" % (d_[0], "#%d" % len(d_[3]) if d_[2] is None else ",".join(repr(float(e)) if
                      float(e) != int(e) else "%g" % e for e in d_[2])) for d_ in S.ZONE_DIMS)
    lint = "not linted (pynescript and the playbook's pine_lint are not installed here)"
    lint_ok = True
    try:
        sys.path.insert(0, str(HERE.parent.parent / "playbook" / "tests"))
        import pine_lint as PL
        import pynescript  # noqa: F401
        IK = PL.INPUT_KW
        PL.NS |= {"request", "ta", "math", "str", "array"}
        PL.FUNCS.update({
            "indicator": {"title", "shorttitle", "overlay", "max_labels_count", "max_bars_back"},
            "input.time": IK, "input.text_area": IK, "input.string": IK | {"options"}, "input.bool": IK,
            "timestamp": set(), "math.floor": set(), "math.round": set(), "math.sqrt": set(), "math.atan": set(),
            "math.todegrees": set(), "array.insert": set(), "array.indexof": set(), "array.set": set(),
            "array.get": set(), "array.push": set(), "array.size": set(), "str.endswith": set(),
            "str.format": set(), "request.security": {"symbol", "timeframe", "expression", "gaps", "lookahead"},
            "ta.sma": {"source", "length"}})
        errs = PL.lint(pine)
        lint, lint_ok = ("linted: clean" if not errs else "lint: " + "; ".join(errs[:5])), not errs
    except ImportError:
        pass
    check("p3 BigMove_Setups.pine: its SETUPS line = FROZEN_SETUPS.json, its DIMS line = ZONE_DIMS, its features = "
          "the mirror's, warm-up 312, zone code tag %s; %s" % (S.PINE_CODE_TAG, lint),
          line("SETUPS") == want_s and line("DIMS") == want_d and line("FEATS") == ",".join(PM.FEATS) and
          line("WARMUP") == "312" and '"BMSZ1|S1=|S2=|S3=|C1=|C2=|C3=|N1="' in pine and lint_ok,
          (line("SETUPS") == want_s, line("DIMS"), want_d, lint))


def main():
    t0 = time.time()
    print("%s self-test" % S.VERSION)
    t_hand()
    t_space()
    t_worlds()
    t_confluence()
    t_build()
    t_v06()
    t_v07()
    t_v08()
    print("%d checks, %d failed (%.0f s)" % (COUNT[0], len(FAILS), time.time() - t0))
    print("VERIFIED (%s)" % S.VERSION if not FAILS else "NOT VERIFIED")
    return 0 if not FAILS else 1


if __name__ == "__main__":
    sys.exit(main())
