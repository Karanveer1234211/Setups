# setuplab v0.8 - entry setups for the model's picks vs the model's D1 entry, on the same trades

Built 7-8 Nov 2026. Files: `setuplab.py`, `FROZEN_SETUPS.json`, `BigMove_Setups.pine`, `features_final.txt`, `tests\test_setuplab.py` and `tests\pine_mirror.py`.
Reads the watchlist, the feature panel, the paper ledger and the cache (read only); writes only under `--out`.

## v0.8 (8 Nov) - each setup's zone, the whole market, and the setups on any TradingView chart

**Zones.** `zones` searches, for each frozen setup, the environment it does best in - on our picks (D and ENS, each
setup's primary exit) and on the whole market (every stock-day in the panel as a pseudo-pick, from 2020, held 5
sessions). Every measure is read at the close before the entry (the close the setup's own conditions are read at), and
every one can be computed on TradingView too, so the chart and the nightly scan apply the same filter:

| measure | what | buckets |
|---|---|---|
| ATRP | ATR14 % of the close | <2 / 2-3 / 3-4.5 / >=4.5 |
| ATRX | ATR14 % / its mean of the last 50 sessions | <0.85 / 0.85-1.15 / >=1.15 |
| TREND | close vs EMA50 and EMA200 | below both / between / above both |
| RET20 | 20-session return % | <-10 / -10 to 0 / 0 to 10 / >=10 |
| RSI14 | RSI 14 | <30 / 30-50 / 50-70 / >=70 |
| DD52 | % from the highest close of the last 252 sessions | <-30 / -30 to -15 / -15 to -5 / >=-5 |
| RVOL | volume / mean volume of the 20 sessions before | <0.7 / 0.7-1.5 / >=1.5 |
| RS20 | 20-session return minus Smallcap 250's (pts) | <-5 / -5 to 5 / >=5 |
| IDX | NIFTY 50, Midcap 150, Smallcap 250 closing at or above their 50-session mean (how many) | 0 / 1 / 2 / 3 |
| VIXP | India VIX percentile in its last 250 sessions | <33 / 33-67 / >=67 |
| VIX5 | India VIX 5-session change % | <-10 / -10 to 10 / >=10 |
| NIFTY20 | NIFTY 50 20-session return % | <-3 / -3 to 3 / >=3 |

A zone is one range of one measure (e.g. ATRP 3 and above) or two ranges of two measures: 2,990 candidates per setup.
**The rule** (declared before any zone result; in the code and in every SETUP_ZONES.json): a zone must keep 40 trades a
year in each population; it QUALIFIES when, in every population, inside minus outside (net % per trade) has a 95%
interval above 0 and the check - picks: the lift over the model's D1 entry on the same picks; whole market: the excess
over buying every stock at the same open - has a 95% interval above 0; the winner is the qualifying zone with the
highest strict lower bound of net per trade (mean - 3.29 bootstrap standard deviations) in its weakest population; none
qualifies = no zone.

**Luck.** Plain 95% per candidate (Karan's choice): about 1 in 20 candidates passes by chance. So the same search is
replayed year by year, 2022-2026: choose with the trades that had exited before 1 January, judge inside vs outside on
that year. The verdict is HOLDS (inside beat outside out of sample, 95%), NOT SHOWN, or WORSE. A zone that does not
HOLD in both engines is noise until the forward record says otherwise.

    call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
    cd /d C:\Users\karanvsi\PyCharmMiscProject\setuplab
    python setuplab.py --selftest
    python setuplab.py zones --root %CACHE_DAILY_ROOT% --features %CACHE_DAILY_ROOT%\panel_oc\panel.parquet --data C:\QuantData\setuplab\WL_R1_10 --out C:\QuantData\setuplab

Expected: `61 checks, 0 failed` / `VERIFIED (setuplab v0.8)` (it needs tradelab and bigmove_deploy on PYTHONPATH -
env_tradelab.bat or env_playbook.bat: it compares the chart's formulas with production's features_daily.py). `zones`
needs the TAGS run (`tag`, v0.7) in the same `--out`; `--picks-only` skips the whole market. With `--data` it first
checks S1's ATR: pick_meta's `s_atr14` is a SIMPLE 14-session ATR / close (the label contract), not the panel's Wilder
`d_atr_pct` (TAGS.md on your data: 3 of 15,819 agree), so the whole market, the chart and the scan's fallback compute
the simple one from the bars; the line `ATR check: N of M picks ...` must say no WARNING. It ends `ZONES WRITTEN`
and writes `C:\QuantData\setuplab\ZONES\ZONES_<date>_<nnn>\`:

- `ZONES.md` - per setup: the setup alone vs inside vs outside its zone (trades a year, net % per trade [95%], Rs a
  year at Rs 1 L a trade, lift or excess [95%]), the year-by-year replay, and the verdict.
- `SETUP_ZONES.json` (hash-checked; the nightly scan reads the newest run), `PINE_ZONE_CODE.txt` (one line for the
  TradingView indicator), `zone_finalists.csv`, `walk_forward.csv`, `picks_zone_trades.parquet`,
  `market_zone_trades.parquet`, `outputs.sha256`.

**The nightly scan** (unchanged command) marks every FIRES / ARMED / ENTERED row IN or OUT of its setup's picks zone;
the ledger keeps it with the entry (ON TIME), the forward record and `SCAN_<date>.md` count the entries in the zone
separately, and tradelab's watch page says "(in its zone)" / "(outside its zone)". A zone problem (an index file
missing) never stops the scan: the rows go without a zone and the log says why.

**BigMove_Setups.pine** - the seven setups on any daily NSE chart, without the model. TradingView: Pine Editor > New
indicator > replace everything with the file > Save > Add to chart. Settings > Inputs > Zone code: paste the line of
`PINE_ZONE_CODE.txt` (once; empty = no zones). Every session is a possible signal day; a label marks the first open in
its five watch days where a setup's conditions hold (setuplab's rule): green = inside the setup's whole-market zone,
orange = outside, grey = the setup has no zone. The table (top right) says what fires at the NEXT open (FIRES; ARMED =
buy only if the open is below tonight's close) and each setup's last mark.

- The features are recomputed from TradingView's bars with production's formulas; `tests\pine_mirror.py` is the Pine
  bar by bar, and the self-test finds it equal to production's `features_daily.py` (largest relative difference about
  1e-10) and its marks equal to the whole-market engine.
- Limits: on a stock the model did not pick, a mark has only the whole-market study behind it. TradingView's bars are
  split-adjusted only, the cache is Kite's: where the data differ, a value (and a mark) can differ. WorldQuant 16 can
  move by one rank step where two 5-day covariances tie exactly (a price stuck for days). No marks in a stock's first
  312 sessions (production's panel starts there). Use it after the close.
- Not compiled by TradingView here (no compiler): parsed and linted (pynescript). If TradingView shows an error, send
  the message and the line.

## v0.7 (8 Nov) - the frozen setups: freeze file, tags on every past pick, the nightly scan

**The freeze.** `FROZEN_SETUPS.json` (beside `setuplab.py`; sha256 `483f1539324f3ae5...`; the tool never writes it
and refuses a changed copy) holds Karan's seven setups, frozen 8 Nov 2026 09:38 IST before any forward setup data was
read. Every setup is watched on D and ENS ranks 1-10, D1-D5 after the pick, bought at the first open where all its
conditions hold, both exits kept; the primary exit decides.

| id | setup | origin | primary exit |
|---|---|---|---|
| S1 | bad week + WQ-16 rising + 1-ATR dip | declared leaderboard #1 | 5th close |
| S2 | bad week + minus-DI 5-day change rising + gap down | declared #2 | 5th close |
| S3 | bad week + WQ-40 rising + 3% dip | declared #3 | 5th close |
| C1 | bad week + minus-DI rising + 2% dip | chosen after looking (capital view #1) | 5th close |
| C2 | B + 3% dip | chosen after looking (capital view #2) | 5th close |
| C3 | A+C, no dip | chosen after looking (capital view #5) | 5th close |
| N1 | below the lower Bollinger band + 2% dip (any weekday) | chosen after looking (non-Tuesday) | fresh |

"Bad week" = the 13-week return fell (the completed week, posted on the week's first session), so S1-S3 and C1-C3 buy
on the week's second session (usually Tuesday). The file also declares the forward judgment: only entries the nightly
scan recorded ON TIME count; month 6 (entries through 2027-03-31) is a first read; month 12 (through 2027-09-30)
decides - CONFIRMED when, in both engines at the primary exit, net per trade and net minus the D1 entry on the same
picks each have a 95% interval above 0 (fewer than 30 settled trades: TOO FEW). Real money only after that and the money
view with the skipped picks counted.

    call C:\Users\karanvsi\PyCharmMiscProject\playbook\env_playbook.bat
    cd /d C:\Users\karanvsi\PyCharmMiscProject\setuplab
    python setuplab.py --selftest
    python setuplab.py frozen
    python setuplab.py tag --data C:\QuantData\setuplab\WL_R1_10 --features %CACHE_DAILY_ROOT%\panel_oc\panel.parquet --out C:\QuantData\setuplab

Expected: `52 checks, 0 failed` / `VERIFIED (setuplab v0.7)` (start with `env_playbook.bat` or `env_tradelab.bat`:
check f14 reads the test's tags and scan with tradelab's `tl_setups`); `FROZEN FILE OK`; the tag run ends `TAGS RECONCILED`
(the same watchlist and panel as FINAL_001 must give FINAL_001's trades and nets - any other answer means stop and
send `TAGS.md`).

- **`tag`** writes `C:\QuantData\setuplab\TAGS\TAGS_<date>_<nnn>\`: `setup_tags.parquet/.csv` (one row per pick:
  `setups` such as `S2@D3 C1@D3`, then per setup `su_<ID>_day / _entry_date / _entry / _net_d5 / _net_fresh /
  _status`, and `d1_net_d5 / d1_net_fresh` = the model's D1 trade on the same pick), `setup_trades.parquet/.csv`
  (one row per entered setup), `TAGS.md` (every setup against FINAL_001; the ATR check), `TAGS.json`,
  `outputs.sha256`. tradelab and playbook read the newest TAGS run (hash-checked) for their tags.
- **`scan`** (every night, step 3 of `run_tonight.bat`, in tradelab's environment): the paper ledger's picks of the
  last five sessions (D and ENS, ranks 1-10) against every frozen setup, with tonight's bars and the nightly panel
  (`panel_live`). It writes `C:\QuantData\setuplab\scan\`: `SCAN_<date>.md` (what to buy at the next open: FIRES =
  buy at the open; ARMED = buy at the open only if it opens below tonight's close - the gap-down setup S2; positions
  already entered; counts; the forward record so far), `scan_<date>.csv` (every pick x setup), `tv_<date>.txt`
  (TradingView: Watchlist menu > Import list - one section per setup), `setup_ledger.jsonl` (hash-chained; ON TIME
  when written before 09:00 IST of the next session, else LATE - counts for nothing), `forward_trades.csv`.
  `--all-missing` scans every evening since 6 Nov not yet scanned (late ones marked LATE). An evening the nightly panel
  has not reached is refused and retried the next night.
- **ATR for S1 (live picks):** pick_meta's card (`PM_cards_<date>.csv`, column `s_atr14`) when it has one, else the
  panel's `d_atr_pct / 100`; `TAGS.md` checks on history whether the two agree.
- **Same rules everywhere:** tag and scan use the backtest's own code (conditions, first qualifying open, exits). The
  self-test runs the scan evening by evening on a planted world and finds every backtest entry named the evening before
  with the same watch day, no false FIRES, and the forward record equal to the backtest's trades; and tradelab's
  reader (`tl_setups`) reads those very tags and scan files the same way (f14).

## v0.6 (7 Nov) - the final run: both engines, ranks 1-10, 53 features, one declared leaderboard

    call C:\Users\karanvsi\PyCharmMiscProject\playbook\env_playbook.bat
    cd /d C:\Users\karanvsi\PyCharmMiscProject\setuplab
    set ABC=<the folder holding BigMove_ABC_Compact's data\ and behaviour_features.parquet>
    python setuplab.py --selftest
    python setuplab.py run --data C:\QuantData\setuplab\WL_R1_10 --features %CACHE_DAILY_ROOT%\panel_oc\panel.parquet --columns-file features_final.txt --engine D,ENS --confluence --check %ABC%\data\watchlist.parquet --out C:\QuantData\setuplab\FINAL_001

Expected then (v0.6): `38 checks, 0 failed` / `VERIFIED (setuplab v0.6)`. The run ends with `DONE`.

- **One command, both engines:** `--engine D,ENS` runs each engine into `D\` and `ENS\`, then a leaderboard across
  both. The confluence pool is the UNION of the engines' pools (every A/B/C label, plus each engine's top 10 pairs by
  lift and by net), so both engines test exactly the same combinations.
- **Features:** `--columns-file features_final.txt` = ChatGPT's 10 + the WHY study's top 50 of engine D (raw levels,
  codes and cross-sectional copies left out) = 53. The panel is read 8 columns at a time, only the picks' stocks.
  The five A/B/C features are required (the run refuses without them); any other missing feature is skipped and listed
  in `RUN.json` and `features_tested.txt`.
- **Resume:** rerun the SAME command after a crash or a closed window: finished stages (`stage1.done`,
  `confluence.done`) are reused. Different settings in the same `--out` folder are refused (use a new folder).
- **New context confluence:** TOP3 (the model's ranks 1-3, the ones traded today).
- **`--check`** compares the watchlist's ranks 1-3 with ChatGPT's file; the result goes to `RUN.json`.

### The leaderboard rule (declared before the run; applied by the code)
Every setup of the run - controls, price-only rules, the six A/B/C labels (alone, with confirmations, with dips), every
feature and pair, the dip exploration, every setup x confluence and every confluence alone - is counted once by its
conditions, and only if tested in every engine. A setup is ELIGIBLE (for one exit) when in EVERY engine:
1. at least 300 trades;
2. the lift over the model's D1 entry on its own trades has a 95% interval above 0;
3. when it has an indicator-free twin (the same dip / confluence without the indicators), the indicators add with a 95%
   interval above 0;
4. trades in at least 6 signal years, net per trade above 0 in all but at most one;
5. net per trade above 0 in both halves of the period;
6. a context filter (state, market, NIFTY, VIX, breadth, volatility flag, rank - conditions on the pick's snapshot)
   must keep better trades than it drops (the same setup's trades with the filter minus those without it), passing a
   false discovery rate of 5% over EVERY filter test of the run (Benjamini-Hochberg).

SCORE = the lower end of the 95% interval of net per trade in the worst engine (money per trade, marked down for small
samples and engine disagreement). Main list: eligible under BOTH exits (score = the lower of the two); each exit's own
list follows. Top 3 = the best scores skipping VERSIONS of a setup already chosen: a rule that only adds or removes
conditions or context filters (one rule's conditions contain the other's), or shares 70%+ of the trades.

Why rule 6 and the versions rule: in the planted test world the first leaderboard filled the top 3 with ONE setup
under three coin-flip context filters, and a later one put a lucky filter at #1 of the fresh list (permutation p
0.0005 - a fluke among ~1,000 filter tests). A filter only chooses WHICH trades, so it is judged on the trades it keeps
vs drops, and with thousands of filter tests per run the luck has to be counted. On planted worlds the rule keeps a
real +0.5% filter effect 89% of the time (as often as a plain 95% test) and lets through 0-0.3% of coin-flip filters
(plain 95%: 1.4-3.8%).

### Outputs (in `--out`)
`LEADERBOARD.md` (the rule; each list's top 3 with every engine x exit: trades, per year, fill %, net [95%], D1 on
the same trades, lift [95%], indicators add [95%], years, halves, open positions avg / max; ranks 1-3 vs 4-10,
bearish vs other states, each year; the context filter's keep-vs-drop test; the versions skipped; the 20 best
eligible before the versions rule; where A, B, C, A+B, A+C, B+C, their 2% dips and the earlier favourites stand);
`FREEZE_CANDIDATES.json` (the same, machine-readable: conditions, stats, filter, versions, ledger files);
`FINALISTS\<list>_<rank>__<engine>.csv` (every trade of each chosen setup, both exits, next to the D1 entry on the
same trade); `leaderboard.csv` / `leaderboard_both_exits.csv` (every setup, eligible or not, with the reasons);
`RUN.json`, `run.log`, `features_tested.txt`; per engine the v0.5 reports (`D\REPORT.md`, `D\CONFLUENCE.md`, ...).

### Verified (v0.6)
38 checks (v0.5's 30 + the bootstrap count matrix = the index bootstrap; stats = the paired test; engine split; chunked
read = in-memory join; the eligibility rule on a crafted table; the versions rule; a two-engine run with a missing
column; resume and refusal; a planted context filter found and a coin-flip one rejected; nothing passes in a world
without filters; Benjamini-Hochberg on a textbook example). The 60 delivered ledgers still reproduce exactly
(largest difference 7.11e-15 pp). A synthetic world at your scale (35,000 picks of ranks 1-10 in two engines, 1,200
stocks, the 53 features in a 2.3-million-row panel): the whole run in 8.5 minutes, peak memory 1.6 GB, on 2 CPUs. The
real run takes longer: about 45 setups in the confluence pool instead of that world's 7, and a bigger panel to read.

## What it does
- Re-implements the A/B/C backtester's rules (backtest.pyz) vectorised: first qualifying open D1..D5, conditions
  read at the previous session, exits original_d5 or fresh (5 sessions), 0.35 pp cost. **Reproduces all 60
  delivered ledgers exactly** (status, entry day, net; largest difference 7e-15 pp).
- Your comparison: each setup's own filled trades vs the model's D1 entry on exactly those trade ids, with 95%
  circular block-bootstrap intervals over signal days.
- Controls on the same ids (no indicators): blind D2 / D3, price dips (DIP_0..DIP_5 % under the D1 open, DIPATR_x
  ATR), bounce markers (down, then a green day / an up close), Tuesday entries (TUE, TUE_DIP_2 - the weekly
  feature changes on Mondays, so its setups can only fire on a Tuesday open).
- The whole pair space of the features (every pair of change directions = A/B/C's family), B / A+B with dips, and
  an exploration of what adds most on top of a 2% dip.

## Install and run (cmd)
Put the two files in `C:\Users\karanvsi\PyCharmMiscProject\setuplab\` (tests in `setuplab\tests\`). Set `ABC` to
the folder where you extracted BigMove_ABC_Compact (it holds `data\` and `behaviour_features.parquet`).

    cd /d C:\Users\karanvsi\PyCharmMiscProject\setuplab
    set ABC=C:\path\to\BigMove_ABC_Compact
    python setuplab.py --selftest
    python setuplab.py reproduce --data %ABC%\data --features %ABC%\behaviour_features.parquet --ledgers %ABC%\combination_runs\<hash>
    python setuplab.py run --data %ABC%\data --features %ABC%\behaviour_features.parquet --out C:\QuantData\setuplab\RUN_001

Expected (v0.5): `28 checks, 0 failed` / `VERIFIED (setuplab v0.5)`; reproduce prints `REPRODUCED`; run takes about
a minute. Needs numpy, pandas, pyarrow (scipy not needed).

**Model features (after the engine D rebuild):** point `--features` at any parquet with symbol + timestamp (or
date) and feature columns, and list the columns to test (big panels are read column by column):

    python setuplab.py run --data %ABC%\data --features %CACHE_DAILY_ROOT%\panel\panel.parquet --columns f1,f2,f3 --out C:\QuantData\setuplab\RUN_002

A missing `<feature>_change` column is computed as the change from the symbol's previous row.

## Outputs
`REPORT.md`; `vs_D1.csv` (every setup vs D1, both exits, with coverage and its percentile in the pair space);
`vs_price_controls.csv` (A/B/C and the combos vs every control on the same ids); `by_year.csv`;
`explore_on_dip.csv`; `by_state.csv` (B, A+B, the combos and the 2% dip by the pick's stock state at the signal, vs D1 and vs the dip); `ledgers\` (every non-space setup's trade ledger).

## v0.5 (7 Nov) - every A/B/C label treated the same
v0.2-v0.4 paired the dips and the confluences with B and A+B only. Now all six distinct labels (A, B, C, A+B, A+C =
A+B+C, B+C) get DIP_1 / DIP_2 / DIP_3 / DIPATR_1, the by-year / by-state / by-rank views and a place in the confluence
pool; the report opens the comparison with a table of every label x entry (net, lift over D1, adds over the same dip
alone). The extra B-only control column is gone. Report headers name the engine and ranks (v0.4.1).

## v0.4 (7 Nov) - ranks 1-10, both engines
ChatGPT's watchlist holds only ranks 1-3. `build` makes the same file for any ranks and both engines from pick_meta +
the daily cache (through playbook's reader, READ ONLY) + tradelab's export (status, net, s_atr14, pre_* context):

    call C:\Users\karanvsi\PyCharmMiscProject\playbook\env_playbook.bat
    cd /d C:\Users\karanvsi\PyCharmMiscProject\setuplab
    python setuplab.py build --root %CACHE_DAILY_ROOT% --export C:\QuantData\tradelab\export\TLX_20261025_001 --out C:\QuantData\setuplab\WL_R1_10 --check %ABC%\data\watchlist.parquet

`--check` compares the built ranks 1-3 with ChatGPT's file (entry, closes, gaps): `BUILD CHECK MATCHED` = at least
99.5% identical. The build also compares every entry with the export's recorded entry. `run --ranks 4-10` (or any
range) filters ranks; with more than one rank the report gets a by-rank view (bands 1-3 / 4-10 and each rank) and
by_rank.csv. Verified on the fake production cache: 32,528 picks of ranks 1-10, entries = the export's on every pick,
ranks 1-3 identical to an independent reference, both engines replay.

## v0.3 (7 Nov) - top-N model features and logical confluences
- `--why <why_features.csv> --top 50`: tests the engine's top 50 features by the WHY surrogate's importance, skipping
  raw price levels / price-scaled values (SMA/EMA levels, ATR14/30, CPR, support/resistance, breakout levels, OBV,
  MACD), categorical codes, the weekday and combined flags; the list goes to `features_tested.txt`.
- The pair space is streamed (5,000 pairs x 2 exits in about 5 minutes, about 0.5 GB); only the picks' stocks are
  read from the panel.
- `--confluence`: setups x logical confluences, declared in the code before any run. Pool = B, A+B, the pair space's
  top 10 by lift and top 10 by net per trade (n >= 300, interval above 0), and NONE (the confluence alone). Price
  confluences: DIP1/2/3, DIPATR1, GREEN, UPCLOSE, GAPDOWN, GAPUP. Context at the signal: BEARSTATE, BULLSTATE,
  NIFTY above / below its MA50, market bullish / bearish, VIX low / high and weak breadth (median splits of the picks'
  own values), NOT_OVEREXT, VOL_ELEVATED. Every single confluence and every price x context pair. Each vs D1 and vs
  the confluence alone on the same ids, with the number of years net > 0. Writes CONFLUENCE.md, confluence.csv.
- Checks: 25 (snapshot fields, the feature picker, a planted world where the setup adds over a confluence alone).
  The streamed results equal v0.2's on every row; 60 ledgers still reproduced. Noise null: 3,120 pairs of pure
  noise features, none beat D1 with the interval above 0.

## v0.2 (7 Nov)
State-by-state view (report section + by_state.csv). The feature reader accepts a panel stored with symbol / date
as its index and zoned timestamps (checked: identical results to the plain file).

## Verified
21 checks: hand-computed trades (entry, gap, both exits, drawdown, zero changes, missing-data rules, dips, ATR dip,
Tuesday, bounce), and three planted worlds - a real setup is found and beats the dip control; in a fall-then-bounce
world noise setups beat D1 (the waiting trap) but NOT the dip control; in a random walk nothing beats D1.
Plus the 60-ledger reproduction on the real data.

## Read with care
Everything here is exploratory on the history the setups were found on (2020-2026, 2026 included). The combos and the
dip exploration were chosen after the first run. The forward paper ledger is the only clean test.
