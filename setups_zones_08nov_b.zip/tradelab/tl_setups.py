"""
tl_setups.py - tl_setups v1.0, the setups add-on for tradelab v1.3.1: the FROZEN entry setups (setuplab v0.7) in
tradelab's tools - the watch page, the trade journal, the backtester and the simulator.

It reads setuplab's outputs READ ONLY (nothing here computes a setup: one source of truth, setuplab's own rules):
  <SETUPLAB_OUT>\\TAGS\\TAGS_<date>_<nnn>\\setup_tags.parquet   every past pick: which frozen setups entered it, on which
                                                                watch day (D1..D5), at what price, both exits
                                                                (setuplab tag; checked against its outputs.sha256)
  <SETUPLAB_OUT>\\scan\\scan_<YYYYMMDD>.csv                     the nightly scan of the last five sessions' picks
  <SETUPLAB_OUT>\\scan\\setup_ledger.jsonl                      the scan's on-time record (for the watch page's ON TIME)
SETUPLAB_OUT comes from --setups or the environment variable SETUPLAB_OUT (env_tradelab.bat sets it). Neither given =
no setup tags (said once, never guessed).

A setup tag is known only on the setup's OWN entry day (its conditions are read at the close before it). So a tag
may describe a trade (a column, a breakdown labelled hindsight) or open a trade at that entry ({"setup": "S2"} entry
legs in a strategy) - it may never decide a D1 entry: filters and rules that name a tag are refused.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from tl_common import TLError

SETUPS_VERSION = "tl_setups v1.1"
ENV = "SETUPLAB_OUT"
TAG_NAME = re.compile(r"\b(su_[A-Za-z0-9_]+|n_setups|setups)\b")
TAGS_FILE = "setup_tags.parquet"


def base_dir(cli: Optional[str] = None) -> Optional[Path]:
    """setuplab's output folder: --setups, else SETUPLAB_OUT, else None (no tags)."""
    v = cli if cli else os.environ.get(ENV, "")
    return Path(v) if v else None


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def latest_tags(base: Path) -> Path:
    runs = sorted((Path(base) / "TAGS").glob("TAGS_*"))
    runs = [r for r in runs if (r / TAGS_FILE).is_file()]
    if not runs:
        raise TLError(f"no setup tags under {Path(base) / 'TAGS'} - run setuplab's tag command first "
                      f"(python setuplab.py tag --data ... --features ... --out {base})")
    return runs[-1]


def load_tags(base: Optional[Path], need: bool = False) -> Tuple[Optional[pd.DataFrame], dict]:
    """The newest tag run (setup_tags.parquet, hash-checked) and its TAGS.json. need=False: (None, why) when absent."""
    if base is None:
        if need:
            raise TLError(f"this needs the frozen setups' tags: pass --setups <setuplab output folder> or set {ENV} "
                          f"(env_tradelab.bat sets it)")
        return None, {"used": False, "why": f"no --setups and no {ENV}"}
    try:
        run = latest_tags(base)
    except TLError as e:
        if need:
            raise
        return None, {"used": False, "why": str(e)}
    p = run / TAGS_FILE
    rec = {}
    hf = run / "outputs.sha256"
    if hf.is_file():
        for ln in hf.read_text(encoding="utf-8").splitlines():
            parts = ln.split("  ", 1)
            if len(parts) == 2:
                rec[parts[1].strip()] = parts[0].strip()
    sha = _sha(p)
    if rec.get(TAGS_FILE) != sha:
        raise TLError(f"{p} does not match {hf} (recorded {str(rec.get(TAGS_FILE))[:16]}, file {sha[:16]}) - refusing")
    meta = {}
    if (run / "TAGS.json").is_file():
        meta = json.loads((run / "TAGS.json").read_text(encoding="utf-8"))
    T = pd.read_parquet(p)
    T["trade_id"] = T["trade_id"].astype(str)
    ids = [s["id"] for s in meta.get("setups", [])] or sorted({c[3:].rsplit("_", 1)[0] for c in T.columns
                                                                if c.startswith("su_") and c.endswith("_day")})
    info = {"used": True, "run": run.name, "folder": str(run), "sha256": sha, "frozen_sha256": meta.get("frozen_sha256"),
            "setups": ids, "names": {s["id"]: s.get("name", "") for s in meta.get("setups", [])},
            "primary_exit": {s["id"]: s.get("primary_exit", "original_d5") for s in meta.get("setups", [])},
            "signal_days": meta.get("signal_days"), "picks": int(len(T)), "tool": meta.get("version")}
    return T, info


def refuse_tag_names(texts: Sequence[str], where: str) -> None:
    """A filter or rule that names a setup tag would decide on later sessions' closes: refused with the way out."""
    for t in texts:
        if not t:
            continue
        m = TAG_NAME.search(str(t))
        if m:
            raise TLError(f"{where}: '{m.group(1)}' is a setup tag. A setup is known only on its own entry day (its "
                          f"conditions are read at the close before it), so a filter or rule cannot read it - it would "
                          f"look at sessions after the pick. To trade a setup, use an entry leg such as "
                          f"{{'name': 's2', 'setup': 'S2'}}.")


def setup_days(tags: Optional[pd.DataFrame], ids: Sequence[str]) -> Dict[str, Dict[str, int]]:
    """trade_id -> {setup id: watch day it entered} (only the setups that entered)."""
    out: Dict[str, Dict[str, int]] = {}
    if tags is None:
        return out
    for sid in ids:
        col = f"su_{sid}_day"
        if col not in tags.columns:
            continue
        g = tags[["trade_id", col]].dropna()
        for t, d in zip(g["trade_id"], g[col]):
            out.setdefault(str(t), {})[sid] = int(d)
    return out


def tag_columns(df: pd.DataFrame, tags: Optional[pd.DataFrame], ids: Sequence[str], primary: Optional[dict] = None,
                nets: bool = False) -> pd.DataFrame:
    """df (with trade_id) + setups (e.g. 'S2@D3 C1@D3'), n_setups, su_<ID>_day; nets=True also su_<ID>_net (net % at
    the setup's primary exit). Picks the tag run does not cover get blank tags and setups_tagged = False."""
    X = df.copy()
    if tags is None:
        return X
    keep = ["trade_id", "setups", "n_setups"] + [f"su_{s}_day" for s in ids if f"su_{s}_day" in tags.columns]
    J = tags[keep].copy()
    if nets:
        for s in ids:
            pe = (primary or {}).get(s, "original_d5")
            col = f"su_{s}_net_{'d5' if pe == 'original_d5' else 'fresh'}"
            if col in tags.columns:
                J[f"su_{s}_net"] = tags[col].to_numpy()
    J["setups_tagged"] = True
    drop = [c for c in J.columns if c != "trade_id" and c in X.columns]
    X = X.drop(columns=drop).merge(J, on="trade_id", how="left")
    X["setups_tagged"] = X["setups_tagged"].astype("boolean").fillna(False).astype(bool)
    X["setups"] = X["setups"].astype(object).where(X["setups"].notna(), "")
    X["n_setups"] = pd.to_numeric(X["n_setups"], errors="coerce").fillna(0).astype(int)
    return X


# ---------------------------------------------------------------------------------------------------- the nightly scan
def scan_path(base: Optional[Path], day) -> Optional[Path]:
    if base is None:
        return None
    return Path(base) / "scan" / f"scan_{pd.Timestamp(day):%Y%m%d}.csv"


def read_scan(base: Optional[Path], day) -> Tuple[Optional[pd.DataFrame], dict]:
    """The scan of one evening (setuplab scan) and whether its ledger record was on time."""
    p = scan_path(base, day)
    if p is None:
        return None, {"found": False, "why": f"no --setups and no {ENV}"}
    if not p.is_file():
        return None, {"found": False, "file": str(p), "why": "no setup scan for this evening (run_tonight.bat runs it "
                                                              "before the watch page)"}
    S = pd.read_csv(p, dtype={"trade_id": str})
    info = {"found": True, "file": str(p), "sha256": _sha(p), "rows": int(len(S)), "on_time": None}
    lp = Path(base) / "scan" / "setup_ledger.jsonl"
    if lp.is_file():
        d = f"{pd.Timestamp(day):%Y-%m-%d}"
        for ln in lp.read_text(encoding="utf-8").splitlines():
            try:
                r = json.loads(ln)
            except json.JSONDecodeError:
                continue
            if r.get("event") == "scan" and r.get("scan_date") == d:
                info.update({"on_time": bool(r.get("on_time")), "recorded_at": r.get("recorded_at"),
                             "frozen_sha256": r.get("frozen_sha256")})
                break
    return S, info


def int_text(x) -> str:
    """A watch day from a CSV cell (int, float or blank) as text: 3 / 3.0 -> '3', blank / NaN -> ''."""
    try:
        v = float(x)
    except (TypeError, ValueError):
        return ""
    return str(int(v)) if np.isfinite(v) else ""


def scan_words(r: dict) -> str:
    """One scan row in words for the watch page (v1.1: with its zone, when setuplab's zones file names one)."""
    st = str(r.get("status") or "")
    sid = str(r.get("setup") or "")
    z = str(r.get("zone") or "")
    zw = {"IN": " (in its zone)", "OUT": " (outside its zone)"}.get(z, "")
    if st == "FIRES":
        return f"{sid} buy at the open{zw}"
    if st == "ARMED":
        return f"{sid} buy at the open only if {r.get('rule_at_open') or 'the open meets its rule'}{zw}"
    if st == "ENTERED":
        try:
            px = f" at {float(r.get('entry')):.2f}"
        except (TypeError, ValueError):
            px = ""
        return f"{sid} entered D{int_text(r.get('entered_day'))}{px}{zw}"
    return ""


def pick_setups_text(S: Optional[pd.DataFrame], engine: str, rank: int, symbol: str, day) -> str:
    """The setups column of one of tonight's picks: what fires / is armed at the next open."""
    if S is None or S.empty:
        return ""
    d = f"{pd.Timestamp(day):%Y-%m-%d}"
    g = S[(S["engine"].astype(str) == str(engine)) & (pd.to_numeric(S["rank"], errors="coerce") == int(rank)) &
          (S["symbol"].astype(str) == str(symbol)) & (S["signal_day"].astype(str) == d) &
          (S["status"].isin(["FIRES", "ARMED"]))]
    return "; ".join(scan_words(r) for r in g.to_dict("records"))


def action_rows(S: Optional[pd.DataFrame]) -> List[dict]:
    """The scan's FIRES / ARMED / ENTERED rows (every pick of the last five sessions), for the watch page's section."""
    if S is None or S.empty:
        return []
    order = {"FIRES": 0, "ARMED": 1, "ENTERED": 2}
    g = S[S["status"].isin(list(order))].copy()
    g["_o"] = g["status"].map(order)
    g = g.sort_values(["_o", "setup", "engine", "rank"]).drop(columns="_o")
    return g.to_dict("records")
