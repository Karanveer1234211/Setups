@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" py -3 -m venv .venv
if errorlevel 1 goto done
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto done
".venv\Scripts\python.exe" backtest.pyz
:done
pause
