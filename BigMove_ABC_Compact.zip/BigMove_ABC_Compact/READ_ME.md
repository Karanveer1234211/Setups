# BigMove A/B/C combination tests

Extract this ZIP fully. On Windows, install Python 3.11 or newer, then double-click RUN.bat. The first launch installs dependencies (internet needed). Leave the window open. Completed strategy ledgers are saved and reused on restart. The bundled data is a fixed historical snapshot, not a live feed.

Mac/Linux: install requirements.txt with pip, then run `python backtest.pyz` from this folder. Optional state restriction: `python backtest.pyz --states S01,S09`. Check compilation without replay: `python backtest.pyz --compile-only`.

## Exact rules

All feature conditions use the previous completed trading session; rising/falling means the stored one-session change is strictly positive/negative. Zero does not qualify.

| Rule | Conditions, both required |
|---|---|
| A | BB width rising AND 13-week return falling |
| B | EMA20 angle falling AND 13-week return falling |
| C | EMA20 angle falling AND WQ44 rising |

Test A, B, C, A+B, A+C, B+C and A+B+C. Plus means AND on the same snapshot, not a chain across different days. Shared conditions are counted once; these are not independent votes.

Each runs with no additional confirmation and with each of three separate confirmations: opening gap > 0%; prior-close EMA20 angle > 0; prior-close minus-DI daily change < 0. Confirmations are tested one at a time, not all together. A falling EMA angle can still be positive. Minus-DI change below zero differs from its change falling.

Enter at the first qualifying open in sessions D1 through D5 after selection. Prior-close signals cannot use the eventual entry day's closing data. Opening-gap fills are theoretical: they do not model auction execution or an intraday confirmation delay.

Two exits: original selection D5, or fifth session inclusive of entry. This gives 7 x 4 x 2 = 56 strategies. Four controls enter blindly at D1 or D3 under each exit policy. No stop or target; flat 0.35 percentage-point round-trip cost. Engine default trade size is INR150,000; this is not a shared-capital, one-trade-per-day simulation.

## Reading results

Outputs are under combination_runs/<configuration hash>/:

- policy_overview.csv: consolidated, state, selection-year and state/year views of all eligible selections, fills, no entries, missing data, net return per fill and per eligible selection. Skips contribute zero only to the latter. Missing-data rows suppress that policy metric.
- same_pick_comparisons.csv: exact trade-ID intersections, grouped by all selections, state, signal year and state/year. Compares each strategy with blind controls, constituent singles and the same combination without confirmation. Returns and lift_pp are percentage points; win_pct is a percentage.
- Individual strategy .csv.gz ledgers: inspect dates, fills, exits and outcomes. scenarios.json records the 56 compiled configurations.

Never compare a strategy's per-fill return with a baseline on a different selection set. Matched tables show both policies on identical filled picks, but are retrospective conditional comparisons: baseline traders could not know which future picks would qualify. Read policy coverage alongside matched returns. Original-D5 policies differ in exposure duration; fresh-five policies differ in calendar dates. Neither comparison alone establishes causality.

Drawdown is peak-to-trough using entry and sampled closes, not intraday MAE and not portfolio maximum drawdown. Year is selection year. Small samples below 100 are flagged; that threshold does not establish statistical significance. These are exploratory tests on historical data, with no holdout validation or multiple-testing correction. Do not call the highest-ranked result proven.

The feature snapshot and core source files are fingerprinted. If they change, archive the old output folder before replaying. Existing behaviour_runs/RESULTS files, if present in your other installation, belong to earlier experiments, not this matrix.

Send back policy_overview.csv and same_pick_comparisons.csv first; retain the compressed ledgers for detailed investigation.

## Compact edition
Seven delivered files: RUN.bat, backtest.pyz, requirements.txt, READ_ME.md, behaviour_features.parquet and two data files inside data/. The pyz is a standard Python ZIP application containing readable Python source modules, not a compiled executable. No old app, old results or test fixtures are included. New results and the Python environment are created only when run.

Portfolio reports use INR600,000 starting cash and fixed INR150,000 lots; no leverage, rank priority, open entries before close exits, profits available the following session, full 0.35% roundtrip cost reserved for open positions. They permit more positions as cash grows. No settlement delays, whole-share rounding or intraday marks. Repeated nominations of the same stock are separate lots.

portfolio_comparison.csv compares each policy with D1 on the same evaluable selection universe (including no-entry selections); unknown rows are excluded from both. Actual fills differ due to filters and cash availability. portfolio_yearly.csv gives calendar-year equity returns, with partial first/last years. portfolio_daily_equity.csv.gz supports drawdown audit. All portfolio runs share a common start/end interval. Existing per-trade state/year reports remain.
