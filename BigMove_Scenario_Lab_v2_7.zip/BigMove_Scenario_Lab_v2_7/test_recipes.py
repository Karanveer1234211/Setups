import unittest
from types import SimpleNamespace

from datafeed import Feed
from engine import run
from recipes import EXAMPLES,compile_recipe


class RecipeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.feed=Feed()

    def test_reference_replay(self):
        cfg=compile_recipe(EXAMPLES['First gap above 2%'],self.feed)
        result=run(self.feed,cfg)
        self.assertEqual(result['n'],1683)
        self.assertAlmostEqual(result['mean'],.9459633333,places=7)

    def test_combined_signal_and_state(self):
        cfg=compile_recipe(EXAMPLES['Signal strength and gap'],self.feed)
        self.assertEqual(cfg['states'],['S01','S02'])
        self.assertEqual([r['field'] for r in cfg['steps'][0]['rules']],['pre_state_rsi14','pre_state_rvol','gap_pct'])
        self.assertEqual(cfg['steps'][0]['logic'],'all')

    def test_sequence_and_capture(self):
        f=SimpleNamespace(fields=self.feed.fields,picks=self.feed.picks,panel=True,has_bars=True)
        cfg=compile_recipe(EXAMPLES['Volume surge then breakout'],f)
        self.assertEqual(cfg['steps'][0]['capture'],'high')
        self.assertEqual(cfg['steps'][1]['rules'][0]['rhs'],'event_value')
        c=compile_recipe('close: close > ema20 * 1.02 or rsi > 55',f)
        self.assertEqual(c['steps'][0]['logic'],'any')
        self.assertEqual(c['steps'][0]['rules'][0]['factor'],1.02)

    def test_panel_custom_column(self):
        fields={**self.feed.fields,'custom_slope':('slope (panel close)','close')}
        f=SimpleNamespace(fields=fields,picks=self.feed.picks,panel=None,has_bars=False)
        c=compile_recipe('close: slope >= 2.5',f)
        self.assertEqual(c['steps'][0]['rules'][0]['field'],'custom_slope')

    def test_exits_and_bad_inputs(self):
        self.assertEqual(compile_recipe(EXAMPLES['Day 1 gap with target'],self.feed)['tp'],5)
        pairs=[('open: rsi > 30','Line 1'),('open: eval(1) > 0','Unknown feature'),
               ('open: gap > 2 and signal rsi > 50 or day = 1','Mixed'),
               ('close: close > 0\nwindow: 1','no eligible fill'),
               ('open: saved level > 1','earlier event'),('open: gap > news','Unknown feature'),
               ('open: gap > 2\nstop: 1%','bundled path'),('open: gap > 2\nstates: Z99','Unknown states'),
               ('open: gap > 2\ntarget: 3%\nstop: 1 ATR','both use'),
               ('close: volume multiple > 3','daily OHLCV'),('intraday: bar close > open','intraday bars')]
        for text,msg in pairs:
            with self.subTest(text=text),self.assertRaisesRegex(ValueError,msg):compile_recipe(text,self.feed)


if __name__=='__main__':unittest.main()
