"""Read-only price sources. All timestamps used for exchange sessions are Indian local time."""
from pathlib import Path
from functools import lru_cache
import re
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
FIELDS = {
    'event_value': ('Level saved by an earlier event', 'open'),
    'gap_pct': ('Opening gap %', 'open'), 'open': ('Session open', 'open'),
    'prev_close': ('Previous close', 'open'), 'day': ('Watch session number', 'open'),
    'close': ('Session close', 'close'), 'intraday_pct': ('Open to close %', 'close'),
    'since_signal_pct': ('Close vs signal close %', 'close'),
    'high': ('Session high', 'close'), 'low': ('Session low', 'close'),
    'volume': ('Session volume', 'close'), 'rvol20': ('Volume / previous 20-session mean', 'close'),
    'rsi14': ('Daily RSI 14', 'close'), 'atr14': ('Daily ATR 14 in rupees', 'close'),
    'ema20_angle': ('EMA20 angle ° · 5 sessions / ATR', 'close'),
    'ema20': ('Daily EMA 20', 'close'), 'ema50': ('Daily EMA 50', 'close'),
    'prev_rsi14': ('Previous completed RSI 14', 'open'), 'prev_rvol20': ('Previous completed volume multiple', 'open'),
    'prev_atr14': ('Previous completed ATR in rupees', 'open'),
    'prior_high': ('Prior session high', 'open'), 'prior_low': ('Prior session low', 'open'),
    'or_high': ('15-minute opening range high', 'intraday'),
    'or_low': ('15-minute opening range low', 'intraday'),
    'bar_close': ('Completed intraday bar close', 'intraday'),
    'bar_high': ('Completed intraday bar high', 'intraday'), 'bar_low': ('Completed intraday bar low', 'intraday'),
    'bar_volume': ('Completed intraday bar volume', 'intraday')
}
def wilder(s, n=14):
    values=s.to_numpy(dtype=float); out=np.full(len(s),np.nan); valid=np.flatnonzero(np.isfinite(values))
    if len(valid)>=n:
        first=valid[n-1]; out[first]=np.mean(values[valid[:n]])
        for i in range(first+1,len(s)): out[i]=(out[i-1]*(n-1)+values[i])/n
    return pd.Series(out,index=s.index)

def local_time(series):
    t=pd.to_datetime(series)
    if t.dt.tz is not None: t=t.dt.tz_convert('Asia/Kolkata').dt.tz_localize(None)
    return t

def normalize(path, extra=(), symbol=None):
    p=Path(path); df=pd.read_parquet(p) if p.suffix.lower()=='.parquet' or p.is_dir() else pd.read_csv(p)
    if any(n is not None for n in df.index.names): df=df.reset_index()
    df.columns=[str(c).lower().strip() for c in df.columns]
    if symbol is not None and 'symbol' not in df:df['symbol']=symbol
    for dest,choices in {'date':['timestamp','datetime','time','trading_date'], 'symbol':['ticker','tradingsymbol']}.items():
        if dest not in df:
            src=next((n for n in choices if n in df),None)
            if src:df=df.rename(columns={src:dest})
    required=['symbol','date','open','high','low','close','volume']
    missing=set(required+list(extra))-set(df)
    if missing:raise ValueError('Missing panel columns: '+', '.join(sorted(missing)))
    df=df[required+list(extra)].copy();df['date']=local_time(df.date);df['symbol']=df.symbol.astype(str).str.upper().str.strip()
    return df

def daily_panel(path,extra,symbols):
    path=Path(path)
    if path.is_dir():
        chunks=[]
        for f in sorted(path.glob('*.parquet')):
            sym=re.sub(r'_(?:1d|daily)$','',f.stem,flags=re.I).upper()
            if sym in symbols:chunks.append(normalize(f,extra,sym))
        if not chunks:raise ValueError('No per-symbol daily files found; use SYMBOL.parquet or SYMBOL_1d.parquet.')
        df=pd.concat(chunks,ignore_index=True)
    else:df=normalize(path,extra)
    df=df[df.symbol.isin(symbols)].copy();df.date=df.date.dt.normalize()
    if df.duplicated(['symbol','date']).any():raise ValueError('Daily panel contains duplicate symbol/session rows.')
    if df.empty:raise ValueError('No watchlist symbols matched the daily panel.')
    parts=[]
    for _,b in df.sort_values(['symbol','date']).groupby('symbol'):
        b=b.copy()
        for k in ['open','high','low','close','volume',*extra]:b[k]=pd.to_numeric(b[k],errors='raise')
        if b[['open','high','low','close','volume']].isna().any().any() or (b[['open','high','low','close']]<=0).any().any() or (b.volume<0).any() or (b.high<b[['open','close','low']].max(axis=1)).any() or (b.low>b[['open','close']].min(axis=1)).any():raise ValueError('Invalid daily OHLCV for '+str(b.symbol.iloc[0]))
        prev=b.close.shift(); delta=b.close.diff()
        gain=wilder(delta.clip(lower=0)); loss=wilder((-delta).clip(lower=0))
        b['rsi14']=100*gain/(gain+loss); b.loc[(gain==0)&(loss==0),'rsi14']=50
        b['atr14']=wilder(pd.concat([b.high-b.low,(b.high-prev).abs(),(b.low-prev).abs()],axis=1).max(axis=1))
        b['rvol20']=b.volume/b.volume.shift().rolling(20).mean().replace(0,np.nan)
        for n in [20,50]:b[f'ema{n}']=b.close.ewm(span=n,adjust=False,min_periods=n).mean()
        b['ema20_angle']=np.degrees(np.arctan((b.ema20-b.ema20.shift(5))/(5*b.atr14.replace(0,np.nan))))
        for dest,src in [('prev_close','close'),('prior_high','high'),('prior_low','low'),('prev_atr14','atr14'),('prev_rsi14','rsi14'),('prev_rvol20','rvol20')]:b[dest]=b[src].shift()
        for name in extra:b['custom_'+name]=b[name]
        parts.append(b)
    return pd.concat(parts).set_index(['symbol','date']).sort_index()

class Feed:
    def __init__(self,panel=None,extras=(),intraday=None,minutes=5,dataset=None,featurefile=None):
        dataset=Path(dataset) if dataset else ROOT/'data'
        df=pd.read_parquet(dataset/'watchlist.parquet')
        self.picks=list(df.to_dict('records'));self.calendar=list(pd.to_datetime(pd.read_parquet(dataset/'calendar.parquet').date).dt.normalize())
        self.fields=dict(FIELDS);self.extra=extras
        for n in df:
            if n.startswith('pre_') or n in ['rank','score','prob_win','both_engines']:
                self.fields[n]=(n.replace('pre_','Signal · ').replace('_',' '),'snapshot')
        self.fields['pre_state_rsi14']=('Signal · RSI 14','snapshot')
        self.fields['pre_state_rvol']=('Signal · volume / prior 50-session median','snapshot')
        for n in extras:self.fields['custom_'+n]=(n+' (panel close)','close')
        self.feature_rows={}
        if featurefile:
            import pyarrow.parquet as pq
            names=pq.read_schema(featurefile).names
            lookup={c.lower():c for c in names}
            datekey=next((lookup[k] for k in ('timestamp','date','datetime') if k in lookup),None)
            if not datekey or 'symbol' not in lookup:raise ValueError('Feature panel needs symbol and timestamp/date.')
            if not extras:raise ValueError('Enter the numeric feature column names to load from the feature panel.')
            absent=set(extras)-set(lookup)
            if absent:raise ValueError('Missing features: '+', '.join(sorted(absent)))
            q=pd.read_parquet(featurefile,columns=[lookup['symbol'],datekey,*[lookup[n] for n in extras]])
            q=q.reset_index() if any(n is not None for n in q.index.names) else q
            q=q[[lookup['symbol'],datekey,*[lookup[n] for n in extras]]]
            q.columns=['symbol','date',*['custom_'+n for n in extras]]
            q.symbol=q.symbol.astype(str).str.strip().str.upper();q.date=local_time(q.date).dt.normalize()
            q=q[q.symbol.isin(set(df.symbol))].copy()
            if q.empty or q.duplicated(['symbol','date']).any():raise ValueError('Empty or duplicated symbol/date feature join')
            for n in extras:q['custom_'+n]=pd.to_numeric(q['custom_'+n],errors='raise')
            self.feature_rows=q.set_index(['symbol','date']).sort_index()
        self.panel=daily_panel(panel,[] if featurefile else extras,set(df.symbol)) if panel else None
        if self.panel is not None:self.calendar=sorted(set(self.calendar)|set(self.panel.index.get_level_values('date')))
        self.dates={d:i for i,d in enumerate(self.calendar)}
        self.intradir=None
        self.minutes=minutes;self.bars={}
        if intraday and Path(intraday).is_dir():
            self.intradir=Path(intraday)
            if not any(self.intradir.glob(f'*_{minutes}m.parquet')):raise ValueError('No matching SYMBOL_interval.parquet intraday files.')
        elif intraday:
            z=normalize(intraday).sort_values(['symbol','date'])
            if z.duplicated(['symbol','date']).any():raise ValueError('Duplicate intraday timestamps.')
            for (sym,date),g in z.groupby(['symbol',z.date.dt.normalize()]):
                self.bars[sym,date]=g.to_dict('records')
        self.has_bars=bool(self.bars) or self.intradir is not None
    @lru_cache(maxsize=12000)
    def panel_row(self,sym,date):
        if self.panel is None:return None
        try:return self.panel.loc[(sym,date)].to_dict()
        except KeyError:return None
    @lru_cache(maxsize=4)
    def intraday_symbol(self,sym):
        if Path(sym).name!=sym:return {}
        file=self.intradir/f'{sym}_{self.minutes}m.parquet'
        if not file.exists():return {}
        z=normalize(file,symbol=sym).sort_values('date')
        if z.date.duplicated().any():raise ValueError('Duplicate intraday timestamp: '+sym)
        return {d:g.to_dict('records') for d,g in z.groupby(z.date.dt.normalize())}
    def intrabars(self,sym,date):
        if self.intradir is not None:return self.intraday_symbol(sym).get(date,[])
        return self.bars.get((sym,date),[])
    def session(self,r,day):
        idx=self.dates[pd.Timestamp(r['entry_day'])]+day-1
        if idx>=len(self.calendar):return None
        date=self.calendar[idx];p=self.panel_row(r['symbol'],date)
        if self.panel is not None and p is None:return None
        if p is None:
            if day>10:return None
            pc=r['signal_close'] if day==1 else r['entry']*(1+r[f'close_{day-1}'])
            o=r['entry'] if day==1 else pc*(1+r[f'overnight_{day}'])
            c=r['entry']*(1+r[f'close_{day}']);p={}
            if day==1:p={'prev_atr14':r['s_atr14']*pc,'prev_rsi14':r['pre_state_rsi14']}
        else:pc,o,c=p['prev_close'],p['open'],p['close']
        features={}
        if isinstance(self.feature_rows,pd.DataFrame):
            try:features=self.feature_rows.loc[(r['symbol'],date)].to_dict()
            except KeyError:pass
        return {**p,**features,'date':date,'day':day,'open':o,'close':c,'prev_close':pc,
                'gap_pct':(o/pc-1)*100 if pc>0 else np.nan,'intraday_pct':(c/o-1)*100,
                'since_signal_pct':(c/r['signal_close']-1)*100 if self.panel is None or abs((self.panel_row(r['symbol'],pd.Timestamp(r['signal_day'])) or {}).get('close',np.nan)/r['signal_close']-1)<.001 else np.nan}
