"""Run locally with python app.py; the server only listens on the loopback interface."""
import os,argparse,json,sqlite3,webbrowser,threading,zlib
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from recipes import compile_recipe, EXAMPLES
from provenance import dataset_id
from paired import journal_view
from datafeed import Feed,ROOT
from engine import run,validate

def rule(field,op,value):return dict(field=field,op=op,value=value)
def event(phase,*rules):return dict(phase=phase,logic='all',rules=list(rules))
def preset(name,steps,**changes):
    return dict(name=name,steps=steps,**(dict(engine='D',window=5,hold=5,rank=3,state='',market='',tp=0,sl=0,unit='pct',cost=.35,size=150000,one=False)|changes))
GAP=rule('gap_pct','>',2)
PRESETS=[
 preset('First gap above 2%', [event('open',GAP)]),
 preset('Day 1 gap · 5% take-profit',[event('open',GAP)],window=1,tp=5),
 preset('Day 1 gap · 2 ATR target',[event('open',GAP)],window=1,tp=2,unit='atr'),
 preset('Open-entry benchmark',[event('open',rule('day','=',1))],window=1),
 preset('Signal RSI + volume + opening gap',[event('open',rule('pre_state_rsi14','>',50),rule('pre_state_rvol','>=',3),GAP)]),
 preset('Volume surge, then a later gap',[event('close',rule('rvol20','>=',3)),event('open',GAP)]),
 preset('15-minute breakout, then retest',[event('intraday',{'field':'bar_close','op':'>','rhs':'or_high'}),event('intraday',{'field':'bar_low','op':'<=','rhs':'or_high'},{'field':'bar_close','op':'>','rhs':'or_high'})])
]
PRESETS.extend([
 preset('RSI above 50 at selection', [event('open',rule('pre_state_rsi14','>',50))],window=1),
 preset('New RSI close above 50', [event('close',rule('rsi14','>',50))]),
 preset('Volume at least 3× prior mean', [event('close',rule('rvol20','>=',3))]),
])
def guard_extras(extras):
    blocked=['future','forward','fwd','lookahead','ahead','label','target','mfe','mae','outcome','post_','exit','next','ret_1d_close_pct','ret_3d_close_pct','ret_5d_close_pct']
    if any(any(k in n for k in blocked) for n in extras):raise ValueError('Forward-looking fields cannot be used.')
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--dataset',type=Path,default=ROOT/'data');parser.add_argument('--feature-panel',type=Path);parser.add_argument('--panel',type=Path);parser.add_argument('--extra',default='',help='Comma-separated trusted point-in-time numeric panel columns');parser.add_argument('--intraday',type=Path);parser.add_argument('--minutes',type=int,choices=[1,3,5,15],default=5);parser.add_argument('--port',type=int,default=8787);parser.add_argument('--no-browser',action='store_true')
    args=parser.parse_args();extras=[x.strip().lower() for x in args.extra.split(',') if x.strip()]
    guard_extras(extras)
    feed=Feed(args.panel,extras,args.intraday,args.minutes,args.dataset,args.feature_panel)
    dbpath=ROOT/'local_history.db'
    with sqlite3.connect(dbpath) as db:
        db.execute('create table if not exists runs (id integer primary key, created text default CURRENT_TIMESTAMP, config text, metrics text, source text)')
        db.execute('create table if not exists recipebook (title text primary key, recipe text not null)')
        db.execute('create table if not exists notes (run integer, state text, body text, primary key(run,state))')
        db.execute('create table if not exists ledgers (id integer primary key, body blob)')
    identity=dataset_id(args.dataset)
    source={'dataset_id':identity,'dataset':str(args.dataset),'featurefile':str(args.feature_panel or ''),'panel':str(args.panel or ''),'intraday':str(args.intraday or ''),'extras':extras,'minutes':args.minutes}
    meta={'fields':feed.fields,'presets':PRESETS,'count':len(feed.picks),'dates':len(set(str(p['signal_day']) for p in feed.picks)),'states':sorted(set(p['pre_state'] for p in feed.picks)),'markets':sorted(set(str(p['pre_env_direction']) for p in feed.picks)),'panel':bool(args.panel),'intraday':feed.has_bars}
    class Handler(BaseHTTPRequestHandler):
        def reply(self,status,data,kind='application/json'):
            raw=json.dumps(data,allow_nan=False).encode() if kind=='application/json' else data
            self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Content-Length',len(raw));self.end_headers();self.wfile.write(raw)
        def do_GET(self):
            path=urlparse(self.path).path
            if path in ['/','/ui.js','/style.css']:
                name={'/':'index.html','/ui.js':'ui.js','/style.css':'style.css'}[path]
                self.reply(200,(ROOT/name).read_bytes(),{'index.html':'text/html; charset=utf-8','ui.js':'application/javascript','style.css':'text/css'}[name])
            elif path=='/meta':self.reply(200,{**meta,'source':source})
            elif path.startswith('/result/') and path[8:].isdigit():
                with sqlite3.connect(dbpath) as db:rec=db.execute('select body from ledgers where id=?',(int(path[8:]),)).fetchone()
                if rec:self.reply(200,json.loads(zlib.decompress(rec[0])))
                else:self.reply(404,{'error':'Ledger unavailable'})
            elif path=='/paired':
                with sqlite3.connect(dbpath) as db:self.reply(200,journal_view(args.dataset,db,parse_qs(urlparse(self.path).query),identity))
            elif path=='/recipes':
                with sqlite3.connect(dbpath) as db:book=dict(db.execute('select title,recipe from recipebook order by title'))
                self.reply(200,{'examples':EXAMPLES,'saved':book})
            elif path=='/notes':
                with sqlite3.connect(dbpath) as db:rows=db.execute('select run,state,body from notes').fetchall()
                self.reply(200,{f'{i}/{s}':v for i,s,v in rows})
            elif path=='/history':
                with sqlite3.connect(dbpath) as db:rows=db.execute('select id,created,config,metrics,source from runs order by id desc').fetchall()
                self.reply(200,[dict(id=i,created=d,config=json.loads(c),metrics=json.loads(m),source=json.loads(s)) for i,d,c,m,s in rows])
            else:self.reply(404,{'error':'Unknown route'})
        def do_POST(self):
            nonlocal feed,source,meta
            if self.path not in ['/run','/source','/note','/feature-columns','/compile','/save-recipe']:return self.reply(404,{'error':'Unknown route'})
            if self.headers.get('Host') not in [f'127.0.0.1:{args.port}',f'localhost:{args.port}']:return self.reply(403,{'error':'Local requests only'})
            if not self.headers.get('Content-Type','').startswith('application/json'):return self.reply(415,{'error':'JSON required'})
            origin=self.headers.get('Origin')
            if origin and origin!=f'http://{self.headers.get("Host")}':return self.reply(403,{'error':'Local requests only'})
            try:
                size=int(self.headers.get('Content-Length',0))
                if not 0<size<=100000:raise ValueError('Invalid request size')
                c=json.loads(self.rfile.read(size))
                if self.path in ['/compile','/save-recipe']:
                    text=c.get('recipe')
                    if not isinstance(text,str) or not text.strip() or len(text)>20000:raise ValueError('Enter a recipe between 1 and 20,000 characters.')
                    compiled=compile_recipe(text,feed)
                    if self.path=='/save-recipe':
                        with sqlite3.connect(dbpath) as db:
                            db.execute('insert or replace into recipebook(title,recipe) values(?,?)',(compiled['name'],text))
                    return self.reply(200,{'config':compiled})
                if self.path=='/feature-columns':
                    import pyarrow as pa,pyarrow.parquet as pq
                    path=Path(os.path.expandvars(c['path']));schema=pq.read_schema(path)
                    names=[]
                    for field in schema:
                        if not (pa.types.is_integer(field.type) or pa.types.is_floating(field.type)):continue
                        try:guard_extras([field.name.lower()])
                        except ValueError:continue
                        names.append(field.name)
                    return self.reply(200,{'columns':names})
                if self.path=='/note':
                    i=int(c['run']);state=c['state'];body=str(c['body']).strip()
                    with sqlite3.connect(dbpath) as db:
                        row=db.execute('select metrics from runs where id=?',(i,)).fetchone()
                        if not row or state not in json.loads(row[0]).get('diagnostics',{}):raise ValueError('Unknown run/state.')
                        db.execute('insert or replace into notes values(?,?,?)',(i,state,body))
                    return self.reply(200,{'saved':True})
                if self.path=='/source':
                    panel=c.get('panel') or None; bars=c.get('intraday') or None
                    extra=[n.strip().lower() for n in c.get('extras','').split(',') if n.strip()]
                    guard_extras(extra)
                    ff=os.path.expandvars(c.get('featurefile','')) or None
                    for path in [panel,bars,ff]:
                        if path and (str(path).startswith(('//','\\\\')) or not Path(path).exists()):raise ValueError('Choose an existing local file or folder.')
                    minutes=int(c.get('minutes',5))
                    if minutes not in [1,3,5,15]:raise ValueError('Unsupported bar interval')
                    newfeed=Feed(panel,extra,bars,minutes,args.dataset,ff)
                    feed=newfeed;source={'dataset_id':identity,'dataset':str(args.dataset),'featurefile':ff or '','panel':panel or '', 'intraday':bars or '', 'extras':extra,'minutes':minutes}
                    meta={**meta,'panel':bool(panel),'intraday':feed.has_bars,'fields':feed.fields}
                    return self.reply(200,{'ready':True})
                feed_for_run,source_for_run=feed,source
                out=run(feed_for_run,c)
                metrics={k:v for k,v in out.items() if k!='rows'}
                with sqlite3.connect(dbpath) as db:
                    cur=db.execute('insert into runs(config,metrics,source) values(?,?,?)',(json.dumps(c),json.dumps(metrics,allow_nan=False),json.dumps(source_for_run)));out['id']=cur.lastrowid
                    db.execute('insert into ledgers values(?,?)',(out['id'],zlib.compress(json.dumps(out,allow_nan=False).encode(),6)))
                self.reply(200,out)
            except (ValueError,TypeError,KeyError,OverflowError,OSError) as e:self.reply(400,{'error':str(e)})
    server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler);url=f'http://127.0.0.1:{args.port}'
    print(f'BigMove Scenario Lab · {url}',flush=True)
    if not args.no_browser:threading.Timer(.5,lambda:webbrowser.open(url)).start()
    server.serve_forever()
if __name__=='__main__':main()
