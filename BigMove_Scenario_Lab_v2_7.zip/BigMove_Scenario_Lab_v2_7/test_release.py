import json
import sqlite3
import tempfile
import unittest
import zlib
from pathlib import Path
import pandas as pd
from paired import journal_view
from provenance import dataset_id

class JournalIntegrity(unittest.TestCase):
    def test_same_trade_id_cannot_link_different_source(self):
        with tempfile.TemporaryDirectory() as tmp,sqlite3.connect(':memory:') as db:
            folder=Path(tmp)
            def write(sym):
                pd.DataFrame([dict(symbol=sym,trade_id='D-20200101-1',entry_day='2020-01-02')]).to_parquet(folder/'trades.parquet')
            write('FIRST');first=dataset_id(folder);write('SECOND')
            pd.DataFrame([dict(date='2020-01-02',env_direction='mixed',environment='mixed')]).to_parquet(folder/'market_days.parquet')
            current=dataset_id(folder);self.assertNotEqual(first,current)
            db.executescript('create table runs(id,config,source);create table ledgers(id,body);')
            for i,src in enumerate([{},dict(dataset_id=first),dict(dataset_id=current)],1):
                db.execute('insert into runs values(?,?,?)',(i,json.dumps({'name':'test'}),json.dumps(src)))
                db.execute('insert into ledgers values(?,?)',(i,zlib.compress(b'{"rows":[]}')))
            v=journal_view(folder,db,{'id':['D-20200101-1']},current)
            self.assertEqual([r['run'] for r in v['runs']],[3]);self.assertEqual((v['unverified_runs'],v['other_dataset_runs']),(1,1))
if __name__=='__main__':unittest.main()
