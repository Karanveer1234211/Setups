"""Content identity for the frozen dataset used by a saved run."""
from hashlib import sha256
from pathlib import Path

DATA_FILES=('watchlist.parquet','calendar.parquet','trades.parquet','market_days.parquet')
def dataset_id(root):
    digest=sha256()
    for name in DATA_FILES:
        path=Path(root)/name
        digest.update(name.encode()+b'\0')
        if not path.exists():
            digest.update(b'absent\0');continue
        with path.open('rb') as f:
            while chunk:=f.read(1024*1024):digest.update(chunk)
    return digest.hexdigest()
