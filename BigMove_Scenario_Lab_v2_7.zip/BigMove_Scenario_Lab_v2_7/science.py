"""Paired net lift per eligible nomination, with a circular date-block interval.

Intervals describe variability within the observed history conditional on the chosen
rule, states, cost and universe. They do not correct for strategy search, identify
trigger skill, or provide forward validation. The shared sample is weighted by
nominations, not by equal-weight daily means.
"""
from math import isfinite
from collections import defaultdict

import numpy as np

BLOCK = 10
RESAMPLES = 2000
SEED = 7
MIN_ACTIVE_DAYS = 30
MIN_OCCUPIED_BLOCKS = 10
LANES = {'PLAN': 'original', 'OPEN6': 'open6'}


def _finite(value):
    return value is not None and isfinite(float(value))


def _block_totals(values, starts, width):
    """Sum each circular block from a prefix array; works for a remainder too."""
    prefix = np.r_[0.0, np.cumsum(np.r_[values, values[:width]])]
    return (prefix[starts + width] - prefix[starts]).sum(axis=1)


def _intervals(daily, lanes):
    n = len(daily)
    full, tail = divmod(n, BLOCK)
    rng = np.random.default_rng(SEED)
    starts = rng.integers(n, size=(RESAMPLES, full))
    last = rng.integers(n, size=(RESAMPLES, 1)) if tail else None

    def sample(values):
        sums = _block_totals(values, starts, BLOCK)
        return sums if not tail else sums + _block_totals(values, last, tail)

    counts = sample(daily[:, 0])
    valid = counts > 0
    if valid.mean() < 0.95:
        return {}
    return {lane: np.percentile(sample(daily[:, idx])[valid] / counts[valid], [2.5, 97.5])
            for lane, idx in lanes.items()}


def paired_evidence(records, sessions):
    """For one scope, use the engine's rows and full ordered session calendar."""
    rows = [r for r in records if r.get('status') != 'Unsettled']
    calendar = sorted({str(day)[:10] for day in sessions})
    groups = defaultdict(list)
    for row in rows:
        groups[str(row['signal_day'])[:10]].append(row)
    active = sorted(groups)
    start = active[0] if active else None
    end = active[-1] if active else None
    dates = [day for day in calendar if active and start <= day <= end]
    if set(groups).difference(dates):
        raise ValueError('Signal dates absent from the exchange calendar.')
    occupied = len({i // BLOCK for i, day in enumerate(dates) if day in groups})
    result = dict(eligible=len(rows), fills=sum(r['status'] == 'Filled' for r in rows),
                  active_days=len(active), active_blocks=occupied, session_days=len(dates),
                  start=start, end=end, block_sessions=BLOCK, replicates=RESAMPLES, seed=SEED)
    daily = np.zeros((len(dates), 3), dtype=float)
    lanes = {}
    for idx, (lane, field) in enumerate(LANES.items(), start=1):
        missing = 0
        for i, day in enumerate(dates):
            cohort = groups.get(day, ())
            daily[i, 0] = len(cohort)
            for row in cohort:
                ret = 0.0 if row['status'] in ('No entry', 'Daily cap') else (
                    row.get('ret') if row['status'] == 'Filled' else None)
                baseline = row.get(field)
                if _finite(ret) and _finite(baseline):
                    daily[i, idx] += ret - baseline
                else:
                    missing += 1
        estimate = float(daily[:, idx].sum() / len(rows)) if rows and not missing else None
        summary = dict(estimate=estimate, lo=None, hi=None, missing=missing, status='No eligible picks')
        result[lane] = summary
        if missing:
            summary['status'] = 'Incomplete pairs'
        elif rows and (len(active) < MIN_ACTIVE_DAYS or occupied < MIN_OCCUPIED_BLOCKS):
            summary['status'] = 'Thin history'
        elif rows:
            lanes[lane] = idx
            summary['status'] = 'Insufficient resampled coverage'
    if lanes:
        for lane, (lo, hi) in _intervals(daily, lanes).items():
            result[lane].update(lo=float(lo), hi=float(hi), status=(
                'Above baseline' if lo > 0 else 'Below baseline' if hi < 0 else 'Crosses zero'))
    return result
