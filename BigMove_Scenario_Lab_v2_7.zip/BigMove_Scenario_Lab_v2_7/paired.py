import json,zlib
import pandas as pd

def journal_view(dataset,db,q,identity=None):
    path=dataset/'trades.parquet'
    if not path.exists():return {'error':'Reimport the TLX journal to enable the original-record view.'}
    trade=q.get('id',[''])[0];sym=q.get('symbol',[''])[0].strip().upper()
    if trade:
        data=pd.read_parquet(path,filters=[('trade_id','=',trade)])
        if data.empty:return {'error':'Unknown trade ID'}
        original=json.loads(data.to_json(orient='records',date_format='iso'))[0]
        runs=[];unverified=0;different=0
        for rid,c,source,blob in db.execute('select runs.id,config,source,body from runs join ledgers on runs.id=ledgers.id order by runs.id desc'):
            recorded=json.loads(source).get('dataset_id')
            if identity is not None and recorded!=identity:
                if recorded is None:unverified+=1
                else:different+=1
                continue
            conf=json.loads(c);result=json.loads(zlib.decompress(blob))
            row=next((r for r in result['rows'] if r['trade_id']==trade),None)
            runs.append(dict(run=rid,strategy=conf['name'],states=conf.get('states') or 'All',outcome=row or {'status':'Outside scope'}))
        market=pd.read_parquet(dataset/'market_days.parquet',columns=['date','env_direction','environment'])
        days=market[(pd.to_datetime(market.date)>=pd.Timestamp(original['entry_day']))].head(5)
        journey=[dict(date=str(pd.Timestamp(b.date).date()),market=b.env_direction,environment=b.environment,close_return=original.get(f'close_ret_s{k}')) for k,b in enumerate(days.itertuples(),1)]
        return dict(original=original,journey=journey,runs=runs,unverified_runs=unverified,other_dataset_runs=different)
    cols=['trade_id','symbol','rank','signal_day','pre_state','pre_state_event','pre_environment','net_bp']
    data=pd.read_parquet(path,columns=cols,filters=[('symbol','=',sym)] if sym else None).sort_values(['signal_day','trade_id'],ascending=[False,True])
    offset=max(0,int(q.get('offset',[0])[0]))
    return dict(total=len(data),rows=json.loads(data.iloc[offset:offset+50].to_json(orient='records',date_format='iso')))
