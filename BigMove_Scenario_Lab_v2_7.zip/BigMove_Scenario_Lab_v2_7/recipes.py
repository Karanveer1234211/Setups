"""A finite, line-based strategy language. Its output is ordinary Scenario Lab JSON."""
from datetime import date
from difflib import get_close_matches
from math import isfinite
import re

from engine import PHASES, validate

EXAMPLES = {
    'First gap above 2%': 'name: First gap above 2%\nopen: gap > 2%\nwindow: 5\nhold: 5',
    'Signal strength and gap': 'name: Signal strength and gap\nstates: S01, S02\nopen: signal RSI > 50 and signal volume >= 3 and gap > 2%\nwindow: 5\nhold: 5',
    'Day 1 gap with target': 'name: Day 1 gap with target\nopen: gap > 2%\nwindow: 1\nhold: 5\ntarget: 5%',
    'Volume surge then breakout': 'name: Volume surge then breakout\nclose: volume multiple >= 3; save high\nintraday: bar close > saved level\nwindow: 5\nhold: 5',
}
ALIASES = {
    'gap': 'gap_pct', 'gap up': 'gap_pct', 'signal rsi': 'pre_state_rsi14',
    'signal volume': 'pre_state_rvol', 'signal rvol': 'pre_state_rvol',
    'rsi': 'rsi14', 'previous rsi': 'prev_rsi14', 'volume multiple': 'rvol20',
    'ema angle': 'ema20_angle', 'ema20 angle': 'ema20_angle', 'saved level': 'event_value',
    'opening range high': 'or_high', 'opening range low': 'or_low',
    'signal state': 'pre_state', 'signal event': 'pre_state_event'
}
NUMBER = r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?'
PANEL_FIELDS = {'high','low','volume','rvol20','rsi14','atr14','ema20','ema50','ema20_angle','prior_high','prior_low','prev_rvol20'}
TEXT_FIELDS = {'pre_state','pre_state_event','pre_state_confidence','pre_state_vol_regime','pre_state_phase','pre_env_direction'}

def _float(value):
    if not re.fullmatch(NUMBER, value): raise ValueError(f'Expected a number, got {value!r}.')
    number = float(value)
    if not isfinite(number): raise ValueError('A number must be finite.')
    return number

def _field(value, feed):
    name = value.strip().lower()
    key = ALIASES.get(name, name.replace(' ', '_'))
    if key in feed.fields: return key
    if 'custom_'+key in feed.fields: return 'custom_'+key
    choices = get_close_matches(key, feed.fields, n=2)
    hint = ' Try '+', '.join(choices)+'.' if choices else ' Use a listed feature or attach it in Data sources.'
    raise ValueError(f'Unknown feature {value!r}.'+hint)

def _comparison(expr, feed):
    match = re.fullmatch(r'([^<>=!]+?)\s*(>=|<=|!=|==|=|>|<)\s*(.+)', expr.strip())
    if not match: raise ValueError('Write a comparison such as gap > 2% or bar close > saved level.')
    left, op, right = match.groups()
    field = _field(left, feed)
    op = '=' if op=='==' else op
    rule = {'field': field, 'op': op}
    if field in TEXT_FIELDS:
        if op not in ('=','!='): raise ValueError('Text features support = and != only.')
        if not re.fullmatch(r'[\w :.-]+', right): raise ValueError('Use a plain category name such as FAILED_BREAKOUT:FAILED.')
        return {**rule, 'value':right.strip()}
    value = re.fullmatch(f'({NUMBER})\\s*(%|x|°)?', right, re.I)
    if value:
        number, suffix = value.groups()
        if suffix=='%' and field not in {'gap_pct','intraday_pct','since_signal_pct'}:
            raise ValueError('Use % only with percentage-point fields such as gap. Other fields use native units.')
        if suffix and suffix.lower()=='x' and field not in {'rvol20','prev_rvol20','pre_state_rvol'}:
            raise ValueError('Use x only for volume multiples.')
        if suffix=='°' and 'angle' not in field: raise ValueError('Use degrees only for an angle.')
        return {**rule, 'value':_float(number)}
    rhs = right.split('*')
    if len(rhs)>2:raise ValueError('Use at most one multiplier, such as ema20 * 1.02.')
    other = _field(rhs[0],feed)
    if other in TEXT_FIELDS: raise ValueError('Numeric features must be compared with numeric fields.')
    return {**rule, 'rhs':other, 'factor':_float(rhs[1].strip()) if len(rhs)==2 else 1}

def _event(value, phase, feed, saved):
    expr, separator, tail = value.partition(';')
    terms = re.split(r'\s+(and|or)\s+',expr.strip(),flags=re.I)
    joins = {s.lower() for s in terms[1::2]}
    if len(joins)>1: raise ValueError('Use only AND or only OR in one event. Mixed precedence is unsupported.')
    rules = [_comparison(t,feed) for t in terms[::2]]
    step = dict(phase=phase,logic='any' if 'or' in joins else 'all',rules=rules)
    if separator:
        cap = re.fullmatch(r'\s*save\s+(.+?)\s*', tail,re.I)
        if not cap:raise ValueError('Use ; save high to remember a field after this event.')
        step['capture'] = _field(cap[1],feed)
        if step['capture'] in TEXT_FIELDS:raise ValueError('Save a numeric level.')
    fields = {k for r in rules for k in (r['field'],r.get('rhs')) if k}
    if step.get('capture'):fields.add(step['capture'])
    if 'event_value' in fields and not saved:raise ValueError('Save a numeric level in an earlier event before using saved level.')
    for field in sorted(fields):
        if feed.fields[field][1] not in PHASES[phase]:
            raise ValueError(f'{field} is unavailable at {phase}. Change the event clock or use a prior completed value.')
        if field in PANEL_FIELDS and feed.panel is None:raise ValueError(f'{field} needs daily OHLCV. Connect it in Data sources.')
    if phase=='intraday' and not feed.has_bars:raise ValueError('Connect intraday bars in Data sources before compiling an intraday event.')
    return step

def _setting(key,value,feed):
    if key in {'name','market'}:
        if key=='market' and value.lower()=='all': value=''
        if key=='market' and value and value not in {p['pre_env_direction'] for p in feed.picks}:
            raise ValueError('Unknown market direction. Use a market shown in Watchlist.')
        return key,value
    if key=='states':
        if value.lower()=='all':return key,[]
        states=list(dict.fromkeys(s.strip().upper() for s in value.split(',')))
        unknown=set(states)-{p['pre_state'] for p in feed.picks}
        if unknown:raise ValueError('Unknown states: '+', '.join(sorted(unknown))+'. Use comma-separated state codes or ALL.')
        return key,states
    if key=='engine':
        if value.upper() not in {'D','ENS'}:raise ValueError('Choose engine D or ENS.')
        return key,value.upper()
    if key in {'window','hold','rank'}:
        limit=3 if key=='rank' else 30
        if not value.isdigit() or not 1<=int(value)<=limit:raise ValueError(f'{key} must be an integer from 1 to {limit}.')
        return key,int(value)
    if key in {'size','cost'}:
        val=_float(value.removesuffix('%').strip() if key=='cost' else value)
        if key=='cost' and not 0<=val<100 or key=='size' and val<=0:raise ValueError(f'Invalid {key}.')
        return key,val
    if key in {'start','end'}:
        date.fromisoformat(value)
        return key+'_date',value
    if key=='one per day':
        if value.lower() not in {'yes','no'}:raise ValueError('Use yes or no for one per day.')
        return 'one',value.lower()=='yes'
    raise ValueError(f'Unknown instruction {key!r}. Use open:, close:, intraday:, states:, window:, hold:, target: or stop:.')

def _earliest_entry(steps, window, minutes):
    """Find the earliest possible fill using clocks alone, independent of prices."""
    clocks = []
    for day in range(1, window+1):
        clocks.append((day,0,'open'))
        clocks.extend((day,minute,'intraday') for minute in range(15,376,minutes))
        clocks.append((day,375,'close'))
    last = (0,0)
    for step in steps:
        observation = next(((day,minute) for day,minute,phase in clocks
                            if phase==step['phase'] and (day,minute)>last),None)
        if observation is None:return window+1
        last = observation
    day,minute = last
    return day + int(minute==375)

def compile_recipe(text,feed):
    """Compile a recipe against the connected data source or raise a user-facing ValueError."""
    if not isinstance(text,str) or not text.strip():raise ValueError('Write at least one event, e.g. open: gap > 2%.')
    if len(text)>20000:raise ValueError('Recipe exceeds 20,000 characters.')
    config=dict(name='Custom recipe',engine='D',rank=3,states=[],state='',market='',window=5,hold=5,
                tp=0,sl=0,unit='pct',size=150000,cost=.35,one=False,steps=[])
    seen=set()
    saved=False
    barrier_unit=None
    for number,line in enumerate(text.splitlines(),1):
        line=line.strip()
        if not line or line.startswith('#'):continue
        try:
            key,sep,value=line.partition(':');key=key.strip().lower();value=value.strip()
            if not sep or not value:raise ValueError('Use instruction: value, e.g. open: gap > 2%.')
            if key in PHASES:
                step=_event(value,key,feed,saved);config['steps'].append(step);saved=saved or bool(step.get('capture'));continue
            if key in seen:raise ValueError(f'Duplicate {key}; specify it only once.')
            seen.add(key)
            if key in {'target','stop'}:
                if value.lower()=='off':continue
                barrier=re.fullmatch(f'({NUMBER})\\s*(%|ATR)',value,re.I)
                if not barrier:raise ValueError('Specify a distance, e.g. 5%, 2 ATR or off.')
                distance=_float(barrier[1]);unit='pct' if barrier[2]=='%' else 'atr'
                if distance<=0:raise ValueError('Use a positive distance or off.')
                if barrier_unit and unit!=barrier_unit:raise ValueError('Stop and target must both use % or both use ATR.')
                barrier_unit=unit;config['unit']=unit;config['tp' if key=='target' else 'sl']=distance;continue
            prop,data=_setting(key,value,feed);config[prop]=data
        except ValueError as exc:raise ValueError(f'Line {number}: {exc}') from exc
    validate(feed,config)
    if _earliest_entry(config['steps'],config['window'],getattr(feed,'minutes',5)) > config['window']:
        raise ValueError('The event clocks leave no eligible fill inside the entry window. A close observation fills at the next open; increase window or change the sequence.')
    if not feed.has_bars and feed.panel is None and (config['sl'] or config['tp']):
        first_day_only=(config['window']==1 or any(r['field']=='day' and r.get('op')=='=' and r.get('value')==1
            for r in config['steps'][-1]['rules']) and config['steps'][-1]['logic']=='all')
        if not(first_day_only and config['hold']==5 and config['tp'] and not config['sl']):
            raise ValueError('The bundled path supports a single target on day 1 held five sessions. Set window: 1 and hold: 5, or connect OHLCV for other barriers.')
    return config
