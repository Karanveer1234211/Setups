"""Reproduce the bounded discovery-period checks in the analyst review."""
from app import Feed, PRESETS, preset, event, rule, run

def main():
    feed=Feed()
    cases=[PRESETS[0],preset('Wait until day 3',[event('open',rule('day','=',3))],window=3),
           preset('Day 1 falls 3%, then close above signal close',
                  [event('close',rule('day','=',1),rule('intraday_pct','<=',-3)),
                   event('close',rule('since_signal_pct','>',0))],window=5)]
    for case in cases:
        # End calibration early to allow all watch/hold windows to finish before 2022.
        past=run(feed,dict(case,start_date='2020-01-01',end_date='2021-11-30'))
        later=run(feed,dict(case,start_date='2022-01-01',end_date='2022-12-31'))
        share=past['n']/past['eligible']
        row=later['consolidated']['year_report']['All years']
        print(case['name'],{
            'prior_fill_rate':round(share,4),'2022_fills':later['n'],'eligible':row['eligible'],
            'strategy_pct':round(row['strategy'],4),'plan_pct':round(row['original'],4),
            'open6_pct':round(row['open6'],4),'smaller_plan_pct':round(share*row['original'],4),
            'delta_vs_smaller_plan_pp':round(row['strategy']-share*row['original'],4)})
if __name__=='__main__':main()
