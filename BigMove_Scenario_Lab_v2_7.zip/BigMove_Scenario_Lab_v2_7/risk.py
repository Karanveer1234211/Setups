from collections import defaultdict
from math import isfinite

def trade_dd(prices):
    """Positive percentage decline using chronological entry, closes and exit."""
    peak=0.;worst=0.
    for price in prices:
        if price is None or not isfinite(price) or price<=0:return None
        peak=max(peak,price);worst=max(worst,100*(1-price/peak))
    return worst

def realized_dd(rows,size,lane):
    moves=defaultdict(float)
    for r in rows:
        if lane=='scenario' and r['status'] in ('No entry','Daily cap'):continue
        if lane=='scenario' and r['status']!='Filled':return None
        day=r.get('exit_date' if lane=='scenario' else 'plan_exit_date')
        ret=r.get('ret' if lane=='scenario' else 'original')
        if not day or ret is None:return None
        moves[day]+=size*ret/100
    value=peak=worst=0.
    for day in sorted(moves):
        value+=moves[day];peak=max(peak,value);worst=max(worst,peak-value)
    return worst
