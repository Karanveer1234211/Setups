# BM-SDE-S02V3-R1 — frozen research candidate and backtest laboratory

This package does **not** change the seven frozen setups, the production Tree, or the source panel. It uses the **exact-freeze CONSO v2** `first_setup_wins_UNIQUE_EVENTS_WITH_STATES.csv` as its signal ledger, and replays alternative entries and exits on the panel's historical OHLC.

## Freeze boundary
`FROZEN_CANDIDATE.json` fixes **S02 bullish pullback + V3 volatility expansion + SDE10 < -0.5 + original first-wins frozen setup**. Entries/exits are research variants, not frozen trading rules. This was discovered on the same history; no strategy promotion is justified.

## Install / run
```
python -m pip install pandas numpy pyarrow tabulate
python backtest.py --panel "C:\QuantData\cache_daily\panel\panel.parquet" --events "C:\PATH\TO\first_setup_wins_UNIQUE_EVENTS_WITH_STATES.csv" --out "C:\QuantData\research_sde_s02v3\RUN_001"
```
Use `--all-states` to examine the **other nine states** under the same V3+negative SDE criteria; this is a challenger experiment, not part of the frozen candidate. Each run requires a **new** output folder. The script will refuse to overwrite an existing folder.

## Experiment grid
- Entry: next session OPEN after signal confirmation (delay 1), or the following session OPEN (delay 2). **Same-close entry is excluded because SDE and state are not confirmed until that close.**
- Exit: close of entry day 3 or entry day 5 (entry day counts as day 1), unless stop or target occurs earlier.
- ATR SL: 1, 1.5, 2, 3 × **signal-close simple TR14 ATR**; ATR TP: 1, 2, 3, 4 × ATR; full grid of 16.
- Fixed SL: 2%, 3%, 5%; fixed TP: 3%, 5%, 8%; full grid of 9.
- Plus no-stop/no-target baseline. Each stop/target strategy gets both `stop_first` and `target_first` collision assumptions.
- Costs: 0.35 percentage points round-trip. MAE/MFE measured with daily OHLC extremes. The same-bar order is unknowable without intraday data.
- First-wins events are deduplicated per symbol+original entry date. Delayed-entry variants may produce multiple trades on the same stock on overlapping dates. Portfolio proxy applies fixed-slot limits, but **does not resolve all overlapping execution edge cases**.

## Outputs
One `CONSO_BACKTEST.md` summary, complete trade-level `ALL_TRADE_VARIANTS.csv`, `ALL_STRATEGY_METRICS.csv`, `YEAR_BY_YEAR.csv`, `BY_FROZEN_SETUP.csv`, `EXIT_REASONS.csv`, `PORTFOLIO_REALIZED_PROXY.csv`, and `RUN.json` with source fingerprint.

## Important limitations
This is a **daily-bar execution sensitivity study**, not a fully verified live-executable portfolio backtest. It does not claim realistic stop/target fill certainty, mark-to-market portfolio drawdown, position sizing, actual spreads/market impact, or independent out-of-sample validation. For full viability, replay 5-minute data, enforce portfolio capital and orders, and use a predeclared forward holdout. Do not rank variants as proven winners based on the same discovery period.
