@echo off
setlocal
set "PANEL=C:\QuantData\cache_daily\panel\panel.parquet"
set "EVENTS=C:\QuantData\research_sde_states_conso\first_setup_wins_UNIQUE_EVENTS_WITH_STATES.csv"
set "OUT=C:\QuantData\research_sde_s02v3\RUN_%RANDOM%_%RANDOM%"
python -m pip install pandas numpy pyarrow tabulate
python "%~dp0backtest.py" --panel "%PANEL%" --events "%EVENTS%" --out "%OUT%"
echo.
echo If the EVENTS path differs, edit RUN_WINDOWS.bat before running.
pause
