"""Read-only BigMove S02/V3/SDE frozen candidate daily-OHLC execution research."""
from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path
import numpy as np
import pandas as pd

S02='S02_BULL_PULLBACK'; V3='V3_EXPANSION'
COST=0.35

def load_prices(path):
    fields=['symbol','timestamp','open','high','low','close','volume']
    if path.suffix.lower()=='.parquet':
        import pyarrow.parquet as pq
        available=pq.read_schema(path).names
        low={x.lower():x for x in available}
        need=fields[:-1]
        if not all(x in low for x in need): raise ValueError(f'Panel missing {set(need)-set(low)}')
        d=pd.read_parquet(path,columns=[low[x] for x in fields if x in low]); d.columns=[x.lower() for x in d.columns]
    else:
        d=pd.read_csv(path); d.columns=d.columns.str.lower()
    if 'date' in d and 'timestamp' not in d: d=d.rename(columns={'date':'timestamp'})
    d['symbol']=d.symbol.astype(str).str.strip().str.upper()
    d['timestamp']=pd.to_datetime(d.timestamp,utc=True).dt.tz_convert('Asia/Kolkata').dt.tz_localize(None).dt.normalize() if isinstance(pd.to_datetime(d.timestamp).dtype,pd.DatetimeTZDtype) else pd.to_datetime(d.timestamp).dt.normalize()
    for x in ['open','high','low','close']: d[x]=pd.to_numeric(d[x],errors='coerce')
    if d.duplicated(['symbol','timestamp']).any(): raise ValueError('Duplicate price bars')
    return d.sort_values(['symbol','timestamp']).reset_index(drop=True)

def stats(d):
    if d.empty:return {'n':0}
    r=d.net_pct.to_numpy(float); eq=np.cumprod(1+r/100); peak=np.maximum.accumulate(np.r_[1,eq]); dd=(np.r_[1,eq]/peak-1)*100
    wins=r[r>0]; losses=r[r<0]
    return {'n':len(d),'mean_net_pct':round(float(np.mean(r)),5),'median_net_pct':round(float(np.median(r)),5),
            'win_pct':round(float(100*np.mean(r>0)),3),'profit_factor':round(float(wins.sum()/-losses.sum()),4) if len(losses) and losses.sum()<0 else None,
            'mean_win_pct':round(float(wins.mean()),4) if len(wins) else None,'mean_loss_pct':round(float(losses.mean()),4) if len(losses) else None,
            'worst_trade_pct':round(float(r.min()),4),'p05_pct':round(float(np.quantile(r,.05)),4),
            'loss_ge_5_pct':round(float(100*np.mean(r<=-5)),3), 'avg_mae_pct':round(float(d.mae_pct.mean()),4),
            'avg_mfe_pct':round(float(d.mfe_pct.mean()),4), 'avg_hold_bars':round(float(d.hold_bars.mean()),3),
            'sum_net_pct':round(float(r.sum()),4),
            'pseudo_sequential_max_dd_pct_NOT_PORTFOLIO':round(float(dd.min()),4)}

def simulate(g,signal_idx,delay,horizon,stop_atr,tp_atr,stop_pct,tp_pct,cost,collision):
    # Signal only available at CLOSE. delay=1 means next session OPEN, delay=2 following session OPEN.
    entry=signal_idx+delay
    if entry>=len(g):return None
    a=g.iloc[entry]; op=float(a.open)
    if not np.isfinite(op) or op<=0:return None
    atr=float(g.iloc[signal_idx].atr_abs)
    if (stop_atr is not None or tp_atr is not None) and (not np.isfinite(atr) or atr<=0):return None
    sl=(op-stop_atr*atr if stop_atr is not None else op*(1-stop_pct/100) if stop_pct is not None else -np.inf)
    tp=(op+tp_atr*atr if tp_atr is not None else op*(1+tp_pct/100) if tp_pct is not None else np.inf)
    if not sl<op<tp:return None
    last=min(entry+horizon-1,len(g)-1)
    if last<entry:return None
    # Require full horizon to avoid truncated end-of-data bias.
    if last!=entry+horizon-1:return None
    mfe=-np.inf;mae=np.inf;reason='TIME';px=None;end=None
    for k in range(entry,last+1):
        b=g.iloc[k]; o,h,l,c=[float(b[x]) for x in ['open','high','low','close']]
        if not all(np.isfinite([o,h,l,c])) or min(o,h,l,c)<=0 or h<max(o,c) or l>min(o,c):return None
        # From entry open onward, OHLC extrema known, but their sequence is not.
        mfe=max(mfe,(h/op-1)*100); mae=min(mae,(l/op-1)*100)
        if o<=sl: px=o;end=k;reason='STOP_GAP';break
        if o>=tp: px=o;end=k;reason='TARGET_GAP';break
        hit_sl=l<=sl;hit_tp=h>=tp
        if hit_sl and hit_tp:
            px=sl if collision=='stop_first' else tp;end=k;reason='BOTH_STOP_FIRST' if collision=='stop_first' else 'BOTH_TARGET_FIRST';break
        if hit_sl: px=sl;end=k;reason='STOP';break
        if hit_tp: px=tp;end=k;reason='TARGET';break
        if k==last:px=c;end=k
    if px is None:return None
    return {'entry_date':str(g.iloc[entry].timestamp.date()),'exit_date':str(g.iloc[end].timestamp.date()),
            'entry_price':op,'exit_price':px,'net_pct':(px/op-1)*100-cost,'gross_pct':(px/op-1)*100,
            'mae_pct':mae,'mfe_pct':mfe,'hold_bars':end-entry+1,'exit_reason':reason,
            'signal_atr_pct':atr/float(g.iloc[signal_idx].close)*100,
            'ambiguous_bar':reason.startswith('BOTH_')}

def apply_portfolio(df,max_positions=3):
    # Equal-notional, fixed slots, no leverage, skip concurrent signals when full.
    # Events on same date sorted deterministically; this is NOT an optimized ranking.
    if df.empty:return pd.DataFrame(),pd.DataFrame()
    d=df.sort_values(['entry_date','symbol','setup'],kind='mergesort')
    active=[];chosen=[];daily={}
    for row in d.itertuples(index=False):
        day=pd.Timestamp(row.entry_date)
        active=[x for x in active if pd.Timestamp(x['exit_date'])>=day]
        if len(active)>=max_positions or any(x['symbol']==row.symbol for x in active):continue
        x=row._asdict();chosen.append(x);active.append(x)
    picked=pd.DataFrame(chosen)
    if picked.empty:return picked,pd.DataFrame()
    # Realized P/L approximation at exit; equity curve is not mark-to-market.
    exits=picked.groupby('exit_date').net_pct.sum()/max_positions
    eq=(1+exits/100).cumprod(); dd=(eq/eq.cummax()-1)*100
    ledger=pd.DataFrame({'exit_date':exits.index,'realized_portfolio_return_pct':exits.values,'equity':eq.values,'drawdown_pct':dd.values})
    return picked,ledger

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--panel',required=True,type=Path)
    p.add_argument('--events',required=True,type=Path,help='first_setup_wins_UNIQUE_EVENTS_WITH_STATES.csv from CONSO v2')
    p.add_argument('--out',required=True,type=Path)
    p.add_argument('--max-positions',type=int,default=3)
    p.add_argument('--cost-pp',type=float,default=COST)
    p.add_argument('--all-states',action='store_true',help='Study all ten states as controls, not just frozen S02')
    a=p.parse_args()
    if a.out.exists():p.error('Output exists; refusing overwrite')
    if a.max_positions<1:p.error('max positions must be positive')
    e=pd.read_csv(a.events)
    needed={'symbol','setup','signal_date','entry_date','state_signal','vol_state_signal','sde_signal'}
    if not needed.issubset(e):raise ValueError(f'Missing events columns: {needed-set(e)}')
    if e.duplicated(['symbol','entry_date']).any():raise ValueError('Events must be FIRST-SETUP-WINS unique stock/entry; duplicates found')
    e['symbol']=e.symbol.astype(str).str.upper().str.strip()
    e['sde_signal']=pd.to_numeric(e.sde_signal,errors='coerce')
    e=e[(e.vol_state_signal==V3)&(e.sde_signal<-.5)]
    if not a.all_states:e=e[e.state_signal==S02]
    e=e.copy()
    if e.empty:raise ValueError('No qualifying signals')
    prices=load_prices(a.panel)
    # Preserve historical ATR convention from frozen setup research: simple TR14.
    out=[];mismatch=0;missing=0
    strategies=[('TIME',None,None,None,None)]
    strategies += [('ATR_SL'+str(s)+'_TP'+str(t),s,t,None,None) for s in (1,1.5,2,3) for t in (1,2,3,4)]
    strategies += [('FIX_SL'+str(s)+'_TP'+str(t),None,None,s,t) for s in (2,3,5) for t in (3,5,8)]
    # Track all raw events before portfolio simulation. Two realistic entry delays, two holding horizons.
    for sym,g in prices.groupby('symbol',sort=False):
        ev=e[e.symbol==sym]
        if ev.empty:continue
        g=g.reset_index(drop=True).copy();tr=pd.concat([(g.high-g.low),(g.high-g.close.shift()).abs(),(g.low-g.close.shift()).abs()],axis=1).max(axis=1)
        g['atr_abs']=tr.rolling(14,min_periods=14).mean()
        ix={str(v.date()):i for i,v in enumerate(g.timestamp)}
        for r in ev.itertuples(index=False):
            sig=ix.get(str(r.signal_date)); oldentry=ix.get(str(r.entry_date))
            if sig is None or oldentry is None:missing+=1;continue
            if oldentry!=sig+1:mismatch+=1;continue
            for delay in (1,2):
                for horizon in (3,5):
                    for label,sa,ta,sp,tp in strategies:
                        for collision in (('stop_first','target_first') if label!='TIME' else ('stop_first',)):
                            z=simulate(g,sig,delay,horizon,sa,ta,sp,tp,a.cost_pp,collision)
                            if z is None:continue
                            z.update(symbol=sym,setup=r.setup,signal_date=str(r.signal_date),
                                     state=r.state_signal,vol_state=r.vol_state_signal,sde=float(r.sde_signal),
                                     entry_delay=delay,exit_horizon=horizon,rule=label,collision=collision,
                                     original_entry_date=str(r.entry_date))
                            out.append(z)
    if not out:raise ValueError('No settled trades. Verify panel date normalization and event inputs.')
    a.out.mkdir(parents=True)
    d=pd.DataFrame(out)
    d.to_csv(a.out/'ALL_TRADE_VARIANTS.csv',index=False)
    group=['state','entry_delay','exit_horizon','rule','collision']
    results=[];portfolio=[]
    for key,g in d.groupby(group,sort=True):
        st=stats(g);st.update(dict(zip(group,key)));st['ambiguous_pct']=round(float(g.ambiguous_bar.mean()*100),3)
        results.append(st)
        selected,ledger=apply_portfolio(g,a.max_positions)
        if not ledger.empty:
            pr={'selected_trades':len(selected),'realized_exit_curve_final_return_pct':round(float((ledger.equity.iloc[-1]-1)*100),3),
                'realized_exit_curve_max_dd_pct':round(float(ledger.drawdown_pct.min()),3),
                'NOTE':'Not mark-to-market; fixed-slot realized-return proxy, not production portfolio simulation'}
            pr.update(dict(zip(group,key)));portfolio.append(pr)
    sm=pd.DataFrame(results).sort_values(['state','entry_delay','exit_horizon','rule','collision'])
    sm.to_csv(a.out/'ALL_STRATEGY_METRICS.csv',index=False)
    pd.DataFrame(portfolio).to_csv(a.out/'PORTFOLIO_REALIZED_PROXY.csv',index=False)
    annual=d.assign(year=pd.to_datetime(d.entry_date).dt.year).groupby(group+['year']).agg(n=('net_pct','size'),mean_net_pct=('net_pct','mean'),win_pct=('net_pct',lambda x:(x>0).mean()*100),avg_mae=('mae_pct','mean'),avg_mfe=('mfe_pct','mean')).reset_index()
    annual.to_csv(a.out/'YEAR_BY_YEAR.csv',index=False)
    bysetup=d.groupby(group+['setup']).agg(n=('net_pct','size'),mean_net_pct=('net_pct','mean'),win_pct=('net_pct',lambda x:(x>0).mean()*100)).reset_index()
    bysetup.to_csv(a.out/'BY_FROZEN_SETUP.csv',index=False)
    reasons=d.groupby(group+['exit_reason']).size().rename('n').reset_index();reasons.to_csv(a.out/'EXIT_REASONS.csv',index=False)
    # Cross-state exploration uses the SAME locked strategy grid; state is not tuned.
    top=sm[(sm.rule=='TIME')&(sm.collision=='stop_first')]
    ranked=sm[(sm.n>=100)&(sm.collision=='stop_first')].sort_values('mean_net_pct',ascending=False).head(35)
    md=['# BigMove S02/V3 negative-SDE frozen candidate — execution research','',
        '## Research contract','- Original seven setup signals are imported from the CONSO v2 exact-freeze event file. No frozen rules are modified.',
        '- S02/V3/SDE are measured at the **completed signal close**. Entry on that same close is NOT assumed executable.',
        '- Delay 1: next-session open; delay 2: following-session open. Horizon 3/5 counts entry session as day 1.',
        '- Stops/targets evaluated from entry-session OHLC. Gap stops/targets fill at opening price. Both-hit bars use separate pessimistic/optimistic paths.',
        '- MAE/MFE use full daily bar extremes, including the exit bar; extrema order is unknown. This can overstate pre-exit excursions.',
        '- ATR stop uses 14-period simple true-range ATR at signal close; not Wilder ATR.',
        '- 0.35 percentage-point round-trip cost; no extra slippage, circuit limits, spread or impact.',
        '- The realized-exit portfolio proxy is **not** mark-to-market and does not establish portfolio viability.',
        '- Strategies evaluated on the SAME historical data that discovered S02/V3/SDE are exploratory, NOT out-of-sample.',
        f'- Unmatched signal dates: {missing}; nonconsecutive original entry dates: {mismatch}.',
        '','## Unstopped baseline (same-day-after-signal vs one more day delay)',top.to_markdown(index=False),
        '','## Highest historical mean returns (minimum 100 trades; research only)',ranked.to_markdown(index=False),
        '','## Files','- ALL_TRADE_VARIANTS.csv: every trade, variant, entry/exit, MAE/MFE and collision flag.',
        '- ALL_STRATEGY_METRICS.csv: return distribution, win rate, profit factor, severe losses, MAE/MFE, exit timing.',
        '- YEAR_BY_YEAR.csv, BY_FROZEN_SETUP.csv, EXIT_REASONS.csv, PORTFOLIO_REALIZED_PROXY.csv.',
        '','## Critical missing validation','- Proper daily marked-to-market equity curve, realistic multi-position fills and capital sizing.',
        '- Intraday sequence needed for unambiguous stop/target collision resolution.',
        '- Separate forward/OOS period and multiple-testing correction before rule promotion.',
        '- Corporate-action, price-band, delisting, turnover, and liquidity survivorship audit.']
    (a.out/'CONSO_BACKTEST.md').write_text('\n'.join(md),encoding='utf-8')
    manifest={'candidate':'BM-SDE-S02V3-R1','state':S02,'volatility':V3,'sde_lt':-.5,'frozen_setup_sha256':'483f1539324f3ae5c06756b00b32c189f5eb995f73956a681673f005ce399c8f',
              'source_panel':str(a.panel),'source_events':str(a.events),'source_events_sha256':hashlib.sha256(a.events.read_bytes()).hexdigest(),
              'cost_pp':a.cost_pp,'max_positions':a.max_positions,'variant_rows':len(d),'signals':int(e.shape[0]),'all_states':a.all_states}
    (a.out/'RUN.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print(f'DONE: {a.out} | signals={len(e)} | variants={len(d)}')
if __name__=='__main__':main()
