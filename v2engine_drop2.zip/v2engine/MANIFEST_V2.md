# MANIFEST_V2.md - v2engine 0.2 (drop 2), 31 Oct 2026

Copy the whole folder to C:\Users\karanvsi\PyCharmMiscProject\v2engine\ (replaces drop 1). Nothing to ignore; nothing goes into bigmove_deploy, pathlab or tradelab.

| file | sha256 (first 16) | bytes |
|---|---|---|
| v2engine.py | 1780417aa680e09f | 1,395 |
| v2_core.py | 738ffb283dfd4ead | 20,242 |
| v2_families.py | 7d973d77ea9742fc | 10,335 |
| v2_research.py | e91a78ef14fd523f | 15,856 |
| v2_learn.py | 5d62a87c83da3501 | 5,810 |
| v2_stats.py | bd517d03283e2b25 | 4,768 |
| tests\v2_world.py | c4603f88cfe5412f | 7,776 |
| tests\test_v2.py | b01ce12bcfdd037b | 39,535 |
| V2_DECLARATION_DRAFT.json | d45bf8521a366a60 | 7,403 |
| README_V2.md | c497d2a19801e340 | 6,640 |
