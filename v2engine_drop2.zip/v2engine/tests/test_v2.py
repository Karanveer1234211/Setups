r"""test_v2.py - verification suite for v2engine drop 1 (synthetic data only).

    python tests\test_v2.py          full suite (includes 20 no-effect worlds for calibration)
    python tests\test_v2.py quick    everything except the calibration worlds

Ends with  VERIFIED (v2engine 0.2 (drop 2))  or  SUITE FAILED: <names>.
"""
import dataclasses
import math
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))

import numpy as np  # noqa: E402

import v2_core as C  # noqa: E402
from v2_core import (BLOCKED, FILLED, GAPPED_OVER, NOT_TRIGGERED, BarStore, SelectionRegistry,  # noqa: E402
                     SelectionStore, SessionCalendar, V2Error, X1, X2, X4, X5, fill_buy_stop, fill_preopen,
                     make_sid, plan_trade, run_exit, structure_target, wilder_atr, x3)
from v2_families import (BreakoutAcceptance, Delay, FailedBreakdown, Family, HomeIndexTurn, Order,  # noqa: E402
                         SqueezeBurst, TurnAfterDip)
from v2_learn import choose_policy, context_table, learn_targets, pool_cells, replay_targets  # noqa: E402
from v2_research import (Budget, check_budget, compare_books, fill_rate, research, run_book,  # noqa: E402
                         settled, trigger_tests)
from v2_stats import DayBoot, bh, eb_shrink, max_t, summary  # noqa: E402
from v2_world import business_days, make_world, tiny_calendar  # noqa: E402

RESULTS = []


def check(name, cond, detail=""):
    RESULTS.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  -> " + str(detail)))


def raises(fn, exc=V2Error):
    try:
        fn()
    except exc:
        return True
    except Exception:
        return False
    return False


def defaults():
    C.set_cost(0.0035)
    C.set_stop_slip(0.05)


def bars_on(cal, open_, high, low, close, upper=None, lower=None):
    bs = BarStore(cal)
    rec = {"open": np.asarray(open_, float), "high": np.asarray(high, float), "low": np.asarray(low, float),
           "close": np.asarray(close, float), "volume": np.ones(cal.n)}
    if upper is not None:
        rec["upper_locked"] = np.asarray(upper, bool)
    if lower is not None:
        rec["lower_locked"] = np.asarray(lower, bool)
    bs.put_arrays("X", rec)
    return bs, bs["X"]


def flat(cal, p=100.0, w=1.0):
    n = cal.n
    return [np.full(n, p), np.full(n, p + w), np.full(n, p - w), np.full(n, p)]


# ---------------------------------------------------------------------------------------------- t01
def t01_calendar():
    days = business_days("2024-01-01", 40, holiday_every=7)
    cal = SessionCalendar(days)
    check("t01a window is T+1..T+10 inclusive", cal.window(5) == list(range(6, 16)), cal.window(5))
    check("t01b arming closes T..T+9", cal.arming_closes(5) == list(range(5, 15)), cal.arming_closes(5))
    gaps = [(days[i + 1] - days[i]).days for i in range(len(days) - 1)]
    check("t01c holidays skipped: T+k counts sessions, not days", max(gaps) >= 2 and cal.n == 40)
    check("t01d end of data: short window flagged", cal.window(35) == [36, 37, 38, 39] and not cal.complete(35))
    cal2 = SessionCalendar(days, special=[days[8]], count_special=True)
    check("t01e special session counted but takes no entry",
          (not cal2.entry_ok[8]) and cal2.window(5) == list(range(6, 16)) and 7 not in cal2.arming_closes(5))
    cal3 = SessionCalendar(days, special=[days[8]], count_special=False)
    check("t01f special session not counted", cal3.n == 39 and not cal3.has(days[8]))
    check("t01g unknown special session refused",
          raises(lambda: SessionCalendar(days, special=["2023-12-31"], count_special=True)))


# ---------------------------------------------------------------------------------------------- t02
def t02_registry():
    cal = tiny_calendar(40)
    reg = SelectionRegistry(cal)
    s1 = reg.add("PM_X", "ENS", 2, cal.date(10), "CUPID", 0.7)
    s2 = reg.add("PM_X", "D", 2, cal.date(11), "CUPID", 0.6)
    s3 = reg.add("PM_X", "ENS", 1, cal.date(11), "CUPID", 0.9)
    check("t02a CUPID pattern = three records with their own ids",
          len(reg.items) == 3 and len({s1.sid, s2.sid, s3.sid}) == 3 and
          s1.sid == make_sid("PM_X", "ENS", cal.date(10), 2) and s1.sid.startswith("PM_X/ENS-"))
    again = reg.add("PM_X", "ENS", 2, cal.date(10), "CUPID", 0.7)
    check("t02b re-adding an identical record changes nothing", again is s1 and len(reg.items) == 3)
    check("t02c a changed record is refused (immutable)",
          raises(lambda: reg.add("PM_X", "ENS", 2, cal.date(10), "CUPID", 0.55)))
    f = reg.flags()
    check("t02d first selection flagged", f[s1.sid]["first"] and not f[s1.sid]["overlap_prior"])
    check("t02e repeats flagged, never merged",
          f[s2.sid]["overlap_prior"] == [s1.sid] and f[s2.sid]["same_day_other"] == [s3.sid] and
          not f[s2.sid]["first"] and not f[s3.sid]["first"])
    c = reg.add("PM_X", "ENS", 2, cal.date(10), "CUPID", 0.71, corrects=s1.sid)
    act = {s.sid for s in reg.active()}
    check("t02f a correction is a new record pointing to the old",
          c.sid == s1.sid + "#c1" and s1.sid not in act and c.sid in act and len(reg.items) == 4)
    check("t02g bad engine / rank / date refused",
          raises(lambda: reg.add("PM_X", "XX", 1, cal.date(5), "A", 0.1)) and
          raises(lambda: reg.add("PM_X", "D", 0, cal.date(5), "A", 0.1)) and
          raises(lambda: reg.add("PM_X", "D", 1, "2030-01-01", "A", 0.1)))
    return reg


# ---------------------------------------------------------------------------------------------- t03
def t03_store():
    cal = tiny_calendar(40)
    reg = SelectionRegistry(cal)
    a = reg.add("PM_X", "D", 1, cal.date(10), "A", 0.5)
    reg.add("PM_X", "ENS", 1, cal.date(10), "B", 0.4)
    with tempfile.TemporaryDirectory() as tmp:
        st = SelectionStore(Path(tmp) / "sel" / "selections.jsonl")
        n1 = st.append(reg.items)
        n2 = st.append(reg.items)
        tampered = dataclasses.replace(a, raw_score=0.1, fingerprint="0000000000000000")
        refused = raises(lambda: st.append([tampered]))
        lines = (Path(tmp) / "sel" / "selections.jsonl").read_text(encoding="utf-8").splitlines()
    check("t03a append-only: written once, re-append writes nothing", n1 == 2 and n2 == 0 and len(lines) == 2)
    check("t03b a record with a different fingerprint is refused", refused)


# ---------------------------------------------------------------------------------------------- t04
def t04_atr():
    rng = np.random.default_rng(4)
    n = 60
    close = 100 * np.exp(np.cumsum(rng.normal(0, 0.02, n)))
    high = close * (1 + rng.random(n) * 0.02)
    low = close * (1 - rng.random(n) * 0.02)
    close[20] = high[20] = low[20] = np.nan
    got = wilder_atr(high, low, close)
    trs, prev = [], None
    for i in range(n):
        if np.isnan(close[i]):
            trs.append(None)
            continue
        trs.append(high[i] - low[i] if prev is None else
                   max(high[i] - low[i], abs(high[i] - prev), abs(low[i] - prev)))
        prev = close[i]
    want, seen, acc, cur = [], 0, 0.0, float("nan")
    for t in trs:
        if t is None:
            want.append(cur)
            continue
        if seen < 14:
            acc += t
            seen += 1
            if seen == 14:
                cur = acc / 14
        else:
            cur = (cur * 13 + t) / 14
        want.append(cur)
    diff = np.nanmax(np.abs(np.array(want, float) - got))
    check("t04 Wilder ATR14 = hand loop (missing bar carried)", diff < 1e-12 and np.isnan(got[12]) and
          not np.isnan(got[13]), diff)


# ---------------------------------------------------------------------------------------------- t05
def t05_fills():
    C.set_stop_slip(0.0)
    cal = tiny_calendar(40)
    o, h, lo, c = flat(cal)
    o[20], h[20] = 100.0, 100.5
    o[21], h[21] = 106.0, 107.0
    o[22], h[22], lo[22] = 102.0, 103.0, 101.0
    o[23], h[23] = 100.0, 103.0
    up = np.zeros(cal.n, bool)
    up[24] = True
    h[24] = 103.0
    bs, b = bars_on(cal, o, h, lo, c, upper=up)
    trig, lim = 101.5, 104.0
    r = [fill_buy_stop(b, i, trig, lim) for i in (20, 21, 22, 23, 24)]
    check("t05a buy-stop cases: not triggered / gapped over / at the open / at the level / blocked",
          r[0][0] == NOT_TRIGGERED and r[1][0] == GAPPED_OVER and r[2] == (FILLED, 102.0) and
          r[3] == (FILLED, 101.5) and r[4][0] == BLOCKED, r)
    C.set_stop_slip(0.05)
    st, px = fill_buy_stop(b, 23, trig, lim)
    want = 101.5 + 0.05 * b["atr"][22]
    st2, px2 = fill_buy_stop(b, 23, trig, 101.52)
    check("t05b buy-stop slippage = 0.05 ATR of the arming close, never above the limit",
          st == FILLED and not np.isnan(want) and abs(px - want) < 1e-12 and st2 == FILLED and
          abs(px2 - 101.52) < 1e-12, (px, want, px2))
    o2, h2, lo2, c2 = flat(cal)
    bs2, b2 = bars_on(cal, o2, h2, lo2, c2)
    gap_open = 100.0 + 1.0 * b2["atr"][19] + 0.5
    o2[20], h2[20] = gap_open, gap_open + 1.0
    up2 = np.zeros(cal.n, bool)
    up2[22] = True
    bs2, b2 = bars_on(cal, o2, h2, lo2, c2, upper=up2)
    check("t05c pre-open: capped at previous close + 1 ATR; blocked on an upper lock; else the open",
          fill_preopen(b2, 20, 1.0)[0] == GAPPED_OVER and fill_preopen(b2, 22, 1.0)[0] == BLOCKED and
          fill_preopen(b2, 23, 1.0) == (FILLED, 100.0),
          (fill_preopen(b2, 20, 1.0), fill_preopen(b2, 22, 1.0), fill_preopen(b2, 23, 1.0)))
    defaults()


# ---------------------------------------------------------------------------------------------- t06
def t06_exits():
    C.set_cost(0.0035)
    cal = tiny_calendar(70)
    o, h, lo, c = flat(cal)
    o[15] = 103.0
    bs, b = bars_on(cal, o, h, lo, c)
    ex = run_exit(b, cal, 10, 100.0, "open", X1)
    check("t06a X1 sells at the open 5 sessions after entry",
          ex["exit_idx"] == 15 and ex["reason"] == "TIME" and abs(ex["net"] - (0.03 - 0.0035)) < 1e-12, ex)
    lk = np.zeros(cal.n, bool)
    lk[15:17] = True
    bs, b = bars_on(cal, o, h, lo, c, lower=lk)
    ex = run_exit(b, cal, 10, 100.0, "open", X1)
    check("t06b a lower-locked exit waits for the first unlocked open", ex["exit_idx"] == 17 and
          ex["reason"] == "TIME_LOCKWAIT", ex)
    lk2 = np.zeros(cal.n, bool)
    lk2[15:40] = True
    bs, b = bars_on(cal, o, h, lo, c, lower=lk2)
    ex = run_exit(b, cal, 10, 100.0, "open", X1)
    check("t06c locked more than 20 sessions -> STUCK", ex["reason"] == "STUCK", ex)
    o, h, lo, c = flat(cal)
    lo[12] = 94.0
    bs, b = bars_on(cal, o, h, lo, c)
    ex = run_exit(b, cal, 10, 100.0, "open", X2, stop=95.0)
    check("t06d X2 stop inside the day exits at the stop", ex["exit_idx"] == 12 and ex["exit_px"] == 95.0 and
          ex["reason"] == "STOP", ex)
    o, h, lo, c = flat(cal)
    o[12], lo[12] = 93.0, 92.0
    bs, b = bars_on(cal, o, h, lo, c)
    ex = run_exit(b, cal, 10, 100.0, "open", X2, stop=95.0)
    check("t06e a gap through the stop exits at the open", ex["exit_px"] == 93.0 and ex["reason"] == "STOP_GAP", ex)
    o, h, lo, c = flat(cal)
    h[13] = 111.0
    bs, b = bars_on(cal, o, h, lo, c)
    ex = run_exit(b, cal, 10, 100.0, "open", x3(2), stop=95.0)
    h[13], lo[13] = 111.0, 94.0
    bs, b = bars_on(cal, o, h, lo, c)
    ex2 = run_exit(b, cal, 10, 100.0, "open", x3(2), stop=95.0)
    check("t06f X3 2R target = entry + 2R; stop and target in one day -> stop first",
          ex["exit_px"] == 110.0 and ex["reason"] == "TARGET" and ex2["reason"] == "STOP", (ex, ex2))
    o, h, lo, c = flat(cal)
    o[14] = 102.0
    bs, b = bars_on(cal, o, h, lo, c)
    ev = np.zeros(cal.n, bool)
    ev[13] = True
    ex = run_exit(b, cal, 10, 100.0, "open", X2, stop=95.0, events=ev)
    check("t06g an event at a close exits at the next open", ex["exit_idx"] == 14 and ex["exit_px"] == 102.0 and
          ex["reason"] == "EVENT", ex)
    o, h, lo, c = flat(cal)
    c[30] = 101.0
    bs, b = bars_on(cal, o, h, lo, c)
    ex = run_exit(b, cal, 10, 100.0, "open", X2, stop=95.0)
    ex5 = run_exit(b, cal, 10, 100.0, "open", X5, stop=95.0)
    check("t06h backstop: X2 at the close 20 sessions after entry, X5 at 40",
          ex["exit_idx"] == 30 and ex["exit_px"] == 101.0 and ex["reason"] == "BACKSTOP" and ex5["exit_idx"] == 50,
          (ex, ex5))
    o, h, lo, c = flat(cal)
    lo[10] = 94.0
    bs, b = bars_on(cal, o, h, lo, c)
    ex = run_exit(b, cal, 10, 100.5, "stop", X2, stop=95.0)
    check("t06i buy-stop entry day: a low at or below the stop counts as stopped (worst case)",
          ex["exit_idx"] == 10 and ex["reason"] == "STOP", ex)
    check("t06j a stop at or above the entry is refused",
          raises(lambda: run_exit(b, cal, 10, 100.0, "open", X2, stop=100.0)))
    ex = run_exit(b, cal, 66, 100.0, "open", X1)
    check("t06k a trade still open when the data ends is unsettled (NaN)", ex["reason"] == "OPEN_AT_END" and
          np.isnan(ex["net"]), ex)


# ---------------------------------------------------------------------------------------------- t07
def t07_plan():
    C.set_cost(0.0035)
    cal = tiny_calendar(40)
    o, h, lo, c = flat(cal)
    o[11], c[15], o[16] = 100.0, 104.0, 103.0
    h[15], h[16] = 104.5, 103.5
    bs, b = bars_on(cal, o, h, lo, c)
    p5, _ = plan_trade(b, cal, 10, "CLOSE5")
    p6, _ = plan_trade(b, cal, 10, "OPEN6")
    lk = np.zeros(cal.n, bool)
    lk[15] = True
    bs, b2 = bars_on(cal, o, h, lo, c, lower=lk)
    p5l, why = plan_trade(b2, cal, 10, "CLOSE5")
    check("t07 PLAN = T+1 open to T+5 close; OPEN6 = to T+6 open; a locked 5th close sells at the next open",
          abs(p5 - (0.04 - 0.0035)) < 1e-12 and abs(p6 - (0.03 - 0.0035)) < 1e-12 and
          abs(p5l - (0.03 - 0.0035)) < 1e-12 and why == "CLOSE5_LOCKWAIT", (p5, p6, p5l, why))


# ---------------------------------------------------------------------------------------------- t08
def t08_families():
    cal = tiny_calendar(60)
    o, h, lo, c = flat(cal)
    c[19], c[20] = 100.0, 98.0
    lo[20], h[20] = 97.0, 100.5
    lo[22] = 96.0
    bs, b = bars_on(cal, o, h, lo, c)
    reg = SelectionRegistry(cal)
    sel = reg.add("PM_X", "D", 1, cal.date(20), "X", 0.5)
    fam = TurnAfterDip()
    o20 = fam.arm(b, cal, sel, 20)
    o22 = fam.arm(b, cal, sel, 22)
    check("t08a T1-2 levels by hand (trigger = high + 0.1 ATR, stop = lowest low since T - 0.25 ATR)",
          fam.eligible(b, cal, sel) and abs(o20.trigger - (100.5 + 0.1 * b["atr"][20])) < 1e-12 and
          abs(o20.stop - (97.0 - 0.25 * b["atr"][20])) < 1e-12 and
          abs(o22.stop - (96.0 - 0.25 * b["atr"][22])) < 1e-12 and o20.kind == "stop", (o20, o22))
    sel2 = reg.add("PM_X", "D", 2, cal.date(30), "X", 0.4)
    check("t08b T1-2 needs a fall into T", not fam.eligible(b, cal, sel2))
    o, h, lo, c = flat(cal, w=2.0)
    for s in (24, 25, 26):
        h[s], lo[s], c[s], o[s] = 100.4, 99.8, 100.1, 100.0
    bs, b = bars_on(cal, o, h, lo, c)
    sq = SqueezeBurst()
    sel3 = reg.add("PM_X", "D", 1, cal.date(22), "X", 0.6)
    got = sq.arm(b, cal, sel3, 26)
    want_t = min(100.4 + 0.1 * b["atr"][26], 100.1 * 1.04)
    check("t08c T1-4 squeeze: 3 narrow sessions -> trigger min(high + 0.1 ATR, close + 4%), stop low - 0.1 ATR",
          got is not None and abs(got.trigger - want_t) < 1e-12 and abs(got.stop - (99.8 - 0.1 * b["atr"][26])) < 1e-12,
          got)
    check("t08d T1-4 needs at least 3 narrow sessions", sq.arm(b, cal, sel3, 25) is None)
    dl = Delay(3)
    arms = [a for a in cal.arming_closes(sel.t_idx) if dl.arm(b, cal, sel, a) is not None]
    od = dl.arm(b, cal, sel, 22)
    check("t08e T1-1 d=3 arms once, after T+2's close, as a pre-open order",
          arms == [22] and od.kind == "preopen" and abs(od.stop - (b["low"][20] - 0.5 * b["atr"][20])) < 1e-12, arms)

    class BelowClose(Family):
        name, priority = "BAD", 1

        def arm(self, b, cal, sel, a):
            return Order("stop", b["close"][a] - 0.01, b["close"][a] + 1, b["close"][a] - 5, a, self.name, self.variant)

    rows, cnt = research(cal, bs, reg, BelowClose(), X1)
    trades, log, _ = run_book(cal, bs, reg, [BelowClose()], X1, "trigger")
    check("t08f already through: a trigger at or below the close is never armed (research and book)",
          len(rows) == 0 and cnt["never_armed"] == len(reg.active()) and len(trades) == 0 and len(log) == 0, cnt)


# ---------------------------------------------------------------------------------------------- t09
def t09_window():
    C.set_stop_slip(0.0)
    cal = tiny_calendar(60)
    res = {}
    for spike in (30, 31):
        o, h, lo, c = flat(cal)
        c[19], c[20] = 100.0, 99.0
        h[spike] = 110.0
        bs, b = bars_on(cal, o, h, lo, c)
        reg = SelectionRegistry(cal)
        reg.add("PM_X", "D", 1, cal.date(20), "X", 0.5)
        rows, _ = research(cal, bs, reg, TurnAfterDip(), X1)
        res[spike] = rows[0]
    check("t09 a trigger on T+10 fills; on T+11 the selection has expired",
          res[30]["filled"] and res[30]["fill_idx"] == 30 and (not res[31]["filled"]) and
          res[31]["trig_reason"] == "EXPIRED" and res[31]["trig"] == 0.0, (res[30]["fill_idx"], res[31]["trig_reason"]))
    defaults()


# ---------------------------------------------------------------------------------------------- t10
def t10_book():
    defaults()
    w = make_world("absent", n_days=400, n_sym=60, seed=3)
    fams = [TurnAfterDip(), SqueezeBurst()]
    tb, lg, _ = run_book(w["cal"], w["bars"], w["registry"], fams, X2, "trigger")
    ab, _, _ = run_book(w["cal"], w["bars"], w["registry"], fams, X2, "act_now")
    check("t10a caps hold in both books (2 a day, 6 in 5 sessions, 8 open, one per stock)",
          check_budget(w["cal"], tb) == [] and check_budget(w["cal"], ab) == [] and len(tb) > 50 and len(ab) > 50,
          (check_budget(w["cal"], tb), check_budget(w["cal"], ab), len(tb), len(ab)))
    tight = Budget(1, 3, 2)
    tb2, _, _ = run_book(w["cal"], w["bars"], w["registry"], fams, X2, "trigger", budget=tight)
    check("t10b a tighter budget is respected too", check_budget(w["cal"], tb2, tight) == [] and len(tb2) < len(tb))
    cal = tiny_calendar(60)
    o, h, lo, c = flat(cal)
    c[19], c[20], c[21] = 100.0, 99.0, 98.0
    h[23] = 110.0
    bs, b = bars_on(cal, o, h, lo, c)
    bs.put_arrays("CUPID", {"open": o, "high": h, "low": lo, "close": c, "volume": np.ones(cal.n)})
    reg = SelectionRegistry(cal)
    e2 = reg.add("PM_X", "ENS", 2, cal.date(20), "CUPID", 0.7)
    d2 = reg.add("PM_X", "D", 2, cal.date(21), "CUPID", 0.6)
    e1 = reg.add("PM_X", "ENS", 1, cal.date(21), "CUPID", 0.9)
    trades, log, _ = run_book(cal, bs, reg, [TurnAfterDip()], X1, "trigger")
    at21 = [x for x in log if x["arm_idx"] == 21]
    check("t10c CUPID: one order for the stock, first in priority, serving all three selections",
          len(trades) == 1 and trades[0]["sid"] == e1.sid and set(trades[0]["served"]) == {e1.sid, d2.sid, e2.sid} and
          len(at21) == 1 and at21[0]["merged"] == [e1.sid, d2.sid, e2.sid], (trades, at21))
    rows, _ = research(cal, bs, reg, TurnAfterDip(), X1)
    check("t10d research keeps the three CUPID selections as three rows", sorted(r["sid"] for r in rows) ==
          sorted([e1.sid, d2.sid, e2.sid]))


# ---------------------------------------------------------------------------------------------- t11
def t11_point_in_time():
    defaults()
    w = make_world("absent", n_days=300, n_sym=40, seed=5)
    cal, bars, reg = w["cal"], w["bars"], w["registry"]
    fam = TurnAfterDip()
    cut = 200

    def decisions(bs):
        out = {}
        for s in reg.active():
            b = bs[s.symbol]
            if not fam.eligible(b, cal, s):
                continue
            for a in cal.arming_closes(s.t_idx):
                if a >= cut:
                    break
                o = fam.arm(b, cal, s, a)
                if o is not None:
                    out[(s.sid, a)] = (o.trigger, o.stop, o.limit)
        return out

    before = decisions(bars)
    rng = np.random.default_rng(99)
    scr = BarStore(cal)
    for sym in bars.symbols():
        r = {k: v.copy() for k, v in bars[sym].items() if k in ("open", "high", "low", "close", "volume")}
        m = cal.n - cut
        p = r["close"][cut - 1] * np.exp(np.cumsum(rng.normal(0, 0.05, m)))
        r["open"][cut:], r["close"][cut:] = p, p * 1.01
        r["high"][cut:], r["low"][cut:] = p * 1.03, p * 0.97
        scr.put_arrays(sym, r)
    after = decisions(scr)
    check("t11a every order armed before the cut is identical when later bars are scrambled",
          len(before) > 500 and before == after, (len(before), len(after)))
    rows1, _ = research(cal, bars, reg, fam, X1)
    rows2, _ = research(cal, scr, reg, fam, X1)
    k1 = {r["sid"]: (r["a0"], r["stop"]) for r in rows1 if r["a0"] < cut - 1}
    k2 = {r["sid"]: (r["a0"], r["stop"]) for r in rows2 if r["sid"] in k1}
    check("t11b baselines are fixed at the first arming close: unchanged by later bars", k1 == k2 and len(k1) > 100,
          len(k1))


# ---------------------------------------------------------------------------------------------- t12
def _run_world(mode, cost, slip, seed=11, fam=None, policy=X1):
    C.set_cost(cost)
    C.set_stop_slip(slip)
    w = make_world(mode, n_days=1000, n_sym=150, seed=seed)
    cal, bars, reg = w["cal"], w["bars"], w["registry"]
    fam = fam or TurnAfterDip()
    rows, cnt = research(cal, bars, reg, fam, policy)
    half = cal.n // 2
    f = fill_rate([r for r in rows if r["t_idx"] < half])
    test = [r for r in rows if r["t_idx"] >= half]
    boot = DayBoot(cal.n, B=2000, seed=7)
    tt = trigger_tests(test, f, boot)
    tb, _, _ = run_book(cal, bars, reg, [fam], policy, "trigger")
    ab, _, _ = run_book(cal, bars, reg, [fam], policy, "act_now")
    bk = compare_books(cal, bars, tb, ab, boot)
    return tt, bk, test, f, boot


def _fmt(s):
    return "%+.1f bp [%+.1f, %+.1f] %s" % (s["mean"] * 1e4, s["lo"] * 1e4, s["hi"] * 1e4, s["verdict"])


def t12_worlds():
    out = {}
    for mode, cost, slip, want in (("absent", 0.0, 0.0, "SPANS 0"), ("planted", 0.0035, 0.05, "ABOVE 0"),
                                   ("reverse", 0.0035, 0.05, "BELOW 0")):
        tt, bk, _, f, _ = _run_world(mode, cost, slip)
        out[mode] = (tt, bk)
        print("     %-8s f_train %.3f | money vs B2 %s | skill vs B2p %s | vs B3b %s | book %s" % (
            mode, f, _fmt(tt["money_vs_b2"]), _fmt(tt["skill_vs_b2p"]), _fmt(tt["vs_b3b"]), _fmt(bk["a_minus_b"])))
        check("t12 %s world: money vs B2, skill vs B2p, vs B3b and the budgeted book all %s" % (mode, want),
              tt["money_vs_b2"]["verdict"] == want and tt["skill_vs_b2p"]["verdict"] == want and
              tt["vs_b3b"]["verdict"] == want and bk["a_minus_b"]["verdict"] == want,
              (tt["money_vs_b2"]["verdict"], tt["skill_vs_b2p"]["verdict"], tt["vs_b3b"]["verdict"],
               bk["a_minus_b"]["verdict"]))
    tt, _ = out["absent"]
    check("t12d per-fill numbers are kept apart and labelled descriptive",
          "per_fill_descriptive" in tt and "b3b_draws_descriptive" in tt)
    defaults()


# ---------------------------------------------------------------------------------------------- t13
def t13_peek_trap():
    fam = TurnAfterDip(offset_atr=1.0, variant="o1.0")
    tt, _, test, f, boot = _run_world("absent", 0.0, 0.0, seed=12, fam=fam)
    rs = settled(test)
    filled = [r for r in rs if r["filled"]]
    day = np.array([r["t_idx"] for r in filled])
    peek = summary(*boot.mean(*boot.by_day(day, np.array([r["trig"] - r["b2"] for r in filled]))))
    print("     fill rate %.3f | honest vs B2 %s | baseline chosen by later fills %s" % (
        f, _fmt(tt["money_vs_b2"]), _fmt(peek)))
    check("t13 a baseline chosen by later trigger outcomes fakes a result in a no-effect world; the honest one does not",
          tt["money_vs_b2"]["verdict"] == "SPANS 0" and peek["verdict"] != "SPANS 0" and f < 0.8, (f, peek))
    defaults()


# ---------------------------------------------------------------------------------------------- t14
def t14_stats():
    rej, adj = bh([0.001, 0.01, 0.03, 0.04, 0.2])
    check("t14a Benjamini-Hochberg by hand", list(rej) == [True, True, True, True, False] and
          abs(adj[2] - 0.05) < 1e-12 and abs(adj[4] - 0.2) < 1e-12, (rej, adj))
    n = 500
    boot = DayBoot(n, B=2000, seed=7)
    rng = np.random.default_rng(14)
    day = rng.integers(0, n, 3000)
    obs, boots = [], []
    for k in range(5):
        v = rng.normal(0.0, 1.0, 3000) + (0.15 if k == 4 else 0.0)
        o_, b_ = boot.mean(*boot.by_day(day, v))
        obs.append(o_)
        boots.append(b_)
    t, p = max_t(obs, boots)
    check("t14b max-t: the planted cell passes, the four null cells do not", p[4] < 0.01 and min(p[:4]) > 0.05, p)
    s, cc = boot.by_day(day, np.ones(3000) * 2.0)
    m, _ = boot.mean(s, cc)
    num, den = rng.random(n), rng.random(n) + 1
    r, _ = boot.ratio(num, den)
    check("t14c bootstrap means and ratios equal the plain figures", abs(m - 2.0) < 1e-12 and
          abs(r - num.sum() / den.sum()) < 1e-12)
    pooled, w8, parent, tau2 = eb_shrink([1.0, 1.0, 1.0], [0.5, 0.5, 0.5], [10, 20, 30])
    pooled2, w82, _, _ = eb_shrink([0.0, 1.0, 2.0], [0.01, 0.01, 0.01], [10, 10, 10])
    check("t14d empirical-Bayes pooling: equal cells pool fully; precise distinct cells keep their own value",
          np.allclose(pooled, 1.0) and tau2 == 0.0 and np.all(w82 > 0.99) and np.allclose(pooled2, [0, 1, 2], atol=0.01))
    rng2 = np.random.default_rng(15)
    rows = []
    for k in range(400):
        opts = list(rng2.normal(0.0, 0.03, int(rng2.integers(3, 10))))
        filled = bool(rng2.random() < 0.4)
        rows.append({"t_idx": int(rng2.integers(0, 300)), "trig": float(rng2.normal(0.01, 0.03)) if filled else 0.0,
                     "b2": float(rng2.normal(0.0, 0.03)), "opts": opts, "filled": filled, "first": True,
                     "b4_2": 0.0, "b4_3": 0.0, "b4_5": 0.0})
    tt = trigger_tests(rows, 0.4, DayBoot(300, B=500, seed=7), b3_draws=50)
    tr = np.array([r["trig"] for r in rows])
    b2 = np.array([r["b2"] for r in rows])
    eb3 = np.array([0.4 * np.mean(r["opts"]) for r in rows])
    check("t14e trigger tests by hand: money = trig - B2, skill = trig - f x B2, B3b = trig - f x mean(entry days)",
          abs(tt["money_vs_b2"]["mean"] - (tr - b2).mean()) < 1e-12 and
          abs(tt["skill_vs_b2p"]["mean"] - (tr - 0.4 * b2).mean()) < 1e-12 and
          abs(tt["vs_b3b"]["mean"] - (tr - eb3).mean()) < 1e-12 and abs(tt["fill_rate"] - 0.4) < 0.1)


# ---------------------------------------------------------------------------------------------- t15
def t15_slippage():
    a, _, _, _, _ = _run_world("planted", 0.0035, 0.0, seed=13)
    b, _, _, _, _ = _run_world("planted", 0.0035, 0.10, seed=13)
    check("t15 buy-stop slippage costs the trigger, not the baseline",
          b["trigger"]["mean"] < a["trigger"]["mean"] and abs(b["b2"]["mean"] - a["b2"]["mean"]) < 1e-12,
          (a["trigger"]["mean"], b["trigger"]["mean"]))
    defaults()


# ---------------------------------------------------------------------------------------------- t16
def t16_package():
    import v2engine
    import io
    import contextlib
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc_run = v2engine.main(["run"])
        rc_none = v2engine.main([])
    txt = buf.getvalue()
    check("t16a the CLI refuses real-data commands until the adapters exist", rc_run == 2 and rc_none == 2 and
          "not wired" in txt, txt)
    files = [ROOT / f for f in ("v2_core.py", "v2_families.py", "v2_research.py", "v2_stats.py", "v2_learn.py",
                                 "v2engine.py")]
    files += [HERE / "v2_world.py", HERE / "test_v2.py"]
    bad = [str(f.name) for f in files if any(ord(ch) > 127 for ch in f.read_text(encoding="utf-8"))]
    check("t16b every module is ASCII", not bad, bad)
    check("t16c version string", C.VERSION == "v2engine 0.2 (drop 2)" and v2engine.VERSION == C.VERSION)


# ---------------------------------------------------------------------------------------------- t17
def t17_calibration():
    C.set_cost(0.0)
    C.set_stop_slip(0.0)
    fam = TurnAfterDip()
    hits = {"money": 0, "skill": 0, "b3b": 0}
    tails = 0
    for seed in range(201, 221):
        w = make_world("absent", n_days=600, n_sym=120, seed=seed)
        cal, bars, reg = w["cal"], w["bars"], w["registry"]
        rows, _ = research(cal, bars, reg, fam, X1)
        half = cal.n // 2
        f = fill_rate([r for r in rows if r["t_idx"] < half])
        tt = trigger_tests([r for r in rows if r["t_idx"] >= half], f, DayBoot(cal.n, B=1000, seed=7), b3_draws=500)
        hits["money"] += tt["money_vs_b2"]["verdict"] != "SPANS 0"
        hits["skill"] += tt["skill_vs_b2p"]["verdict"] != "SPANS 0"
        hits["b3b"] += tt["vs_b3b"]["verdict"] != "SPANS 0"
        pc = tt["b3b_draws_descriptive"]["percentile"]
        tails += pc < 5 or pc > 95
    print("     20 no-effect worlds, intervals that missed 0: %s; draw-percentile in the outer 10%%: %d" % (hits, tails))
    check("t17 calibration: each paired test misses 0 in at most 3 of 20 no-effect worlds",
          all(v <= 3 for v in hits.values()), hits)
    defaults()


# ---------------------------------------------------------------------------------------------- drop 2
def _events(cal):
    n = cal.n
    return {"s10_level": np.full(n, np.nan), "s10_start": np.full(n, -1), "s10_status": np.array([""] * n, dtype=object),
            "s04_level": np.full(n, np.nan), "s04_start": np.full(n, -1), "s04_status": np.array([""] * n, dtype=object),
            "exit": np.zeros(n, bool), "swing_highs": []}


def t18_event_families():
    cal = tiny_calendar(70)
    o, h, lo, c = flat(cal)
    T = 30
    c[T + 1], lo[T + 1], o[T + 1] = 97.0, 96.5, 99.0
    h[T + 1] = 99.5
    for s in range(T + 2, T + 9):
        o[s], h[s], lo[s], c[s] = 97.0, 97.5, 96.6, 97.0     # stays below the breakdown level
    bs, b = bars_on(cal, o, h, lo, c)
    reg = SelectionRegistry(cal)
    sel = reg.add("PM_X", "D", 1, cal.date(T), "X", 0.5)
    ev = _events(cal)
    for a in range(T + 1, T + 9):
        ev["s10_level"][a], ev["s10_start"][a], ev["s10_status"][a] = 98.5, T + 1, "NEW"
    fb = FailedBreakdown({"X": ev})
    o1 = fb.arm(b, cal, sel, T + 1)
    last = fb.arm(b, cal, sel, T + 5)
    late = fb.arm(b, cal, sel, T + 6)
    check("t18a T1-3: buy-stop at the S10 level + 0.25 ATR for 5 sessions after the breakdown; stop = low since - 0.25 ATR",
          o1 is not None and abs(o1.trigger - (98.5 + 0.25 * b["atr"][T + 1])) < 1e-12 and
          abs(o1.stop - (96.5 - 0.25 * b["atr"][T + 1])) < 1e-12 and last is not None and late is None, (o1, last, late))
    ev2 = _events(cal)
    for a in range(T - 12, T + 5):
        ev2["s10_level"][a], ev2["s10_start"][a], ev2["s10_status"][a] = 98.5, T - 12, "CONFIRMED"
    check("t18b T1-3 ignores a breakdown more than 10 sessions before the pick",
          FailedBreakdown({"X": ev2}).arm(b, cal, sel, T) is None)
    o, h, lo, c = flat(cal)
    k = T + 2
    h[k], c[k], o[k] = 104.0, 103.0, 100.5
    for s in range(k + 1, k + 6):
        o[s], h[s], lo[s], c[s] = 101.5, 101.9, 101.0, 101.4
    bs, b = bars_on(cal, o, h, lo, c)
    ev3 = _events(cal)
    for a in range(k, k + 6):
        ev3["s04_level"][a], ev3["s04_start"][a], ev3["s04_status"][a] = 101.0, k, "NEW" if a < k + 3 else "CONFIRMED"
    ba, bb = BreakoutAcceptance({"X": ev3}, "a"), BreakoutAcceptance({"X": ev3}, "b")
    oa = ba.arm(b, cal, sel, k)
    ob = bb.arm(b, cal, sel, k + 2)
    ev4 = {kk: (v.copy() if hasattr(v, "copy") else v) for kk, v in ev3.items()}
    ev4["s04_status"][k + 2] = "STALLED"
    check("t18c T1-5 (a): breakout session's high + 0.1 ATR; stop = S04 level - 1.0 ATR",
          oa is not None and abs(oa.trigger - (104.0 + 0.1 * b["atr"][k])) < 1e-12 and
          abs(oa.stop - (101.0 - 1.0 * b["atr"][k])) < 1e-12, oa)
    check("t18d T1-5 (b): retest within 0.5 ATR of the level, then that session's high + 0.1 ATR; STALLED arms nothing",
          ob is not None and abs(ob.trigger - (101.9 + 0.1 * b["atr"][k + 2])) < 1e-12 and
          BreakoutAcceptance({"X": ev4}, "b").arm(b, cal, sel, k + 2) is None, ob)
    ix = {"high": np.full(cal.n, 100.0), "close": np.full(cal.n, 99.0)}
    ix["close"][T + 3], ix["high"][T + 3] = 101.0, 101.5
    hi7 = HomeIndexTurn({"SC250": ix}, {"X": "SC250"})
    before = hi7.arm(b, cal, sel, T + 2)
    after = hi7.arm(b, cal, sel, T + 4)
    check("t18e T1-7 arms only after the home index closes above its prior 5-session high",
          before is None and after is not None and abs(after.stop - (b["low"][T] - 0.5 * b["atr"][T])) < 1e-12)


def t19_structure_target():
    sh = [(20, 108.0), (22, 104.0), (30, 103.5), (31, 103.0), (25, 140.0)]
    tgt = structure_target(sh, 30, 100.0, 97.0)
    none = structure_target([(20, 101.0), (21, 125.0)], 30, 100.0, 97.0)
    check("t19a X4 target = nearest swing high confirmed by the close before entry, >= 1R above; none within 6R -> none",
          tgt == 104.0 and np.isnan(none), (tgt, none))
    cal = tiny_calendar(70)
    o, h, lo, c = flat(cal)
    h[33] = 105.0
    bs, b = bars_on(cal, o, h, lo, c)
    ex = run_exit(b, cal, 30, 100.0, "open", X4, stop=97.0, target_abs=tgt)
    ex2 = run_exit(b, cal, 30, 100.0, "open", X4, stop=97.0, target_abs=np.nan)
    check("t19b X4 exits at its structure target; without one it runs like X2",
          ex["reason"] == "TARGET" and ex["exit_px"] == 104.0 and ex2["reason"] == "BACKSTOP", (ex, ex2))


def _target_rows(n_per, peaks):
    """Hand-built filled trades: entry 100, stop 98 (R = 2); the price climbs to the group's peak in R,
    then falls through the stop."""
    C.set_cost(0.0)
    cal = tiny_calendar(40)
    bs = BarStore(cal)
    rows, groups = [], []
    k = 0
    for g, peak in peaks.items():
        for _ in range(n_per):
            n = cal.n
            p = np.full(n, 100.0)
            top = 100.0 + 2.0 * peak
            p[11:14] = np.linspace(100.0, top, 4)[1:]
            p[14:18] = np.linspace(top, 96.0, 5)[1:]
            p[18:] = 96.0
            h, lo = p + 0.05, p - 0.05
            h[13] = top
            sym = "T%04d" % k
            bs.put_arrays(sym, {"open": p.copy(), "high": h, "low": lo, "close": p.copy(), "volume": np.ones(n)})
            rows.append({"symbol": sym, "filled": True, "fill_idx": 10, "fill_px": 100.0, "stop": 98.0})
            groups.append(g)
            k += 1
    return cal, bs, rows, groups


def t20_target_learning():
    cal, bs, rows, groups = _target_rows(300, {"A": 1.5, "B": 6.5})
    cur = replay_targets(cal, bs, rows)
    big = learn_targets(cur, groups)
    cal2, bs2, rows2, groups2 = _target_rows(30, {"A": 1.5, "B": 6.5})
    small = learn_targets(replay_targets(cal2, bs2, rows2), groups2)
    check("t20a X3 learns per group: a 1.5R mover gets 1.5R, a 6.5R mover gets 6R (300 trades each)",
          big["A"]["target_r"] == 1.5 and big["B"]["target_r"] == 6.0, {g: big[g]["target_r"] for g in ("A", "B")})
    check("t20b with 30 trades a group leans on the family's target (weight 30/130)",
          small["A"]["raw_best"] == 1.5 and small["A"]["target_r"] == small["family"]["target_r"] == 6.0 and
          abs(small["A"]["weight"] - 30 / 130) < 1e-12, {g: (small[g]["target_r"]) for g in ("family", "A", "B")})
    defaults()


def t21_context():
    defaults()
    C.set_stop_slip(0.0)
    res = {}
    for name, filt in (("absent", None), ("S08 only", lambda sn: sn["state"] == "S08"),
                       ("S08 x S10 only", lambda sn: sn["state"] == "S08" and sn["event"] == "S10")):
        w = make_world("absent" if filt is None else "planted", n_days=1000, n_sym=150, seed=21, planted_filter=filt)
        cal, bars, reg = w["cal"], w["bars"], w["registry"]
        rows, _ = research(cal, bars, reg, TurnAfterDip(), X1)
        half = cal.n // 2
        f = fill_rate([r for r in rows if r["t_idx"] < half])
        test = [r for r in rows if r["t_idx"] >= half]
        boot = DayBoot(cal.n, B=2000, seed=7)
        l1 = context_table(test, f, boot, key=lambda r: r["ctx_state"])
        l2 = context_table(test, f, boot, key=lambda r: (r["ctx_state"], r["ctx_event"]))
        res[name] = (l1, l2)
        print("     %-15s L1: %s" % (name, " | ".join("%s %+.0f bp p=%.3f" % (g, v["contrast"]["mean"] * 1e4, v["p_maxt"])
                                                      for g, v in l1.items())))
    l1a, l2a = res["absent"]
    check("t21a no-effect world: no context group passes (Level 1 and Level 2)",
          all(v["p_maxt"] > 0.05 for v in l1a.values()) and all(v["p_maxt"] > 0.05 for v in l2a.values()),
          ({g: round(v["p_maxt"], 3) for g, v in l1a.items()}))
    l1b, _ = res["S08 only"]
    check("t21b Level 1: an effect planted only in S08 shows in S08's contrast and nowhere else positive",
          l1b["S08"]["contrast"]["verdict"] == "ABOVE 0" and l1b["S08"]["p_maxt"] < 0.01 and
          l1b["S01"]["contrast"]["mean"] < 0 and l1b["S07"]["contrast"]["mean"] < 0, {g: v["p_maxt"] for g, v in l1b.items()})
    _, l2c = res["S08 x S10 only"]
    cell = ("S08", "S10")
    others = [g for g in l2c if g != cell]
    pooled = pool_cells(l2c, parent_of=lambda g: g[0])
    pc = pooled[cell]
    check("t21c Level 2: an effect planted in one exact cell passes there, and its pooled size is shrunk toward its group",
          l2c[cell]["contrast"]["verdict"] == "ABOVE 0" and l2c[cell]["p_maxt"] < 0.01 and
          all(l2c[g]["p_maxt"] > 0.01 or l2c[g]["contrast"]["mean"] < 0 for g in others) and
          pc["parent_mean"] <= pc["pooled"] <= pc["raw"] and 0 < pc["weight"] <= 1,
          (l2c[cell]["p_maxt"], pc))
    defaults()


def t22_policy_choice():
    defaults()
    w = make_world("planted", n_days=800, n_sym=120, seed=22)
    cal, bars, reg = w["cal"], w["bars"], w["registry"]
    best, vals = choose_policy(cal, bars, reg, TurnAfterDip(), [X1, X2, X5], 0, cal.n // 2, Budget())
    print("     training-years book, net per session on capital in use: %s" % {k: round(v * 1e4, 2) for k, v in vals.items()})
    check("t22 the exit policy is chosen on training years by the budgeted book (a 5-session drift -> X1)",
          best == "X1" and vals["X1"] > vals["X5"], vals)


QUICK = [t01_calendar, t02_registry, t03_store, t04_atr, t05_fills, t06_exits, t07_plan, t08_families,
         t09_window, t10_book, t11_point_in_time, t12_worlds, t13_peek_trap, t14_stats, t15_slippage, t16_package,
         t18_event_families, t19_structure_target, t20_target_learning, t21_context, t22_policy_choice]
FULL = QUICK + [t17_calibration]


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    tests = QUICK if "quick" in argv else FULL
    t0 = time.time()
    for t in tests:
        defaults()
        try:
            t()
        except Exception as e:  # a crash is a failure, never a skip
            import traceback
            traceback.print_exc()
            check(t.__name__ + " crashed", False, repr(e))
    defaults()
    fails = [n for n, ok in RESULTS if not ok]
    print("")
    print("%d checks, %d failed, %.0f s" % (len(RESULTS), len(fails), time.time() - t0))
    if fails:
        print("SUITE FAILED: " + ", ".join(fails))
        return 1
    print("VERIFIED (%s)" % C.VERSION)
    return 0


if __name__ == "__main__":
    sys.exit(main())
