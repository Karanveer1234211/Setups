# v2engine 0.2 (drop 2) - BigMove v2 execution engine core

Built 31 Oct 2026 from Spec v2.3 ("BigMove Execution Engine - Spec v2", Claude Doc).
**Synthetic data only.** Nothing here reads your cache, pick_meta, tradelab or pathlab. Real-data
commands are refused until the adapters are built on your uploaded pathlab and tradelab code.

## Run (cmd)

    cd /d C:\Users\karanvsi\PyCharmMiscProject\v2engine
    python v2engine.py --selftest quick     (about 30 s)
    python v2engine.py --selftest           (about 60 s; adds 20 calibration worlds)

Expected last line: `VERIFIED (v2engine 0.2 (drop 2))`. Needs numpy only (no pandas).

## Files

| File | What it does |
|---|---|
| v2_core.py | NSE session calendar (entry on T+1..T+10 inclusive; special sessions never take entries); selection registry (one immutable record per pick run / engine / rank / T, repeat flags, append-only store, corrections as new records); Wilder ATR14 known at each close; fill model; exits X1-X5; X4 structure target; PLAN and OPEN6 per selection |
| v2_families.py | T1-1 delay, T1-2 turn after the dip, T1-4 squeeze burst; T1-3 failed breakdown and T1-5 breakout acceptance (a, b) on an event input built from tl_state; T1-7 home-index turn on index bars; the "already through" rule |
| v2_research.py | Per armed order: trigger vs B2, B2p, B3b (paired), B4, B0, B0'. Budgeted book: allocator (2 a day, 6 in 5 sessions, 8 open, one per stock, same-stock selections merged into one order) for the trigger book and the act-now (B2) book; net return per session on the capital in use |
| v2_learn.py | X3 target learning (R grid replayed on each training trade's own path; groups shrunk toward the family, weight n/(n+100)); exit-policy choice on training years by the family's budgeted book; Level 1 / Level 2 context tables (two-sided max-t); Level 2 pooling toward the group |
| v2_stats.py | Circular block bootstrap keyed by signal day; studentised max-t (one- or two-sided); Benjamini-Hochberg; empirical-Bayes pooling |
| v2engine.py | Command line: --selftest, --version; everything else refused ("not wired yet") |
| tests/v2_world.py | Synthetic worlds: martingale prices with continuous-path highs and lows; absent / planted / reverse T1-2 effect, optionally only in chosen contexts |
| tests/test_v2.py | The suite (73 checks) |
| V2_DECLARATION_DRAFT.json | Every declared default so far. DRAFT: frozen only after the map and the trigger counts |

## Verified here

- Full suite: 73 checks, 0 failed, on Python 3.13 / numpy 2.5.3 and Python 3.12 / numpy 2.4.1 (your
  numpy); the two runs print identical numbers. Clean-extraction run of the zip passes too.
- 17 planted bugs, each caught: already-through guard removed; B2 entering at the trigger's fill
  session; the 6-in-5 cap miscounted; no merging; window one session too long; ATR read a session
  ahead; target before stop; slippage ignored; X1 a session late; B3b ignoring the fill rate; world
  highs from samples only; T1-3 a 6th session after the breakdown; T1-5 on its own 20-session high
  instead of S04's level; X4 using a swing high confirmed on the entry session; no shrinkage of
  targets; the worst exit policy chosen; T1-7's index window including the current session.

### Trigger tests (1,000 sessions, 150 stocks, T1-2, exit X1, test half = sessions 500-999)

| World | Trigger minus B2, per armed order | Minus B2p | Minus B3b (paired) | Budgeted book minus B2 book, per session |
|---|---|---|---|---|
| absent (no effect, costs 0) | +2.7 bp [-22.6, +28.9] | +2.8 [-22.3, +28.7] | +14.0 [-9.1, +37.2] | -0.5 [-7.0, +5.6] |
| planted | +245.8 [+210.3, +281.5] | +244.1 [+210.4, +278.7] | +171.2 [+146.6, +194.4] | +32.8 [+25.7, +39.9] |
| reverse | -98.9 [-121.6, -74.9] | -100.8 [-123.2, -76.9] | -180.1 [-202.5, -158.5] | -16.8 [-24.0, -9.6] |

A baseline chosen by later trigger outcomes (B2 on filled orders only) shows -295.0 bp [-357.4, -231.8]
in a no-effect world; the honest B2 shows +8.2 [-22.1, +38.3].

### Context tests (Question B), lift against B2p, group minus the rest

| World | Level 1 by state (contrast, two-sided max-t p) | Level 2 exact cell |
|---|---|---|
| no effect | S01 -29 bp p=0.541; S07 +50 p=0.264; S08 -20 p=0.745 | no cell passes |
| effect only in S08 | S08 +217 p<0.001; S01 -101; S07 -116 | - |
| effect only in S08 x S10 | S08 +36 p=0.409 (diluted: Level 1 misses it) | S08 x S10: +205.2 bp [+106.8, +304.8], p=0.0025; pooled size +178.0 (raw +195.5, group mean +34.6, weight 0.89); no other cell passes |

The last row is your point 2 in numbers: an effect confined to one exact state x event cell is invisible
in the broad groups and found by the exact cell, with its size pulled back toward its group.

### Targets and exit choice

- X3 on hand-built trades: a group that peaks at 1.5R gets a 1.5R target and one that peaks at 6.5R
  gets 6R (300 trades each); with 30 trades the 1.5R group leans on the family's 6R (weight 30/130).
- Exit choice on training years in a world whose edge lasts 5 sessions: X1 +31.45 bp per session on
  capital in use, X2 +17.84, X5 +7.97 -> X1 chosen.

## Found while building (spec updated)

1. Buy-stop fills at exactly the level faked +33.6 bp a trade in a no-effect world (overshoot past the
   level booked as profit). Continuous-path world highs and lows, plus a declared 0.05 ATR buy-stop
   slippage (stress 0 and 0.10); the opening auction pays none.
2. The 1,000-draw B3b percentile ran hot (8 of 20 no-effect worlds in the outer 10%); Gate 3 uses the
   paired form (0 of 20 missed).
3. Per armed order, trading less is not skill: hence B2p and B3b at the training-year fill rate, and the
   budgeted book (which redeploys unused slots) as the primary trigger test.

## Calibration (simulation, an inference about real data)

Across 160 no-effect worlds the trigger-minus-B2 interval missed zero 8.75% of the time against 5%
nominal; z-score spread 1.00-1.08. A PASS still needs every lens, each engine and 2 of 3 test years.

## Not built yet

- B3a allocator null (many book runs; with the money view).
- After your zips: adapters to pick_meta (PM_20261017_001), stage E's loader and calendar, TLX trades
  (B0), tl_state (the event input above), tl_context, the 3-minute store (T1-8, intraday order of
  events), the ETF rule; stage E's simulator for the money view; the watch-only Pine indicator; the
  trade map in tl_journal.

## Rules kept

No `label_*` input; no raw price level as a model input (levels appear only inside trigger rules); costs
35 bp; nothing written anywhere (the only writer is SelectionStore, used by the tests in a temporary
folder); no default paths.
