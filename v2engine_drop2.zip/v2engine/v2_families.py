r"""v2_families.py - Tier 1 setup families: T1-1 delay, T1-2 turn after the dip, T1-4 burst after a
squeeze (drop 1); T1-3 failed breakdown, T1-5 breakout acceptance, T1-7 home-index turn (drop 2, on an
event input built from tl_state and on index bars). Each family arms at most one order per selection per close, from bars
known at that close; nothing here looks past the arming close.

General rule (spec section 5): a buy-stop is armed only while its trigger sits above the last close.
A trigger at or below the close means the move already happened ("already through"): no order that
evening. Below the price, a Kite GTT would act as a buy-on-dip and the daily fill model would buy at
the open; neither is the setup.

T1-6 (VIX allocation) reorders arming and T1-8 (intraday VWAP reclaim) needs 3-minute bars: later.
"""
from dataclasses import dataclass

import numpy as np

LIMIT_ATR = 0.3          # buy-stop limit = trigger + 0.3 ATR (declared)


@dataclass(frozen=True)
class Order:
    kind: str            # 'stop' (GTT buy-stop) or 'preopen' (limit buy in the pre-open)
    trigger: float       # nan for preopen
    limit: float         # nan for preopen (its cap is applied by the fill model)
    stop: float          # initial stop = setup invalidation (1R)
    arm_idx: int         # the close it was armed after; it trades in session arm_idx + 1
    family: str
    variant: str


class Family:
    name = "base"
    priority = 99        # lower = armed first (declared)

    def __init__(self, variant="v1"):
        self.variant = variant

    @property
    def key(self):
        return "%s:%s" % (self.name, self.variant)

    def eligible(self, b, cal, sel):
        return True

    def arm(self, b, cal, sel, a):
        raise NotImplementedError


def _ok(*vals):
    return all(not np.isnan(v) for v in vals)


class Delay(Family):
    """T1-1: no signal; buy at the open of T+d with a pre-open order. Stop: selection-day low - 0.5 ATR."""
    name = "T1-1"
    priority = 8

    def __init__(self, d=2, stop_atr=0.5):
        super().__init__("d%d" % d)
        self.d, self.stop_atr = int(d), float(stop_atr)

    def arm(self, b, cal, sel, a):
        T = sel.t_idx
        if a != T + self.d - 1:
            return None
        lowT, atrT = b["low"][T], b["atr"][T]
        if not _ok(lowT, atrT):
            return None
        return Order("preopen", np.nan, np.nan, lowT - self.stop_atr * atrT, a, self.name, self.variant)


class TurnAfterDip(Family):
    """T1-2: the pick fell into T (close below the previous close); each evening inside the window a
    buy-stop at that session's high + offset x ATR. Stop: lowest low since selection - 0.25 ATR."""
    name = "T1-2"
    priority = 2

    def __init__(self, offset_atr=0.1, stop_atr=0.25, variant=None):
        super().__init__(variant or "o%g" % offset_atr)
        self.offset_atr, self.stop_atr = float(offset_atr), float(stop_atr)

    def eligible(self, b, cal, sel):
        T = sel.t_idx
        if T < 1:
            return False
        c0, c1 = b["close"][T - 1], b["close"][T]
        return _ok(c0, c1) and c1 < c0

    def arm(self, b, cal, sel, a):
        h, c, atr = b["high"][a], b["close"][a], b["atr"][a]
        if not _ok(h, c, atr):
            return None
        trig = h + self.offset_atr * atr
        if trig <= c:
            return None                                   # already through
        lows = b["low"][sel.t_idx:a + 1]
        lows = lows[~np.isnan(lows)]
        if len(lows) == 0:
            return None
        stop = lows.min() - self.stop_atr * atr
        return Order("stop", trig, trig + LIMIT_ATR * atr, stop, a, self.name, self.variant)


class SqueezeBurst(Family):
    """T1-4: at least min_len consecutive narrow sessions ending at the arming close, all on or after T
    (narrow = high - low <= nr_ratio x the previous close's ATR). Buy-stop at the squeeze high + 0.1 ATR
    or the close + 4%, whichever is lower. Stop: squeeze low - 0.1 ATR."""
    name = "T1-4"
    priority = 4

    def __init__(self, nr_ratio=0.75, min_len=3, pct_cap=0.04, variant=None):
        super().__init__(variant or "nr%g_n%d" % (nr_ratio, min_len))
        self.nr_ratio, self.min_len, self.pct_cap = float(nr_ratio), int(min_len), float(pct_cap)

    def _narrow(self, b, s):
        if s < 1:
            return False
        h, lo, prev_atr = b["high"][s], b["low"][s], b["atr"][s - 1]
        return _ok(h, lo, prev_atr) and (h - lo) <= self.nr_ratio * prev_atr

    def arm(self, b, cal, sel, a):
        T = sel.t_idx
        run = 0
        s = a
        while s >= T and self._narrow(b, s):
            run += 1
            s -= 1
        if run < self.min_len:
            return None
        seg = slice(a - run + 1, a + 1)
        sq_hi, sq_lo = np.nanmax(b["high"][seg]), np.nanmin(b["low"][seg])
        c, atr = b["close"][a], b["atr"][a]
        if not _ok(c, atr):
            return None
        trig = min(sq_hi + 0.1 * atr, c * (1.0 + self.pct_cap))
        if trig <= c:
            return None                                   # already through
        return Order("stop", trig, trig + LIMIT_ATR * atr, sq_lo - 0.1 * atr, a, self.name, self.variant)


# ============================================================================ drop 2: event families
# Event input (built from tl_state by the adapter; synthetic in the tests), per symbol on the session index:
#   s10_level / s10_start / s10_status   the S10 breakdown known at that close: its level, the session it
#                                         happened (-1 none) and tl_state's status ('NEW', 'CONFIRMED', ...)
#   s04_level / s04_start / s04_status   the same for the S04 breakout
#   exit                                  a declared exit event at that close (section 5)
#   swing_highs                           [(session confirmed, level), ...] for X4
# No other lookback is called S04 or S10: the levels are tl_state's own.
ACTIVE = ("NEW", "CONFIRMED")


def _ev(events, sym):
    if not events or sym not in events:
        return None
    return events[sym]


class FailedBreakdown(Family):
    """T1-3: an S10 breakdown within 10 sessions of the pick (on or before the arming close); for up to
    5 sessions after it, a buy-stop at the breakdown level + 0.25 ATR. Stop: lowest low since the
    breakdown - 0.25 ATR."""
    name = "T1-3"
    priority = 1

    def __init__(self, events, max_after=5, lookback=10, offset_atr=0.25, stop_atr=0.25, variant=None):
        super().__init__(variant or "a%d" % max_after)
        self.events, self.max_after, self.lookback = events, int(max_after), int(lookback)
        self.offset_atr, self.stop_atr = float(offset_atr), float(stop_atr)

    def arm(self, b, cal, sel, a):
        ev = _ev(self.events, sel.symbol)
        if ev is None:
            return None
        k = int(ev["s10_start"][a])
        if k < 0 or k <= sel.t_idx - self.lookback or k > a or a - k > self.max_after - 1:
            return None
        lvl, c, atr = ev["s10_level"][a], b["close"][a], b["atr"][a]
        if not _ok(lvl, c, atr):
            return None
        trig = lvl + self.offset_atr * atr
        if trig <= c:
            return None
        lows = b["low"][k:a + 1]
        stop = np.nanmin(lows) - self.stop_atr * atr
        return Order("stop", trig, trig + LIMIT_ATR * atr, stop, a, self.name, self.variant)


class BreakoutAcceptance(Family):
    """T1-5 on tl_state's S04 (its own level and status), breakout on or after T:
    (a) a buy-stop at the breakout session's high + 0.1 ATR while S04 is NEW or CONFIRMED;
    (b) after a close back within 0.5 ATR of the S04 level, a buy-stop at that session's high + 0.1 ATR.
    Stop: the S04 level - 1.0 ATR."""
    name = "T1-5"
    priority = 5

    def __init__(self, events, mode="a", variant=None):
        if mode not in ("a", "b"):
            raise ValueError("mode a or b")
        super().__init__(variant or mode)
        self.events, self.mode = events, mode

    def arm(self, b, cal, sel, a):
        ev = _ev(self.events, sel.symbol)
        if ev is None:
            return None
        k = int(ev["s04_start"][a])
        if k < 0 or k < sel.t_idx or k > a or ev["s04_status"][a] not in ACTIVE:
            return None
        lvl, c, atr = ev["s04_level"][a], b["close"][a], b["atr"][a]
        if not _ok(lvl, c, atr):
            return None
        if self.mode == "a":
            hk, atk = b["high"][k], b["atr"][k]
            if not _ok(hk, atk):
                return None
            trig = hk + 0.1 * atk
        else:
            if a == k or abs(c - lvl) > 0.5 * atr:
                return None
            trig = b["high"][a] + 0.1 * atr
        if trig <= c:
            return None
        return Order("stop", trig, trig + LIMIT_ATR * atr, lvl - 1.0 * atr, a, self.name, self.variant)


class HomeIndexTurn(Family):
    """T1-7: once the stock's home index has closed above its prior 5-session high (on or after T),
    each evening a buy-stop at the stock's session high + 0.1 ATR. Stop: selection-day low - 0.5 ATR.
    index_bars: {index name: {'high': array, 'close': array}} on the same session index; home: {symbol: index}."""
    name = "T1-7"
    priority = 7

    def __init__(self, index_bars, home, lookback=5, variant=None):
        super().__init__(variant or "h%d" % lookback)
        self.index_bars, self.home, self.lookback = index_bars, home, int(lookback)

    def _turned(self, ix, T, a):
        for c in range(max(T, self.lookback), a + 1):
            prior = ix["high"][c - self.lookback:c]
            if not np.isnan(ix["close"][c]) and len(prior) and ix["close"][c] > np.nanmax(prior):
                return True
        return False

    def arm(self, b, cal, sel, a):
        name = self.home.get(sel.symbol)
        if name is None or name not in self.index_bars:
            return None
        if not self._turned(self.index_bars[name], sel.t_idx, a):
            return None
        T = sel.t_idx
        h, c, atr, lowT, atrT = b["high"][a], b["close"][a], b["atr"][a], b["low"][T], b["atr"][T]
        if not _ok(h, c, atr, lowT, atrT):
            return None
        trig = h + 0.1 * atr
        if trig <= c:
            return None
        return Order("stop", trig, trig + LIMIT_ATR * atr, lowT - 0.5 * atrT, a, self.name, self.variant)
