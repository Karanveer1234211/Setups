# MANIFEST - playbook v1.0 (BMPB1)

Folder: C:\Users\karanvsi\PyCharmMiscProject\playbook\ (next to v2engine\, tradelab\, pathlab\).
Needs: v2engine 0.3 (drop 3, the shipped one), tradelab v1.3.1, pathlab, bigmove_deploy's env_daily.bat. Python 3.12 / 3.13 with numpy and pandas (as v2engine).

| file | sha256 (first 16) | bytes | lines |
|---|---|---|---|
| playbook.py | 8e05e7080b4d6176 | 27241 | 489 |
| pb_core.py | a72dde717d77fc10 | 20665 | 495 |
| BigMove_Playbook.pine | c6aad5f047d15827 | 70799 | 1173 |
| env_playbook.bat | 8ace7498f410ca52 | 1436 | 32 |
| README_PLAYBOOK.md | 8744e454c384261e | 9412 | 128 |
| tests\test_playbook.py | b5825b5f4e885ee7 | 36400 | 639 |
| tests\pine_twin.py | d4647a6bc79e738c | 9675 | 244 |
| tests\pine_lint.py | cf9e7c9a8406958b | 18462 | 382 |

env_playbook.bat has CRLF line endings and labels no_v2, no_pb, v2_failed, no_root (no duplicates).
Outputs go only under PB_OUT (C:\QuantData\playbook): pine\, review_picks.csv, by_category\, categories.csv, EXPORT.md, sim_<hash>\, matrix_<hash>\, playbook_ledger.jsonl.

Verified where it was built: 79 checks (full), 0 failed, Python 3.13 / numpy 2.5.3 / pandas 3.0.5; quick suite (78) also on Python 3.12 / numpy 2.4.1 / pandas 2.3.3; 20 of 20 planted bugs caught; the Pine parsed and linted (pynescript 0.3.0), not compiled by TradingView.
