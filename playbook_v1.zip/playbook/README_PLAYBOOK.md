# playbook v1.0 (BMPB1) - a playbook per state + event, on TradingView, the open entry beside every trade

Built 1 Nov 2026. Each pick's category = tl_state's state and shown event at its close T (plus the market regime).
A mapping sends each category to one of six playbooks (entry rule + exit rule, every field a setting). The Pine
strategy trades the playbooks on the chart, shows the open entry (OPEN6: T+1 open to T+6 open) for the same pick from
the chart's own bars, and lets you step through the trades one by one and record a verdict per trade. The Python side
exports your picks for the chart and runs the chart's exact rules on every pick.

| File | What it does |
|---|---|
| BigMove_Playbook.pine | The TradingView strategy (Pine v5) |
| playbook.py | `export` (picks + tl_state context -> Pine input per symbol, review sheets), `sim` (the chart's rules on every pick, per category vs OPEN6), `matrix` (all six playbooks on every category), `--selftest` |
| pb_core.py | The rules in Python with TradingView's order semantics (the mirror) |
| env_playbook.bat | Session setup (calls v2engine's env_v2.bat; CRLF) |
| tests\ | test_playbook.py (the suite), pine_twin.py (the Pine's logic bar by bar), pine_lint.py (static checks of the Pine) |

Reads production READ ONLY through v2engine 0.3's adapter (pick_meta's run, the cache, tl_state, tl_context).
Writes only under `%PB_OUT%`. Nothing in bigmove_deploy, tradelab, pathlab or v2engine is touched.

## Install (cmd)

Unzip so that `C:\Users\karanvsi\PyCharmMiscProject\playbook\` sits next to `v2engine\`, `tradelab\`, `pathlab\`.

    call C:\Users\karanvsi\PyCharmMiscProject\playbook\env_playbook.bat
    python playbook.py --selftest quick

Expected: `78 checks, 0 failed` and last line `VERIFIED (playbook v1.0)` (about 30 seconds). `--selftest` without
`quick` runs 24,000 random cases instead of 6,000 (and lints the Pine where pynescript is installed).

## 1. Export (once)

    python playbook.py export --root %CACHE_DAILY_ROOT% --out %PB_OUT%

Default: engines D and ENS, ranks 1-3, signal days 2020-01-01 .. 2022-12-31 (the discovery years). Options:
`--engines D`, `--ranks 1-10`, `--from`, `--to`. Writes under `%PB_OUT%`:

- `pine\<SYMBOL>.txt` - one stock, every category (file name = TradingView's NSE ticker, e.g. `M_M` for M&M)
- `pine_by_category\<STATE>_<EVENT>.txt` - one category, every stock (split by year when it would pass the 40,000
  character paste limit): paste once, then change the chart's symbol; the strategy keeps the chart's own picks
- `review_picks.csv` and `by_category\<STATE>_<EVENT>.csv` - one row per pick: category, context, the open-entry
  baselines (flat commission and stage E's fully net), empty columns for your findings
- `categories.csv` - per engine and category: picks, OPEN6 / PLAN5 net per pick with 95% intervals, win rate,
  bad-trade rate, CVaR5
- `EXPORT.md` - counts per category and the steps below

## 2. On TradingView

1. Pine Editor: new script, replace everything with `BigMove_Playbook.pine`, Save, Add to chart.
2. Open the stock's daily chart (NSE:<SYMBOL>).
3. Settings > Inputs > Picks: paste a whole file - `pine\<SYMBOL>.txt`, or to go through one category stock by stock,
   `pine_by_category\<STATE>_<EVENT>.txt` and then switch the chart's symbol (the category's stocks are in
   `by_category\<STATE>_<EVENT>.csv`, column `tv_symbol`). The audit table (top left) must say `OK` for the symbol
   and `1D OK`; if TradingView names a stock differently from the export, type the export's name in `Ticker in the
   file`. Keep Properties as shipped (commission 0.175%, bar magnifier off).
4. Step through: `Focus pick #` = 1, 2, 3 ... Blue background = T, yellow = the order working, green = in the trade;
   orange dotted = trigger / limit, purple dashed = the event level, blue line = the playbook's entry, red / orange
   steps = its stop / trail, grey dashed = the OPEN6 trade. Hover a pick's label for its full record. The pick list
   (bottom left) pages through every pick; the category table (top right) totals per category; Strategy Tester >
   List of Trades has every trade (signal = trade id; `id~F` = a fallback order, `id~3` = the order placed at
   T+3's close).
5. Look at one category: State / Event / Regime filters. One playbook on every pick shown: Playbook = P1 .. P6.
6. Record: `Findings` box, one line per trade, `D-20220314-1|BETTER|retest held` (BETTER / WORSE / SAME are counted
   per category in the table; the note shows on the pick and in the logs). Or fill the columns in the CSVs.
7. Pine Logs (script menu > Pine Logs): first line `PBCFG` = the full config code; one `PBLOG` CSV line per pick
   (columns in the `PBHDR` line); 'scroll to bar' jumps to the pick.

## 3. The chart's rules on every pick

The audit table shows the short config code (only what differs from the shipped defaults) and the command:

    python playbook.py sim --root %CACHE_DAILY_ROOT% --out %PB_OUT% --code "BMPB1|P2=O:0.5"
    python playbook.py matrix --root %CACHE_DAILY_ROOT% --out %PB_OUT%

`sim` writes `%PB_OUT%\sim_<hash>\REPORT.md` (per category and playbook: playbook net per pick with unfilled picks
counted 0, OPEN6 net per pick, the paired difference with its 95% block-bootstrap interval over signal days),
`trades.csv` (every pick, with verdict / notes columns) and `summary.csv`. `--force P3` = that playbook on every pick
(the chart's Playbook = P3). `matrix` = all six playbooks on every category. Every run appends to
`%PB_OUT%\playbook_ledger.jsonl`. A code can be typed by hand: fields left out keep their defaults.

## The rules

Entry (orders placed at a close act from the next session; ATR = ta.atr(14) on the chart):
OPEN market at T+1's open (G > 0: limit at T's close x (1 + G%) for T+1 only) / DELAY market at the open of T+1+V /
STH buy stop at T's high + O x ATR(T) for V sessions (stop-limit + L x ATR; L = 0 = plain stop) / STPD buy stop at
the previous session's high + O x ATR, a fresh order every evening / STLV buy stop at the event level + O x ATR(T) /
LMLV limit at the event level + O x ATR(T) / LMTC limit at T's close - O x ATR(T) / LMEMA limit at EMA20 + O x ATR,
fresh every evening / SKIP. A buy stop whose trigger is at or below the last close is not placed (at T) or cancelled.
F = OPEN: nothing filled in the window (or no order possible) -> market at the next open.

Exit: stop NONE / ATR / PCT / TLOW / LVL (placed at the entry session's close: the entry session has no stop), target
NONE / R / PCT, hold H sessions from the entry session (X = OPEN sells at the next open, X = CLOSE at that close),
trail (after a completed close above entry + TA%: stop to entry + both commissions, then TM x ATR under the highest
close, never down; EX > H holds a trailed trade up to EX sessions). A gap through a stop or target fills at the open;
both inside one bar: open -> the nearer extreme -> the other -> close (TradingView's rule without the magnifier).
Net = (exit - entry - c x (entry + exit)) / entry, c = 0.175% a side.

Shipped defaults (starting hypotheses, all editable): S01-S03 with BO_NEW / BO_CONF -> P2 (limit at the breakout level
+ 0.25 ATR, 5 sessions); FBO -> P3 (stop at the level + 0.1 ATR, 10 sessions); BD_NEW / BD_CONF -> P4 (reclaim of the
level + 0.25 ATR, 5 sessions); S06-S12 with FBD / NONE / stalled -> P5 (stop above T's high + 0.1 ATR, 10 sessions);
everything else -> P1 (OPEN = the baseline). Every exit is the plain 5-session hold, so the comparison isolates the
entry. P6 (limit at T's close - 1 ATR, 3 sessions) is unmapped.

## Checks the chart shows you

- TV check: TradingView's own net per trade vs the table's; anything above 0.0001% = Properties' commission differs.
- Data check: per pick, OPEN6 gross from the chart vs from the cache; above 0.2% is flagged (a session one side lacks,
  e.g. Muhurat; a data adjustment). For flagged picks the chart and `sim` will differ.
- TradingView fills at prices rounded to the tick; `sim` does not round: up to one tick apart.

## Verified here / not

- pb_core by hand: every fill rule, entry rule, exit, status and fallback.
- The Pine's logic as a bar-by-bar twin with a TradingView-style broker (tests\pine_twin.py) = pb_core on 24,000
  random price paths x playbooks: identical trades (status, bars, prices, exit reason).
- The Pine itself: parsed (pynescript) and linted here (every built-in name and keyword argument, declare-before-use,
  Pick fields, function definitions; 13 of 13 planted mistakes caught by the linter). **It has not been compiled by TradingView** -
  that happens the first time you add it to a chart. A compile error: send me the message and the line number.
- Exporter and sim on a fake production cache; everything mapped to P1 reproduces OPEN6 on every pick to 1e-12.
- A planted category effect is found, an absent one is not; 40 null worlds flag 'better' at the expected rate.
- 79 checks (full), 0 failed, on Python 3.13 / numpy 2.5.3 / pandas 3.0.5; the quick suite also on Python 3.12 /
  numpy 2.4.1 / pandas 2.3.3. 20 planted bugs in the rules, the twin, the sim and the export: each one caught.
- Your cache has not been read yet.

## Discipline

2020-22 is the discovery period: what you see on the charts there is a hypothesis. `--to` after 2022-12-31 is refused
unless `--spend-holdout` (recorded in the ledger). To test a playbook on 2023-25: write its config code down first,
run it once.
