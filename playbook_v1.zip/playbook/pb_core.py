r"""pb_core.py - the BigMove playbook: categories, playbooks, the config code and a TradingView-faithful mirror.

A pick's CATEGORY is tl_state's confirmed state and the shown event at the pick's close T (plus the market regime):
    state   S01 S02 S03 S06 S07 S08 S09 S12 UNK INS
    event   BO_NEW BO_CONF BO_STALL FBO BD_NEW BD_CONF BD_STALL FBD NONE
            (S04 breakout new / confirmed / stalled, S11 failed breakout, S10 breakdown new / confirmed / stalled,
             failed breakdown = bear trap, none)
    regime  BB broad bullish, NB narrow bullish, MX mixed, BR broad bearish, HS high stress, NA unknown
A MAPPING sends each category to one of six PLAYBOOKS, first matching rule wins:
    S01,S02,S03:BO_NEW,BO_CONF:*=P2;*:FBO:*=P3;...;*:*:*=P1          ('*' = any; lists with commas)
A PLAYBOOK is an entry rule plus an exit rule (every field tweakable; the Pine script has the same fields):
    E   entry   OPEN   market at T+1's open (G > 0: a limit at T's close x (1 + G%) for T+1 only)
                DELAY  market at the open of T+1+V
                STH    buy-stop at T's high + O x ATR(T), sessions T+1 .. T+V        (stop-limit: + L x ATR;
                       L = 0: a plain buy-stop, a gap above the trigger fills at the open)
                STPD   buy-stop at the previous session's high + O x ATR, re-set each evening, T+1 .. T+V
                STLV   buy-stop at the event level + O x ATR(T) (reclaim of a failed breakout / breakdown level)
                LMLV   limit at the event level + O x ATR(T) (retest of the breakout level)
                LMTC   limit at T's close - O x ATR(T) (pullback)
                LMEMA  limit at EMA20 + O x ATR, re-set each evening
                SKIP   no trade
        Buy-stops follow the 'already through' rule: an order whose trigger is at or below the last close is not
        placed (or is cancelled): the move happened without it.
    F   if nothing filled in the window: NONE, or OPEN (market at the next open)
    S   stop    NONE | ATR (entry - SK x ATR at the entry close) | PCT (entry x (1 - SK%)) | TLOW (T's low - SK x ATR(T))
                | LVL (event level - SK x ATR(T))
    T   target  NONE | R (entry + TK x (entry - stop)) | PCT (entry x (1 + TK%))
    H   hold    sessions counted from the entry session; X = OPEN sells at the next open (H = 5 from a T+1 entry is
                OPEN6), X = CLOSE sells at that session's close (PLAN)
    TR  trail   1 = after a COMPLETED close above entry x (1 + TA%), the stop moves to entry + both commissions and then
                trails TM x ATR under the highest close; it never moves down; EX > 0 holds a trailed trade up to EX
                sessions instead of H
Order of events (as TradingView's broker emulator runs a strategy on daily bars):
    orders are placed at a session's close and act from the next session; the stop / target of a trade are placed at
    its entry session's close (so the entry session itself has no stop); a stop or target gapped through fills at the
    open; a stop and a target inside one bar: the emulator's path rule - open -> the nearer extreme -> the other
    extreme -> close; a stop-limit gapped above its limit fills at the limit if the bar trades back down to it.
Net return = (exit - entry - c x (entry + exit)) / entry, c = commission per side (TradingView's percent commission).
"""
import math
from dataclasses import dataclass, field, asdict

import numpy as np

VERSION = "playbook v1.0"
CODE_TAG = "BMPB1"
STATES = ("S01", "S02", "S03", "S06", "S07", "S08", "S09", "S12", "UNK", "INS")
EVENTS = ("BO_NEW", "BO_CONF", "BO_STALL", "FBO", "BD_NEW", "BD_CONF", "BD_STALL", "FBD", "NONE")
REGIMES = ("BB", "NB", "MX", "BR", "HS", "NA")
ENTRY = ("OPEN", "DELAY", "STH", "STPD", "STLV", "LMLV", "LMTC", "LMEMA", "SKIP")
STOPS = ("NONE", "ATR", "PCT", "TLOW", "LVL")
TARGETS = ("NONE", "R", "PCT")
EXIT_AT = ("OPEN", "CLOSE")
FALLBACK = ("NONE", "OPEN")
FIELDS = ("E", "O", "V", "L", "G", "F", "S", "SK", "T", "TK", "H", "X", "TR", "TA", "TM", "EX")
COMMISSION = 0.175          # percent per side (35 bp round trip, the project's flat cost)

# tl_state / tl_context codes -> playbook tokens
STATE_TOKEN = {"S01": "S01", "S02": "S02", "S03": "S03", "S06": "S06", "S07": "S07", "S08": "S08", "S09": "S09",
               "S12": "S12", "UNKNOWN": "UNK", "INSUFFICIENT_DATA": "INS"}
STATE_CODE_TOKEN = {1: "S01", 2: "S02", 3: "S03", 6: "S06", 7: "S07", 8: "S08", 9: "S09", 12: "S12", 0: "UNK", -1: "INS"}
EVENT_CODE_TOKEN = {0: "NONE", 1: "BO_NEW", 2: "BO_CONF", 3: "BO_STALL", 4: "FBO", 5: "BD_NEW", 6: "BD_CONF",
                    7: "BD_STALL", 8: "FBD"}
REGIME_CODE_TOKEN = {0: "BB", 1: "NB", 2: "MX", 3: "BR", 4: "HS", -1: "NA"}


@dataclass
class Playbook:
    name: str
    E: str = "OPEN"
    O: float = 0.0
    V: int = 1
    L: float = 0.3
    G: float = 0.0
    F: str = "NONE"
    S: str = "NONE"
    SK: float = 0.0
    T: str = "NONE"
    TK: float = 0.0
    H: int = 5
    X: str = "OPEN"
    TR: int = 0
    TA: float = 3.0
    TM: float = 2.0
    EX: int = 0
    title: str = ""

    def check(self):
        bad = []
        if self.E not in ENTRY:
            bad.append("E=%s" % self.E)
        if self.S not in STOPS:
            bad.append("S=%s" % self.S)
        if self.T not in TARGETS:
            bad.append("T=%s" % self.T)
        if self.X not in EXIT_AT:
            bad.append("X=%s" % self.X)
        if self.F not in FALLBACK:
            bad.append("F=%s" % self.F)
        if int(self.V) < 1 or int(self.H) < 1:
            bad.append("V and H must be >= 1")
        if bad:
            raise ValueError("playbook %s: %s" % (self.name, ", ".join(bad)))
        return self


# The starting hypotheses (Karan 31 Oct): a category decides HOW to enter; the exit is the plain hold so that the
# comparison with buying at the open isolates the entry. Every field is a setting.
DEFAULT_PLAYBOOKS = {
    "P1": Playbook("P1", "OPEN", 0.0, 1, 0.3, 0.0, "NONE", title="Open T+1 (baseline)"),
    "P2": Playbook("P2", "LMLV", 0.25, 5, 0.3, 0.0, "NONE", title="Breakout retest: limit at the breakout level"),
    "P3": Playbook("P3", "STLV", 0.10, 10, 0.3, 0.0, "NONE", title="Failed breakout: reclaim the level"),
    "P4": Playbook("P4", "STLV", 0.25, 5, 0.3, 0.0, "NONE", title="Breakdown: bear-trap reclaim of the level"),
    "P5": Playbook("P5", "STH", 0.10, 10, 0.3, 0.0, "NONE", title="Confirmation: above T's high"),
    "P6": Playbook("P6", "LMTC", 1.0, 3, 0.3, 0.0, "NONE", title="Pullback: limit at T's close - 1 ATR"),
}
DEFAULT_MAP = ("S01,S02,S03:BO_NEW,BO_CONF:*=P2;*:FBO:*=P3;*:BD_NEW,BD_CONF:*=P4;"
               "S06,S07,S08,S09,S12:FBD,NONE,BO_STALL,BD_STALL:*=P5;*:*:*=P1")


# ============================================================================ mapping and the config code
@dataclass
class Rule:
    states: tuple      # () = any
    events: tuple
    regimes: tuple
    pb: str
    text: str = ""


def parse_map(text):
    rules = []
    for raw in text.replace("\r", "").replace("\n", ";").split(";"):
        r = raw.replace(" ", "")
        if not r:
            continue
        if "=" not in r:
            raise ValueError("mapping rule without '=': %r" % raw)
        left, pb = r.split("=", 1)
        parts = left.split(":")
        while len(parts) < 3:
            parts.append("*")
        if len(parts) > 3:
            raise ValueError("mapping rule needs STATE:EVENT[:REGIME]=Pn: %r" % raw)

        def lst(s, allowed):
            if s == "*" or s == "":
                return ()
            vals = tuple(x for x in s.split(",") if x)
            for v in vals:
                if v not in allowed:
                    raise ValueError("unknown token %r in rule %r" % (v, raw))
            return vals
        if pb not in ("P1", "P2", "P3", "P4", "P5", "P6"):
            raise ValueError("rule %r must end in =P1 .. =P6" % raw)
        rules.append(Rule(lst(parts[0], STATES), lst(parts[1], EVENTS), lst(parts[2], REGIMES), pb, r))
    if not rules:
        raise ValueError("empty mapping")
    return rules


def match(rules, state, event, regime):
    for r in rules:
        if (not r.states or state in r.states) and (not r.events or event in r.events) and \
                (not r.regimes or regime in r.regimes):
            return r.pb
    return "P1"


def _num(x):
    s = ("%.6f" % float(x)).rstrip("0").rstrip(".")
    return s if s not in ("-0", "") else "0"


def config_code(playbooks=None, mapping=DEFAULT_MAP, comm=COMMISSION):
    pbs = playbooks or DEFAULT_PLAYBOOKS
    parts = [CODE_TAG, "C=" + _num(comm), "M=" + mapping.replace("\n", ";").replace(" ", "")]
    for k in ("P1", "P2", "P3", "P4", "P5", "P6"):
        p = pbs[k]
        vals = []
        for f in FIELDS:
            v = getattr(p, f)
            vals.append("%s:%s" % (f, v if isinstance(v, str) else _num(v)))
        parts.append("%s=%s" % (k, ",".join(vals)))
    return "|".join(parts)


def parse_code(code):
    """The config code printed by the Pine script (or config_code()) -> (playbooks, rules, comm)."""
    code = code.strip()
    parts = code.split("|")
    if not parts or parts[0] != CODE_TAG:
        raise ValueError("not a %s config code" % CODE_TAG)
    comm, mapping, pbs = COMMISSION, DEFAULT_MAP, {k: Playbook(**{**asdict(v)}) for k, v in DEFAULT_PLAYBOOKS.items()}
    for p in parts[1:]:
        if "=" not in p:
            continue
        k, v = p.split("=", 1)
        if k == "C":
            comm = float(v)
        elif k == "M":
            mapping = v
        elif k in pbs:
            d = asdict(pbs[k])
            for kv in v.split(","):
                if ":" not in kv:
                    continue
                f, val = kv.split(":", 1)
                if f not in FIELDS:
                    raise ValueError("unknown playbook field %s" % f)
                cur = d[f]
                d[f] = val if isinstance(cur, str) else (int(round(float(val))) if isinstance(cur, int) else float(val))
            pbs[k] = Playbook(**d).check()
    return pbs, parse_map(mapping), comm, mapping


# ============================================================================ TradingView's indicators
def tv_atr(h, l, c, n=14):
    """ta.atr(14) = ta.rma(ta.tr(true), 14): the first true range is high - low; seeded with the mean of 14."""
    m = len(c)
    tr = np.empty(m)
    tr[0] = h[0] - l[0]
    if m > 1:
        pc = c[:-1]
        tr[1:] = np.maximum(h[1:] - l[1:], np.maximum(np.abs(h[1:] - pc), np.abs(l[1:] - pc)))
    out = np.full(m, np.nan)
    if m >= n:
        a = tr[:n].mean()
        out[n - 1] = a
        for i in range(n, m):
            a = (a * (n - 1) + tr[i]) / n
            out[i] = a
    return out


def tv_ema(c, n=20):
    """ta.ema: alpha = 2 / (n + 1), seeded with the first value (Pine's reference implementation)."""
    a = 2.0 / (n + 1)
    out = np.empty(len(c))
    e = c[0]
    for i in range(len(c)):
        e = c[i] if i == 0 else a * c[i] + (1 - a) * e
        out[i] = e
    return out


# ============================================================================ fills (TradingView's broker emulator)
def high_first(o, h, l):
    """The emulator's intrabar path: if the high is closer to the open than the low, open -> high -> low -> close."""
    return (h - o) < (o - l)


def fill_stop_limit(o, h, l, trig, lim):
    """A buy stop-limit for this bar (lim None: a plain buy-stop). Returns the fill price or None."""
    if o >= trig:                       # triggered at the open
        if lim is None or o <= lim:
            return o
        return lim if l <= lim else None
    if h >= trig:
        return trig                     # crossed intrabar; trig <= lim
    return None


def fill_limit_buy(o, h, l, lim):
    if o <= lim:
        return o
    return lim if l <= lim else None


def exit_in_bar(o, h, l, stop, tgt):
    """(price, reason) when a protective stop / target order fills in this bar, else None."""
    has_s = stop is not None and np.isfinite(stop)
    has_t = tgt is not None and np.isfinite(tgt)
    if has_s and o <= stop:
        return o, "STOP_GAP"
    if has_t and o >= tgt:
        return o, "TARGET_GAP"
    hit_s = has_s and l <= stop
    hit_t = has_t and h >= tgt
    if hit_s and hit_t:
        return (tgt, "TARGET") if high_first(o, h, l) else (stop, "STOP")
    if hit_s:
        return stop, "STOP"
    if hit_t:
        return tgt, "TARGET"
    return None


def net_of(entry, exitp, comm_pct):
    c = comm_pct / 100.0
    return (exitp - entry - c * (entry + exitp)) / entry


# ============================================================================ one pick
@dataclass
class Bars:
    """One stock's own bars (as its TradingView chart has them) and the indicators the playbooks use."""
    o: np.ndarray
    h: np.ndarray
    l: np.ndarray
    c: np.ndarray
    atr: np.ndarray = field(default=None)
    ema: np.ndarray = field(default=None)

    def __post_init__(self):
        if self.atr is None:
            self.atr = tv_atr(self.h, self.l, self.c)
        if self.ema is None:
            self.ema = tv_ema(self.c)

    @property
    def n(self):
        return len(self.c)


def baseline(b, t, comm):
    """Buy T+1's open; OPEN6 = sell T+6's open, PLAN5 = sell T+5's close."""
    out = {"b_entry": np.nan, "open6_gross": np.nan, "open6_net": np.nan, "plan5_gross": np.nan, "plan5_net": np.nan}
    if t + 1 < b.n:
        e = b.o[t + 1]
        out["b_entry"] = e
        if t + 5 < b.n:
            out["plan5_gross"] = b.c[t + 5] / e - 1.0
            out["plan5_net"] = net_of(e, b.c[t + 5], comm)
        if t + 6 < b.n:
            out["open6_gross"] = b.o[t + 6] / e - 1.0
            out["open6_net"] = net_of(e, b.o[t + 6], comm)
    return out


def simulate_pick(b, t, pb, lvl, comm):
    """The playbook's trade for a pick whose signal close is bar t. lvl: the event level (price) or NaN.
    Returns a dict (status FILLED/NO_FILL/NO_ORDER/NO_LEVEL/SKIP/OPEN_AT_END, entry / exit bars and prices, reason, net)."""
    r = {"status": "", "entry_i": None, "entry_px": np.nan, "exit_i": None, "exit_px": np.nan, "reason": "",
         "net": np.nan, "gross": np.nan, "trig": np.nan, "stop": np.nan, "target": np.nan, "armed": False}
    n = b.n
    E = pb.E
    if E == "SKIP":
        r["status"] = "SKIP"
        return r
    atr_t = b.atr[t]
    entry_i = entry_px = None
    fb_i = None                      # the bar whose open a fallback market order takes (F = OPEN)
    V = int(pb.V)
    last = t
    if E == "OPEN":
        last = t + 1
        if t + 1 < n:
            if pb.G > 0:
                px = fill_limit_buy(b.o[t + 1], b.h[t + 1], b.l[t + 1], b.c[t] * (1 + pb.G / 100.0))
                if px is not None:
                    entry_i, entry_px = t + 1, px
                else:
                    fb_i = t + 2
            else:
                entry_i, entry_px = t + 1, b.o[t + 1]
    elif E == "DELAY":
        last = t + V + 1
        if t + V + 1 < n:
            entry_i, entry_px = t + V + 1, b.o[t + V + 1]
    elif E in ("STLV", "LMLV") and not np.isfinite(lvl):
        r["status"] = "NO_LEVEL"
        fb_i = t + 1
    elif not np.isfinite(atr_t):
        r["status"] = "NO_ATR"
        fb_i = t + 1
    else:
        last = min(t + V, n - 1)
        fixed = None
        if E == "STH":
            fixed = b.h[t] + pb.O * atr_t
        elif E in ("STLV", "LMLV"):
            fixed = lvl + pb.O * atr_t
        elif E == "LMTC":
            fixed = b.c[t] - pb.O * atr_t
        r["trig"] = fixed if fixed is not None else np.nan
        for a in range(t, min(t + V - 1, n - 1) + 1):     # evenings that place an order for bar a + 1
            i = a + 1
            order = None                                  # (trigger, limit): trigger None = a limit buy
            if E in ("STH", "STLV"):
                if not (fixed > b.c[a]):                  # already through: not placed (a = T) / cancelled
                    if a == t:
                        r["status"] = "NO_ORDER"
                    fb_i = a + 1
                    break
                order = (fixed, fixed + pb.L * atr_t if pb.L > 0 else None)
            elif E == "STPD":
                if np.isfinite(b.atr[a]):
                    trig = b.h[a] + pb.O * b.atr[a]
                    if trig > b.c[a]:                     # else: no order this evening
                        order = (trig, trig + pb.L * b.atr[a] if pb.L > 0 else None)
            elif E in ("LMLV", "LMTC"):
                order = (None, fixed)
            elif E == "LMEMA":
                if np.isfinite(b.atr[a]):
                    order = (None, b.ema[a] + pb.O * b.atr[a])
            else:
                raise ValueError(E)
            if i > n - 1:
                break                                     # the order is still working when the data end
            if order is None:
                continue
            if order[0] is None:
                px = fill_limit_buy(b.o[i], b.h[i], b.l[i], order[1])
            else:
                px = fill_stop_limit(b.o[i], b.h[i], b.l[i], order[0], order[1])
            if px is not None:
                entry_i, entry_px = i, px
                break
        if entry_i is None and fb_i is None and t + V <= n - 1:
            fb_i = last + 1                               # the window closed without a fill
    if entry_i is None and pb.F == "OPEN" and fb_i is not None:
        if fb_i >= n:                                     # the fallback's open is not in the data yet
            r["status"] = "OPEN_AT_END"
            return r
        entry_i, entry_px = fb_i, b.o[fb_i]
        r["entry_how"] = "FALLBACK"
    if entry_i is None:
        if not r["status"]:
            r["status"] = "NO_FILL" if (fb_i is not None or (E in ("OPEN", "DELAY") and last < n)) else "OPEN_AT_END"
        return r
    r.setdefault("entry_how", "ORDER")
    r.update(status="FILLED", entry_i=int(entry_i), entry_px=float(entry_px))
    e = entry_i
    px0 = entry_px
    # protective orders, placed at the entry session's close
    stop = np.nan
    if pb.S == "ATR" and np.isfinite(b.atr[e]):
        stop = px0 - pb.SK * b.atr[e]
    elif pb.S == "PCT":
        stop = px0 * (1 - pb.SK / 100.0)
    elif pb.S == "TLOW" and np.isfinite(atr_t):
        stop = b.l[t] - pb.SK * atr_t
    elif pb.S == "LVL" and np.isfinite(lvl) and np.isfinite(atr_t):
        stop = lvl - pb.SK * atr_t
    tgt = np.nan
    if pb.T == "R" and np.isfinite(stop) and px0 > stop:
        tgt = px0 + pb.TK * (px0 - stop)
    elif pb.T == "PCT":
        tgt = px0 * (1 + pb.TK / 100.0)
    r["stop"], r["target"] = stop, tgt
    hi_c = px0
    armed = False
    hold = int(pb.H)
    max_hold = int(pb.EX) if (pb.TR and int(pb.EX) > hold) else hold
    cpct = comm / 100.0

    def close_decisions(j):
        nonlocal hi_c, armed, stop
        hi_c = max(hi_c, b.c[j])
        if pb.TR:
            if not armed and b.c[j] > px0 * (1 + pb.TA / 100.0):
                armed = True
            if armed and np.isfinite(b.atr[j]):
                lvl_t = max(px0 * (1 + 2 * cpct), hi_c - pb.TM * b.atr[j])
                stop = lvl_t if not np.isfinite(stop) else max(stop, lvl_t)

    close_decisions(e)
    j = e
    while True:
        held = j - e + 1                                   # sessions held including bar j
        limit_hold = max_hold if armed else hold
        if held >= limit_hold:
            if pb.X == "CLOSE":
                r.update(exit_i=j, exit_px=float(b.c[j]), reason="TIME")
                break
            if j + 1 >= n:
                r["status"] = "OPEN_AT_END"
                return r
            k = j + 1
            ex = exit_in_bar(b.o[k], b.h[k], b.l[k], stop, tgt)
            if ex is not None and ex[1].endswith("_GAP"):
                reason = ex[1]
                if armed and reason.startswith("STOP"):
                    reason = "TRAIL" + reason[4:]
                r.update(exit_i=k, exit_px=float(ex[0]), reason=reason)
            else:
                r.update(exit_i=k, exit_px=float(b.o[k]), reason="TIME")
            break
        j += 1
        if j >= n:
            r["status"] = "OPEN_AT_END"
            return r
        ex = exit_in_bar(b.o[j], b.h[j], b.l[j], stop, tgt)
        if ex is not None:
            reason = ex[1]
            if armed and reason.startswith("STOP"):
                reason = "TRAIL" + reason[4:]
            r.update(exit_i=j, exit_px=float(ex[0]), reason=reason)
            break
        close_decisions(j)
    r["armed"] = armed
    r["gross"] = r["exit_px"] / px0 - 1.0
    r["net"] = net_of(px0, r["exit_px"], comm)
    return r
