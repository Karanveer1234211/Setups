r"""pine_lint.py - static checks of BigMove_Playbook.pine beyond syntax (TradingView's compiler is not available here).

pynescript parses Pine v5 (syntax only). On its syntax tree this checks what a typo would break on TradingView:
    every built-in function and attribute exists (a whitelist of the v5 names this script uses) and gets only the
    keyword arguments that function takes;
    every name is declared before it is used (Pine has no hoisting; a function sees only the globals above it);
    ':=' and '+=' only on declared variables; no name declared twice in one scope or shadowing an outer one;
    every field read or written on a Pick exists in the type; methods on arrays / maps are real methods;
    user functions are defined before they are called and get no more arguments than they have parameters.
What it cannot check: types (int vs float vs string), series vs simple qualifiers, runtime limits. Those were
written by hand against the v5 reference and need TradingView's compiler: the README says so.
"""
import hashlib
import pickle
import tempfile
from pathlib import Path

NS = {"strategy", "ta", "str", "array", "map", "math", "label", "line", "table", "input", "log", "color", "position",
      "size", "text", "xloc", "yloc", "extend", "display", "barstate", "syminfo", "timeframe", "format", "order",
      "plot", "shape", "location"}
TYPES = {"int", "float", "bool", "string", "color", "label", "line", "table", "array", "map"}
VARS = {"open", "high", "low", "close", "volume", "time", "bar_index", "na", "true", "false", "year", "month",
        "dayofmonth", "last_bar_index"}
STRAT_KW = {"title", "shorttitle", "overlay", "format", "precision", "scale", "pyramiding", "calc_on_order_fills",
            "calc_on_every_tick", "max_bars_back", "backtest_fill_limits_assumption", "default_qty_type",
            "default_qty_value", "initial_capital", "currency", "slippage", "commission_type", "commission_value",
            "process_orders_on_close", "close_entries_rule", "margin_long", "margin_short", "explicit_plot_zorder",
            "max_lines_count", "max_labels_count", "max_boxes_count", "risk_free_rate", "use_bar_magnifier",
            "fill_orders_on_standard_ohlc", "max_polylines_count", "dynamic_requests", "behind_chart"}
INPUT_KW = {"defval", "title", "tooltip", "inline", "group", "confirm", "display"}
FUNCS = {   # v5 function -> keyword arguments it takes (positional use is not checked)
    "strategy": STRAT_KW,
    "strategy.entry": {"id", "direction", "qty", "limit", "stop", "oca_name", "oca_type", "comment", "alert_message",
                       "disable_alert"},
    "strategy.exit": {"id", "from_entry", "qty", "qty_percent", "profit", "limit", "loss", "stop", "trail_price",
                      "trail_points", "trail_offset", "oca_name", "comment", "comment_profit", "comment_loss",
                      "comment_trailing", "alert_message", "alert_profit", "alert_loss", "alert_trailing",
                      "disable_alert"},
    "strategy.close": {"id", "comment", "qty", "qty_percent", "alert_message", "immediately", "disable_alert"},
    "strategy.cancel": {"id"},
    "strategy.opentrades.entry_bar_index": set(), "strategy.opentrades.entry_id": set(),
    "strategy.opentrades.entry_price": set(), "strategy.closedtrades.entry_id": set(),
    "strategy.closedtrades.entry_price": set(), "strategy.closedtrades.exit_price": set(),
    "strategy.closedtrades.exit_bar_index": set(), "strategy.closedtrades.size": set(),
    "strategy.closedtrades.profit": set(),
    "input.text_area": {"defval", "title", "tooltip", "group", "confirm", "display"},
    "input.string": INPUT_KW | {"options"},
    "input.int": INPUT_KW | {"minval", "maxval", "step", "options"},
    "input.float": INPUT_KW | {"minval", "maxval", "step", "options"},
    "input.bool": INPUT_KW,
    "ta.atr": {"length"}, "ta.ema": {"source", "length"},
    "str.split": set(), "str.replace_all": set(), "str.length": set(), "str.startswith": set(),
    "str.substring": set(), "str.contains": set(), "str.tonumber": set(), "str.tostring": set(), "str.upper": set(),
    "array.new_string": set(), "array.new_int": set(), "array.new_float": set(), "array.from": set(),
    "array.sort_indices": set(), "array.new": set(), "map.new": set(),
    "math.max": set(), "math.min": set(), "math.abs": set(), "math.ceil": set(),
    "label.new": {"x", "y", "text", "xloc", "yloc", "color", "style", "textcolor", "size", "textalign", "tooltip",
                  "text_font_family"},
    "label.set_text": set(), "label.set_color": set(), "label.set_tooltip": set(),
    "line.new": {"x1", "y1", "x2", "y2", "xloc", "extend", "color", "style", "width"},
    "table.new": {"position", "columns", "rows", "bgcolor", "frame_color", "frame_width", "border_color",
                  "border_width"},
    "table.cell": {"table_id", "column", "row", "text", "width", "height", "text_color", "text_halign",
                   "text_valign", "text_size", "bgcolor", "tooltip", "text_font_family"},
    "table.clear": set(),
    "color.new": set(), "log.info": set(), "bgcolor": {"color", "offset", "editable", "show_last", "title",
                                                         "display"},
    "int": set(), "float": set(), "na": set(), "nz": set(),
}
ATTRS = {
    "strategy.long", "strategy.cash", "strategy.commission.percent", "strategy.opentrades", "strategy.closedtrades",
    "barstate.isfirst", "barstate.islast", "syminfo.ticker", "syminfo.mintick", "timeframe.isdaily",
    "timeframe.multiplier", "display.none", "xloc.bar_index", "yloc.belowbar", "label.style_label_up",
    "label.style_label_left", "label.style_label_right", "line.style_solid", "line.style_dotted", "line.style_dashed",
    "size.tiny", "size.small", "size.normal", "position.top_left", "position.top_right", "position.bottom_left",
    "position.bottom_right", "text.align_left", "order.ascending", "order.descending", "format.mintick",
    "color.gray", "color.white", "color.blue", "color.red", "color.green", "color.orange", "color.yellow",
    "color.purple", "color.navy", "color.black",
}
ARRAY_METHODS = {"get", "set", "push", "size", "remove", "includes", "insert", "pop", "clear", "indexof"}
MAP_METHODS = {"put", "get", "contains", "size", "remove", "keys", "values", "clear"}


class Lint:
    def __init__(self, A):
        self.A = A
        self.errors = []
        self.scopes = [dict()]          # name -> declared type ('' unknown)
        self.funcs = {}                  # name -> number of parameters
        self.types = {}                  # UDT name -> set of fields
        self.in_func = False

    # ------------------------------------------------------------------ helpers
    def err(self, node, msg):
        ln = getattr(node, "lineno", None)
        self.errors.append("line %s: %s" % (ln if ln is not None else "?", msg))

    def lookup(self, name):
        for sc in reversed(self.scopes):
            if name in sc:
                return sc[name]
        return None

    def declare(self, node, name, typ=""):
        if name in self.scopes[-1]:
            self.err(node, "%r declared twice in one scope" % name)
        elif any(name in sc for sc in self.scopes[:-1]):
            self.err(node, "%r shadows a variable of an outer scope" % name)
        self.scopes[-1][name] = typ

    def dotted(self, node):
        A = self.A
        parts = []
        while isinstance(node, A.Attribute):
            parts.append(node.attr)
            node = node.value
        if isinstance(node, A.Name):
            parts.append(node.id)
            return ".".join(reversed(parts)), node
        return None, node

    def type_name(self, t):
        """Declared type -> 'Pick', 'array<Pick>', 'map', 'array', 'int' ..."""
        A = self.A
        if t is None:
            return ""
        if isinstance(t, A.Name):
            return t.id
        if isinstance(t, A.Specialize):
            base = t.value.id if isinstance(t.value, A.Name) else ""
            arg = t.args
            if isinstance(arg, A.Name):
                return "%s<%s>" % (base, arg.id)
            return base
        return ""

    def value_type(self, v):
        A = self.A
        if isinstance(v, A.Call):
            f = v.func
            if isinstance(f, A.Specialize):
                name, _ = self.dotted(f.value)
                if name == "array.new" and isinstance(f.args, A.Name):
                    return "array<%s>" % f.args.id
                if name == "map.new":
                    return "map"
            name, root = self.dotted(f)
            if name in ("array.new_string", "array.new_int", "array.new_float", "array.from", "array.sort_indices",
                        "str.split"):
                return "array"
            if name and name.endswith(".new") and name.split(".")[0] in self.types:
                return name.split(".")[0]
            if name and "." in name:                         # x.get(i) on array<Pick>
                head, meth = name.rsplit(".", 1)
                t = self.lookup(head) if "." not in head else None
                if t and t.startswith("array<") and meth == "get":
                    return t[6:-1]
        return ""

    # ------------------------------------------------------------------ expressions
    def expr(self, node):
        A = self.A
        if node is None:
            return
        if isinstance(node, list):
            for x in node:
                self.expr(x)
            return
        if isinstance(node, A.Name):
            n = node.id
            if not (self.lookup(n) is not None or n in VARS or n in NS or n in TYPES or n in self.types or
                    n in self.funcs):
                self.err(node, "%r used before it is declared (or misspelled)" % n)
            return
        if isinstance(node, A.Attribute):
            name, root = self.dotted(node)
            if name is None:
                self.expr(root)
                return
            head = name.split(".")[0]
            if head in NS:
                if name not in ATTRS:
                    self.err(node, "unknown built-in %r" % name)
                return
            t = self.lookup(head)
            if t is None and head not in VARS:
                self.err(node, "%r used before it is declared (or misspelled)" % head)
                return
            fields = name.split(".")[1:]
            if t in self.types and fields:
                if fields[0] not in self.types[t]:
                    self.err(node, "%s has no field %r" % (t, fields[0]))
            return
        if isinstance(node, A.Call):
            self.call(node)
            return
        if isinstance(node, A.Specialize):
            return
        # anything else: walk its children
        for fld in getattr(node, "_fields", ()):
            v = getattr(node, fld, None)
            if isinstance(v, (A.AST, list)):
                if isinstance(v, list):
                    for x in v:
                        if isinstance(x, A.AST):
                            self.node(x)
                else:
                    self.node(v)

    def call(self, node):
        A = self.A
        f = node.func
        kws = [a.name for a in node.args if getattr(a, "name", None)]
        for a in node.args:
            self.expr(a.value)
        if isinstance(f, A.Specialize):
            name, _ = self.dotted(f.value)
            if name not in ("array.new", "map.new"):
                self.err(node, "unknown generic call %r" % name)
            args = f.args.elts if isinstance(f.args, A.Tuple) else [f.args]
            for a in args:
                if isinstance(a, A.Name) and a.id not in TYPES and a.id not in self.types:
                    self.err(node, "unknown type %r" % a.id)
            return
        name, root = self.dotted(f)
        if name is None:
            self.err(node, "call of something that is not a name")
            return
        head = name.split(".")[0]
        if head in NS or name in FUNCS:
            if name not in FUNCS:
                self.err(node, "unknown built-in function %r" % name)
                return
            bad = [k for k in kws if k not in FUNCS[name]]
            if bad:
                self.err(node, "%s() takes no keyword argument %s" % (name, ", ".join(bad)))
            return
        if "." not in name:
            if name not in self.funcs:
                self.err(node, "function %r called before it is defined (or misspelled)" % name)
            elif len(node.args) > self.funcs[name]:
                self.err(node, "%s() gets %d arguments, takes %d" % (name, len(node.args), self.funcs[name]))
            return
        # obj.method(...) or Type.new(...)
        obj, meth = name.rsplit(".", 1)
        if obj in self.types:
            if meth != "new":
                self.err(node, "%s.%s is not a type method" % (obj, meth))
            return
        if "." in obj:
            self.err(node, "unsupported call %r" % name)
            return
        t = self.lookup(obj)
        if t is None:
            self.err(node, "%r used before it is declared (or misspelled)" % obj)
            return
        if t.startswith("array") and meth not in ARRAY_METHODS:
            self.err(node, "arrays have no method %r" % meth)
        elif t == "map" and meth not in MAP_METHODS:
            self.err(node, "maps have no method %r" % meth)
        elif not (t.startswith("array") or t == "map") and meth not in ARRAY_METHODS | MAP_METHODS:
            self.err(node, "method %r on %r of unknown type" % (meth, obj))

    # ------------------------------------------------------------------ statements
    def body(self, stmts, declare=None):
        self.scopes.append(dict())
        for n, t in (declare or []):
            self.scopes[-1][n] = t
        for s in stmts or []:
            self.node(s)
        self.scopes.pop()

    def target_store(self, tgt):
        A = self.A
        if isinstance(tgt, A.Name):
            if self.lookup(tgt.id) is None:
                self.err(tgt, "':=' on %r, which is not declared" % tgt.id)
            elif self.in_func and tgt.id in self.scopes[0] and not any(tgt.id in sc for sc in self.scopes[1:]):
                self.err(tgt, "a function cannot assign the global %r" % tgt.id)
        elif isinstance(tgt, A.Attribute):
            a = A.Attribute(value=tgt.value, attr=tgt.attr, ctx=A.Load())
            a.lineno = getattr(tgt, "lineno", None)
            self.expr(a)
        else:
            self.err(tgt, "unsupported assignment target")

    def node(self, n):
        A = self.A
        if isinstance(n, A.Expr):
            self.node(n.value)
        elif isinstance(n, A.Assign):
            self.expr(n.value)
            t = self.type_name(getattr(n, "type", None)) or self.value_type(n.value)
            if isinstance(n.target, A.Name):
                self.declare(n, n.target.id, t)
            elif isinstance(n.target, A.Tuple):
                for e in n.target.elts:
                    self.declare(n, e.id, "")
        elif isinstance(n, (A.ReAssign, A.AugAssign)):
            self.expr(n.value)
            self.target_store(n.target)
        elif isinstance(n, A.If):
            self.expr(n.test)
            self.body(n.body)
            orelse = n.orelse or []
            if len(orelse) == 1 and isinstance(orelse[0], (A.If,)):
                self.node(orelse[0])
            elif len(orelse) == 1 and isinstance(orelse[0], A.Expr) and isinstance(orelse[0].value, A.If):
                self.node(orelse[0].value)
            else:
                self.body(orelse)
        elif isinstance(n, A.ForTo):
            self.expr(n.start)
            self.expr(n.end)
            self.expr(getattr(n, "step", None))
            if self.lookup(n.target.id) is not None:
                self.err(n, "loop counter %r shadows a variable" % n.target.id)
            self.body(n.body, [(n.target.id, "int")])
        elif isinstance(n, A.ForIn):
            self.expr(n.iter)
            it = self.lookup(n.iter.id) if isinstance(n.iter, A.Name) else ""
            el = it[6:-1] if it and it.startswith("array<") else ""
            if isinstance(n.target, A.Tuple):
                names = [(n.target.elts[0].id, "int"), (n.target.elts[1].id, el)]
            else:
                names = [(n.target.id, el)]
            for nm, _ in names:
                if self.lookup(nm) is not None:
                    self.err(n, "loop variable %r shadows a variable" % nm)
            self.body(n.body, names)
        elif isinstance(n, A.While):
            self.expr(n.test)
            self.body(n.body)
        elif isinstance(n, A.Switch):
            self.expr(getattr(n, "subject", None))
            for c in n.cases:
                self.expr(getattr(c, "pattern", None))
                self.body(c.body)
        elif isinstance(n, A.FunctionDef):
            if n.name in self.funcs or self.lookup(n.name) is not None:
                self.err(n, "function %r defined twice / clashes with a variable" % n.name)
            params = [(p.name, self.type_name(getattr(p, "type", None))) for p in n.args]
            saved, self.scopes = self.scopes, [dict(self.scopes[0])]
            self.in_func = True
            self.body(n.body, params)
            self.in_func = False
            self.scopes = saved
            self.funcs[n.name] = len(params)
        elif isinstance(n, A.TypeDef):
            self.types[n.name] = {a.target.id for a in n.body if isinstance(a, A.Assign)}
        elif isinstance(n, (A.Break, A.Continue)):
            pass
        else:
            self.expr(n)


def parse_cached(src, log=print):
    """pynescript's tree of the source (cached by content hash: the parse takes minutes)."""
    from pynescript.ast import parse
    h = hashlib.sha256(src.encode("utf-8")).hexdigest()[:20]
    cache = Path(tempfile.gettempdir()) / ("pb_pine_ast_%s.pkl" % h)
    if cache.exists():
        try:
            return pickle.loads(cache.read_bytes())
        except Exception:
            pass
    tree = parse(src)
    try:
        cache.write_bytes(pickle.dumps(tree))
    except Exception:
        pass
    return tree


def lint(src):
    """[] when clean, else the problems. Raises ImportError when pynescript is not installed."""
    import pynescript.ast as A
    tree = parse_cached(src)
    L = Lint(A)
    for s in tree.body:
        L.node(s)
    return L.errors
