r"""pine_twin.py - the Pine strategy's logic for one pick, bar by bar, with a minimal TradingView broker emulator.

BigMove_Playbook.pine is a transliteration of run_twin() below (same states, same order of steps at each close).
pb_core.simulate_pick() is an independent window-loop implementation of the same rules. The tests run both on
thousands of random bar paths and playbooks and require identical trades: a disagreement is a bug in one of them.

Broker (TradingView, daily bars, no bar magnifier, orders placed at a close act from the next bar):
    an open position: a 'close at the next open' order fills at the open first; else the exit orders (stop / target)
    via the path rule; a pending entry: market at the open, limit, stop, stop-limit (pb_core's fill helpers).
"""
import math

import numpy as np

import pb_core as P

WAIT, WORK, IN, DONE = "WAIT", "WORK", "IN", "DONE"
FINAL = ("SKIP", "NO_ORDER", "NO_LEVEL", "NO_ATR", "NO_FILL")


class Broker:
    def __init__(self, b):
        self.b = b
        self.entry = None          # ("MKT"|"LMT"|"STP"|"STL", trig, lim), active from the bar after it is placed
        self.pos = None            # (entry_i, px)
        self.exit = None           # (stop, tgt)
        self.close_next = False
        self.closed = None         # (exit_i, px, how)

    # orders (called by the script at a close)
    def place(self, kind, trig=np.nan, lim=np.nan):
        self.entry = (kind, trig, lim)

    def cancel(self):
        self.entry = None

    def set_exit(self, stop, tgt):
        self.exit = (stop, tgt)

    def close_at_open(self):
        self.close_next = True

    def close_now(self, i):
        self.closed = (i, float(self.b.c[i]), "NOW")
        self.pos = None

    # one bar of the emulator (before the script runs at its close)
    def bar(self, i):
        o, h, l = self.b.o[i], self.b.h[i], self.b.l[i]
        if self.pos is not None and self.pos[0] < i:
            if self.close_next:
                self.closed = (i, float(o), "OPEN")
                self.pos = None
                return
            if self.exit is not None:
                ex = P.exit_in_bar(o, h, l, self.exit[0], self.exit[1])
                if ex is not None:
                    self.closed = (i, float(ex[0]), ex[1])
                    self.pos = None
            return
        if self.entry is not None and self.pos is None and self.closed is None:
            kind, trig, lim = self.entry
            if kind == "MKT":
                px = o
            elif kind == "LMT":
                px = P.fill_limit_buy(o, h, l, lim)
            elif kind == "STP":
                px = P.fill_stop_limit(o, h, l, trig, None)
            else:
                px = P.fill_stop_limit(o, h, l, trig, lim)
            if px is not None:
                self.pos = (i, float(px))
                self.entry = None


def run_twin(b, t, pb, lvl, comm):
    """Same result dict as pb_core.simulate_pick."""
    n = b.n
    r = {"status": "", "entry_i": None, "entry_px": np.nan, "exit_i": None, "exit_px": np.nan, "reason": "",
         "net": np.nan, "gross": np.nan, "trig": np.nan, "stop": np.nan, "target": np.nan, "armed": False,
         "entry_how": ""}
    br = Broker(b)
    st = WAIT
    why = ""                     # NO_ORDER / NO_LEVEL / NO_ATR / NO_FILL (kept if there is no fallback)
    mode = ""                    # "MKT": a market order is pending (fills at the next open)
    how = "ORDER"
    E, V = pb.E, int(pb.V)
    trig = lim = np.nan
    atrT = b.atr[t]
    ebar = None
    epx = stop = tgt = hic = np.nan
    armed = False
    txbar = None
    hold = int(pb.H)
    max_hold = int(pb.EX) if (pb.TR and int(pb.EX) > hold) else hold
    cpct = comm / 100.0

    def stl(tr, atr_now):
        return ("STL", tr, tr + pb.L * atr_now) if pb.L > 0 else ("STP", tr, np.nan)

    def fallback(reason):
        nonlocal st, why, mode, how
        why = reason
        if pb.F == "OPEN":
            br.place("MKT")
            mode, how, st = "MKT", "FALLBACK", WORK
        else:
            st = reason

    for i in range(t, n):
        if i > t:
            br.bar(i)
        k = i - t
        # ---- detection (what the broker did during bar i)
        if st == WORK and br.pos is not None and br.pos[0] == i:
            st, ebar, epx = IN, i, br.pos[1]
        if st == IN and br.closed is not None:
            xi, xpx, xhow = br.closed
            st = DONE
            if xhow == "OPEN":
                reason = "TIME"
                if np.isfinite(stop) and b.o[xi] <= stop:
                    reason = "STOP_GAP"
                elif np.isfinite(tgt) and b.o[xi] >= tgt:
                    reason = "TARGET_GAP"
            elif xhow == "NOW":
                reason = "TIME"
            else:
                reason = xhow
            if armed and reason.startswith("STOP"):
                reason = "TRAIL" + reason[4:]
            r.update(exit_i=xi, exit_px=xpx, reason=reason)
            break
        # ---- the script at close i
        if k == 0:
            if E == "SKIP":
                st = "SKIP"
            elif E == "OPEN":
                st = WORK
                if pb.G > 0:
                    lim = b.c[t] * (1 + pb.G / 100.0)
                    br.place("LMT", lim=lim)
                else:
                    br.place("MKT")
                    mode = "MKT"
            elif E == "DELAY":
                st = WORK
            elif E in ("STLV", "LMLV") and not np.isfinite(lvl):
                fallback("NO_LEVEL")
            elif not np.isfinite(atrT):
                fallback("NO_ATR")
            else:
                st = WORK
                if E in ("STH", "STLV"):
                    trig = (b.h[t] if E == "STH" else lvl) + pb.O * atrT
                    if trig > b.c[t]:
                        br.place(*stl(trig, atrT))
                    else:
                        fallback("NO_ORDER")
                elif E == "STPD":
                    tr = b.h[t] + pb.O * atrT
                    if tr > b.c[t]:
                        br.place(*stl(tr, atrT))
                elif E in ("LMLV", "LMTC"):
                    lim = (lvl + pb.O * atrT) if E == "LMLV" else (b.c[t] - pb.O * atrT)
                    br.place("LMT", lim=lim)
                elif E == "LMEMA":
                    br.place("LMT", lim=b.ema[t] + pb.O * atrT)
        elif st == WORK and mode != "MKT":
            if E == "OPEN":                                   # the gap-capped limit had its one session
                br.cancel()
                fallback("NO_FILL")
            elif E == "DELAY":
                if k == V:
                    br.place("MKT")
                    mode = "MKT"
            elif k >= V:                                      # the window is over
                br.cancel()
                fallback("NO_FILL")
            elif E in ("STH", "STLV"):
                if not (trig > b.c[i]):                       # already through: cancelled
                    br.cancel()
                    fallback("NO_FILL")
            elif E == "STPD":
                if np.isfinite(b.atr[i]) and b.h[i] + pb.O * b.atr[i] > b.c[i]:
                    br.place(*stl(b.h[i] + pb.O * b.atr[i], b.atr[i]))
                else:
                    br.cancel()
            elif E == "LMEMA":
                if np.isfinite(b.atr[i]):
                    br.place("LMT", lim=b.ema[i] + pb.O * b.atr[i])
                else:
                    br.cancel()
        if st == IN:
            if i == ebar:
                if pb.S == "ATR" and np.isfinite(b.atr[i]):
                    stop = epx - pb.SK * b.atr[i]
                elif pb.S == "PCT":
                    stop = epx * (1 - pb.SK / 100.0)
                elif pb.S == "TLOW" and np.isfinite(atrT):
                    stop = b.l[t] - pb.SK * atrT
                elif pb.S == "LVL" and np.isfinite(lvl) and np.isfinite(atrT):
                    stop = lvl - pb.SK * atrT
                if pb.T == "R" and np.isfinite(stop) and epx > stop:
                    tgt = epx + pb.TK * (epx - stop)
                elif pb.T == "PCT":
                    tgt = epx * (1 + pb.TK / 100.0)
                hic = epx
            hic = max(hic, b.c[i])
            if pb.TR:
                if not armed and b.c[i] > epx * (1 + pb.TA / 100.0):
                    armed = True
                if armed and np.isfinite(b.atr[i]):
                    lv = max(epx * (1 + 2 * cpct), hic - pb.TM * b.atr[i])
                    stop = lv if not np.isfinite(stop) else max(stop, lv)
            if np.isfinite(stop) or np.isfinite(tgt):
                br.set_exit(stop, tgt)
            held = i - ebar + 1
            if held >= (max_hold if armed else hold) and txbar is None:
                txbar = i
                if pb.X == "CLOSE":
                    br.close_now(i)
                    st = DONE
                    r.update(exit_i=i, exit_px=float(b.c[i]), reason="TIME")
                    break
                br.close_at_open()
        if st in FINAL:
            break
    # ---- the result
    r["trig"] = trig if E in ("STH", "STLV") else (lim if E in ("LMLV", "LMTC") else np.nan)
    if st in FINAL:
        r["status"] = st
        return r
    if st in (WAIT, WORK):
        r["status"] = "OPEN_AT_END"
        return r
    if st == IN:
        r.update(status="OPEN_AT_END", entry_i=int(ebar), entry_px=float(epx))
        return r
    r.update(status="FILLED", entry_i=int(ebar), entry_px=float(epx), entry_how=how, stop=stop, target=tgt,
             armed=armed)
    r["gross"] = r["exit_px"] / epx - 1.0
    r["net"] = P.net_of(epx, r["exit_px"], comm)
    return r
