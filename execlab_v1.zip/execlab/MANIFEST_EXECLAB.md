# MANIFEST - execlab v1.0 (1 Nov 2026)

Copy the whole folder to C:\Users\karanvsi\PyCharmMiscProject\execlab\ (next to v2engine, tradelab, pathlab).
Nothing else changes: no file of bigmove_deploy, tradelab, pathlab, v2engine or playbook is replaced.

| file | lines | bytes | sha256 (first 16) |
|---|---|---|---|
| execlab.py | 568 | 28990 | 6a5c6da0cd1ead7c |
| xl_common.py | 287 | 11439 | 2e75f789e58a4637 |
| xl_data.py | 105 | 4574 | 069c8c0f88676c22 |
| xl_feat.py | 210 | 8921 | 2ea09a7dd5f7ee12 |
| xl_sim.py | 262 | 13022 | 439a44412ede518a |
| xl_learn.py | 507 | 23141 | f5ce660cb6b44e57 |
| xl_ledger.py | 222 | 9697 | cc5b33940ddedd3d |
| xl_eval.py | 231 | 11618 | 4a814b47dfbd4f7a |
| xl_cards.py | 92 | 3604 | 547698d571f62bda |
| xl_report.py | 195 | 11885 | 9c8945b2984acd42 |
| XL_DECLARATION.json | 190 | 7124 | 54d57296ab10739b |
| env_execlab.bat | 37 | 1601 | 72a6735d664cdd1e |
| README_EXECLAB.md | 145 | 11030 | 846e434885ed849a |
| tests\test_execlab.py | 726 | 38343 | 88aebba1b3c31cc4 |
| tests\xl_world.py | 239 | 11031 | 9a8a2a6d2755813a |
| tests\xl_mutate.py | 73 | 5677 | ccd696b4ca23ab3a |

Needs: Python 3.10+, numpy, pandas, scikit-learn (any recent; 1.5.2 and 1.9.1 tested), v2engine 0.3 (drop 3),
tradelab v1.3.1, pathlab v1.0 (read only, through env_v2.bat).

Verified 1 Nov 2026: 37 checks, 0 failed (full and quick) on Python 3.13 / numpy 2.5.3 / pandas 3.0.5 / scikit-learn 1.9.1; 37 checks, 0 failed (quick) on Python 3.12 / numpy 2.4.1 / pandas 2.3.3 / scikit-learn 1.5.2; 22 of 22 planted bugs caught (tests\xl_mutate.py). Not yet run on Karan's cache.
