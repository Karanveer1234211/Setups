r"""xl_world.py - synthetic worlds for execlab's tests: daily bars (and 3-minute bars on entry sessions) with planted
effects that a correct engine must find, and worlds where they are absent.

Planted (each keyed on what is known at the selection's close T; drifts are added to the daily log returns):
  (one effect per selection, first match: abandon, entry, tail, exit)
  abandon  a failed breakout (FAILED_BREAKOUT:FAILED) at T: T+1..T+10 fall 1.5% a day (do not trade)
  entry    tl_state bull states (S01-S03): T+1..T+2 fall 2% a day, T+3..T+12 rise 1% a day (waiting / a dip limit
           beats the open);  bear states (S08 / S09): T+1..T+5 rise 1.5% a day (the open is right)
  tail     the top 10% of raw scores in bull states: +0.8% a day for 25 more sessions after the rally (hold the winner)
  exit     turn / flat states (S06 / S07): T+1..T+3 rise 1.5% a day, T+4..T+15 fall 1.2% a day (exit early)
  intraday a new breakout (BREAKOUT:NEW) at T: on T+1 the first 30 minutes fall 1.2%, back by 11:00 (a 10:00 entry
           beats the open); every other pick's T+1 rises 0.4% in its first 45 minutes (waiting costs); 3-minute bars
           exist for every session and the daily bar is built from them
  absent   none of the above (random walks)
"""
from types import SimpleNamespace

import numpy as np

import v2_core as C
import v2_money as M

STATE_POOL = (1, 2, 3, 6, 7, 8, 9)
EVENT_POOL = (0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8)
NB = 125


def business_days(start, n):
    d = np.datetime64(start, "D")
    out = []
    while len(out) < n:
        if np.is_busday(d):
            out.append(d)
        d += np.timedelta64(1, "D")
    return np.array(out, dtype="datetime64[D]")


def _blocks(rng, n, pool, lo=30, hi=80):
    out = np.zeros(n, dtype=np.int64)
    starts = []
    i = 0
    while i < n:
        L = int(rng.integers(lo, hi))
        out[i:i + L] = pool[int(rng.integers(0, len(pool)))]
        starts.append(i)
        i += L
    return out, starts


class DenseLite:
    def __init__(self, days, O, H, L, C_, V):
        self.days, self.O, self.H, self.L, self.C, self.V = days, O, H, L, C_, V
        self.present = np.isfinite(O)
        self.usable = np.ones(len(days), bool)
        self.pos = {d: i for i, d in enumerate(days.tolist())}


def make_world(effects=("entry", "abandon", "exit", "tail"), n_days=700, n_sym=90, picks=3, seed=1,
               start="2020-01-01", sigma=0.018, gap_sd=0.005, engines=("D", "ENS"), pick_run="PM_XLSYN",
               scale=None, perturb_after=None, perturb_seed=99, locks=0.0):
    """effects: subset of entry / abandon / exit / tail / intraday ('absent' = none). scale: {symbol: factor} multiplies
    that stock's prices (scale-invariance test). perturb_after: a calendar index after which every bar is redrawn
    (the leak test). locks: probability of a lower-locked session (lock rules)."""
    effects = tuple(e for e in effects if e != "absent")
    rng = np.random.default_rng(seed)
    days = business_days(start, n_days)
    cal = C.SessionCalendar(days.tolist())
    n = cal.n
    syms = ["S%03d" % k for k in range(n_sym)]
    st = np.zeros((n_sym, n), np.int64)
    ev = np.zeros((n_sym, n), np.int64)
    age = np.full((n_sym, n), -1, np.int64)
    for k in range(n_sym):
        st[k], _ = _blocks(rng, n, STATE_POOL)
        ev[k], starts = _blocks(rng, n, EVENT_POOL, 5, 25)
        bs = np.zeros(n, np.int64)
        for s0 in starts:
            bs[s0:] = s0
        age[k] = np.where(ev[k] > 0, np.arange(n) - bs, -1)
    regime, _ = _blocks(rng, n, (0, 1, 2, 3, 4), 40, 120)
    drift = np.zeros((n_sym, n))
    intra = np.zeros((n_sym, n), bool)
    intra_up = np.zeros((n_sym, n), bool)
    sels = []
    warm = 70
    for eng in engines:
        for t in range(warm, n - 1):
            ks = rng.choice(n_sym, size=picks, replace=False)
            for rk, k in enumerate(ks, 1):
                score = float(rng.normal())
                sels.append((eng, rk, t, int(k), score))
    scores = np.array([s[4] for s in sels])
    top = np.quantile(scores, 0.9) if len(scores) else np.inf
    for eng, rk, t, k, score in sels:          # one effect per selection, in this order
        g = st[k, t]
        e_ = ev[k, t]
        if "intraday" in effects and t + 1 < n:
            if e_ == 1:
                intra[k, t + 1] = True
            else:
                intra_up[k, t + 1] = True
        if "abandon" in effects and e_ == 4:
            drift[k, t + 1:t + 11] += -0.015
        elif "entry" in effects and g in (1, 2, 3):
            drift[k, t + 1:t + 3] += -0.020
            drift[k, t + 3:t + 13] += 0.010
            if "tail" in effects and score >= top:
                drift[k, t + 13:t + 38] += 0.008
        elif "tail" in effects and g in (1, 2, 3) and score >= top:
            drift[k, t + 3:t + 33] += 0.008
        elif "entry" in effects and g in (8, 9):
            drift[k, t + 1:t + 6] += 0.015
        elif "exit" in effects and g in (6, 7):
            drift[k, t + 1:t + 4] += 0.015
            drift[k, t + 4:t + 16] += -0.012
    eps = rng.normal(0, sigma, (n_sym, n))
    gap = rng.normal(0, gap_sd, (n_sym, n))
    wig = np.abs(rng.normal(0, 0.006, (n_sym, n, 2)))
    vol = np.exp(rng.normal(13.5, 0.4, (n_sym, n)))
    if perturb_after is not None:
        r2 = np.random.default_rng(perturb_seed)
        a = int(perturb_after) + 1
        eps[:, a:] = r2.normal(0, sigma * 1.7, (n_sym, n - a))
        gap[:, a:] = r2.normal(0.004, gap_sd * 3, (n_sym, n - a))
        wig[:, a:] = np.abs(r2.normal(0, 0.012, (n_sym, n - a, 2)))
        vol[:, a:] = np.exp(r2.normal(14.0, 0.8, (n_sym, n - a)))
        drift[:, a:] = r2.normal(0, 0.01, (n_sym, n - a))
    p0 = np.exp(rng.uniform(np.log(80), np.log(900), n_sym))
    bars = C.BarStore(cal)
    dense = {}
    ll = rng.random((n_sym, n)) < locks
    for k, s in enumerate(syms):
        lr = drift[k] + eps[k] - gap[k]
        c = np.empty(n)
        o = np.empty(n)
        prev = p0[k]
        for i in range(n):
            o[i] = prev * np.exp(gap[k, i])
            c[i] = o[i] * np.exp(lr[i])
            prev = c[i]
        h = np.maximum(o, c) * np.exp(wig[k, :, 0])
        l_ = np.minimum(o, c) * np.exp(-wig[k, :, 1])
        rows = np.flatnonzero(intra[k]) if "intraday" in effects else np.array([], int)
        if "intraday" in effects:
            rows = np.flatnonzero(np.ones(n, bool))[warm:]          # every session gets 3-minute bars
            O3, H3, L3, C3, V3 = (np.full((len(rows), NB), np.nan) for _ in range(5))
            for q, i in enumerate(rows):
                steps = rng.normal(0, 0.0015, NB)
                path = np.cumsum(steps)
                if intra[k, i]:
                    shape = np.r_[np.linspace(0, -0.012, 11), np.linspace(-0.012, 0.0, 25), np.zeros(NB - 36)]
                    path = path + shape[:NB]
                elif intra_up[k, i]:
                    shape = np.r_[np.linspace(0, 0.004, 16), np.full(NB - 16, 0.004)]
                    path = path + shape[:NB]
                target = np.log(c[i] / o[i])
                path = path - np.linspace(0, 1, NB) * (path[-1] - target)
                cl = o[i] * np.exp(path)
                op = np.r_[o[i], cl[:-1]]
                hi_ = np.maximum(op, cl) * np.exp(np.abs(rng.normal(0, 0.0005, NB)))
                lo_ = np.minimum(op, cl) * np.exp(-np.abs(rng.normal(0, 0.0005, NB)))
                O3[q], H3[q], L3[q], C3[q], V3[q] = op, hi_, lo_, cl, vol[k, i] / NB
                h[i], l_[i], c[i] = hi_.max(), lo_.min(), cl[-1]
            dense[s] = DenseLite(days[rows], O3, H3, L3, C3, V3)
        f = (scale or {}).get(s, 1.0)
        rec = {"open": o * f, "high": h * f, "low": l_ * f, "close": c * f, "volume": vol[k] / f,
               "upper_locked": np.zeros(n, bool), "lower_locked": np.zeros(n, bool)}
        if locks:
            lk = ll[k]
            rec["ll_open"] = lk.copy()
            rec["ll_close"] = lk.copy()
            rec["lower_locked"] = lk & False
        bars.put_arrays(s, rec)
        M.prepare_bars(bars[s])
    reg = C.SelectionRegistry(cal)
    for eng, rk, t, k, score in sels:
        reg.add(pick_run, eng, rk, days[t], syms[k], score,
                {"state": int(st[k, t]), "event": int(ev[k, t]), "age": int(age[k, t]), "regime": int(regime[t])})
    D = SimpleNamespace()
    D.cal, D.bars, D.registry = cal, bars, reg
    D.ctx = {s: {"state": st[k], "event": ev[k], "age": age[k]} for k, s in enumerate(syms)}
    D.regime = regime
    nifty = 10000 * np.exp(np.cumsum(rng.normal(0, 0.01, n)))
    small = 8000 * np.exp(np.cumsum(rng.normal(0, 0.012, n)))
    vix = 15 * np.exp(np.cumsum(rng.normal(0, 0.03, n)))
    if perturb_after is not None:
        a = int(perturb_after) + 1
        for x in (nifty, small, vix):
            x[a:] *= np.exp(np.cumsum(r2.normal(0, 0.05, n - a)))
        regime[a:] = r2.integers(0, 5, n - a)
        for k in range(n_sym):
            st[k, a:] = r2.choice(STATE_POOL, n - a)
            ev[k, a:] = r2.choice(EVENT_POOL, n - a)
    D.index_bars = {"nifty": {"high": nifty, "close": nifty}, "small": {"high": small, "close": small}}
    D.vix = vix
    D.cm = M.CostModel(cal.days)
    D.info = {"synthetic": list(effects), "seed": seed}
    D.sealed_end = None
    from xl_data import DictIntraday
    D.intraday = DictIntraday(dense)
    D.events = {}
    return D


def cut(D, seal_end):
    """The same world as loaded with a seal: nothing after seal_end exists."""
    k = int(np.searchsorted(D.cal.days, np.datetime64(seal_end, "D"), side="right"))
    E = SimpleNamespace()
    E.cal = C.SessionCalendar(D.cal.days[:k].tolist())
    E.bars = C.BarStore(E.cal)
    for s in D.bars.symbols():
        b = D.bars[s]
        rec = {f: np.asarray(b[f])[:k].copy() for f in ("open", "high", "low", "close", "volume", "upper_locked",
                                                         "lower_locked") }
        for f in ("ll_open", "ll_close"):
            if f in b:
                rec[f] = np.asarray(b[f])[:k].copy()
        E.bars.put_arrays(s, rec)
        M.prepare_bars(E.bars[s])
    E.registry = C.SelectionRegistry(E.cal)
    for s in D.registry.active():
        if s.t_idx < k:
            E.registry.add(s.pick_run, s.engine, s.rank, s.T, s.symbol, s.raw_score, s.snap())
    E.ctx = {s: {kk: np.asarray(v)[:k].copy() for kk, v in c.items()} for s, c in D.ctx.items()}
    E.regime = np.asarray(D.regime)[:k].copy()
    E.index_bars = {kk: {f: np.asarray(v[f])[:k].copy() for f in v} for kk, v in D.index_bars.items()}
    E.vix = None if D.vix is None else np.asarray(D.vix)[:k].copy()
    E.cm = M.CostModel(E.cal.days)
    E.info = dict(D.info, sealed_end=str(seal_end))
    E.sealed_end = str(seal_end)
    from xl_data import DictIntraday
    lim = np.datetime64(seal_end, "D")
    dd = {}
    for s, dn in D.intraday.d.items():
        m = dn.days <= lim
        dd[s] = DenseLite(dn.days[m], dn.O[m], dn.H[m], dn.L[m], dn.C[m], dn.V[m])
    E.intraday = DictIntraday(dd)
    E.events = {}
    return E
