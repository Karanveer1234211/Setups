r"""xl_mutate.py - plants one bug at a time in a copy of execlab and requires the suite to catch it.

  python tests\xl_mutate.py          every mutation (unit checks for most; the planted / absent world or the CLI
                                     for the learning and seal mutations)
  python tests\xl_mutate.py twice    only the mutations whose name contains 'twice'
"""
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

MUTATIONS = [
    ("limit fills on a touch", "xl_sim.py", "f = ok & np.isfinite(lim) & (l < lim)", "f = ok & np.isfinite(lim) & (l <= lim)", "unit"),
    ("buy-stop slippage sign", "xl_sim.py", "np.maximum(o[f], trig[f]) + stop_slip * atr[f]", "np.maximum(o[f], trig[f]) - stop_slip * atr[f]", "unit"),
    ("buy on an upper-locked bar", "xl_sim.py", "ok &= np.isfinite(o) & ~B.ul[j, ii] & B.entry_ok[ii]", "ok &= np.isfinite(o) & B.entry_ok[ii]", "unit"),
    ("exit ignores the lock wait", "xl_sim.py", "k = np.where(inb, B.nxt_open[j, nxc], -1)", "k = np.where(inb, nxc, -1)", "unit"),
    ("stop fills on a frozen bar", "xl_sim.py", "live = sel & inb & np.isfinite(o) & np.isfinite(stp) & ~B.lk[j, nxc]", "live = sel & inb & np.isfinite(o) & np.isfinite(stp)", "unit"),
    ("target fills on a touch", "xl_sim.py", "ins = live & ~(o >= tp) & (h > tp)", "ins = live & ~(o >= tp) & (h >= tp)", "unit"),
    ("stock feature looks ahead", "xl_feat.py", "F[:, 0], F[:, 1], F[:, 2], F[:, 3], F[:, 4] = (_lagret(c, k) for k in (1, 3, 5, 10, 20))", "F[:, 0], F[:, 1], F[:, 2], F[:, 3], F[:, 4] = (np.r_[_lagret(c, k)[1:], np.nan] for k in (1, 3, 5, 10, 20))", "unit"),
    ("market feature looks ahead", "xl_feat.py", "M[:, 6] = _lagret(vx, 5)", "M[:, 6] = np.r_[_lagret(vx, 5)[1:], np.nan]", "unit"),
    ("a raw price level as a feature", "xl_feat.py", "F[:, 5] = atr / c", "F[:, 5] = atr", "unit"),
    ("hold continuation inverted", "xl_learn.py", "cont = C[:, h + 1] / C[:, h] * (1.0 + V[:, h + 1]) - 1.0 - rent", "cont = C[:, h] / C[:, h + 1] * (1.0 + V[:, h + 1]) - 1.0 - rent", "unit"),
    ("hurdle ignored", "xl_learn.py", "NETm[q, k] - hurdle, nxt)", "NETm[q, k], nxt)", "unit"),
    ("no purge", "xl_common.py", "train = np.flatnonzero((t + horizon < a) | (t > b + horizon))", "train = np.flatnonzero((t < a) | (t > b))", "unit"),
    ("bootstrap interval quantiles", "xl_common.py", 'out["lo"], out["hi"] = float(np.quantile(bs, 0.025)), float(np.quantile(bs, 0.975))', 'out["lo"], out["hi"] = float(np.quantile(bs, 0.25)), float(np.quantile(bs, 0.75))', "unit"),
    ("daily entry budget ignored", "xl_ledger.py", 'budget = max(0, min(int(pf["max_entries_day"]), b5, int(pf["max_open"]) - open_after))', 'budget = max(0, min(99, b5, int(pf["max_open"]) - open_after))', "unit"),
    ("one per stock ignored", "xl_ledger.py", "if s in hsyms or s in today:", "if False:", "unit"),
    ("five-session window too short", "xl_ledger.py", 'entries[max(0, i - 3):i + 1]', 'entries[max(0, i - 2):i + 1]', "unit"),
    ("OPEN6 comparator is CLOSE5", "xl_sim.py", 'd6 = C.plan_detail(b, B.cal, int(recs["t"][q]), "OPEN6")', 'd6 = C.plan_detail(b, B.cal, int(recs["t"][q]), "CLOSE5")', "unit"),
    ("trade net is gross", "xl_sim.py", 'float(P[q]), int(x[q]), float(px[q]))["net"]', 'float(P[q]), int(x[q]), float(px[q]))["gross"]', "unit"),
    ("evaluation in sample", "xl_learn.py", "fold = np.full(len(r), -1) if full else world.fold[r]", "fold = np.full(len(r), -1)", "only=x13"),
    ("advantages not paired", "xl_learn.py", "    if qs.ref is not None:                       # paired", "    if False:                       # paired", "only=x12"),
    ("discovery loads the sealed years", "execlab.py", "    D = loader(a, decl, t_from, t_to, t_to, log)\n    if np.datetime64", "    D = loader(a, decl, t_from, t_to, None, log)\n    if np.datetime64", "only=x16"),
    ("evaluate twice", "execlab.py", '    if list(out.glob("eval_*")):\n        why.append("the sealed evaluation already ran', '    if False:\n        why.append("the sealed evaluation already ran', "only=x16"),
]


def main():
    pick = [a for a in sys.argv[1:]]
    todo = [m for m in MUTATIONS if not pick or any(k in m[0] for k in pick)]
    tmp = Path(tempfile.mkdtemp(prefix="xlmut_"))
    caught = 0
    try:
        for name, fn, old, new, mode in todo:
            d = tmp / "execlab"
            if d.exists():
                shutil.rmtree(d)
            shutil.copytree(ROOT, d, ignore=shutil.ignore_patterns("__pycache__"))
            src = (d / fn).read_text(encoding="utf-8")
            if src.count(old) != 1:
                print("  SKIP?  %s: the original text is not unique in %s (%d)" % (name, fn, src.count(old)))
                continue
            (d / fn).write_text(src.replace(old, new), encoding="utf-8")
            env = dict(os.environ)
            r = subprocess.run([sys.executable, str(d / "tests" / "test_execlab.py"), "quick", mode], cwd=str(d),
                               env=env, capture_output=True, text=True)
            fails = [ln.strip()[:110] for ln in r.stdout.splitlines() if ln.startswith("  FAIL")][:2]
            ok = r.returncode != 0 and bool(fails)          # a crash is not a catch
            caught += ok
            print("  %s  %s   %s" % ("caught" if ok else "MISSED", name, fails if ok else
                                        (r.stdout.splitlines()[-2:] + r.stderr.splitlines()[-2:])), flush=True)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("%d of %d planted bugs caught" % (caught, len(todo)))
    return 0 if caught == len(todo) else 1


if __name__ == "__main__":
    sys.exit(main())
