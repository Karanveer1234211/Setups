# execlab v1.0 - the execution research engine on BigMove's selections

Built 1 Nov 2026. For every D and ENS selection (top 3 a day), execlab decides at each close of its ten-session
watch window whether to buy tomorrow (and with which order), wait, or give up, and at each close of a position
whether to keep it, sell at the next open, put a protective stop or a take-profit under / over it. It learns those
decisions from 2020-22 only, compares them with the original BigMove (PLAN), OPEN6 and a same-budget open-entry book,
and keeps 2023-25 sealed until you freeze the candidates and the acceptance rule. It does not assume a setup: the
order menu below is what can be placed; which order fits which situation is learned.

| File | What it does |
|---|---|
| execlab.py | `discover`, `freeze`, `evaluate`, `status`, `--selftest` |
| XL_DECLARATION.json | every setting: menus, fills, learning, variants, hurdles, budgets, comparators, candidate rule, acceptance A1-A4 |
| xl_data.py | data through v2engine 0.3 (read only) + India VIX + 3-minute bars |
| xl_feat.py | what is known at a close (features; the label firewall) |
| xl_sim.py | fills, exits, lock rules, stage E costs, OPEN6 / PLAN |
| xl_learn.py | the learning (policy iteration, cross-fitting, variants) |
| xl_ledger.py | research ledger, allocator + execution ledger, money view |
| xl_eval.py, xl_cards.py, xl_report.py | measures, setup / exit cards, REPORT.md and the CSVs |
| env_execlab.bat | session setup (calls v2engine's env_v2.bat; CRLF) |
| tests\ | test_execlab.py (the suite), xl_world.py (planted / absent / null worlds), xl_mutate.py (planted bugs) |

Reads production READ ONLY (pick_meta's run, the cache, tl_state, tl_context, stage E's cost code) through
v2engine's adapter. Writes only under `%XL_OUT%` (C:\QuantData\execlab). Nothing in bigmove_deploy, tradelab,
pathlab, v2engine or playbook is touched.

## Install (cmd)

Unzip so that `C:\Users\karanvsi\PyCharmMiscProject\execlab\` sits next to `v2engine\`, `tradelab\`, `pathlab\`.
scikit-learn is needed (`python -m pip install scikit-learn` if the bat says it is missing).

    call C:\Users\karanvsi\PyCharmMiscProject\execlab\env_execlab.bat
    python execlab.py --selftest quick

Expected last two lines: `37 checks, 0 failed (... s)` and `VERIFIED (execlab v1.0)`. The quick suite took under 2
minutes here; `--selftest` without `quick` uses bigger worlds and more null worlds. Run one heavy job at a time: two
scikit-learn jobs side by side on the same cores slow each other down many times over.

## 1. Discover (2020-22; 2023-25 is not even loaded)

    python execlab.py discover --root %CACHE_DAILY_ROOT% --out %XL_OUT%

Engines D and ENS are learned separately. For each: 3 model variants (universal / context / specialised) x 4
hurdles (0 / 25 / 50 / 100 bp) = 12 configurations. Writes `%XL_OUT%\disc_<id>\`:

- `REPORT.md` - per engine: the research ledger table (every selection on its own: net per selection with unfilled
  = 0, vs OPEN6, vs PLAN, major winners captured / missed, bad trades avoided, false triggers), the execution ledger
  table (Rs 10 lakh, your budgets: CAGR, worst drawdown, CAGR at a -25% drawdown, daily excess over the same-budget
  open entry with its interval, Romano-Wolf adjusted p), PBO, the candidates, and for the best configuration: entry-lag
  cohorts, abandons by close, context groups (state group x event group x market, Benjamini-Hochberg), setup cards,
  exit cards, the intraday study (3-minute bars, exploratory)
- `ledger_research.csv` - every selection x configuration, filled or not (OUT_OF_PERIOD rows: the path would end
  after 2022-12-31), with its decision close, order, fill, exit, reason, net, MFE / MAE, OPEN6, PLAN
- `ledger_execution.csv` - the same for the portfolio (TRADED / NO_ROOM / HELD_SYMBOL / ABANDONED / NO_FILL / EXPIRED)
- `configs.csv`, `daily_returns.csv`, `context_groups.csv`, `cards_setup.csv`, `cards_exit.csv`, `candidates.json`,
  `models.pkl`, `RUN.json`

Time, measured on the 2-core build machine at your scale (about 2,000 selections per engine): the specialised variant
took 13 minutes for one engine (hold learning 5 minutes, then 2 minutes per hurdle); the other two variants take less.
Both engines with all 12 configurations come to roughly an hour there; scikit-learn uses every core, so a PC with more
cores is faster. Memory peaked at 0.7 GB. `--quick` (3 folds, 2 rounds, smaller models) gives a first look in about a
fifth of the time, but a quick run can never be frozen. The same run twice is refused (`--again` repeats it).

## 2. Freeze (once you have read the discovery report)

    python execlab.py status --out %XL_OUT%
    python execlab.py freeze --out %XL_OUT% --run disc_<id>

The candidates are chosen by the declared rule, not by hand: per engine, configurations whose discovery portfolio
beats the same-budget open entry with a Romano-Wolf adjusted p under 0.20 across the engine's 12, whose own CAGR and
net per selection are above 0, best first, at most 5. Freeze refuses a run made with changed settings (`--quick`,
`--variants`, ...), a changed declaration or code, a ranks 1-10 run, or a changed models file. No candidate = nothing
to freeze, and that is the result. To change the acceptance rule or budgets, edit XL_DECLARATION.json BEFORE the
discovery run (the run records the declaration's fingerprint).

## 3. Evaluate (one shot, the sealed 2023-25)

    python execlab.py evaluate --root %CACHE_DAILY_ROOT% --out %XL_OUT%

Applies the frozen models unchanged to signal days 2023-01-01 .. 2025-12-31. Refused when the code, the declaration,
the models or scikit-learn's version changed after the freeze, and refused the second time. `eval_<id>\REPORT.md`
gives per candidate: A1 (daily excess over the same-budget open entry, interval above 0, own CAGR above 0), A2 (CAGR
at a -25% drawdown at least the open entry's), A3 (major winners' profit captured >= 70%), A4 (excess positive in at
least 2 of the 3 years). ACCEPTED = all four, and still means paper trading first (the production rule).

## How it decides

- Watch (every close T .. T+9 of a selection, the order acts in the next session only): ABANDON, WAIT, or one of
  OPEN (market at the open), BSTOP (buy stop at the close + 0.5 ATR), BHIGH (buy stop at the day's high + 0.1 ATR),
  LDIP (limit at the close - 0.5 ATR), LDEEP (limit at the close - 1 ATR). An order that does not fill leaves the
  selection watching; an entry is possible on T+1 .. T+10.
- Hold (every close of a position, up to 40 sessions, then sold at the next open): KEEP, EXIT (next open; a locked
  open waits up to 20 sessions), STOP1 / STOP2 (stop 1 / 2 ATR under the close, next session), TP2 (limit 2 ATR over
  the close).
- Learning: approximate policy iteration with realized values (Longstaff-Schwartz style). For every row, the target
  of an action is what actually happened when taking it and then following the current policy; the models estimate
  each action's advantage over a reference action on the same rows (the open entry for watch, KEEP for hold), so the
  shared future path cancels out. Start: OPEN6 (buy T+1's open, sell after age 4); three improvement rounds. The hold
  policy is learned first (on each selection's T+1 entry plus two random later entries with random orders); the watch
  policy is learned on the trades that the hold policy actually makes.
- Honesty: five purged time-block folds; every prediction used to judge a selection comes from models that never saw
  it or anything within 51 sessions of it. The frozen models are trained on all of 2020-22.
- Variants: universal (the stock's own price / volume / position), context (+ NIFTY / Smallcap, India VIX, tl_context
  regime, tl_state state / event / age), specialised (separate models per tl_state state group). Hurdles: an entry has
  to beat waiting / giving up by 0 / 25 / 50 / 100 bp (the slot's opportunity cost).
- Portfolio: <= 2 entries a day, <= 6 in 5 sessions, <= 8 open, one position per stock, re-entry after a close, no
  adding; orders ranked by estimated advantage, fills taken in that order, the rest cancelled when a budget binds;
  1/8 of equity a position, integer shares, 2% of ADV, cash (v2_money.simulate). A selection that was not served
  keeps watching.
- Costs and fills: stage E's zerodha_base, fully net (STT, stamp, exchange, SEBI, GST, DP, impact 0.5 x vol20 x
  sqrt(value / ADV), exit tick); buy stops pay 0.05 ATR slippage, sell stops 0.05 ATR; a limit needs the price to trade
  through it; no buy on an upper-locked bar, no sell on a frozen lower-locked bar.

## Ranks 1-10 (a separate experiment)

    python execlab.py discover --root %CACHE_DAILY_ROOT% --out %XL_OUT% --ranks 1-10

Writes its own `disc_<id>_r1-10` folder; it is never mixed with the top-3 results and cannot be frozen.

## Verified here / not

- Fills and exits by hand (every order type, gaps, trade-through, locks, lock waits, STUCK); the hold engine with
  'sell after age 4' reproduces v2's OPEN6 on every record (exit session and price, stage E net to 1e-12); the
  learning's cost stand-in is within 2 bp of stage E's net.
- No look-ahead (everything after a cut redrawn: identical features up to it), no raw price level (prices x 10:
  identical features), the label firewall; backward induction by hand; purged folds; the statistics (coverage,
  Romano-Wolf, BH, PBO, CAGR at -25% DD); the allocator under random orders (0 budget violations).
- Planted worlds: entry timing found where the dip is planted (and the open kept where the rally is immediate),
  failed breakouts avoided, early exits where the move reverses, long holds and >= 70% of major winners' profit where
  the trend runs, context beats universal on context-keyed effects, a planted 3-minute dip found; absent and null
  worlds: no positive edge claimed (and evaluating in sample - the bug the cross-fitting prevents - shows a fake
  +0.95% a selection in the same absent world).
- The CLI: discovery never loads 2023; refusals (sealed dates, repeat runs, changed settings, changed code, evaluate
  twice); freeze -> one evaluation; every command in the ledger. The real loader on pathlab's fake production cache.
- 22 planted bugs (tests\xl_mutate.py: fills, exits, look-ahead, a raw price feature, the recursions, the hurdle,
  the purge, the bootstrap, every budget, the comparators, costs, in-sample evaluation, unpaired models, loading the
  sealed years, evaluating twice): each one caught by a failing check.
- 37 checks, 0 failed, on Python 3.13 / numpy 2.5.3 / pandas 3.0.5 / scikit-learn 1.9.1 (full and quick) and on
  Python 3.12 / numpy 2.4.1 / pandas 2.3.3 / scikit-learn 1.5.2 (quick).
- **Your cache has not been read yet.** The first discover on your PC is the first contact with real data.

## Discipline

2020-22 is the discovery period. Everything in a discovery report is a hypothesis. 2023-25 is read once, by
`evaluate`, after `freeze`. Edit the declaration before discovering, never after looking at a sealed result.
