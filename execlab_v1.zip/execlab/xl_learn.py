r"""xl_learn.py - execlab: learning the watch and hold decisions (approximate policy iteration, realized values).

World      one engine's selections in a period, their purged folds, the stocks' bars and features, how often each
           stock was selected in the last 10 sessions (all engines), and tl_state's state group at every close.
Model      HistGradientBoostingRegressor (declared settings, native categorical codes) or ridge (tests, ablation).
QSet       one model per (fold, group, action); fold -1 = trained on everything (the model that is frozen). Paired:
           watch = the open entry's value + every other action's advantage over it; hold = every action's advantage
           over KEEP (the shared future path cancels out of each target).

Hold (age h = 0 .. 39 after the entry session's close; at 40 the position is sold at the next open):
  training positions = every record's T+1 open entry plus (hold_sample_entries - 1) random later entry sessions with
  a random order kind (OPEN where that order does not fill). Targets: take the action at h, then follow the current
  policy (realized, never fitted, continuation): KEEP -> next close x (1 + V[h + 1]), EXIT -> the next unlocked open,
  STOPm / TP2 -> the fill when hit in the next session, else as KEEP. Start: exit at the open after age 4 (OPEN6);
  each iteration refits the five Q models and takes the best action at every row (out of fold).
Watch (close a = T .. T+9, the order acts at a + 1):
  ENTER_k -> the trade's stage E net minus the hurdle when it fills (managed by the learned hold policy, out of
  fold), else the value of watching on; WAIT -> the value of watching on (0 after T+9); ABANDON -> 0.
  Start: the open entry at T+1 (repeated each evening until it fills). One fit per hurdle.
"""
import time
import warnings

import numpy as np

import xl_feat as F
import xl_sim as S
from xl_common import XLError, purged_folds

WATCH_ACTIONS = ("ABANDON", "WAIT") + tuple("ENTER_" + k for k in S.ENTRY)


# ============================================================================ the world of one engine
class World:
    def __init__(self, D, decl, engine, ranks, t_from, t_to, folds=None, log=print, B=None, fs=None):
        self.D, self.decl, self.engine = D, decl, engine
        self.W = int(decl["window"]["watch_closes"])
        self.H = int(decl["window"]["hold_max"])
        cal = D.cal
        lo, hi = np.datetime64(t_from, "D"), np.datetime64(t_to, "D")
        allsel = list(D.registry.active())
        sels = [s for s in allsel if s.engine == engine and s.rank in set(ranks) and
                lo <= np.datetime64(s.T, "D") <= hi]
        sels.sort(key=lambda s: (s.t_idx, s.rank, s.sid))
        syms = sorted({s.symbol for s in allsel})
        self.B = B if B is not None else S.Bars(D, syms, int(decl["window"]["lock_wait"]))
        self.fs = fs if fs is not None else F.FeatureStore(D, self.B.syms)
        n = cal.n
        need = self.W + self.H + 2
        self.all_recs = sels
        ok = np.array([s.t_idx + need <= n - 1 and s.symbol in self.B.k for s in sels], bool)
        self.out_of_period = [s for s, k in zip(sels, ok) if not k]
        use = [s for s, k in zip(sels, ok) if k]
        self.recs = {"sid": np.array([s.sid for s in use], dtype=object),
                     "sym": np.array([s.symbol for s in use], dtype=object),
                     "j": np.array([self.B.k[s.symbol] for s in use], dtype=np.int64),
                     "t": np.array([s.t_idx for s in use], dtype=np.int64),
                     "rank": np.array([s.rank for s in use], dtype=float),
                     "score": np.array([s.raw_score for s in use], dtype=float),
                     "T": np.array([s.T for s in use], dtype=object)}
        self.n_rec = len(use)
        # selections of each stock within the last 10 sessions (all engines and ranks loaded), and on the day
        S_, n_ = len(self.B.syms), n
        R1 = np.zeros((S_, n_), np.float32)
        for s in allsel:
            if s.symbol in self.B.k:
                R1[self.B.k[s.symbol], s.t_idx] += 1
        cs = np.cumsum(R1, axis=1)
        R10 = cs.copy()
        R10[:, 10:] = cs[:, 10:] - cs[:, :-10]
        self.R1, self.R10 = R1, R10
        G = np.full((S_, n_), 3, np.int8)
        st = self.fs.X[:, :, 0]
        codes = np.array(F.STATE_LIST)
        okx = np.isfinite(st)
        sc = np.where(okx, codes[np.where(okx, st, 0).astype(int)], -1)
        G[np.isin(sc, (1, 2, 3))] = 0
        G[np.isin(sc, (6, 7))] = 1
        G[np.isin(sc, (8, 9))] = 2
        self.G = G
        # folds
        K = int(folds if folds is not None else decl["learning"]["folds"])
        self.K = K
        self.fold = np.full(self.n_rec, -1, dtype=np.int64)
        self.train_ok = np.zeros((K, self.n_rec), bool)
        if self.n_rec and K >= 2:
            for f, (te, tr) in enumerate(purged_folds(self.recs["t"], K, int(decl["learning"]["purge_sessions"]))):
                self.fold[te] = f
                self.train_ok[f, tr] = True
        log("   %s: %d selections in %s .. %s (%d with a path ending inside the period), %d folds" % (
            engine, len(sels), t_from, t_to, self.n_rec, K))

    def watch_rows(self):
        """(r, a) for every record and close a = T .. T+9."""
        r = np.repeat(np.arange(self.n_rec), self.W)
        d = np.tile(np.arange(self.W), self.n_rec)
        a = self.recs["t"][r] + d
        return r, a, d

    def watch_X(self, cols, r, a):
        B, R = self.B, self.recs
        j, t = R["j"][r], R["t"][r]
        sel = {"rank": R["rank"][r], "score": R["score"][r],
               "resel10": self.R10[j, a] - 1.0, "resel_today": self.R1[j, a] - (a == t)}
        cT = B.cf[j, t]
        run = np.zeros(len(r))
        pull = np.zeros(len(r))
        for d in range(1, self.W):
            m = (a - t) >= d
            if m.any():
                hh, ll_ = B.h[j[m], t[m] + d], B.l[j[m], t[m] + d]
                run[m] = np.fmax(run[m], hh / cT[m] - 1.0)
                pull[m] = np.fmin(pull[m], ll_ / cT[m] - 1.0)
        with np.errstate(invalid="ignore", divide="ignore"):
            extra = {"day": (a - t).astype(float), "ret_since_T": B.cf[j, a] / cT - 1.0, "runup_T": run,
                     "pullback_T": pull, "move_T_atr": (B.cf[j, a] - cT) / B.atr[j, t]}
        return F.assemble(self.fs, cols, j, a, sel, extra)

    def hold_X(self, cols, j, i, e, t, P, kind, rank, score, runmax):
        B = self.B
        c = B.cf[j, i]
        sel = {"rank": rank, "score": score, "resel10": self.R10[j, i], "resel_today": self.R1[j, i]}
        with np.errstate(invalid="ignore", divide="ignore"):
            extra = {"age": (i - e).astype(float), "lag": (e - t).astype(float), "gain": c / P - 1.0,
                     "mfe": runmax / P - 1.0, "dd_peak": c / runmax - 1.0, "gain_atr": (c - P) / B.atr[j, i],
                     "kind": kind.astype(float)}
        return F.assemble(self.fs, cols, j, i, sel, extra)


# ============================================================================ models
class Ridge:
    def __init__(self, alpha=10.0):
        self.alpha = alpha

    def fit(self, X, y):
        X = np.asarray(X, dtype=float)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)       # an all-missing column is imputed as 0
            med = np.nanmedian(np.where(np.isfinite(X), X, np.nan), axis=0)
        self.med = np.where(np.isfinite(med), med, 0.0)
        Z = np.where(np.isfinite(X), X, self.med)
        self.mu, sd = Z.mean(axis=0), Z.std(axis=0)
        self.sd = np.where(sd > 0, sd, 1.0)
        Z = (Z - self.mu) / self.sd
        self.y0 = float(np.mean(y))
        A = Z.T @ Z + self.alpha * np.eye(Z.shape[1])
        self.w = np.linalg.solve(A, Z.T @ (y - self.y0))
        return self

    def predict(self, X):
        X = np.asarray(X, dtype=float)
        Z = (np.where(np.isfinite(X), X, self.med) - self.mu) / self.sd
        return Z @ self.w + self.y0


def make_model(decl, cols, seed):
    kind = decl["learning"]["model"]
    if kind == "ridge":
        return Ridge()
    if kind != "hgb":
        raise XLError("learning.model must be hgb or ridge")
    try:
        from sklearn.ensemble import HistGradientBoostingRegressor
    except ImportError:
        raise XLError("scikit-learn is needed (pip install scikit-learn); learning.model = ridge runs without it")
    cat = np.array([c in F.CATEGORICAL for c in cols], bool)
    return HistGradientBoostingRegressor(loss="squared_error", categorical_features=cat if cat.any() else None,
                                         random_state=int(seed), early_stopping=False, **decl["learning"]["hgb"])


class QSet:
    """Action values. With ref (an action index) the models are paired: the reference action's own value (when
    level) and every other action's ADVANTAGE over it on the same rows (the same future path is in both targets, so
    its noise cancels): Q_ref = level, Q_a = level + advantage_a."""

    def __init__(self, actions, cols, specialised, ref=None, level=True):
        self.actions, self.cols, self.specialised = tuple(actions), list(cols), bool(specialised)
        self.ref, self.level = ref, bool(level)
        self.models = {}
        self.const = {}

    def predict(self, X, fold, grp):
        raw = self._raw(X, fold, grp)
        if self.ref is None:
            return raw
        lv = raw[:, self.ref] if self.level else np.zeros(len(X))
        out = raw + lv[:, None]
        out[:, self.ref] = lv
        return out

    def _raw(self, X, fold, grp):
        out = np.zeros((len(X), len(self.actions)))
        fold = np.asarray(fold)
        grp = np.asarray(grp) if self.specialised else np.full(len(X), -1)
        for f in np.unique(fold):
            for g in np.unique(grp):
                m = (fold == f) & (grp == g)
                if not m.any():
                    continue
                gg = g if any((f, g, a) in self.models or (f, g, a) in self.const for a in self.actions) else -1
                for q, a in enumerate(self.actions):
                    key = (f, gg, a)
                    if key in self.models:
                        out[m, q] = self.models[key].predict(X[m])
                    elif key in self.const:
                        out[m, q] = self.const[key]
                    elif (f, -1, a) in self.models:
                        out[m, q] = self.models[(f, -1, a)].predict(X[m])
                    else:
                        out[m, q] = self.const.get((f, -1, a), 0.0)
        return out


def fit_qset(qs, X, Y, rows_rec, rows_grp, world, decl, fit_folds=True, fit_full=True, log=None, tag=""):
    """Y: (rows, actions) targets (NaN = action unavailable there). Fits fold models (training rows = rows whose
    record is in the fold's purged training set) and the full model."""
    L = decl["learning"]
    lo, hi = L["target_clip"]
    cap = int(L["max_train_rows"])
    seed = int(L["seed"])
    keys = ([f for f in range(world.K)] if fit_folds else []) + ([-1] if fit_full else [])
    groups = [-1] + ([0, 1, 2, 3] if qs.specialised else [])
    if qs.ref is not None:                       # paired targets: the reference's value, the others' advantage
        Yr = Y[:, qs.ref].copy()
        Y = Y - Yr[:, None]
        Y[:, qs.ref] = Yr if qs.level else np.nan
    for f in keys:
        base = world.train_ok[f, rows_rec] if f >= 0 else np.ones(len(rows_rec), bool)
        for g in groups:
            mg = base if g < 0 else base & (rows_grp == g)
            if g >= 0 and len(np.unique(rows_rec[mg])) < int(L["min_group_records"]):
                continue
            for q, a in enumerate(qs.actions):
                y = Y[:, q]
                m = mg & np.isfinite(y)
                idx = np.flatnonzero(m)
                if len(idx) == 0:
                    continue
                if len(idx) > cap:
                    rng = np.random.default_rng([seed, f + 7, g + 7, q])
                    idx = np.sort(rng.choice(idx, cap, replace=False))
                yy = np.clip(y[idx], lo, hi)
                if len(idx) < 50 or np.std(yy) == 0:
                    qs.const[(f, g, a)] = float(np.mean(yy))
                    continue
                mdl = make_model(decl, qs.cols, seed + q)
                mdl.fit(X[idx], yy)
                qs.models[(f, g, a)] = mdl
    return qs


def oof_predict(qs, X, rows_rec, rows_grp, world):
    return qs.predict(X, world.fold[rows_rec], rows_grp)


# ============================================================================ hold
def _menus(decl):
    return decl["entry_menu"], decl["hold_menu"]


def sample_positions(world, rng):
    """Training positions: T+1 open for every record + (k - 1) random later entry sessions / random orders."""
    decl = world.decl
    k = int(decl["learning"]["hold_sample_entries"])
    R, B = world.recs, world.B
    rr, ee, PP, kk = [], [], [], []
    em, _ = _menus(decl)
    for r in range(world.n_rec):
        t = int(R["t"][r])
        lags = [1] + (sorted(rng.choice(np.arange(2, world.W + 1), size=min(k - 1, world.W - 1), replace=False).tolist())
                      if k > 1 else [])
        for lag in lags:
            kind = 0 if lag == 1 else int(rng.integers(0, len(S.ENTRY)))
            rr.append(r), ee.append(t + lag), kk.append(kind)
    rr, ee, kk = np.array(rr), np.array(ee), np.array(kk)
    PP = np.full(len(rr), np.nan)
    j = R["j"][rr]
    for q, name in enumerate(S.ENTRY):
        m = kk == q
        if m.any():
            f, px = S.entry_fill(B, j[m], ee[m] - 1, name, em, decl["fills"]["stop_slip_atr"])
            PP[np.flatnonzero(m)[f]] = px[f]
    miss = ~np.isfinite(PP)
    if miss.any():
        f, px = S.entry_fill(B, j[miss], ee[miss] - 1, "OPEN", em)
        PP[np.flatnonzero(miss)[f]] = px[f]
        kk[np.flatnonzero(miss)[f]] = 0
    ok = np.isfinite(PP)
    return {"r": rr[ok], "j": j[ok], "e": ee[ok], "P": PP[ok], "kind": kk[ok]}


def hold_static(world, pos):
    """Per position and age: closes, the next session's outcome of every action (relative to the close), masks."""
    B, H, decl = world.B, world.H, world.decl
    _, hm = _menus(decl)
    slip = decl["fills"]["exit_slip_atr"]
    n = len(pos["j"])
    j, e = pos["j"], pos["e"]
    imp = B.impact(j, e)
    C = np.stack([B.cf[j, e + h] for h in range(H + 2)], axis=1)
    ok_dec = np.stack([np.isfinite(B.c[j, e + h]) for h in range(H + 1)], axis=1)
    val = np.full((n, H + 1, len(S.HOLDA)), np.nan)          # immediate value when the action ends the trade
    hit = np.zeros((n, H + 1, len(S.HOLDA)), bool)
    for h in range(H + 1):
        i = e + h
        for q, a in enumerate(S.HOLDA):
            if a == "KEEP":
                continue
            done, xs, px, rc, tc = S.resolve_hold(B, j, i, np.full(n, q), hm, slip)
            with np.errstate(invalid="ignore", divide="ignore"):
                sf = B.s0 + imp + 0.05 / np.where(px > 0, px, np.nan)
                v = px * (1.0 - sf) / C[:, h] - 1.0
            hit[:, h, q] = done & np.isfinite(v)
            val[:, h, q] = np.where(hit[:, h, q], v, np.nan)
    return {"C": C, "ok": ok_dec, "val": val, "hit": hit, "imp": imp}


def hold_values(world, st, A, rent=0.0):
    """Realized values under the decisions A (positions, ages 0..H-1): V (positions, H+1) and the targets
    Y (positions, H, actions) = take the action at h, then follow A."""
    H = world.H
    C, val, hit = st["C"], st["val"], st["hit"]
    n = C.shape[0]
    V = np.zeros((n, H + 1))
    ex = S.HOLDA.index("EXIT")
    V[:, H] = val[:, H, ex]
    Y = np.full((n, H, len(S.HOLDA)), np.nan)
    with np.errstate(invalid="ignore", divide="ignore"):
        for h in range(H - 1, -1, -1):
            cont = C[:, h + 1] / C[:, h] * (1.0 + V[:, h + 1]) - 1.0 - rent
            for q, a in enumerate(S.HOLDA):
                Y[:, h, q] = cont if a == "KEEP" else np.where(hit[:, h, q], val[:, h, q], cont)
            V[:, h] = Y[np.arange(n), h, A[:, h]]
    return V, Y


def hold_rows(world, pos, st, cols):
    """Feature rows (position, age h < H) where a decision is made."""
    H = world.H
    pi, hh = np.nonzero(st["ok"][:, :H])
    R = world.recs
    r = pos["r"][pi]
    runmax = np.maximum.accumulate(st["C"][:, :H + 1], axis=1)[pi, hh]
    j, e = pos["j"][pi], pos["e"][pi]
    X = world.hold_X(cols, j, e + hh, e, R["t"][r], pos["P"][pi], pos["kind"][pi], R["rank"][r], R["score"][r],
                     runmax)
    grp = world.G[j, e + hh]
    return pi, hh, X, grp


def learn_hold(world, variant, log=print):
    decl = world.decl
    L = decl["learning"]
    t0 = time.time()
    rng = np.random.default_rng(int(L["seed"]))
    cols = F.columns("hold", variant)
    pos = sample_positions(world, rng)
    st = hold_static(world, pos)
    pi, hh, X, grp = hold_rows(world, pos, st, cols)
    rrec = pos["r"][pi]
    H = world.H
    A = np.where(np.arange(H)[None, :] >= 4, S.HOLDA.index("EXIT"), S.HOLDA.index("KEEP")) * np.ones(
        (len(pos["j"]), 1), np.int64)
    A = A.astype(np.int64)
    rent = float(decl.get("rent_bp_per_session", 0)) / 1e4
    iters = int(L["iterations_hold"])
    hist = []
    qs = None
    for it in range(iters):
        V, Y = hold_values(world, st, A, rent)
        hist.append(float(np.nanmean(V[:, 0])))
        qs = QSet(S.HOLDA, cols, variant == "specialised", ref=S.HOLDA.index("KEEP"), level=False)
        fit_qset(qs, X, Y[pi, hh], rrec, grp, world, decl, fit_folds=True, fit_full=(it == iters - 1))
        Q = oof_predict(qs, X, rrec, grp, world)
        A = np.full_like(A, S.HOLDA.index("KEEP"))
        A[pi, hh] = np.argmax(Q, axis=1)
    V, Y = hold_values(world, st, A, rent)
    hist.append(float(np.nanmean(V[:, 0])))
    log("   %s hold %s: %d positions, %d rows, value at entry by iteration %s (%.0f s)" % (
        world.engine, variant, len(pos["j"]), len(pi), " ".join("%+.4f" % v for v in hist), time.time() - t0))
    return qs, {"positions": int(len(pos["j"])), "rows": int(len(pi)), "value_by_iteration": hist}


def hold_decider(world, qs, pos, full=False):
    """The callback of xl_sim.hold_forward: the best hold action under qs at each alive position (out of fold
    unless full)."""
    R = world.recs

    def decide(ids, h, i, runmax):
        r = pos["r"][ids]
        j = pos["j"][ids]
        X = world.hold_X(qs.cols, j, i, pos["e"][ids], R["t"][r], pos["P"][ids], pos["kind"][ids], R["rank"][r],
                         R["score"][r], runmax)
        fold = np.full(len(ids), -1) if full else world.fold[r]
        return np.argmax(qs.predict(X, fold, world.G[j, i]), axis=1)

    return decide


def run_trades(world, qs_hold, pos, full=False):
    """Every position forward under the learned hold policy; stage E's net per trade."""
    decl = world.decl
    _, hm = _menus(decl)
    out = S.hold_forward(world.B, pos, hold_decider(world, qs_hold, pos, full), world.H, hm,
                         decl["fills"]["exit_slip_atr"])
    out["net"] = S.trade_nets(world.B, pos["j"], pos["e"], pos["P"], out["x"], out["px"])
    return out


# ============================================================================ watch
def entry_table(world, r, a):
    """Fills of every entry order at every watch row: filled (rows, kinds), P (rows, kinds)."""
    em, _ = _menus(world.decl)
    j = world.recs["j"][r]
    Fm = np.zeros((len(r), len(S.ENTRY)), bool)
    Pm = np.full((len(r), len(S.ENTRY)), np.nan)
    for q, k in enumerate(S.ENTRY):
        f, px = S.entry_fill(world.B, j, a, k, em, world.decl["fills"]["stop_slip_atr"])
        Fm[:, q], Pm[:, q] = f, px
    return Fm, Pm


def enter_outcomes(world, qs_hold, r, a, Fm, Pm, full=False, only=None):
    """Trades of every filled (row, kind) (or of the (row, kind) pairs in only) under the hold policy."""
    rr, kk = np.nonzero(Fm if only is None else (Fm & only))
    pos = {"r": r[rr], "j": world.recs["j"][r[rr]], "e": a[rr] + 1, "P": Pm[rr, kk], "kind": kk.astype(np.int64)}
    tr = run_trades(world, qs_hold, pos, full)
    NET = np.full(Fm.shape, np.nan)
    NET[rr, kk] = tr["net"]
    tr["row"], tr["k"] = rr, kk
    tr["pos"] = pos
    return NET, tr


def watch_masks(world, r, a, d):
    B = world.B
    j = world.recs["j"][r]
    can_enter = (a + 1 <= B.n - 1) & B.entry_ok[np.minimum(a + 1, B.n - 1)] & np.isfinite(B.c[j, a])
    can_wait = d < world.W - 1
    return can_enter, can_wait


def watch_values(world, d, NETm, Fm, A, hurdle):
    """Backward over the window: V (records, W + 1) and targets Y (rows, actions) for decisions A (rows)."""
    W = world.W
    nr = world.n_rec
    V = np.zeros((nr, W + 1))
    Y = np.full((len(d), len(WATCH_ACTIONS)), np.nan)
    rows = np.arange(len(d)).reshape(nr, W)
    for dd in range(W - 1, -1, -1):
        q = rows[:, dd]
        nxt = V[:, dd + 1]
        y = np.full((nr, len(WATCH_ACTIONS)), np.nan)
        y[:, 0] = 0.0
        y[:, 1] = nxt
        for k in range(len(S.ENTRY)):
            y[:, 2 + k] = np.where(Fm[q, k] & np.isfinite(NETm[q, k]), NETm[q, k] - hurdle, nxt)
        Y[q] = y
        V[:, dd] = y[np.arange(nr), A[q]]
    return V, Y


def choose_watch(Q, can_enter, can_wait):
    Q = Q.copy()
    Q[:, 0] = 0.0
    Q[~can_wait, 1] = -np.inf
    Q[~can_enter, 2:] = -np.inf
    return np.argmax(Q, axis=1), Q


def learn_watch(world, variant, X, r, a, d, Fm, NETm, hurdle_bp, log=print):
    decl = world.decl
    L = decl["learning"]
    t0 = time.time()
    hurdle = float(hurdle_bp) / 1e4
    can_enter, can_wait = watch_masks(world, r, a, d)
    grp = world.G[world.recs["j"][r], a]
    A = np.where(can_enter, 2, 1).astype(np.int64)          # start: the open entry each evening until it fills
    A[~can_enter & ~can_wait] = 0
    iters = int(L["iterations_watch"])
    hist = []
    qs = None
    for it in range(iters):
        V, Y = watch_values(world, d, NETm, Fm, A, hurdle)
        hist.append(float(V[:, 0].mean()) if world.n_rec else np.nan)
        Yf = Y[:, 1:].copy()
        Yf[~can_wait, 0] = np.nan
        Yf[~can_enter, 1:] = np.nan
        qs = QSet(WATCH_ACTIONS[1:], F.columns("watch", variant), variant == "specialised",
                  ref=WATCH_ACTIONS[1:].index("ENTER_OPEN"), level=True)
        fit_qset(qs, X, Yf, r, grp, world, decl, fit_folds=True, fit_full=(it == iters - 1))
        Q = np.c_[np.zeros(len(r)), oof_predict(qs, X, r, grp, world)]
        A, _ = choose_watch(Q, can_enter, can_wait)
    V, Y = watch_values(world, d, NETm, Fm, A, hurdle)
    hist.append(float(V[:, 0].mean()) if world.n_rec else np.nan)
    log("   %s watch %s hurdle %d bp: value per selection by iteration %s (%.0f s)" % (
        world.engine, variant, hurdle_bp, " ".join("%+.4f" % v for v in hist), time.time() - t0))
    return qs, A, {"value_by_iteration": hist}


def watch_decisions(world, qs, X, r, a, d, full=False):
    can_enter, can_wait = watch_masks(world, r, a, d)
    grp = world.G[world.recs["j"][r], a]
    fold = np.full(len(r), -1) if full else world.fold[r]
    Q = np.c_[np.zeros(len(r)), qs.predict(X, fold, grp)]
    A, Qm = choose_watch(Q, can_enter, can_wait)
    return A, Qm
