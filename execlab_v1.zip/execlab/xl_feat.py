r"""xl_feat.py - execlab: what is known at a close, as features (point-in-time, no labels, no raw price levels).

FeatureStore(D, symbols) computes, once per symbol on the calendar, the stock's own features at every close
(returns, ATR %, distance from 20 / 60-session highs and lows, EMA gaps, where the close sits in the day's range,
gap, body in ATRs, volume ratio, vol20, log ADV, ATR5 / ATR20 compression, lock flags) and the market's (NIFTY and
Smallcap returns, India VIX's percentile in its last 250 sessions and 5-session change, tl_context's regime), plus
tl_state's state / event / age per stock and session. Every value at close i uses bars up to i only: the tests
perturb everything after a cut and require identical features up to it, and scale a stock's prices by 10 and require
identical features (log ADV, a liquidity level in rupees, is the one declared exception).

Rows:  watch (selection r, close a):    stock + market + context + selection + window features
       hold  (position p, close h):     stock + market + context + selection + position features (age, entry lag,
                                        gain since the fill, best close since the fill, drop from it, gain in ATRs,
                                        entry order)
Variants pick columns: universal = stock + selection + window / position; context and specialised = everything.
"""
import numpy as np
import pandas as pd

from xl_common import XLError

SYM = ("ret1", "ret3", "ret5", "ret10", "ret20", "atr_pct", "dist_hi20", "dist_lo20", "dist_hi60", "ema20_gap",
       "ema50_gap", "clv", "gap", "body_atr", "vol_ratio", "vol20", "adv_log", "comp", "up_lock", "dn_lock")
MKT = ("nifty_r1", "nifty_r5", "nifty_r20", "small_r5", "small_r20", "vix_pct", "vix_chg5", "regime")
CTX = ("state", "event", "ev_age")
SEL = ("rank", "score", "resel10", "resel_today")
WATCH = ("day", "ret_since_T", "runup_T", "pullback_T", "move_T_atr")
HOLD = ("age", "lag", "gain", "mfe", "dd_peak", "gain_atr", "kind")
CATEGORICAL = {"regime", "state", "event", "kind"}
STATE_LIST = (-1, 0, 1, 2, 3, 6, 7, 8, 9, 12)
STATE_IDX = {c: k for k, c in enumerate(STATE_LIST)}
GROUPS = ("bull", "turn_flat", "bear", "other")


def firewall(names):
    bad = [n for n in names if n.startswith("label_")]
    if bad:
        raise XLError("label firewall: %s" % bad)
    allowed = set(SYM) | set(MKT) | set(CTX) | set(SEL) | set(WATCH) | set(HOLD)
    unk = [n for n in names if n not in allowed]
    if unk:
        raise XLError("feature(s) not on the declared list: %s" % unk)
    return True


def columns(kind, variant):
    base = (SYM + SEL + (WATCH if kind == "watch" else HOLD))
    if variant == "universal":
        cols = base
    elif variant in ("context", "specialised"):
        cols = base + MKT + CTX
    else:
        raise XLError("unknown variant %r" % variant)
    firewall(cols)
    return list(cols)


def state_group(code):
    c = int(code) if np.isfinite(code) else -1
    if c in (1, 2, 3):
        return 0
    if c in (6, 7):
        return 1
    if c in (8, 9):
        return 2
    return 3


def _ffill(x):
    x = np.asarray(x, dtype=float)
    ok = np.isfinite(x)
    idx = np.where(ok, np.arange(len(x)), -1)
    np.maximum.accumulate(idx, out=idx)
    out = np.where(idx >= 0, x[np.maximum(idx, 0)], np.nan)
    return out


def _lagret(c, k):
    out = np.full(len(c), np.nan)
    if len(c) > k:
        with np.errstate(invalid="ignore", divide="ignore"):
            out[k:] = c[k:] / c[:-k] - 1.0
    return out


def _roll(x, w, how):
    s = pd.Series(x)
    r = s.rolling(w, min_periods=max(2, w // 2))
    return (r.max() if how == "max" else r.min() if how == "min" else r.mean() if how == "mean" else r.median()).to_numpy(float)


def _ema(x, span):
    return pd.Series(x).ewm(span=span, adjust=False, min_periods=span).mean().to_numpy(float)


def stock_features(b):
    """(n, len(SYM)) float32: the stock's own features at every close (NaN where unknown)."""
    o, h, l, c0, v = (np.asarray(b[k], dtype=float) for k in ("open", "high", "low", "close", "volume"))
    n = len(c0)
    has = np.isfinite(c0)
    c = _ffill(c0)
    atr = np.asarray(b["atr"], dtype=float)
    prev = np.r_[np.nan, c[:-1]]
    with np.errstate(invalid="ignore", divide="ignore"):
        tr = np.where(has, np.fmax(h - l, np.fmax(np.abs(h - prev), np.abs(l - prev))), np.nan)
        hh = np.where(has, h, np.nan)
        ll = np.where(has, l, np.nan)
        F = np.full((n, len(SYM)), np.nan)
        F[:, 0], F[:, 1], F[:, 2], F[:, 3], F[:, 4] = (_lagret(c, k) for k in (1, 3, 5, 10, 20))
        F[:, 5] = atr / c
        F[:, 6] = c / _roll(hh, 20, "max") - 1.0
        F[:, 7] = c / _roll(ll, 20, "min") - 1.0
        F[:, 8] = c / _roll(hh, 60, "max") - 1.0
        F[:, 9] = c / _ema(c, 20) - 1.0
        F[:, 10] = c / _ema(c, 50) - 1.0
        rng = h - l
        F[:, 11] = np.where(has, np.where(rng > 0, (c0 - l) / np.where(rng > 0, rng, 1.0), 0.5), np.nan)
        F[:, 12] = np.where(has, o / prev - 1.0, np.nan)
        F[:, 13] = np.where(has, (c0 - o) / atr, np.nan)
        vm = _roll(np.where(has, v, np.nan), 20, "median")
        vm_prev = np.r_[np.nan, vm[:-1]]
        F[:, 14] = np.where(has, v / vm_prev, np.nan)
        F[:, 15] = np.asarray(b.get("vol20", np.full(n, np.nan)), dtype=float)
        adv = np.asarray(b.get("adv", np.full(n, np.nan)), dtype=float)
        F[:, 16] = np.where(adv > 0, np.log10(np.where(adv > 0, adv, 1.0)), np.nan)
        F[:, 17] = _roll(tr, 5, "mean") / _roll(tr, 20, "mean")
        F[:, 18] = np.asarray(b["upper_locked"], dtype=float)
        F[:, 19] = np.asarray(b.get("ll_close", b["lower_locked"]), dtype=float)
    F[~np.isfinite(F)] = np.nan
    return F.astype(np.float32)


def market_features(D):
    n = D.cal.n
    M = np.full((n, len(MKT)), np.nan)
    ib = getattr(D, "index_bars", {}) or {}
    if "nifty" in ib:
        c = _ffill(ib["nifty"]["close"])
        M[:, 0], M[:, 1], M[:, 2] = _lagret(c, 1), _lagret(c, 5), _lagret(c, 20)
    if "small" in ib:
        c = _ffill(ib["small"]["close"])
        M[:, 3], M[:, 4] = _lagret(c, 5), _lagret(c, 20)
    vix = getattr(D, "vix", None)
    if vix is not None:
        vx = _ffill(vix)
        M[:, 5] = pd.Series(vx).rolling(250, min_periods=60).rank(pct=True).to_numpy(float)
        M[:, 6] = _lagret(vx, 5)
    reg = getattr(D, "regime", None)
    if reg is not None:
        r = np.asarray(reg, dtype=float)
        M[:, 7] = np.where(r >= 0, r + 1.0, 0.0)          # -1 (unknown) -> 0, regimes 0..4 -> 1..5
    M[~np.isfinite(M)] = np.nan
    return M.astype(np.float32)


class FeatureStore:
    """S[k, i, :] = stock k's SYM features at close i; X[k, i, :] = its tl_state context; M[i, :] = the market."""

    def __init__(self, D, symbols):
        self.D = D
        self.syms = list(symbols)
        self.k = {s: j for j, s in enumerate(self.syms)}
        n = D.cal.n
        self.S = np.full((len(self.syms), n, len(SYM)), np.nan, dtype=np.float32)
        self.X = np.full((len(self.syms), n, len(CTX)), np.nan, dtype=np.float32)
        self.close = np.full((len(self.syms), n), np.nan)          # forward-filled closes (path arithmetic)
        for s, j in self.k.items():
            b = D.bars[s]
            self.S[j] = stock_features(b)
            self.close[j] = _ffill(b["close"])
            cx = (getattr(D, "ctx", {}) or {}).get(s)
            if cx is not None:
                st = np.asarray(cx["state"])
                self.X[j, :, 0] = [STATE_IDX.get(int(x), 0) for x in st]
                self.X[j, :, 1] = np.asarray(cx["event"], dtype=float)
                ag = np.asarray(cx["age"], dtype=float)
                self.X[j, :, 2] = np.where(ag >= 0, ag, np.nan)
        self.M = market_features(D)

    def group(self, j, i):
        """tl_state state group (0 bull, 1 turn_flat, 2 bear, 3 other) of stock j at close i."""
        v = self.X[j, i, 0]
        if not np.isfinite(v):
            return 3
        return state_group(STATE_LIST[int(v)])


def assemble(fs, cols, j, i, sel, extra):
    """Rows for stocks j at closes i: the declared columns in order. sel: dict of SEL arrays; extra: dict of the
    window / position arrays. Returns float32 (rows, len(cols))."""
    j = np.asarray(j, dtype=np.int64)
    i = np.asarray(i, dtype=np.int64)
    out = np.empty((len(j), len(cols)), dtype=np.float32)
    sk = {c: k for k, c in enumerate(SYM)}
    mk = {c: k for k, c in enumerate(MKT)}
    xk = {c: k for k, c in enumerate(CTX)}
    for q, c in enumerate(cols):
        if c in sk:
            out[:, q] = fs.S[j, i, sk[c]]
        elif c in mk:
            out[:, q] = fs.M[i, mk[c]]
        elif c in xk:
            out[:, q] = fs.X[j, i, xk[c]]
        elif c in sel:
            out[:, q] = sel[c]
        elif c in extra:
            out[:, q] = extra[c]
        else:
            raise XLError("no values for column %s" % c)
    return out
