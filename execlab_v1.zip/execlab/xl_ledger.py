r"""xl_ledger.py - execlab: the research ledger (every selection, on its own) and the execution ledger (one portfolio
with the declared budgets), the comparators, and the money view (v2_money.simulate: Rs 10 lakh, 1/8 of equity a
position, integer shares, 2% of ADV, cash).

Allocator, at every close i (orders for session i + 1):
  budget = min(max_entries_day - 0, max_entries_5 - entries on sessions i-3 .. i, max_open - positions still held after
  i + 1's open); a stock already held (or already ordered today) is skipped (HELD_SYMBOL); the policy's orders are
  ranked by estimated advantage; fills are taken in that order; once the budget binds the rest are cancelled
  (NO_ROOM). A record that was not served keeps watching (its window still decides). Re-entry is allowed once a
  position is closed; no adding to an open position.
"""
import numpy as np

import xl_sim as S

STATUS = ("TRADED", "ABANDONED", "NO_FILL", "EXPIRED", "NO_ROOM", "HELD_SYMBOL", "OUT_OF_PERIOD")


def rows_policy(world, A, Qm, Fm, Pm, trades):
    """Per watch row: action (0 abandon, 1 wait, 2 enter), priority, filled, and the trade of the chosen order."""
    nq = len(A)
    act = np.where(A >= 2, 2, A).astype(np.int8)
    k = np.clip(A - 2, 0, len(S.ENTRY) - 1)
    q = np.arange(nq)
    best_alt = np.maximum(Qm[:, 1].clip(min=-1e9), 0.0)
    prio = np.where(act == 2, Qm[q, A] - best_alt, -np.inf)
    fill = (act == 2) & Fm[q, k]
    TI = np.full(Fm.shape, -1, dtype=np.int64)
    TI[trades["row"], trades["k"]] = np.arange(len(trades["row"]))
    ti = np.where(fill, TI[q, k], -1)
    fill &= ti >= 0
    return _rows(world, act, prio, fill, ti, trades, k)


def rows_open_sb(world, Fm, op6):
    """OPEN_SB: every record bought at T+1's open (the first watch row), sold at T+6's open."""
    W = world.W
    nq = world.n_rec * W
    d = np.tile(np.arange(W), world.n_rec)
    r = np.repeat(np.arange(world.n_rec), W)
    act = np.where(d == 0, 2, 0).astype(np.int8)
    prio = np.where(d == 0, -world.recs["rank"][r] + 1e-9 * np.nan_to_num(world.recs["score"][r]), -np.inf)
    ok = (d == 0) & Fm[:, 0] & np.isfinite(op6["open6"][r])
    t = world.recs["t"][r]
    tr = {"e": t + 1, "P": world.B.o[world.recs["j"][r], np.minimum(t + 1, world.B.n - 1)], "x": op6["open6_x"][r],
          "px": op6["open6_px"][r], "timing": op6["open6_tim"][r], "reason": np.full(nq, S.REASONS.index("EXIT"),
                                                                                    np.int8),
          "net": op6["open6"][r], "mfe": np.full(nq, np.nan), "mae": np.full(nq, np.nan)}
    ti = np.where(ok, np.arange(nq), -1)
    return _rows(world, act, prio, ok, ti, {"pos": {"e": tr["e"], "P": tr["P"]}, **tr}, np.zeros(nq, np.int64))


def _rows(world, act, prio, fill, ti, trades, k):
    pos = trades["pos"]
    g = lambda arr, fillv: np.where(ti >= 0, np.asarray(arr)[np.maximum(ti, 0)], fillv)   # noqa: E731
    return {"act": act, "prio": prio, "fill": fill, "kind": k,
            "e": g(pos["e"], -1).astype(np.int64), "P": g(pos["P"], np.nan), "x": g(trades["x"], -1).astype(np.int64),
            "px": g(trades["px"], np.nan), "timing": g(trades["timing"], 0).astype(np.int8),
            "reason": g(trades["reason"], 0).astype(np.int8), "net": g(trades["net"], np.nan),
            "mfe": g(trades["mfe"], np.nan), "mae": g(trades["mae"], np.nan)}


def research(world, R):
    """Unconstrained: each record follows its own decisions; returns per-record outcome arrays."""
    W = world.W
    nr = world.n_rec
    q = np.arange(nr * W).reshape(nr, W)
    out = {"status": np.full(nr, "EXPIRED", dtype=object), "row": np.full(nr, -1, np.int64)}
    live = np.ones(nr, bool)
    tried = np.zeros(nr, bool)
    for d in range(W):
        qq = q[:, d]
        ab = live & (R["act"][qq] == 0)
        out["status"][ab], out["row"][ab] = "ABANDONED", qq[ab]
        live &= ~ab
        en = live & (R["act"][qq] == 2)
        tried |= en
        f = en & R["fill"][qq]
        out["status"][f], out["row"][f] = "TRADED", qq[f]
        live &= ~f
    out["status"][(out["status"] == "EXPIRED") & tried] = "NO_FILL"
    return _outcome(world, R, out)


def _outcome(world, R, out):
    row = out["row"]
    tr = out["status"] == "TRADED"
    rr = np.maximum(row, 0)
    for f in ("e", "P", "x", "px", "timing", "reason", "net", "mfe", "mae", "kind", "prio"):
        v = R[f][rr]
        if v.dtype.kind == "f":
            out[f] = np.where(tr, v, np.nan)
        else:
            out[f] = np.where(tr, v, -1)
    out["decision_d"] = np.where(row >= 0, row % world.W, -1)
    out["net0"] = np.where(tr, out["net"], 0.0)          # unfilled = 0
    return out


def execution(world, R, decl):
    """The portfolio: the declared budgets over the records' own decisions."""
    pf = decl["portfolio"]
    W, n = world.W, world.B.n
    nr = world.n_rec
    t = world.recs["t"]
    sym = world.recs["sym"]
    status = np.full(nr, "EXPIRED", dtype=object)
    row = np.full(nr, -1, np.int64)
    tried = np.zeros(nr, bool)
    blocked = np.full(nr, "", dtype=object)
    done = np.zeros(nr, bool)
    by_close = {}
    for r in range(nr):
        for d in range(W):
            by_close.setdefault(int(t[r]) + d, []).append((r, d))
    held = []                      # (symbol, exit session, timing)
    entries = np.zeros(n + 2, np.int64)
    for i in sorted(by_close):
        held = [h for h in held if h[1] > i]           # sold at or before close i
        live = [(r, d) for r, d in by_close[i] if not done[r]]
        if not live:
            continue
        cands = []
        for r, d in live:
            q = r * W + d
            a = R["act"][q]
            if a == 0:
                status[r], row[r], done[r] = "ABANDONED", q, True
            elif a == 2:
                tried[r] = True
                cands.append((-R["prio"][q], world.recs["sid"][r], r, q))
        if not cands:
            continue
        cands.sort()
        open_after = sum(1 for h in held if not (h[1] == i + 1 and h[2] == 1))
        b5 = int(pf["max_entries_5"]) - int(entries[max(0, i - 3):i + 1].sum())
        budget = max(0, min(int(pf["max_entries_day"]), b5, int(pf["max_open"]) - open_after))
        hsyms = {h[0] for h in held}
        today = set()
        taken = 0
        for _, _, r, q in cands:
            s = sym[r]
            if s in hsyms or s in today:
                blocked[r] = "HELD_SYMBOL"
                continue
            if not R["fill"][q]:
                continue
            if taken >= budget:
                blocked[r] = "NO_ROOM"
                continue
            today.add(s)
            taken += 1
            status[r], row[r], done[r] = "TRADED", q, True
            held.append((s, int(R["x"][q]), int(R["timing"][q])))
            entries[int(R["e"][q])] += 1
    for r in range(nr):
        if status[r] == "EXPIRED":
            if blocked[r]:
                status[r] = blocked[r]
            elif tried[r]:
                status[r] = "NO_FILL"
    return _outcome(world, R, {"status": status, "row": row})


def book_trades(world, out):
    tr = []
    for r in np.flatnonzero(out["status"] == "TRADED"):
        tr.append({"sid": world.recs["sid"][r], "symbol": world.recs["sym"][r], "entry_idx": int(out["e"][r]),
                   "entry_raw": float(out["P"][r]), "exit_idx": int(out["x"][r]), "exit_raw": float(out["px"][r]),
                   "timing": S.TIMING[int(out["timing"][r])] or "close", "reason": S.REASONS[int(out["reason"][r])],
                   "net": float(out["net"][r])})
    return tr


def money(world, trades, decl, t_lo, t_hi, slots=None):
    import v2_money as M
    pf = decl["portfolio"]
    sim = M.simulate(world.D.cal, world.D.bars, trades, world.D.cm, capital=float(pf["capital"]),
                     slots=int(slots or pf["slots"]), t_lo=int(t_lo), t_hi=int(t_hi),
                     integer=bool(pf["integer_shares"]), liq_cap=float(pf["liq_cap"]))
    return sim, M.daily_returns(sim), M.perf(sim, world.D.cal.days)


def plan_native_book(world, t_lo, t_hi):
    """Stage E style: the first 3 buyable picks a day (ranks 1-3), T+1 open to T+5 close."""
    import v2_book2 as VB

    class Pool:
        def __init__(self, items):
            self.items = items

        def active(self):
            return self.items

    sels = [s for s in world.all_recs if s.t_idx in set(world.recs["t"].tolist())]
    bk = VB.plan_native(world.D.cal, world.D.bars, Pool(sels), 3, t_lo=int(t_lo), t_hi=int(t_hi))
    return [{"sid": x["sid"], "symbol": x["symbol"], "entry_idx": x["entry_idx"], "entry_raw": x["entry_raw"],
             "exit_idx": x["exit_idx"], "exit_raw": x["exit_raw"], "timing": x["timing"], "reason": x["reason"],
             "net": x["net"]} for x in bk["trades"]]


def check_budgets(world, out, decl):
    """Every declared rule, counted on the execution ledger's trades (the tests' independent check)."""
    pf = decl["portfolio"]
    tr = np.flatnonzero(out["status"] == "TRADED")
    e, x, tim = out["e"][tr], out["x"][tr], out["timing"][tr]
    sym = world.recs["sym"][tr]
    viol = {"day": 0, "five": 0, "open": 0, "symbol": 0}
    if not len(tr):
        return viol
    for i in np.unique(e):
        viol["day"] += int((e == i).sum() > int(pf["max_entries_day"]))
        viol["five"] += int(((e > i - 5) & (e <= i)).sum() > int(pf["max_entries_5"]))
        held = (e <= i) & ((x > i) | ((x == i) & (tim != 1)))
        viol["open"] += int(held.sum() > int(pf["max_open"]))
    for s in np.unique(sym):
        m = sym == s
        ee, xx = e[m], x[m]
        o = np.argsort(ee)
        ee, xx = ee[o], xx[o]
        viol["symbol"] += int(np.any(ee[1:] <= xx[:-1]))
    return viol
