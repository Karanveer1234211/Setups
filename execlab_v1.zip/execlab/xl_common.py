r"""xl_common.py - execlab: version, the declaration, the ledger, output guards and the statistics.

Statistics (every interval in execlab comes from here):
  block_mean        mean per observation with a 95% circular block bootstrap over signal days (paired values)
  daily_diff        mean daily difference of two return series, block bootstrap over sessions
  romano_wolf       step-down max-t over k candidates (paired daily differences): family-wise adjusted p-values
  bh                Benjamini-Hochberg false-discovery control
  pbo_cscv          probability of backtest overfitting, combinatorially symmetric cross-validation
  cagr_at_dd        CAGR when position size is scaled until the worst drawdown is the target (scaled-returns
                    shortcut: exact for a constant fraction of equity per day, an approximation for slots)
  purged_folds      time-block folds over signal days; a training record whose window + hold overlaps the test
                    block (either side) is removed, so no outcome path is shared between training and testing
"""
import hashlib
import itertools
import json
import math
import os
from pathlib import Path

import numpy as np

VERSION = "execlab v1.0"
HERE = Path(__file__).resolve().parent
CODE_FILES = ("execlab.py", "xl_common.py", "xl_data.py", "xl_feat.py", "xl_sim.py", "xl_learn.py", "xl_ledger.py",
              "xl_eval.py", "xl_cards.py", "xl_report.py")
DAYS_PER_YEAR = 250


class XLError(Exception):
    pass


# ============================================================================ hashing, declaration, ledger
def sha16_bytes(b):
    return hashlib.sha256(b).hexdigest()[:16]


def sha16_file(p):
    return sha16_bytes(Path(p).read_bytes())


def canon(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str)


def sha16_obj(obj):
    return sha16_bytes(canon(obj).encode("utf-8"))


def load_decl(path=None):
    p = Path(path) if path else HERE / "XL_DECLARATION.json"
    if not p.exists():
        raise XLError("declaration %s not found" % p)
    d = json.loads(p.read_text(encoding="utf-8"))
    if d.get("version") != VERSION:
        raise XLError("declaration is for %r, this code is %s" % (d.get("version"), VERSION))
    d["_fingerprint"] = sha16_obj({k: v for k, v in d.items() if not k.startswith("_")})
    d["_path"] = str(p)
    return d


def code_hashes():
    return {f: sha16_file(HERE / f) for f in CODE_FILES if (HERE / f).exists()}


def ledger_append(out, rec):
    p = Path(out) / "execlab_ledger.jsonl"
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8", newline="\n") as fh:
        fh.write(json.dumps(rec, sort_keys=True, default=str) + "\n")


def guard_out(out, root=None):
    """Outputs never go inside the cache or a production / tool folder."""
    o = Path(out).resolve()
    bad = []
    for k in ("CACHE_DAILY_ROOT", "BIGMOVE_DIR", "TRADELAB_DIR", "PATHLAB_DIR", "V2_DIR", "XL_DIR", "PB_DIR"):
        v = os.environ.get(k)
        if v:
            bad.append(Path(v).resolve())
    if root:
        bad.append(Path(root).resolve())
    bad.append(HERE)                                   # never inside execlab's own folder
    for b in bad:
        try:
            o.relative_to(b)
            raise XLError("refused: output %s is inside %s" % (o, b))
        except ValueError:
            pass
    return o


# ============================================================================ statistics
def _block_index(n, B, block, rng):
    k = int(math.ceil(n / block))
    starts = rng.integers(0, n, size=(B, k))
    return ((starts[:, :, None] + np.arange(block)[None, None, :]) % n).reshape(B, -1)[:, :n]


def block_mean(days, vals, B=2000, block=10, seed=7, min_days=20):
    """Mean per observation of vals (paired differences are passed in as vals) and its 95% interval: circular
    block bootstrap over the distinct signal days. Returns dict(mean, lo, hi, n, days)."""
    vals = np.asarray(vals, dtype=float)
    days = np.asarray(days)
    ok = np.isfinite(vals)
    vals, days = vals[ok], days[ok]
    out = {"mean": np.nan, "lo": np.nan, "hi": np.nan, "p": np.nan, "n": int(len(vals)), "days": 0}
    if len(vals) == 0:
        return out
    ud, inv = np.unique(days, return_inverse=True)
    sums = np.bincount(inv, weights=vals, minlength=len(ud))
    cnts = np.bincount(inv, minlength=len(ud)).astype(float)
    out["mean"] = float(sums.sum() / cnts.sum())
    out["days"] = int(len(ud))
    if len(ud) < min_days:
        return out
    idx = _block_index(len(ud), B, block, np.random.default_rng(seed))
    bs = sums[idx].sum(axis=1) / np.maximum(cnts[idx].sum(axis=1), 1e-12)
    out["lo"], out["hi"] = float(np.quantile(bs, 0.025)), float(np.quantile(bs, 0.975))
    c = bs - out["mean"]                                  # centred: the share of draws as far from 0 (two-sided)
    out["p"] = float(min(1.0, np.mean(np.abs(c) >= abs(out["mean"]))))
    return out


def daily_diff(a, b, B=2000, block=10, seed=7):
    """Mean of a - b (two daily return series on the same sessions) with a block-bootstrap interval."""
    d = np.asarray(a, dtype=float) - np.asarray(b, dtype=float)
    d = d[np.isfinite(d)]
    out = {"mean": np.nan, "lo": np.nan, "hi": np.nan, "n": int(len(d))}
    if len(d) < 20:
        if len(d):
            out["mean"] = float(d.mean())
        return out
    idx = _block_index(len(d), B, block, np.random.default_rng(seed))
    bs = d[idx].mean(axis=1)
    out.update(mean=float(d.mean()), lo=float(np.quantile(bs, 0.025)), hi=float(np.quantile(bs, 0.975)))
    return out


def romano_wolf(diffs, B=2000, block=10, seed=7):
    """diffs: (k, n) paired daily differences (candidate minus comparator) on the same sessions. Step-down max-t
    (Romano and Wolf 2005) with the same block draws for every candidate. Returns per candidate: mean, t and the
    family-wise adjusted one-sided p-value (H0: mean <= 0)."""
    D = np.asarray(diffs, dtype=float)
    if D.ndim == 1:
        D = D[None, :]
    k, n = D.shape
    ok = np.all(np.isfinite(D), axis=0)
    D = D[:, ok]
    n = D.shape[1]
    if n < 20:
        return [{"mean": float(np.nanmean(D[i])) if n else np.nan, "t": np.nan, "p_adj": np.nan} for i in range(k)]
    idx = _block_index(n, B, block, np.random.default_rng(seed))
    m = D.mean(axis=1)
    bm = D[:, idx].mean(axis=2)                     # (k, B)
    se = bm.std(axis=1, ddof=1)
    se = np.where(se > 0, se, np.nan)
    t = m / se
    tb = (bm - m[:, None]) / se[:, None]            # centred bootstrap t
    order = np.argsort(-np.nan_to_num(t, nan=-np.inf))
    p_adj = np.full(k, np.nan)
    running = 0.0
    active = list(order)
    for j in order:
        mx = np.nanmax(tb[active], axis=0)
        p = float(np.mean(mx >= t[j])) if np.isfinite(t[j]) else 1.0
        running = max(running, p)
        p_adj[j] = running
        active.remove(j)
    return [{"mean": float(m[i]), "t": float(t[i]), "p_adj": float(p_adj[i])} for i in range(k)]


def bh(p, q=0.05):
    p = np.asarray(p, dtype=float)
    ok = np.isfinite(p)
    rej = np.zeros(len(p), bool)
    qv = np.full(len(p), np.nan)
    if ok.sum() == 0:
        return rej, qv
    pv = p[ok]
    m = len(pv)
    o = np.argsort(pv)
    ranked = pv[o] * m / (np.arange(m) + 1)
    qq = np.minimum.accumulate(ranked[::-1])[::-1]
    qa = np.empty(m)
    qa[o] = np.minimum(qq, 1.0)
    qv[ok] = qa
    rej[ok] = qa <= q
    return rej, qv


def pbo_cscv(R, S=10):
    """R: (n_configs, n_sessions) daily returns. Splits the sessions into S contiguous blocks; for every choice of
    S/2 blocks as 'in sample', the in-sample best configuration (by mean return) is ranked out of sample. PBO =
    share of splits where it ranks at or below the out-of-sample median (logit <= 0). Bailey et al. (2017)."""
    R = np.asarray(R, dtype=float)
    N, T = R.shape
    if N < 2 or T < 2 * S:
        return {"pbo": np.nan, "splits": 0, "configs": int(N)}
    cuts = np.array_split(np.arange(T), S)
    means = np.array([[np.nanmean(R[i, c]) for c in cuts] for i in range(N)])     # (N, S) block means
    lens = np.array([len(c) for c in cuts], dtype=float)
    logits = []
    for js in itertools.combinations(range(S), S // 2):
        ins = np.zeros(S, bool)
        ins[list(js)] = True
        mi = (means[:, ins] * lens[ins]).sum(axis=1) / lens[ins].sum()
        mo = (means[:, ~ins] * lens[~ins]).sum(axis=1) / lens[~ins].sum()
        best = int(np.argmax(mi))
        rank = (mo < mo[best]).sum() + 0.5 * ((mo == mo[best]).sum() - 1) + 1     # 1 = worst
        w = rank / (N + 1)
        logits.append(math.log(w / (1 - w)))
    lg = np.array(logits)
    return {"pbo": float(np.mean(lg <= 0)), "splits": int(len(lg)), "configs": int(N),
            "logit_median": float(np.median(lg))}


def max_dd(r):
    eq = np.cumprod(1.0 + np.asarray(r, dtype=float))
    eq = np.r_[1.0, eq]
    return float((eq / np.maximum.accumulate(eq) - 1.0).min())


def cagr_of(r):
    r = np.asarray(r, dtype=float)
    if len(r) == 0:
        return np.nan
    g = float(np.prod(1.0 + r))
    return g ** (DAYS_PER_YEAR / len(r)) - 1.0 if g > 0 else -1.0


def cagr_at_dd(r, target=-0.25):
    """f* in (0, 1] so that the scaled daily returns f x r reach the target worst drawdown (1 when they never do);
    CAGR at f*. The scaled-returns shortcut (dd_replay): exact for a constant fraction of equity, approximate for
    slot sizing."""
    r = np.asarray(r, dtype=float)
    r = r[np.isfinite(r)]
    if len(r) == 0:
        return {"f": np.nan, "cagr": np.nan, "max_dd": np.nan}
    if max_dd(r) >= target:
        return {"f": 1.0, "cagr": cagr_of(r), "max_dd": max_dd(r)}
    lo, hi = 0.0, 1.0
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        if max_dd(mid * r) >= target:
            lo = mid
        else:
            hi = mid
    return {"f": float(lo), "cagr": cagr_of(lo * r), "max_dd": max_dd(lo * r)}


def purged_folds(t_rec, K, horizon):
    """t_rec: calendar index of each record's signal day. K contiguous blocks of distinct signal days (equal
    counts); for each block, train = records whose [t, t + horizon] does not overlap [first t, last t + horizon]
    of the block. Returns a list of (test_idx, train_idx) over record positions."""
    t = np.asarray(t_rec, dtype=np.int64)
    ud = np.unique(t)
    if K < 2 or len(ud) < K:
        raise XLError("cannot make %d folds from %d signal days" % (K, len(ud)))
    blocks = np.array_split(ud, K)
    out = []
    for blk in blocks:
        a, b = int(blk[0]), int(blk[-1])
        test = np.flatnonzero((t >= a) & (t <= b))
        train = np.flatnonzero((t + horizon < a) | (t > b + horizon))
        out.append((test, train))
    return out


def fmt_pct(x, nd=2):
    return "-" if x is None or not np.isfinite(x) else ("%+.*f%%" % (nd, 100 * x))


def fmt_bp(x, nd=1):
    return "-" if x is None or not np.isfinite(x) else ("%+.*f bp" % (nd, 1e4 * x))


def fmt_ci(s, unit="pct", nd=2):
    """{'mean','lo','hi'} -> '+1.23% [+0.10, +2.40]' or '+12.3 bp [...]' ."""
    if not s or s.get("mean") is None or not np.isfinite(s["mean"]):
        return "-"
    k = 100.0 if unit == "pct" else 1e4
    u = "%" if unit == "pct" else " bp"
    if not np.isfinite(s.get("lo", np.nan)):
        return "%+.*f%s (too few days)" % (nd, k * s["mean"], u)
    return "%+.*f%s [%+.*f, %+.*f]" % (nd, k * s["mean"], u, nd, k * s["lo"], nd, k * s["hi"])
