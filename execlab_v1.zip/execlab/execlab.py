r"""execlab.py - execlab v1.0: the execution research engine on BigMove's selections.

  python execlab.py --selftest [quick]
  python execlab.py discover --root %CACHE_DAILY_ROOT% --out %XL_OUT%          (2020-22 only; 2023-25 is not loaded)
  python execlab.py freeze   --out %XL_OUT% --run disc_<id>                    (the candidates and the acceptance rule)
  python execlab.py evaluate --root %CACHE_DAILY_ROOT% --out %XL_OUT%          (once: the sealed 2023-25)
  python execlab.py status   --out %XL_OUT%

Reads production READ ONLY through v2engine 0.3 (tradelab, stage E's costs). Writes only under --out. Every command
appends to <out>\execlab_ledger.jsonl.
"""
import argparse
import json
import os
import pickle
import platform
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import xl_common as XC  # noqa: E402
import xl_eval as EV  # noqa: E402
import xl_feat as F  # noqa: E402
import xl_learn as XLL  # noqa: E402
import xl_ledger as LG  # noqa: E402
import xl_report as RP  # noqa: E402
import xl_sim as S  # noqa: E402
from xl_cards import exit_cards, setup_cards  # noqa: E402

QUICK = {"learning.folds": 3, "learning.iterations_hold": 2, "learning.iterations_watch": 2,
         "learning.hold_sample_entries": 2, "learning.max_train_rows": 60000, "learning.hgb.max_iter": 60,
         "learning.hgb.learning_rate": 0.1}


def set_path(d, dotted, v):
    ks = dotted.split(".")
    for k in ks[:-1]:
        d = d[k]
    d[ks[-1]] = v


def versions():
    out = {"python": platform.python_version(), "numpy": np.__version__}
    try:
        import pandas
        out["pandas"] = pandas.__version__
    except ImportError:
        pass
    try:
        import sklearn
        out["sklearn"] = sklearn.__version__
    except ImportError:
        out["sklearn"] = None
    return out


def parse_ranks(s):
    out = []
    for part in str(s).split(","):
        if "-" in part:
            a, b = part.split("-")
            out += list(range(int(a), int(b) + 1))
        elif part.strip():
            out.append(int(part))
    return sorted(set(out))


def strip(qs):
    """Only the models trained on everything (fold -1): what is frozen."""
    q = XLL.QSet(qs.actions, qs.cols, qs.specialised, qs.ref, qs.level)
    q.models = {k: v for k, v in qs.models.items() if k[0] == -1}
    q.const = {k: v for k, v in qs.const.items() if k[0] == -1}
    return q


def real_loader(a, decl, t_from, t_to, seal_end, log):
    import xl_data as XD
    return XD.load_real(a.root, a.pm_run, a.engines, a.ranks, t_from, t_to, seal_end, log=log,
                        stage_e_any=a.stage_e_any, tradelab_any=a.tradelab_any, costs=a.costs,
                        max_symbols=a.max_symbols, warmup=int(decl["data"]["warmup_sessions"]))


# ============================================================================ one engine
def _base(world, decl, op6, Fm, t_lo, t_hi):
    R0 = LG.rows_open_sb(world, Fm, op6)
    e0 = LG.execution(world, R0, decl)
    _, r0, p0 = LG.money(world, LG.book_trades(world, e0), decl, t_lo, t_hi)
    pn = LG.plan_native_book(world, t_lo, t_hi)
    _, rP, pP = LG.money(world, pn, decl, t_lo, t_hi, slots=15)
    return e0, r0, EV.portfolio_metrics(r0, p0, None, decl), rP, EV.portfolio_metrics(rP, pP, r0, decl)


def _detail(world, decl, cfg, X, cols, op6, qh, trades, hurdle, log):
    res = cfg["res"]
    co, ab = EV.cohorts(world, res)
    cfg["cohorts"], cfg["abandons"] = co, ab
    cfg["groups"] = EV.context_groups(world, res, op6, decl)
    cfg["setup_cards"] = setup_cards(world, X, cols, cfg["A"], res, op6, XLL.WATCH_ACTIONS, decl)
    tr = np.flatnonzero(res["status"] == "TRADED")
    if len(tr):
        ti = {(int(rw), int(k)): q for q, (rw, k) in enumerate(zip(trades["row"], trades["k"]))}
        sel = np.array([ti[(int(res["row"][r]), int(res["kind"][r]))] for r in tr])
        pos = {k: np.asarray(v)[sel] for k, v in trades["pos"].items()}
        trace = []
        _, hm = XLL._menus(decl)
        S.hold_forward(world.B, pos, XLL.hold_decider(world, qh, pos, full=cfg.get("full", False)), world.H, hm,
                       decl["fills"]["exit_slip_atr"], trace=trace)
        if trace:
            ids = np.concatenate([t[0] for t in trace])
            hh = np.concatenate([t[1] for t in trace])
            acts = np.concatenate([t[2] for t in trace])
            rmax = np.concatenate([t[3] for t in trace])
            R = world.recs
            r = pos["r"][ids]
            Xh = world.hold_X(qh.cols, pos["j"][ids], pos["e"][ids] + hh, pos["e"][ids], R["t"][r], pos["P"][ids],
                              pos["kind"][ids], R["rank"][r], R["score"][r], rmax)
            cfg["exit_cards"] = exit_cards(Xh, qh.cols, acts, S.HOLDA, decl)
    if not cfg.get("full"):                       # exploratory, never frozen: discovery only
        cfg["intraday"] = EV.intraday_study(world, res, decl, hurdle, log)


def engine_discover(D, decl, eng, ranks, t_from, t_to, B, fs, variants, hurdles, log):
    t0 = time.time()
    world = XLL.World(D, decl, eng, ranks, t_from, t_to, log=log, B=B, fs=fs)
    E = {"n_all": len(world.all_recs), "n_rec": world.n_rec, "n_oop": len(world.out_of_period), "configs": {},
         "learning": {}, "world": world}
    need = int(decl["learning"]["min_records"])
    if world.n_rec < need:
        E["skipped"] = "Engine %s: %d selections with a complete path - too few to learn from (%d needed)." % (
            eng, world.n_rec, need)
        return E, {}
    op6 = S.comparators(B, world.recs)
    E["op6"] = op6
    r, a, d = world.watch_rows()
    Fm, Pm = XLL.entry_table(world, r, a)
    t_lo, t_hi = int(world.recs["t"].min()), D.cal.n - 1
    E["t_lo"], E["t_hi"] = t_lo, t_hi
    e0, r0, E["open_sb"], rP, E["plan_native"] = _base(world, decl, op6, Fm, t_lo, t_hi)
    E["open_sb_exe"], E["daily"] = e0, {"OPEN_SB": r0, "PLAN_native": rP}
    E["base_research"] = EV.research_metrics(world, {"net0": np.nan_to_num(op6["open6"]), "status": np.where(
        np.isfinite(op6["open6"]), "TRADED", "NO_FILL").astype(object), "net": op6["open6"],
        "x": np.where(np.isfinite(op6["open6"]), op6["open6_x"], -1), "e": world.recs["t"] + 1,
        "mfe": np.full(world.n_rec, np.nan), "mae": np.full(world.n_rec, np.nan),
        "kind": np.zeros(world.n_rec, np.int64), "reason": np.ones(world.n_rec, np.int8)}, op6, decl)
    models = {"hold": {}, "watch": {}}
    keep = {}
    for v in variants:
        qh, hd = XLL.learn_hold(world, v, log)
        E["learning"]["hold %s" % v] = hd["value_by_iteration"]
        NETm, trades = XLL.enter_outcomes(world, qh, r, a, Fm, Pm)
        cols = F.columns("watch", v)
        Xw = world.watch_X(cols, r, a)
        models["hold"][v] = strip(qh)
        for hb in hurdles:
            qw, _, wd = XLL.learn_watch(world, v, Xw, r, a, d, Fm, NETm, hb, log)
            E["learning"]["watch %s %dbp" % (v, hb)] = wd["value_by_iteration"]
            A, Qm = XLL.watch_decisions(world, qw, Xw, r, a, d)
            R = LG.rows_policy(world, A, Qm, Fm, Pm, trades)
            res, exe = LG.research(world, R), LG.execution(world, R, decl)
            _, rr, pf = LG.money(world, LG.book_trades(world, exe), decl, t_lo, t_hi)
            name = "%s/%dbp" % (v, hb)
            E["configs"][name] = {"variant": v, "hurdle": hb, "res": res, "exe": exe, "A": A,
                                  "research": EV.research_metrics(world, res, op6, decl),
                                  "portfolio": EV.portfolio_metrics(rr, pf, r0, decl),
                                  "budget_check": LG.check_budgets(world, exe, decl)}
            E["daily"][name] = rr
            models["watch"][name] = strip(qw)
        keep[v] = (qh, trades, Xw, cols)
    names = list(E["configs"])
    E["rw"], E["pbo"] = EV.family({k: E["daily"][k] for k in names}, r0, decl)
    E["candidates"] = EV.candidates(E["configs"], E["rw"], decl)
    best = E["candidates"][0] if E["candidates"] else max(names, key=lambda k: E["rw"][k]["mean"])
    E["best"] = best
    for name in dict.fromkeys(E["candidates"] + [best]):
        c = E["configs"][name]
        qh, trades, Xw, cols = keep[c["variant"]]
        _detail(world, decl, c, Xw, cols, op6, qh, trades, c["hurdle"], log)
    log("   %s done in %.0f s; candidates: %s" % (eng, time.time() - t0, ", ".join(E["candidates"]) or "none"))
    return E, models


def engine_evaluate(D, decl, eng, ranks, t_from, t_to, B, fs, cands, models, log):
    world = XLL.World(D, decl, eng, ranks, t_from, t_to, folds=1, log=log, B=B, fs=fs)
    E = {"n_all": len(world.all_recs), "n_rec": world.n_rec, "n_oop": len(world.out_of_period), "configs": {},
         "world": world}
    if world.n_rec == 0 or not cands:
        E["skipped"] = "Engine %s: %s." % (eng, "no frozen candidate" if not cands else "no selections")
        return E
    op6 = S.comparators(B, world.recs)
    E["op6"] = op6
    r, a, d = world.watch_rows()
    Fm, Pm = XLL.entry_table(world, r, a)
    t_lo, t_hi = int(world.recs["t"].min()), D.cal.n - 1
    E["t_lo"], E["t_hi"] = t_lo, t_hi
    e0, r0, E["open_sb"], rP, E["plan_native"] = _base(world, decl, op6, Fm, t_lo, t_hi)
    E["daily"] = {"OPEN_SB": r0, "PLAN_native": rP}
    days = D.cal.days[t_lo:t_hi + 1]
    for name in cands:
        v, hb = name.split("/")[0], int(name.split("/")[1].replace("bp", ""))
        qh, qw = models["hold"][v], models["watch"][name]
        cols = F.columns("watch", v)
        Xw = world.watch_X(cols, r, a)
        A, Qm = XLL.watch_decisions(world, qw, Xw, r, a, d, full=True)
        want = np.zeros(Fm.shape, bool)
        m = A >= 2
        want[np.flatnonzero(m), A[m] - 2] = True
        NETm, trades = XLL.enter_outcomes(world, qh, r, a, Fm, Pm, full=True, only=want)
        R = LG.rows_policy(world, A, Qm, Fm, Pm, trades)
        res, exe = LG.research(world, R), LG.execution(world, R, decl)
        _, rr, pf = LG.money(world, LG.book_trades(world, exe), decl, t_lo, t_hi)
        c = {"variant": v, "hurdle": hb, "res": res, "exe": exe, "A": A, "full": True,
             "research": EV.research_metrics(world, res, op6, decl),
             "portfolio": EV.portfolio_metrics(rr, pf, r0, decl), "budget_check": LG.check_budgets(world, exe, decl)}
        c["years"] = EV.yearly(days, rr, r0)
        E["configs"][name] = c
        E["daily"][name] = rr
        _detail(world, decl, c, Xw, cols, op6, qh, trades, hb, log)
    E["rw"], _ = EV.family({k: E["daily"][k] for k in cands}, r0, decl)
    E["acceptance"] = {}
    for name in cands:
        c = E["configs"][name]
        acc = EV.acceptance(c["portfolio"], E["open_sb"], c["research"]["majors"]["capture_share"], c["years"],
                            E["rw"][name]["p_adj"], len(cands))
        acc["years"] = c["years"]
        E["acceptance"][name] = acc
    E["best"] = cands[0]
    return E


# ============================================================================ outputs
def write_outputs(out_dir, run, engines_out, decl, sealed):
    out_dir.mkdir(parents=True, exist_ok=True)
    lr, le, cfgs, groups, sc, ec = [], [], [], [], [], []
    daily_cols, daily = [], []
    for eng, E in engines_out.items():
        if E.get("skipped"):
            continue
        w, op6 = E["world"], E["op6"]
        for name, c in E["configs"].items():
            lr += RP.ledger_rows(w, eng, name, c["res"], op6, decl)
            le += RP.ledger_rows(w, eng, name, c["exe"], op6, decl)
            m, p = c["research"], c["portfolio"]
            cfgs.append({"engine": eng, "config": name, "net": m["net"]["mean"], "net_lo": m["net"]["lo"],
                         "net_hi": m["net"]["hi"], "vs_open6": m["vs_open6"]["mean"], "vs_open6_lo": m["vs_open6"]["lo"],
                         "vs_open6_hi": m["vs_open6"]["hi"], "traded": m["trades"]["n"], "win": m["trades"]["win"],
                         "majors_capture": m["majors"]["capture_share"], "majors_missed": m["majors"]["missed"],
                         "bad_avoided": m["bad"]["avoided"], "false_trigger_share": m["false_triggers"]["share"],
                         "cagr": p["cagr"], "max_dd": p["max_dd"], "sharpe": p["sharpe"], "cagr_at_dd": p["at_dd"]["cagr"],
                         "excess": p["excess"]["mean"], "excess_lo": p["excess"]["lo"], "excess_hi": p["excess"]["hi"],
                         "rw_p": E.get("rw", {}).get(name, {}).get("p_adj"), "trades_book": p["trades"],
                         "budget_violations": sum(c["budget_check"].values())})
            for g in c.get("groups", []):
                groups.append({"engine": eng, "config": name, "group": g["group"], "n": g["n"], "traded": g["traded"],
                               "diff": g["diff"]["mean"], "lo": g["diff"]["lo"], "hi": g["diff"]["hi"], "p": g["p"],
                               "q": g["q"], "flag": int(g["flag"])})
            for k, cd in enumerate(c.get("setup_cards", []), 1):
                sc.append({"engine": eng, "config": name, "card": k, "rule": cd["rule"], "rows": cd["rows"],
                           "decided": cd["records_decided"], "actions": cd["actions"], "vs_open6": cd["vs_open6"]["mean"],
                           "lo": cd["vs_open6"].get("lo"), "hi": cd["vs_open6"].get("hi")})
            for k, cd in enumerate(c.get("exit_cards", []), 1):
                ec.append({"engine": eng, "config": name, "card": k, "rule": cd["rule"], "rows": cd["rows"],
                           "actions": cd["actions"]})
        days = w.D.cal.days[E["t_lo"]:E["t_hi"] + 1] if "t_lo" in E else None
        for k, v in E["daily"].items():
            daily_cols.append("%s %s" % (eng, k))
            daily.append((days, v))
    RP.write_csv(out_dir / "ledger_research.csv", RP.LEDGER_COLS, lr)
    RP.write_csv(out_dir / "ledger_execution.csv", RP.LEDGER_COLS, le)
    if cfgs:
        RP.write_csv(out_dir / "configs.csv", list(cfgs[0]), cfgs)
    RP.write_csv(out_dir / "context_groups.csv", ("engine", "config", "group", "n", "traded", "diff", "lo", "hi", "p",
                                                  "q", "flag"), groups)
    RP.write_csv(out_dir / "cards_setup.csv", ("engine", "config", "card", "rule", "rows", "decided", "actions",
                                               "vs_open6", "lo", "hi"), sc)
    RP.write_csv(out_dir / "cards_exit.csv", ("engine", "config", "card", "rule", "rows", "actions"), ec)
    if daily:
        allday = sorted({str(d) for days, _ in daily if days is not None for d in days})
        idx = {d: q for q, d in enumerate(allday)}
        M = np.full((len(allday), len(daily)), np.nan)
        for c, (days, v) in enumerate(daily):
            for d, x in zip(days, v):
                M[idx[str(d)], c] = x
        RP.write_csv(out_dir / "daily_returns.csv", ["session"] + daily_cols,
                     [[d] + list(M[q]) for q, d in enumerate(allday)])
    (out_dir / "RUN.json").write_text(json.dumps(run, indent=1, sort_keys=True, default=str), encoding="utf-8")
    RP.report(out_dir / "REPORT.md", "execlab %s" % ("sealed evaluation 2023-25" if sealed else "discovery"), run,
              engines_out, decl, sealed)


# ============================================================================ commands
def _decl(a):
    decl = XC.load_decl(a.decl)
    over = {}
    if getattr(a, "quick", False):
        for k, v in QUICK.items():
            set_path(decl, k, v)
            over[k] = v
    for k in ("model",):
        v = getattr(a, k, None)
        if v:
            set_path(decl, "learning.model", v)
            over["learning.model"] = v
    if getattr(a, "folds", None):
        set_path(decl, "learning.folds", int(a.folds))
        over["learning.folds"] = int(a.folds)
    return decl, over


def cmd_discover(a, loader, log):
    decl, over = _decl(a)
    variants = list(decl["variants"])
    hurdles = [int(x) for x in decl["hurdles_bp"]]
    if a.variants:
        variants = [v for v in a.variants.split(",") if v]
        over["variants"] = variants
    if a.hurdles:
        hurdles = [int(x) for x in a.hurdles.split(",") if x != ""]
        over["hurdles_bp"] = hurdles
    dd = decl["data"]
    a.pm_run = a.pm_run or dd["pm_run"]
    t_from = a.d_from or dd["discovery_from"]
    t_to = a.d_to or dd["discovery_to"]
    if np.datetime64(t_to, "D") > np.datetime64(dd["discovery_to"], "D"):
        log("REFUSED: discovery ends at %s; 2023-25 stays sealed until freeze (then: evaluate)" % dd["discovery_to"])
        return 3
    if t_from != dd["discovery_from"]:
        over["from"] = t_from
    if t_to != dd["discovery_to"]:
        over["to"] = t_to
    if a.pm_run != dd["pm_run"]:
        over["pm_run"] = a.pm_run
    for k in ("max_symbols", "stage_e_any", "tradelab_any"):
        if getattr(a, k, None):
            over[k] = getattr(a, k)
    if a.costs != "stage_e":
        over["costs"] = a.costs
    out = XC.guard_out(a.out, a.root)
    key = {"decl": decl["_fingerprint"], "over": over, "code": XC.code_hashes(), "pm_run": a.pm_run,
           "engines": a.engines, "ranks": a.ranks, "from": t_from, "to": t_to, "root": str(a.root)}
    rid = XC.sha16_obj(key)
    tag = "disc_%s%s" % (rid, "" if a.ranks == [1, 2, 3] else "_r%d-%d" % (min(a.ranks), max(a.ranks)))
    od = out / tag
    if (od / "REPORT.md").exists() and not a.again:
        log("REFUSED: %s already holds this exact run (same declaration, code, data and settings); --again repeats "
            "it" % od)
        return 3
    t0 = time.time()
    XC.ledger_append(out, {"cmd": "discover", "run": tag, "start": time.strftime("%Y-%m-%d %H:%M:%S"), **key})
    log("execlab discover %s -> %s" % (XC.VERSION, od))
    D = loader(a, decl, t_from, t_to, t_to, log)
    if np.datetime64(D.cal.days[-1], "D") > np.datetime64(dd["discovery_to"], "D"):
        raise XC.XLError("the loaded calendar ends after the discovery period (%s): refusing" % D.cal.days[-1])
    B = S.Bars(D, sorted({s.symbol for s in D.registry.active()}), int(decl["window"]["lock_wait"]))
    fs = F.FeatureStore(D, B.syms)
    engines_out, models = {}, {}
    for eng in a.engines:
        E, mdl = engine_discover(D, decl, eng, a.ranks, t_from, t_to, B, fs, variants, hurdles, log)
        engines_out[eng], models[eng] = E, mdl
    od.mkdir(parents=True, exist_ok=True)
    blob = pickle.dumps({"version": XC.VERSION, "models": models}, protocol=4)
    (od / "models.pkl").write_bytes(blob)
    cand = {"run": tag, "decl_fingerprint": decl["_fingerprint"], "overrides": over, "ranks": a.ranks,
            "models_sha16": XC.sha16_bytes(blob), "code": XC.code_hashes(), "versions": versions(),
            "rule": decl["candidates"]["rule"],
            "candidates": {e: E.get("candidates", []) for e, E in engines_out.items()},
            "rw": {e: {k: v for k, v in E.get("rw", {}).items()} for e, E in engines_out.items()}}
    (od / "candidates.json").write_text(json.dumps(cand, indent=1, default=str), encoding="utf-8")
    run = {"version": XC.VERSION, "decl_fingerprint": decl["_fingerprint"], "when": time.strftime("%Y-%m-%d %H:%M"),
           "t_from": t_from, "t_to": t_to, "data_to": str(D.cal.days[-1]), "ranks": a.ranks, "engines": a.engines,
           "overrides": over, "code": XC.code_hashes(), "versions": versions(), "data": D.info,
           "seconds": round(time.time() - t0, 1)}
    write_outputs(od, run, engines_out, decl, sealed=False)
    XC.ledger_append(out, {"cmd": "discover", "run": tag, "done": time.strftime("%Y-%m-%d %H:%M:%S"),
                           "candidates": cand["candidates"], "seconds": run["seconds"]})
    log("done in %.0f s: %s" % (time.time() - t0, od / "REPORT.md"))
    for e, c in cand["candidates"].items():
        log("   %s candidates: %s" % (e, ", ".join(c) or "none"))
    return 0


def cmd_freeze(a, log):
    out = XC.guard_out(a.out, getattr(a, "root", None))
    decl = XC.load_decl(a.decl)
    od = out / a.run
    fz = out / "FROZEN.json"
    try:
        cand = json.loads((od / "candidates.json").read_text(encoding="utf-8"))
    except FileNotFoundError:
        log("REFUSED: %s has no candidates.json (run discover first)" % od)
        return 3
    why = []
    if cand["overrides"]:
        why.append("the run changed declared settings %s (freeze needs a run with the declaration as written)" %
                   cand["overrides"])
    if cand["decl_fingerprint"] != decl["_fingerprint"]:
        why.append("the declaration changed since the run")
    if cand["code"] != XC.code_hashes():
        why.append("the code changed since the run")
    if cand["ranks"] != [1, 2, 3]:
        why.append("ranks %s is the separate experiment; only the top-3 universe is frozen" % cand["ranks"])
    if XC.sha16_file(od / "models.pkl") != cand["models_sha16"]:
        why.append("models.pkl does not match the run")
    if list(out.glob("eval_*")):
        why.append("a sealed evaluation already exists")
    if fz.exists() and not a.replace:
        why.append("FROZEN.json exists (--replace overwrites it while no evaluation has run)")
    if why:
        for w in why:
            log("REFUSED: " + w)
        return 3
    if not any(cand["candidates"].values()):
        log("Nothing to freeze: no engine has a candidate under the declared rule. That is the result.")
        XC.ledger_append(out, {"cmd": "freeze", "run": a.run, "result": "no candidate"})
        return 0
    fr = {"version": XC.VERSION, "frozen": time.strftime("%Y-%m-%d %H:%M:%S"), "run": a.run,
          "decl_fingerprint": decl["_fingerprint"], "code": XC.code_hashes(), "versions": cand["versions"],
          "models": str(od / "models.pkl"), "models_sha16": cand["models_sha16"], "candidates": cand["candidates"],
          "acceptance": decl["acceptance"], "sealed_from": decl["data"]["sealed_from"],
          "sealed_to": decl["data"]["sealed_to"]}
    fz.write_text(json.dumps(fr, indent=1), encoding="utf-8")
    XC.ledger_append(out, {"cmd": "freeze", "run": a.run, "frozen": fr["frozen"], "candidates": fr["candidates"],
                           "models_sha16": fr["models_sha16"]})
    log("FROZEN: %s" % fz)
    for e, c in fr["candidates"].items():
        log("   %s: %s" % (e, ", ".join(c) or "none"))
    return 0


def cmd_evaluate(a, loader, log):
    out = XC.guard_out(a.out, a.root)
    decl = XC.load_decl(a.decl)
    fz = out / "FROZEN.json"
    if not fz.exists():
        log("REFUSED: no FROZEN.json in %s (discover, then freeze)" % out)
        return 3
    fr = json.loads(fz.read_text(encoding="utf-8"))
    why = []
    if fr["decl_fingerprint"] != decl["_fingerprint"]:
        why.append("the declaration changed after the freeze")
    if fr["code"] != XC.code_hashes():
        why.append("the code changed after the freeze")
    if not Path(fr["models"]).exists():
        why.append("the frozen models file %s is missing (the discovery folder was moved or deleted)" % fr["models"])
    elif XC.sha16_file(fr["models"]) != fr["models_sha16"]:
        why.append("the frozen models file changed")
    if versions().get("sklearn") != fr["versions"].get("sklearn") and decl["learning"]["model"] == "hgb":
        why.append("scikit-learn is %s, the models were fitted with %s" % (versions().get("sklearn"),
                                                                          fr["versions"].get("sklearn")))
    if list(out.glob("eval_*")):
        why.append("the sealed evaluation already ran (one shot): %s" % [p.name for p in out.glob("eval_*")])
    if why:
        for w in why:
            log("REFUSED: " + w)
        return 3
    a.pm_run = a.pm_run or decl["data"]["pm_run"]
    blob = pickle.loads(Path(fr["models"]).read_bytes())
    models = blob["models"]
    t_from, t_to = fr["sealed_from"], fr["sealed_to"]
    tag = "eval_%s" % XC.sha16_obj({"frozen": fr, "root": str(a.root)})
    od = out / tag
    od.mkdir(parents=True, exist_ok=False)
    XC.ledger_append(out, {"cmd": "evaluate", "run": tag, "start": time.strftime("%Y-%m-%d %H:%M:%S"),
                           "frozen": fr["frozen"], "candidates": fr["candidates"]})
    t0 = time.time()
    a.ranks = [1, 2, 3]
    D = loader(a, decl, t_from, t_to, t_to, log)
    B = S.Bars(D, sorted({s.symbol for s in D.registry.active()}), int(decl["window"]["lock_wait"]))
    fs = F.FeatureStore(D, B.syms)
    engines_out = {}
    for eng in a.engines:
        engines_out[eng] = engine_evaluate(D, decl, eng, [1, 2, 3], t_from, t_to, B, fs,
                                           fr["candidates"].get(eng, []), models.get(eng, {}), log)
    run = {"version": XC.VERSION, "decl_fingerprint": decl["_fingerprint"], "when": time.strftime("%Y-%m-%d %H:%M"),
           "t_from": t_from, "t_to": t_to, "data_to": str(D.cal.days[-1]), "ranks": [1, 2, 3], "engines": a.engines,
           "overrides": {}, "code": XC.code_hashes(), "versions": versions(), "data": D.info, "frozen": fr,
           "seconds": round(time.time() - t0, 1)}
    write_outputs(od, run, engines_out, decl, sealed=True)
    verdict = {e: E.get("acceptance", {}) for e, E in engines_out.items()}
    XC.ledger_append(out, {"cmd": "evaluate", "run": tag, "done": time.strftime("%Y-%m-%d %H:%M:%S"),
                           "verdict": {e: {k: v["ACCEPTED"] for k, v in d.items()} for e, d in verdict.items()}})
    log("done: %s" % (od / "REPORT.md"))
    for e, d in verdict.items():
        for k, v in d.items():
            log("   %s %s: %s" % (e, k, "ACCEPTED" if v["ACCEPTED"] else "rejected (%s)" % ", ".join(
                x for x in ("A1", "A2", "A3", "A4") if not v[x])))
    return 0


def cmd_status(a, log):
    out = Path(a.out)
    log("execlab %s, output folder %s" % (XC.VERSION, out))
    for p in sorted(out.glob("disc_*")):
        c = p / "candidates.json"
        cc = json.loads(c.read_text(encoding="utf-8"))["candidates"] if c.exists() else "unfinished"
        log("   %s: candidates %s" % (p.name, cc))
    fz = out / "FROZEN.json"
    log("   FROZEN.json: %s" % (json.loads(fz.read_text(encoding="utf-8"))["frozen"] if fz.exists() else "none"))
    for p in sorted(out.glob("eval_*")):
        log("   %s (sealed evaluation)" % p.name)
    return 0


def main(argv=None, loader=None, log=print):
    ap = argparse.ArgumentParser(prog="execlab", description=XC.VERSION)
    ap.add_argument("--selftest", nargs="?", const="full", default=None)
    sub = ap.add_subparsers(dest="cmd")
    for nm in ("discover", "freeze", "evaluate", "status"):
        p = sub.add_parser(nm)
        p.add_argument("--out", required=False, default=os.environ.get("XL_OUT"))
        p.add_argument("--decl", default=None)
        if nm in ("discover", "evaluate"):
            p.add_argument("--root", default=None)
            p.add_argument("--pm-run", default=None, help="default: the declaration's data.pm_run")
            p.add_argument("--engines", default="D,ENS")
            p.add_argument("--stage-e-any", action="store_true")
            p.add_argument("--tradelab-any", action="store_true")
            p.add_argument("--costs", default="stage_e", choices=("stage_e", "replica"))
            p.add_argument("--max-symbols", type=int, default=None)
        if nm == "discover":
            p.add_argument("--ranks", default="1-3")
            p.add_argument("--from", dest="d_from", default=None)
            p.add_argument("--to", dest="d_to", default=None)
            p.add_argument("--quick", action="store_true")
            p.add_argument("--variants", default=None)
            p.add_argument("--hurdles", default=None)
            p.add_argument("--model", default=None, choices=("hgb", "ridge"))
            p.add_argument("--folds", type=int, default=None)
            p.add_argument("--again", action="store_true")
        if nm == "freeze":
            p.add_argument("--run", required=True)
            p.add_argument("--replace", action="store_true")
    a = ap.parse_args(argv)
    if a.selftest:
        sys.path.insert(0, str(HERE / "tests"))
        import test_execlab
        return test_execlab.main(["quick"] if a.selftest == "quick" else [])
    if not a.cmd:
        ap.print_help()
        return 2
    if not a.out:
        log("ERROR: --out is required (or set XL_OUT); there is no default output folder")
        return 2
    try:
        if a.cmd in ("discover", "evaluate"):
            if loader is None and not a.root:
                log("ERROR: --root is required (no silent default cache path)")
                return 2
            a.engines = [e for e in a.engines.split(",") if e]
            if a.cmd == "discover":
                a.ranks = parse_ranks(a.ranks)
            fn = cmd_discover if a.cmd == "discover" else cmd_evaluate
            return fn(a, loader or real_loader, log)
        if a.cmd == "freeze":
            return cmd_freeze(a, log)
        return cmd_status(a, log)
    except XC.XLError as e:
        log("ERROR: %s" % e)
        return 3


if __name__ == "__main__":
    sys.exit(main())
