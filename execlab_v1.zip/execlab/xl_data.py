r"""xl_data.py - execlab: the data, read through v2engine 0.3's adapter (READ ONLY), plus India VIX and 3-minute bars.

  load_real   v2_data.load_real: NIFTY's calendar cut at the seal (nothing after it is loaded), stage E's bars with
              lock flags, Wilder ATR, ADV and vol20, tl_state contexts, tl_context regimes, NIFTY / Midcap / Smallcap
              closes, pick_meta's selections (ETFs out, recorded outcomes never read), stage E's own cost functions.
              Added here: India VIX on the calendar (tradelab's Market, the symbol tl_context uses) and a lazy
              reader of the 3-minute bars (tradelab's IntradayStore path, pathlab's read_dense: 125 bars a session,
              tradelab's usable-session test), cut at the same seal.
Nothing here writes anywhere (v2_data may keep its breadth copy under V2_OUT\context, as it always does).
"""
from pathlib import Path

import numpy as np

from xl_common import XLError


def _closes(dn, days):
    out = {}
    for d in days:
        q = dn.pos.get(np.datetime64(d, "D").item()) if dn is not None else None
        out[d] = dn.C[q].copy() if q is not None and dn.usable[q] else None
    return out


class Intraday:
    """closes(sym, days) -> {day: the session's 125 3-minute closes, or None when the session is not usable}. A
    stock's file is read once per request and dropped (only the asked sessions are kept); sessions after the seal are
    never read."""

    def __init__(self, market, d_to, log=print):
        self.market, self.d_to, self.log = market, d_to, log
        self.kept, self.store, self.missing = {}, None, 0
        try:
            self.store = market.intraday()
        except Exception as e:          # noqa: BLE001 - no 3-minute folder: the intraday layer reports it, nothing else stops
            log("   3-minute bars: not available (%s)" % e)

    def _dense(self, sym):
        if self.store is None:
            return None
        import pl_intraday as PI
        p = self.store.path(sym)
        if not Path(p).exists():
            return None
        self.market.load([sym])
        ds = self.market.series(sym)
        return None if ds is None else PI.read_dense(Path(p), ds.dates, ds.o, ds.h, ds.l, None, self.d_to)

    def closes(self, sym, days):
        want = [d for d in days if (sym, d) not in self.kept]
        if want:
            dn = self._dense(sym)
            self.missing += dn is None
            for d, v in _closes(dn, want).items():
                self.kept[(sym, d)] = v
        return {d: self.kept[(sym, d)] for d in days}


class DictIntraday:
    """Synthetic worlds: a dict symbol -> Dense (the same closes() as Intraday)."""

    def __init__(self, d):
        self.d = d
        self.missing = 0

    def closes(self, sym, days):
        return _closes(self.d.get(sym), days)


def on_calendar(cal_days, dates, values):
    days = np.asarray(cal_days).astype("datetime64[D]")
    out = np.full(len(days), np.nan)
    d = np.asarray(dates).astype("datetime64[D]")
    j = np.searchsorted(d, days)
    ok = j < len(d)
    ok[ok] = d[j[ok]] == days[ok]
    out[ok] = np.asarray(values, dtype=float)[j[ok]]
    return out


def load_real(root, pm_run, engines, ranks, t_first, t_last, seal_end, log=print, stage_e_any=False,
              tradelab_any=False, costs="stage_e", max_symbols=None, warmup=320):
    if not root or not Path(root).is_dir():
        raise XLError("--root %r is not a folder (no silent default cache path)" % (root,))
    import v2_data as VD
    D = VD.load_real(root, pm_run, tuple(engines), tuple(range(1, max(ranks) + 1)), t_first, t_last,
                     seal_end=seal_end, warmup_sessions=warmup, stage_e_any=stage_e_any, tradelab_any=tradelab_any,
                     log=log, max_symbols=max_symbols, with_home=True, costs=costs)
    TC, TD, TS, TX = VD.tradelab_modules(tradelab_any)
    market = TD.Market(Path(root), TD.Production(stage_e_any))
    D.vix = None
    vsym = TX.SPEC.get("vix", ("INDIAVIX",))[0]
    try:
        market.load([vsym])
        ds = market.series(vsym)
        if ds is not None and len(ds):
            D.vix = on_calendar(D.cal.days, ds.dates, ds.c)
    except Exception as e:              # noqa: BLE001
        log("   India VIX: not read (%s)" % e)
    log("   India VIX: %s" % ("%d sessions" % int(np.isfinite(D.vix).sum()) if D.vix is not None else "absent"))
    d_to = np.datetime64(D.cal.days[-1], "D")
    D.intraday = Intraday(market, d_to, log)
    D.info["execlab_data"] = {"vix": D.vix is not None, "intraday_to": str(d_to)}
    return D
