@echo off
rem env_execlab.bat - execlab v1.0: start an execlab session in cmd.
rem   call C:\Users\karanvsi\PyCharmMiscProject\execlab\env_execlab.bat
rem Runs v2engine's env_v2.bat (bigmove_deploy's env_daily.bat: CACHE_DAILY_ROOT; PYTHONPATH to v2engine, pathlab,
rem tradelab, open_close; V2_OUT), then puts execlab first on PYTHONPATH. Reads production READ ONLY.
rem Writes only under XL_OUT. Edit the paths below if your folders differ.
set "V2_ENV=C:\Users\karanvsi\PyCharmMiscProject\v2engine\env_v2.bat"
set "XL_DIR=C:\Users\karanvsi\PyCharmMiscProject\execlab"
set "XL_OUT=C:\QuantData\execlab"
if not exist "%V2_ENV%" goto :no_v2
if not exist "%XL_DIR%\execlab.py" goto :no_xl
set "PYTHONPATH="
call "%V2_ENV%"
if "%PYTHONPATH%"=="" goto :v2_failed
if "%CACHE_DAILY_ROOT%"=="" goto :no_root
set "PYTHONPATH=%XL_DIR%;%PYTHONPATH%"
python -c "import sklearn" 2>nul
if errorlevel 1 goto :no_sklearn
if not exist "%XL_OUT%" mkdir "%XL_OUT%"
cd /d "%XL_DIR%"
echo execlab ready: CACHE_DAILY_ROOT=%CACHE_DAILY_ROOT%   XL_OUT=%XL_OUT%
goto :eof
:no_v2
echo ERROR: %V2_ENV% not found - edit V2_ENV at the top of env_execlab.bat
exit /b 1
:no_xl
echo ERROR: execlab.py not found in %XL_DIR% - edit XL_DIR at the top of env_execlab.bat
exit /b 1
:v2_failed
echo ERROR: env_v2.bat stopped (its message is above) - execlab needs v2engine 0.3, tradelab and pathlab
exit /b 1
:no_root
echo ERROR: env_v2.bat ran but CACHE_DAILY_ROOT is empty
exit /b 1
:no_sklearn
echo ERROR: scikit-learn is missing in this Python - run: python -m pip install scikit-learn
exit /b 1
