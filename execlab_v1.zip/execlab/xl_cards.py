r"""xl_cards.py - execlab: setup and exit cards = the learned policy read back as a few rules.

A shallow decision tree (declared depth 3, leaves of at least 3% of the rows) is fitted to the POLICY'S OWN
choices (not to outcomes), on the rows where the policy decided. Each leaf is a card: the rule path, rows, records,
the actions the policy took there, and for setup cards what those records made against their own OPEN6 trade
(unfilled = 0, 95% block bootstrap over signal days). A card describes the policy; the evidence is the value column.
"""
import numpy as np

from xl_common import block_mean


def _paths(tree, names):
    t = tree.tree_
    out = {}

    def walk(node, conds):
        if t.children_left[node] == -1:
            out[node] = " AND ".join(conds) if conds else "(all rows)"
            return
        f, thr = names[t.feature[node]], t.threshold[node]
        walk(t.children_left[node], conds + ["%s <= %.4g" % (f, thr)])
        walk(t.children_right[node], conds + ["%s > %.4g" % (f, thr)])

    walk(0, [])
    return out


def _tree(X, y, decl, seed=7):
    from sklearn.tree import DecisionTreeClassifier
    c = decl["cards"]
    Xf = np.where(np.isfinite(X), X, -999.0)
    leaf = max(20, int(float(c["min_leaf_share"]) * len(y)))
    dt = DecisionTreeClassifier(max_depth=int(c["depth"]), min_samples_leaf=leaf, random_state=seed)
    dt.fit(Xf, y)
    return dt, dt.apply(Xf)


def setup_cards(world, X, cols, A, res, op6, actions, decl):
    """Rows the policy decided on: every watch row up to (and including) the record's deciding close."""
    W = world.W
    nr = world.n_rec
    d = np.tile(np.arange(W), nr)
    r = np.repeat(np.arange(nr), W)
    last = np.where(res["decision_d"] >= 0, res["decision_d"], W - 1)
    use = d <= last[r]
    if use.sum() < 100:
        return []
    try:
        dt, leaf = _tree(X[use], A[use], decl)
    except ImportError:
        return []
    paths = _paths(dt, cols)
    ru = r[use]
    decisive = d[use] == last[ru]
    gain = res["net0"] - np.nan_to_num(op6["open6"])
    cards = []
    for lf in np.unique(leaf):
        m = leaf == lf
        acts = A[use][m]
        recs = np.unique(ru[m & decisive])
        top = np.bincount(acts, minlength=len(actions))
        shares = top / max(1, top.sum())
        order = np.argsort(-shares)[:3]
        st = block_mean(world.recs["t"][recs], gain[recs], B=int(decl["stats"]["B"]), block=int(decl["stats"]["block"]),
                        seed=int(decl["stats"]["seed"])) if len(recs) else {"mean": np.nan}
        cards.append({"rule": paths[lf], "rows": int(m.sum()), "records_decided": int(len(recs)),
                      "actions": ", ".join("%s %.0f%%" % (actions[k], 100 * shares[k]) for k in order if shares[k] > 0),
                      "main": actions[int(order[0])], "vs_open6": st})
    cards.sort(key=lambda c: -c["rows"])
    return cards


def exit_cards(X, cols, acts, actions, decl):
    if len(acts) < 100:
        return []
    try:
        dt, leaf = _tree(X, acts, decl)
    except ImportError:
        return []
    paths = _paths(dt, cols)
    cards = []
    for lf in np.unique(leaf):
        m = leaf == lf
        top = np.bincount(acts[m], minlength=len(actions))
        shares = top / max(1, top.sum())
        order = np.argsort(-shares)[:3]
        cards.append({"rule": paths[lf], "rows": int(m.sum()),
                      "actions": ", ".join("%s %.0f%%" % (actions[k], 100 * shares[k]) for k in order if shares[k] > 0),
                      "main": actions[int(order[0])]})
    cards.sort(key=lambda c: -c["rows"])
    return cards
