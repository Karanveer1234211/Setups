r"""xl_report.py - execlab: REPORT.md and the CSV files of a discovery or a sealed evaluation."""
import csv
import json
from pathlib import Path

import numpy as np

import xl_sim as S
from xl_common import fmt_bp, fmt_ci, fmt_pct

LEDGER_COLS = ("engine", "config", "sid", "T", "symbol", "rank", "score", "status", "decision_close", "lag", "order",
               "entry_date", "fill", "exit_date", "exit_raw", "exit_reason", "held", "net", "net0", "mfe", "mae",
               "open6", "plan", "major", "bad")


def _f(x, nd=6):
    if x is None:
        return ""
    if isinstance(x, (float, np.floating)):
        return "" if not np.isfinite(x) else ("%.*f" % (nd, x))
    return str(x)


def write_csv(path, header, rows):
    with Path(path).open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        for r in rows:
            w.writerow([_f(r.get(h)) for h in header] if isinstance(r, dict) else [_f(v) for v in r])


def ledger_rows(world, eng, cfg, out, op6, decl):
    days = world.D.cal.days
    big, bad = float(decl["majors"]["plan_net_above"]), float(decl["bad"]["plan_net_below"])
    R = world.recs
    rows = []
    for q in range(world.n_rec):
        tr = out["status"][q] == "TRADED"
        dd = int(out["decision_d"][q])
        e, x = int(out["e"][q]), int(out["x"][q])
        pl = op6["plan"][q]
        rows.append({"engine": eng, "config": cfg, "sid": R["sid"][q], "T": R["T"][q], "symbol": R["sym"][q],
                     "rank": int(R["rank"][q]), "score": float(R["score"][q]), "status": out["status"][q],
                     "decision_close": str(days[int(R["t"][q]) + dd]) if dd >= 0 else "",
                     "lag": e - int(R["t"][q]) if tr else "", "order": S.ENTRY[int(out["kind"][q])] if tr else "",
                     "entry_date": str(days[e]) if tr else "", "fill": float(out["P"][q]),
                     "exit_date": str(days[x]) if tr and x >= 0 else "", "exit_raw": float(out["px"][q]),
                     "exit_reason": S.REASONS[int(out["reason"][q])] if tr else "", "held": x - e if tr else "",
                     "net": float(out["net"][q]), "net0": float(out["net0"][q]), "mfe": float(out["mfe"][q]),
                     "mae": float(out["mae"][q]), "open6": float(op6["open6"][q]), "plan": float(pl),
                     "major": int(np.isfinite(pl) and pl > big), "bad": int(np.isfinite(pl) and pl < bad)})
    for s in world.out_of_period:
        rows.append({"engine": eng, "config": cfg, "sid": s.sid, "T": s.T, "symbol": s.symbol, "rank": s.rank,
                     "score": s.raw_score, "status": "OUT_OF_PERIOD"})
    return rows


def _row(L, cells):
    L.append("| " + " | ".join(cells) + " |")


def research_table(L, items):
    _row(L, ["book", "net / selection (unfilled 0)", "vs OPEN6", "vs PLAN", "traded", "win", "median held",
             "majors captured", "majors missed", "bad avoided", "false triggers"])
    _row(L, ["---"] * 11)
    for name, m in items:
        _row(L, [name, fmt_ci(m["net"]), fmt_ci(m["vs_open6"]), fmt_ci(m["vs_plan"]), str(m["trades"]["n"]),
                 fmt_pct(m["trades"]["win"], 1).lstrip("+"), "%.0f" % m["trades"]["median_held"]
                 if np.isfinite(m["trades"]["median_held"]) else "-",
                 "%s of %d" % (fmt_pct(m["majors"]["capture_share"], 1).lstrip("+"), m["majors"]["n"]),
                 str(m["majors"]["missed"]), "%d of %d" % (m["bad"]["avoided"], m["bad"]["n"]),
                 "%d (%s)" % (m["false_triggers"]["n"], fmt_pct(m["false_triggers"]["share"], 1).lstrip("+"))])


def portfolio_table(L, items, rw=None):
    _row(L, ["book", "CAGR", "worst DD", "Sharpe", "CAGR at -25% DD", "trades", "daily excess vs OPEN_SB",
             "Romano-Wolf p"])
    _row(L, ["---"] * 8)
    for name, p in items:
        ex = p.get("excess")
        _row(L, [name, fmt_pct(p["cagr"], 1), fmt_pct(p["max_dd"], 1), "%.2f" % p["sharpe"] if p["sharpe"] is not None
                 and np.isfinite(p["sharpe"]) else "-", fmt_pct(p["at_dd"]["cagr"], 1) + " (x%.2f)" % p["at_dd"]["f"]
                 if np.isfinite(p["at_dd"]["f"]) else "-", str(p["trades"]),
                 fmt_ci(ex, unit="bp") if ex else "-",
                 "%.3f" % rw[name]["p_adj"] if rw and name in rw and np.isfinite(rw[name]["p_adj"]) else "-"])


def report(path, title, run, engines_out, decl, sealed=False):
    L = ["# %s" % title, "",
         "%s | declaration %s | %s" % (run["version"], run["decl_fingerprint"], run["when"]),
         "Period (signal days): %s .. %s | data loaded up to %s%s | ranks %s | engines %s" % (
             run["t_from"], run["t_to"], run["data_to"], " (SEALED period)" if sealed else " (2023-25 not loaded)",
             run["ranks"], ", ".join(run["engines"])),
         "Settings changed from the declaration: %s" % (json.dumps(run["overrides"]) if run["overrides"] else "none"),
         "", "Net = stage E's zerodha_base, fully net. Intervals: 95%% block bootstrap (%d draws, %d-session blocks). "
             "Evaluation of every record in discovery uses models that never saw it (purged cross-fitting)." % (
                 decl["stats"]["B"], decl["stats"]["block"]), ""]
    for eng, E in engines_out.items():
        L += ["## Engine %s" % eng, ""]
        if E.get("skipped"):
            L += [E["skipped"], ""]
            continue
        L += ["%d selections, %d with a path ending inside the period, %d listed as OUT_OF_PERIOD." % (
            E["n_all"], E["n_rec"], E["n_oop"]), ""]
        L += ["### Research ledger (every selection on its own, no budgets)", ""]
        items = [("OPEN6 (every selection)", E["base_research"])] if E.get("base_research") else []
        research_table(L, items + [(k, v["research"]) for k, v in E["configs"].items()])
        L += ["", "### Execution ledger (Rs 10 lakh, 1/8 of equity, <= %d entries a day, <= %d in 5 sessions, <= %d "
              "open, one per stock)" % (decl["portfolio"]["max_entries_day"], decl["portfolio"]["max_entries_5"],
                                        decl["portfolio"]["max_open"]), ""]
        portfolio_table(L, [("OPEN_SB", E["open_sb"]), ("PLAN_native", E["plan_native"])] +
                        [(k, v["portfolio"]) for k, v in E["configs"].items()], E.get("rw"))
        if "pbo" in E:
            L += ["", "Probability of backtest overfitting (CSCV, %d configurations): %s" % (
                E["pbo"].get("configs", 0), "%.2f" % E["pbo"]["pbo"] if np.isfinite(E["pbo"].get("pbo", np.nan))
                else "-")]
        if "candidates" in E:
            L += ["", "**Candidates (declared rule: %s): %s**" % (decl["candidates"]["rule"],
                                                                 ", ".join(E["candidates"]) or "none")]
        if "acceptance" in E:
            L += ["", "### Acceptance (sealed)", ""]
            _row(L, ["candidate", "A1 excess > 0", "A2 CAGR at -25% DD", "A3 majors >= 70%", "A4 >= 2 of 3 years",
                     "verdict", "yearly excess (bp / day)"])
            _row(L, ["---"] * 7)
            for k, a in E["acceptance"].items():
                _row(L, [k] + ["yes" if a[x] else "no" for x in ("A1", "A2", "A3", "A4")] +
                     ["ACCEPTED" if a["ACCEPTED"] else "rejected",
                      ", ".join("%d %s" % (y, fmt_bp(v)) for y, v in a["years"].items())])
        best = E.get("best")
        if best:
            c = E["configs"][best]
            m = c["research"]
            L += ["", "### %s in detail" % best, "",
                  "Orders traded: %s. Exits: %s. Mean MFE %s, MAE %s." % (
                      ", ".join("%s %d" % kv for kv in m["trades"]["kinds"].items()),
                      ", ".join("%s %d" % kv for kv in m["trades"]["exits"].items()),
                      fmt_pct(m["trades"]["mfe"], 1), fmt_pct(m["trades"]["mae"], 1)),
                  "Majors: %d (PLAN profit %s), %d traded, profit captured %s; bad trades avoided %d of %d (loss "
                  "avoided %s of PLAN net); opportunity cost: OPEN6 net of the %d records not traded = %s per "
                  "selection." % (m["majors"]["n"], fmt_pct(m["majors"]["plan_profit"], 1), m["majors"]["traded"],
                                  fmt_pct(m["majors"]["capture_share"], 1), m["bad"]["avoided"], m["bad"]["n"],
                                  fmt_pct(m["bad"]["loss_avoided"], 1), m["opportunity_cost"]["records"],
                                  fmt_pct(m["opportunity_cost"]["per_selection"], 3)), ""]
            if c.get("cohorts"):
                L += ["Entry lag cohorts:", ""]
                _row(L, ["lag", "trades", "mean net", "median held", "win"])
                _row(L, ["---"] * 5)
                for x in c["cohorts"]:
                    if x["n"]:
                        _row(L, ["T+%d" % x["lag"], str(x["n"]), fmt_pct(x["mean"]), "%.0f" % x["held"],
                                 fmt_pct(x["win"], 0).lstrip("+")])
                L += ["", "Abandons by close: " + ", ".join("%s %d" % (a["close"], a["n"]) for a in c["abandons"]), ""]
            if c.get("groups"):
                L += ["Context groups (state group | event group | market), selection net minus OPEN6, BH q <= %.2f "
                      "flagged:" % decl["stats"]["fdr_q"], ""]
                _row(L, ["group", "selections", "traded", "vs OPEN6", "q", "flag"])
                _row(L, ["---"] * 6)
                for g in c["groups"]:
                    _row(L, [g["group"], str(g["n"]), str(g["traded"]), fmt_ci(g["diff"]),
                             "%.3f" % g["q"] if np.isfinite(g["q"]) else "-", "*" if g["flag"] else ""])
                L.append("")
            if c.get("setup_cards"):
                L += ["Setup cards (the policy's own choices as rules; value = those records vs their OPEN6):", ""]
                _row(L, ["#", "rule", "rows", "decided", "policy did", "vs OPEN6"])
                _row(L, ["---"] * 6)
                for k, cd in enumerate(c["setup_cards"], 1):
                    _row(L, [str(k), cd["rule"], str(cd["rows"]), str(cd["records_decided"]), cd["actions"],
                             fmt_ci(cd["vs_open6"])])
                L.append("")
            if c.get("exit_cards"):
                L += ["Exit cards (hold decisions of the traded positions):", ""]
                _row(L, ["#", "rule", "rows", "policy did"])
                _row(L, ["---"] * 4)
                for k, cd in enumerate(c["exit_cards"], 1):
                    _row(L, [str(k), cd["rule"], str(cd["rows"]), cd["actions"]])
                L.append("")
            it = c.get("intraday")
            if it:
                L += ["Intraday (exploratory, 3-minute bars, %d open entries with usable bars):" % it["sessions"], ""]
                if it.get("note"):
                    L.append(it["note"])
                for nm, v in it.get("checkpoints", {}).items():
                    L.append("- %s: %d trades; every one there instead of the open %s; chosen before the open "
                             "(%d picked, the rest at the open) %s" % (nm, v["n"], fmt_ci(v["always"]), v["picked"],
                                                                       fmt_ci(v["chosen"])))
                L.append("")
        if E.get("learning"):
            L += ["Learning (value at the start by policy-iteration step):", ""]
            for k, v in E["learning"].items():
                L.append("- %s: %s" % (k, " -> ".join("%+.4f" % x for x in v)))
            L.append("")
    L += ["## Files", "", "ledger_research.csv (every selection x configuration, OUT_OF_PERIOD included), "
          "ledger_execution.csv, configs.csv, daily_returns.csv, context_groups.csv, cards_setup.csv, cards_exit.csv, "
          "RUN.json%s." % ("" if sealed else ", candidates.json, models.pkl"), ""]
    Path(path).write_text("\n".join(L) + "\n", encoding="utf-8")
