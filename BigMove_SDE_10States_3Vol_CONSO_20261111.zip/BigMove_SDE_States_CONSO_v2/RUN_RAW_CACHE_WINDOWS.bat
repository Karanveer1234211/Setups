@echo off
setlocal
REM Verify DAILY_DIR contains *_daily.parquet; frozen files untouched.
set "DAILY_DIR=C:\QuantData\cache_daily"
set "FEATURE_CODE=C:\Users\karanvis\PyCharmProjects\bigmove_deploy\features_daily.py"
set "BASE=C:\QuantData\research_sde_states_conso"
for /f %%a in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "STAMP=%%a"
set "OUT=%BASE%\RAW_%STAMP%"
echo [START] Raw cache full universe. No source files will be changed.
echo [OUTPUT] %OUT%
python "%~dp0sde_states_conso.py" --daily-dir "%DAILY_DIR%" --features-code "%FEATURE_CODE%" --frozen-json "%~dp0FROZEN_SETUPS.json" --from 2021-01-01 --through 2026-09-22 --out "%OUT%" --min-events 100
if errorlevel 1 (
 echo [ERROR] Research stopped. Verify paths. Production/frozen files unchanged.
 pause
 exit /b 1
)
echo [COMPLETE] CONSO report: %OUT%\CONSO_REPORT.html
start "" "%OUT%\CONSO_REPORT.html"
pause
endlocal
