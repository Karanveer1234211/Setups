# BigMove: FULL UNIVERSE × 10 Stock States × 3 Volatility States × SDE × Exact Frozen Setups

**Research package, v2. Date: 2026-11-11.** No BigMove rank filter. No edits to production or frozen files.

## Start here

Double-click `RUN_PANEL_WINDOWS.bat` on your Windows PC. It reads:

`C:\QuantData\cache_daily\panel\panel.parquet`

and writes to a **new timestamped** folder under:

`C:\QuantData\research_sde_states_conso\`

After the run, open **`CONSO_REPORT.html`**. It is the **one single, self-contained, searchable consolidated report** containing all available cases; it opens directly in Edge/Chrome without internet. A text counterpart `CONSO_REPORT.md` and audit CSVs are generated too.

Or, for the broadest available *raw daily cache* universe, use `RUN_RAW_CACHE_WINDOWS.bat`. Edit `DAILY_DIR` in the batch file if raw `*_daily.parquet` files aren't directly inside `C:\QuantData\cache_daily`.

### One-time install

Open PowerShell in the extracted package folder and run:

```powershell
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
```

### Manual panel command

```powershell
python sde_states_conso.py --panel "C:\QuantData\cache_daily\panel\panel.parquet" --from 2021-01-01 --through 2026-09-22 --min-events 100 --out "C:\QuantData\research_sde_states_conso\RUN_001"
```

### Quick five-symbol smoke test first

```powershell
python sde_states_conso.py --panel "C:\QuantData\cache_daily\panel\panel.parquet" --limit-symbols 5 --out "C:\QuantData\research_sde_states_conso\SMOKE_001"
```

Each output directory must not already exist: the program deliberately refuses overwrites. The freeze JSON must hash-validate. The required nine features must be present, and symbol/date bars must not be duplicated.

## SDE specification

`SDE10[t] = (Close[t] - Close[t-10]) / SUM_j=1..10(abs(Close[t-j+1] - Close[t-j]))`

- Extreme negative: **SDE < -0.5**
- Middle: **-0.5 <= SDE <= +0.5**
- Extreme positive: **SDE > +0.5**

Both `sde_d0` and `sde_signal` are output. **Use `sde_signal`** (last completed close before setup-entry open) to compare distinct entry events. It is free from differing arbitrary historical D0 windows that lead to the same entry. S2 also requires the *actual opening gap* for entry confirmation; no future information is used for that condition.

## Ten EXCLUSIVE structural stock states

These ten are a pre-declared **5×2 matrix** and do **not** use SDE for classification:

| State | Slow structural condition | Fast positioning |
|---|---|---|
| S01 BULL ADVANCING | SMA50 > 1.02 × SMA200; SMA200 rising vs 20 sessions ago | Close >= EMA20 |
| S02 BULL PULLBACK | Same structural bull | Close < EMA20 |
| S03 BULL WEAKENING UP | SMA50 > 1.02 × SMA200; SMA200 not rising | Close >= EMA20 |
| S04 BULL WEAKENING DOWN | Same weakening bull | Close < EMA20 |
| S05 BALANCED UP LEG | 0.98 <= SMA50/SMA200 <= 1.02 | Close >= EMA20 |
| S06 BALANCED DOWN LEG | Same balanced regime | Close < EMA20 |
| S07 BEAR STABILIZING UP | SMA50 < 0.98 × SMA200; SMA200 not falling | Close >= EMA20 |
| S08 BEAR STABILIZING DOWN | Same stabilizing bear | Close < EMA20 |
| S09 BEAR RALLY | SMA50 < 0.98 × SMA200; SMA200 falling | Close >= EMA20 |
| S10 BEAR CONTINUATION | Same falling bear | Close < EMA20 |

SMA200's current value and 20-session-ago value require at least **220 observed stock sessions**. Until then state = `UNCLASSIFIED`, tracked separately. The ±2% band is a **research definition**, not a fitted optimum.

## Three additional ORTHOGONAL volatility states

The runner computes the frozen `setuplab.atr_simple` true range: 14-session **simple** rolling TR average divided by today's close (not Wilder ATR). It then compares current ATR% against quantiles calculated from the **prior** 252 observed stock sessions, requiring at least 60 previous nonmissing ATR observations:

- `V1_QUIET`: ATR% below the historical 33rd percentile.
- `V2_NORMAL`: 33rd percentile <= ATR% <= 67th percentile.
- `V3_EXPANSION`: ATR% above historical 67th percentile.

Where history is insufficient, `V_UNKNOWN` is flagged and excluded from the 10×3 complete-grid comparison. Volatility states are relative **to the stock's own history**, not hardcoded ATR% groups. Absolute ATR% >=3 and >=6 are independently tested in **universe screens**.

## Eleven screening universes: what we compare

All conditions are evaluated at the **signal close before the actual frozen setup entry**, never at the exit.

| Universe | Screening criteria |
|---|---|
| `ALL_CACHED` | Every stock in input panel/raw cache with settled setup |
| `PRICE_GE_50` | Previous close >= ₹50 |
| `LIQUID_5CR` | Previous close >= ₹50 and preceding 20-session average close×volume >= ₹5 crore/day |
| `LIQUID_25CR` | Same but >= ₹25 crore/day |
| `LIQUID_ATR_GE_3` | Liquid_5cr and simple ATR14% >= 3% |
| `LIQUID_ATR_GE_6` | Liquid_5cr and simple ATR14% >= 6% |
| `LIQUID_ATR3_ABOVE_SMA200` | Liquid_5cr + ATR>=3 + close >= SMA200 |
| `LIQUID_ATR3_BELOW_SMA200` | Liquid_5cr + ATR>=3 + close < SMA200 |
| `LIQUID_ATR3_DIP_1ATR` | Liquid_5cr + ATR>=3 + past 10-session return <= -1 ATR |
| `LIQUID_ATR3_NEAR_52W_HIGH` | Liquid_5cr + ATR>=3 + close within 2% of 252-session high |
| `LIQUID_ATR3_AWAY_FROM_HIGH` | Liquid_5cr + ATR>=3 + close more than 2% below 252-session high |

**Note:** These universes **OVERLAP** and must not be summed. The DIP state is deliberately correlated with SDE; treat its conditional results as descriptive, not independent SDE confirmation. Missing liquidity never passes liquidity screens. `D_dollar_vol` from original `features_daily.py` is accepted as `close*volume` when raw volume isn't in the panel; if both are missing, the liquidity feature is missing. The report counts such cases.

## Exactly seven frozen setups remain unchanged

`S1 S2 S3 C1 C2 C3 N1` are called through the original `setuplab.trigger()` from `frozen_setuplab_reference.py`, with canonical `FROZEN_SETUPS.json`. All seven per-setup SHA256 values and aggregate freeze hash are checked by the original `load_frozen()` before running. Nine-decimal comparisons and missing-feature rules are preserved.

- S1's dip uses the **D0 pick's** 14-session simple ATR.
- S2's rising five-day minus-DI difference and gap-down-open rule are unchanged.
- S1–C3 exit at original hypothetical D5 close.
- N1 exits at fresh D5 relative to the *actual entry* (entry+4 sessions).
- Flat **0.35 percentage-point round-trip cost** is deducted once per trade.

Two independent analysis families are run:

1. **`independent_setups`**: each of the seven separately. De-duplicate same stock+setup+entry date.
2. **`first_setup_wins`**: earliest qualifying setup on each hypothetical D0 watch. De-duplicate same stock+entry date. Exact JSON order breaks equal-day ties **for research only**; it is not the frozen capital-constrained Tree priority.

All-hypothetical D0 watches may overlap, but the unique-event summaries avoid counting the same stock-entry many times.

## The ONE consolidated report

**`CONSO_REPORT.html`** (opens offline) contains:

1. Full research contract, all 10 state definitions and 3 volatility definitions
2. Full sample coverage and missing-history/liquidity counts
3. Baseline SDE results for independent and first-wins entries
4. All 11 universe slices and the difference between liquid/illiquid and high/low ATR
5. All 10 states × SDE and all 3 volatility states × SDE, with embedded charts
6. The **complete 11 universe × 7 setups × 10 states × 3 vol regimes × 3 SDE groups** table, including **zero-count cells** (6,930 theoretical cells for each family)
7. Year-by-year cell comparisons
8. Same-entry-date cross-sectional NEG vs MID and NEG vs POS matches; descriptive weekly-block bootstrap uncertainty for matching cells
9. Exploratory top cells only where **both** negative and middle SDE have >=100 independent distinct entry events (adjustable using `--min-events`)
10. Source, runtime and methodology caveats

Supporting individual CSVs include `first_setup_wins_UNIQUE_EVENTS_WITH_STATES.csv`, `independent_setups_UNIQUE_EVENTS_WITH_STATES.csv`, `*_ALL_CASES.csv`, `*_ALL_CASES_BY_YEAR.csv`, `*_DATE_MATCHED.csv` and `*_UNKNOWN_HISTORY_AUDIT.csv`. The **single HTML file is the CONSO**; no need to open 20 CSVs unless auditing individual trades.

`CONSO_REPORT.md` is a text-compatible executive/definitions counterpart. All outputs are created under `--out` only.

## Interpretation guardrails

- These stocks come from your cache, not necessarily a historic point-in-time universe free of survivorship bias.
- Most of the history was used to develop the frozen setups and investigate SDE. The new state partition is a new **exploratory multiple-testing search** on those historical outcomes, not fresh independent OOS validation.
- A 6,930-cell grid contains many empty or tiny groups. Their means are not rules to optimize blindly.
- D0 watches overlap heavily; unique events reduce but do not remove serial dependence. Cluster-based matched uncertainty is descriptive.
- Do not confuse higher mean per event with higher capital-constrained CAGR. There is **no actual three-position portfolio replay**; setup overlap, trade priority, liquidity and market impact still need independent simulations.
- There are **no direct intraday semivariance / order-book measures** without intraday tick or quote data.
- Trade fills at opening auction, lower/upper circuits, market impact and all costs beyond the flat 35bp assumption are not verified.
- Near-52-week highs, sharp selloffs, price and ATR levels were not optimized; do not optimize them on the same historic sample and call it a discovered edge.

**Do not trade or change the frozen Tree based on this study alone.**

## Verification status

Nine automated tests, including four copied exact-freeze parity tests and five state/timing/liquidity tests, passed in the isolated environment. Two synthetic end-to-end CSV runs passed (including a test with volume). Real whole-universe cache is not available in this environment, so **no new 10-state or 3-volatility real-market returns are claimed**. Run on your Windows PC and share `CONSO_REPORT.html` + `RUN.json` for genuine results.
