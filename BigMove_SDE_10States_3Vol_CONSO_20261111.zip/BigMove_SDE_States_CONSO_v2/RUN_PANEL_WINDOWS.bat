@echo off
setlocal
REM BigMove FULL PANEL / READ ONLY / original freeze unchanged.
set "PANEL=C:\QuantData\cache_daily\panel\panel.parquet"
set "BASE=C:\QuantData\research_sde_states_conso"
for /f %%a in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "STAMP=%%a"
set "OUT=%BASE%\PANEL_%STAMP%"
echo [START] All panel symbols x SDE x 10 states x 3 volatility states x frozen setups
echo [OUTPUT] %OUT%
python "%~dp0sde_states_conso.py" --panel "%PANEL%" --frozen-json "%~dp0FROZEN_SETUPS.json" --from 2021-01-01 --through 2026-09-22 --out "%OUT%" --min-events 100
if errorlevel 1 (
 echo [ERROR] Research stopped. No production/frozen files changed.
 pause
 exit /b 1
)
echo [COMPLETE] CONSO report: %OUT%\CONSO_REPORT.html
start "" "%OUT%\CONSO_REPORT.html"
pause
endlocal
