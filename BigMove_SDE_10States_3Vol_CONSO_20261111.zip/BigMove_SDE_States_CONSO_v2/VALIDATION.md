# Verification log — 2026-11-11

- Freeze hash: `483f1539324f3ae5c06756b00b32c189f5eb995f73956a681673f005ce399c8f`
- `frozen_setuplab_reference.py` SHA256: `9979d418aecec6debcd91991f5d4454696af866be8d84fb1fb79d977364e088f`, byte-for-byte matching user's `setuplab.py`.
- `FROZEN_SETUPS.json` bytes SHA256: `bed8fd610cf686af2ddafabfc9e6db43d2a60c9666e1076857da1d539c6da2e8`, matching user's `FROZEN_SETUPS.json.txt`.
- `python -m unittest discover -s tests -v`: **9 tests passed**. Four frozen parity tests, plus five state timing, vol/liq and grid tests.
- Three-stock synthetic historical OHLCV end-to-end run passed and generated self-contained `CONSO_REPORT.html`, `CONSO_REPORT.md`, `RUN.json`, and all audit CSVs.
- Complete cube cardinality checked: **11 universe screens × 7 setups × 10 structural states × 3 volatility states × 3 SDE buckets = 6,930 rows for EACH family**; zero-event cases have `n=0`, not fabricated 0% returns.
- A second synthetic three-stock run with volume populated `LIQUID_5CR` and ATR-filtered slices, and passed the same output construction.
- No actual panel parquet run was possible here. The user must run the Windows launcher on their local historical cache. Synthetic returns are NOT research findings and are NOT included in the deliverable ZIP.
- Input files, frozen logic, user's panel and production Tree are never modified.
