#!/usr/bin/env python3
"""BigMove research-only full-universe SDE x exact frozen setups x 10 states x 3 volatility states.

Read-only. Does not modify / re-freeze production models, Tree or setup rules.
The existing sde_universe_setup_study.scan_symbol calls the original setuplab.trigger verbatim.
This extension adds ONLY point-in-time context, filters, diagnostics and a CONSO report.
"""
from __future__ import annotations
import argparse
import base64
import hashlib
import html
import json
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd

import frozen_setuplab_reference as freeze
import sde_universe_setup_study as original

STATES = [
    'S01_BULL_ADVANCING', 'S02_BULL_PULLBACK',
    'S03_BULL_WEAKENING_UP', 'S04_BULL_WEAKENING_DOWN',
    'S05_BALANCED_UP_LEG', 'S06_BALANCED_DOWN_LEG',
    'S07_BEAR_STABILIZING_UP', 'S08_BEAR_STABILIZING_DOWN',
    'S09_BEAR_RALLY', 'S10_BEAR_CONTINUATION',
]
VOLS = ['V1_QUIET', 'V2_NORMAL', 'V3_EXPANSION']
BUCKETS = ['NEG_LT_-0.5', 'MID', 'POS_GT_+0.5']
UNIVERSES = [
    'ALL_CACHED', 'PRICE_GE_50', 'LIQUID_5CR', 'LIQUID_25CR',
    'LIQUID_ATR_GE_3', 'LIQUID_ATR_GE_6',
    'LIQUID_ATR3_ABOVE_SMA200', 'LIQUID_ATR3_BELOW_SMA200',
    'LIQUID_ATR3_DIP_1ATR', 'LIQUID_ATR3_NEAR_52W_HIGH',
    'LIQUID_ATR3_AWAY_FROM_HIGH',
]
STATE_DEFS = [
    ('S01_BULL_ADVANCING', 'SMA50/SMA200 > 1.02; SMA200 rising over 20 sessions; close >= EMA20'),
    ('S02_BULL_PULLBACK', 'SMA50/SMA200 > 1.02; SMA200 rising over 20 sessions; close < EMA20'),
    ('S03_BULL_WEAKENING_UP', 'SMA50/SMA200 > 1.02; SMA200 flat/falling; close >= EMA20'),
    ('S04_BULL_WEAKENING_DOWN', 'SMA50/SMA200 > 1.02; SMA200 flat/falling; close < EMA20'),
    ('S05_BALANCED_UP_LEG', '0.98 <= SMA50/SMA200 <= 1.02; close >= EMA20'),
    ('S06_BALANCED_DOWN_LEG', '0.98 <= SMA50/SMA200 <= 1.02; close < EMA20'),
    ('S07_BEAR_STABILIZING_UP', 'SMA50/SMA200 < 0.98; SMA200 flat/rising; close >= EMA20'),
    ('S08_BEAR_STABILIZING_DOWN', 'SMA50/SMA200 < 0.98; SMA200 flat/rising; close < EMA20'),
    ('S09_BEAR_RALLY', 'SMA50/SMA200 < 0.98; SMA200 falling over 20 sessions; close >= EMA20'),
    ('S10_BEAR_CONTINUATION', 'SMA50/SMA200 < 0.98; SMA200 falling over 20 sessions; close < EMA20'),
]
VOL_DEFS = [
    ('V1_QUIET', 'Current ATR14% below prior 252-session 33rd percentile'),
    ('V2_NORMAL', 'Current ATR14% between prior 33rd and 67th percentiles'),
    ('V3_EXPANSION', 'Current ATR14% above prior 252-session 67th percentile'),
]
CONTEXT_COLS = ['date', 'state', 'vol_state', 'atr_pct', 'sma50', 'sma200', 'ema20',
                'close_price', 'above200', 'adv20_cr', 'ret10_atr', 'near52w', 'liquidity_source']


def price_context(g: pd.DataFrame) -> pd.DataFrame:
    """Every row uses OHLCV at or BEFORE the row's closing timestamp."""
    c = pd.Series(g.close.to_numpy(float)); h = pd.Series(g.high.to_numpy(float))
    s50 = c.rolling(50, min_periods=50).mean()
    s200 = c.rolling(200, min_periods=200).mean()
    e20 = c.ewm(span=20, adjust=False, min_periods=20).mean()
    s200_old = s200.shift(20)
    ratio = s50 / s200.replace(0, np.nan)
    valid = (s50.notna() & s200.notna() & s200_old.notna() & e20.notna() &
             (c > 0) & np.isfinite(ratio))
    long_rising = s200 > s200_old
    long_falling = s200 < s200_old
    above_ema = c >= e20
    core = np.select(
        [ratio > 1.02, ratio < .98, (ratio >= .98) & (ratio <= 1.02)],
        ['BULL', 'BEAR', 'BALANCED'], default='UNKNOWN')
    state = np.full(len(g), 'UNCLASSIFIED', dtype=object)
    state_map = {
        ('BULL', True, True): STATES[0], ('BULL', True, False): STATES[1],
        ('BULL', False, True): STATES[2], ('BULL', False, False): STATES[3],
        ('BALANCED', True, True): STATES[4], ('BALANCED', True, False): STATES[5],
        ('BEAR', True, True): STATES[6], ('BEAR', True, False): STATES[7],
        ('BEAR', False, True): STATES[8], ('BEAR', False, False): STATES[9],
    }
    for (regime, is_advancing, is_above), label in state_map.items():
        if regime == 'BULL': advancing = long_rising
        elif regime == 'BEAR': advancing = ~long_falling
        else: advancing = pd.Series(np.full(len(g), True))
        if regime == 'BALANCED' and not is_advancing: continue
        mask = valid & (core == regime) & (advancing == is_advancing) & (above_ema == is_above)
        state[mask.to_numpy()] = label

    atr_frac = freeze.atr_simple(g.high.to_numpy(float), g.low.to_numpy(float), c.to_numpy(float))
    atr_pct = pd.Series(100 * atr_frac).replace([np.inf, -np.inf], np.nan)
    # Compare to HISTORICAL ATR distribution before the signal session; don't peek forward.
    atr_hist = atr_pct.shift(1)
    qlo = atr_hist.rolling(252, min_periods=60).quantile(.33)
    qhi = atr_hist.rolling(252, min_periods=60).quantile(.67)
    vol = np.full(len(g), 'V_UNKNOWN', dtype=object)
    isvalid = atr_pct.notna() & qlo.notna() & qhi.notna()
    vol[(isvalid & (atr_pct < qlo)).to_numpy()] = VOLS[0]
    vol[(isvalid & (atr_pct >= qlo) & (atr_pct <= qhi)).to_numpy()] = VOLS[1]
    vol[(isvalid & (atr_pct > qhi)).to_numpy()] = VOLS[2]

    # NSE close*shares is a daily rupee turnover proxy; adjusted historical OHLCV must be consistent.
    # The user's original features_daily.py defines D_dollar_vol = close*volume, denominated in local currency.
    if 'volume' in g:
        dv = (c * pd.Series(g.volume.to_numpy(float))).where(lambda x: x > 0)
        source = 'close*volume'
        if 'd_dollar_vol' in g:
            alt = pd.Series(g.d_dollar_vol.to_numpy(float)).where(lambda x: x > 0)
            dv = dv.fillna(alt)
            source = 'close*volume_with_d_dollar_vol_fallback'
    elif 'd_dollar_vol' in g:
        dv = pd.Series(g.d_dollar_vol.to_numpy(float)).where(lambda x: x > 0)
        source = 'd_dollar_vol_from_original_features'
    else:
        dv = pd.Series(np.nan, index=c.index)
        source = 'MISSING_VOLUME_AND_TURNOVER'
    adv20_cr = dv.rolling(20, min_periods=20).mean()/1e7
    ret10_atr = (c/c.shift(10)-1) / pd.Series(atr_frac).where(lambda x: x > 0)
    h52 = h.rolling(252, min_periods=126).max()
    near52 = (c >= .98*h52) & h52.notna()
    return pd.DataFrame({
        'date':g.timestamp.dt.strftime('%Y-%m-%d'), 'state':state,
        'vol_state':vol, 'atr_pct':atr_pct.to_numpy(),
        'sma50':s50.to_numpy(), 'sma200':s200.to_numpy(), 'ema20':e20.to_numpy(),
        'close_price':c.to_numpy(), 'above200':np.where(s200.notna(),c>=s200,False),
        'adv20_cr':adv20_cr.to_numpy(), 'ret10_atr':ret10_atr.to_numpy(),
        'near52w':near52.to_numpy(), 'liquidity_source':source,
    })[CONTEXT_COLS]


def annotate(trades:pd.DataFrame,ctx:pd.DataFrame)->pd.DataFrame:
    if trades.empty: return trades.copy()
    # Join state and volatility at signal day (close before entry), AND at D0.
    assert ctx.date.is_unique
    ss = ctx.rename(columns={'date':'signal_date', **{c:c+'_signal' for c in CONTEXT_COLS if c!='date'}})
    dd = ctx.rename(columns={'date':'d0_date', **{c:c+'_d0' for c in CONTEXT_COLS if c!='date'}})
    e=trades.merge(ss,how='left',on='signal_date',validate='many_to_one')
    e=e.merge(dd,how='left',on='d0_date',validate='many_to_one')
    if e.state_signal.isna().any() or e.state_d0.isna().any():
        raise AssertionError('Unmatched signal or D0 context')
    if (pd.to_datetime(e.signal_date) >= pd.to_datetime(e.entry_date)).any():
        raise AssertionError('Future leakage: signal date >= entry date')
    if (pd.to_datetime(e.d0_date) >= pd.to_datetime(e.entry_date)).any():
        raise AssertionError('Future leakage: D0 date >= entry date')
    return e


def universe_masks(e:pd.DataFrame):
    p=e.close_price_signal
    liquid = (p >= 50) & (e.adv20_cr_signal >= 5)
    atr3 = (e.atr_pct_signal >= 3)
    above = e.above200_signal.astype(bool)
    res = {
        'ALL_CACHED': pd.Series(True,index=e.index),
        'PRICE_GE_50': p >= 50,
        'LIQUID_5CR': liquid,
        'LIQUID_25CR': (p>=50)&(e.adv20_cr_signal>=25),
        'LIQUID_ATR_GE_3': liquid & atr3,
        'LIQUID_ATR_GE_6': liquid & (e.atr_pct_signal>=6),
        'LIQUID_ATR3_ABOVE_SMA200': liquid & atr3 & above & e.sma200_signal.notna(),
        'LIQUID_ATR3_BELOW_SMA200': liquid & atr3 & ~above & e.sma200_signal.notna(),
        'LIQUID_ATR3_DIP_1ATR': liquid & atr3 & (e.ret10_atr_signal <= -1),
        'LIQUID_ATR3_NEAR_52W_HIGH': liquid & atr3 & e.near52w_signal.astype(bool),
        'LIQUID_ATR3_AWAY_FROM_HIGH': liquid & atr3 & (~e.near52w_signal.astype(bool)),
    }
    return res


def summary(df:pd.DataFrame,keys:list[str])->pd.DataFrame:
    cols=keys+['n','avg_net_pct','median_net_pct','win_pct','severe_loss_pct','severe_win_pct',
               'avg_vs_d1_same_exit_pp','avg_d1_d5_pct','avg_atr_pct','avg_turnover_cr']
    if df.empty: return pd.DataFrame(columns=cols)
    e=df.assign(_win=df.net_setup_pct.gt(0).astype('int8'),
                _loss=df.net_setup_pct.le(-5).astype('int8'),
                _big=df.net_setup_pct.ge(5).astype('int8'))
    a=e.groupby(keys,observed=True,dropna=False,sort=True).agg(
        n=('net_setup_pct','size'),avg_net_pct=('net_setup_pct','mean'),
        median_net_pct=('net_setup_pct','median'),win_pct=('_win','mean'),
        severe_loss_pct=('_loss','mean'),severe_win_pct=('_big','mean'),
        avg_vs_d1_same_exit_pp=('ret_vs_d1_same_exit_pp','mean'),
        avg_d1_d5_pct=('net_d1_d5_pct','mean'),
        avg_atr_pct=('atr_pct_signal','mean'),avg_turnover_cr=('adv20_cr_signal','mean')).reset_index()
    for x in ['win_pct','severe_loss_pct','severe_win_pct']:a[x]*=100
    return a[cols]


def compare_neg_middle(gr:pd.DataFrame,groupkeys:list[str])->pd.DataFrame:
    if gr.empty:return pd.DataFrame()
    x=gr.pivot_table(index=groupkeys,columns='sde_bucket_signal',
          values=['avg_net_pct','n'],aggfunc='first',observed=True)
    x.columns=[f'{a}_{b}' for a,b in x.columns];x=x.reset_index()
    for b in BUCKETS:
        for c in ['n','avg_net_pct']:
            if f'{c}_{b}' not in x:x[f'{c}_{b}']=np.nan
    x['lift_neg_vs_mid_pp']=x['avg_net_pct_NEG_LT_-0.5']-x['avg_net_pct_MID']
    x['lift_neg_vs_pos_pp']=x['avg_net_pct_NEG_LT_-0.5']-x['avg_net_pct_POS_GT_+0.5']
    return x


def matched_by_entry_day(e:pd.DataFrame,dimensions:list[str],positive=False):
    """Same entry_date and optional setup/state/vol, comparing cross-sectional groups.
    Each matched unit (date+context) contributes equal weight, preventing pooled-date confounding.
    """
    target='POS_GT_+0.5' if positive else 'MID'
    q=e[e.sde_bucket_signal.isin(['NEG_LT_-0.5',target])]
    cols=['entry_date']+dimensions+['sde_bucket_signal']
    g=q.groupby(cols,observed=True,dropna=False).net_setup_pct.agg(['mean','size']).reset_index()
    if g.empty:return pd.DataFrame()
    wide=g.pivot(index=['entry_date']+dimensions,columns='sde_bucket_signal',values=['mean','size'])
    needed=[('mean','NEG_LT_-0.5'),('mean',target)]
    if not all(c in wide.columns for c in needed): return pd.DataFrame()
    x=wide.dropna(subset=needed).reset_index()
    x['diff_pp']=x[('mean','NEG_LT_-0.5')]-x[('mean',target)]
    out=pd.DataFrame({n:x[n].iloc[:,0] if isinstance(x[n],pd.DataFrame) else x[n] for n in ['entry_date']+dimensions})
    out['neg_n']=x[('size','NEG_LT_-0.5')].to_numpy()
    out['comparison_n']=x[('size',target)].to_numpy()
    out['diff_pp']=x['diff_pp'].to_numpy()
    out['comparison']=f'NEG_vs_{target}'
    return out


def matched_stats(matches:pd.DataFrame)->dict:
    if matches.empty:return dict(matched_cells=0,mean_daily_diff_pp=np.nan,median_diff_pp=np.nan,ci95_lo=np.nan,ci95_hi=np.nan)
    # Bootstrap over distinct calendar weeks, not individual correlated stock trades.
    dates=pd.to_datetime(matches.entry_date)
    tmp=matches.assign(week=dates.dt.to_period('W-FRI').astype(str))
    byweek=tmp.groupby('week',sort=True).diff_pp.agg(['sum','size']).reset_index()
    means=byweek['sum'].to_numpy(float); counts=byweek['size'].to_numpy(int)
    rng=np.random.default_rng(77)
    if len(byweek)>=4:
        sample=rng.integers(0,len(byweek),size=(1000,len(byweek)))
        draws=means[sample].sum(axis=1)/counts[sample].sum(axis=1)
        lo,hi=np.quantile(draws,[.025,.975])
    else:lo=hi=np.nan
    return dict(matched_cells=len(matches),matched_weeks=len(byweek),
                mean_daily_diff_pp=float(matches.diff_pp.mean()),
                median_diff_pp=float(matches.diff_pp.median()),
                ci95_lo=float(lo),ci95_hi=float(hi))


def table_md(df:pd.DataFrame,limit=30)->str:
    if df.empty:return '*No observations.*'
    d=df.head(limit).copy()
    for k in d.columns:
        if pd.api.types.is_numeric_dtype(d[k]):
            d[k]=d[k].map(lambda x:'—' if pd.isna(x) else (f'{int(x):,}' if k in ('n','matched_cells','matched_weeks') else f'{x:+.3f}' if 'lift_' in k or k.startswith('mean_daily_diff') else f'{x:.3f}'))
    return '| '+' | '.join(map(str,d.columns))+' |\n|'+ '|'.join(['---']*len(d.columns))+'|\n'+'\n'.join('| '+' | '.join(map(str,row))+' |' for row in d.itertuples(index=False,name=None))


def compact(df:pd.DataFrame):
    d=df.copy()
    for col in d.select_dtypes(include=['float']).columns:d[col]=d[col].round(3)
    return d


def render_html(md_report:str,full_tables:dict[str,pd.DataFrame],out:Path,metadata:dict,images:dict[str,Path]):
    # Single self-contained report: no external CSS, JS, fonts, image URLs, or network access.
    sections=[]
    def htable(d,ident):
        if d.empty:return '<p>No cases with complete observations.</p>'
        return compact(d).to_html(index=False,border=0,table_id=ident,escape=True,classes=['data'])
    for title,df in full_tables.items():
        ident='table_'+str(len(sections))
        sections.append(f'<details><summary>{html.escape(title)} — {len(df):,} rows</summary>'
                        f'<p>Search within this table: <input class="find" data-table="{ident}" placeholder="Filter state / setup / year / universe"></p>'
                        f'<div class="scroll">{htable(df,ident)}</div></details>')
    figures=[]
    for title,p in images.items():
        if p.is_file():
            encoded=base64.b64encode(p.read_bytes()).decode('ascii')
            figures.append(f'<section><h2>{html.escape(title)}</h2><img alt="{html.escape(title)}" src="data:image/png;base64,{encoded}"></section>')
    # markdown text is kept as <pre> plus HTML summary curated tables below; markdown remains independently readable.
    try:
        import mistune
        summary=mistune.create_markdown(plugins=['table'])(md_report)
    except ImportError:
        summary='<pre>'+html.escape(md_report[:25000])+'</pre>'
    css='''body{font:14px/1.5 Arial,sans-serif;max-width:1220px;margin:auto;padding:26px;color:#192b36;background:#fafbfd}h1{font-size:26px}h2{font-size:19px}code,pre{font:12px/1.55 Consolas,monospace}pre{white-space:pre-wrap;background:#f1f4f7;padding:14px;border-radius:9px}.scroll{max-height:650px;overflow:auto;border:1px solid #ddd}table{border-collapse:collapse;font-size:12px;width:100%;background:white}th,td{padding:6px 8px;border-bottom:1px solid #e7ecef;text-align:right;white-space:nowrap}th:first-child,td:first-child{text-align:left}th{position:sticky;top:0;background:#eaf0f4;z-index:1}details{margin:16px 0;background:white;border:1px solid #d6dee6;border-radius:9px;padding:12px}summary{font-size:15px;font-weight:650;cursor:pointer}input{padding:8px;border:1px solid #ccd;border-radius:6px;width:340px}img{width:100%;max-width:920px;height:auto}p.warn{border-left:3px solid #cc9e24;padding:10px;background:#faf5e7}'''
    js='''document.querySelectorAll('input.find').forEach(el=>el.addEventListener('input',()=>{let q=el.value.trim().toLowerCase();let rows=document.querySelectorAll('#'+el.dataset.table+' tbody tr');rows.forEach(r=>{r.style.display=r.textContent.toLowerCase().includes(q)?'':'none'})}));'''
    content=f'''<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>BigMove SDE State CONSO</title><style>{css}</style></head><body>
    <h1>BigMove — SDE × 10 stock states × 3 volatility states</h1><p><b>Single consolidated exploratory report</b> · Frozen hash {html.escape(metadata['frozen_sha256'])} · Read-only</p>
    <p class="warn">Not OOS. Historic setups and SDE have been repeatedly researched. Large overlapping candidate populations are NOT independent evidence of tradable portfolio profit. Fills and market impact are unverified.</p>
    <h2>Executive summary and definitions (also in CONSO_REPORT.md)</h2><section class="executive">{summary}</section>
    {''.join(figures)}<h2>Complete comparison tables — all available cases</h2>{''.join(sections)}
    <p>Data-quality and output details: RUN.json, CONSO_REPORT.md, and raw trade-event CSVs. Frozen source files unchanged.</p><script>{js}</script></body></html>'''
    (out/'CONSO_REPORT.html').write_text(content,encoding='utf-8')


def draw_plots(df:pd.DataFrame,out:Path)->dict[str,Path]:
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:return {}
    paths={}
    core=summary(df,['state_signal','sde_bucket_signal'])
    if not core.empty:
        pivot=core.pivot(index='state_signal',columns='sde_bucket_signal',values='avg_net_pct').reindex(STATES)
        ax=pivot[BUCKETS].plot(kind='bar',figsize=(14,6),rot=50)
        ax.axhline(0,linewidth=.7,color='gray'); ax.set_ylabel('Net return %')
        ax.set_title('First-trigger unique events: 10 stock states × pre-entry SDE10')
        plt.tight_layout();path=out/'state_by_sde.png';plt.savefig(path,dpi=140);plt.close();paths['10 stock states vs SDE']=path
    vol=summary(df,['vol_state_signal','sde_bucket_signal'])
    if not vol.empty:
        pivot=vol.pivot(index='vol_state_signal',columns='sde_bucket_signal',values='avg_net_pct').reindex(VOLS)
        ax=pivot[BUCKETS].plot(kind='bar',figsize=(10,5),rot=0)
        ax.axhline(0,linewidth=.7,color='gray');ax.set_ylabel('Net return %')
        ax.set_title('First-trigger unique events: 3 volatility regimes × pre-entry SDE10')
        plt.tight_layout();path=out/'vol_by_sde.png';plt.savefig(path,dpi=140);plt.close();paths['3 volatility states vs SDE']=path
    return paths


def analyze_family(d:pd.DataFrame,prefix:str,out:Path,min_n:int,make_plots=False):
    if d.empty:
        raise RuntimeError(f'No setup events for {prefix}: check data and dates')
    event_key=(['symbol','entry_date'] if prefix=='first_setup_wins' else ['symbol','setup','entry_date'])
    d=d.sort_values(['symbol','entry_date','d0_date'],kind='mergesort')
    events=d.drop_duplicates(event_key,keep='last').copy()
    if events.duplicated(event_key).any():raise AssertionError('Deduplication failed')
    # Write event-level raw audit, including precise time-aligned state and screen values.
    events.to_csv(out/(prefix+'_UNIQUE_EVENTS_WITH_STATES.csv'),index=False)
    # Keep candidate-wide files optional because full universe can be several hundred thousand records.
    bucket_cols=['sde_bucket_signal','sde_bucket_d0']
    events['year']=pd.to_datetime(events.entry_date).dt.year
    events['screen_source']=events.liquidity_source_signal
    flags=universe_masks(events)
    full_cases=[]; annual=[]; universe_metrics=[]; state_vol=[]; state_lift=[]; matches=[]
    for universe in UNIVERSES:
        e=events.loc[flags[universe]]
        if e.empty:continue
        s=summary(e,['sde_bucket_signal'])
        s.insert(0,'universe',universe); universe_metrics.append(s)
        a=summary(e,['state_signal','vol_state_signal','sde_bucket_signal'])
        a.insert(0,'universe',universe);state_vol.append(a)
        lift=compare_neg_middle(summary(e,['state_signal','vol_state_signal','sde_bucket_signal']),['state_signal','vol_state_signal'])
        if not lift.empty:
            lift.insert(0,'universe',universe);state_lift.append(lift)
        # Full 7-setup × 10 states × 3 vol × 3 SDE for every universe.
        # A case is real only if it has observed events. Zero-count theoretical cells are retained separately in grid audit.
        cases=summary(e,['setup','state_signal','vol_state_signal','sde_bucket_signal'])
        cases.insert(0,'universe',universe);full_cases.append(cases)
        yy=summary(e,['year','setup','state_signal','vol_state_signal','sde_bucket_signal'])
        yy.insert(0,'universe',universe);annual.append(yy)
        for dims,scope in [([], 'ENTRY_DAY'),(['setup'],'ENTRY_DAY_SETUP'),
                           (['setup','state_signal'],'ENTRY_DAY_SETUP_STATE'),
                           (['setup','state_signal','vol_state_signal'],'ENTRY_DAY_SETUP_STATE_VOL')]:
            # Detailed matched rows are not persisted for all subsets to avoid enormous files.
            for positive in (False,True):
                x=matched_by_entry_day(e,dims,positive=positive)
                sta=matched_stats(x)
                sta.update({'universe':universe,'scope':scope,
                            'comparison':'NEG_vs_POS' if positive else 'NEG_vs_MID',
                            'eligible_events':len(e)})
                matches.append(sta)
    if not full_cases:raise RuntimeError('No classified candidate cells')
    observed_combos=pd.concat(full_cases,ignore_index=True)
    # Complete the entire 7 x 10 x 3 x 3 cube for every universe with zero-N
    # cells. Unknown-history categories are retained in a separate audit table.
    cube_keys=['universe','setup','state_signal','vol_state_signal','sde_bucket_signal']
    grid=pd.MultiIndex.from_product([UNIVERSES,list(original.ORDER),STATES,VOLS,BUCKETS],names=cube_keys)
    combos=(observed_combos.set_index(cube_keys).reindex(grid).reset_index())
    combos['n']=combos['n'].fillna(0).astype('int64')
    unknown=observed_combos.loc[(observed_combos.state_signal=='UNCLASSIFIED')|
                                 (observed_combos.vol_state_signal=='V_UNKNOWN')].copy()
    unknown.to_csv(out/(prefix+'_UNKNOWN_HISTORY_AUDIT.csv'),index=False)
    annual_cases=pd.concat(annual,ignore_index=True)
    metrics=pd.concat(universe_metrics,ignore_index=True)
    by_sv=pd.concat(state_vol,ignore_index=True)
    lift=pd.concat(state_lift,ignore_index=True) if state_lift else pd.DataFrame()
    match=pd.DataFrame(matches)
    combos.to_csv(out/(prefix+'_ALL_CASES.csv'),index=False)
    annual_cases.to_csv(out/(prefix+'_ALL_CASES_BY_YEAR.csv'),index=False)
    metrics.to_csv(out/(prefix+'_UNIVERSE_BASELINES.csv'),index=False)
    by_sv.to_csv(out/(prefix+'_10x3xSDE.csv'),index=False)
    lift.to_csv(out/(prefix+'_STATE_VOL_LIFTS.csv'),index=False)
    match.to_csv(out/(prefix+'_DATE_MATCHED.csv'),index=False)
    other={
        'year_by_sde':summary(events,['year','sde_bucket_signal']),
        'setup_by_sde':summary(events,['setup','sde_bucket_signal']),
        'state_by_sde':summary(events,['state_signal','sde_bucket_signal']),
        'vol_by_sde':summary(events,['vol_state_signal','sde_bucket_signal']),
        'd0_state_by_sde':summary(events,['state_d0','sde_bucket_d0']),
        'by_liquidity':summary(events.assign(liq_band=np.select(
                [events.adv20_cr_signal < 5,events.adv20_cr_signal <25,events.adv20_cr_signal>=25],
                ['LOW_LT5CR','MID_5TO25CR','HIGH_GE25CR'],default='UNKNOWN')),
               ['liq_band','sde_bucket_signal']),
    }
    for name,g in other.items():g.to_csv(out/(prefix+'_'+name+'.csv'),index=False)
    # Missing history / liquidity documented in report, not treated as a negative SDE case.
    coverage={
        'candidate_rows':len(d), 'distinct_event_rows':len(events),
        'missing_stock_state_events':int((events.state_signal=='UNCLASSIFIED').sum()),
        'missing_volatility_state_events':int((events.vol_state_signal=='V_UNKNOWN').sum()),
        'missing_liquidity_events':int(events.adv20_cr_signal.isna().sum()),
        'missing_historical_sma200_events':int(events.sma200_signal.isna().sum()),
        'base_by_universe':{u:int(m.sum()) for u,m in flags.items()},
        'sde_groups':events.sde_bucket_signal.value_counts().to_dict(),
        'liquidity_sources':events.liquidity_source_signal.value_counts().to_dict(),
    }
    # Top uplift cells gated by both sample sizes to discourage tiny-bin cherry picking.
    if not lift.empty:
        strong=lift[(lift['n_NEG_LT_-0.5']>=min_n)&(lift['n_MID']>=min_n)].copy()
        strong=strong.sort_values('lift_neg_vs_mid_pp',ascending=False)
        strong.to_csv(out/(prefix+'_RANKED_MIN_SAMPLE_CELLS.csv'),index=False)
    else:strong=pd.DataFrame()
    plots=draw_plots(events,out) if make_plots else {}
    return dict(events=events,coverage=coverage,combos=combos,annual=annual_cases,metrics=metrics,
                by_sv=by_sv,lift=lift,match=match,other=other,top=strong,plots=plots)


def create_conso(first:dict,ind:dict,out:Path,meta:dict,min_n:int):
    lines=['# BigMove — CONSOLIDATED SDE × stock state × volatility × frozen setups', '',
       '**One consolidated research report.** Full-universe historical exploratory results, not a live strategy or OOS.',
       f'Frozen setup hash: `{meta["frozen_sha256"]}`. The code uses the original `setuplab.trigger()` and its seven unchanged setups.',
       f'Universe: {meta["stock_count"]:,} stock symbols; {meta["eligible_d0"]:,} eligible hypothetical D0 watches; cost 0.35 percentage points round-trip.',
       '', '## 1. Research contract / definitions','',
       'SDE10 = (C[t]-C[t-10]) / sum(|C[j]-C[j-1]|, j=t-9..t). NEG: strictly below -0.5. POS: strictly above +0.5. Exactly +/-0.5 is MID.',
       'Primary SDE, states, volatility and liquidity are observed **at the last COMPLETED close before each setup entry**. D0 values are separately shown; they are not interchangeable when multiple synthetic watches generate the same entry.',
       '**Ten structural states:** 5 slow SMA50/SMA200 regimes × position above/below EMA20. States do NOT depend on SDE. Classification requires 220 daily observations; otherwise UNCLASSIFIED.',
       '**Three additional volatility states:** simple ATR14/close compared with prior up to 252 historical sessions (minimum 60), with rolling 33rd and 67th percentile thresholds. These are RELATIVE volatility states, not absolute ATR bands.',
       '**Trade universe slices:** point-in-time signal-close screen, price >= ₹50; ADV20 >= ₹5 crore/day; high-liquidity >=₹25 crore/day; ATR% >=3% and >=6%; above/below SMA200; >=1 ATR 10-session decline; near 52-week high. The last two are explicitly exploratory and may correlate mechanically with SDE.',
       '', '### 10 structural stock states',
       table_md(pd.DataFrame(STATE_DEFS,columns=['State','Rule']),12),'','### 3 volatility states',
       table_md(pd.DataFrame(VOL_DEFS,columns=['Volatility state','Rule']),5),
       '', '## 2. Data quality and event accounting',
       f'- Independent setup events (unique stock + setup + entry): **{ind["coverage"]["distinct_event_rows"]:,}**.',
       f'- First-setup-wins events (unique stock + entry): **{first["coverage"]["distinct_event_rows"]:,}**.',
       f'- Missing stock-state labels (first wins): **{first["coverage"]["missing_stock_state_events"]:,}**.',
       f'- Missing volatility-state labels (first wins): **{first["coverage"]["missing_volatility_state_events"]:,}**.',
       f'- Missing traded-value context (first wins): **{first["coverage"]["missing_liquidity_events"]:,}**.',
       '', '## 3. All cached setup entries: pre-entry SDE (FIRST SETUP WINS)',
       table_md(first['other']['year_by_sde'].groupby('sde_bucket_signal',as_index=False).agg(n=('n','sum'))),
       '', '### SDE bucket performance (first wins)',
       table_md(first['metrics'].query('universe=="ALL_CACHED"').drop(columns='universe'),5),
       '', '### SDE bucket performance (each setup independently)',
       table_md(ind['metrics'].query('universe=="ALL_CACHED"').drop(columns='universe'),5),
       '', '## 4. How universe filters change performance (FIRST SETUP WINS)',
       table_md(first['metrics'][['universe','sde_bucket_signal','n','avg_net_pct','win_pct','severe_loss_pct','avg_turnover_cr']],60),
       '', '## 5. Ten stock states × SDE (FIRST SETUP WINS)',
       table_md(first['other']['state_by_sde'][['state_signal','sde_bucket_signal','n','avg_net_pct','win_pct','severe_loss_pct']],40),
       '', '## 6. Three volatility states × SDE (FIRST SETUP WINS)',
       table_md(first['other']['vol_by_sde'][['vol_state_signal','sde_bucket_signal','n','avg_net_pct','win_pct','severe_loss_pct']],15),
       '', '## 7. Each frozen setup × pre-entry SDE (INDEPENDENT SETUP EVENTS)',
       table_md(ind['other']['setup_by_sde'][['setup','sde_bucket_signal','n','avg_net_pct','win_pct','severe_loss_pct']],25),
       '', '## 8. 10 × 3 state-volatility grid (FIRST SETUP WINS)',
       table_md(first['by_sv'].query('universe=="ALL_CACHED"')[['state_signal','vol_state_signal','sde_bucket_signal','n','avg_net_pct','win_pct','severe_loss_pct']],150),
       '', f'## 9. Strongest conditional cells (minimum {min_n} distinct events per NEG and MID group)',
       'CAUTION: these are retrospective rankings among many cells; **not** tuned rules or independent confirmation.',
       table_md(first['top'][['universe','state_signal','vol_state_signal','n_NEG_LT_-0.5','n_MID','lift_neg_vs_mid_pp']].head(35) if len(first['top']) else pd.DataFrame(),35),
       '', '## 10. Same-date controls (first wins; compare only dates with both SDE groups)',
       table_md(first['match'][['universe','scope','comparison','matched_cells','matched_weeks','mean_daily_diff_pp','ci95_lo','ci95_hi']].query('scope in ["ENTRY_DAY","ENTRY_DAY_SETUP"]'),55),
       '', '## 11. Year-by-year stability (first wins; pre-entry SDE)',
       table_md(first['other']['year_by_sde'][['year','sde_bucket_signal','n','avg_net_pct','win_pct','severe_loss_pct']],30),
       '', '## 12. Entry-time versus D0 and overlap limitations',
       'The report always distinguishes pre-entry SDE/state from D0 SDE/state. Consecutive D0 windows share future returns. A unique stock-entry event is not automatically an independent investment opportunity. Independent setup events can overlap when multiple rules trigger on the same stock and date.',
       'Only first-trigger unique events are closest to an event-level strategy; even those ignore capital occupancy, fees beyond 35bp, fills, price limits and delisting/survivorship bias. Same-date comparisons reduce date confounding but do not establish causality or remove stock dependencies.',
       'The 2021–2026 period has already been mined for frozen setups and SDE. Conditioning on past studies introduces multiple-testing bias. A genuinely independent prospective sample is needed before using any state/SDE interaction to trade.',
       '', '## 13. Full-case files and how to read the CONSO',
       '`CONSO_REPORT.html` is the **single self-contained consolidated report** with full filterable tables and charts. '
       'The complete 7-setup × 10-state × 3-volatility × 3-SDE grid is in '
       '`independent_setups_ALL_CASES.csv` and `first_setup_wins_ALL_CASES.csv` for each universe. '
       'The same cells by year appear in `*_ALL_CASES_BY_YEAR.csv`; all individual records are in `*_UNIQUE_EVENTS_WITH_STATES.csv`.',
       '', '**No frozen code, production data, or portfolio rules were modified.**']
    report='\n'.join(lines)+'\n'
    (out/'CONSO_REPORT.md').write_text(report,encoding='utf-8')
    tables={
        'First-wins: SDE buckets across 11 universe screens': first['metrics'],
        'Independent setups: SDE buckets across universe screens': ind['metrics'],
        'First-wins: 10 states × 3 volatility × SDE × universe': first['by_sv'],
        'All 7 setups: full universe × state × volatility × SDE grid': ind['combos'],
        'First-wins: full universe × state × volatility × SDE grid': first['combos'],
        'First-wins: all cells by year': first['annual'],
        'All 7 independent setups: all cells by year': ind['annual'],
        'Matched same-day controls':first['match'],
        'Top cells with minimum sample gates (EXPLORATORY)':first['top'],
    }
    render_html(report,tables,out,meta,first['plots'])


def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    src=ap.add_mutually_exclusive_group(required=True)
    src.add_argument('--panel',type=Path)
    src.add_argument('--daily-dir',type=Path)
    ap.add_argument('--features-code',type=Path)
    ap.add_argument('--frozen-json',type=Path,default=Path(__file__).resolve().with_name('FROZEN_SETUPS.json'))
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--from',dest='start',default='2021-01-01')
    ap.add_argument('--through',dest='end',default='2026-09-22')
    ap.add_argument('--min-events',type=int,default=100)
    ap.add_argument('--limit-symbols',type=int,default=0,help='smoke-test only')
    args=ap.parse_args(argv)
    if args.out.exists():ap.error('REFUSING to overwrite output directory: '+str(args.out))
    if args.daily_dir and not args.features_code:ap.error('Raw cache requires --features-code')
    if args.panel and not args.panel.is_file():ap.error('Panel file does not exist')
    if args.daily_dir and not args.daily_dir.is_dir():ap.error('Raw directory does not exist')
    frozen_path,doc=freeze.load_frozen(args.frozen_json)
    if tuple(x['id'] for x in doc['setups']) != original.ORDER:
        raise ValueError('The seven frozen setup IDs / order do not match the audited source')
    if doc['sha256'] != '483f1539324f3ae5c06756b00b32c189f5eb995f73956a681673f005ce399c8f':
        raise ValueError('Unexpected frozen config hash. Explicitly audit a new version rather than silently continue.')
    start,end=pd.Timestamp(args.start),pd.Timestamp(args.end)
    if end<start:ap.error('End date before start date')
    if args.panel:
        full=original.read_panel(args.panel)
        dates=pd.DatetimeIndex(full.timestamp.unique()).sort_values()
        groups=((s,g) for s,g in full.groupby('symbol',sort=True))
        num=full.symbol.nunique()
    else:
        paths=sorted(args.daily_dir.glob('*_daily.parquet'))
        if not paths:raise ValueError('No *_daily.parquet found')
        print('Building calendar from',len(paths),'raw daily files ...',flush=True)
        calset=set()
        for i,p in enumerate(paths):
            z=pd.read_parquet(p,columns=['timestamp']);calset.update(original.date_ist(z.timestamp).dropna().tolist())
            if (i+1)%250==0:print('Calendar',i+1,'/',len(paths),flush=True)
        dates=pd.DatetimeIndex(sorted(calset))
        module=[None]
        groups=((p.stem,original.from_raw(p,args.features_code,module)) for p in paths)
        num=len(paths)
    calendar={d:i for i,d in enumerate(dates)}
    args.out.mkdir(parents=True)
    independent=[];first=[];counts=Counter();processed=0
    print('READ ONLY | Using EXACT freeze:',doc['sha256'],flush=True)
    for sym,g in groups:
        if str(sym).upper() in original.EXCLUDED:continue
        if args.limit_symbols and processed>=args.limit_symbols:break
        processed+=1
        try:
            a,f,s=original.scan_symbol(g,calendar,start,end,doc,float(doc['cost_pp']))
            counts.update(s)
            if len(a) or len(f):
                ctx=price_context(g)
                if len(a):independent.append(annotate(a,ctx))
                if len(f):first.append(annotate(f,ctx))
        except Exception as exc:
            raise RuntimeError(f'STOP at symbol {sym}: {exc}') from exc
        if processed%100==0:print(f'Stocks {processed:,}/{num:,}, frozen triggers {counts["all_setup_entries"]:,}',flush=True)
    if not independent or not first:raise ValueError('No settled frozen setup entries in this sample')
    ind=pd.concat(independent,ignore_index=True)
    fw=pd.concat(first,ignore_index=True)
    print('Computing full-grid/annual/matched comparisons...',flush=True)
    A=analyze_family(ind,'independent_setups',args.out,args.min_events)
    F=analyze_family(fw,'first_setup_wins',args.out,args.min_events,make_plots=True)
    meta={
        'status':'FULL UNIVERSE EXPLORATORY / exact frozen setup trigger; separate point-in-time states',
        'source':str(args.panel or args.daily_dir), 'frozen_sha256':doc['sha256'],
        'frozen_reference_code_file_sha256':hashlib.sha256(Path(freeze.__file__).read_bytes()).hexdigest(),
        'feature_source':str(args.features_code) if args.features_code else 'panel features',
        'stock_count':processed,'eligible_d0':int(counts['eligible_d0']),
        'first_wins_unique_entry_events':F['coverage']['distinct_event_rows'],
        'independent_unique_setup_entry_events':A['coverage']['distinct_event_rows'],
        'candidate_first_wins':len(fw),'candidate_all_setups':len(ind),
        'first_coverage':F['coverage'],'independent_coverage':A['coverage'],
        'scan_counters':dict(counts),
        'state_definitions':STATE_DEFS,'volatility_state_definitions':VOL_DEFS,
        'universe_names':UNIVERSES,'from':str(start.date()),'through':str(end.date()),
        'caveats':['Study performed on available cache; not guaranteed survivorship-free NSE universe',
         'Historical hypothesis selected after observing outcomes; no independent OOS',
         '10 states are mutually exclusive where history available; 3 vol regimes are orthogonal',
         'All liquidity and states measured on close preceding setup entry, not future close',
         'Missing history or traded value explicitly flagged; not silently assigned',
         'Very large correlated overlapping synthetic D0; no 3-slot capital-constrained replay',
         'S2 may be conditioned on actual entry-open gap known only at that open',
         'Missing costs beyond flat 35bp, fills/market impact/circuits',
         'No production files changed']}
    (args.out/'RUN.json').write_text(json.dumps(meta,indent=2,default=str),encoding='utf8')
    create_conso(F,A,args.out,meta,args.min_events)
    print('DONE: '+str(args.out/'CONSO_REPORT.html'),flush=True)
    return 0


if __name__=='__main__':
    raise SystemExit(main())
