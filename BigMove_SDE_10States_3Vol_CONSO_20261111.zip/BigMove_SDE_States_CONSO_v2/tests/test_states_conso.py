import sys
import unittest
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import sde_states_conso as state
import sde_universe_setup_study as study


class StateContextTests(unittest.TestCase):
    @staticmethod
    def sample(n=500):
        rng=np.random.default_rng(123)
        c=100*np.exp(np.cumsum(rng.normal(.0001,.025,n)))
        o=c*np.exp(rng.normal(0,.007,n))
        h=np.maximum(o,c)*1.015
        low=np.minimum(o,c)*.985
        d={'symbol':'SYN','timestamp':pd.bdate_range('2021-01-01',periods=n),
           'open':o,'high':h,'low':low,'close':c,'volume':np.full(n,3_000_000.)}
        for feat in study.FEATURES:d[feat]=rng.normal(size=n)
        return study.normalize(pd.DataFrame(d))

    def test_lagged_state_and_vol_are_point_in_time(self):
        g=self.sample()
        orig=state.price_context(g)
        gg=g.copy()
        gg.loc[400:,'close']=gg.loc[400:,'close']*10
        gg.loc[400:,'high']=gg.loc[400:,'high']*10
        gg.loc[400:,'low']=gg.loc[400:,'low']*10
        gg.loc[400:,'open']=gg.loc[400:,'open']*10
        now=state.price_context(gg)
        for k in ['state','vol_state','atr_pct','adv20_cr','ret10_atr','near52w']:
            a=orig.loc[:399,k]; b=now.loc[:399,k]
            pd.testing.assert_series_equal(a,b,check_names=False)

    def test_ten_states_disjoint_and_unknown_missing_history(self):
        ctx=state.price_context(self.sample())
        self.assertTrue(set(ctx.state.unique()).issubset(set(state.STATES)|{'UNCLASSIFIED'}))
        self.assertTrue(set(ctx.vol_state.unique()).issubset(set(state.VOLS)|{'V_UNKNOWN'}))
        self.assertTrue((ctx.loc[:218,'state']=='UNCLASSIFIED').all())
        self.assertTrue((ctx.loc[219:,'state']!='UNCLASSIFIED').all())
        self.assertEqual((ctx.vol_state=='V_UNKNOWN').sum(),74) # ATR starts bar14; historical 60 -> bar74
        self.assertEqual(len(state.STATES),10)
        self.assertEqual(len(state.VOLS),3)

    def test_liquidity_is_rupee_turnover_and_uses_signal_close(self):
        g=self.sample()
        ctx=state.price_context(g)
        t=ctx.iloc[280]
        self.assertGreater(t.adv20_cr,5)
        self.assertIn(t.liquidity_source,('close*volume','close*volume_with_d_dollar_vol_fallback'))
        df=pd.DataFrame({'close_price_signal':[55.,45.,80.],
                         'adv20_cr_signal':[6.,30.,np.nan],
                         'atr_pct_signal':[3.5,7.,4.],
                         'above200_signal':[True,True,False],
                         'sma200_signal':[50.,50.,50.],
                         'ret10_atr_signal':[-2.,-3.,-4.],
                         'near52w_signal':[False,True,True]})
        masks=state.universe_masks(df)
        self.assertEqual(masks['LIQUID_5CR'].tolist(),[True,False,False])
        self.assertEqual(masks['LIQUID_ATR3_ABOVE_SMA200'].tolist(),[True,False,False])
        self.assertEqual(masks['LIQUID_ATR_GE_6'].sum(),0)

    def test_context_join_does_not_use_entry_close(self):
        g=self.sample()
        ctx=state.price_context(g)
        dates=g.timestamp.dt.strftime('%Y-%m-%d')
        row=pd.DataFrame([{'d0_date':dates.iloc[300], 'signal_date':dates.iloc[301],
                           'entry_date':dates.iloc[302], 'symbol':'SYN', 'setup':'S2',
                           'sde_bucket_signal':'NEG_LT_-0.5', 'net_setup_pct':2.}])
        x=state.annotate(row,ctx)
        self.assertEqual(x.state_signal.iloc[0],ctx.state.iloc[301])
        self.assertEqual(x.state_d0.iloc[0],ctx.state.iloc[300])
        with self.assertRaises(AssertionError):
            state.annotate(row.assign(signal_date=dates.iloc[303]),ctx)

    def test_full_cube_expected_cardinality_and_zero(self):
        self.assertEqual(len(state.UNIVERSES)*7*len(state.STATES)*len(state.VOLS)*3,6930)

if __name__=='__main__':unittest.main()
