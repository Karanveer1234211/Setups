"""
test_setuplab.py - setuplab's checks: hand-computed trades, the engine's edge cases, and three planted worlds.

  world R ("real setup"): every pick falls for 1-3 days then bounces; feature x turns down exactly on the last
          falling day, feature y is noise. x must beat D1 AND beat the price-only dip entry on the same trades;
          y must not beat the dip entry.
  world W ("waiting world"): the same fall-then-bounce prices, x and y both noise. Noise setups DO beat D1 here
          (just by waiting) - the trap - but must NOT beat the price-only dip entry.
  world N ("null"): random-walk prices, noise features: nothing beats D1.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import setuplab as S  # noqa: E402

FAILS = []
COUNT = [0]


def check(name, ok, detail=""):
    COUNT[0] += 1
    print(("  ok    " if ok else "  FAIL  ") + name + ("" if ok else "   <- %s" % (detail,)))
    if not ok:
        FAILS.append(name)


def make_world(kind, n_days=520, per_day=3, seed=1):
    """kind R / W / N. Each pick its own symbol; features given per symbol-date with explicit *_change."""
    rng = np.random.default_rng(seed)
    cal = pd.bdate_range("2021-01-01", periods=n_days + 15)
    wl, fe = [], []
    t = 0
    for d in range(2, n_days):
        for r in range(1, per_day + 1):
            t += 1
            sym = "S%05d" % t
            sc = 100.0
            ent = sc * (1 + rng.normal(0, 0.005))
            b = int(rng.integers(1, 4))                      # last falling day
            lr = rng.normal(0, 0.012, 10)
            if kind in ("R", "W"):
                lr[:b] -= 0.02
                lr[b:b + 4] += 0.015
            # closes relative to the D1 open; D1 open = entry; opens of later days = previous close (no gap) + noise
            C = np.empty(11)
            O = np.empty(11)
            O[1] = ent
            C[1] = ent * np.exp(lr[0])
            for k in range(2, 11):
                O[k] = C[k - 1] * (1 + rng.normal(0, 0.002))
                C[k] = O[k] * np.exp(lr[k - 1])
            row = {"trade_id": "D-%s-%d" % (cal[d].strftime("%Y%m%d"), r), "symbol": sym, "rank": r,
                   "signal_day": cal[d], "entry_day": cal[d + 1].strftime("%Y-%m-%d"), "signal_close": sc,
                   "status": "ok", "entry": ent, "net_bp": 0.0, "engine": "D", "pre_state": "S01",
                   "s_atr14": 0.02, "pre_state_bearish": int(rng.integers(0, 2)), "pre_state_bullish": 0,
                   "pre_nifty_vs_ma50": float(rng.normal()), "pre_env_code": int(rng.integers(0, 4)),
                   "pre_vix_pct250": float(rng.random()), "pre_ad_ratio_10": float(rng.random()),
                   "pre_state_overextended": 0, "pre_state_vol_elevated": int(rng.integers(0, 2))}
            for k in range(1, 11):
                row["close_%d" % k] = C[k] / ent - 1
                row["overnight_%d" % k] = (O[k] / (sc if k == 1 else C[k - 1]) - 1) if k > 1 else 0.0
            wl.append(row)
            # features on the signal day (D0) and D1..D6 dates: change at the date of day k is read at day k+1's open
            for k in range(0, 8):
                date = cal[d + k]
                if kind == "R":
                    xc = -1.0 if k == b else 1.0
                else:
                    xc = float(rng.choice([-1.0, 1.0]))
                yc = float(rng.choice([-1.0, 1.0]))
                fe.append({"symbol": sym, "timestamp": date, "x": xc, "x_change": xc, "y": yc, "y_change": yc})
    W = pd.DataFrame(wl)
    F = pd.DataFrame(fe)
    return S.Book(W, pd.Series(cal), F, "D"), W, F


def t_hand():
    """A three-pick hand world: every number below computed by hand."""
    cal = pd.bdate_range("2024-01-01", periods=20)
    rows = []

    def pick(i, closes, over, sc=100.0, ent=100.0):
        r = {"trade_id": "D-T-%d" % i, "symbol": "H%d" % i, "rank": 1, "signal_day": cal[2],
             "entry_day": cal[3].strftime("%Y-%m-%d"), "signal_close": sc, "status": "ok", "entry": ent,
             "net_bp": 0.0, "engine": "D", "pre_state": "S01", "s_atr14": 0.02,
             "pre_state_bearish": {1: 1, 2: 0, 3: np.nan}[i]}
        for k in range(1, 11):
            r["close_%d" % k] = closes[k - 1] / ent - 1
            r["overnight_%d" % k] = over[k - 1]
        return r
    cl = [98, 96, 97, 99, 101, 102, 103, 104, 105, 106]
    rows.append(pick(1, cl, [0] * 10))
    rows.append(pick(2, cl, [0, 0.01, 0, 0, 0, 0, 0, 0, 0, 0]))
    rows.append(pick(3, cl, [0] * 10))
    W = pd.DataFrame(rows)
    fe = []
    # feature f: change sequence by date index cal[2+k] (k = 0 is D0): pick 1 turns down at D2 (read at D3's open)
    seq = {1: [1, 1, -1, 1, 1, 1, 1], 2: [1, -1, 1, 1, 1, 1, 1], 3: [1, 0, 0, np.nan, 1, -1, 1]}
    for i, sq in seq.items():
        for k, v in enumerate(sq):
            fe.append({"symbol": "H%d" % i, "timestamp": cal[2 + k], "f": v, "f_change": v})
    book = S.Book(W, pd.Series(cal), pd.DataFrame(fe), "D")
    c = [("f_change", "<", 0)]
    L = S.replay(book, c, "original_d5").set_index("trade_id")
    Lf = S.replay(book, c, "fresh").set_index("trade_id")
    # pick 1: f falls at D2 -> enter D3 open = D2 close 96 (no gap) -> original exit D5 close 101
    check("h1 entry at the first open after the condition (D3 open = 96)", L.loc["D-T-1", "day"] == 3 and
          abs(L.loc["D-T-1", "price"] - 96) < 1e-9, L.loc["D-T-1"].to_dict())
    check("h2 original_d5 net = 101/96 - 1 - 0.35 pp", abs(L.loc["D-T-1", "ret"] - ((101 / 96 - 1) * 100 - 0.35)) < 1e-9)
    check("h3 fresh net = the close 4 sessions after entry (D7 = 103)",
          abs(Lf.loc["D-T-1", "ret"] - ((103 / 96 - 1) * 100 - 0.35)) < 1e-9 and Lf.loc["D-T-1", "exit_day"] == 7)
    # pick 2: f falls at D1 -> D2 open = D1 close 98 x 1.01 (gap) = 98.98
    check("h4 a gap is in the entry price (D2 open = 98 x 1.01)", abs(L.loc["D-T-2", "price"] - 98.98) < 1e-9)
    dd = 100 * (1 - 96 / 98.98)
    check("h5 trade drawdown = peak-to-trough over entry and closes", abs(L.loc["D-T-2", "trade_dd"] - dd) < 1e-9,
          (L.loc["D-T-2", "trade_dd"], dd))
    # pick 3: zero changes do not pass, then a missing value with no False -> Missing signal data
    check("h6 a zero change does not pass; a missing value then makes the trade 'Missing signal data'",
          L.loc["D-T-3", "status"] == "Missing signal data", L.loc["D-T-3", "status"])
    # condition with a False beside the missing value -> skip that day, not missing
    c2 = [("f_change", "<", 0), ("gap_pct", ">", 5)]
    L2 = S.replay(book, c2, "original_d5").set_index("trade_id")
    check("h7 a False beside a missing value = just not today (No entry, not Missing)",
          L2.loc["D-T-3", "status"] == "No entry", L2.loc["D-T-3", "status"])
    # blind D5 under original_d5: enter and exit the same session (open -> close)
    L3 = S.replay(book, [("day", ">=", 5), ("day", "<=", 5)], "original_d5").set_index("trade_id")
    check("h8 entry on D5 under original_d5 = D5 open to D5 close",
          abs(L3.loc["D-T-1", "ret"] - ((101 / 99 - 1) * 100 - 0.35)) < 1e-9)
    # fresh exit past D10 -> Missing exit data
    L4 = S.replay(book, [("day", ">=", 5), ("day", "<=", 5)], "fresh").set_index("trade_id")
    check("h9 fresh exit inside the 10-session path (D5 entry -> D9 close)",
          L4.loc["D-T-1", "status"] == "Filled" and L4.loc["D-T-1", "exit_day"] == 9)
    # dip control: pc_vs_d1 on D1 is never a dip; D2 open after D1 close 98 < 100 -> DIP_0 enters D2
    L5 = S.replay(book, S.control_setups()["DIP_0"], "original_d5").set_index("trade_id")
    L6 = S.replay(book, S.control_setups()["DIP_3"], "original_d5").set_index("trade_id")
    check("h10 price-only dip: DIP_0 enters D2 (98 < 100), DIP_3 waits for a close under 97 (D2 close 96 -> D3)",
          L5.loc["D-T-1", "day"] == 2 and L6.loc["D-T-1", "day"] == 3, (L5.loc["D-T-1", "day"], L6.loc["D-T-1", "day"]))
    L7 = S.replay(book, S.control_setups()["BOUNCE_upclose"], "original_d5").set_index("trade_id")
    L8 = S.replay(book, S.control_setups()["DIPATR_1"], "original_d5").set_index("trade_id")
    check("h12 ATR dip: ATR 2%%; D1 close 98 = exactly -1 ATR does not pass '< -1'; D2 close 96 (-2 ATR) -> enter D3",
          L8.loc["D-T-1", "day"] == 3, L8.loc["D-T-1", "day"])
    L9 = S.replay(book, S.control_setups()["TUE"], "original_d5").set_index("trade_id")
    exp = next((k for k in range(1, 6) if cal[3 + k - 1].weekday() == 1), 0)      # sessions, not calendar days
    check("h13 TUE control enters the first Tuesday open of D1..D5 (D1 = %s)" % cal[3].day_name(),
          (L9.loc["D-T-1", "day"] if L9.loc["D-T-1", "status"] == "Filled" else 0) == exp, (L9.loc["D-T-1", "day"], exp))
    L10 = S.replay(book, [("snap:pre_state_bearish", ">", 0.5)], "original_d5").set_index("trade_id")
    check("h14 snapshot field (the pick's state at the signal): 1 -> enter D1, 0 -> No entry, missing -> Missing",
          L10.loc["D-T-1", "day"] == 1 and L10.loc["D-T-2", "status"] == "No entry" and
          L10.loc["D-T-3", "status"] == "Missing signal data", L10["status"].to_dict())
    check("h11 bounce marker: under the D1 open, then an up close (D3 close 97 > 96 -> enter D4)",
          L7.loc["D-T-1", "day"] == 4, L7.loc["D-T-1", "day"])


def t_worlds():
    res = {}
    for kind in ("R", "W", "N"):
        book, _, _ = make_world(kind, seed={"R": 3, "W": 4, "N": 5}[kind])
        boot = S.Boot(book.signal_day[book.ok])
        setups = {"X": [("x_change", "<", 0)], "Y": [("y_change", "<", 0)], **S.control_setups()}
        led = S.run_all(book, setups, boot)
        res[kind] = {}
        for nm in ("X", "Y"):
            for ctl in ("Blind_D1", "DIP_0"):
                res[kind][(nm, ctl)] = S.paired(led[(nm, "original_d5")], led[(ctl, "original_d5")], boot)
                res[kind][(nm, ctl, "fresh")] = S.paired(led[(nm, "fresh")], led[(ctl, "fresh")], boot)
    R, Wd, N = res["R"], res["W"], res["N"]
    f = lambda r: "lift %+.3f [%+.3f, %+.3f] n %d" % (r["lift_pp"], r["lo"], r["hi"], r["n"])
    check("w1 world R: the planted setup beats D1 on its own trades (interval above 0)", R[("X", "Blind_D1")]["lo"] > 0,
          f(R[("X", "Blind_D1")]))
    check("w2 world R: the planted setup beats the price-only dip entry on the same trades (both exits)",
          R[("X", "DIP_0")]["lo"] > 0 and R[("X", "DIP_0", "fresh")]["lo"] > 0,
          (f(R[("X", "DIP_0")]), f(R[("X", "DIP_0", "fresh")])))
    check("w3 world R: the noise feature does not beat the dip entry", not R[("Y", "DIP_0")]["lo"] > 0,
          f(R[("Y", "DIP_0")]))
    check("w4 world W (fall-then-bounce, noise features): noise setups DO beat D1 - waiting alone pays (the trap)",
          Wd[("X", "Blind_D1")]["lo"] > 0 and Wd[("Y", "Blind_D1")]["lo"] > 0,
          (f(Wd[("X", "Blind_D1")]), f(Wd[("Y", "Blind_D1")])))
    check("w5 world W: ... but they do NOT beat the price-only dip entry (the control catches the trap)",
          not Wd[("X", "DIP_0")]["lo"] > 0 and not Wd[("Y", "DIP_0")]["lo"] > 0,
          (f(Wd[("X", "DIP_0")]), f(Wd[("Y", "DIP_0")])))
    check("w6 world N (random walk, noise): no setup beats D1", all(not (N[(k, "Blind_D1")]["lo"] > 0) and
                                                                   not (N[(k, "Blind_D1")]["hi"] < 0) for k in "XY"),
          (f(N[("X", "Blind_D1")]), f(N[("Y", "Blind_D1")])))


def t_space():
    book, _, _ = make_world("N", n_days=200, seed=9)
    sp = S.space_setups(["x", "y"])
    check("s1 the pair space of 2 features = 4 singles... (2 x 2 singles + 1 pair x 4 directions = 8 setups)",
          len(sp) == 8, len(sp))
    abc = S.abc_setups()
    check("s2 A/B/C x 4 confirmations = 28 setups; A+C and A+B+C identical conditions",
          len(abc) == 28 and set(abc["A+C__none"]) == set(abc["A+B+C__none"]))


def t_confluence():
    import tempfile
    tmp = Path(tempfile.mkdtemp(prefix="sl_conf_"))
    pd.DataFrame({"engine": ["D"] * 6, "feature": ["D_sma200", "D_ema20_angle_deg", "Comb_X", "D_missing",
                                                   "W_ret_13w", "D_rsi14"],
                  "importance": [6, 5, 4, 3, 2, 1]}).to_csv(tmp / "why.csv", index=False)
    pd.DataFrame({"symbol": ["A"], "timestamp": [pd.Timestamp("2024-01-01")], "D_sma200": [1.0],
                  "D_ema20_angle_deg": [1.0], "Comb_X": [1.0], "W_ret_13w": [1.0], "D_rsi14": [1.0]}).to_parquet(
        tmp / "panel.parquet")
    ch, sk = S.pick_features(tmp / "why.csv", 2, tmp / "panel.parquet")
    check("c1 feature picker: by importance, skipping raw levels (D_sma200), combined flags and absent features",
          ch == ["D_ema20_angle_deg", "W_ret_13w"] and [x[0] for x in sk] == ["D_sma200", "Comb_X", "D_missing"],
          (ch, sk))
    book, _, _ = make_world("R", n_days=300, seed=21)
    import io
    from contextlib import redirect_stdout
    with redirect_stdout(io.StringIO()):
        v1, _ = S.cmd_run(book, tmp / "run", log=lambda *a: None, with_confluence=True)
    X = pd.read_csv(tmp / "run" / "confluence.csv")
    r = X[(X.setup == "x_change<0") & (X.confluence == "BEARSTATE") & (X.exit == "original_d5")] if \
        "x_change<0" in set(X.setup) else X.iloc[0:0]
    if r.empty:      # the pool names pairs only; the planted single x lives inside a pair with y
        r = X[X.setup.str.contains("x_change<0") & (X.confluence == "BEARSTATE") & (X.exit == "original_d5")]
    check("c2 confluence stage runs: NONE baselines, every context confluence, price x context pairs, 'adds' column",
          (X.setup == "NONE").any() and {"BEARSTATE", "DIP2&BEARSTATE", "MKT_BEARISH"} <= set(X.confluence) and
          X["adds_over_conf"].notna().any() and (tmp / "run" / "CONFLUENCE.md").is_file(), X.shape)
    check("c3 world R: a setup built on the planted feature adds over the confluence alone (BEARSTATE)",
          len(r) > 0 and (r.adds_lo > 0).all(), r[["setup", "adds_over_conf", "adds_lo", "adds_hi"]].to_dict("records")
          if len(r) else "no row")


def t_build():
    # b1: hand bars with a missing session and a pick near the data's end
    cal = pd.bdate_range("2024-01-01", periods=20)
    o = np.array([10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21], float)
    c = o + 0.5
    ci = np.array([0, 1, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12])          # session 3 missing for this stock
    W = S.watchlist_rows([{"trade_id": "D-X-1", "engine": "D", "rank": 4, "symbol": "Q", "signal_day": cal[1], "j": 1},
                          {"trade_id": "D-X-2", "engine": "D", "rank": 9, "symbol": "Q", "signal_day": cal[10], "j": 8}],
                         {"Q": (o, c, ci)}, cal.to_numpy()).set_index("trade_id")
    r = W.loc["D-X-1"]
    check("b1 build from own bars: entry = next bar's open, close_k / entry - 1, gaps, the entry day after a missing "
          "session, NaN past the data's end",
          r.entry == 12 and r.signal_close == 11.5 and abs(r.close_1 - (12.5 / 12 - 1)) < 1e-12 and
          abs(r.overnight_2 - (13 / 12.5 - 1)) < 1e-12 and r.entry_day == str(cal[2].date()) and
          W.loc["D-X-2", "entry_day"] == str(cal[10].date()) and np.isfinite(W.loc["D-X-2", "close_3"]) and
          np.isnan(W.loc["D-X-2", "close_4"]), W.T.to_dict())
    # b2: a world rebuilt through watchlist_rows replays identically (the build's format = the backtester's)
    book, W0, F = make_world("R", n_days=150, seed=31)
    P, bars = [], {}
    for i in range(book.n):
        sym = "Z%05d" % i
        oo = np.concatenate([[book.sc[i]], book.O[i, 1:]])
        cc = np.concatenate([[book.sc[i]], book.C[i, 1:]])
        bars[sym] = (oo, cc, book.i1[i] - 1 + np.arange(len(oo)))
        P.append({"trade_id": book.ids[i], "engine": "D", "rank": int(book.rank[i]), "symbol": sym,
                  "signal_day": book.signal_day[i], "j": 0})
    W1 = S.watchlist_rows(P, bars, book.cal)
    keep = W0.set_index("trade_id")[["status", "net_bp", "pre_state", "s_atr14", "symbol"]]
    W1 = W1.drop(columns="symbol").join(keep, on="trade_id")
    b2 = S.Book(W1, pd.Series(book.cal), F, "D")
    same = True
    for conds in ([("x_change", "<", 0)], S.control_setups()["DIP_2"], [("day", "<=", 1), ("day", ">=", 1)]):
        for m in S.EXITS:
            x, y = S.replay(book, conds, m), S.replay(b2, conds, m)
            same &= (x.status.values == y.status.values).all() and np.allclose(x.ret, y.ret, equal_nan=True,
                                                                                 atol=1e-9)
    check("b2 a watchlist rebuilt from bars replays identically (setups, dips, D1; both exits)", bool(same))
    # b3: ranks filter and the by-rank view
    bk = S.Book(W0, pd.Series(book.cal), F, "D", ranks=[1, 2])
    import tempfile, io
    from contextlib import redirect_stdout
    tmp = Path(tempfile.mkdtemp(prefix="sl_rank_"))
    with redirect_stdout(io.StringIO()):
        S.cmd_run(book, tmp, log=lambda *a: None)
    rk = pd.read_csv(tmp / "by_rank.csv") if (tmp / "by_rank.csv").is_file() else pd.DataFrame()
    check("b3 --ranks keeps only those ranks; the by-rank view has the 1-3 band and each rank",
          set(bk.rank) == {1, 2} and len(rk) > 0 and {"ranks 1-3", "rank 01", "rank 03"} <= set(rk.group),
          (set(bk.rank), sorted(set(rk.group)) if len(rk) else None))


def main():
    t0 = time.time()
    print("%s self-test" % S.VERSION)
    t_hand()
    t_space()
    t_worlds()
    t_confluence()
    t_build()
    print("%d checks, %d failed (%.0f s)" % (COUNT[0], len(FAILS), time.time() - t0))
    print("VERIFIED (%s)" % S.VERSION if not FAILS else "NOT VERIFIED")
    return 0 if not FAILS else 1


if __name__ == "__main__":
    sys.exit(main())
