# MANIFEST - setuplab v0.9 (8 Nov 2026: runners - which picks will NOT dip; on top of v0.8's frozen setups, zones and TradingView indicator)

Folder: C:\Users\karanvsi\PyCharmMiscProject\setuplab\ (tests in setuplab\tests\). v0.9 changes three files: setuplab.py, tests\test_setuplab.py, README_SETUPLAB.md (and this manifest); the others are v0.8's, unchanged. FROZEN_SETUPS.json is the freeze (never edit it: a changed copy is refused). Writes only under --out (C:\QuantData\setuplab). The scan, the zones and the runners read tradelab's readers (tradelab with the setups add-on on PYTHONPATH: env_tradelab.bat or env_playbook.bat); the self-test also reads production's features_daily.py (bigmove_deploy on PYTHONPATH). Python with numpy, pandas, pyarrow. BigMove_Setups.pine goes into TradingView's Pine Editor.

| file | sha256 (first 16) | bytes | lines | v0.9 |
|---|---|---|---|---|
| setuplab.py | bae7e2298deb6797 | 253401 | 4663 | changed: the runners command |
| FROZEN_SETUPS.json | bed8fd610cf686af | 24439 | 935 | unchanged |
| BigMove_Setups.pine | 1904f972378eb49c | 24113 | 588 | unchanged |
| features_final.txt | bcb6c16bdfd7513d | 1689 | 60 | unchanged |
| README_SETUPLAB.md | 7657990539def535 | 29074 | 357 | changed: the v0.9 section |
| tests\test_setuplab.py | 153e5223b701a601 | 89524 | 1426 | changed: r1-r7 |
| tests\pine_mirror.py | 326cb336f1c7e96c | 13337 | 337 | unchanged |

FROZEN_SETUPS.json's own sha256 (inside the file): 483f1539324f3ae5... (`python setuplab.py frozen` prints FROZEN FILE OK).

Verified where it was built: 71 self-test checks, 0 failed, with pandas 2.3.3 / numpy 2.4.1 (Karan's versions) and pandas 3.0.5 / numpy 2.5.3. v0.6's 38; v0.7's f1-f14; v0.8's z1-z6 and p1-p3; v0.9's r1-r7 (10 checks): the labels, the lift, the weighted AUC (= brute force), the four entries and the money sim by hand; a planted no-dip rule found alone, qualified in both engines and holding out of sample, an absent one not found, a fading one caught by the replay (NOT SHOWN); the runners command end to end after tag and zones with every pick's labels = its own bars by hand and a hash-checked candidates file; the zone values point in time. Planted bugs caught: v0.8 5 of 5; v0.9 8 of 8 (the dip window, the lift's yardstick, the replay's years, the breakout's fill, the slot timing, the earn-its-place test, the zone day, the bars' alignment). Runtime measured at Karan's scale (17,580 picks per engine, 60 features, 25,595 rules): about 4 minutes of computing. The Pine has not been compiled by TradingView.
