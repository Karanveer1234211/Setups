"""
setuplab.py - setuplab v0.9: entry setups for the engines' picks, compared trade by trade with the model's D1 entry.

v0.7 (8 Nov 2026) - the FROZEN setups (FROZEN_SETUPS.json beside this file; never written by the tool):
    python setuplab.py frozen                    check the freeze file (sha256) and list its setups
    python setuplab.py tag  --data <watchlist folder> --features <panel.parquet> --out C:\\QuantData\\setuplab
                            every past pick tagged: which frozen setups entered, on which watch day, both exits,
                            D1 on the same pick -> TAGS\\TAGS_<date>_<nnn> (reconciled against FINAL_001)
    python setuplab.py scan --root %CACHE_DAILY_ROOT% --out C:\\QuantData\\setuplab [--all-missing] [--date ...]
                            the nightly scan (tradelab's env): the last five sessions' picks of the paper ledger
                            against every frozen setup -> scan\\SCAN_<date>.md, scan_<date>.csv, tv_<date>.txt
                            (TradingView import) and the hash-chained, on-time setup_ledger.jsonl

v0.9 (8 Nov 2026) - runners: which picks will NOT dip (tradelab's env, read only):
    python setuplab.py runners --root %CACHE_DAILY_ROOT% --data <watchlist folder> --features <panel.parquet>
                            --out C:\\QuantData\\setuplab   -> RUNNERS\\RUNNERS_<date>_<nnn> (RUNNERS.md, the
                            candidates, what marks a runner, the entries, the replay, the money view)

    python setuplab.py run --data <folder with watchlist.parquet + calendar.parquet> --features <features.parquet>
                           --out <output folder> [--engine D] [--setups default|<setups.json>]
    python setuplab.py reproduce --data ... --features ... --ledgers <folder of delivered *.csv.gz>
    python setuplab.py --selftest

What it does (the rules of the ChatGPT backtester, backtest.pyz, re-implemented vectorised):
  * a setup = a list of conditions, ALL required, read at the open of watch day k (k = 1..5 after the pick):
      <feature>          the feature's value at the previous completed session (k-1; D0 = the signal day)
      <feature>_change   that value minus the session before (stored *_change column if the file has one)
      gap_pct            today's open vs the previous close, %
      pc_vs_d1           the previous close vs the D1 open, %          (known from D2 on; False on D1)
      pc_vs_d1_atr       the same in units of the pick's ATR14 at the signal (s_atr14)
      prev_intraday      the previous session's close vs its open, %   (D2 on)
      prev_ret           the previous session's close vs the close before, %  (D2 on)
      day                the watch day number (blind controls)
      weekday            the watch day's weekday, 0 = Monday (weekly features change on Mondays: their setups
                         can only fire on a Tuesday open - the TUE controls separate the feature from the weekday)
    numbers are rounded to 9 decimals before comparing; 0 does not pass > 0 or < 0
  * entry at the FIRST open whose conditions all hold; a False condition = not today; a missing value with no
    False = the trade is "Missing signal data" (as the original engine); no qualifying open = "No entry"
  * exits: original_d5 = the pick's D5 close; fresh = the close 4 sessions after the entry day (5 sessions held)
  * net % = exit / entry - 1 (in %) - 0.35 (cost)
  * the comparison is Karan's: each setup's OWN filled trades against the model's D1 entry (blind D1, same exit
    rule) on exactly those trade ids. 95% circular block bootstrap over signal days (10-day blocks, 2,000 draws).
    Under original_d5 both legs sell at the same D5 close, so the whole difference is the entry price; under
    fresh the exit moves with the entry, and "after-entry" = setup net minus the D1 trade held from the same
    entry-day open would be the same as the setup itself - so we report the entry discount beside the lift.
  * controls on the same ids: price-only dip entries and bounce markers (no indicators), to see whether a
    setup's conditions add anything beyond "buy after the price has come down"
"""
from __future__ import annotations

import argparse
import datetime as _dt
import hashlib
import itertools
import json
import re
import sys
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "setuplab v0.9"
WATCH = 5               # watch days D1..D5
PATH = 10               # sessions of path in the watchlist (close_1..close_10)
COST = 0.35
EXITS = ("original_d5", "fresh")
OPS = {">": np.greater, "<": np.less, ">=": np.greater_equal, "<=": np.less_equal}
PRICE_FIELDS = ("gap_pct", "pc_vs_d1", "pc_vs_d1_atr", "prev_intraday", "prev_ret", "day", "weekday")


# ---------------------------------------------------------------------------------------------------- data
class Book:
    """Engine D's picks with their D1..D10 opens / closes and every feature at the previous session of each watch
    day. Arrays are (trades, PATH + 1) with column k = watch day k (column 0 unused for prices)."""

    def __init__(self, wl: pd.DataFrame, cal: pd.Series, feats: pd.DataFrame | None, engine="D", feature_cols=None,
                 ranks=None):
        wl = wl[wl["engine"] == engine].copy() if engine and "engine" in wl.columns else wl.copy()
        self.engine = engine or "ALL"
        if ranks:
            wl = wl[wl["rank"].isin(ranks)]
        wl = wl.sort_values(["signal_day", "rank", "trade_id"]).reset_index(drop=True)
        self.wl = wl
        self.n = len(wl)
        self.ids = wl["trade_id"].astype(str).to_numpy()
        self.signal_day = pd.to_datetime(wl["signal_day"]).dt.normalize().to_numpy()
        self.ok = (wl["status"].astype(str) == "ok").to_numpy() & np.isfinite(wl["net_bp"].astype(float).to_numpy())
        cal = pd.to_datetime(pd.Series(cal)).dt.normalize().sort_values().drop_duplicates().reset_index(drop=True)
        self.cal = cal.to_numpy()
        pos = {d: i for i, d in enumerate(cal)}
        e1 = pd.to_datetime(wl["entry_day"]).dt.normalize()
        self.i1 = np.array([pos.get(d, -1) for d in e1], dtype=np.int64)
        if (self.i1 < 0).any():
            raise ValueError("%d entry days are not in the calendar" % int((self.i1 < 0).sum()))
        ent = wl["entry"].astype(float).to_numpy()
        sc = wl["signal_close"].astype(float).to_numpy()
        O = np.full((self.n, PATH + 1), np.nan)
        C = np.full((self.n, PATH + 1), np.nan)
        PC = np.full((self.n, PATH + 1), np.nan)
        for k in range(1, PATH + 1):
            C[:, k] = ent * (1 + wl["close_%d" % k].astype(float).to_numpy())
            PC[:, k] = sc if k == 1 else ent * (1 + wl["close_%d" % (k - 1)].astype(float).to_numpy())
            O[:, k] = ent if k == 1 else PC[:, k] * (1 + wl["overnight_%d" % k].astype(float).to_numpy())
        # a session past the calendar's end does not exist
        for k in range(1, PATH + 1):
            gone = self.i1 + k - 1 >= len(self.cal)
            O[gone, k] = C[gone, k] = PC[gone, k] = np.nan
        self.O, self.C, self.PC = O, C, PC
        self.sc, self.ent = sc, ent
        self.atr = wl["s_atr14"].astype(float).to_numpy() if "s_atr14" in wl.columns else np.full(self.n, np.nan)
        self.symbols = wl["symbol"].astype(str).str.strip().str.upper().to_numpy()
        self.state = wl["pre_state"].astype(str).to_numpy() if "pre_state" in wl.columns else np.array([""] * self.n)
        self.rank = wl["rank"].astype(int).to_numpy()
        self.engine_arr = wl["engine"].astype(str).to_numpy() if "engine" in wl.columns else \
            np.array([self.engine] * self.n)
        # year index and the two halves of the period (split at the median signal day of the settled picks)
        yrs = pd.DatetimeIndex(self.signal_day).year.to_numpy()
        self.yi = (yrs - yrs.min()) if self.n else yrs
        okd = self.signal_day[self.ok] if self.ok.any() else self.signal_day
        self.split_day = np.sort(okd)[len(okd) // 2] if len(okd) else None
        self.half = (self.signal_day > self.split_day).astype(int) if len(okd) else np.zeros(self.n, int)
        self.span_years = max(1e-9, (okd.max() - okd.min()) / np.timedelta64(365, "D")) if len(okd) else 1.0
        self.features = []
        self.F = {}
        if feats is not None:
            self._join(feats, feature_cols)

    PER_TRADE = ("ids", "signal_day", "ok", "i1", "O", "C", "PC", "sc", "ent", "atr", "symbols", "state", "rank",
                 "engine_arr", "yi", "half")

    def take(self, mask, engine=None):
        """The same book restricted to some picks (e.g. one engine); shares the split day and the span."""
        b = object.__new__(Book)
        b.__dict__.update({k: v for k, v in self.__dict__.items() if k != "_cache"})
        for k in self.PER_TRADE:
            setattr(b, k, getattr(self, k)[mask])
        b.F = {k: v[mask] for k, v in self.F.items()}
        b.wl = self.wl[mask].reset_index(drop=True)
        b.n = int(np.sum(mask))
        b.engine = engine or self.engine
        return b

    def attach(self, path, cols, chunk=8, log=lambda *a: None):
        """Read the feature columns from a big panel a few at a time, only the picks' stocks and only the dates the
        watch windows need (+ 120 days for the changes): memory stays small whatever the panel's size.
        Returns (attached, missing)."""
        import pyarrow.parquet as pq
        names = pq.read_schema(path).names
        low = {c.lower(): c for c in names}
        dk = low.get("timestamp") or low.get("date")
        if "symbol" not in low or not dk:
            raise ValueError("the feature file needs symbol and timestamp (or date) columns")
        want, miss = [], []
        for c in cols:
            (want if c.lower() in low else miss).append(c.lower())
        want = list(dict.fromkeys(want))
        syms = sorted(set(self.symbols))
        first = pd.Timestamp(self.cal[max(0, int(self.i1.min()) - 2)]) - pd.Timedelta(days=120) if self.n else None
        for i in range(0, len(want), chunk):
            part = want[i:i + chunk]
            rc = [low["symbol"], dk] + [low[c] for c in part] + [low[c + "_change"] for c in part
                                                                 if c + "_change" in low]
            F = None
            try:
                F = pq.read_table(path, columns=rc, filters=[(low["symbol"], "in", syms)]).to_pandas()
            except Exception:
                F = None
            if F is None or len(F) == 0:
                F = pd.read_parquet(path, columns=rc)
            self._join(F, part, append=True, min_date=first)
            del F
            log(" features: %d of %d attached" % (min(i + chunk, len(want)), len(want)))
        return want, miss

    def _join(self, feats, feature_cols, append=False, min_date=None):
        f = feats.copy()
        if any(n is not None for n in f.index.names):                 # symbol / date stored as the index
            f = f.reset_index()
        f.columns = [str(c).lower() for c in f.columns]
        dk = "timestamp" if "timestamp" in f.columns else "date"
        if "symbol" not in f.columns or dk not in f.columns:
            raise ValueError("the feature file needs symbol and timestamp (or date) columns")
        f["symbol"] = f["symbol"].astype(str).str.strip().str.upper()
        t = pd.to_datetime(f[dk])
        if t.dt.tz is not None:                                         # a zoned clock -> Indian dates, no zone
            t = t.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
        f[dk] = t.dt.normalize()
        base = [c for c in (feature_cols or f.columns) if c not in ("symbol", dk) and not c.endswith("_change")]
        f = f[f["symbol"].isin(set(self.symbols))]
        if min_date is not None:
            f = f[f[dk] >= min_date]
        if f.duplicated(["symbol", dk]).any():
            raise ValueError("duplicated symbol/date rows in the feature file")
        f = f.sort_values(["symbol", dk])
        for c in base:
            if c + "_change" not in f.columns:            # the change = this session minus the symbol's previous row
                f[c + "_change"] = f.groupby("symbol")[c].diff()
        cols = base + [c + "_change" for c in base]
        # previous-session date of each watch day k
        rows, ks, keys_s, keys_d = [], [], [], []
        for k in range(1, WATCH + 1):
            j = self.i1 + k - 2
            ok = (j >= 0) & (j < len(self.cal))
            rows.append(np.flatnonzero(ok))
            ks.append(np.full(ok.sum(), k))
            keys_s.append(self.symbols[ok])
            keys_d.append(self.cal[j[ok]])
        L = pd.DataFrame({"row": np.concatenate(rows), "k": np.concatenate(ks), "symbol": np.concatenate(keys_s),
                          dk: np.concatenate(keys_d)})
        M = L.merge(f[["symbol", dk] + cols], on=["symbol", dk], how="left")
        for c in cols:
            A = np.full((self.n, WATCH + 1), np.nan)
            A[M["row"].to_numpy(), M["k"].to_numpy()] = pd.to_numeric(M[c], errors="coerce").to_numpy(float)
            self.F[c] = A
        self.features = (list(self.features) if append else []) + [c for c in base if c not in
                                                                   (self.features if append else [])]

    def field(self, name):
        """(trades, WATCH + 1) values of a condition field at the open of each watch day (cached)."""
        if name in self.F:
            return self.F[name]
        cache = self.__dict__.setdefault("_cache", {})
        if name not in cache:
            cache[name] = self._field(name)
        return cache[name]

    def _field(self, name):
        A = np.full((self.n, WATCH + 1), np.nan)
        if name.startswith("snap:"):                  # the pick's snapshot at the signal close (watchlist pre_*)
            col = name[5:]
            if col not in self.wl.columns:
                raise KeyError("no column %s in the watchlist" % col)
            v = pd.to_numeric(self.wl[col], errors="coerce").astype(float).to_numpy()
            A[:, 1:] = v[:, None]
        elif name == "gap_pct":
            A[:, 1:] = (self.O[:, 1:WATCH + 1] / self.PC[:, 1:WATCH + 1] - 1) * 100
        elif name == "day":
            A[:, 1:] = np.arange(1, WATCH + 1)[None, :]
        elif name == "pc_vs_d1":
            A[:, 2:] = (self.C[:, 1:WATCH] / self.O[:, [1]] - 1) * 100
            A[:, 1] = 0.0                          # nothing to compare on D1: a dip test (< 0) is False there
        elif name == "weekday":
            for k in range(1, WATCH + 1):
                j = np.minimum(self.i1 + k - 1, len(self.cal) - 1)
                A[:, k] = pd.DatetimeIndex(self.cal[j]).weekday
        elif name == "pc_vs_d1_atr":
            A[:, 2:] = (self.C[:, 1:WATCH] / self.O[:, [1]] - 1) / self.atr[:, None]
            A[:, 1] = 0.0
        elif name == "prev_intraday":
            A[:, 2:] = (self.C[:, 1:WATCH] / self.O[:, 1:WATCH] - 1) * 100
            A[:, 1] = 0.0
        elif name == "prev_ret":
            prev = np.column_stack([self.sc, self.C[:, 1:WATCH]])
            A[:, 2:] = (self.C[:, 1:WATCH] / prev[:, :WATCH - 1] - 1) * 100
            A[:, 1] = 0.0
        else:
            raise KeyError("unknown field %s" % name)
        return A


# ---------------------------------------------------------------------------------------------------- replay
def trigger(book: Book, conds):
    """First watch day whose conditions all hold. Returns (day, status) arrays: day 0 = none.
    status: 'Filled' candidates (day > 0), 'No entry', 'Missing signal data'."""
    n = book.n
    day = np.zeros(n, dtype=np.int64)
    missing = np.zeros(n, dtype=bool)
    done = ~book.ok.copy()
    for k in range(1, WATCH + 1):
        sess = np.isfinite(book.O[:, k])
        newly_missing = ~done & ~sess                       # watch session unavailable
        missing |= newly_missing
        done |= newly_missing
        anyF = np.zeros(n, dtype=bool)
        anyN = np.zeros(n, dtype=bool)
        for fld, op, val in conds:
            a = book.field(fld)[:, k]
            nan = np.isnan(a)
            r = OPS[op](np.round(np.where(nan, 0, a), 9), round(float(val), 9))
            anyF |= ~nan & ~r
            anyN |= nan
        hit = ~done & ~anyF & ~anyN
        miss = ~done & ~anyF & anyN
        day[hit] = k
        missing |= miss
        done |= hit | miss
    status = np.where(~book.ok, "Unsettled",
                      np.where(missing, "Missing signal data", np.where(day > 0, "Filled", "No entry")))
    return day, status


def exits(book: Book, day, status, mode):
    a = exits_arr(book, day, status, mode)
    return pd.DataFrame({"trade_id": book.ids, "signal_day": book.signal_day, "pre_state": book.state,
                         "rank": book.rank, "status": a["st"], "day": a["day"], "price": a["price"], "exit_day": a["exit_day"],
                         "ret": a["ret"], "trade_dd": a["dd"]})


def exits_arr(book: Book, day, status, mode):
    """Vectorised exit: buy at the entry day's open, sell at the exit close; drawdown over entry + closes.
    Returns plain arrays (compact: thousands of setups can be compared without holding their tables)."""
    n = book.n
    st = status.copy()
    f = status == "Filled"
    k = np.where(f, day, 1)
    e = np.where(f, 5 if mode == "original_d5" else day + 4, 1)
    rows = np.arange(n)
    kk, ee = np.clip(k, 1, PATH), np.clip(e, 1, PATH)
    Ok = book.O[rows, kk]
    j = np.arange(1, PATH + 1)[None, :]
    win = (j >= kk[:, None]) & (j <= ee[:, None])
    Cw = book.C[:, 1:]
    bad = (win & ~np.isfinite(Cw)).any(1) | ~np.isfinite(Ok) | (e > PATH)
    ok = f & ~bad
    st[f & bad] = "Missing exit data"
    with np.errstate(invalid="ignore", divide="ignore"):
        peak = np.maximum(np.maximum.accumulate(np.where(win, Cw, -np.inf), axis=1), Ok[:, None])
        ddj = np.where(win, 100 * (1 - Cw / peak), -np.inf).max(1)
        dd = np.where(ok, np.maximum(ddj, 0.0), np.nan)
        ret = np.where(ok, (book.C[rows, ee] / Ok - 1) * 100 - COST, np.nan)
    return {"st": st, "f": ok, "day": np.where(day > 0, day, np.nan).astype(float),
            "price": np.where(ok, Ok, np.nan), "exit_day": np.where(ok, e, 0), "ret": ret, "dd": dd}


def replay2(book, conds):
    """Both exits from one trigger pass, as arrays."""
    d, s = trigger(book, conds)
    return {m: exits_arr(book, d, s, m) for m in EXITS}


def arr_of(df):
    st = df["status"].to_numpy()
    return {"st": st, "f": st == "Filled", "day": df["day"].to_numpy(float), "price": df["price"].to_numpy(float),
            "ret": df["ret"].to_numpy(float), "dd": df["trade_dd"].to_numpy(float)}


def coverage(a, ok):
    st = a["st"][ok]
    return {"eligible": int(ok.sum()), "filled": int((st == "Filled").sum()), "no_entry": int((st == "No entry").sum()),
            "missing": int(np.char.startswith(st.astype(str), "Missing").sum())}


def replay(book, conds, mode):
    d, s = trigger(book, conds)
    return exits(book, d, s, mode)


# ---------------------------------------------------------------------------------------------------- setups
RULES = {"A": [("d_bb_bw_20_change", ">", 0), ("w_ret_13w_change", "<", 0)],
         "B": [("d_ema20_angle_deg_change", "<", 0), ("w_ret_13w_change", "<", 0)],
         "C": [("d_ema20_angle_deg_change", "<", 0), ("d_wq_44_change", ">", 0)]}
CONF = {"none": [], "positive_open_gap": [("gap_pct", ">", 0)],
        "positive_EMA_slope": [("d_ema20_angle_deg", ">", 0)], "declining_minus_DI": [("d_mdi14_diff1", "<", 0)]}


def abc_setups():
    out = {}
    for r in range(1, 4):
        for sub in itertools.combinations("ABC", r):
            for cn, extra in CONF.items():
                conds = list(dict.fromkeys(sum([RULES[x] for x in sub], []) + extra))
                out["+".join(sub) + "__" + cn] = conds
    return out


def control_setups():
    out = {"Blind_D%d" % k: [("day", "<=", k), ("day", ">=", k)] for k in (1, 2, 3)}
    for x in (0, 1, 2, 3, 5):                                    # price-only dip: prior close X% under the D1 open
        out["DIP_%d" % x] = [("pc_vs_d1", "<", -x if x else 0)] if x else [("pc_vs_d1", "<", 0)]
    out["BOUNCE_green"] = [("pc_vs_d1", "<", 0), ("prev_intraday", ">", 0)]      # down from D1, then a green day
    out["BOUNCE_upclose"] = [("pc_vs_d1", "<", 0), ("prev_ret", ">", 0)]         # down from D1, then an up close
    out["BOUNCE_dip2_green"] = [("pc_vs_d1", "<", -2), ("prev_intraday", ">", 0)]
    out["TUE"] = [("weekday", ">=", 1), ("weekday", "<=", 1)]                      # the first Tuesday open
    out["TUE_DIP_2"] = [("weekday", ">=", 1), ("weekday", "<=", 1), ("pc_vs_d1", "<", -2)]
    for x in (0.5, 1.0, 1.5):                                    # the dip in the stock's own ATR units
        out["DIPATR_%g" % x] = [("pc_vs_d1_atr", "<", -x)]
    return out


def labels():
    """The six distinct A/B/C labels (A+B+C has exactly A+C's conditions: A+C implies B)."""
    out = {}
    for r in range(1, 4):
        for sub in itertools.combinations("ABC", r):
            conds = list(dict.fromkeys(sum([RULES[x] for x in sub], [])))
            if frozenset(conds) not in {frozenset(v) for v in out.values()}:
                out["+".join(sub)] = conds
    return out


DIPS = {"DIP_1": [("pc_vs_d1", "<", -1)], "DIP_2": [("pc_vs_d1", "<", -2)], "DIP_3": [("pc_vs_d1", "<", -3)],
        "DIPATR_1": [("pc_vs_d1_atr", "<", -1)]}


def combo_setups(have=lambda c: True):
    """EVERY A/B/C label with each price dip (v0.5, 7 Nov: v0.2-v0.4 paired dips with B and A+B only)."""
    out = {}
    for ln, lc in labels().items():
        if have(lc):
            for dn, dc in DIPS.items():
                out["%s&%s" % (ln, dn)] = lc + dc
    return out


def explore(book, v1, boot, log=print, di=None, d1=None):
    """What adds most on top of a price dip (7 Nov, exploratory, chosen after the first run - a hypothesis search,
    not a test): every single feature condition, the 10 best pairs of the space and B / A+B, each AND a 2% dip
    (and B / A+B AND a 1-ATR dip); each compared on the same trades with the dip alone and with D1."""
    st = {"DIP_2": [("pc_vs_d1", "<", -2)], "DIPATR_1": [("pc_vs_d1_atr", "<", -1)],
          "Blind_D1": [("day", "<=", 1), ("day", ">=", 1)]}
    dip = ("pc_vs_d1", "<", -2)
    for f in book.features:
        for kind in ("", "_change"):
            for op in (">", "<"):
                st["X1|%s%s%s0" % (f, kind, op)] = [(f + kind, op, 0), dip]
    sp = v1[(v1.exit == "original_d5") & v1.setup.str.startswith("S2|")].sort_values("lift_pp", ascending=False)
    space = space_setups(book.features)
    for nm in sp.setup.head(10):
        st["X2|" + nm[3:]] = space[nm] + [dip]
    if all(c[0] in book.F for c in RULES["A"] + RULES["B"]):
        ab = list(dict.fromkeys(RULES["A"] + RULES["B"]))
        st["XA|B&DIPATR_1"] = RULES["B"] + [("pc_vs_d1_atr", "<", -1)]
        st["XA|A+B&DIPATR_1"] = ab + [("pc_vs_d1_atr", "<", -1)]
    di = boot.index(book.signal_day) if di is None else di
    bases = {k: replay2(book, st[k]) for k in ("DIP_2", "DIPATR_1", "Blind_D1")}
    d1 = d1 or bases["Blind_D1"]
    rows, srows = [], []
    fam = {"X1": "feature+dip", "X2": "pair+dip", "XA": "label+dip"}
    for nm in st:
        if not nm.startswith("X"):
            continue
        base = "DIPATR_1" if "DIPATR" in nm else "DIP_2"
        R = replay2(book, st[nm])
        for mode in EXITS:
            r = paired_fast(R[mode], bases[base][mode], boot, di)
            r1 = paired_fast(R[mode], bases["Blind_D1"][mode], boot, di)
            if r and r1:
                rows.append({"setup": nm, "exit": mode, "vs": base, **r, "lift_vs_D1": r1["lift_pp"],
                             "lo_vs_D1": r1["lo"], "hi_vs_D1": r1["hi"]})
            q = stats(R[mode], d1[mode], boot, di, book, bases[base][mode])
            if q:
                srows.append({"family": fam[nm[:2]], "setup": nm, "conds": canon(st[nm]), "twin": base,
                              "twin_conds": canon(st[base]), "exit": mode, **q})
    X = pd.DataFrame(rows)
    log(" exploration: %d setups on top of a dip" % (len(st) - 3))
    return X, srows


# ---------------------------------------------------------------------------------------------------- confluences
# Declared 7 Nov 2026, 10:30 IST, BEFORE any confluence run. Price confluences read the path known at that open;
# context confluences read the pick's snapshot at the signal close (watchlist pre_* columns). Median splits use
# the picks' own snapshot values (no outcomes).
PRICE_CONF = {"DIP1": [("pc_vs_d1", "<", -1)], "DIP2": [("pc_vs_d1", "<", -2)], "DIP3": [("pc_vs_d1", "<", -3)],
              "DIPATR1": [("pc_vs_d1_atr", "<", -1)], "GREEN": [("prev_intraday", ">", 0)],
              "UPCLOSE": [("prev_ret", ">", 0)], "GAPDOWN": [("gap_pct", "<", 0)], "GAPUP": [("gap_pct", ">", 0)]}


def context_conf(book):
    med = lambda c: float(np.nanmedian(pd.to_numeric(book.wl[c], errors="coerce"))) if c in book.wl else np.nan
    out = {"BEARSTATE": [("snap:pre_state_bearish", ">", 0.5)], "BULLSTATE": [("snap:pre_state_bullish", ">", 0.5)],
           "NIFTY_ABOVE_MA50": [("snap:pre_nifty_vs_ma50", ">", 0)],
           "NIFTY_BELOW_MA50": [("snap:pre_nifty_vs_ma50", "<", 0)],
           "MKT_BULLISH": [("snap:pre_env_code", "<=", 1)], "MKT_BEARISH": [("snap:pre_env_code", ">=", 3)],
           "VIX_LOW": [("snap:pre_vix_pct250", "<", med("pre_vix_pct250"))],
           "VIX_HIGH": [("snap:pre_vix_pct250", ">=", med("pre_vix_pct250"))],
           "BREADTH_WEAK": [("snap:pre_ad_ratio_10", "<", med("pre_ad_ratio_10"))],
           "NOT_OVEREXT": [("snap:pre_state_overextended", "<", 0.5)],
           "VOL_ELEVATED": [("snap:pre_state_vol_elevated", ">", 0.5)],
           "TOP3": [("snap:rank", "<=", 3)]}                    # v0.6: the ranks traded today (declared 7 Nov 13:00)
    return {k: v for k, v in out.items() if all(f[5:] in book.wl.columns and np.isfinite(t) for f, _, t in v)
            and not (k == "TOP3" and len(set(book.rank)) < 2)}


def make_pool(book, v1s, pool_n=10):
    """The setups that meet the confluences: NONE (the confluence alone), every A/B/C label, and from EACH engine's
    pair space its top pool_n by lift over D1 and top pool_n by net per trade (n >= 300, interval above 0,
    original_d5) - the union, so every engine tests exactly the same combinations."""
    space = space_setups(book.features)
    pool = {"NONE": []}
    for ln, lc in labels().items():                       # every A/B/C label, equally (v0.5)
        if all(c[0] in book.F for c in lc):
            pool[ln] = lc
    for v1 in v1s:
        sp = v1[(v1.exit == "original_d5") & v1.setup.str.startswith("S2|") & (v1.n >= 300) & (v1.lo > 0)]
        for nm in list(sp.sort_values("lift_pp", ascending=False).setup.head(pool_n)) + \
                list(sp.sort_values("setup_net", ascending=False).setup.head(pool_n)):
            if nm in space and frozenset(space[nm]) not in {frozenset(v) for v in pool.values()}:
                pool.setdefault(nm[3:], space[nm])
    return pool


def confluence(book, v1, boot, out, log=print, pool_n=10, di=None, pool=None):
    """Setups x logical confluences. Pool: make_pool (shared across engines in a multi-engine run). Each setup x
    each confluence (single, or one price x one context), vs D1 and vs the confluence alone on the same trade ids."""
    pool = make_pool(book, [v1], pool_n) if pool is None else pool
    ctx = context_conf(book)
    confs = {**PRICE_CONF, **ctx}
    for a, b in itertools.product(PRICE_CONF, ctx):
        confs[a + "&" + b] = PRICE_CONF[a] + ctx[b]
    st = {"Blind_D1": [("day", "<=", 1), ("day", ">=", 1)]}
    for pn, pc in pool.items():
        for cn, cc in confs.items():
            st["%s || %s" % (pn, cn)] = list(dict.fromkeys(pc + cc))
    log(" confluence: %d setups x %d confluences = %d combinations" % (len(pool), len(confs), len(st) - 1))
    di = boot.index(book.signal_day) if di is None else di
    d1 = replay2(book, st["Blind_D1"])
    alone = {cn: replay2(book, st["NONE || " + cn]) for cn in confs}       # the confluences alone, kept
    # a context filter (the pick's snapshot) only chooses WHICH trades: test it as keeps-vs-drops on its parent
    # (the same setup and price confluence without the filter)
    pick_mask = {}
    for cx, cc in ctx.items():
        msk = np.ones(book.n, bool)
        for f, op, v in cc:
            a = book.field(f)[:, 1]
            msk &= np.isfinite(a) & OPS[op](np.round(np.where(np.isfinite(a), a, 0), 9), round(float(v), 9))
        pick_mask[cx] = msk
    parents = {}

    def parent_of(pn, cn):
        if cn in ctx:
            pc, cx = [], cn
        elif "&" in cn and cn.split("&", 1)[1] in ctx:
            pc, cx = PRICE_CONF[cn.split("&", 1)[0]], cn.split("&", 1)[1]
        else:
            return None, None
        conds = list(dict.fromkeys(pool[pn] + pc)) or D1_CONDS
        k = canon(conds)
        if k not in parents:
            parents[k] = replay2(book, conds)
        return parents[k], cx
    rows, srows = [], []
    t0 = time.time()
    for i, name in enumerate(st):
        if name == "Blind_D1":
            continue
        pn, cn = name.split(" || ")
        R = alone[cn] if pn == "NONE" else replay2(book, st[name])
        for mode in EXITS:
            r = stats(R[mode], d1[mode], boot, di, book, None if pn == "NONE" else alone[cn][mode])
            if not r:
                continue
            par, cx = parent_of(pn, cn)
            if par is not None:
                pa = par[mode]
                keep = pa["f"] & pick_mask[cx]
                drop = pa["f"] & ~pick_mask[cx]
                if keep.sum() > 1 and drop.sum() > 1:
                    lo95, hi95, sd = boot.ci_diff(di[keep], pa["ret"][keep], di[drop], pa["ret"][drop])
                    r.update({"filter_gain": float(pa["ret"][keep].mean() - pa["ret"][drop].mean()),
                              "filter_lo": lo95, "filter_hi": hi95, "filter_sd": sd, "filter_kept": int(keep.sum()),
                              "filter_dropped": int(drop.sum())})
            row = {"setup": pn, "confluence": cn, "exit": mode, **r}
            if "adds" in r:
                row.update({"adds_over_conf": r["adds"]})
            rows.append(row)
            srows.append({"family": "confluence-alone" if pn == "NONE" else "confluence", "setup": name,
                          "conds": canon(st[name]), "twin": "" if pn == "NONE" else "NONE || " + cn,
                          "twin_conds": "" if pn == "NONE" else canon(st["NONE || " + cn]), "exit": mode, **r})
        if (i + 1) % 500 == 0:
            log(" confluence: %d of %d (%.0f s)" % (i + 1, len(st) - 1, time.time() - t0))
    X = pd.DataFrame(rows)
    SR = pd.DataFrame(srows)
    if "filter_gain" in X:
        # every filter test of the run counts: one-sided p from the bootstrap, Benjamini-Hochberg q over all of them
        X["filter_p"] = filter_p(X["filter_gain"], X["filter_sd"])
        X["filter_q"] = bh_q(X["filter_p"])
        SR["filter_p"], SR["filter_q"] = X["filter_p"].to_numpy(), X["filter_q"].to_numpy()
        m = X["filter_p"].notna()
        log(" confluence: %d context-filter tests; %d keep clearly better trades (false discovery rate %.0f%%)" % (
            int(m.sum()), int((X["filter_q"] <= LB_FDR).sum()), 100 * LB_FDR))
    X.to_csv(out / "confluence.csv", index=False)
    L = ["# setuplab - setups x logical confluences (%s) - engine %s, ranks %d-%d, %d picks" % (
        VERSION, book.engine, min(book.rank), max(book.rank), book.n), "",
         "Pool: %s." % ", ".join(pool), "",
         "Confluences (declared before the run): price %s; context %s; and every price x context pair." % (
             ", ".join(PRICE_CONF), ", ".join(ctx)), "",
         "Each row: the combination's own trades vs the model's D1 entry on the same ids; 'adds' = the same "
         "combination vs the confluence ALONE on the same ids (what the indicator setup adds); years = signal years "
         "with net per trade above 0. Net %% after 0.35 pp; 95%% block bootstrap over signal days. Exploratory: "
         "%d combinations on the history the setups came from - expect some to look good by chance." % (len(st) - 1),
         ""]
    for mode in EXITS:
        m = X[(X.exit == mode) & (X.n >= 150)]
        best = m[(m.setup != "NONE") & (m.lo > 0)].sort_values("setup_net", ascending=False).head(25)
        L += ["## %s exit - top 25 combinations by net per trade (n >= 150, lift over D1 interval above 0)" % mode,
              "", "| setup | confluence | n | net | D1 | lift over D1 [95%] | adds over the confluence alone [95%] "
              "| years net > 0 |", "|---|---|---:|---:|---:|---|---|---:|"]
        for _, r in best.iterrows():
            L.append("| %s | %s | %d | %+.4f | %+.4f | %+.4f [%+.4f, %+.4f] | %s | %d/%d |" % (
                r.setup, r.confluence, r.n, r.setup_net, r.control_net, r.lift_pp, r.lo, r.hi,
                ("%+.4f [%+.4f, %+.4f]" % (r.adds_over_conf, r.adds_lo, r.adds_hi)) if pd.notna(
                    r.get("adds_over_conf")) else "-", r.years_net_pos, r.years))
        base = m[m.setup == "NONE"].sort_values("setup_net", ascending=False).head(15)
        L += ["", "### The confluences ALONE (no indicator setup) - top 15 by net per trade (n >= 150)", "",
              "| confluence | n | net | D1 | lift over D1 [95%] | years net > 0 |", "|---|---:|---:|---:|---|---:|"]
        for _, r in base.iterrows():
            L.append("| %s | %d | %+.4f | %+.4f | %+.4f [%+.4f, %+.4f] | %d/%d |" % (
                r.confluence, r.n, r.setup_net, r.control_net, r.lift_pp, r.lo, r.hi, r.years_net_pos, r.years))
        L.append("")
    (out / "CONFLUENCE.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    SR.to_csv(out / "setups_confluence.csv", index=False)
    (out / "confluence.done").write_text(time.strftime("%Y-%m-%d %H:%M:%S") + "\n", encoding="utf-8")
    log(" confluence: wrote CONFLUENCE.md, confluence.csv, setups_confluence.csv")
    return X


def filter_p(gain, sd):
    """One-sided p-value of 'the filter keeps better trades than it drops' (normal approximation, bootstrap sd)."""
    g, s_ = np.asarray(gain, float), np.asarray(sd, float)
    with np.errstate(invalid="ignore", divide="ignore"):
        z = np.where(s_ > 0, g / s_, np.nan)
    return np.array([0.5 * math.erfc(v / math.sqrt(2)) if np.isfinite(v) else np.nan for v in z])


def bh_q(p):
    """Benjamini-Hochberg q-values (the false discovery rate at which each test would pass)."""
    p = np.asarray(p, float)
    q = np.full(p.shape, np.nan)
    ok = np.isfinite(p)
    m = int(ok.sum())
    if m:
        o = np.argsort(p[ok])
        r = p[ok][o] * m / np.arange(1, m + 1)
        r = np.minimum(np.minimum.accumulate(r[::-1])[::-1], 1.0)
        qq = np.empty(m)
        qq[o] = r
        q[ok] = qq
    return q


def space_setups(features):
    """Every single-feature change direction and every pair of change directions (the A/B/C family)."""
    out = {}
    for f in features:
        for op in (">", "<"):
            out["S1|%s_change%s0" % (f, op)] = [(f + "_change", op, 0)]
    for f, g in itertools.combinations(features, 2):
        for a, b in itertools.product((">", "<"), repeat=2):
            out["S2|%s_change%s0&%s_change%s0" % (f, a, g, b)] = [(f + "_change", a, 0), (g + "_change", b, 0)]
    return out


# ---------------------------------------------------------------------------------------------------- statistics
class Boot:
    """Circular block bootstrap over signal days, shared index draws so every comparison uses the same resamples."""

    def __init__(self, days, B=2000, block=10, seed=7):
        self.days = np.sort(np.unique(days))
        self.pos = {d: i for i, d in enumerate(self.days)}
        n = len(self.days)
        rng = np.random.default_rng(seed)
        nb = int(np.ceil(n / block))
        st = rng.integers(0, n, size=(B, nb))
        self.ix = ((st[:, :, None] + np.arange(block)[None, None, :]) % n).reshape(B, -1)[:, :n]
        # M[b, d] = how often day d is in resample b: a resample's sum = M @ per-day sums (same draws, faster)
        flat = (np.arange(B)[:, None] * n + self.ix).ravel()
        self.M = np.bincount(flat, minlength=B * n).reshape(B, n).astype(float)

    def ci(self, days, vals):
        return self.ci_idx(np.array([self.pos[d] for d in days]), vals)

    def index(self, days):
        return np.array([self.pos.get(d, -1) for d in days])

    def ci_diff(self, da, va, db, vb):
        """mean(va) - mean(vb), both groups resampled with the same days (dependence kept): the 95% percentile
        interval and the bootstrap standard deviation (for a widened interval)."""
        n = len(self.days)
        X = self.M @ np.column_stack([np.bincount(da, weights=va, minlength=n), np.bincount(da, minlength=n),
                                      np.bincount(db, weights=vb, minlength=n), np.bincount(db, minlength=n)])
        with np.errstate(invalid="ignore", divide="ignore"):
            d = X[:, 0] / np.where(X[:, 1] > 0, X[:, 1], np.nan) - X[:, 2] / np.where(X[:, 3] > 0, X[:, 3], np.nan)
        return float(np.nanpercentile(d, 2.5)), float(np.nanpercentile(d, 97.5)), float(np.nanstd(d))

    def ci_idx(self, di, vals):
        s = np.bincount(di, weights=vals, minlength=len(self.days))
        c = np.bincount(di, minlength=len(self.days)).astype(float)
        S, Cn = self.M @ s, self.M @ c
        m = S / np.where(Cn > 0, Cn, np.nan)
        return float(np.nanpercentile(m, 2.5)), float(np.nanpercentile(m, 97.5))


def paired(a: pd.DataFrame, b: pd.DataFrame, boot: Boot):
    """a's filled trades vs b's on exactly the ids both filled (a = setup, b = control)."""
    A = a[a.status == "Filled"].set_index("trade_id")
    Bf = b[b.status == "Filled"].set_index("trade_id")
    ids = A.index.intersection(Bf.index)
    if len(ids) == 0:
        return None
    x, y = A.loc[ids], Bf.loc[ids]
    lift = x["ret"].to_numpy() - y["ret"].to_numpy()
    lo, hi = boot.ci(x["signal_day"].to_numpy(), lift) if len(ids) > 1 else (np.nan, np.nan)
    disc = (y["price"].to_numpy() / x["price"].to_numpy() - 1) * 100     # % the setup bought under the control
    return {"n": len(ids), "control_net": float(y["ret"].mean()), "setup_net": float(x["ret"].mean()),
            "lift_pp": float(lift.mean()), "lo": lo, "hi": hi, "setup_better_pct": float(100 * (lift > 0).mean()),
            "entry_cheaper_pct": float(np.mean(disc)), "setup_dd": float(x["trade_dd"].mean()),
            "control_dd": float(y["trade_dd"].mean()), "setup_p5": float(np.percentile(x["ret"], 5)),
            "control_p5": float(np.percentile(y["ret"], 5)),
            "mean_entry_day": float(x["day"].mean())}


def paired_fast(a, b, boot, di):
    """paired() on aligned arrays from the same book (same numbers; no tables)."""
    m = a["f"] & b["f"]
    n = int(m.sum())
    if n == 0:
        return None
    x, y = a["ret"][m], b["ret"][m]
    lift = x - y
    lo, hi = boot.ci_idx(di[m], lift) if n > 1 else (np.nan, np.nan)
    disc = (b["price"][m] / a["price"][m] - 1) * 100
    return {"n": n, "control_net": float(np.mean(y)), "setup_net": float(np.mean(x)), "lift_pp": float(lift.mean()),
            "lo": lo, "hi": hi, "setup_better_pct": float(100 * (lift > 0).mean()),
            "entry_cheaper_pct": float(np.mean(disc)), "setup_dd": float(np.mean(a["dd"][m])),
            "control_dd": float(np.mean(b["dd"][m])), "setup_p5": float(np.percentile(x, 5)),
            "control_p5": float(np.percentile(y, 5)), "mean_entry_day": float(np.mean(a["day"][m]))}


def stats(a, base, boot, di, book, twin=None):
    """Everything the comparison and the leaderboard need for one setup and one exit, on aligned arrays:
    the setup's own filled trades vs D1 (base) on the same ids - n, net and its 95% interval, the lift and its
    interval, years with net > 0, the two halves of the period, coverage; and, when the setup has an
    indicator-free twin (the same dip / confluence without the indicator conditions), what the indicators add."""
    m = a["f"] & base["f"]
    n = int(m.sum())
    if n == 0:
        return None
    x, y = a["ret"][m], base["ret"][m]
    lift = x - y
    lo, hi = boot.ci_idx(di[m], lift) if n > 1 else (np.nan, np.nan)
    nlo, nhi = boot.ci_idx(di[m], x) if n > 1 else (np.nan, np.nan)
    disc = (base["price"][m] / a["price"][m] - 1) * 100
    r = {"n": n, "control_net": float(np.mean(y)), "setup_net": float(np.mean(x)), "lift_pp": float(lift.mean()),
         "lo": lo, "hi": hi, "net_lo": nlo, "net_hi": nhi, "setup_better_pct": float(100 * (lift > 0).mean()),
         "entry_cheaper_pct": float(np.mean(disc)), "setup_dd": float(np.mean(a["dd"][m])),
         "control_dd": float(np.mean(base["dd"][m])), "setup_p5": float(np.percentile(x, 5)),
         "control_p5": float(np.percentile(y, 5)), "mean_entry_day": float(np.mean(a["day"][m]))}
    ys = book.yi[m]
    sm, ct = np.bincount(ys, weights=x), np.bincount(ys)
    r["years_net_pos"] = int(((ct > 0) & (sm > 0)).sum())
    r["years"] = int((ct > 0).sum())
    for h in (0, 1):
        hm = book.half[m] == h
        r["half%d_n" % (h + 1)] = int(hm.sum())
        r["half%d_net" % (h + 1)] = float(x[hm].mean()) if hm.any() else np.nan
    r.update(coverage(a, book.ok))
    r["fill_pct"] = 100.0 * r["filled"] / max(1, r["eligible"])
    r["trades_per_year"] = n / book.span_years
    if twin is not None:
        m2 = a["f"] & twin["f"]
        n2 = int(m2.sum())
        if n2:
            d = a["ret"][m2] - twin["ret"][m2]
            alo, ahi = boot.ci_idx(di[m2], d) if n2 > 1 else (np.nan, np.nan)
            r.update({"adds": float(d.mean()), "adds_lo": alo, "adds_hi": ahi, "adds_n": n2,
                      "twin_net": float(np.mean(twin["ret"][m2]))})
    return r


def canon(conds):
    """A setup's identity: its conditions, sorted (the same rule found by two routes counts once)."""
    return json.dumps(sorted([[f, op, float(v)] for f, op, v in dict.fromkeys(conds)]))


def uncanon(text):
    return [(f, op, v) for f, op, v in json.loads(text)]


# ---------------------------------------------------------------------------------------------------- build
def watchlist_rows(picks, bars, cal_days):
    """The watchlist (ChatGPT's format) from each stock's own daily bars.
    picks: rows with trade_id, engine, rank, symbol, signal_day, j (the signal bar's index in the stock's own bars);
    bars: symbol -> (o, c, cal_index of each own bar); cal_days: the session calendar.
    entry = the next own bar's open (D1); close_k = own bar j+k's close / entry - 1; overnight_k (k >= 2) = own bar
    j+k's open / own bar j+k-1's close - 1; missing bars past the data's end are NaN."""
    out = []
    for p in picks:
        o, c, ci = bars[p["symbol"]]
        j = int(p["j"])
        n = len(c)
        if j + 1 >= n:
            continue
        ent, sc = float(o[j + 1]), float(c[j])
        row = {"trade_id": p["trade_id"], "engine": p["engine"], "rank": int(p["rank"]), "symbol": p["symbol"],
               "signal_day": pd.Timestamp(p["signal_day"]), "entry_day": str(pd.Timestamp(cal_days[ci[j + 1]]).date()),
               "signal_close": sc, "entry": ent}
        for k in range(1, PATH + 1):
            row["close_%d" % k] = float(c[j + k]) / ent - 1 if j + k < n else np.nan
            row["overnight_%d" % k] = (0.0 if k == 1 else (float(o[j + k]) / float(c[j + k - 1]) - 1)
                                       if j + k < n else np.nan)
        out.append(row)
    return pd.DataFrame(out)


def check_watchlists(W, ref_path):
    """The built watchlist vs ChatGPT's (ranks 1-3): entry, signal close, the ten closes and gaps."""
    C = pd.read_parquet(ref_path)
    C["trade_id"] = C["trade_id"].astype(str)
    W = W.copy()
    W["trade_id"] = W["trade_id"].astype(str)
    M = W.merge(C, on="trade_id", suffixes=("", "_ref"))
    cols = ["entry", "signal_close"] + ["close_%d" % k for k in range(1, PATH + 1)] + \
           ["overnight_%d" % k for k in range(2, PATH + 1)]
    cols = [c for c in cols if c in M and c + "_ref" in M]
    diff = np.column_stack([(M[c].astype(float) - M[c + "_ref"].astype(float)).abs().to_numpy() for c in cols]) \
        if cols and len(M) else np.zeros((0, 1))
    same = np.all(np.isnan(diff) | (diff < 1e-6), axis=1) if len(M) else np.zeros(0, bool)
    verdict = "MATCHED" if len(M) and same.mean() >= 0.995 else "DIFFERS"
    text = ("check vs %s: %d of its %d picks are in this watchlist, %d identical on entry / closes / gaps (%.2f%%), "
            "largest difference %.2e -> %s" % (Path(ref_path).name, len(M), len(C), int(same.sum()),
                                                100 * same.mean() if len(M) else 0,
                                                np.nanmax(diff) if diff.size and len(M) else np.nan, verdict))
    return {"common": int(len(M)), "reference": int(len(C)), "identical": int(same.sum()), "verdict": verdict,
            "text": text}


def cmd_build(a, log=print):
    """picks (pick_meta, any ranks) + each stock's bars (the daily cache, through playbook's reader = v2engine's
    adapter, READ ONLY) + the context (tradelab's export trades.parquet: status, net_bp, s_atr14, pre_*)."""
    try:
        import playbook as PB
    except ImportError:
        print("REFUSED: playbook is not importable - run  call ...\\playbook\\env_playbook.bat  first")
        return 3
    ex = Path(a.export)
    if not (ex / "trades.parquet").is_file():
        print("REFUSED: no trades.parquet in %s" % ex)
        return 3
    T = pd.read_parquet(ex / "trades.parquet")
    T["trade_id"] = T["trade_id"].astype(str)
    ranks = a.ranks_list or list(range(1, 11))
    engines = [e.strip() for e in a.engines.split(",") if e.strip()]
    d_from = str(pd.to_datetime(T["signal_day"]).min().date())
    d_to = a.to or str(pd.to_datetime(T["signal_day"]).max().date())
    log("%s build: engines %s, ranks %s, signal days %s .. %s" % (VERSION, engines, ranks, d_from, d_to))
    picks, own, data = PB.load(a.root, a.pm_run, engines, ranks, d_from, d_to, log=log,
                               stage_e_any=a.stage_e_any, costs=a.costs)
    cal_days = np.asarray(data.cal.days)
    bars = {s: (ob.o, ob.c, idx) for s, (idx, ob) in own.items()}
    P = [{"trade_id": p.id, "engine": p.engine, "rank": p.rank, "symbol": p.symbol, "signal_day": p.T, "j": p.t_own}
         for p in picks]
    W = watchlist_rows(P, bars, cal_days)
    keep = [c for c in T.columns if c.startswith("pre_") or c in ("status", "net_bp", "s_atr14", "entry", "score",
                                                                    "open6_status", "open6_net_bp")]
    W = W.merge(T[["trade_id"] + keep].rename(columns={"entry": "export_entry"}), on="trade_id", how="left")
    W["status"] = W["status"].fillna("not in the export")
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    W.to_parquet(out / "watchlist.parquet", index=False)
    first = W["signal_day"].min() - pd.Timedelta(days=10)
    pd.DataFrame({"date": pd.to_datetime(cal_days[cal_days >= np.datetime64(first)])}).to_parquet(
        out / "calendar.parquet", index=False)
    d = (W["entry"] / W["export_entry"] - 1).abs()
    log(" %d picks (%s); entry vs the export's recorded entry: %d of %d within 1e-6, largest difference %.2e" % (
        len(W), ", ".join("%s %d" % kv for kv in W.groupby("engine").size().items()), int((d < 1e-6).sum()),
        int(d.notna().sum()), float(d.max()) if d.notna().any() else np.nan))
    if a.check:
        res = check_watchlists(W, a.check)
        log(" " + res["text"])
        print("BUILD CHECK " + res["verdict"])
    log(" wrote %s" % out)
    return 0


# ---------------------------------------------------------------------------------------------------- commands
RAW_LEVEL = re.compile(r"^d_(sma|ema)\d+$|^d_atr(14|30)$|^d_cpr_(pivot|bc|tc)$|^d_(support|resistance)\d+$|vpoc|"
                       r"^d_breakout_(high|low)_\d+$|^d_obv$|macd|midpoint_slope|dollar_vol$|_code$|_trend$|"
                       r"^d_dow$|^comb_|prev_inside_day|ema_stack|^label_|(^|_)(open|high|low|close|vwap)$")


def pick_features(why_csv, top, panel, engine="D"):
    """The engine's top features by the WHY surrogate's importance (why_features.csv), skipping raw price levels /
    price-scaled values, categorical codes, the day of week, combined flags and anything not in the panel.
    Returns (chosen, skipped-with-reason)."""
    import pyarrow.parquet as pq
    W = pd.read_csv(why_csv)
    if "engine" in W.columns:
        W = W[W["engine"] == engine]
    W = W.sort_values("importance", ascending=False)
    have = {c.lower() for c in pq.read_schema(panel).names}
    chosen, skipped = [], []
    for f in W["feature"].astype(str):
        if len(chosen) >= top:
            break
        lf = f.lower()
        if RAW_LEVEL.search(lf):
            skipped.append((f, "raw level / code / flag"))
        elif lf not in have:
            skipped.append((f, "not in the panel"))
        else:
            chosen.append(f)
    return chosen, skipped


REQUIRED = ("d_ema20_angle_deg", "w_ret_13w", "d_bb_bw_20", "d_wq_44", "d_mdi14_diff1")   # A/B/C + confirmations


def read_columns_file(path):
    """One feature name per line; '#' starts a comment."""
    out = []
    for ln in Path(path).read_text(encoding="utf-8").splitlines():
        ln = ln.split("#", 1)[0].strip()
        if ln:
            out.append(ln)
    return list(dict.fromkeys(out))


def load(data, features, engine="D", feature_cols=None, ranks=None, log=lambda *a: None, chunk=8):
    """engine None = every engine in the watchlist (split later with Book.take). feature_cols: read only these
    columns, a few at a time (the big panel); a missing column is skipped and listed, except the A/B/C ones."""
    wl = pd.read_parquet(Path(data) / "watchlist.parquet")
    cal = pd.read_parquet(Path(data) / "calendar.parquet")["date"]
    if features and feature_cols:
        book = Book(wl, cal, None, engine, None, ranks)
        want, miss = book.attach(features, feature_cols, chunk, log)
        book.missing_features = miss
        need = [c for c in REQUIRED if c in [x.lower() for x in feature_cols] and c not in book.features]
        if need:
            raise ValueError("the A/B/C features are not in the feature file: " + ", ".join(need))
        if not book.features:
            raise ValueError("none of the feature columns is in the feature file")
        return book
    F = pd.read_parquet(features) if features else None
    book = Book(wl, cal, F, engine, feature_cols, ranks)
    book.missing_features = []
    return book


def cmd_reproduce(book, ledgers):
    setups = {**abc_setups(), "Blind_D1": [("day", "<=", 1), ("day", ">=", 1)],
              "Blind_D3": [("day", "<=", 3), ("day", ">=", 3)]}
    worst = 0.0
    bad = []
    n = 0
    for name, conds in setups.items():
        for mode in EXITS:
            fn = Path(ledgers) / (("%s__%s.csv.gz" % (name, mode)) if not name.startswith("Blind")
                                  else ("%s_%s.csv.gz" % (name, mode)))
            if not fn.is_file():
                bad.append((name, mode, "no ledger"))
                continue
            L = pd.read_csv(fn).set_index("trade_id")
            R = replay(book, conds, mode).set_index("trade_id")
            ids = L.index.intersection(R.index)
            st_ok = (L.loc[ids, "status"].astype(str) == R.loc[ids, "status"].astype(str))
            f = ids[(L.loc[ids, "status"] == "Filled").to_numpy()]
            dret = np.abs(L.loc[f, "ret"].to_numpy(float) - R.loc[f, "ret"].to_numpy(float))
            dday = (L.loc[f, "day"].to_numpy(float) != R.loc[f, "day"].to_numpy(float)).sum()
            w = float(np.nanmax(dret)) if len(dret) else 0.0
            worst = max(worst, w)
            n += 1
            if (~st_ok).sum() or dday or w > 1e-6 or len(ids) != len(L):
                bad.append((name, mode, "status %d, day %d, ret %.2e, ids %d/%d" % (int((~st_ok).sum()), int(dday), w,
                                                                                  len(ids), len(L))))
    return n, bad, worst


def run_all(book, setups, boot):
    led = {}
    for name, conds in setups.items():
        for mode in EXITS:
            led[(name, mode)] = replay(book, conds, mode)
    return led


def compare(led, names, controls, boot):
    rows = []
    for name in names:
        for mode in EXITS:
            for ctl in controls:
                if ctl == name:
                    continue
                r = paired(led[(name, mode)], led[(ctl, mode)], boot)
                if r:
                    rows.append({"setup": name, "exit": mode, "control": ctl, **r})
    return pd.DataFrame(rows)


def family_twin(name):
    """The family of a setup of the small set and its indicator-free twin (None when it has none)."""
    if name.startswith("Blind_"):
        return "control", None
    if name in control_setups():
        return "price-only", None
    if "&" in name and name.split("&", 1)[1] in DIPS:
        return "label+dip", name.split("&", 1)[1]
    return ("label", None) if name.endswith("__none") else ("label+confirmation", None)


def stage1(book, out, log=print):
    """Every setup except the confluences: controls, A/B/C labels (+ confirmations, + dips), the pair space, the
    dip exploration. Writes the report files and setups_stage1.csv (one row per setup and exit, for the
    leaderboard). Returns v1, v2, the rows, the bootstrap and the day index."""
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    have = lambda conds: all(f in book.F or f in PRICE_FIELDS for f, _, _ in conds)
    abc = {k: v for k, v in abc_setups().items() if have(v)}       # A/B/C only when their features are loaded
    ctl = control_setups()
    space = space_setups(book.features)
    combo = combo_setups(have)
    setups = {**ctl, **abc, **combo}
    log("%s: engine %s, %d trades, %d setups (%d A/B/C, %d controls, %d combos, %d feature-space), 2 exits" % (
        VERSION, book.engine, book.n, len(setups) + len(space), len(abc), len(ctl), len(combo), len(space)))
    led = run_all(book, setups, None)
    boot = Boot(book.signal_day[book.ok])
    di = boot.index(book.signal_day)
    arrs = {k: {m: arr_of(led[(k, m)]) for m in EXITS} for k in setups}
    d1 = arrs["Blind_D1"]
    v1rows, srows = [], []

    def add(name, family, conds, R, twin=None):
        for m in EXITS:
            r = stats(R[m], d1[m], boot, di, book, arrs[twin][m] if twin else None)
            if r:
                v1rows.append({"setup": name, "exit": m, "control": "Blind_D1", **r})
                srows.append({"family": family, "setup": name, "conds": canon(conds), "twin": twin or "",
                              "twin_conds": canon(setups[twin]) if twin else "", "exit": m, **r})
    # 1. every setup vs the model's D1 entry on its own trades (the pair space streamed: compared, then dropped)
    for k, c in setups.items():
        fam, tw = family_twin(k)
        add(k, fam, c, arrs[k], tw)
    for i, (name, conds) in enumerate(space.items()):
        add(name, "single" if name.startswith("S1|") else "pair", conds, replay2(book, conds))
        if (i + 1) % 1000 == 0:
            log(" pair space: %d of %d (%.0f s)" % (i + 1, len(space), time.time() - t0))
    v1 = pd.DataFrame(v1rows)
    log(" replayed in %.0f s" % (time.time() - t0))
    # 2. A/B/C and the combos vs the price-only controls on the same trades
    keys = [k for k in abc if k.endswith("__none")] + list(combo)
    v2 = compare(led, keys, [c for c in ctl if c != "Blind_D1"], boot)
    # by signal year: the key setups vs D1 and vs the 2% dip on the same trades
    yrs = []
    key_names = [k + "__none" for k in labels() if k + "__none" in abc] + [k for k in combo if k.endswith("&DIP_2")]
    for name in key_names:
        for mode in EXITS:
            a = led[(name, mode)]
            a = a[a.status == "Filled"].set_index("trade_id")
            for c in ("Blind_D1", "DIP_2"):
                b = led[(c, mode)]
                b = b[b.status == "Filled"].set_index("trade_id")
                ids = a.index.intersection(b.index)
                z = pd.DataFrame({"year": pd.to_datetime(a.loc[ids, "signal_day"]).dt.year,
                                  "setup": a.loc[ids, "ret"], "lift": a.loc[ids, "ret"] - b.loc[ids, "ret"]})
                for y, g in z.groupby("year"):
                    yrs.append({"setup": name, "exit": mode, "control": c, "year": y, "n": len(g),
                                "setup_net": g.setup.mean(), "lift_pp": g.lift.mean()})
    yrs = pd.DataFrame(yrs)
    yrs.to_csv(out / "by_year.csv", index=False)
    sts = by_state(led, key_names + ["DIP_2"], boot)
    sts.to_csv(out / "by_state.csv", index=False)
    rks = None
    if len(set(book.rank)) > 1:
        rks = by_rank(led, key_names + ["DIP_2"], boot)
        rks.to_csv(out / "by_rank.csv", index=False)
    # rank of each setup's lift inside the feature space (same exit)
    sp = v1[v1.setup.str.startswith("S2|")]
    for mode in EXITS:
        ref = np.sort(sp[sp.exit == mode]["lift_pp"].to_numpy())
        m = v1.exit == mode
        v1.loc[m, "pct_of_pair_space"] = [100 * np.searchsorted(ref, x, side="right") / max(1, len(ref))
                                          for x in v1.loc[m, "lift_pp"]]
    X, xrows = explore(book, v1, boot, log, di, d1)
    srows += xrows
    X.to_csv(out / "explore_on_dip.csv", index=False)
    v1.to_csv(out / "vs_D1.csv", index=False)
    v2.to_csv(out / "vs_price_controls.csv", index=False)
    (out / "ledgers").mkdir(exist_ok=True)
    for (name, mode), d in led.items():
        if not name.startswith("S"):
            d.to_csv(out / "ledgers" / ("%s__%s.csv.gz" % (name, mode)), index=False)
    report(v1, v2, out, book, yrs, X, sts, rks)
    S1 = pd.DataFrame(srows)
    S1.to_csv(out / "setups_stage1.csv", index=False)
    (out / "stage1.done").write_text(time.strftime("%Y-%m-%d %H:%M:%S") + "\n", encoding="utf-8")
    log(" stage 1 written (%.0f s)" % (time.time() - t0))
    return v1, v2, S1, boot, di


def cmd_run(book, out, log=print, with_confluence=False):
    """One engine: stage 1 (+ the confluences with its own pool), files in out."""
    t0 = time.time()
    out = Path(out)
    v1, v2, S1, boot, di = stage1(book, out, log)
    if with_confluence:
        confluence(book, v1, boot, out, log, di=di)
    log(" wrote %s (%.0f s)" % (out, time.time() - t0))
    return v1, v2


def cmd_run_multi(books, out, log=print, with_confluence=True):
    """Several engines in one run: stage 1 for each (resumed when its stage1.done exists), ONE confluence pool for
    all (the union of each engine's choice, POOL.json), the confluences for each (resumed likewise), then the
    leaderboard across engines."""
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    res = {}
    for e, b in books.items():
        d = out / e
        if (d / "stage1.done").is_file() and (d / "vs_D1.csv").is_file():
            log(" %s: stage 1 already done - resumed from %s" % (e, d))
            boot = Boot(b.signal_day[b.ok])
            res[e] = (pd.read_csv(d / "vs_D1.csv"), boot, boot.index(b.signal_day))
        else:
            v1, v2, S1, boot, di = stage1(b, d, log)
            res[e] = (v1, boot, di)
    if with_confluence:
        pf = out / "POOL.json"
        if pf.is_file():
            pool = {k: [tuple(c) for c in v] for k, v in json.loads(pf.read_text(encoding="utf-8")).items()}
            log(" confluence pool: %d setups (from POOL.json)" % len(pool))
        else:
            pool = make_pool(next(iter(books.values())), [r[0] for r in res.values()])
            pf.write_text(json.dumps(pool, indent=1), encoding="utf-8")
            log(" confluence pool: %d setups, the same for every engine (POOL.json)" % len(pool))
        for e, b in books.items():
            d = out / e
            if (d / "confluence.done").is_file():
                log(" %s: confluences already done - resumed" % e)
                continue
            v1, boot, di = res[e]
            confluence(b, v1, boot, d, log, di=di, pool=pool)
    return leaderboard(books, out, log)


# ---------------------------------------------------------------------------------------------------- leaderboard
LB_MIN_N = 300
LB_MIN_YEARS = 6
LB_OVERLAP = 0.70
LB_TOP = 3
LB_FDR = 0.05
FAMILY_ORDER = ("label", "label+dip", "label+confirmation", "price-only", "control", "single", "pair", "feature+dip",
                "pair+dip", "confluence", "confluence-alone")
LB_RULE = [
    "Declared 7 Nov 2026 (13:00 IST) before the final run, applied by the code - nobody picks by eye.",
    "Universe: every setup of the run - controls and price-only rules, the A/B/C labels (with and without "
    "confirmations and dips), every single feature and pair, the dip exploration, every setup x confluence and every "
    "confluence alone - each counted once by its conditions, and only if it was tested in every engine of the run.",
    "ELIGIBLE (for one exit) when in EVERY engine: (1) at least %d trades; (2) the lift over the model's D1 entry on its "
    "own trades has a 95%% interval above 0 (Karan's comparison); (3) when it has an indicator-free twin (the same dip "
    "/ confluence without the indicator conditions), the indicators add with a 95%% interval above 0; (4) trades in at "
    "least %d signal years and net per trade above 0 in all but at most one; (5) net per trade above 0 in both halves "
    "of the period." % (LB_MIN_N, LB_MIN_YEARS),
    "(6) A context filter (a condition on the pick's snapshot at the signal: state, market, NIFTY, VIX, breadth, the "
    "volatility flag, the rank) only chooses WHICH trades to take: it must keep better trades than it drops - the same "
    "setup's trades with the filter minus those without it - and pass after counting EVERY filter test of the run "
    "(thousands: each setup meets every context filter, alone and with each price confluence): a false discovery "
    "rate of at most 5% (Benjamini-Hochberg), in every engine. Otherwise a filter that kept a lucky subset would "
    "float a setup to the top: a filtered setup gets no more chances to pass by luck than a plain one.",
    "SCORE = the lower end of the 95% interval of net per trade (after 0.35 pp) in the worst engine: money per trade, "
    "marked down for small samples and for disagreement between the engines.",
    "Lists: BOTH EXITS (eligible under original_d5 AND fresh; score = the lower of the two) is the main list; each "
    "exit on its own follows.",
    "Top %d = the best scores, skipping VERSIONS of a setup already chosen: a setup whose rule (leaving out the "
    "context filters) contains the other's rule or is contained in it, or whose trades overlap %d%% or more with it "
    "(of the smaller set, first engine). Different setups, not versions of one." % (LB_TOP, int(LB_OVERLAP * 100)),
]
D1_CONDS = [("day", "<=", 1), ("day", ">=", 1)]


def lb_table(out, engines):
    """One row per setup (by its conditions) and exit, with every engine's numbers side by side (engine:field)."""
    per = {}
    for e in engines:
        parts = [pd.read_csv(Path(out) / e / f) for f in ("setups_stage1.csv", "setups_confluence.csv")
                 if (Path(out) / e / f).is_file()]
        T = pd.concat(parts, ignore_index=True)
        for c in ("twin", "twin_conds"):
            T[c] = T[c].fillna("").astype(str)
        T["_fam"] = T["family"].map({f: i for i, f in enumerate(FAMILY_ORDER)}).fillna(99)
        per[e] = T.sort_values("_fam", kind="stable").drop_duplicates(["conds", "exit"], keep="first")
    keys, meta = ["conds", "exit"], ["family", "setup", "twin", "twin_conds", "_fam"]
    W = per[engines[0]][keys + meta[:-1]].copy()
    for e in engines:
        T = per[e].set_index(keys)
        W = W.join(T[[c for c in T.columns if c not in meta]].add_prefix(e + ":"), on=keys, how="inner")
    return W.reset_index(drop=True)


def rank_rows(W, engines, min_n=LB_MIN_N, min_years=LB_MIN_YEARS):
    """The declared eligibility (with the reasons a setup fails) and the score."""
    W = W.copy()
    twin = W["twin_conds"].fillna("").astype(str).to_numpy() != ""
    filt = W["conds"].astype(str).str.contains('"snap:', regex=False).to_numpy()
    ok = np.ones(len(W), bool)
    why = [[] for _ in range(len(W))]

    def flag(bad, text):
        bad = np.asarray(bad, bool)
        ok[bad] = False
        for i in np.flatnonzero(bad):
            why[i].append(text)
    for e in engines:
        g = lambda c: pd.to_numeric(W["%s:%s" % (e, c)], errors="coerce").to_numpy(float) if \
            "%s:%s" % (e, c) in W else np.full(len(W), np.nan)
        flag(~(g("n") >= min_n), "%s: fewer than %d trades" % (e, min_n))
        flag(~(g("lo") > 0), "%s: lift over D1 not clearly above 0" % e)
        flag(twin & ~(g("adds_lo") > 0), "%s: the indicators add nothing clear over the same entry without them" % e)
        flag(~(g("years") >= min_years), "%s: trades in fewer than %d years" % (e, min_years))
        flag(~(g("years_net_pos") >= g("years") - 1), "%s: net <= 0 in more than one year" % e)
        flag(~((g("half1_net") > 0) & (g("half2_net") > 0)), "%s: net <= 0 in one half of the period" % e)
        flag(filt & ~(g("filter_q") <= LB_FDR), "%s: the context filter does not clearly keep better trades" % e)
    W["eligible"] = ok
    W["why_not"] = ["; ".join(x) for x in why]
    W["score"] = np.nanmin(np.vstack([pd.to_numeric(W["%s:net_lo" % e], errors="coerce") for e in engines]), axis=0)
    W["min_net"] = np.nanmin(np.vstack([pd.to_numeric(W["%s:setup_net" % e], errors="coerce") for e in engines]),
                             axis=0)
    return W


def both_exits(R):
    """Main list: eligible under both exits; score = the lower of the two."""
    o = R[R.exit == "original_d5"].set_index("conds")
    f = R[R.exit == "fresh"].set_index("conds")
    j = o[["setup", "family", "twin_conds", "eligible", "score", "why_not"]].join(
        f[["eligible", "score", "why_not"]], rsuffix="_fresh", how="inner")
    j["eligible_both"] = j["eligible"] & j["eligible_fresh"]
    j["score_both"] = np.minimum(j["score"], j["score_fresh"])
    return j.reset_index()


def overlap(a, b):
    return len(a & b) / max(1, min(len(a), len(b)))


def core(key):
    """A setup's rule without its context filters (the conditions that decide the entry)."""
    try:
        return frozenset(tuple(c) for c in json.loads(key) if not str(c[0]).startswith("snap:"))
    except (TypeError, ValueError):
        return frozenset([key])


def is_version(a, b, ids, thr=LB_OVERLAP):
    ca, cb = core(a), core(b)
    return ca <= cb or cb <= ca or overlap(ids(a), ids(b)) >= thr


def versions_skipped(chosen, order, ids, limit=200, k=5):
    """For each chosen setup, the best-placed setups (of the first `limit`) skipped as its versions."""
    out = {c: [] for c in chosen}
    for key in order[:limit]:
        if key in out:
            continue
        for c in chosen:
            if is_version(key, c, ids):
                if len(out[c]) < k:
                    out[c].append(key)
                break
    return out


def pick_diverse(order, ids, thr=LB_OVERLAP, k=LB_TOP):
    """Walk down the ranking; keep a setup unless it is a version of one already kept."""
    chosen = []
    for key in order:
        if ids(key) and not any(is_version(key, c, ids, thr) for c in chosen):
            chosen.append(key)
        if len(chosen) == k:
            break
    return chosen


WORDS = {"pre_state_bearish": "a bearish state at the pick (S08/S09)",
         "pre_state_bullish": "a bullish state at the pick (S01-S03)",
         "pre_state_overextended": "overextended at the pick", "pre_state_vol_elevated": "volatility elevated at the pick",
         "pre_nifty_vs_ma50": "NIFTY vs its 50-day average at the pick", "pre_env_code": "the market environment code",
         "pre_vix_pct250": "VIX's 250-day percentile at the pick", "pre_ad_ratio_10": "10-day breadth at the pick",
         "rank": "the model's rank"}


def describe(conds):
    """The conditions in words (an A/B/C label is named when all its conditions are there)."""
    conds = list(dict.fromkeys(conds))
    out, used = [], set()
    labs = sorted(labels().items(), key=lambda kv: -len(kv[1]))
    for ln, lc in labs:
        if set(lc) <= set(conds) and not set(lc) <= used:
            out.append("%s (%s)" % (ln, " and ".join(describe_one(c) for c in lc)))
            used |= set(lc)
            break
    for c in conds:
        if c not in used:
            out.append(describe_one(c))
    return "; ".join(out)


def describe_one(c):
    f, op, v = c
    v = float(v)
    if f == "pc_vs_d1":
        return "yesterday's close below the D1 open" if v == 0 else "yesterday's close more than %g%% below the D1 " \
            "open" % -v
    if f == "pc_vs_d1_atr":
        return "yesterday's close more than %g ATR below the D1 open" % -v
    if f == "gap_pct":
        return "opens below yesterday's close (gap down)" if op == "<" else "opens above yesterday's close (gap up)"
    if f == "prev_intraday":
        return "yesterday closed above its open"
    if f == "prev_ret":
        return "yesterday closed up"
    if f == "day":
        return "watch day %s %g" % (op, v)
    if f == "weekday":
        return "weekday %s %g (1 = Tuesday)" % (op, v)
    if f.startswith("snap:"):
        k = f[5:]
        if k in ("pre_state_bearish", "pre_state_bullish", "pre_state_vol_elevated"):
            return WORDS[k]
        if k == "pre_state_overextended":
            return "not overextended at the pick"
        if k == "rank":
            return "the model's rank %s %g" % (op, v)
        return "%s %s %.4g" % (WORDS.get(k, k), op, v)
    if f.endswith("_change"):
        return "%s %s on the previous session" % (f[:-7], "rose" if op == ">" else "fell")
    return "%s %s %g on the previous session" % (f, "above" if op == ">" else "below", v)


def _sub(a, mask):
    b = dict(a)
    b["f"] = a["f"] & mask
    return b


def positions(b, a):
    """Open positions per market session (entry open to exit close): the average over the sessions from the first
    entry to the last exit, the maximum, and the most entries on one session."""
    k = np.flatnonzero(a["f"])
    if not len(k):
        return {}
    s = b.i1[k] + a["day"][k].astype(int) - 1
    x = b.i1[k] + a["exit_day"][k].astype(int) - 1
    lo = int(s.min())
    d = np.zeros(int(x.max()) - lo + 2)
    np.add.at(d, s - lo, 1)
    np.add.at(d, x - lo + 1, -1)
    op = np.cumsum(d)[:-1]
    return {"pos_avg": float(op.mean()), "pos_max": int(op.max()), "entries_max_day": int(np.bincount(s - lo).max())}


def finalist_ledger(b, R, D):
    """Every trade of a chosen setup (both exits) next to the model's D1 entry on the same trade. Dates are market
    sessions counted from D1 (a stock that skipped a session in its watch window is off by the skipped days)."""
    cal = pd.DatetimeIndex(b.cal)
    parts = []
    for m in EXITS:
        a, d = R[m], D[m]
        k = np.flatnonzero(a["f"])
        ed, xd = a["day"][k].astype(int), a["exit_day"][k].astype(int)
        dd = lambda off: cal[np.clip(b.i1[k] + off - 1, 0, len(cal) - 1)].strftime("%Y-%m-%d")
        parts.append(pd.DataFrame({
            "exit_mode": m, "trade_id": b.ids[k], "engine": b.engine_arr[k], "symbol": b.symbols[k], "rank": b.rank[k],
            "pre_state": b.state[k], "signal_day": pd.DatetimeIndex(b.signal_day[k]).strftime("%Y-%m-%d"),
            "d1_date": dd(1), "entry_watch_day": ed, "entry_date": dd(ed), "entry_price": a["price"][k],
            "exit_date": dd(xd), "exit_price": b.C[k, xd], "net_pct": a["ret"][k], "trade_dd_pct": a["dd"][k],
            "d1_entry_price": d["price"][k], "d1_net_pct": np.where(d["f"][k], d["ret"][k], np.nan),
            "lift_pp": np.where(d["f"][k], a["ret"][k] - d["ret"][k], np.nan)}))
    return pd.concat(parts, ignore_index=True)


def finalist(books, conds, twin_conds, cache):
    """A chosen setup in every engine and exit: all trades, rank bands, bearish vs other states, each year."""
    out = {}
    for e, b in books.items():
        if e not in cache:
            boot = Boot(b.signal_day[b.ok])
            cache[e] = (boot, boot.index(b.signal_day), replay2(b, D1_CONDS))
        boot, di, D = cache[e]
        R = replay2(b, conds)
        T = replay2(b, twin_conds) if twin_conds else None
        years = pd.DatetimeIndex(b.signal_day).year.to_numpy()
        bear = np.isin(b.state, ["S08", "S09"])
        out[(e, "ledger")] = finalist_ledger(b, R, D)
        for m in EXITS:
            groups = {"ranks 1-3": b.rank <= 3, "ranks 4-10": b.rank > 3, "bearish state": bear, "other states": ~bear}
            out[(e, m)] = {"all": stats(R[m], D[m], boot, di, b, T[m] if T else None), "positions": positions(b, R[m]),
                           "groups": {g: stats(_sub(R[m], k), D[m], boot, di, b) for g, k in groups.items()},
                           "years": {int(y): stats(_sub(R[m], years == y), D[m], boot, di, b)
                                     for y in sorted(set(years))}}
    return out


def _f(x, nd=4):
    return "-" if x is None or not np.isfinite(x) else ("%+." + str(nd) + "f") % x


def leaderboard(books, out, log=print):
    """The declared rule over every setup of the run, across the engines. Writes LEADERBOARD.md,
    leaderboard.csv and FREEZE_CANDIDATES.json."""
    out = Path(out)
    engines = list(books)
    R = rank_rows(lb_table(out, engines), engines)
    B = both_exits(R)
    first = books[engines[0]]
    ids_cache = {}

    def ids(conds):
        if conds not in ids_cache:
            a = replay2(first, uncanon(conds))["original_d5"]
            ids_cache[conds] = set(first.ids[a["f"]])
        return ids_cache[conds]
    lists = {}
    elig_b = B[B.eligible_both].sort_values(["score_both", "score"], ascending=False)
    lists["both exits"] = (elig_b, pick_diverse(list(elig_b.conds), ids), "score_both")
    for m in EXITS:
        el = R[(R.exit == m) & R.eligible].sort_values(["score", "min_net"], ascending=False)
        lists[m] = (el, pick_diverse(list(el.conds), ids), "score")
    cache = {}
    (out / "FINALISTS").mkdir(exist_ok=True)

    def row(conds, m):
        x = R[(R.conds == conds) & (R.exit == m)]
        return x.iloc[0] if len(x) else pd.Series(dtype=object)
    L = ["# setuplab leaderboard - the declared rule over every setup (%s)" % VERSION, "",
         "Engines %s; %s. %d setups x 2 exits tested in every engine; eligible: both exits %d, original_d5 %d, "
         "fresh %d." % (", ".join(engines), ", ".join("%s %d picks" % (e, books[e].n) for e in engines),
                        R.conds.nunique(), int(B.eligible_both.sum()), int(R[(R.exit == "original_d5")].eligible.sum()),
                        int(R[(R.exit == "fresh")].eligible.sum())), "", "## The rule", ""] + \
        ["- " + t for t in LB_RULE] + [""]
    freeze = {"version": VERSION, "rule": LB_RULE, "engines": engines, "lists": {}}
    for lname, (el, chosen, sc) in lists.items():
        order = list(el.conds)
        skipped = versions_skipped(chosen, order, ids)
        eli = el.drop_duplicates("conds").set_index("conds")
        L += ["## %s - the top %d" % (lname.upper() if lname == "both exits" else lname + " exit", LB_TOP), ""]
        if not chosen:
            L += ["No setup meets the rule.", ""]
        freeze["lists"][lname] = []
        for rk, conds in enumerate(chosen, 1):
            r0 = row(conds, "original_d5")
            r0 = r0 if len(r0) else row(conds, "fresh")
            det = finalist(books, uncanon(conds), uncanon(r0.twin_conds) if r0.twin_conds else None, cache)
            title = "### %d. %s  (%s)" % (rk, r0.setup, r0.family)
            L += [title, "", "**Rule:** %s. Watch D1-D5 after the pick, buy at the first open where all hold; "
                  "exit original_d5 = the pick's D5 close, fresh = the close 4 sessions after entry; 0.35 pp costs." %
                  describe(uncanon(conds)), "",
                  "| engine | exit | trades | per year | fill % | net | net 95% | D1 same trades | lift over D1 [95%] "
                  "| indicators add [95%] | years net > 0 | 1st / 2nd half | open positions avg / max (entries one day) |",
                  "|---|---|---:|---:|---:|---:|---|---:|---|---|---:|---|---|"]
            item = {"rank": rk, "setup": r0.setup, "family": r0.family, "conds": uncanon(conds),
                    "description": describe(uncanon(conds)), "twin_conds": uncanon(r0.twin_conds) if
                    r0.twin_conds else None, "stats": {}}
            for e in engines:
                for m in EXITS:
                    a = det[(e, m)]["all"]
                    if not a:
                        continue
                    item["stats"]["%s %s" % (e, m)] = {k: (float(v) if isinstance(v, (int, float, np.floating,
                                                                                       np.integer)) else v)
                                                       for k, v in a.items()}
                    po = det[(e, m)]["positions"]
                    item["stats"]["%s %s" % (e, m)].update(po)
                    L.append("| %s | %s | %d | %.0f | %.1f | %s | %s .. %s | %s | %s [%s, %s] | %s | %d/%d | %s / %s | %s |" % (
                        e, m, a["n"], a["trades_per_year"], a["fill_pct"], _f(a["setup_net"]), _f(a["net_lo"]),
                        _f(a["net_hi"]), _f(a["control_net"]), _f(a["lift_pp"]), _f(a["lo"]), _f(a["hi"]),
                        ("%s [%s, %s]" % (_f(a["adds"]), _f(a["adds_lo"]), _f(a["adds_hi"]))) if "adds" in a else "-",
                        a["years_net_pos"], a["years"], _f(a["half1_net"], 2), _f(a["half2_net"], 2),
                        ("%.1f / %d (%d)" % (po["pos_avg"], po["pos_max"], po["entries_max_day"])) if po else "-"))
            if any(str(c[0]).startswith("snap:") for c in uncanon(conds)):
                fx = []
                for e in engines:
                    for m in EXITS:
                        q = row(conds, m)
                        g = lambda c: float(pd.to_numeric(pd.Series([q.get("%s:%s" % (e, c))]), errors="coerce").iloc[0])
                        fx.append("%s %s %s [%s, %s], q %s (kept %s, dropped %s)" % (
                            e, m, _f(g("filter_gain")), _f(g("filter_lo")), _f(g("filter_hi")),
                            "-" if not np.isfinite(g("filter_q")) else "%.4f" % g("filter_q"),
                            "-" if not np.isfinite(g("filter_kept")) else "%d" % g("filter_kept"),
                            "-" if not np.isfinite(g("filter_dropped")) else "%d" % g("filter_dropped")))
                        item.setdefault("filter", {})["%s %s" % (e, m)] = {
                            k: float(g(k)) for k in ("filter_gain", "filter_lo", "filter_hi", "filter_p", "filter_q",
                                                     "filter_kept", "filter_dropped")}
                L += ["", "**Context filter (rule 6)** - the parent setup's trades WITH the filter minus those "
                      "WITHOUT it, net per trade [95%%], q = the false discovery rate over all the run's filter tests "
                      "(passes at <= %.2f): " % LB_FDR + "; ".join(fx) + "."]
            if skipped.get(conds):
                L += ["", "**Versions skipped** (eligible, but the same rule with conditions or context filters added "
                      "or removed, or 70%%+ the same trades): %s." % "; ".join(
                          "%s (place %d, score %s)" % (eli.loc[v, "setup"], order.index(v) + 1, _f(eli.loc[v, sc]))
                          for v in skipped[conds])]
                item["versions_skipped"] = [eli.loc[v, "setup"] for v in skipped[conds]]
            slug = "%s_%d" % (lname.replace(" ", "_"), rk)
            for e in engines:
                det[(e, "ledger")].to_csv(out / "FINALISTS" / ("%s__%s.csv" % (slug, e)), index=False)
            item["ledgers"] = ["FINALISTS/%s__%s.csv" % (slug, e) for e in engines]
            L += ["", "Every trade (both exits, with the D1 entry on the same trade): %s." % ", ".join(
                "`%s`" % x for x in item["ledgers"])]
            L += ["", "| engine | exit | ranks 1-3 | ranks 4-10 | bearish state | other states | by year (net, trades) |",
                  "|---|---|---|---|---|---|---|"]
            for e in engines:
                for m in EXITS:
                    g = det[(e, m)]["groups"]
                    cell = lambda x: "-" if not x else "%s (%d)" % (_f(x["setup_net"], 2), x["n"])
                    yy = ", ".join("%d %s (%d)" % (y, _f(v["setup_net"], 2), v["n"]) for y, v in
                                   det[(e, m)]["years"].items() if v)
                    L.append("| %s | %s | %s | %s | %s | %s | %s |" % (e, m, cell(g["ranks 1-3"]), cell(g["ranks 4-10"]),
                                                                       cell(g["bearish state"]),
                                                                       cell(g["other states"]), yy))
            L.append("")
            freeze["lists"][lname].append(item)
        # the table of the leading eligible setups (no overlap rule)
        L += ["#### The 20 best eligible scores, %s (before the overlap rule)" % lname, "",
              "| # | setup | family | score | %s |" % " | ".join("%s net (%s)" % (e, "orig / fresh" if lname ==
                                                                                "both exits" else lname)
                                                                for e in engines), "|---:|---|---|---:|" +
              "---:|" * len(engines)]
        for i, (_, r) in enumerate(el.head(20).iterrows(), 1):
            nets = []
            for e in engines:
                if lname == "both exits":
                    o, f = row(r.conds, "original_d5"), row(r.conds, "fresh")
                    nets.append("%s / %s" % (_f(o["%s:setup_net" % e], 2), _f(f["%s:setup_net" % e], 2)))
                else:
                    nets.append(_f(r["%s:setup_net" % e], 2))
            L.append("| %d | %s%s | %s | %s | %s |" % (i, r.setup, " *" if r.conds in chosen else "", r.family,
                                                        _f(r[sc], 4), " | ".join(nets)))
        L.append("")
    # where the setups discussed so far stand
    refs = {"A": labels()["A"], "B": labels()["B"], "C": labels()["C"], "A+B": labels()["A+B"],
            "A+C (= A+B+C)": labels()["A+C"], "B+C": labels()["B+C"]}
    for ln in ("A", "B", "C", "A+B", "A+C", "B+C"):
        refs["%s & 2%% dip" % ln] = labels()[ln] + DIPS["DIP_2"]
    refs["2% dip alone"] = DIPS["DIP_2"]
    refs["WQ_44 up & 13w down + gap down + vol elevated"] = [("d_wq_44_change", ">", 0), ("w_ret_13w_change", "<", 0),
                                                            ("gap_pct", "<", 0), ("snap:pre_state_vol_elevated", ">", 0.5)]
    refs["B + 1-ATR dip + bearish"] = labels()["B"] + DIPS["DIPATR_1"] + [("snap:pre_state_bearish", ">", 0.5)]
    refs["B + 3% dip + bearish"] = labels()["B"] + DIPS["DIP_3"] + [("snap:pre_state_bearish", ">", 0.5)]
    L += ["## Where the setups discussed so far stand", "",
          "| setup | both exits: eligible / score / place | why not (first reasons) |", "|---|---|---|"]
    order_b = list(elig_b.conds)
    for name, c in refs.items():
        k = canon(c)
        r = B[B.conds == k]
        if r.empty:
            L.append("| %s | not tested in every engine | - |" % name)
            continue
        r = r.iloc[0]
        place = (order_b.index(k) + 1) if k in order_b else None
        why = "; ".join(dict.fromkeys(y for x in (r.why_not, r.why_not_fresh) if isinstance(x, str) and x
                                      for y in x.split("; ")))[:300]
        L.append("| %s | %s / %s / %s | %s |" % (name, "yes" if r.eligible_both else "no", _f(r.score_both),
                                                 place or "-", why or "-"))
    L += ["", "Families (eligible both exits / tested): " + ", ".join(
        "%s %d/%d" % (f, int(g.eligible_both.sum()), len(g)) for f, g in B.groupby("family")), "",
          "Read with care: this ranks thousands of rules on the history they were found on; the winners' numbers "
          "will shrink going forward. The forward paper ledger is the test."]
    (out / "LEADERBOARD.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    R.to_csv(out / "leaderboard.csv", index=False)
    B.to_csv(out / "leaderboard_both_exits.csv", index=False)
    (out / "FREEZE_CANDIDATES.json").write_text(json.dumps(freeze, indent=1, default=str), encoding="utf-8")
    log(" leaderboard: %d eligible in both exits; wrote LEADERBOARD.md, FREEZE_CANDIDATES.json" %
        int(B.eligible_both.sum()))
    return R, B


def by_group(led, names, boot, key, label):
    """Like by_state, for any grouping of the trades (key: ledger -> group labels)."""
    rows = []
    for name in names:
        for mode in EXITS:
            a = led[(name, mode)]
            ga = key(a)
            for ctl in ("Blind_D1", "DIP_2"):
                if ctl == name:
                    continue
                b = led[(ctl, mode)]
                gb = key(b)
                for g in sorted(pd.unique(ga)):
                    r = paired(a[ga == g], b[gb == g], boot)
                    if r:
                        rows.append({"setup": name, "exit": mode, "control": ctl, label: g, **r})
    return pd.DataFrame(rows)


def by_rank(led, names, boot):
    one = by_group(led, names, boot, lambda d: d["rank"].map(lambda r: "rank %02d" % r).to_numpy(), "group")
    band = by_group(led, names, boot, lambda d: np.where(d["rank"].to_numpy() <= 3, "ranks 1-3", "ranks 4-10"),
                    "group")
    return pd.concat([band, one], ignore_index=True)


def by_state(led, names, boot):
    """Each setup's own trades vs D1 (and vs the 2% dip) on the same ids, split by the pick's stock state at the
    signal (pre_state from the watchlist: nomination context, not the state on the entry day)."""
    rows = []
    for name in names:
        for mode in EXITS:
            a = led[(name, mode)]
            for ctl in ("Blind_D1", "DIP_2"):
                if ctl == name:
                    continue
                b = led[(ctl, mode)]
                for st in sorted(a.pre_state.astype(str).unique()):
                    r = paired(a[a.pre_state.astype(str) == st], b[b.pre_state.astype(str) == st], boot)
                    if r:
                        rows.append({"setup": name, "exit": mode, "control": ctl, "state": st, **r})
    return pd.DataFrame(rows)


def _fmt(r):
    return "%d | %+.4f | %+.4f | **%+.4f** | %+.4f .. %+.4f | %.1f | %.4f" % (
        r["n"], r["control_net"], r["setup_net"], r["lift_pp"], r["lo"], r["hi"], r["setup_better_pct"],
        r["entry_cheaper_pct"])


def report(v1, v2, out, book, yrs=None, X=None, sts=None, rks=None):
    L = ["# setuplab - setups vs the model's D1 entry on the same trades (%s)" % VERSION, "",
         "Engine %s, ranks %s, %d picks, %d settled. Net %% per trade after 0.35 pp. Each row: the setup's OWN filled trades "
         "against the model buying the same trade ids at the D1 open (same exit rule). 95%% circular block bootstrap "
         "over signal days (10-day blocks, 2,000 draws). 'Cheaper' = how far under the control's entry the setup "
         "bought, on average." % (book.engine, "%d-%d" % (min(book.rank), max(book.rank)) if book.n else "-",
                                   book.n, int(book.ok.sum())), ""]
    hdr = "| setup | n | D1 net | setup net | lift pp | 95% interval | setup better % | entry cheaper % |"
    sep = "|---|---:|---:|---:|---:|---|---:|---:|"
    for mode in EXITS:
        L += ["## %s exit" % mode, "", "### A/B/C and the price-only controls", "", hdr, sep]
        sub = v1[(v1.exit == mode) & ~v1.setup.str.startswith("S")]
        for _, r in sub.sort_values("lift_pp", ascending=False).iterrows():
            L.append("| %s | %s |" % (r["setup"], _fmt(r)))
        sp = v1[(v1.exit == mode) & v1.setup.str.startswith("S2|")].sort_values("lift_pp", ascending=False)
        L += ["", "### The whole pair space of the %d features (%d setups; A/B/C's family) - top 15 and bottom 5" %
              (len(book.features), len(sp)), "", hdr, sep]
        for _, r in pd.concat([sp.head(15), sp.tail(5)]).iterrows():
            L.append("| %s | %s |" % (r["setup"][3:], _fmt(r)))
        L += ["", "Pair space: lift above 0 with the interval above 0 in %d of %d setups; median lift %+.4f pp." % (
            int((sp.lo > 0).sum()), len(sp), sp.lift_pp.median()), ""]
        own = sp[(sp.n >= 300) & (sp.lo > 0)].sort_values("setup_net", ascending=False).head(15)
        L += ["### Pair space - top 15 by net per trade (n >= 300, lift interval above 0)", "", hdr, sep]
        for _, r in own.iterrows():
            L.append("| %s | %s |" % (r["setup"][3:], _fmt(r)))
        L.append("")
        L += ["### A/B/C against the price-only controls (same trade ids, both filled)", "",
              "| setup | control | n | control net | setup net | lift pp | 95% interval | setup better % | entry cheaper % |",
              "|---|---|---:|---:|---:|---:|---|---:|---:|"]
        for _, r in (v2[v2.exit == mode] if len(v2) else v2).iterrows():
            L.append("| %s | %s | %s |" % (r["setup"], r["control"], _fmt(r)))
        L.append("")
        if yrs is not None and len(yrs):
            L += ["### By signal year (lift pp on the same trades; setup net in brackets)", ""]
            ys = sorted(yrs.year.unique())
            L += ["| setup | vs | " + " | ".join(str(y) for y in ys) + " |", "|---|---|" + "---:|" * len(ys)]
            for (nm, c), g in yrs[yrs.exit == mode].groupby(["setup", "control"], sort=False):
                g = g.set_index("year")
                L.append("| %s | %s | " % (nm, c) + " | ".join(
                    ("%+.2f (%+.2f, n %d)" % (g.loc[y, "lift_pp"], g.loc[y, "setup_net"], g.loc[y, "n"]))
                    if y in g.index else "-" for y in ys) + " |")
            L.append("")
    labs = [ln for ln in labels() if ln + "__none" in set(v1.setup)]
    if labs:
        L += ["## Every A/B/C label, treated the same (A+B+C = A+C: identical conditions)", "",
              "Net % per trade on the label's own trades (original_d5 / fresh), its lift over D1 on those trades "
              "[95%], and what the label adds over the same dip ALONE on the same trades [95%].", ""]
        for mode in EXITS:
            L += ["### %s exit" % mode, "", "| label | entry | n | net | lift over D1 [95%] | adds over the dip alone [95%] |",
                  "|---|---|---:|---:|---|---|"]
            for ln in labs:
                for dn in [None] + list(DIPS):
                    nm = ln + "__none" if dn is None else "%s&%s" % (ln, dn)
                    r = v1[(v1.setup == nm) & (v1.exit == mode)]
                    if r.empty:
                        continue
                    r = r.iloc[0]
                    a = v2[(v2.setup == nm) & (v2.exit == mode) & (v2.control == dn)] if dn and len(v2) else []
                    adds = ("%+.4f [%+.4f, %+.4f]" % (a.lift_pp.iloc[0], a.lo.iloc[0], a.hi.iloc[0])) if len(a) else "-"
                    L.append("| %s | %s | %d | %+.4f | %+.4f [%+.4f, %+.4f] | %s |" % (
                        ln, dn or "no dip", r.n, r.setup_net, r.lift_pp, r.lo, r.hi, adds))
            L.append("")
    if rks is not None and len(rks):
        L += ["## By rank (the model's rank on the signal day)", "",
              "Each cell: lift over D1 on the setup's own trades [95% interval] / net per trade / trades.", ""]
        for mode in EXITS:
            sub = rks[(rks.exit == mode) & (rks.control == "Blind_D1")]
            names = list(dict.fromkeys(sub.setup))
            L += ["### %s exit" % mode, "", "| group | " + " | ".join(names) + " |", "|---|" + "---|" * len(names)]
            for g in list(dict.fromkeys(sub.group)):
                cells = []
                for nm in names:
                    r = sub[(sub.setup == nm) & (sub.group == g)]
                    cells.append("-" if r.empty else "%+.2f [%+.2f, %+.2f] / %+.2f / %d" % (
                        r.lift_pp.iloc[0], r.lo.iloc[0], r.hi.iloc[0], r.setup_net.iloc[0], r.n.iloc[0]))
                L.append("| %s | " % g + " | ".join(cells) + " |")
            L.append("")
    if sts is not None and len(sts):
        L += ["## By stock state at the signal (pre_state; nomination context)", "",
              "Each cell: lift over D1 on the setup's own trades [95% interval] / the setup's net per trade / trades. "
              "States with under 30 trades are noisy.", ""]
        for mode in EXITS:
            sub = sts[(sts.exit == mode) & (sts.control == "Blind_D1")]
            names = list(dict.fromkeys(sub.setup))
            L += ["### %s exit" % mode, "", "| state | " + " | ".join(names) + " |", "|---|" + "---|" * len(names)]
            for st in sorted(sub.state.unique()):
                cells = []
                for nm in names:
                    r = sub[(sub.setup == nm) & (sub.state == st)]
                    cells.append("-" if r.empty else "%+.2f [%+.2f, %+.2f] / %+.2f / %d" % (
                        r.lift_pp.iloc[0], r.lo.iloc[0], r.hi.iloc[0], r.setup_net.iloc[0], r.n.iloc[0]))
                L.append("| %s | " % st + " | ".join(cells) + " |")
            L.append("")
    if X is not None and len(X):
        L += ["## Exploration: what adds most on top of a price dip (hypotheses, chosen after looking)", "",
              "Each row: the condition AND the dip, its own trades vs the dip alone on the same ids (lift), and vs D1. "
              "Sorted by lift over the dip; n >= 150 only. X1 = one feature condition, X2 = one of the 10 best pairs "
              "of the space, XA = B / A+B with a 1-ATR dip.", ""]
        for mode in EXITS:
            sub = X[(X.exit == mode) & (X.n >= 150)].sort_values("lift_pp", ascending=False)
            L += ["### %s exit - top 15 of %d (interval above 0 over the dip: %d)" % (
                mode, len(sub), int((sub.lo > 0).sum())), "",
                  "| setup | over | n | dip net | setup net | lift over dip | 95% interval | lift over D1 | 95% interval |",
                  "|---|---|---:|---:|---:|---:|---|---:|---|"]
            for _, r in sub.head(15).iterrows():
                L.append("| %s | %s | %d | %+.4f | %+.4f | **%+.4f** | %+.4f .. %+.4f | %+.4f | %+.4f .. %+.4f |" % (
                    r.setup, r.vs, r.n, r.control_net, r.setup_net, r.lift_pp, r.lo, r.hi, r.lift_vs_D1, r.lo_vs_D1,
                    r.hi_vs_D1))
            L.append("")
    L += ["Controls: DIP_x = the first open D2..D5 after a close more than x% under the D1 open (DIP_0: any close under "
          "it); BOUNCE_green = under the D1 open, then a green day; BOUNCE_upclose = under it, then an up close; "
          "BOUNCE_dip2_green = more than 2% under it, then a green day; DIPATR_x = a close more than x ATR14 (at the "
          "signal) under the D1 open. No indicators in any control.",
          "Exploratory: the same history the setups were found on. Under original_d5 both legs sell at the same D5 "
          "close, so a lift there is entirely the entry price."]
    (out / "REPORT.md").write_text("\n".join(L) + "\n", encoding="utf-8")


# ==================================================================================================== v0.7
# The FROZEN setups (FROZEN_SETUPS.json, shipped next to this file): tags on every past pick (tag) and the nightly
# scan of the last five days' picks (scan). Both use the backtest's own rules (Book.field, OPS, trigger, exits_arr).
FROZEN_FILE = "FROZEN_SETUPS.json"
IST = _dt.timezone(_dt.timedelta(hours=5, minutes=30))     # a fixed offset: no time-zone database needed on Windows
ON_TIME_HOUR = 9            # a scan record counts only if written before 09:00 IST of the session it names (paper rule)
SCAN_BACK = 9               # a scan reads picks up to 9 sessions back: 5 to buy from + 4 for open fresh exits
FORWARD_FROM = "2026-11-06"  # the last session before the freeze: its scan names the first forward entries
SCAN_WORDS = {
    "FIRES": "every condition holds at tonight's close: buy at the next open",
    "ARMED": "every condition known tonight holds: buy at the next open only if that open is %s",
    "ENTERED": "entered earlier in the pick's window (entry shown); exits pending or settled",
    "WATCHING": "a condition fails tonight; the pick's window has days left",
    "EXPIRED": "the pick's five-day window ended without an entry",
    "NO DATA": "a value the setup needs is missing (bar, feature or ATR) - nothing is assumed"}
SCAN_COLS = ["scan_date", "setup", "name", "status", "trade_id", "engine", "rank", "symbol", "signal_day",
             "next_watch_day", "close_tonight", "rule_at_open", "open_threshold", "entered_day", "entry_date", "entry",
             "mark_pct", "atr_source", "primary_exit", "zone"]


def _canon_json(obj):
    return json.dumps(obj, sort_keys=True)


def frozen_hash(doc):
    return hashlib.sha256(_canon_json({k: v for k, v in doc.items() if k != "sha256"}).encode()).hexdigest()


def setup_hash(s):
    return hashlib.sha256(_canon_json({"id": s["id"], "conds": s["conds"]}).encode()).hexdigest()


def load_frozen(path=None):
    """The freeze file - shipped next to setuplab.py, never written by the tool. A changed file is refused."""
    p = Path(path) if path else Path(__file__).resolve().with_name(FROZEN_FILE)
    if not p.is_file():
        raise ValueError("no freeze file at %s (it ships next to setuplab.py)" % p)
    doc = json.loads(p.read_text(encoding="utf-8"))
    if doc.get("sha256") != frozen_hash(doc):
        raise ValueError("%s was changed after the freeze (its sha256 does not match its content) - restore the "
                         "shipped file" % p)
    for s in doc["setups"]:
        if s.get("sha256") != setup_hash(s):
            raise ValueError("setup %s in %s was changed after the freeze" % (s.get("id"), p))
    return p, doc


def frozen_conds(doc):
    return {s["id"]: [(str(c[0]), str(c[1]), float(c[2])) for c in s["conds"]] for s in doc["setups"]}


def base_name(f):
    return f[:-7] if f.endswith("_change") else f


def frozen_features(doc):
    out = []
    for s in doc["setups"]:
        for f, _, _ in s["conds"]:
            if f in PRICE_FIELDS or f.startswith("snap:"):
                continue
            out.append(base_name(f))
    return list(dict.fromkeys(out))


def new_run_dir(base, prefix):
    base = Path(base)
    base.mkdir(parents=True, exist_ok=True)
    day = time.strftime("%Y%m%d")
    for i in range(1, 1000):
        d = base / ("%s_%s_%03d" % (prefix, day, i))
        if not d.exists():
            d.mkdir()
            return d
    raise ValueError("no free run folder under %s" % base)


def write_hashes(folder, names):
    lines = []
    for nm in names:
        h = hashlib.sha256((Path(folder) / nm).read_bytes()).hexdigest()
        lines.append("%s  %s" % (h, nm))
    (Path(folder) / "outputs.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")


def _days(book, idx):
    """Calendar dates (YYYY-MM-DD text) at calendar positions idx; '' outside the calendar."""
    idx = np.asarray(idx, dtype=np.int64)
    ok = (idx >= 0) & (idx < len(book.cal))
    out = np.full(len(idx), "", dtype=object)
    if ok.any():
        out[ok] = pd.DatetimeIndex(book.cal[idx[ok]]).strftime("%Y-%m-%d").to_numpy()
    return out


def tag_book(book, conds, doc):
    """One engine's book: each frozen setup's entry on every pick (watch day, date, price) and both exits, with the
    model's D1 trade on the same pick. Returns (wide: one row per pick, long: one row per entered setup, recon)."""
    n = book.n
    rows = np.arange(n)
    d1 = replay2(book, D1_CONDS)
    eng = str(book.engine_arr[0]) if n else book.engine
    W = pd.DataFrame({"trade_id": book.ids, "engine": book.engine_arr, "rank": book.rank, "symbol": book.symbols,
                      "signal_day": pd.DatetimeIndex(book.signal_day).strftime("%Y-%m-%d"), "settled": book.ok,
                      "d1_net_d5": d1["original_d5"]["ret"], "d1_net_fresh": d1["fresh"]["ret"]})
    meta = {s["id"]: s for s in doc["setups"]}
    fired = [[] for _ in range(n)]
    longs, recon = [], []
    for sid, cc in conds.items():
        day, st = trigger(book, cc)
        R = {m: exits_arr(book, day, st, m) for m in EXITS}
        has = st == "Filled"
        k = np.where(has, day, 1)
        price = np.where(has, book.O[rows, np.clip(k, 1, PATH)], np.nan)
        ent_date = np.where(has, _days(book, book.i1 + k - 1), "")
        x5 = np.where(has, _days(book, book.i1 + 4), "")
        xf = np.where(has, _days(book, book.i1 + k + 3), "")
        W["su_%s_day" % sid] = np.where(has, k, np.nan)
        W["su_%s_entry_date" % sid] = ent_date
        W["su_%s_entry" % sid] = price
        W["su_%s_net_d5" % sid] = R["original_d5"]["ret"]
        W["su_%s_net_fresh" % sid] = R["fresh"]["ret"]
        W["su_%s_status" % sid] = st
        pe = meta[sid]["primary_exit"]
        for i in np.flatnonzero(has):
            fired[i].append("%s@D%d" % (sid, k[i]))
            longs.append({"trade_id": book.ids[i], "engine": book.engine_arr[i], "rank": int(book.rank[i]),
                          "symbol": book.symbols[i], "signal_day": W.at[i, "signal_day"], "setup": sid,
                          "name": meta[sid]["name"], "watch_day": int(k[i]), "entry_date": ent_date[i],
                          "entry": float(price[i]), "exit_d5_date": x5[i], "exit_fresh_date": xf[i],
                          "net_d5": float(R["original_d5"]["ret"][i]), "net_fresh": float(R["fresh"]["ret"][i]),
                          "d1_net_d5": float(d1["original_d5"]["ret"][i]), "primary_exit": pe,
                          "net_primary": float(R[pe]["ret"][i]),
                          "settled": bool(np.isfinite(R[pe]["ret"][i]))})
        for m in EXITS:
            mm = R[m]["f"] & d1[m]["f"]
            nn = int(mm.sum())
            net = float(np.mean(R[m]["ret"][mm])) if nn else np.nan
            ctl = float(np.mean(d1[m]["ret"][mm])) if nn else np.nan
            ref = meta[sid]["final_001"].get("%s %s" % (eng, m), {})
            same = (nn == int(ref.get("n") or -1) and ref.get("setup_net") is not None
                    and abs(net - float(ref["setup_net"])) < 2e-6)
            recon.append({"setup": sid, "engine": eng, "exit": m, "n": nn, "net": net, "d1_same": ctl,
                          "final_001_n": ref.get("n"), "final_001_net": ref.get("setup_net"), "same": bool(same)})
    W["setups"] = [" ".join(x) for x in fired]
    W["n_setups"] = [len(x) for x in fired]
    return W, pd.DataFrame(longs), recon


def cmd_tag(a, log=print):
    """Tags every pick of a research watchlist (setuplab build's watchlist.parquet + calendar.parquet) with the
    frozen setups, using the panel the backtest used. Writes TAGS_<date>_<nnn> under --out."""
    try:
        fp, doc = load_frozen(a.frozen)
    except ValueError as e:
        print("REFUSED: %s" % e)
        return 3
    conds, feats = frozen_conds(doc), frozen_features(doc)
    run = new_run_dir(Path(a.out) / "TAGS", "TAGS")
    log("%s tag: freeze %s (sha256 %s), %d setups; watchlist %s; panel %s -> %s" % (
        VERSION, fp.name, doc["sha256"][:16], len(conds), a.data, a.features, run))
    engines = [e.strip() for e in a.engines.split(",") if e.strip()]
    Ws, Ls, recon, atr = [], [], [], []
    for e in engines:
        try:
            book = load(a.data, a.features, e, feats + ["d_atr_pct"], None, log, a.chunk)
        except ValueError as ex:
            print("REFUSED: %s" % ex)
            return 3
        if book.n == 0:
            print("REFUSED: no picks of engine %s in the watchlist" % e)
            return 3
        miss = [f for f in feats if f not in book.features]
        if miss:
            print("REFUSED: the panel lacks %s (needed by the frozen setups)" % ", ".join(miss))
            return 3
        W, L, R = tag_book(book, conds, doc)
        Ws.append(W)
        Ls.append(L)
        recon += R
        if "d_atr_pct" in book.F:                       # is pick_meta's s_atr14 the panel's ATR% / 100? (the scan
            pa = book.F["d_atr_pct"][:, 1] / 100.0      # needs an ATR for the live picks)
            ok = np.isfinite(pa) & np.isfinite(book.atr)
            d = np.abs(pa[ok] - book.atr[ok])
            atr.append({"engine": e, "compared": int(ok.sum()), "within_1e-6": int((d < 1e-6).sum()),
                        "max_abs_diff": float(d.max()) if ok.any() else np.nan})
        log(" %s: %d picks, %d entered setups" % (e, book.n, len(L)))
    W = pd.concat(Ws, ignore_index=True)
    L = pd.concat(Ls, ignore_index=True) if Ls else pd.DataFrame()
    Rc = pd.DataFrame(recon)
    W.to_parquet(run / "setup_tags.parquet", index=False)
    W.to_csv(run / "setup_tags.csv", index=False)
    L.to_parquet(run / "setup_trades.parquet", index=False)
    L.to_csv(run / "setup_trades.csv", index=False)
    rec_ok = bool(Rc["same"].all()) if len(Rc) else False
    meta = {"version": VERSION, "made": _dt.datetime.now(IST).isoformat(timespec="seconds"),
            "frozen_file": str(fp), "frozen_sha256": doc["sha256"],
            "setups": [{"id": s["id"], "name": s["name"], "primary_exit": s["primary_exit"],
                        "sha256": s["sha256"]} for s in doc["setups"]],
            "watchlist": str(Path(a.data) / "watchlist.parquet"), "panel": str(a.features), "engines": engines,
            "picks": int(len(W)), "signal_days": [str(W["signal_day"].min()), str(W["signal_day"].max())],
            "reconciled_with_final_001": rec_ok, "atr_check": atr}
    (run / "TAGS.json").write_text(json.dumps(meta, indent=1, default=str), encoding="utf-8")
    md = ["# Setup tags (%s)" % VERSION, "",
          "Freeze `%s` sha256 `%s` - %s" % (fp.name, doc["sha256"][:16], ", ".join(
              "%s %s" % (s["id"], s["name"]) for s in doc["setups"])), "",
          "Watchlist `%s`, panel `%s`; %d picks, signal days %s .. %s." % (
              meta["watchlist"], meta["panel"], len(W), meta["signal_days"][0], meta["signal_days"][1]), "",
          "Files: `setup_tags.parquet/.csv` (one row per pick: `setups` = which setups entered and on which watch day, "
          "then per setup `su_<ID>_day / _entry_date / _entry / _net_d5 / _net_fresh / _status`), "
          "`setup_trades.parquet/.csv` (one row per entered setup), `TAGS.json`. Net % after 0.35 pp.", "",
          "## Every setup against FINAL_001 (the same rule on the same data must give the same trades)", "",
          "| setup | engine | exit | trades | net | D1 same trades | FINAL_001 trades | FINAL_001 net | same |",
          "|---|---|---|---:|---:|---:|---:|---:|---|"]
    for r in recon:
        md.append("| %s | %s | %s | %d | %+.4f | %+.4f | %s | %s | %s |" % (
            r["setup"], r["engine"], r["exit"], r["n"], r["net"], r["d1_same"], r["final_001_n"],
            "%+.4f" % r["final_001_net"] if r["final_001_net"] is not None else "-", "yes" if r["same"] else "NO"))
    md += ["", "**%s**" % ("RECONCILED: every setup gives FINAL_001's trades and net." if rec_ok else
                          "DIFFERS from FINAL_001 - expected only when the watchlist or the panel is not FINAL_001's "
                          "(e.g. later dates); otherwise send this file."), ""]
    if atr:
        md += ["ATR (information): pick_meta's s_atr14 is a simple 14-session ATR / close, the panel's d_atr_pct a "
               "Wilder one, so they differ by definition. The scan uses pick_meta's card or the simple ATR from the bars "
               "(v0.8); `setuplab zones --data` checks that one. s_atr14 vs d_atr_pct / 100 at the signal day: " + "; ".join(
                   "%s %d of %d within 1e-6 (largest difference %.2e)" % (x["engine"], x["within_1e-6"],
                                                                         x["compared"], x["max_abs_diff"])
                   for x in atr), ""]
    else:
        md += ["ATR check: the panel has no d_atr_pct column.", ""]
    (run / "TAGS.md").write_text("\n".join(md), encoding="utf-8")
    write_hashes(run, ["setup_tags.parquet", "setup_tags.csv", "setup_trades.parquet", "setup_trades.csv",
                       "TAGS.json", "TAGS.md"])
    log(" %s" % ("RECONCILED with FINAL_001" if rec_ok else "DIFFERS from FINAL_001 (see TAGS.md)"))
    log(" wrote %s" % run)
    print("TAGS %s" % ("RECONCILED" if rec_ok else "WRITTEN (not FINAL_001's data)"))
    return 0


# ---------------------------------------------------------------------------------------------------- the scan
def read_paper_ledger(root):
    """paper\\ledger.jsonl -> the paper test's recorded picks, with tradelab tl_watch's reader rules: a record needs
    date, engine, rank, symbol and score; the first record of each date, engine and rank is kept."""
    p = Path(root) / "paper" / "ledger.jsonl"
    if not p.is_file():
        raise ValueError("paper ledger not found: %s" % p)
    recs = []
    for line in p.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            r = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(r, dict) and all(k in r for k in ("date", "engine", "rank", "symbol", "score")):
            recs.append({"date": str(r["date"])[:10], "engine": str(r["engine"]), "rank": int(r["rank"]),
                         "symbol": str(r["symbol"]).strip(), "score": float(r["score"]),
                         "recorded_at": str(r.get("recorded_at") or "")})
    if not recs:
        raise ValueError("%s holds no watchlist records (date, engine, rank, symbol, score)" % p)
    L = pd.DataFrame(recs).drop_duplicates(["date", "engine", "rank"], keep="first").reset_index(drop=True)
    L["signal_day"] = pd.to_datetime(L["date"]).dt.normalize()
    return L


def tv_name(sym):
    """TradingView's NSE ticker (playbook's rule): '&' and '-' become '_' (M&M -> M_M)."""
    return "".join(ch if ch.isalnum() else "_" for ch in str(sym).upper())


def next_weekday(d):
    d = pd.Timestamp(d).normalize() + pd.Timedelta(days=1)
    while d.weekday() >= 5:
        d += pd.Timedelta(days=1)
    return d


def pm_atr(root, day):
    """pick_meta's forward card for a signal day: {(engine, rank, symbol): s_atr14} when the card has that column."""
    p = Path(root) / "research2" / "pick_meta" / "forward" / ("PM_cards_%s.csv" % pd.Timestamp(day).strftime("%Y%m%d"))
    if not p.is_file():
        return {}
    try:
        df = pd.read_csv(p)
    except Exception:
        return {}
    low = {c.lower(): c for c in df.columns}
    if not {"engine", "rank", "symbol", "s_atr14"} <= set(low):
        return {}
    out = {}
    for _, r in df.iterrows():
        try:
            out[(str(r[low["engine"]]), int(r[low["rank"]]), str(r[low["symbol"]]).strip())] = float(r[low["s_atr14"]])
        except (TypeError, ValueError):
            continue
    return out


def live_book(picks, bars, cal_days, T, root):
    """A Book of live picks with every bar up to session T and ONE extra session after T (the next open, its prices
    unknown), so Book.field gives each watch day's values exactly as in the backtest.
    picks: DataFrame trade_id, engine, rank, symbol, signal_day. bars: symbol -> (dates, o, c) up to T.
    Returns (book, kstar, dropped) - kstar = the next open's watch day per pick (in the book's order); dropped =
    [(trade_id, why)] for picks that cannot be read."""
    T = np.datetime64(pd.Timestamp(T).date(), "D")
    nxt = np.datetime64(next_weekday(T).date(), "D")
    cal = np.concatenate([cal_days[cal_days <= T], [nxt]])
    rows, kst, dropped = [], {}, []
    for p in picks.itertuples(index=False):
        b = bars.get(p.symbol)
        sday = np.datetime64(pd.Timestamp(p.signal_day).date(), "D")
        if b is None:
            dropped.append((p.trade_id, "no daily bars in the cache"))
            continue
        dates, o, c = b
        m = dates <= T
        dates, o, c = dates[m], o[m], c[m]
        js = np.flatnonzero(dates == sday)
        if not len(js):
            dropped.append((p.trade_id, "no bar on the signal day"))
            continue
        j = int(js[0])
        nT = len(dates)
        ent = float(o[j + 1]) if j + 1 < nT else np.nan
        eday = dates[j + 1] if j + 1 < nT else nxt
        row = {"trade_id": p.trade_id, "engine": p.engine, "rank": int(p.rank), "symbol": p.symbol,
               "signal_day": pd.Timestamp(sday), "entry_day": str(pd.Timestamp(eday).date()), "signal_close": float(c[j]),
               "entry": ent, "status": "ok", "net_bp": 0.0}
        for k in range(1, PATH + 1):
            row["close_%d" % k] = float(c[j + k]) / ent - 1 if j + k < nT and np.isfinite(ent) else np.nan
            row["overnight_%d" % k] = (0.0 if k == 1 else float(o[j + k]) / float(c[j + k - 1]) - 1) \
                if j + k < nT else np.nan
        rows.append(row)
        kst[p.trade_id] = nT - 1 - j + 1               # own bars after the signal bar up to T, + 1
    wl = pd.DataFrame(rows)
    if wl.empty:
        return None, np.zeros(0, dtype=np.int64), dropped
    book = Book(wl, pd.Series(cal), None, engine=None)
    kstar = np.array([kst[t] for t in book.ids], dtype=np.int64)
    return book, kstar, dropped


def live_eval(book, conds, kstar):
    """Each pick's state for the next open (watch day kstar): the backtest's rule (trigger) on the days already
    past, then tonight's verdict - FIRES / ARMED (only the open's gap is unknown) / WATCHING / EXPIRED / NO DATA.
    Returns (status, entered watch day)."""
    n = book.n
    status = np.full(n, "", dtype=object)
    day = np.zeros(n, dtype=np.int64)
    done = np.zeros(n, dtype=bool)
    for k in range(1, WATCH + 1):
        anyF = np.zeros(n, dtype=bool)
        gapN = np.zeros(n, dtype=bool)
        othN = np.zeros(n, dtype=bool)
        for fld, op, val in conds:
            a = book.field(fld)[:, k]
            nan = np.isnan(a)
            r = OPS[op](np.round(np.where(nan, 0, a), 9), round(float(val), 9))
            anyF |= ~nan & ~r
            if fld == "gap_pct":
                gapN |= nan
            else:
                othN |= nan
        past = ~done & (kstar > k)
        sess = np.isfinite(book.O[:, k])
        gone = past & ~sess
        status[gone] = "NO DATA"
        done |= gone
        hit = past & sess & ~anyF & ~gapN & ~othN
        miss = past & sess & ~anyF & (gapN | othN)
        status[hit] = "ENTERED"
        day[hit] = k
        status[miss] = "NO DATA"
        done |= hit | miss
        cur = ~done & (kstar == k)
        status[cur & ~anyF & ~gapN & ~othN] = "FIRES"
        status[cur & ~anyF & gapN & ~othN] = "ARMED"
        status[cur & ~anyF & othN] = "NO DATA"
        status[cur & anyF] = "WATCHING" if k < WATCH else "EXPIRED"
        done |= cur
    status[~done] = "EXPIRED"
    return status, day


def gap_threshold(conds, close):
    """For an ARMED setup: the open's price rule, e.g. ('below', 123.4) for gap_pct < 0."""
    for f, op, v in conds:
        if f == "gap_pct":
            word = {"<": "below", "<=": "at or below", ">": "above", ">=": "at or above"}[op]
            return word, close * (1 + float(v) / 100.0)
    return "", np.nan


def on_time_deadline(T, cal_days):
    """09:00 IST of the session after T: the calendar's when it is already known (a late scan), else the next
    weekday (a holiday only moves the real session later, so the record is still on time)."""
    T = np.datetime64(pd.Timestamp(T).date(), "D")
    later = cal_days[cal_days > T]
    d = pd.Timestamp(later[0]) if len(later) else next_weekday(T)
    return _dt.datetime(d.year, d.month, d.day, ON_TIME_HOUR, 0, tzinfo=IST)


def ledger_lines(path):
    p = Path(path)
    if not p.is_file():
        return []
    out = []
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip():
            out.append(json.loads(line))
    return out


def ledger_append(path, rec):
    """Hash-chained: each record carries the previous record's sha256 and its own."""
    old = ledger_lines(path)
    prev = old[-1]["sha256"] if old else "0" * 64
    for i, r in enumerate(old):                       # the chain must be intact before anything is added
        want = old[i - 1]["sha256"] if i else "0" * 64
        body = {k: v for k, v in r.items() if k != "sha256"}
        if r.get("prev") != want or r.get("sha256") != hashlib.sha256(_canon_json(body).encode()).hexdigest():
            raise ValueError("%s: record %d does not match the chain - the ledger was edited" % (path, i + 1))
    rec = dict(rec, prev=prev)
    rec["sha256"] = hashlib.sha256(_canon_json(rec).encode()).hexdigest()
    with open(path, "a", encoding="utf-8", newline="\n") as f:
        f.write(_canon_json(rec) + "\n")
    return rec


class LiveData:
    """Bars, calendar and panel for the scan: tradelab's readers (stage E's bar loader, read only) and panel_live."""

    def __init__(self, root, stage_e_any=False, panel="panel_live"):
        try:
            import tl_data as TD
        except ImportError as e:
            raise ValueError("cannot import tradelab's tl_data (%s) - start with tradelab's env_tradelab.bat" % e)
        self.root = Path(root)
        self.TD = TD
        self.market = TD.Market(self.root, TD.Production(stage_e_any=stage_e_any))
        self.cal = np.asarray(self.market.cal).astype("datetime64[D]")
        self.panel = self.root / panel / "panel.parquet" if panel else None
        if panel and not self.panel.is_file():
            raise ValueError("%s not found (the scan reads the nightly panel)" % self.panel)

    def bars(self, symbols):
        self.market.load(list(symbols))
        out = {}
        for s in symbols:
            ds = self.market.series(s)
            if ds is not None:
                out[s] = (np.asarray(ds.dates).astype("datetime64[D]"), np.asarray(ds.o, float),
                          np.asarray(ds.c, float))
        return out

    def ohlcv(self, symbols):
        """symbol -> (dates, open, high, low, close, volume) of the stock's own daily bars (v0.8: the zones)."""
        self.market.load(list(symbols))
        out = {}
        for s in symbols:
            ds = self.market.series(s)
            if ds is not None:
                out[s] = (np.asarray(ds.dates).astype("datetime64[D]"), np.asarray(ds.o, float),
                          np.asarray(ds.h, float), np.asarray(ds.l, float), np.asarray(ds.c, float),
                          np.asarray(ds.v, float))
        return out

    def index_closes(self, names):
        """{key: cache symbol} -> {key: (dates, closes)}; a missing index file is refused (the zones need all four)."""
        out = {}
        for k, sym in names.items():
            ds = self.market.series(sym)
            if ds is None:
                raise ValueError("%s daily bars are not in the cache (the zones need NIFTY50, NIFTYMIDCAP150, "
                                 "NIFTYSMLCAP250 and INDIAVIX)" % sym)
            out[k] = (np.asarray(ds.dates).astype("datetime64[D]"), np.asarray(ds.c, float))
        return out

    def forget(self, symbols):
        """Drop symbols' bars from memory (the whole-market pass reads every stock once)."""
        keep = {v for _, v in ZONE_INDEX} | {"NIFTY50"}
        for s in symbols:
            if s not in keep:
                self.market.daily.pop(s, None)


def scan_day(T, doc, conds, feats, L, data, out, log=print):
    """One evening: every pick of the last SCAN_BACK sessions up to T against every frozen setup."""
    T = np.datetime64(pd.Timestamp(T).date(), "D")
    cal = data.cal
    iT = int(np.searchsorted(cal, T, side="right")) - 1
    if iT < 0 or cal[iT] != T:
        raise ValueError("%s is not a session in the cache's calendar" % T)
    first = cal[max(0, iT - SCAN_BACK)]
    P = L[(L["signal_day"] >= pd.Timestamp(first)) & (L["signal_day"] <= pd.Timestamp(T))].copy()
    P["trade_id"] = ["%s-%s-%d" % (e, pd.Timestamp(d).strftime("%Y%m%d"), r)
                     for e, d, r in zip(P["engine"], P["signal_day"], P["rank"])]
    bars = data.bars(sorted(P["symbol"].unique()))
    book, kstar, dropped = live_book(P, bars, cal, T, data.root)
    meta = {s["id"]: s for s in doc["setups"]}
    rows = []
    byid = P.set_index("trade_id")
    for tid, why in dropped:
        p = byid.loc[tid]
        for sid in conds:
            rows.append({"scan_date": str(pd.Timestamp(T).date()), "setup": sid, "name": meta[sid]["name"],
                         "status": "NO DATA", "trade_id": tid, "engine": p["engine"], "rank": int(p["rank"]),
                         "symbol": p["symbol"], "signal_day": str(pd.Timestamp(p["signal_day"]).date()),
                         "next_watch_day": "", "close_tonight": np.nan, "rule_at_open": why, "open_threshold": np.nan,
                         "entered_day": "", "entry_date": "", "entry": np.nan, "mark_pct": np.nan, "atr_source": "",
                         "primary_exit": meta[sid]["primary_exit"]})
    if book is None or book.n == 0:
        return pd.DataFrame(rows, columns=SCAN_COLS), P
    book.attach(data.panel, feats + ["d_atr_pct"], chunk=8)
    miss = [f for f in feats if f not in book.features]
    if miss:
        raise ValueError("%s lacks %s (the frozen setups read them)" % (data.panel, ", ".join(miss)))
    live = kstar <= WATCH
    if live.any():
        rr = np.flatnonzero(live)
        seen = np.zeros(len(rr), dtype=bool)
        for f in feats:
            seen |= np.isfinite(book.F[f][rr, kstar[rr]])
        if not seen.any():
            raise ValueError("%s has no row for %s yet (the scan reads tonight's features from it): run the scan again "
                             "once the nightly panel is updated (it is retried by --all-missing)" % (
                                 data.panel, pd.Timestamp(T).date()))
    # ATR14 / close at the pick: pick_meta's card when it has s_atr14, else the panel's d_atr_pct / 100
    src = np.full(book.n, "", dtype=object)
    atr = np.full(book.n, np.nan)
    cards = {}
    for i in range(book.n):
        d = pd.Timestamp(book.signal_day[i])
        if d not in cards:
            cards[d] = pm_atr(data.root, d)
        v = cards[d].get((str(book.engine_arr[i]), int(book.rank[i]), str(book.symbols[i])))
        if v is not None and np.isfinite(v):
            atr[i], src[i] = v, "pick_meta"
    fill = ~np.isfinite(atr)
    if fill.any():
        sa = signal_atr(data, book, np.flatnonzero(fill))
        ok = np.isfinite(sa)
        idx = np.flatnonzero(fill)[ok]
        atr[idx], src[idx] = sa[ok], "bars"
    book.atr = atr
    book.__dict__.pop("_cache", None)
    rws = np.arange(book.n)
    cT = book.PC[rws, np.clip(kstar, 1, PATH)]          # tonight's close = the previous close of the next open
    for sid, cc in conds.items():
        if any(base_name(f) in miss for f, _, _ in cc):
            st, day = np.full(book.n, "NO DATA", dtype=object), np.zeros(book.n, dtype=np.int64)
        else:
            st, day = live_eval(book, cc, kstar)
        word, _ = gap_threshold(cc, 1.0)
        for i in range(book.n):
            k = int(kstar[i])
            r = {"scan_date": str(pd.Timestamp(T).date()), "setup": sid, "name": meta[sid]["name"],
                 "status": st[i], "trade_id": book.ids[i], "engine": book.engine_arr[i], "rank": int(book.rank[i]),
                 "symbol": book.symbols[i], "signal_day": str(pd.Timestamp(book.signal_day[i]).date()),
                 "next_watch_day": k if k <= WATCH else "", "close_tonight": float(cT[i]) if k <= PATH else np.nan,
                 "rule_at_open": "", "open_threshold": np.nan, "entered_day": "", "entry_date": "", "entry": np.nan,
                 "mark_pct": np.nan, "atr_source": src[i] if any(f == "pc_vs_d1_atr" for f, _, _ in cc) else "",
                 "primary_exit": meta[sid]["primary_exit"]}
            if st[i] == "ARMED":
                w, thr = gap_threshold(cc, float(cT[i]))
                r["rule_at_open"], r["open_threshold"] = "open %s %.2f" % (w, thr), thr
            if st[i] == "ENTERED":
                kk = int(day[i])
                r["entered_day"] = kk
                r["entry_date"] = str(pd.Timestamp(book.cal[book.i1[i] + kk - 1]).date())
                r["entry"] = float(book.O[i, kk])
                last = min(k - 1, PATH)
                if last >= kk and np.isfinite(book.C[i, last]):
                    r["mark_pct"] = (float(book.C[i, last]) / r["entry"] - 1) * 100
            rows.append(r)
    S = pd.DataFrame(rows, columns=SCAN_COLS)
    return S, P


def atr_simple(h, l, c):
    """ATR14 / close as pick_meta's s_atr14 (the label contract, panel_build): a SIMPLE 14-session mean of the true
    range from the second bar, divided by the close. Not D_atr_pct (Wilder): v0.8 found the two agree on 3 of 15,819
    picks, so S1's 1-ATR dip must use this one wherever s_atr14 is not recorded."""
    h, l, c = (np.asarray(x, float) for x in (h, l, c))
    tr = np.full(len(c), np.nan)
    if len(c) > 1:
        tr[1:] = np.maximum(h[1:] - l[1:], np.maximum(np.abs(h[1:] - c[:-1]), np.abs(l[1:] - c[:-1])))
    a = pd.Series(tr).rolling(14, min_periods=14).mean().to_numpy()
    with np.errstate(invalid="ignore", divide="ignore"):
        return a / np.where(c == 0, np.nan, c)


def signal_atr(data, book, rows):
    """s_atr14 at the signal day for book rows without one, from the stock's bars (atr_simple)."""
    out = np.full(len(rows), np.nan)
    if not hasattr(data, "ohlcv") or not len(rows):
        return out
    bars = data.ohlcv(sorted({str(book.symbols[i]) for i in rows}))
    for k, i in enumerate(rows):
        b = bars.get(str(book.symbols[i]))
        if b is None:
            continue
        dates = np.asarray(b[0]).astype("datetime64[D]")
        j = int(np.searchsorted(dates, np.datetime64(pd.Timestamp(book.signal_day[i]).date(), "D")))
        if j < len(dates) and dates[j] == np.datetime64(pd.Timestamp(book.signal_day[i]).date(), "D"):
            out[k] = atr_simple(b[2], b[3], b[4])[j]
    return out


def zone_flags(S, data, zdoc, T):
    """v0.8: each FIRES / ARMED / ENTERED row IN or OUT of its setup's picks zone (SETUP_ZONES.json), read at the
    close before the entry: tonight's close for FIRES / ARMED, the close before the entry day for ENTERED. Blank =
    the setup has no zone (or no zones file)."""
    S = S.copy()
    S["zone"] = ""
    if zdoc is None or S.empty:
        return S
    zones = {sid: zone_parse(((zdoc["setups"].get(sid) or {}).get("picks") or {}).get("zone", ""))
             for sid in S["setup"].unique()}
    need = S["status"].isin(["FIRES", "ARMED", "ENTERED"]).to_numpy() & S["setup"].map(
        lambda x: bool(zones.get(x))).to_numpy()
    if not need.any():
        return S
    M = market_dims(data.index_closes(dict(ZONE_INDEX)))
    bars = data.ohlcv(sorted(S.loc[need, "symbol"].unique()))
    T = np.datetime64(pd.Timestamp(T).date(), "D")
    cache, out = {}, S["zone"].to_numpy(dtype=object, copy=True)
    for i in np.flatnonzero(need):
        r = S.iloc[i]
        if r["symbol"] not in bars:
            out[i] = "OUT"
            continue
        if r["symbol"] not in cache:
            dates, o, h, l, c, v = bars[r["symbol"]]
            dates = np.asarray(dates).astype("datetime64[D]")
            cache[r["symbol"]] = (dates, zone_buckets(zone_values(dates, o, h, l, c, v, M)))
        dates, B = cache[r["symbol"]]
        if r["status"] == "ENTERED":
            j = int(np.searchsorted(dates, np.datetime64(str(r["entry_date"]), "D"))) - 1
        else:
            j = int(np.searchsorted(dates, T, side="right")) - 1
            if j >= 0 and dates[j] != T:
                j = -1
        inside = j >= 0 and all(lo <= B[dim][j] <= hi for dim, lo, hi in zones[r["setup"]])
        out[i] = "IN" if inside else "OUT"
    S["zone"] = out
    return S


def forward_record(L, data, doc, conds, feats, ledger_path, T, since=FORWARD_FROM):
    """The forward record: every setup entry a scan named ON TIME (FIRES / ARMED, the scan date on or after
    FORWARD_FROM) that the bars then show was entered on that watch day; both exits and D1 on the same pick."""
    recs = [r for r in ledger_lines(ledger_path) if r.get("event") == "scan" and r.get("on_time")
            and r.get("scan_date", "") >= since]
    named, zoned = {}, {}
    for r in recs:
        for x in r.get("named", []):
            named.setdefault((x["trade_id"], x["setup"]), (int(x["watch_day"]), r["scan_date"]))
            zoned.setdefault((x["trade_id"], x["setup"]), x.get("zone", ""))
    if not named:
        return pd.DataFrame()
    ids = sorted({t for t, _ in named})
    P = L.copy()
    P["trade_id"] = ["%s-%s-%d" % (e, pd.Timestamp(d).strftime("%Y%m%d"), r)
                     for e, d, r in zip(P["engine"], P["signal_day"], P["rank"])]
    P = P[P["trade_id"].isin(ids)]
    bars = data.bars(sorted(P["symbol"].unique()))
    book, kstar, _ = live_book(P, bars, data.cal, T, data.root)
    if book is None:
        return pd.DataFrame()
    book.attach(data.panel, feats + ["d_atr_pct"], chunk=8)
    atr = np.full(book.n, np.nan)
    for i in range(book.n):
        v = pm_atr(data.root, book.signal_day[i]).get((str(book.engine_arr[i]), int(book.rank[i]),
                                                        str(book.symbols[i])))
        if v is not None:
            atr[i] = v
    fill = ~np.isfinite(atr)
    if fill.any():
        atr[np.flatnonzero(fill)] = signal_atr(data, book, np.flatnonzero(fill))
    book.atr = atr
    book.__dict__.pop("_cache", None)
    meta = {s["id"]: s for s in doc["setups"]}
    rows = []
    d1d, d1s = trigger_all(book, D1_CONDS)
    d1 = exits_arr(book, d1d, d1s, "original_d5")
    for sid, cc in conds.items():
        st, day = live_eval(book, cc, np.full(book.n, WATCH + 1, dtype=np.int64))
        status = np.where(st == "ENTERED", "Filled", "No entry")
        R = {m: exits_arr(book, day, status, m) for m in EXITS}
        for i in range(book.n):
            key = (book.ids[i], sid)
            if key not in named:
                continue
            k_named, sdate = named[key]
            entered = st[i] == "ENTERED" and int(day[i]) == k_named
            pe = meta[sid]["primary_exit"]
            rows.append({"setup": sid, "trade_id": book.ids[i], "engine": book.engine_arr[i],
                         "rank": int(book.rank[i]), "symbol": book.symbols[i],
                         "signal_day": str(pd.Timestamp(book.signal_day[i]).date()), "named_on": sdate,
                         "named_watch_day": k_named, "entered": bool(entered),
                         "entry_date": str(pd.Timestamp(book.cal[book.i1[i] + k_named - 1]).date())
                         if entered else "", "entry": float(book.O[i, k_named]) if entered else np.nan,
                         "net_d5": float(R["original_d5"]["ret"][i]) if entered else np.nan,
                         "net_fresh": float(R["fresh"]["ret"][i]) if entered else np.nan,
                         "d1_net_d5": float(d1["ret"][i]), "primary_exit": pe, "zone": zoned.get(key, ""),
                         "net_primary": float(R[pe]["ret"][i]) if entered else np.nan})
    F = pd.DataFrame(rows)
    if len(F):
        F["settled"] = F["entered"] & np.isfinite(F["net_primary"].astype(float))
    return F


def trigger_all(book, conds):
    """trigger() for books whose picks are not settled yet (every pick is evaluated)."""
    ok = book.ok
    book.ok = np.ones(book.n, dtype=bool)
    try:
        return trigger(book, conds)
    finally:
        book.ok = ok


def scan_page(T, S, F, doc, rec, out_csv, tv_file, zdoc=None):
    """SCAN_<date>.md: what to do at the next open, positions, and the forward record so far."""
    d = str(pd.Timestamp(T).date())
    L = ["# Setup scan - picks of the last five sessions, tonight %s (%s)" % (d, VERSION), "",
         "Freeze sha256 `%s`. Recorded %s - %s (%s)." % (
             doc["sha256"][:16], rec["recorded_at"], "ON TIME" if rec["on_time"] else "LATE: counts for nothing",
             "deadline %s" % rec["deadline"]), ""]
    if S.empty:
        L += ["No picks in the last five sessions.", ""]
    else:
        act = S[S["status"].isin(["FIRES", "ARMED"])].sort_values(["setup", "engine", "rank"])
        L += ["## At the next open", ""]
        if act.empty:
            L += ["Nothing fires.", ""]
        else:
            L += ["| setup | what to do | stock | engine / rank | signal day | watch day | tonight's close | zone |",
                  "|---|---|---|---|---|---:|---:|---|"]
            for r in act.itertuples(index=False):
                what = "BUY at the open" if r.status == "FIRES" else "BUY at the open only if %s" % r.rule_at_open
                L.append("| %s | %s | %s | %s %d | %s | D%s | %.2f | %s |" % (
                    r.setup, what, r.symbol, r.engine, r.rank, r.signal_day, r.next_watch_day, r.close_tonight,
                    getattr(r, "zone", "") or "-"))
            L.append("")
        pos = S[S["status"] == "ENTERED"].sort_values(["setup", "entry_date"])
        if len(pos):
            L += ["## Entered (exits: original_d5 = the pick's D5 close; fresh = 4 sessions after the entry)", "",
                  "| setup | stock | engine / rank | signal day | entered | price | now % (gross) |",
                  "|---|---|---|---|---|---:|---:|"]
            for r in pos.itertuples(index=False):
                L.append("| %s | %s | %s %d | %s | %s (D%s) | %.2f | %s |" % (
                    r.setup, r.symbol, r.engine, r.rank, r.signal_day, r.entry_date, r.entered_day, r.entry,
                    "%+.2f" % r.mark_pct if np.isfinite(r.mark_pct) else "-"))
            L.append("")
        cnt = S.pivot_table(index="setup", columns="status", values="trade_id", aggfunc="count", fill_value=0)
        L += ["## Every pick of the last five sessions (counts)", "",
              "| setup | " + " | ".join(cnt.columns) + " |", "|---|" + "---:|" * len(cnt.columns)]
        for sid, r in cnt.iterrows():
            L.append("| %s | " % sid + " | ".join(str(int(x)) for x in r.to_numpy()) + " |")
        L += [""]
    L += ["## Forward record since the freeze (entries named on time; the judge is at month 6 / 12)", ""]
    if F is None or F.empty:
        L += ["No on-time entries yet.", ""]
    else:
        L += ["| setup | named | entered | settled | mean net at its primary exit | D1 on the same picks | "
              "settled IN its zone | mean net IN its zone |",
              "|---|---:|---:|---:|---:|---:|---:|---:|"]
        for s in doc["setups"]:
            g = F[F["setup"] == s["id"]]
            st = g[g["settled"]]
            zi = st[st["zone"] == "IN"] if "zone" in st.columns else st.iloc[:0]
            L.append("| %s | %d | %d | %d | %s | %s | %d | %s |" % (
                s["id"], len(g), int(g["entered"].sum()), len(st),
                "%+.4f" % st["net_primary"].mean() if len(st) else "-",
                "%+.4f" % st["d1_net_d5"].mean() if len(st) and st["d1_net_d5"].notna().any() else "-",
                len(zi), "%+.4f" % zi["net_primary"].mean() if len(zi) else "-"))
        L += [""]
    L += ["Statuses: " + "; ".join("%s = %s" % (k, (v % "below / above the threshold") if "%s" in v else v)
                                   for k, v in SCAN_WORDS.items()), "",
          "Files: `%s` (every pick x setup), `%s` (import into TradingView: Watchlist menu, Import list)." % (
              Path(out_csv).name, Path(tv_file).name),
          "Setups: " + "; ".join("%s %s (primary exit %s)" % (s["id"], s["name"], s["primary_exit"])
                                 for s in doc["setups"]), ""]
    if zdoc is not None:
        L += ["Zones (SETUP_ZONES.json sha256 %s; IN / OUT = the close before the entry inside / outside the setup's "
              "picks zone; a zone is a hypothesis - the forward record keeps every entry): " % zdoc["sha256"][:16] +
              "; ".join("%s %s (out of sample: %s)" % (
                  sid, (r.get("picks") or {}).get("text", "-"), " / ".join(
                      v["verdict"] for v in ((r.get("picks") or {}).get("out_of_sample") or {}).values()) or "-")
                  for sid, r in zdoc["setups"].items()), ""]
    else:
        L += ["Zones: none (run setuplab zones to add each setup's zone).", ""]
    return "\n".join(L)


def tv_text(S):
    """TradingView import: one section per setup and action, NSE tickers."""
    parts = []
    if S.empty:
        return ""
    for sid in sorted(S["setup"].unique()):
        for stt, label in (("FIRES", "buy at open"), ("ARMED", "buy if the open meets its rule")):
            g = S[(S["setup"] == sid) & (S["status"] == stt)]
            if len(g):
                parts.append("###%s %s" % (sid, label))
                parts += ["NSE:%s" % tv_name(s) for s in dict.fromkeys(g["symbol"])]
    w = S[S["status"] == "ENTERED"]
    if len(w):
        parts.append("###Entered (open setup positions)")
        parts += ["NSE:%s" % tv_name(s) for s in dict.fromkeys(w["symbol"])]
    return ",".join(parts)


def cmd_scan(a, log=print):
    """The nightly scan (after Run Now): the last five sessions' picks against every frozen setup."""
    try:
        fp, doc = load_frozen(a.frozen)
    except ValueError as e:
        print("REFUSED: %s" % e)
        return 3
    conds, feats = frozen_conds(doc), frozen_features(doc)
    out = Path(a.out) / "scan"
    out.mkdir(parents=True, exist_ok=True)
    try:
        data = LiveData(a.root, a.stage_e_any, a.panel)
        log("%s scan: freeze %s (sha256 %s); bars through %s; panel %s" % (
            VERSION, fp.name, doc["sha256"][:16], pd.Timestamp(data.cal[-1]).date(), data.panel))
        L = read_paper_ledger(a.root)
    except ValueError as e:
        print("REFUSED: %s" % e)
        return 3
    try:
        zrun, zdoc = load_zones(a.out)
    except ValueError as e:
        zrun, zdoc = None, None
        log(" zones NOT used: %s" % e)
    if zdoc is not None:
        log(" zones: %s (sha256 %s): %s" % (zrun.name, zdoc["sha256"][:16], "; ".join(
            "%s %s" % (sid, (r.get("picks") or {}).get("zone") or "-") for sid, r in zdoc["setups"].items())))
    cal = data.cal
    if a.date:
        days = [np.datetime64(pd.Timestamp(a.date).date(), "D")]
    else:
        last = cal[-1]
        days = [last]
        if a.all_missing:
            days = [d for d in cal if np.datetime64(FORWARD_FROM, "D") <= d <= last]
    lp = out / "setup_ledger.jsonl"
    rc = 0
    for T in days:
        tag = pd.Timestamp(T).strftime("%Y%m%d")
        page, csv, tv = out / ("SCAN_%s.md" % tag), out / ("scan_%s.csv" % tag), out / ("tv_%s.txt" % tag)
        if page.is_file() and not a.force:
            log(" %s: already scanned (SCAN_%s.md) - skipped; --force rescans (the ledger keeps the first record)" % (
                pd.Timestamp(T).date(), tag))
            continue
        try:
            S, P = scan_day(T, doc, conds, feats, L, data, out, log)
        except ValueError as e:
            print("REFUSED (%s): %s" % (pd.Timestamp(T).date(), e))
            rc = 3
            continue
        try:
            S = zone_flags(S, data, zdoc, T)
        except Exception as e:                    # a zone problem never stops the scan: the rows stay without zone
            log(" %s: zones not applied (%s: %s)" % (pd.Timestamp(T).date(), type(e).__name__, e))
            S = S.copy()
            S["zone"] = ""
        now = _dt.datetime.now(IST)
        dl = on_time_deadline(T, cal)
        named = [] if S.empty else [
            {"setup": r.setup, "status": r.status, "trade_id": r.trade_id, "symbol": r.symbol,
             "watch_day": int(r.next_watch_day), "close_tonight": round(float(r.close_tonight), 4),
             "rule_at_open": r.rule_at_open, "zone": r.zone}
            for r in S[S["status"].isin(["FIRES", "ARMED"])].itertuples(index=False)]
        rec = {"event": "scan", "scan_date": str(pd.Timestamp(T).date()), "recorded_at": now.isoformat(timespec="seconds"),
               "deadline": dl.isoformat(timespec="minutes"), "on_time": now < dl, "tool": VERSION,
               "frozen_sha256": doc["sha256"], "zones_sha256": zdoc["sha256"] if zdoc else None,
               "picks": int(len(P)), "named": named}
        old = [r for r in ledger_lines(lp) if r.get("event") == "scan" and r.get("scan_date") == rec["scan_date"]]
        if not old:
            try:
                ledger_append(lp, rec)
            except ValueError as e:
                print("REFUSED: %s" % e)
                return 3
        else:
            rec = old[0]
        F = forward_record(L, data, doc, conds, feats, lp, T)
        S.to_csv(csv, index=False)
        tv.write_text(tv_text(S) + "\n", encoding="utf-8")
        if F is not None and len(F):
            F.to_csv(out / "forward_trades.csv", index=False)
        page.write_text(scan_page(T, S, F, doc, rec, csv, tv, zdoc), encoding="utf-8")
        act = 0 if S.empty else int(S["status"].isin(["FIRES", "ARMED"]).sum())
        log(" %s: %d picks, %d setup entries named for the next open (%s) -> %s" % (
            pd.Timestamp(T).date(), len(P), act, "on time" if rec["on_time"] else "LATE", page))
    return rc


# ===================================================================================== v0.8: zones and the whole market
ZONES_FILE = "SETUP_ZONES.json"
ZONE_RULE = ("zones v1, declared 8 Nov 2026 before any zone result. Every dimension is read at the close before the "
             "entry (the close the setup's own conditions are read at). A candidate is one range of one dimension, or "
             "two ranges of two dimensions. It must keep %d trades a year in each population. It QUALIFIES when, in "
             "every population (picks: D and ENS; the whole market: one), inside minus outside (net %% per trade) has "
             "a 95%% interval above 0 and the check (picks: the lift over the model's D1 entry on the same picks; the "
             "whole market: the excess over buying every stock at the same open) has a 95%% interval above 0. The "
             "winner is the qualifying zone whose net per trade has the highest strict lower bound (mean - 3.29 "
             "bootstrap standard deviations, 99.9%%) in its weakest population - the strict level only RANKS the "
             "qualifiers, so a narrow lucky slice does not beat a broad real one. None qualifies = no zone. Plain 95%% per candidate (Karan's choice, 8 Nov): about 1 in 20 "
             "candidates passes by luck, so the same search is replayed year by year (choose with exits before "
             "1 Jan, judge on that year): HOLDS only if inside beats outside out of sample." % 40)
# (id, what, edges ascending - bucket = how many edges are at or below the value - or None for a code, bucket labels)
ZONE_DIMS = (
    ("ATRP", "ATR14 % of the close", (2.0, 3.0, 4.5), ("<2", "2-3", "3-4.5", ">=4.5")),
    ("ATRX", "ATR14 % / its mean of the last 50 sessions", (0.85, 1.15), ("<0.85", "0.85-1.15", ">=1.15")),
    ("TREND", "close vs EMA50 and EMA200", None, ("below both", "between", "above both")),
    ("RET20", "20-session return %", (-10.0, 0.0, 10.0), ("<-10", "-10 to 0", "0 to 10", ">=10")),
    ("RSI14", "RSI 14", (30.0, 50.0, 70.0), ("<30", "30-50", "50-70", ">=70")),
    ("DD52", "% from the highest close of the last 252 sessions", (-30.0, -15.0, -5.0),
     ("<-30", "-30 to -15", "-15 to -5", ">=-5")),
    ("RVOL", "volume / mean volume of the 20 sessions before", (0.7, 1.5), ("<0.7", "0.7-1.5", ">=1.5")),
    ("RS20", "20-session return minus Smallcap 250's (pts)", (-5.0, 5.0), ("<-5", "-5 to 5", ">=5")),
    ("IDX", "NIFTY 50, Midcap 150, Smallcap 250 closing at or above their 50-session mean (how many)", None,
     ("0", "1", "2", "3")),
    ("VIXP", "India VIX percentile in its last 250 sessions", (100.0 / 3, 200.0 / 3), ("<33", "33-67", ">=67")),
    ("VIX5", "India VIX 5-session change %", (-10.0, 10.0), ("<-10", "-10 to 10", ">=10")),
    ("NIFTY20", "NIFTY 50 20-session return %", (-3.0, 3.0), ("<-3", "-3 to 3", ">=3")),
)
ZDIM = {d[0]: d for d in ZONE_DIMS}
ZONE_INDEX = (("nifty", "NIFTY50"), ("mid", "NIFTYMIDCAP150"), ("small", "NIFTYSMLCAP250"), ("vix", "INDIAVIX"))
ZONE_MIN_PER_YEAR = 40       # trades a year a zone must keep in each population (month 12 can then reach 30)
ZONE_FINALISTS = 40          # the best by a quick strict lower bound get the full block bootstrap
ZONE_RANK_Z = 3.29           # ranking only: mean - 3.29 standard deviations (99.9%); qualifying stays plain 95%
ZONE_WF_YEARS = (2022, 2023, 2024, 2025, 2026)
MARKET_FROM = np.datetime64("2020-01-01")
PINE_CODE_TAG = "BMSZ1"


def stock_dims(o, h, l, c, v):
    """The stock's own zone values at every bar's close (ATR, RSI and EMA exactly as production's features_daily)."""
    h, l, c, v = (pd.Series(np.asarray(x, float)) for x in (h, l, c, v))
    pc = c.shift(1)
    tr = pd.concat([h - l, (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1)
    atrp = tr.ewm(alpha=1 / 14, adjust=False, min_periods=14).mean() / c.replace(0, np.nan) * 100
    e50 = c.ewm(span=50, adjust=False, min_periods=50).mean()
    e200 = c.ewm(span=200, adjust=False, min_periods=200).mean()
    trend = np.where((c > e50) & (c > e200), 2.0, np.where((c < e50) & (c < e200), 0.0, 1.0))
    trend[(e50.isna() | e200.isna() | c.isna()).to_numpy()] = np.nan
    d = c.diff()
    ag = d.clip(lower=0).ewm(alpha=1 / 14, adjust=False, min_periods=14).mean()
    al = (-d.clip(upper=0)).ewm(alpha=1 / 14, adjust=False, min_periods=14).mean()
    rsi = 100 - 100 / (1 + ag / al.replace(0, np.nan))
    warm = ag.notna() & al.notna()
    rsi = rsi.mask(warm & (al == 0) & (ag > 0), 100.0).mask(warm & (ag == 0) & (al > 0), 0.0) \
        .mask(warm & (ag == 0) & (al == 0), 50.0)
    vm = v.shift(1).rolling(20, min_periods=20).mean()
    out = {"ATRP": atrp, "ATRX": atrp / atrp.rolling(50, min_periods=50).mean(), "TREND": pd.Series(trend),
           "RET20": (c / c.shift(20) - 1) * 100, "RSI14": rsi,
           "DD52": (c / c.rolling(252, min_periods=252).max() - 1) * 100, "RVOL": v / vm.replace(0, np.nan)}
    return {k: pd.to_numeric(x, errors="coerce").replace([np.inf, -np.inf], np.nan).to_numpy(float)
            for k, x in out.items()}


def pct_rank_window(x, window=250, minp=60):
    """tradelab tl_context's rolling_pct_rank: the share of the last `window` values (today included) at or below
    today's; blank with fewer than minp values."""
    x = np.asarray(x, float)
    out = np.full(len(x), np.nan)
    for i in range(len(x)):
        if np.isfinite(x[i]):
            a = x[max(0, i - window + 1):i + 1]
            a = a[np.isfinite(a)]
            if len(a) >= minp:
                out[i] = float(np.mean(a <= x[i]))
    return out


def market_dims(idx):
    """idx: nifty / mid / small / vix -> (dates, closes). -> by date: IDX, VIXP, VIX5, NIFTY20 and SMALL20 (for RS20).
    Each index's measures run over its own sessions; a date an input lacks stays blank."""
    S = {k: pd.Series(np.asarray(cl, float), index=pd.DatetimeIndex(np.asarray(d).astype("datetime64[D]")))
         for k, (d, cl) in idx.items()}
    cols = {}
    for k in ("nifty", "mid", "small"):
        s = S[k]
        m = s.rolling(50, min_periods=50).mean()
        cols["up_" + k] = (s >= m).astype(float).where(m.notna() & s.notna())
    cols["NIFTY20"] = (S["nifty"] / S["nifty"].shift(20) - 1) * 100
    cols["SMALL20"] = (S["small"] / S["small"].shift(20) - 1) * 100
    vx = S["vix"]
    cols["VIXP"] = pd.Series(pct_rank_window(vx.to_numpy()) * 100, index=vx.index)
    cols["VIX5"] = (vx / vx.shift(5) - 1) * 100
    M = pd.DataFrame(cols)
    M["IDX"] = M[["up_nifty", "up_mid", "up_small"]].sum(axis=1, min_count=3)
    return M[["IDX", "VIXP", "VIX5", "NIFTY20", "SMALL20"]].replace([np.inf, -np.inf], np.nan)


def zone_values(dates, o, h, l, c, v, M):
    """Every zone dimension at every bar's close of one stock (M = market_dims)."""
    z = stock_dims(o, h, l, c, v)
    m = M.reindex(pd.DatetimeIndex(np.asarray(dates).astype("datetime64[D]")))
    for k in ("IDX", "VIXP", "VIX5", "NIFTY20"):
        z[k] = m[k].to_numpy(float)
    z["RS20"] = z["RET20"] - m["SMALL20"].to_numpy(float)
    return z


def zone_buckets(z):
    """dimension -> int8 bucket of every value (-1 = unknown)."""
    out = {}
    for dim, _, edges, labels in ZONE_DIMS:
        x = np.asarray(z[dim], float)
        b = np.full(len(x), -1, np.int8)
        ok = np.isfinite(x)
        if edges is None:
            b[ok] = np.clip(np.round(x[ok]), 0, len(labels) - 1).astype(np.int8)
        else:
            b[ok] = np.searchsorted(np.asarray(edges, float), x[ok], side="right").astype(np.int8)
        out[dim] = b
    return out


def _zone_ranges():
    R = []
    for dim, _, _, labels in ZONE_DIMS:
        for lo in range(len(labels)):
            for hi in range(lo, len(labels)):
                if not (lo == 0 and hi == len(labels) - 1):
                    R.append((dim, lo, hi))
    return R


ZONE_RANGES = _zone_ranges()


def zone_key(zone):
    return "+".join("%s:%d:%d" % r for r in zone) if zone else ""


def zone_parse(text):
    if not text:
        return ()
    out = []
    for part in str(text).split("+"):
        dim, lo, hi = part.split(":")
        if dim not in ZDIM or not 0 <= int(lo) <= int(hi) < len(ZDIM[dim][3]):
            raise ValueError("not a zone: %s" % text)
        out.append((dim, int(lo), int(hi)))
    return tuple(out)


def zone_text(zone):
    """A zone in words, e.g. 'ATR14 % of the close 3 and above & India VIX percentile below 33'."""
    if not zone:
        return "no zone (the setup alone)"
    parts = []
    for dim, lo, hi in zone:
        _, what, edges, labels = ZDIM[dim]
        if edges is None:
            v = labels[lo] if lo == hi else "%s to %s" % (labels[lo], labels[hi])
        elif lo == 0:
            v = "below %g" % edges[hi]
        elif hi == len(labels) - 1:
            v = "%g and above" % edges[lo - 1]
        else:
            v = "%g to %g" % (edges[lo - 1], edges[hi])
        parts.append("%s %s: %s" % (dim, what, v))
    return " & ".join(parts)


def zone_mask(zone, B):
    """Which rows are inside the zone (B: dimension -> buckets; an unknown bucket is outside)."""
    n = len(next(iter(B.values())))
    m = np.ones(n, bool)
    for dim, lo, hi in zone:
        b = np.asarray(B[dim])
        m &= (b >= lo) & (b <= hi)
    return m


def _mfield(fld, k, D, e, x, o, c, F, atrf, dates):
    """A condition field at watch day k of every pseudo-pick D (entry bar e, decision bar x = e - 1); setuplab's
    Book.field on the stock's own bars."""
    if fld in F:
        return F[fld][x]
    if fld == "gap_pct":
        return (o[e] / c[e - 1] - 1) * 100
    if fld in ("pc_vs_d1", "pc_vs_d1_atr", "prev_intraday", "prev_ret"):
        if k == 1:
            return np.zeros(len(D))
        if fld == "pc_vs_d1":
            return (c[x] / o[D + 1] - 1) * 100
        if fld == "pc_vs_d1_atr":
            return (c[x] / o[D + 1] - 1) / atrf[D]
        if fld == "prev_intraday":
            return (c[x] / o[x] - 1) * 100
        return (c[x] / c[x - 1] - 1) * 100
    if fld == "day":
        return np.full(len(D), float(k))
    if fld == "weekday":
        return pd.DatetimeIndex(np.asarray(dates)[e]).weekday.to_numpy(float)
    raise KeyError("unknown field %s" % fld)


def market_entries(dates, o, c, F, atrf, setups, d_ok):
    """Every first qualifying open of every pseudo-pick of one stock: each own bar d with d_ok[d] is a signal day,
    its watch days are the next five own bars, and setuplab's trigger rule applies (a False condition = not that
    day; unknown with no False = the pseudo-pick stops). F: feature (and feature_change) -> values on the bars
    (blank = no panel row); atrf: ATR14 as a fraction at each bar. -> {setup: unique sorted entry bars}"""
    o, c = np.asarray(o, float), np.asarray(c, float)
    n = len(c)
    D = np.flatnonzero(np.asarray(d_ok, bool)[:max(n - 1, 0)])
    out = {}
    for sid, conds in setups.items():
        done = np.zeros(len(D), bool)
        hit = np.zeros(len(D), np.int64)
        for k in range(1, WATCH + 1):
            e = D + k
            sess = e < n
            ee = np.where(sess, e, n - 1)
            sess &= np.isfinite(o[ee])
            done |= ~sess
            x = ee - 1
            anyF = np.zeros(len(D), bool)
            anyN = np.zeros(len(D), bool)
            with np.errstate(invalid="ignore", divide="ignore"):
                for fld, op, val in conds:
                    a = np.asarray(_mfield(fld, k, D, ee, x, o, c, F, atrf, dates), float)
                    nan = np.isnan(a)
                    r = OPS[op](np.round(np.where(nan, 0, a), 9), round(float(val), 9))
                    anyF |= ~nan & ~r
                    anyN |= nan
            h = ~done & ~anyF & ~anyN
            m = ~done & ~anyF & anyN
            hit[h] = k
            done |= h | m
        out[sid] = np.unique((D + hit)[hit > 0])
    return out


def panel_frame(path, feats, d_from, symbols=None, log=print):
    """The panel's rows from d_from on: symbol, date and the features (lower-case names; read in batches)."""
    import pyarrow.parquet as pq
    pf = pq.ParquetFile(path)
    names = pf.schema_arrow.names
    low = {n.lower(): n for n in names}
    want = list(dict.fromkeys([f.lower() for f in feats] + ["d_atr_pct"]))
    miss = [f for f in want if f not in low]
    if miss:
        raise ValueError("%s lacks %s" % (path, ", ".join(miss)))
    tk = low.get("timestamp", low.get("date"))
    if "symbol" not in low or tk is None:
        raise ValueError("%s needs symbol and timestamp (or date) columns" % path)
    parts = []
    for b in pf.iter_batches(batch_size=400_000, columns=[low["symbol"], tk] + [low[f] for f in want]):
        f = b.to_pandas()
        f.columns = ["symbol", "date"] + want
        t = pd.to_datetime(f["date"])
        if t.dt.tz is not None:
            t = t.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
        f["date"] = t.dt.normalize().to_numpy().astype("datetime64[D]")
        f = f[f["date"] >= d_from]
        f["symbol"] = f["symbol"].astype(str).str.strip().str.upper()
        if symbols is not None:
            f = f[f["symbol"].isin(symbols)]
        for c in want:
            f[c] = pd.to_numeric(f[c], errors="coerce").astype(np.float64)
        parts.append(f)
    P = pd.concat(parts, ignore_index=True).sort_values(["symbol", "date"], kind="mergesort")
    if P.duplicated(["symbol", "date"]).any():
        raise ValueError("duplicated symbol/date rows in %s" % path)
    P["symbol"] = P["symbol"].astype("category")
    log(" panel: %d rows, %d stocks, %s .. %s" % (len(P), P["symbol"].nunique(), P["date"].min(), P["date"].max()))
    return P.reset_index(drop=True), want


def align_panel(Psym, want, dates):
    """One stock's panel rows on its own bars: feature and feature_change (this row minus the stock's previous
    panel row, as setuplab) -> arrays on the bars; and whether each bar has a panel row."""
    pd_ = Psym["date"].to_numpy().astype("datetime64[D]")
    dates = np.asarray(dates).astype("datetime64[D]")
    pos = np.searchsorted(pd_, dates)
    pos_c = np.minimum(pos, max(len(pd_) - 1, 0))
    have = (pos < len(pd_)) & (pd_[pos_c] == dates) if len(pd_) else np.zeros(len(dates), bool)
    F = {}
    for f in want:
        v = Psym[f].to_numpy(float)
        ch = np.concatenate([[np.nan], np.diff(v)]) if len(v) else v
        F[f] = np.where(have, v[pos_c], np.nan) if len(v) else np.full(len(dates), np.nan)
        F[f + "_change"] = np.where(have, ch[pos_c], np.nan) if len(v) else np.full(len(dates), np.nan)
    return F, have


def market_symbol(dates, o, h, l, c, v, Fsym, have, setups, M, d_from):
    """One stock in the whole-market study: its setups' trades (held 5 sessions: the fresh exit), the zone at the
    close before each entry, and its buy-everything rows (every open it was in the universe the evening before)."""
    dates = np.asarray(dates).astype("datetime64[D]")
    o, c = np.asarray(o, float), np.asarray(c, float)
    n = len(c)
    z = zone_buckets(zone_values(dates, o, h, l, c, v, M))
    atrf = atr_simple(h, l, c)                    # pick_meta's s_atr14 definition, not the panel's Wilder ATR
    d_ok = have & (dates >= d_from)
    ent = market_entries(dates, o, c, Fsym, atrf, setups, d_ok)
    rows = []
    for sid, e in ent.items():
        e = e[e + 4 < n]
        if not len(e):
            continue
        with np.errstate(invalid="ignore", divide="ignore"):
            net = (c[e + 4] / o[e] - 1) * 100 - COST
        rows.append(pd.DataFrame({"setup": sid, "day": dates[e], "exit": dates[e + 4], "net": net,
                                  **{d: z[d][e - 1] for d in z}}))
    i = np.arange(1, max(n - 4, 1))
    i = i[(i + 4 < n) & have[i - 1] & (dates[i] >= d_from)] if n > 5 else np.array([], int)
    with np.errstate(invalid="ignore", divide="ignore"):
        bench = (c[i + 4] / o[i] - 1) * 100 - COST if len(i) else np.array([])
    ok = np.isfinite(bench)
    return (pd.concat(rows, ignore_index=True) if rows else None), (dates[i][ok], bench[ok])


# ------------------------------------------------------------------------------------------------- the search
def _years(days):
    days = np.asarray(days).astype("datetime64[D]")
    return max(0.5, float((days.max() - days.min()).astype(int)) / 365.25) if len(days) else 0.5


def zone_screen(di, net, B, nd):
    """Every candidate's trades inside, mean net inside and a quick lower bound (signal days as clusters)."""
    nb = {d[0]: len(d[3]) for d in ZONE_DIMS}

    def stats(S, N):
        n = N.sum()
        if n <= 1:
            return n, np.nan, np.nan
        m = S.sum() / n
        r = S - m * N
        g = int((N > 0).sum())
        se = np.sqrt((r * r).sum() * g / max(g - 1, 1)) / n
        return n, m, m - ZONE_RANK_Z * se

    cube = {}
    for d in nb:
        b = np.where(B[d] < 0, nb[d], B[d]).astype(np.int64)
        cube[d] = b
    res_n, res_m, res_lb = [], [], []
    one = {}
    for d in nb:
        code = di * (nb[d] + 1) + cube[d]
        S = np.bincount(code, weights=net, minlength=nd * (nb[d] + 1)).reshape(nd, nb[d] + 1)
        N = np.bincount(code, minlength=nd * (nb[d] + 1)).reshape(nd, nb[d] + 1).astype(float)
        one[d] = (S, N)
    for dim, lo, hi in ZONE_RANGES:
        S, N = one[dim]
        n, m, lb = stats(S[:, lo:hi + 1].sum(1), N[:, lo:hi + 1].sum(1))
        res_n.append(n), res_m.append(m), res_lb.append(lb)
    dims = [d[0] for d in ZONE_DIMS]
    byd = {}
    for r in ZONE_RANGES:
        byd.setdefault(r[0], []).append(r)
    for i, d1 in enumerate(dims):
        for d2 in dims[i + 1:]:
            n1, n2 = nb[d1] + 1, nb[d2] + 1
            code = (di * n1 + cube[d1]) * n2 + cube[d2]
            S = np.bincount(code, weights=net, minlength=nd * n1 * n2).reshape(nd, n1, n2)
            N = np.bincount(code, minlength=nd * n1 * n2).reshape(nd, n1, n2).astype(float)
            S1 = {r: S[:, r[1]:r[2] + 1, :] for r in byd[d1]}
            N1 = {r: N[:, r[1]:r[2] + 1, :] for r in byd[d1]}
            for r1 in byd[d1]:
                s1, n1_ = S1[r1].sum(1), N1[r1].sum(1)
                for r2 in byd[d2]:
                    n, m, lb = stats(s1[:, r2[1]:r2[2] + 1].sum(1), n1_[:, r2[1]:r2[2] + 1].sum(1))
                    res_n.append(n), res_m.append(m), res_lb.append(lb)
    return np.array(res_n), np.array(res_m), np.array(res_lb)


def _cands():
    singles = [(r,) for r in ZONE_RANGES]
    dims = [d[0] for d in ZONE_DIMS]
    byd = {}
    for r in ZONE_RANGES:
        byd.setdefault(r[0], []).append(r)
    pairs = [(r1, r2) for i, d1 in enumerate(dims) for d2 in dims[i + 1:] for r1 in byd[d1] for r2 in byd[d2]]
    return singles + pairs


ZONE_CANDS = _cands()        # the order zone_screen returns its numbers in


def zone_eval(boot, di, net, chk, m):
    """Inside the zone (m): mean net per trade with its 95% interval, inside minus outside, the check inside."""
    nd = len(boot.days)
    cols = np.column_stack([np.bincount(di[m], weights=net[m], minlength=nd), np.bincount(di[m], minlength=nd),
                            np.bincount(di[~m], weights=net[~m], minlength=nd), np.bincount(di[~m], minlength=nd),
                            np.bincount(di[m], weights=chk[m], minlength=nd)]).astype(float)
    X = boot.M @ cols
    with np.errstate(invalid="ignore", divide="ignore"):
        mi = X[:, 0] / np.where(X[:, 1] > 0, X[:, 1], np.nan)
        mo = X[:, 2] / np.where(X[:, 3] > 0, X[:, 3], np.nan)
        mc = X[:, 4] / np.where(X[:, 1] > 0, X[:, 1], np.nan)
    pc = lambda a: (float(np.nanpercentile(a, 2.5)), float(np.nanpercentile(a, 97.5))) if np.isfinite(a).any() \
        else (np.nan, np.nan)
    n_in, n_out = int(m.sum()), int((~m).sum())
    r = {"n": n_in, "n_out": n_out, "net": float(net[m].mean()) if n_in else np.nan,
         "net_out": float(net[~m].mean()) if n_out else np.nan, "chk": float(chk[m].mean()) if n_in else np.nan}
    r["lo"], r["hi"] = pc(mi)
    r["strict"] = r["net"] - ZONE_RANK_Z * float(np.nanstd(mi)) if n_in else np.nan
    r["diff"] = r["net"] - r["net_out"] if n_in and n_out else np.nan
    r["diff_lo"], r["diff_hi"] = pc(mi - mo) if n_in and n_out else (np.nan, np.nan)
    r["chk_lo"], r["chk_hi"] = pc(mc)
    return r


def _pop(name, days, exits, net, chk, B):
    days = np.asarray(days).astype("datetime64[D]")
    return {"name": name, "days": days, "exit": np.asarray(exits).astype("datetime64[D]"),
            "net": np.asarray(net, float), "chk": np.asarray(chk, float), "B": {k: np.asarray(v) for k, v in B.items()}}


def _zsub(p, m):
    return {"name": p["name"], "days": p["days"][m], "exit": p["exit"][m], "net": p["net"][m], "chk": p["chk"][m],
            "B": {k: v[m] for k, v in p["B"].items()}}


def choose_zone(pops, min_per_year=ZONE_MIN_PER_YEAR, finalists=ZONE_FINALISTS):
    """The declared rule on populations (each: days, net, chk, buckets). -> (zone or None, {pop: eval} of the
    winner, finalists table, {pop: eval} of the setup alone)."""
    prep = []
    for p in pops:
        if len(p["net"]) < 30:
            return None, {}, pd.DataFrame(), {}
        boot = Boot(p["days"])
        di = np.searchsorted(boot.days, p["days"])
        prep.append((p, boot, di, min_per_year * _years(p["days"])))
    base = {p["name"]: zone_eval(b, di, p["net"], p["chk"], np.ones(len(di), bool)) for p, b, di, _ in prep}
    scr = [zone_screen(di, p["net"], p["B"], len(b.days)) for p, b, di, _ in prep]
    elig = np.all([s[0] >= mn for s, (_, _, _, mn) in zip(scr, prep)], axis=0)
    score = np.min([s[2] for s in scr], axis=0)
    base_lb = min(base[p["name"]]["lo"] for p, _, _, _ in prep)
    ok = elig & np.isfinite(score)
    order = [int(i) for i in np.argsort(-np.where(ok, score, -np.inf)) if ok[i]][:finalists]
    rows = []
    best, best_key = None, None
    for i in order:
        z = ZONE_CANDS[i]
        ev = {}
        for p, b, di, mn in prep:
            ev[p["name"]] = zone_eval(b, di, p["net"], p["chk"], zone_mask(z, p["B"]))
        qual = all(e["n"] >= mn and e["diff_lo"] > 0 and e["chk_lo"] > 0 for e, (_, _, _, mn) in
                   zip(ev.values(), prep))
        sc = min(e["strict"] for e in ev.values())
        row = {"zone": zone_key(z), "text": zone_text(z), "qualifies": bool(qual), "score": sc,
               "screen": float(score[i])}
        for nm, e in ev.items():
            row.update({"%s_%s" % (nm, k): v for k, v in e.items()})
        rows.append(row)
        key = (sc, sum(e["n"] for e in ev.values()))
        if qual and (best is None or key > best_key):
            best, best_key = (z, ev), key
    T = pd.DataFrame(rows)
    if len(T):
        T = T.sort_values(["qualifies", "score"], ascending=[False, False]).reset_index(drop=True)
    if best is None:
        return None, {}, T, base
    return best[0], best[1], T, base


def walk_forward(pops, years=ZONE_WF_YEARS, min_per_year=ZONE_MIN_PER_YEAR):
    """The search replayed: for each year, choose with the trades that had exited before 1 Jan, judge on that year.
    -> (rows by year, {pop: pooled inside minus outside with its 95% interval and the verdict})"""
    rows, pool = [], {p["name"]: [] for p in pops}
    for Y in years:
        cut, nxt = np.datetime64("%d-01-01" % Y), np.datetime64("%d-01-01" % (Y + 1))
        train = [_zsub(p, p["exit"] < cut) for p in pops]
        test = [_zsub(p, (p["days"] >= cut) & (p["days"] < nxt)) for p in pops]
        if any(len(t["net"]) < 30 for t in train) or any(len(t["net"]) == 0 for t in test):
            rows.append({"year": Y, "zone": "", "text": "too few trades to choose", "chosen": False})
            continue
        z, _, _, _ = choose_zone(train, min_per_year)
        row = {"year": Y, "zone": zone_key(z), "text": zone_text(z), "chosen": z is not None}
        for t in test:
            row["%s_n" % t["name"]] = len(t["net"])
            row["%s_net_all" % t["name"]] = float(t["net"].mean())
            if z is not None:
                m = zone_mask(z, t["B"])
                row["%s_n_in" % t["name"]] = int(m.sum())
                row["%s_net_in" % t["name"]] = float(t["net"][m].mean()) if m.any() else np.nan
                row["%s_net_out" % t["name"]] = float(t["net"][~m].mean()) if (~m).any() else np.nan
                pool[t["name"]].append((t["days"], t["net"], m))
        rows.append(row)
    res = {}
    for nm, parts in pool.items():
        if not parts:
            res[nm] = {"years": 0, "verdict": "NO ZONE CHOSEN"}
            continue
        d = np.concatenate([x[0] for x in parts])
        v = np.concatenate([x[1] for x in parts])
        m = np.concatenate([x[2] for x in parts])
        if not m.any() or m.all():
            res[nm] = {"years": len(parts), "n_in": int(m.sum()), "verdict": "NOT SHOWN"}
            continue
        boot = Boot(d)
        e = zone_eval(boot, np.searchsorted(boot.days, d), v, v, m)
        verdict = "HOLDS" if e["diff_lo"] > 0 else ("WORSE" if e["diff_hi"] < 0 else "NOT SHOWN")
        res[nm] = {"years": len(parts), "n_in": e["n"], "n_out": e["n_out"], "net_in": e["net"],
                   "net_out": e["net_out"], "diff": e["diff"], "diff_lo": e["diff_lo"], "diff_hi": e["diff_hi"],
                   "verdict": verdict}
    return pd.DataFrame(rows), res


# ------------------------------------------------------------------------------------------------- the zones command
def read_hashed_run(folder, files):
    """A run folder's files, refused when one does not match its outputs.sha256."""
    folder = Path(folder)
    rec = {}
    hf = folder / "outputs.sha256"
    if hf.is_file():
        for ln in hf.read_text(encoding="utf-8").splitlines():
            parts = ln.split("  ", 1)
            if len(parts) == 2:
                rec[parts[1].strip()] = parts[0].strip()
    for f in files:
        h = hashlib.sha256((folder / f).read_bytes()).hexdigest()
        if rec.get(f) != h:
            raise ValueError("%s does not match %s - refusing" % (folder / f, hf))
    return rec


def latest_run(base, prefix, need):
    runs = sorted(p for p in (Path(base) / prefix).glob(prefix + "_*") if all((p / f).is_file() for f in need))
    return runs[-1] if runs else None


def picks_zone_table(doc, tags_dir, ohlcv, M, log=print):
    """Every tagged setup entry of D and ENS with its net at the primary exit, the lift over the model's D1 entry on
    the same pick, and the zone at the close before its entry."""
    read_hashed_run(tags_dir, ["setup_tags.parquet", "setup_trades.parquet"])
    L = pd.read_parquet(Path(tags_dir) / "setup_trades.parquet")
    W = pd.read_parquet(Path(tags_dir) / "setup_tags.parquet")[["trade_id", "d1_net_d5", "d1_net_fresh"]]
    L = L.merge(W[["trade_id"] + [c for c in ("d1_net_d5", "d1_net_fresh") if c not in L.columns]], on="trade_id",
                how="left")
    pe = {s["id"]: s["primary_exit"] for s in doc["setups"]}
    d5 = L["setup"].map(pe).eq("original_d5").to_numpy()
    L["net"] = np.where(d5, L["net_d5"], L["net_fresh"])
    L["chk"] = L["net"] - np.where(d5, L["d1_net_d5"], L["d1_net_fresh"])
    L["day"] = pd.to_datetime(L["entry_date"]).to_numpy().astype("datetime64[D]")
    L["exit"] = pd.to_datetime(np.where(d5, L["exit_d5_date"], L["exit_fresh_date"])).to_numpy().astype("datetime64[D]")
    for d in ZDIM:
        L[d] = np.int8(-1)
    syms = sorted(L["symbol"].astype(str).unique())
    found = 0
    for i in range(0, len(syms), 100):
        bars = ohlcv(syms[i:i + 100])
        for s, (dates, o, h, l, c, v) in bars.items():
            dates = np.asarray(dates).astype("datetime64[D]")
            z = zone_buckets(zone_values(dates, o, h, l, c, v, M))
            rows = np.flatnonzero(L["symbol"].to_numpy() == s)
            j = np.searchsorted(dates, L["day"].to_numpy()[rows])
            ok = (j > 0) & (j < len(dates))
            ok[ok] &= dates[j[ok]] == L["day"].to_numpy()[rows][ok]
            for d in z:
                col = L[d].to_numpy(copy=True)
                col[rows[ok]] = z[d][j[ok] - 1]
                L[d] = col
            found += int(ok.sum())
    keep = np.isfinite(L["net"].to_numpy(float)) & np.isfinite(L["chk"].to_numpy(float)) & ~pd.isna(L["exit"])
    log(" picks: %d setup entries of %d picks (%d settled); the zone at the close before the entry found for %d" % (
        len(L), L["trade_id"].nunique(), int(keep.sum()), found))
    return L[keep].reset_index(drop=True)


def market_zone_table(doc, setups, panel_path, ohlcv, forget, M, log=print, d_from=MARKET_FROM, symbols=None):
    """The whole market: every stock-day in the panel from d_from as a pseudo-pick, each setup's trades held 5
    sessions, their zones, and the excess over buying every stock at the same open (same hold)."""
    feats = frozen_features(doc)
    P, want = panel_frame(panel_path, feats, d_from - np.timedelta64(400, "D"), symbols, log)
    idx = P.groupby("symbol", sort=False, observed=True).indices
    syms = sorted(idx)
    trades, bdays, bvals, done = [], [], [], 0
    for i in range(0, len(syms), 100):
        chunk = syms[i:i + 100]
        bars = ohlcv(chunk)
        for s in chunk:
            if s not in bars:
                continue
            dates, o, h, l, c, v = bars[s]
            dates = np.asarray(dates).astype("datetime64[D]")
            F, have = align_panel(P.iloc[idx[s]], want, dates)
            T, (bd, bv) = market_symbol(dates, o, h, l, c, v, F, have, setups, M, d_from)
            if T is not None:
                T.insert(0, "symbol", s)
                trades.append(T)
            bdays.append(bd)
            bvals.append(bv)
            done += 1
        forget(chunk)
        log(" market: %d of %d stocks" % (min(i + 100, len(syms)), len(syms)))
    if not trades:
        raise ValueError("no setup ever entered in the whole market - check the panel and the bars")
    T = pd.concat(trades, ignore_index=True)
    b = pd.Series(np.concatenate(bvals)).groupby(np.concatenate(bdays)).mean()
    T["bench"] = b.reindex(pd.DatetimeIndex(T["day"].to_numpy())).to_numpy(float)
    T["chk"] = T["net"] - T["bench"]
    log(" market: %d stocks, %d setup trades (%s)" % (done, len(T), ", ".join(
        "%s %d" % (k, v) for k, v in T["setup"].value_counts().reindex([s["id"] for s in doc["setups"]]).fillna(0)
        .astype(int).items())))
    return T, b


def pops_of(T, names, col="pop"):
    out = []
    for nm in names:
        S = T[T[col] == nm] if col in T.columns else T
        out.append(_pop(nm, S["day"], S["exit"], S["net"], S["chk"], {d: S[d].to_numpy() for d in ZDIM}))
    return out


def rupees(net, per_year):
    """Rs a year at Rs 1 lakh a trade: net % x trades a year x Rs 1,000."""
    return net * per_year * 1000.0 if np.isfinite(net) else np.nan


def zone_section(sid, name, part, pops, zone, ev, base, T, wf, wfres, chk_name):
    yrs = {p["name"]: _years(p["days"]) for p in pops}
    fm = lambda x, nd=2: "" if x is None or not np.isfinite(x) else ("%+.*f" % (nd, x))
    L = ["### %s - %s" % (part, "the zone: " + zone_text(zone) if zone else "no zone qualified"), "",
         "| | " + " | ".join("%s trades/yr | %s net %% per trade [95%%] | %s Rs a year at Rs 1 L a trade | %s %s [95%%]"
                             % (n, n, n, n, chk_name) for n in yrs) + " |",
         "|---|" + "---:|" * (4 * len(yrs))]

    def line(label, e, n_key="n"):
        cells = []
        for nm in yrs:
            x = e.get(nm)
            if not x:
                cells += ["", "", "", ""]
                continue
            py = x[n_key] / yrs[nm]
            cells += ["%.0f" % py, "%s [%s, %s]" % (fm(x["net"]), fm(x["lo"]), fm(x["hi"])),
                      "{:,.0f}".format(rupees(x["net"], py)), "%s [%s, %s]" % (fm(x["chk"]), fm(x["chk_lo"]),
                                                                              fm(x["chk_hi"]))]
        return "| %s | %s |" % (label, " | ".join(cells))
    L.append(line("the setup alone", base))
    if zone:
        L.append(line("inside the zone", ev))
        L.append("| outside the zone | " + " | ".join(
            "%.0f | %s | %s | " % (ev[nm]["n_out"] / yrs[nm], fm(ev[nm]["net_out"]),
                                   "{:,.0f}".format(rupees(ev[nm]["net_out"], ev[nm]["n_out"] / yrs[nm])))
            for nm in yrs) + "|")
        L += ["", "Inside minus outside (net %% per trade): %s." % "; ".join(
            "%s %s [%s, %s]" % (nm, fm(ev[nm]["diff"]), fm(ev[nm]["diff_lo"]), fm(ev[nm]["diff_hi"])) for nm in yrs)]
    q = int(T["qualifies"].sum()) if len(T) else 0
    L += ["", "Candidates tested: %d; finalists bootstrapped: %d; qualifying: %d." % (len(ZONE_CANDS), len(T), q), "",
          "**Out of sample (the search replayed year by year):** " + "; ".join(
              "%s %s%s" % (nm, r["verdict"], (" - inside %s vs outside %s, inside minus outside %s [%s, %s], %d "
                                               "years with a zone" % (fm(r["net_in"]), fm(r["net_out"]),
                                                                      fm(r["diff"]), fm(r["diff_lo"]),
                                                                      fm(r["diff_hi"]), r["years"]))
                                              if "diff" in r else "") for nm, r in wfres.items()), "",
          "| year | zone chosen with exits before 1 Jan | " + " | ".join(
              "%s trades | %s in zone | %s net in zone | %s net all" % (n, n, n, n) for n in yrs) + " |",
          "|---|---|" + "---:|" * (4 * len(yrs))]
    for r in wf.to_dict("records"):
        cells = []
        for nm in yrs:
            cells += [str(int(r["%s_n" % nm])) if np.isfinite(r.get("%s_n" % nm, np.nan)) else "",
                      str(int(r["%s_n_in" % nm])) if np.isfinite(r.get("%s_n_in" % nm, np.nan)) else "",
                      fm(r.get("%s_net_in" % nm, np.nan)), fm(r.get("%s_net_all" % nm, np.nan))]
        L.append("| %s | %s | %s |" % (r["year"], r["text"] if r.get("chosen") else "none (%s)" % r["text"],
                                       " | ".join(cells)))
    return L


def _clean(x):
    if isinstance(x, dict):
        return {k: _clean(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_clean(v) for v in x]
    if isinstance(x, (np.floating, float)):
        return None if not np.isfinite(x) else round(float(x), 6)
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.bool_,)):
        return bool(x)
    return x


def zones_hash(doc):
    return hashlib.sha256(_canon_json({k: v for k, v in doc.items() if k != "sha256"}).encode()).hexdigest()


def load_zones(base):
    """The newest zones run's SETUP_ZONES.json (hash-checked) -> (folder, doc) or (None, None)."""
    run = latest_run(base, "ZONES", [ZONES_FILE])
    if run is None:
        return None, None
    doc = json.loads((run / ZONES_FILE).read_text(encoding="utf-8"))
    if doc.get("sha256") != zones_hash(doc):
        raise ValueError("%s was changed after it was written - refusing (rerun setuplab zones)" % (run / ZONES_FILE))
    return run, doc


def pine_code(doc_z, ids):
    return PINE_CODE_TAG + "|" + "|".join("%s=%s" % (s, (doc_z["setups"][s]["market"] or {}).get("zone", ""))
                                          for s in ids)


def cmd_zones(a, log=print, data=None):
    fp, doc = load_frozen(a.frozen or None)
    conds = frozen_conds(doc)
    ids = [s["id"] for s in doc["setups"]]
    out = Path(a.out)
    tags = latest_run(out, "TAGS", ["setup_tags.parquet", "setup_trades.parquet"])
    if tags is None:
        print("REFUSED: no TAGS run under %s - run setuplab tag first" % (out / "TAGS"))
        return 3
    t0 = time.time()
    if data is None:
        data = LiveData(a.root, a.stage_e_any, panel=None)
    log("%s zones: freeze %s (sha256 %s); tags %s; panel %s" % (VERSION, fp.name, doc["sha256"][:16], tags.name,
                                                                  a.features))
    idx = data.index_closes(dict(ZONE_INDEX))
    M = market_dims(idx)
    LT = picks_zone_table(doc, tags, data.ohlcv, M, log)
    LT["pop"] = LT["engine"].astype(str)
    atr_line = "not checked (give --data <watchlist folder>)"
    if getattr(a, "data", None) and (Path(a.data) / "watchlist.parquet").is_file():
        WL = pd.read_parquet(Path(a.data) / "watchlist.parquet", columns=["symbol", "signal_day", "s_atr14"])
        WL["d"] = pd.to_datetime(WL["signal_day"]).to_numpy().astype("datetime64[D]")
        got, n_ok, n = [], 0, 0
        syms = sorted(WL["symbol"].astype(str).unique())
        for i in range(0, len(syms), 100):
            for s_, (dates, o, h, l, c, v) in data.ohlcv(syms[i:i + 100]).items():
                dates = np.asarray(dates).astype("datetime64[D]")
                g = WL[WL["symbol"] == s_]
                j = np.searchsorted(dates, g["d"].to_numpy())
                okj = (j < len(dates))
                okj[okj] &= dates[j[okj]] == g["d"].to_numpy()[okj]
                sa = atr_simple(h, l, c)
                x = g["s_atr14"].to_numpy(float)[okj]
                y = sa[j[okj]]
                m = np.isfinite(x) & np.isfinite(y)
                n += int(m.sum())
                n_ok += int((np.abs(x[m] - y[m]) < 1e-6).sum())
            data.forget(syms[i:i + 100])
        share = n_ok / n if n else np.nan
        atr_line = "%d of %d picks: pick_meta's s_atr14 = the simple ATR14 / close from the bars (within 1e-6)%s" % (
            n_ok, n, "" if share >= 0.99 else " - WARNING: below 99%: the whole market's and the chart's S1 use a "
                                              "different ATR from the picks' S1; send ZONES.md")
        log(" ATR check: " + atr_line)
    MT = None
    if not a.picks_only:
        MT, _ = market_zone_table(doc, conds, a.features, data.ohlcv, data.forget, M, log)
    run = new_run_dir(out / "ZONES", "ZONES")
    res = {"atr_check": atr_line, "file": ZONES_FILE, "tool": VERSION, "made_at": _dt.datetime.now(IST).isoformat(timespec="seconds"),
           "rule": ZONE_RULE, "dims": [list(d) for d in ZONE_DIMS], "freeze_sha256": doc["sha256"],
           "tags_run": tags.name, "panel": str(a.features), "whole_market": MT is not None, "setups": {}}
    md = ["# Setup zones - %s (%s)" % (time.strftime("%d %b %Y"), VERSION), "",
          "Freeze %s (sha256 %s); tags %s; whole market: %s." % (
              fp.name, doc["sha256"][:16], tags.name,
              "every stock-day in %s from %s (held 5 sessions)" % (a.features, MARKET_FROM) if MT is not None
              else "not run (--picks-only)"), "",
          "**The rule (declared before any zone result):** " + ZONE_RULE, "",
          "**ATR check** (S1's 1-ATR dip; the whole market and the chart compute the ATR themselves): " + atr_line, "",
          "Money: Rs a year at Rs 1 L a trade = net %% per trade x trades a year x Rs 1,000 (one position of Rs 1 L per "
          "trade, no compounding, skipped trades in cash).", "", "## Verdicts", "",
          "| setup | picks: zone | picks: out of sample (D / ENS) | whole market: zone | whole market: out of sample |",
          "|---|---|---|---|---|"]
    body, fin_all, wf_all = [], [], []
    for s in doc["setups"]:
        sid = s["id"]
        r = {"name": s["name"], "primary_exit": s["primary_exit"]}
        body += ["", "## %s - %s" % (sid, s["name"]), ""]
        parts = [("picks", pops_of(LT[LT["setup"] == sid], ["D", "ENS"]), "lift over D1")]
        if MT is not None:
            S = MT[MT["setup"] == sid]
            parts.append(("market", [_pop("MKT", S["day"], S["exit"], S["net"], S["chk"],
                                          {d: S[d].to_numpy() for d in ZDIM})], "excess"))
        for part, pops, chk in parts:
            z, ev, T, base = choose_zone(pops)
            wf, wfres = walk_forward(pops)
            T.insert(0, "part", part), T.insert(0, "setup", sid)
            wf.insert(0, "part", part), wf.insert(0, "setup", sid)
            fin_all.append(T), wf_all.append(wf)
            r[part] = _clean({"zone": zone_key(z), "text": zone_text(z), "inside": ev, "alone": base,
                              "out_of_sample": wfres,
                              "holds": bool(z is not None and all(v["verdict"] == "HOLDS" for v in wfres.values()))})
            if not base:
                body += ["### %s - too few trades" % part, ""]
                continue
            body += zone_section(sid, s["name"], "Picks (D and ENS, primary exit %s)" % s["primary_exit"]
                                 if part == "picks" else "Whole market (every stock, held 5 sessions)",
                                 pops, z, ev, base, T, wf, wfres, chk) + [""]
        if MT is None:
            r["market"] = None
        res["setups"][sid] = r
        vv = lambda p: "" if not r.get(p) else " / ".join(x["verdict"] for x in r[p]["out_of_sample"].values())
        md.append("| %s | %s | %s | %s | %s |" % (
            sid, (r["picks"] or {}).get("text", ""), vv("picks"),
            (r["market"] or {}).get("text", "not run") if r.get("market") is not None else "not run", vv("market")))
    md += ["", "HOLDS = inside beat outside out of sample (95%). NOT SHOWN = it did not. A zone is a hypothesis "
               "until the forward record (ON TIME scans) confirms it; the nightly scan marks every setup IN ZONE or "
               "OUTSIDE and the forward record keeps both."] + body
    res["pine_code"] = pine_code(res, ids)
    res["sha256"] = zones_hash(res)
    (run / ZONES_FILE).write_text(json.dumps(res, indent=1), encoding="utf-8")
    (run / "ZONES.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    (run / "PINE_ZONE_CODE.txt").write_text(res["pine_code"] + "\n", encoding="ascii")
    pd.concat(fin_all, ignore_index=True).to_csv(run / "zone_finalists.csv", index=False)
    pd.concat(wf_all, ignore_index=True).to_csv(run / "walk_forward.csv", index=False)
    LT.drop(columns=["pop"]).to_parquet(run / "picks_zone_trades.parquet", index=False)
    names = [ZONES_FILE, "ZONES.md", "PINE_ZONE_CODE.txt", "zone_finalists.csv", "walk_forward.csv",
             "picks_zone_trades.parquet"]
    if MT is not None:
        MT.to_parquet(run / "market_zone_trades.parquet", index=False)
        names.append("market_zone_trades.parquet")
    write_hashes(run, names)
    for sid, r in res["setups"].items():
        for part in ("picks", "market"):
            if r.get(part):
                log(" %s %-6s %s%s" % (sid, part, r[part]["text"], "  (out of sample: %s)" % " / ".join(
                    v["verdict"] for v in r[part]["out_of_sample"].values())))
    log(" pine code: %s" % res["pine_code"])
    log("ZONES WRITTEN -> %s (%.1f min)" % (run, (time.time() - t0) / 60))
    return 0


# ======================================================================================== v0.9: runners (no dip)
RUN_FILE = "RUNNER_CANDIDATES.json"
RUN_DIP = 2.0                 # % - a close this far below the D1 open is a dip (Karan, 8 Nov: a close 2% below)
RUN_RT = 5.0                  # % - the D5 close this far above the D1 open = the right tail (10% also measured)
RUN_RT2 = 10.0
RUN_MIN_PER_YEAR = 25         # trades a year a rule must keep in each engine
RUN_MAX_BAD_YEARS = 2         # years with net <= 0 a rule may have
RUN_FINALISTS = 60            # the best by the quick screen get the full block bootstrap
RUN_TRIPLE_PAIRS = 150        # the best pairs that get a third (rank / agreement / weekday / context / gap) condition
RUN_TOP = 5
RUN_OVERLAP = 0.70
RUN_Z = 1.96
RUN_WF_YEARS = (2022, 2023, 2024, 2025, 2026)
RUN_WF_MIN = 300              # picks a training window needs in each engine
RUN_ALIGN_TOL = 1e-4          # a pick's own bars must give the watchlist's D1-D5 closes (relative difference)
RUN_MONEY_FROM = np.datetime64("2022-01-01")
RUN_CAPITAL = 5e5             # Rs 5 L
RUN_SLOTS = (2, 3, 5, 7)
RUN_MTF_DAY = 0.0004          # Zerodha MTF: 0.04% a day on the borrowed amount
RUN_STOP_BUF = 0.0005         # the breakout buy-stop sits 0.05% above the signal-day high
RUN_STRONG = 0.7              # a strong D1: green and the close in the top 30% of the day's range
RUN_ANAT_B = 200              # day-block resamples for the AUC's standard deviation
RUN_RULE = (
    "runners v1, declared 8 Nov 2026 before any result on real picks. Karan: find which model picks will NOT dip and "
    "buy them at the model's open or on an event; 5-7 quality trades a week together with the dip setups; don't be "
    "conservative. PICKS: engines D and ENS, ranks 1-10, bought at the D1 open (the model's own price), sold at the "
    "D5 close, 0.35 pp costs; a pick whose own daily bars do not give the watchlist's D1-D5 closes is left out "
    "(counted). DIP = a close on D1-D4 at least 2% below the D1 open (Karan's choice: the closes a dip setup acts "
    "on); also measured: the intraday low 2% below on D1-D5, and a close 1 ATR below. RIGHT TAIL = the D5 close 5% "
    "or more above the D1 open (10% also shown). RUNNER = no dip and the right tail. A RULE = one to three "
    "conditions known at the signal close (a feature rose / fell on the signal day; a zone range at the signal "
    "close; the model's rank; the other engine picking it too; the weekday of D1; the market context and the "
    "stock's state at the pick) or at the D1 open (the gap, seen in the pre-open); it buys every pick it selects at "
    "the D1 open. SEARCH, in both engines: every single condition, every pair from different families, and the 150 "
    "best pairs with one more rank / agreement / weekday / context / gap condition; the 60 best by a quick 95% lower "
    "bound (day-clustered) get the full block bootstrap. A rule QUALIFIES when, in both engines: 25 or more trades a "
    "year; net per trade 95% interval above 0; its lift over every pick of the same days (net minus that day's mean "
    "over all the engine's picks) 95% interval above 0; net <= 0 in at most 2 of its years; EVERY CONDITION EARNS ITS "
    "PLACE: the rule's net per trade minus the net of the trades its simpler version (that condition dropped) adds, "
    "95% interval above 0 (the quick screen applies the same test before the bootstrap, so a narrower rule never "
    "displaces the simpler one, with more trades, by luck). Score = the lower 95% bound of net per trade in the "
    "weaker engine. CANDIDATES for the forward paper test = the top 5 qualifiers that "
    "are not versions of each other (one's conditions within the other's, or 70% of the same D trades); the best 5 "
    "by score are listed too, qualified or not. Plain 95% per rule (don't be conservative): some rules pass by luck, "
    "so the whole search is replayed year by year 2022-2026 - choose the candidates with the picks whose D5 exit was "
    "before 1 January, judge their picks (each pick once) on that year: HOLDS when the pooled lift over all picks is "
    "above 0 out of sample (95%), WORSE when below, else NOT SHOWN. EVENTS on the candidates' picks and on all "
    "picks, each against the D1 open on the same picks: the breakout (a buy-stop 0.05% above the signal-day high, "
    "live on D1 and D2), the D2 open after a strong D1 (green, the close in the top 30% of its range), the D1 close "
    "after a strong D1. MONEY: Rs 5 L in 2 / 3 / 5 / 7 equal slots, profits reinvested, no MTF and MTF 2x (0.04% a "
    "day on the borrowed half), entries from 2022, one position per pick (its earliest entry); the dip arm = the "
    "frozen setups' trades in the newest ZONES run, IN or OUT of their picks zone; the same open: the source with "
    "the higher net per trade first, then the model's rank.")
CTX_ATOMS = (
    ("BULLSTATE", "pre_state_bullish", ">", 0.5, "state", "a bullish stock state at the pick (S01-S03)"),
    ("BEARSTATE", "pre_state_bearish", ">", 0.5, "state", "a bearish stock state at the pick (S08/S09)"),
    ("NIFTY_UP", "pre_nifty_vs_ma50", ">", 0.0, "nifty", "NIFTY above its 50-day average"),
    ("NIFTY_DN", "pre_nifty_vs_ma50", "<", 0.0, "nifty", "NIFTY below its 50-day average"),
    ("MKT_BULL", "pre_env_code", "<=", 1.0, "env", "a bullish market (tl_context: broad or narrow bullish)"),
    ("MKT_BEAR", "pre_env_code", ">=", 3.0, "env", "a bearish market (tl_context: broad bearish / high stress)"),
    ("VIX_LOW", "pre_vix_pct250", "<", 0.5, "vix", "India VIX in the lower half of its last year"),
    ("VIX_HIGH", "pre_vix_pct250", ">=", 0.5, "vix", "India VIX in the upper half of its last year"),
    ("BREADTH_UP", "pre_ad_ratio_10", ">=", 0.5, "breadth", "more stocks rising than falling over 10 days"),
    ("BREADTH_DN", "pre_ad_ratio_10", "<", 0.5, "breadth", "more stocks falling than rising over 10 days"),
    ("NOT_OVEREXT", "pre_state_overextended", "<", 0.5, "overext", "not overextended at the pick"),
    ("VOL_ELEV", "pre_state_vol_elevated", ">", 0.5, "volstate", "volatility elevated at the pick"))
RUN_CTX_GROUPS = {"rank", "agree", "weekday", "gap", "state", "nifty", "env", "vix", "breadth", "overext", "volstate"}
RUN_OPS = dict(OPS, **{"==": np.equal})
WEEKDAYS = ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday")
EVENT_WORDS = {"E0": "D1 open (the model's own buy; AMO / pre-open)",
               "E1": "breakout: buy-stop 0.05% above the signal-day high, live D1-D2 (GTT)",
               "E2": "D2 open after a strong D1 (green, close in the top 30% of its range; AMO)",
               "E3": "D1 close after a strong D1 (at the screen about 15:20)"}


def _bci(boot, days, vals):
    """The 95% block-bootstrap interval of a mean (days: among the boot's days)."""
    return boot.ci_idx(np.searchsorted(boot.days, np.asarray(days)), np.asarray(vals, float))


def run_bars(book, ohlcv, forget, M):
    """Per pick, from the stock's own daily bars: highs / lows / closes of D0..D5 (D0 = the signal day, Dk = its k-th
    own bar after it) and every zone value at the D0 close."""
    n = book.n
    H, L, Cb = (np.full((n, 6), np.nan) for _ in range(3))
    Z = {d[0]: np.full(n, np.nan) for d in ZONE_DIMS}
    sd = np.asarray(book.signal_day).astype("datetime64[D]")
    rows_of = pd.Series(np.arange(n)).groupby(book.symbols).indices
    syms = sorted(rows_of)
    for i in range(0, len(syms), 100):
        part = syms[i:i + 100]
        for s_, (dates, o, h, l, c, v) in ohlcv(part).items():
            rows = np.asarray(rows_of.get(s_, []), dtype=np.int64)
            dates = np.asarray(dates).astype("datetime64[D]")
            if not len(rows) or not len(dates):
                continue
            j = np.searchsorted(dates, sd[rows])
            ok = j < len(dates)
            ok[ok] &= dates[j[ok]] == sd[rows][ok]
            rows, j = rows[ok], j[ok]
            if not len(rows):
                continue
            h, l, c = (np.asarray(x, float) for x in (h, l, c))
            for k in range(6):
                v_ = j + k < len(dates)
                H[rows[v_], k], L[rows[v_], k], Cb[rows[v_], k] = h[j[v_] + k], l[j[v_] + k], c[j[v_] + k]
            if M is not None:
                z = zone_values(dates, o, h, l, c, v, M)
                for dn in Z:
                    Z[dn][rows] = z[dn][j]
        forget(part)
    return {"H": H, "L": L, "Cb": Cb, "Z": Z}


def runner_labels(O1, C, H, L, atr):
    """C / H / L: (n, 6), column k = Dk (0 = the signal day), all finite. -> the labels and outcomes."""
    lo4 = C[:, 1:5].min(1)
    r = C[:, 5] / O1 - 1
    fa = np.isfinite(atr)
    out = {"dip": lo4 <= O1 * (1 - RUN_DIP / 100), "dip_low": L[:, 1:6].min(1) <= O1 * (1 - RUN_DIP / 100),
           "dip_atr": fa & (lo4 <= O1 * (1 - np.where(fa, atr, 0.0))),
           "rt5": r * 100 >= RUN_RT, "rt10": r * 100 >= RUN_RT2, "net": r * 100 - COST,
           "mfe": (H[:, 1:6].max(1) / O1 - 1) * 100, "mae": (L[:, 1:6].min(1) / O1 - 1) * 100}
    out["runner"] = ~out["dip"] & out["rt5"]
    return out


def run_sub(P, m):
    """The same table for some picks (the day index is rebuilt by run_index)."""
    out = {}
    for k, v in P.items():
        if k in ("days", "counts"):
            out[k] = v
        elif isinstance(v, dict):
            out[k] = {kk: (vv[m] if isinstance(vv, np.ndarray) and len(vv) == len(m) else vv) for kk, vv in v.items()}
        elif isinstance(v, np.ndarray) and v.ndim and len(v) == len(m):
            out[k] = v[m]
        else:
            out[k] = v
    return out


def run_index(P):
    """Day index, the lift (net minus the day's mean net over every pick of the table), years."""
    P["days"] = np.unique(P["day"])
    P["di"] = np.searchsorted(P["days"], P["day"])
    nd = len(P["days"])
    s = np.bincount(P["di"], weights=P["net"], minlength=nd)
    c = np.bincount(P["di"], minlength=nd)
    P["lift"] = P["net"] - (s / np.maximum(c, 1))[P["di"]]
    P["year"] = pd.DatetimeIndex(P["day"]).year.to_numpy()
    P["years"] = _years(P["day"])
    return P


def runner_table(book, bars, others, name):
    """Every complete pick of one engine (book: that engine's picks; bars: their rows of run_bars): the labels, the
    net, the lift and every condition field. others: {(signal day, symbol): the other engine's rank}."""
    C = np.column_stack([book.sc] + [book.C[:, k] for k in range(1, 6)])
    O1 = book.O[:, 1]
    with np.errstate(invalid="ignore", divide="ignore"):
        scale = book.sc / bars["Cb"][:, 0]           # a later price adjustment in the cache scales a stock's bars
        H, L, Cb = (bars[k] * scale[:, None] for k in ("H", "L", "Cb"))
        dev = np.abs(Cb[:, 1:6] / C[:, 1:6] - 1)
        have = np.isfinite(Cb).all(1) & np.isfinite(H).all(1) & np.isfinite(L).all(1)
        aligned = have & np.isfinite(dev).all(1) & (np.where(np.isfinite(dev), dev, 1.0) <= RUN_ALIGN_TOL).all(1)
        scaled = aligned & (np.abs(np.where(np.isfinite(scale), scale, 1.0) - 1) > 1e-6)
    keep = book.ok & aligned & np.isfinite(O1) & np.isfinite(book.O[:, 2]) & np.isfinite(C).all(1)
    cal = np.asarray(book.cal).astype("datetime64[D]")
    sd = np.asarray(book.signal_day).astype("datetime64[D]")
    P = {"name": name, "ids": book.ids, "symbols": book.symbols, "day": sd, "d1": cal[book.i1],
         "d5": cal[np.minimum(book.i1 + 4, len(cal) - 1)], "ent": book.i1.astype(np.int64),
         "ex": (book.i1 + 4).astype(np.int64), "rank": book.rank.astype(float), "atr": book.atr, "O": book.O, "C": C,
         "H": H, "L": L, "gap_d1": (O1 / book.sc - 1) * 100,
         "weekday_d1": pd.DatetimeIndex(cal[book.i1]).weekday.to_numpy().astype(float)}
    o_rank = np.array([others.get((d, s), np.nan) for d, s in zip(sd, book.symbols)], float)
    fo = np.isfinite(o_rank)
    P["agree"] = fo.astype(float)
    P["agree3"] = (fo & (np.where(fo, o_rank, 99) <= 3) & (book.rank <= 3)).astype(float)
    P["fc"] = {f: book.F[f + "_change"][:, 1] for f in book.features if f + "_change" in book.F}
    P["fv"] = {f: book.F[f][:, 1] for f in book.features if f in book.F}
    P["zv"] = {k: np.asarray(v, float) for k, v in bars["Z"].items()}
    P["zb"] = zone_buckets(P["zv"])
    P["snap"] = {}
    for c in book.wl.columns:
        if str(c).startswith("pre_"):
            x = pd.to_numeric(book.wl[c], errors="coerce").to_numpy(float)
            if np.isfinite(x).any():
                P["snap"][str(c)] = x
    P = run_sub(P, keep)
    P.update(runner_labels(P["O"][:, 1], P["C"], P["H"], P["L"], P["atr"]))
    P["counts"] = {"settled": int(book.ok.sum()), "with_bars": int((book.ok & have).sum()),
                   "aligned": int((book.ok & aligned).sum()), "rescaled": int((book.ok & scaled).sum()),
                   "complete": int(keep.sum())}
    return run_index(P)


def run_atoms(P):
    """Every single condition: (id, family, machine condition, words)."""
    A = []
    for f in sorted(P["fc"]):
        for op, w in ((">", "rose"), ("<", "fell")):
            A.append(("F|%s%s0" % (f, op), "f:" + f, [f + "_change", op, 0], "%s %s on the signal day" % (f, w)))
    for dim, lo, hi in ZONE_RANGES:
        A.append(("Z|%s:%d:%d" % (dim, lo, hi), "z:" + dim, ["zone:" + dim, "in", [lo, hi]],
                  zone_text(((dim, lo, hi),)) + " at the signal close"))
    A += [("P|rank1", "rank", ["rank", "<=", 1], "the model's rank 1"),
          ("P|top3", "rank", ["rank", "<=", 3], "the model's ranks 1-3"),
          ("P|rank4_10", "rank", ["rank", ">=", 4], "the model's ranks 4-10"),
          ("P|agree", "agree", ["agree", ">=", 1], "the other engine picked it too (its ranks 1-10)"),
          ("P|agree3", "agree", ["agree3", ">=", 1], "both engines have it in their ranks 1-3"),
          ("P|alone", "agree", ["agree", "<=", 0], "only this engine picked it")]
    for w, nm in enumerate(WEEKDAYS):
        A.append(("W|%d" % w, "weekday", ["weekday_d1", "==", w], "D1 (the buy day) is a %s" % nm))
    for nm, col, op, v, grp, words in CTX_ATOMS:
        if col in P["snap"]:
            A.append(("C|" + nm, grp, ["snap:" + col, op, v], words))
    A += [("G|up0", "gap", ["gap_d1", ">=", 0], "D1 opens at or above the signal close (seen in the pre-open)"),
          ("G|up1", "gap", ["gap_d1", ">=", 1], "D1 opens 1% or more above the signal close (pre-open)"),
          ("G|dn0", "gap", ["gap_d1", "<", 0], "D1 opens below the signal close (pre-open)"),
          ("G|dn1", "gap", ["gap_d1", "<=", -1], "D1 opens 1% or more below the signal close (pre-open)")]
    return A


def atom_mask(cond, P):
    f, op, v = cond
    if f.startswith("zone:"):
        b = P["zb"][f[5:]]
        return (b >= v[0]) & (b <= v[1])
    if f.endswith("_change"):
        x = P["fc"].get(f[:-7])
    elif f.startswith("snap:"):
        x = P["snap"].get(f[5:])
    else:
        x = P.get(f)
    if x is None:
        return np.zeros(len(P["net"]), bool)
    x = np.asarray(x, float)
    ok = np.isfinite(x)
    r = np.zeros(len(x), bool)
    r[ok] = RUN_OPS[op](np.round(x[ok], 9), round(float(v), 9))
    return r


def run_cands(atoms, pairs_from=None):
    """Singles and every pair from different families (pairs_from None), or the given pairs with one more
    rank / agreement / weekday / context / gap condition."""
    grp = [a[1] for a in atoms]
    if pairs_from is None:
        n = len(atoms)
        return [(i,) for i in range(n)] + [(i, j) for i in range(n) for j in range(i + 1, n) if grp[i] != grp[j]]
    ctx = [i for i, a in enumerate(atoms) if a[1] in RUN_CTX_GROUPS]
    out = []
    for c in pairs_from:
        g = {grp[x] for x in c}
        out += [tuple(sorted(c + (k,))) for k in ctx if grp[k] not in g]
    return list(dict.fromkeys(out))


def _cmask(AM, c):
    m = AM[c[0]]
    for x in c[1:]:
        m = m & AM[x]
    return m


def _clb(di, x, nd):
    """Trades, mean and the quick 95% lower bound (standard error clustered by day)."""
    n = len(x)
    if n < 2:
        return n, (float(x.mean()) if n else np.nan), np.nan
    S = np.bincount(di, weights=x, minlength=nd)
    N = np.bincount(di, minlength=nd)
    m = S.sum() / n
    r = S - m * N
    g = int((N > 0).sum())
    se = math.sqrt(float((r * r).sum()) * g / max(g - 1, 1)) / n
    return n, m, m - RUN_Z * se


def _dlb(di_c, x_c, di_x, x_x, nd):
    """The quick 95% lower bound of mean(x_c) - mean(x_x), both groups clustered by day (delta method)."""
    nc, nx = len(x_c), len(x_x)
    if nc < 2 or nx < 2:
        return np.nan
    mc, mx = float(x_c.mean()), float(x_x.mean())
    r = np.bincount(di_c, weights=x_c - mc, minlength=nd) / nc - np.bincount(di_x, weights=x_x - mx, minlength=nd) / nx
    g = int(((np.bincount(di_c, minlength=nd) + np.bincount(di_x, minlength=nd)) > 0).sum())
    return (mc - mx) - RUN_Z * math.sqrt(float((r * r).sum()) * g / max(g - 1, 1))


def run_extras(AM, c):
    """For each condition of a rule: the trades its simpler version (that condition dropped) adds."""
    m = _cmask(AM, c)
    return m, ([_cmask(AM, c[:k] + c[k + 1:]) & ~m for k in range(len(c))] if len(c) > 1 else [])


def run_earn_quick(P, AM, c):
    """The smallest quick 95% lower bound, over the rule's conditions, of: its net per trade minus the net of the
    trades its simpler version adds (+inf for one condition; -inf when a simpler version adds no trades)."""
    if len(c) < 2:
        return np.inf
    m, extras = run_extras(AM, c)
    ic, nd, out = np.flatnonzero(m), len(P["days"]), np.inf
    for x in extras:
        ix = np.flatnonzero(x)
        v = _dlb(P["di"][ic], P["net"][ic], P["di"][ix], P["net"][ix], nd)
        if not np.isfinite(v) or v <= 0:
            return v if np.isfinite(v) else -np.inf
        out = min(out, v)
    return out


def run_screen(Ps, AMs, cands):
    """-> (candidates, engines, 4): trades, mean net, quick 95% lower bound of the net, of the lift."""
    R = np.full((len(cands), len(Ps), 4), np.nan)
    for e, (P, AM) in enumerate(zip(Ps, AMs)):
        di, net, lift, nd = P["di"], P["net"], P["lift"], len(P["days"])
        for i, c in enumerate(cands):
            idx = np.flatnonzero(_cmask(AM, c))
            R[i, e, 0] = len(idx)
            if len(idx) < 2:
                continue
            n, m, lb = _clb(di[idx], net[idx], nd)
            R[i, e, 1:3] = m, lb
            R[i, e, 3] = _clb(di[idx], lift[idx], nd)[2]
    return R


def run_eval(boot, P, m, extras=()):
    """One rule in one engine: trades, net per trade and its 95% interval, the lift and its interval, years, rates;
    earn_lo = the smallest 95% lower bound of (its net - the net of the trades a simpler version adds)."""
    nd = len(boot.days)
    di = np.searchsorted(boot.days, P["day"][m])
    net, lift = P["net"][m], P["lift"][m]
    n = int(m.sum())
    r = {"n": n, "per_year": n / P["years"], "net": float(net.mean()) if n else np.nan,
         "lift": float(lift.mean()) if n else np.nan, "lo": np.nan, "hi": np.nan, "lift_lo": np.nan,
         "lift_hi": np.nan, "years": 0, "bad_years": 0, "earn_lo": np.nan}
    if extras:
        los = []
        for x in extras:
            if n < 2 or x.sum() < 2:
                los.append(-np.inf)
                continue
            los.append(boot.ci_diff(di, net, np.searchsorted(boot.days, P["day"][x]), P["net"][x])[0])
        r["earn_lo"] = float(np.nanmin(los)) if np.isfinite(los).any() else -np.inf
    if n >= 2:
        X = boot.M @ np.column_stack([np.bincount(di, weights=net, minlength=nd), np.bincount(di, minlength=nd),
                                      np.bincount(di, weights=lift, minlength=nd)]).astype(float)
        with np.errstate(invalid="ignore", divide="ignore"):
            cnt = np.where(X[:, 1] > 0, X[:, 1], np.nan)
            mn, ml = X[:, 0] / cnt, X[:, 2] / cnt
        r["lo"], r["hi"] = float(np.nanpercentile(mn, 2.5)), float(np.nanpercentile(mn, 97.5))
        r["lift_lo"], r["lift_hi"] = float(np.nanpercentile(ml, 2.5)), float(np.nanpercentile(ml, 97.5))
    if n:
        yrs = P["year"][m]
        u = np.unique(yrs)
        r["years"] = int(len(u))
        r["bad_years"] = int(sum(net[yrs == y].mean() <= 0 for y in u))
        for k in ("dip", "runner", "rt5", "rt10", "dip_low"):
            r[k] = float(100 * P[k][m].mean())
        r["mae"] = float(P["mae"][m].mean())
    return r


def run_search(Ps, atoms, finalists=RUN_FINALISTS, log=lambda *a: None):
    """The declared search on engine tables Ps. -> (finalists table, atom masks per engine)."""
    AMs = [[atom_mask(a[2], P) for a in atoms] for P in Ps]
    mins = [RUN_MIN_PER_YEAR * P["years"] for P in Ps]
    base = run_cands(atoms)
    tested = [0]

    def scored(R):
        elig = np.all([R[:, e, 0] >= mins[e] for e in range(len(Ps))], axis=0)
        lb = np.where(np.isfinite(R[:, :, 2]), R[:, :, 2], -np.inf).min(1)
        return elig & np.isfinite(lb), lb

    def earning(cands, elig, score, k, size=None):
        """Down the ranking: the first k eligible rules whose every condition earns its place (quick, both engines)."""
        out = []
        for i in np.argsort(-np.where(elig, score, -np.inf), kind="stable"):
            if not elig[i] or len(out) == k:
                break
            if size and len(cands[i]) != size:
                continue
            tested[0] += 1
            if all(run_earn_quick(P, AM, cands[i]) > 0 for P, AM in zip(Ps, AMs)):
                out.append(int(i))
        return out
    R = run_screen(Ps, AMs, base)
    elig, score = scored(R)
    pairs = [base[i] for i in earning(base, elig, score, RUN_TRIPLE_PAIRS, size=2)]
    tri = run_cands(atoms, pairs)
    cands = base + tri
    if tri:
        R = np.concatenate([R, run_screen(Ps, AMs, tri)])
    elig, score = scored(R)
    order = earning(cands, elig, score, finalists)
    log("   screened %d rules (%d singles and pairs, %d triples); %d keep %d+ trades a year in both engines; %d "
        "tested for every condition earning its place" % (len(cands), len(base), len(tri), int(elig.sum()),
                                                          RUN_MIN_PER_YEAR, tested[0]))
    boots = [Boot(P["day"]) for P in Ps]
    rows = []
    for i in order:
        c = cands[i]
        ev = [run_eval(b, P, *run_extras(AM, c)) for b, P, AM in zip(boots, Ps, AMs)]
        qual = all(x["n"] >= mn and x["lo"] > 0 and x["lift_lo"] > 0 and x["bad_years"] <= RUN_MAX_BAD_YEARS and
                   (len(c) == 1 or x["earn_lo"] > 0) for x, mn in zip(ev, mins))
        row = {"cand": tuple(c), "rule": " & ".join(atoms[x][0] for x in c),
               "text": " & ".join(atoms[x][3] for x in c), "qualifies": bool(qual),
               "score": float(min(x["lo"] for x in ev)), "screen": float(score[i])}
        for P, x in zip(Ps, ev):
            row.update({"%s_%s" % (P["name"], k): v for k, v in x.items()})
        rows.append(row)
    T = pd.DataFrame(rows)
    if len(T):
        T = T.sort_values(["qualifies", "score"], ascending=[False, False], kind="stable").reset_index(drop=True)
    return T, AMs


def run_pick_top(T, AMs, k=RUN_TOP, only_qualified=True):
    """Walk down the ranking (only_qualified=False: by score alone); keep a rule unless it is a version of one kept
    (its conditions within the other's, or 70% of the same trades of the first engine)."""
    if not len(T):
        return []
    rows = T if only_qualified else T.sort_values("score", ascending=False, kind="stable")
    chosen = []
    for r in rows.itertuples(index=False):
        if only_qualified and not r.qualifies:
            continue
        c = tuple(r.cand)
        ids = set(np.flatnonzero(_cmask(AMs[0], c)).tolist())
        if not ids or any(set(c) <= set(c2) or set(c2) <= set(c) or overlap(ids, i2) >= RUN_OVERLAP
                          for c2, i2 in chosen):
            continue
        chosen.append((c, ids))
        if len(chosen) == k:
            break
    return [c for c, _ in chosen]


def _union(AM, cands, n):
    m = np.zeros(n, bool)
    for c in cands:
        m |= _cmask(AM, c)
    return m


def run_walk_forward(Ps, atoms, years=RUN_WF_YEARS, log=lambda *a: None):
    """The search replayed: each year, the candidates chosen with the picks whose D5 exit was before 1 January,
    their picks (each once) judged on that year. -> (rows, {engine: pooled out-of-sample lift and verdict})."""
    rows, pool = [], {P["name"]: [] for P in Ps}
    for Y in years:
        cut, nxt = np.datetime64("%d-01-01" % Y), np.datetime64("%d-01-01" % (Y + 1))
        train = [run_index(run_sub(P, P["d5"] < cut)) for P in Ps]
        test = [run_index(run_sub(P, (P["day"] >= cut) & (P["day"] < nxt))) for P in Ps]
        if any(len(t["net"]) < RUN_WF_MIN for t in train) or any(len(t["net"]) == 0 for t in test):
            rows.append({"year": Y, "chosen": 0, "rules": "", "text": "too few picks to choose with"})
            continue
        T, AMs = run_search(train, atoms)
        top = run_pick_top(T, AMs)
        row = {"year": Y, "chosen": len(top), "rules": "; ".join(" & ".join(atoms[x][0] for x in c) for c in top),
               "text": "; ".join(" & ".join(atoms[x][3] for x in c) for c in top) or
               "no rule qualified on the years before"}
        for t in test:
            e = t["name"]
            row["%s_n" % e] = len(t["net"])
            row["%s_net_all" % e] = float(t["net"].mean())
            row["%s_nodip_all" % e] = float(100 * (~t["dip"]).mean())
            if top:
                m = _union([atom_mask(a[2], t) for a in atoms], top, len(t["net"]))
                row["%s_n_in" % e] = int(m.sum())
                if m.any():
                    row["%s_net_in" % e] = float(t["net"][m].mean())
                    row["%s_lift_in" % e] = float(t["lift"][m].mean())
                    row["%s_nodip_in" % e] = float(100 * (~t["dip"][m]).mean())
                    pool[e].append((t["day"][m], t["lift"][m], t["net"][m]))
        rows.append(row)
        log("   replay %d: %s" % (Y, row["rules"] or row["text"]))
    res = {}
    for e, parts in pool.items():
        d = np.concatenate([x[0] for x in parts]) if parts else np.array([], "datetime64[D]")
        if len(d) < 2:
            res[e] = {"years": len(parts), "n": int(len(d)), "verdict": "NO RULE CHOSEN" if not parts else "NOT SHOWN"}
            continue
        lift, net = np.concatenate([x[1] for x in parts]), np.concatenate([x[2] for x in parts])
        boot = Boot(d)
        lo, hi = _bci(boot, d, lift)
        nlo, nhi = _bci(boot, d, net)
        res[e] = {"years": len(parts), "n": int(len(d)), "lift": float(lift.mean()), "lift_lo": lo, "lift_hi": hi,
                  "net": float(net.mean()), "net_lo": nlo, "net_hi": nhi,
                  "verdict": "HOLDS" if lo > 0 else ("WORSE" if hi < 0 else "NOT SHOWN")}
    return pd.DataFrame(rows), res


def run_events(P):
    """Every pick's entries, all sold at the D5 close: {event: (filled, net)}."""
    O, C, H, L = P["O"], P["C"], P["H"], P["L"]
    stop = H[:, 0] * (1 + RUN_STOP_BUF)
    f1 = H[:, 1] >= stop
    f2 = ~f1 & (H[:, 2] >= stop)
    px = np.where(f1, np.maximum(O[:, 1], stop), np.where(f2, np.maximum(O[:, 2], stop), np.nan))
    rng = H[:, 1] - L[:, 1]
    with np.errstate(invalid="ignore", divide="ignore"):
        strong = (C[:, 1] > O[:, 1]) & (rng > 0) & ((C[:, 1] - L[:, 1]) / np.where(rng > 0, rng, 1.0) >= RUN_STRONG)
        c5 = C[:, 5]
        return {"E0": (np.ones(len(c5), bool), P["net"]),
                "E1": (f1 | f2, (c5 / px - 1) * 100 - COST),
                "E2": (strong, (c5 / np.where(strong, O[:, 2], np.nan) - 1) * 100 - COST),
                "E3": (strong, (c5 / np.where(strong, C[:, 1], np.nan) - 1) * 100 - COST)}


def run_event_rows(P, m, source, boot):
    """The four entries on the picks of one rule (m): per trade, per pick (an unfilled pick = 0, cash) and against
    the D1 open on exactly the picks the event filled."""
    rows = []
    for ev, (f, net) in run_events(P).items():
        ff = m & f & np.isfinite(net)
        r = {"source": source, "engine": P["name"], "event": ev, "entry": EVENT_WORDS[ev], "picks": int(m.sum()),
             "filled": int(ff.sum()), "fill_pct": 100.0 * ff.sum() / max(1, m.sum())}
        if ff.sum() >= 2:
            lo, hi = _bci(boot, P["day"][ff], net[ff])
            slot = np.where(ff, net, 0.0)[m]
            slo, shi = _bci(boot, P["day"][m], slot)
            d = net[ff] - P["net"][ff]
            dlo, dhi = _bci(boot, P["day"][ff], d)
            r.update({"net": float(net[ff].mean()), "lo": lo, "hi": hi, "per_pick": float(slot.mean()),
                      "per_pick_lo": slo, "per_pick_hi": shi, "vs_open": float(d.mean()), "vs_open_lo": dlo,
                      "vs_open_hi": dhi, "nodip_pct": float(100 * (~P["dip"][ff]).mean()),
                      "runner_pct": float(100 * P["runner"][ff].mean()), "per_year": ff.sum() / P["years"]})
        rows.append(r)
    return rows


def wauc(x, y, W):
    """AUC of x for y (bool) with weights W (rows = resamples): ties count half."""
    o = np.argsort(x, kind="mergesort")
    return _wauc_sorted(x[o], y[o], W[:, o])


def _wauc_sorted(xs, ys, Ws, st=None):
    if st is None:
        st = np.flatnonzero(np.r_[True, xs[1:] != xs[:-1]])
    pos = np.add.reduceat(Ws * ys, st, axis=1)
    neg = np.add.reduceat(Ws, st, axis=1) - pos
    below = np.cumsum(neg, axis=1) - neg
    with np.errstate(invalid="ignore", divide="ignore"):
        return (pos * (below + 0.5 * neg)).sum(1) / (pos.sum(1) * neg.sum(1))


def run_anatomy(Ps, target="runner", word="runners", B=RUN_ANAT_B, seed=7):
    """What marks the target at the signal close (and the D1 open): every measure's AUC in each engine with a 95%
    interval (AUC +- 1.96 x its block-bootstrap standard deviation over signal days), Benjamini-Hochberg q within each
    engine. SHOWN = both engines' intervals off 0.5 the same way and q <= 0.10 in both."""
    def measures(P):
        M = {"rank": P["rank"], "other engine picked it": P["agree"], "gap at the D1 open %": P["gap_d1"],
             "s_atr14": P["atr"]}
        M.update({"%s (level)" % f: v for f, v in P["fv"].items()})
        M.update({"%s (change on the signal day)" % f: v for f, v in P["fc"].items()})
        M.update({"zone %s" % k: v for k, v in P["zv"].items()})
        M.update({"snapshot %s" % k: v for k, v in P["snap"].items()})
        return M
    per = []
    for P in Ps:
        boot = Boot(P["day"], B=B, seed=seed)
        Wfull = boot.M[:, np.searchsorted(boot.days, P["day"])]
        y = P[target].astype(bool)
        res = {}
        for k, x in measures(P).items():
            x = np.asarray(x, float)
            ok = np.isfinite(x)
            if ok.sum() < 50 or y[ok].all() or not y[ok].any() or np.std(x[ok]) == 0:
                continue
            xo, yo = x[ok], y[ok]
            o = np.argsort(xo, kind="mergesort")
            xs, ys, cols = xo[o], yo[o], np.flatnonzero(ok)[o]
            st = np.flatnonzero(np.r_[True, xs[1:] != xs[:-1]])
            a = float(_wauc_sorted(xs, ys, np.ones((1, len(xs))), st)[0])
            bs = np.concatenate([_wauc_sorted(xs, ys, Wfull[i:i + 100][:, cols], st) for i in range(0, B, 100)])
            sd = float(np.nanstd(bs))
            z = (a - 0.5) / sd if sd > 0 else np.nan
            med = np.median(xo)
            res[k] = {"auc": a, "lo": a - RUN_Z * sd if sd > 0 else np.nan, "hi": a + RUN_Z * sd if sd > 0 else np.nan,
                      "p": math.erfc(abs(z) / math.sqrt(2)) if np.isfinite(z) else np.nan,
                      "rate_hi": float(100 * yo[xo >= med].mean()),
                      "rate_lo": float(100 * yo[xo < med].mean()) if (xo < med).any() else np.nan}
        for (k, v), qq in zip(res.items(), bh_q([v["p"] for v in res.values()])):
            v["q"] = float(qq)
        per.append(res)
    rows = []
    for k in [k for k in per[0] if all(k in r for r in per)]:
        up = all(p[k]["lo"] > 0.5 for p in per)
        dn = all(p[k]["hi"] < 0.5 for p in per)
        r = {"measure": k, "shown": bool((up or dn) and all(p[k]["q"] <= 0.10 for p in per)),
             "direction": ("higher -> more " + word) if up else (("lower -> more " + word) if dn else ""),
             "strength": float(min(abs(p[k]["auc"] - 0.5) for p in per)) if (up or dn) else 0.0}
        for P, p in zip(Ps, per):
            r.update({"%s_%s" % (P["name"], kk): vv for kk, vv in p[k].items()})
        rows.append(r)
    A = pd.DataFrame(rows)
    if len(A):
        A = A.sort_values(["shown", "strength"], ascending=[False, False], kind="stable").reset_index(drop=True)
    return A


def run_sim(ent, ex, ret, prio, sym, t0, t1, cal, k, lev=1):
    """Closed-trade equity of a k-slot book (start 1.0) on calendar indices t0..t1: each trade gets 1/k of the equity
    at its entry open; all slots busy = skipped (the lower prio first on the same open); exits at the close, the slot
    free from the next open; MTF: lev x exposure, 0.04% a day on the borrowed part."""
    keep = (ent >= t0) & (ent <= t1)
    o = np.lexsort((sym[keep], prio[keep], ent[keep]))
    E, X, R = ent[keep][o], ex[keep][o], ret[keep][o]
    cash, pos, eq, j, n, skipped = 1.0, [], np.empty(t1 - t0 + 1), 0, 0, 0
    for t in range(t0, t1 + 1):
        while j < len(E) and E[j] == t:
            if len(pos) < k:
                size = (cash + sum(p[1] for p in pos)) / k
                if size > 0:
                    days = int((cal[X[j]] - cal[E[j]]) / np.timedelta64(1, "D"))
                    cash -= size
                    pos.append((X[j], size, size * (lev * R[j] / 100 - (lev - 1) * RUN_MTF_DAY * days)))
                    n += 1
            else:
                skipped += 1
            j += 1
        still = []
        for p in pos:
            if p[0] <= t:
                cash += p[1] + p[2]
            else:
                still.append(p)
        pos = still
        eq[t - t0] = cash + sum(p[1] for p in pos)
    return np.maximum(eq, 0.0), n, skipped


def run_book_stats(eq, n, skipped, years):
    end = float(eq[-1]) if len(eq) else np.nan
    dd = float(np.max(1 - eq / np.maximum(np.maximum.accumulate(eq), 1e-12))) * 100 if len(eq) else np.nan
    return {"end_rs": end * RUN_CAPITAL, "cagr": (end ** (1 / years) - 1) * 100 if end > 0 else -100.0,
            "worst_fall": dd, "trades": n, "per_week": n / (years * 365.25 / 7), "skipped": skipped}


def run_dedupe(T):
    """One position per pick: its earliest entry (the same open: the lower prio)."""
    return T.sort_values(["pick", "ent", "prio"], kind="stable").drop_duplicates("pick", keep="first")


def run_money(arms, cal):
    """arms: {name: DataFrame(pick, ent, ex, net, prio, sym)} on calendar indices. Every book on the same window
    (from RUN_MONEY_FROM to the last exit of any book). -> rows."""
    calD = np.asarray(cal).astype("datetime64[D]")
    t0 = int(np.searchsorted(calD, RUN_MONEY_FROM))
    arms = {k: run_dedupe(v) for k, v in arms.items() if len(v)}
    last = [int(v.loc[v["ent"] >= t0, "ex"].max()) for v in arms.values() if (v["ent"] >= t0).any()]
    if not last or t0 >= len(calD):
        return pd.DataFrame()
    t1 = min(len(calD) - 1, max(last))
    years = max(1e-9, float((calD[t1] - calD[t0]) / np.timedelta64(1, "D")) / 365.25)
    rows = []
    for name, T in arms.items():
        for k in RUN_SLOTS:
            for lev in (1, 2):
                eq, n, sk = run_sim(T["ent"].to_numpy(np.int64), T["ex"].to_numpy(np.int64), T["net"].to_numpy(float),
                                    T["prio"].to_numpy(float), T["sym"].astype(str).to_numpy(), t0, t1, calD, k, lev)
                rows.append({"book": name, "slots": k, "mtf": "2x" if lev == 2 else "none",
                             **run_book_stats(eq, n, sk, years), "from": str(calD[t0]), "to": str(calD[t1])})
    return pd.DataFrame(rows)


def run_dip_arm(out, cal):
    """The frozen setups' trades of the newest ZONES run (picks_zone_trades.parquet, hash-checked) with IN / OUT of
    each setup's picks zone, on the watchlist's calendar. -> (DataFrame or None, note)."""
    try:
        zrun, zdoc = load_zones(Path(out))
    except ValueError as e:
        return None, "not used: %s" % e
    if zrun is None or not (Path(zrun) / "picks_zone_trades.parquet").is_file():
        return None, "not used: no ZONES run with picks_zone_trades.parquet under %s" % (Path(out) / "ZONES")
    read_hashed_run(zrun, ["picks_zone_trades.parquet"])
    Z = pd.read_parquet(Path(zrun) / "picks_zone_trades.parquet")
    sid_ = Z["setup"].astype(str).to_numpy()
    inz = np.zeros(len(Z), bool)
    for sid in np.unique(sid_):
        key = (((zdoc.get("setups") or {}).get(sid) or {}).get("picks") or {}).get("zone", "")
        m = sid_ == sid
        if key:
            inz[m] = zone_mask(zone_parse(key), {d: Z.loc[m, d].to_numpy() for d in ZDIM})
    calD = np.asarray(cal).astype("datetime64[D]")
    e_ = pd.to_datetime(Z["day"]).to_numpy().astype("datetime64[D]")
    x_ = pd.to_datetime(Z["exit"]).to_numpy().astype("datetime64[D]")
    ent, ex = np.searchsorted(calD, e_), np.searchsorted(calD, x_)
    ok = (ent < len(calD)) & (ex < len(calD)) & np.isfinite(Z["net"].to_numpy(float))
    ok[ok] &= (calD[ent[ok]] == e_[ok]) & (calD[ex[ok]] == x_[ok])
    D = pd.DataFrame({"pick": Z["trade_id"].astype(str).to_numpy(), "engine": Z["engine"].astype(str).to_numpy(),
                      "setup": sid_, "ent": ent, "ex": ex, "net": Z["net"].to_numpy(float),
                      "rank": Z["rank"].to_numpy(float), "sym": Z["symbol"].astype(str).to_numpy(),
                      "zone_in": inz})[ok].reset_index(drop=True)
    return D, "%s: %d setup trades, %d of them IN their picks zone" % (Path(zrun).name, len(D), int(D["zone_in"].sum()))


def run_arms(P, masks, names, dip):
    """One engine's money books: the plan (ranks 1-3 at the D1 open), the no-dip arm (the candidates' picks at the D1
    open), the dip arm (S3 in its zone; all 7 setups) and both arms together."""
    base = pd.DataFrame({"pick": P["ids"], "ent": P["ent"], "ex": P["ex"], "net": P["net"], "rank": P["rank"],
                         "sym": P["symbols"]})
    plan = base[P["rank"] <= 3].copy()
    plan["prio"] = plan["rank"]
    arms = {"plan: ranks 1-3 at the D1 open": plan}
    N = None
    if masks:
        N = pd.concat([base[m].assign(src=nm) for m, nm in zip(masks, names)], ignore_index=True)
        N["prio"] = -N["src"].map(N.groupby("src")["net"].mean()) * 1000 + N["rank"]
        arms["no-dip arm: the candidates at the D1 open"] = N
    if dip is not None and len(dip):
        D = dip[dip["engine"] == P["name"]].copy()
        if len(D):
            good = D["zone_in"].to_numpy(bool)
            D["src"] = np.where(good, "IN:", "OUT:").astype(object) + D["setup"].to_numpy(object)
            D["prio"] = -D["src"].map(D.groupby("src")["net"].mean()) * 1000 + D["rank"]
            s3 = D[(D["setup"] == "S3").to_numpy() & good]
            if len(s3):
                arms["dip arm: S3 in its zone"] = s3
            arms["dip arm: all 7 setups (in-zone first)"] = D
            if N is not None:
                if len(s3):
                    arms["BOTH ARMS: no-dip + S3 in its zone"] = pd.concat([N, s3], ignore_index=True)
                arms["BOTH ARMS: no-dip + all 7 setups"] = pd.concat([N, D], ignore_index=True)
    return arms


def runners_hash(doc):
    return hashlib.sha256(_canon_json({k: v for k, v in doc.items() if k != "sha256"}).encode()).hexdigest()


def load_runners(base):
    """The newest runners run's RUNNER_CANDIDATES.json (hash-checked) -> (folder, doc) or (None, None)."""
    run = latest_run(base, "RUNNERS", [RUN_FILE])
    if run is None:
        return None, None
    doc = json.loads((run / RUN_FILE).read_text(encoding="utf-8"))
    if doc.get("sha256") != runners_hash(doc):
        raise ValueError("%s was changed after it was written - refusing" % (run / RUN_FILE))
    return run, doc


def _p(x, nd=2, sign=True):
    try:
        x = float(x)
    except (TypeError, ValueError):
        return ""
    return ("%+.*f" % (nd, x) if sign else "%.*f" % (nd, x)) if np.isfinite(x) else ""


def _g(r, k):
    try:
        return float(r.get(k, np.nan))
    except (TypeError, ValueError):
        return np.nan


def cmd_runners(a, log=None, data=None):
    """The no-dip study: labels, what marks a runner, the rule search, entries, the year-by-year replay, the money
    view with the dip arm. Writes RUNNERS\\RUNNERS_<date>_<nnn>\\ under --out."""
    log = log or (lambda *x: print(time.strftime("%H:%M:%S ") + " ".join(str(y) for y in x), flush=True))
    t0 = time.time()
    cols_file = Path(a.columns_file) if getattr(a, "columns_file", "") else \
        Path(__file__).resolve().with_name("features_final.txt")
    if not cols_file.is_file():
        print("REFUSED: no feature list %s (give --columns-file)" % cols_file)
        return 3
    cols = read_columns_file(cols_file)
    log("%s runners: watchlist %s; panel %s; features %s (%d)" % (VERSION, a.data, a.features, cols_file.name,
                                                                  len(cols)))
    book = load(a.data, a.features, None, cols, None, log, getattr(a, "chunk", 8))
    if book.missing_features:
        log(" NOTE: %d feature columns are not in the panel: %s" % (len(book.missing_features),
                                                                    ", ".join(book.missing_features)))
    if data is None:
        data = LiveData(a.root, getattr(a, "stage_e_any", False), panel=None)
    M = market_dims(data.index_closes(dict(ZONE_INDEX)))
    log(" reading every pick's own bars (highs, lows, the zone values at the signal close)")
    bars = run_bars(book, data.ohlcv, data.forget, M)
    engines = [e for e in ("D", "ENS") if (book.engine_arr == e).any()]
    if not engines:
        print("REFUSED: no D or ENS picks in the watchlist")
        return 3
    sdD = np.asarray(book.signal_day).astype("datetime64[D]")
    ranks = {e: dict(zip(zip(sdD[book.engine_arr == e], book.symbols[book.engine_arr == e]),
                         book.rank[book.engine_arr == e].astype(float))) for e in engines}
    Ps = []
    for e in engines:
        m = book.engine_arr == e
        other = ranks[[x for x in engines if x != e][0]] if len(engines) > 1 else {}
        bsub = {"H": bars["H"][m], "L": bars["L"][m], "Cb": bars["Cb"][m], "Z": {k: v[m] for k, v in bars["Z"].items()}}
        P = runner_table(book.take(m, e), bsub, other, e)
        Ps.append(P)
        c = P["counts"]
        log(" %s: %d settled picks, %d with their bars, %d whose bars give the watchlist's D1-D5 closes (%d after a "
            "price adjustment), %d complete; %.1f years" % (e, c["settled"], c["with_bars"], c["aligned"],
                                                             c["rescaled"], c["complete"], P["years"]))
    align = "; ".join("%s: %d of %d settled picks complete (their bars give the watchlist's D1-D5 closes)%s" % (
        P["name"], P["counts"]["complete"], P["counts"]["settled"],
        " - WARNING: below 98%, send RUNNERS.md" if P["counts"]["complete"] < 0.98 * P["counts"]["settled"] else "")
        for P in Ps)
    del bars
    have = [{x[0] for x in run_atoms(P)} for P in Ps]
    atoms = [x for x in run_atoms(Ps[0]) if all(x[0] in h for h in have)]
    log(" %d single conditions (features %d, zones %d, rank / agreement / weekday / context / gap %d)" % (
        len(atoms), sum(x[0].startswith("F|") for x in atoms), sum(x[0].startswith("Z|") for x in atoms),
        sum(not x[0].startswith(("F|", "Z|")) for x in atoms)))
    base = []
    for P in Ps:
        net, top3 = P["net"], P["rank"] <= 3
        tot = float(net.sum())
        base.append({"engine": P["name"], "picks": int(len(net)), "no_dip_pct": float(100 * (~P["dip"]).mean()),
                     "dip_low_pct": float(100 * P["dip_low"].mean()), "dip_atr_pct": float(100 * P["dip_atr"].mean()),
                     "rt5_pct": float(100 * P["rt5"].mean()), "rt10_pct": float(100 * P["rt10"].mean()),
                     "runner_pct": float(100 * P["runner"].mean()), "net_all": float(net.mean()),
                     "net_runner": float(net[P["runner"]].mean()) if P["runner"].any() else np.nan,
                     "net_nodip": float(net[~P["dip"]].mean()) if (~P["dip"]).any() else np.nan,
                     "net_dip": float(net[P["dip"]].mean()) if P["dip"].any() else np.nan,
                     "runner_share_of_profit": float(100 * net[P["runner"]].sum() / tot) if tot > 0 else np.nan,
                     "top3_no_dip_pct": float(100 * (~P["dip"][top3]).mean()) if top3.any() else np.nan})
    log(" base: " + "; ".join("%s no dip %.1f%%, runners %.1f%% (net %s; all picks %s)" % (
        b["engine"], b["no_dip_pct"], b["runner_pct"], _p(b["net_runner"]), _p(b["net_all"])) for b in base))
    log(" what marks a runner / a dip (AUC of every measure, both engines)")
    AN = run_anatomy(Ps, "runner", "runners")
    AN2 = run_anatomy(Ps, "dip", "dips")
    log(" the rule search (both engines)")
    T, AMs = run_search(Ps, atoms, log=log)
    top = run_pick_top(T, AMs)
    top_any = run_pick_top(T, AMs, only_qualified=False)
    nm = lambda c: " & ".join(atoms[x][0] for x in c)
    log(" %d of %d finalists qualify; candidates: %s" % (int(T["qualifies"].sum()) if len(T) else 0, len(T),
                                                         "; ".join(nm(c) for c in top) or "none"))
    log(" the year-by-year replay")
    WF, wfres = run_walk_forward(Ps, atoms, log=log)
    log(" out of sample: " + "; ".join("%s %s" % (e, v["verdict"]) for e, v in wfres.items()))
    log(" entries on the candidates' picks")
    ev_rows = []
    for P, AM in zip(Ps, AMs):
        boot = Boot(P["day"])
        ev_rows += run_event_rows(P, np.ones(len(P["net"]), bool), "ALL picks", boot)
        if top:
            ev_rows += run_event_rows(P, _union(AM, top, len(P["net"])), "the no-dip arm (R1-R%d)" % len(top), boot)
        for c in dict.fromkeys(top + top_any):
            ev_rows += run_event_rows(P, _cmask(AM, c), nm(c), boot)
    EV = pd.DataFrame(ev_rows)
    log(" the money view")
    dip, dip_note = run_dip_arm(a.out, book.cal)
    money = []
    for P, AM in zip(Ps, AMs):
        Mo = run_money(run_arms(P, [_cmask(AM, c) for c in top], ["R%d" % (i + 1) for i in range(len(top))], dip),
                       book.cal)
        if len(Mo):
            Mo.insert(0, "engine", P["name"])
            money.append(Mo)
    MO = pd.concat(money, ignore_index=True) if money else pd.DataFrame()
    run = new_run_dir(Path(a.out) / "RUNNERS", "RUNNERS")
    cand_doc = []
    pos = {tuple(c): i for i, c in enumerate(T["cand"])} if len(T) else {}
    for kind, lst, tag in (("qualified", top, "R"), ("best by score", top_any, "B")):
        for i, c in enumerate(lst):
            r = T.iloc[pos[tuple(c)]]
            cand_doc.append({"list": kind, "id": "%s%d" % (tag, i + 1), "rule": r["rule"], "text": r["text"],
                             "qualifies": bool(r["qualifies"]), "conds": [atoms[x][2] for x in c],
                             "stats": {P["name"]: {k: r.get("%s_%s" % (P["name"], k)) for k in
                                                   ("n", "per_year", "net", "lo", "hi", "lift", "lift_lo", "lift_hi",
                                                    "dip", "runner", "rt5", "rt10", "mae", "bad_years", "years")}
                                       for P in Ps}})
    res = _clean({"file": RUN_FILE, "tool": VERSION, "made_at": _dt.datetime.now(IST).isoformat(timespec="seconds"),
                  "rule": RUN_RULE, "watchlist": str(a.data), "panel": str(a.features), "features": cols_file.name,
                  "alignment": align, "counts": {P["name"]: P["counts"] for P in Ps}, "base": base,
                  "candidates": cand_doc, "out_of_sample": wfres, "dip_arm": dip_note})
    res["sha256"] = runners_hash(res)
    (run / RUN_FILE).write_text(json.dumps(res, indent=1), encoding="utf-8")
    Tw = T.copy()
    if len(Tw):
        Tw["cand"] = Tw["cand"].apply(lambda c: "+".join(atoms[x][0] for x in c))
    Tw.to_csv(run / "runner_finalists.csv", index=False)
    WF.to_csv(run / "runner_walk_forward.csv", index=False)
    AN.to_csv(run / "runner_anatomy.csv", index=False)
    AN2.to_csv(run / "dip_anatomy.csv", index=False)
    EV.to_csv(run / "runner_events.csv", index=False)
    MO.to_csv(run / "runner_money.csv", index=False)
    pk = []
    for P, AM in zip(Ps, AMs):
        D = pd.DataFrame({"trade_id": P["ids"], "engine": P["name"], "symbol": P["symbols"], "signal_day": P["day"],
                          "rank": P["rank"], "net": P["net"], "lift": P["lift"], "dip": P["dip"],
                          "dip_low": P["dip_low"], "dip_atr": P["dip_atr"], "rt5": P["rt5"], "rt10": P["rt10"],
                          "runner": P["runner"], "mfe": P["mfe"], "mae": P["mae"], "gap_d1": P["gap_d1"],
                          "agree": P["agree"]})
        for i, c in enumerate(top):
            D["R%d" % (i + 1)] = _cmask(AM, c)
        pk.append(D)
    pd.concat(pk, ignore_index=True).to_parquet(run / "runner_picks.parquet", index=False)
    md = runner_report(res, base, AN, AN2, T, top, top_any, WF, wfres, EV, MO, [P["name"] for P in Ps])
    (run / "RUNNERS.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    write_hashes(run, [RUN_FILE, "RUNNERS.md", "runner_finalists.csv", "runner_walk_forward.csv",
                       "runner_anatomy.csv", "dip_anatomy.csv", "runner_events.csv", "runner_money.csv",
                       "runner_picks.parquet"])
    log("RUNNERS WRITTEN -> %s (%.1f min)" % (run, (time.time() - t0) / 60))
    return 0


def runner_report(res, base, AN, AN2, T, top, top_any, WF, wfres, EV, MO, E):
    md = ["# Runners - the picks that do not dip (%s, %s)" % (time.strftime("%d %b %Y"), VERSION), "",
          "Watchlist %s; panel %s; features %s. %s." % (res["watchlist"], res["panel"], res["features"],
                                                        res["alignment"]), "",
          "**The rule (declared before any result):** " + RUN_RULE, "",
          "Rs a year = net % per trade x trades a year x Rs 1,000 (Rs 1 L a trade, before taxes).", "",
          "## Verdict: the no-dip candidates (bought at the D1 open, sold at the D5 close)", ""]
    hdr = "| | rule | " + " | ".join(("%s trades a year | %s net %% per trade [95%%] | %s lift over all picks [95%%] | "
                                      "%s no dip | %s runners | %s Rs a year") % ((e,) * 6) for e in E) + " |"
    sep = "|---|---|" + "---:|" * (6 * len(E))
    pos = {tuple(c): i for i, c in enumerate(T["cand"])} if len(T) else {}

    def line(tag, c):
        r = T.iloc[pos[tuple(c)]]
        cells = []
        for e in E:
            n_, py = _g(r, e + "_net"), _g(r, e + "_per_year")
            cells += ["%.0f" % py, "%s [%s, %s]" % (_p(n_), _p(_g(r, e + "_lo")), _p(_g(r, e + "_hi"))),
                      "%s [%s, %s]" % (_p(_g(r, e + "_lift")), _p(_g(r, e + "_lift_lo")), _p(_g(r, e + "_lift_hi"))),
                      "%.1f%%" % (100 - _g(r, e + "_dip")), "%.1f%%" % _g(r, e + "_runner"),
                      "{:,.0f}".format(n_ * py * 1000) if np.isfinite(n_ * py) else ""]
        return "| %s | %s%s | %s |" % (tag, r["text"], "" if r["qualifies"] else " (does NOT qualify)",
                                       " | ".join(cells))
    md += [hdr, sep] + [line("R%d" % (i + 1), c) for i, c in enumerate(top)]
    if not top:
        md.append("| | no rule qualifies in both engines |" + " |" * (6 * len(E)))
    md += ["", "**Out of sample (the whole search replayed year by year, the candidates' picks each once):** " +
           "; ".join("%s **%s** - lift over all picks %s [%s, %s], net %s [%s, %s] per trade on %d picks in %d years"
                     % (e, v["verdict"], _p(v.get("lift")), _p(v.get("lift_lo")), _p(v.get("lift_hi")),
                        _p(v.get("net")), _p(v.get("net_lo")), _p(v.get("net_hi")), v.get("n", 0), v.get("years", 0))
                     for e, v in wfres.items()), "",
           "The best 5 by score, qualified or not (the open list):", "", hdr, sep]
    md += [line("B%d" % (i + 1), c) for i, c in enumerate(top_any)]
    if len(MO):
        md += ["", "**Trades a week and money at a glance** (Rs 5 L, no MTF, from 2022; in-sample):", "",
               "| engine | book | slots | trades a week | Rs 5 L became | a year | worst fall |",
               "|---|---|---:|---:|---:|---:|---:|"]
        for r in MO[(MO["mtf"] == "none") & MO["slots"].isin([3, 5])].to_dict("records"):
            md.append("| %s | %s | %d | %.1f | Rs %s | %s%% | %.1f%% |" % (
                r["engine"], r["book"], r["slots"], r["per_week"], "{:,.0f}".format(r["end_rs"]), _p(r["cagr"], 1),
                r["worst_fall"]))
    md += ["", "## The year-by-year replay", "",
           "| year | candidates chosen with exits before 1 January | " + " | ".join(
               "%s picks that year | %s in the candidates | %s net in them | %s net all picks | %s no dip in them | "
               "%s no dip all" % ((e,) * 6) for e in E) + " |", "|---|---|" + "---:|" * (6 * len(E))]
    for r in WF.to_dict("records"):
        cells = []
        for e in E:
            cells += ["%.0f" % _g(r, e + "_n") if np.isfinite(_g(r, e + "_n")) else "",
                      "%.0f" % _g(r, e + "_n_in") if np.isfinite(_g(r, e + "_n_in")) else "",
                      _p(_g(r, e + "_net_in")), _p(_g(r, e + "_net_all")),
                      ("%.1f%%" % _g(r, e + "_nodip_in")) if np.isfinite(_g(r, e + "_nodip_in")) else "",
                      ("%.1f%%" % _g(r, e + "_nodip_all")) if np.isfinite(_g(r, e + "_nodip_all")) else ""]
        md.append("| %s | %s | %s |" % (r["year"], r.get("rules") or r.get("text", ""), " | ".join(cells)))
    md += ["", "## Base rates (every complete pick bought at the D1 open, sold at the D5 close)", "",
           "| engine | picks | no dip (a close 2% below) | dip by the intraday low 2% | dip by 1 ATR | D5 close +5% | "
           "+10% | runners | net all | net runners | net no dip | net dip | runners' share of the profit | ranks 1-3 "
           "no dip |", "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for b in base:
        md.append("| %s | %d | %.1f%% | %.1f%% | %.1f%% | %.1f%% | %.1f%% | %.1f%% | %s | %s | %s | %s | %s | %s |" % (
            b["engine"], b["picks"], b["no_dip_pct"], b["dip_low_pct"], b["dip_atr_pct"], b["rt5_pct"], b["rt10_pct"],
            b["runner_pct"], _p(b["net_all"]), _p(b["net_runner"]), _p(b["net_nodip"]), _p(b["net_dip"]),
            ("%.0f%%" % b["runner_share_of_profit"]) if np.isfinite(_g(b, "runner_share_of_profit")) else "",
            ("%.1f%%" % b["top3_no_dip_pct"]) if np.isfinite(_g(b, "top3_no_dip_pct")) else ""))
    for title, A, what in (("What marks a runner at the signal close (and the D1 open)", AN, "runners"),
                           ("What marks a pick that will dip (below 0.5 = less dipping)", AN2, "dips")):
        md += ["", "## " + title, "",
               "AUC = the chance a pick with the outcome scores higher on the measure than one without (0.5 = no "
               "information). SHOWN = both engines' 95%% intervals off 0.5 the same way and q <= 0.10 in both. Above / "
               "below = the share of %s among picks above / below the measure's median. The 30 strongest:" % what, "",
               "| measure | SHOWN | " + " | ".join("%s AUC [95%%] | %s above / below the median" % (e, e) for e in E)
               + " |", "|---|---|" + "---:|" * (2 * len(E))]
        for r in A.head(30).to_dict("records"):
            md.append("| %s | %s | %s |" % (r["measure"], ("yes, " + r["direction"]) if r["shown"] else "", " | ".join(
                "%.3f [%.3f, %.3f] | %.1f%% / %s" % (
                    r["%s_auc" % e], r["%s_lo" % e], r["%s_hi" % e], r["%s_rate_hi" % e],
                    ("%.1f%%" % r["%s_rate_lo" % e]) if np.isfinite(_g(r, "%s_rate_lo" % e)) else "") for e in E)))
    md += ["", "## Entries: the D1 open against the events, on the same picks", "",
           "Per trade = the filled trades only; per pick = an unfilled pick counts 0 (cash); against the D1 open = the "
           "event's trade minus the D1-open trade on exactly the picks the event filled. All sold at the D5 close.",
           "", "| picks of | engine | entry | filled | per trade [95%] | per pick [95%] | against the D1 open [95%] | "
           "no dip | runners | trades a year |", "|---|---|---|---:|---:|---:|---:|---:|---:|---:|"]
    for r in EV.to_dict("records"):
        md.append("| %s | %s | %s | %d of %d (%.0f%%) | %s [%s, %s] | %s [%s, %s] | %s [%s, %s] | %s | %s | %s |" % (
            r["source"], r["engine"], r["entry"], r["filled"], r["picks"], r["fill_pct"], _p(_g(r, "net")),
            _p(_g(r, "lo")), _p(_g(r, "hi")), _p(_g(r, "per_pick")), _p(_g(r, "per_pick_lo")),
            _p(_g(r, "per_pick_hi")), _p(_g(r, "vs_open")), _p(_g(r, "vs_open_lo")), _p(_g(r, "vs_open_hi")),
            ("%.1f%%" % _g(r, "nodip_pct")) if np.isfinite(_g(r, "nodip_pct")) else "",
            ("%.1f%%" % _g(r, "runner_pct")) if np.isfinite(_g(r, "runner_pct")) else "",
            ("%.0f" % _g(r, "per_year")) if np.isfinite(_g(r, "per_year")) else ""))
    md += ["", "## Money: the arms alone and together (one position per pick, Rs 5 L, profits reinvested, from 2022)",
           "", "Dip arm: %s. Worst fall = the largest fall from a peak, counted when trades close (open positions' "
           "daily swings would show more). In-sample: the candidates and the zones were chosen on these years. One "
           "slot holds a 5-session trade, so a slot carries about one trade a week." % res["dip_arm"], "",
           "| engine | book | slots | MTF | Rs 5 L became | a year | worst fall | trades a week | skipped (slots full) |",
           "|---|---|---:|---|---:|---:|---:|---:|---:|"]
    for r in MO.to_dict("records"):
        md.append("| %s | %s | %d | %s | Rs %s | %s%% | %.1f%% | %.1f | %d |" % (
            r["engine"], r["book"], r["slots"], r["mtf"], "{:,.0f}".format(r["end_rs"]), _p(r["cagr"], 1),
            r["worst_fall"], r["per_week"], r["skipped"]))
    md += ["", "## Limits", "",
           "- Everything here is on the history the engines, the setups and the zones were studied on; the replay "
           "guards the search, not the list of conditions. Only the forward paper ledger is clean evidence.",
           "- The D1 open and the gap are the cache's; a pre-open (AMO) order fills at the open price. The breakout "
           "fills at the stop (or the open above it) with no slippage; the D1-close entry fills at the official close.",
           "- The money view ignores taxes and assumes every order fills; MTF needs the stock on the broker's list."]
    return md


def main(argv=None):
    ap = argparse.ArgumentParser(prog="setuplab")
    ap.add_argument("command", nargs="?", choices=("run", "reproduce", "build", "tag", "scan", "frozen", "zones",
                                                       "runners"))
    ap.add_argument("--ranks", default="", help="run: only these ranks (e.g. 1-3, 4-10); build: default 1-10")
    ap.add_argument("--root", help="build: the daily cache root (%%CACHE_DAILY_ROOT%%)")
    ap.add_argument("--export", help="build: tradelab's export folder (TLX_...)")
    ap.add_argument("--pm-run", default="PM_20261017_001")
    ap.add_argument("--engines", default="D,ENS")
    ap.add_argument("--to", default="")
    ap.add_argument("--stage-e-any", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--costs", default="stage_e", help=argparse.SUPPRESS)
    ap.add_argument("--check", default="", help="build: ChatGPT's watchlist.parquet - the ranks 1-3 must match")
    ap.add_argument("--data")
    ap.add_argument("--features")
    ap.add_argument("--ledgers")
    ap.add_argument("--out")
    ap.add_argument("--engine", default="D", help="D, ENS, or several: D,ENS (one run, a leaderboard across them)")
    ap.add_argument("--columns-file", default="", help="a file of feature names, one per line (# = comment)")
    ap.add_argument("--chunk", type=int, default=8, help=argparse.SUPPRESS)
    ap.add_argument("--columns", default="", help="comma list of feature columns to test (default: every column)")
    ap.add_argument("--why", default="", help="why_features.csv: test the engine's top --top features by its importance")
    ap.add_argument("--top", type=int, default=50)
    ap.add_argument("--confluence", action="store_true", help="also run the setups x logical confluences stage")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--frozen", default="", help="tag / scan: another freeze file (default: FROZEN_SETUPS.json beside "
                                                  "setuplab.py)")
    ap.add_argument("--date", default="", help="scan: the evening to scan (default: the cache's last session)")
    ap.add_argument("--all-missing", action="store_true", help="scan: every session since the freeze not scanned yet")
    ap.add_argument("--force", action="store_true", help="scan: rescan a scanned evening (its first record stays)")
    ap.add_argument("--panel", default="panel_live", help="scan: the panel folder under --root (default panel_live)")
    ap.add_argument("--picks-only", action="store_true", help="zones: skip the whole-market study")
    a = ap.parse_args(argv)
    if a.selftest:
        sys.path.insert(0, str(Path(__file__).resolve().parent / "tests"))
        import test_setuplab
        return test_setuplab.main()
    a.ranks_list = []
    if a.ranks:
        lo, _, hi = a.ranks.partition("-")
        a.ranks_list = list(range(int(lo), int(hi or lo) + 1))
    if a.command == "frozen":
        try:
            fp, doc = load_frozen(a.frozen or None)
        except ValueError as e:
            print("REFUSED: %s" % e)
            return 3
        print("%s - %s, frozen %s, sha256 %s" % (VERSION, fp, doc["frozen_at"], doc["sha256"]))
        for x in doc["setups"]:
            print("  %s  %-70s primary exit %-11s  %s" % (x["id"], x["name"][:70], x["primary_exit"],
                                                          " & ".join("%s %s %g" % tuple(c) for c in x["conds"])))
        print("FROZEN FILE OK")
        return 0
    if a.command == "tag":
        if not a.data or not a.features or not a.out:
            print("ERROR: tag needs --data <watchlist folder>, --features <panel.parquet> and --out (no defaults)")
            return 2
        a.frozen = a.frozen or None
        return cmd_tag(a)
    if a.command == "scan":
        if not a.root or not Path(a.root).is_dir() or not a.out:
            print("ERROR: scan needs --root <cache root> and --out <setuplab output folder> (no defaults)")
            return 2
        a.frozen = a.frozen or None
        return cmd_scan(a)
    if a.command == "zones":
        if not a.root or not Path(a.root).is_dir() or not a.out or not a.features or not Path(a.features).is_file():
            print("ERROR: zones needs --root <cache root>, --features <panel.parquet> and --out <setuplab output "
                  "folder holding the TAGS run> (no defaults)")
            return 2
        try:
            return cmd_zones(a)
        except ValueError as e:
            print("REFUSED: %s" % e)
            return 3
    if a.command == "runners":
        if not a.root or not Path(a.root).is_dir() or not a.out or not a.data or not a.features or \
                not Path(a.features).is_file():
            print("ERROR: runners needs --root <cache root>, --data <watchlist folder>, --features <panel.parquet> "
                  "and --out <setuplab output folder> (no defaults)")
            return 2
        try:
            return cmd_runners(a)
        except ValueError as e:
            print("REFUSED: %s" % e)
            return 3
    if a.command == "build":
        if not a.root or not Path(a.root).is_dir() or not a.export or not a.out:
            print("ERROR: build needs --root <cache root>, --export <tradelab export folder> and --out (no defaults)")
            return 2
        return cmd_build(a)
    if not a.command or not a.data or not a.features:
        print("ERROR: give a command, --data and --features (no default paths)")
        return 2
    cols = [c.strip() for c in a.columns.split(",") if c.strip()] or None
    if a.columns_file:
        if not Path(a.columns_file).is_file():
            print("REFUSED: no file %s" % a.columns_file)
            return 3
        cols = list(dict.fromkeys((cols or []) + read_columns_file(a.columns_file)))
    if a.why:
        if not Path(a.why).is_file():
            print("REFUSED: no file %s" % a.why)
            return 3
        cols, skipped = pick_features(a.why, a.top, a.features, a.engine.split(",")[0])
        print("%s: the top %d features by the WHY importance (%d skipped before reaching them: %s)" % (
            VERSION, len(cols), len(skipped), ", ".join("%s (%s)" % x for x in skipped[:40])))
        print("  " + ", ".join(cols))
    engines = [e.strip() for e in a.engine.split(",") if e.strip()]
    if a.command == "reproduce":
        try:
            book = load(a.data, a.features, engines[0], cols, a.ranks_list or None)
        except ValueError as e:
            print("REFUSED: %s" % e)
            return 3
        if not a.ledgers:
            print("ERROR: --ledgers <folder of the delivered *.csv.gz>")
            return 2
        n, bad, worst = cmd_reproduce(book, a.ledgers)
        print("%s reproduce: %d ledgers compared, %d differ, largest ret difference %.2e pp" % (
            VERSION, n, len(bad), worst))
        for b in bad:
            print("  DIFFERS", *b)
        print("REPRODUCED" if not bad else "NOT REPRODUCED")
        return 0 if not bad else 1
    if not a.out:
        print("ERROR: --out <folder>")
        return 2
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    # the same command again resumes a stopped run; different settings in the same folder are refused
    st = lambda f: [str(Path(f).resolve()), Path(f).stat().st_size, int(Path(f).stat().st_mtime)] if f else None
    settings = {"version": VERSION, "engines": engines, "ranks": a.ranks_list, "columns": cols,
                "confluence": bool(a.confluence), "watchlist": st(Path(a.data) / "watchlist.parquet"),
                "features": st(a.features)}
    sf = out / "RUN_SETTINGS.json"
    if sf.is_file():
        old = json.loads(sf.read_text(encoding="utf-8"))
        if old != json.loads(json.dumps(settings)):
            print("REFUSED: %s holds a run with other settings (or another version / data) - use a new --out" % out)
            return 3
        print("resuming the run in %s (finished parts are kept)" % out)
    sf.write_text(json.dumps(settings, indent=1), encoding="utf-8")
    logf = open(out / "run.log", "a", encoding="utf-8")

    def log(*x):
        line = time.strftime("%H:%M:%S ") + " ".join(str(y) for y in x)
        print(line, flush=True)
        logf.write(line + "\n")
        logf.flush()
    t0 = time.time()
    try:
        book = load(a.data, a.features, None if len(engines) > 1 else engines[0], cols, a.ranks_list or None, log,
                    a.chunk)
    except ValueError as e:
        print("REFUSED: %s" % e)
        return 3
    info = {"version": VERSION, "started": time.strftime("%Y-%m-%d %H:%M:%S"), "args": vars(a),
            "features_attached": book.features, "features_missing": getattr(book, "missing_features", []),
            "python": sys.version.split()[0], "numpy": np.__version__, "pandas": pd.__version__}
    if book.missing_features:
        log(" NOTE: %d feature columns are not in the panel and were skipped: %s" % (
            len(book.missing_features), ", ".join(book.missing_features)))
    if a.check:
        res = check_watchlists(book.wl, a.check)
        info["watchlist_check"] = res
        log(" " + res["text"])
    if cols:
        (out / "features_tested.txt").write_text("\n".join(book.features) + "\n", encoding="utf-8")
    if len(engines) == 1:
        cmd_run(book, out, log=log, with_confluence=a.confluence)
    else:
        books = {}
        for e in engines:
            mask = book.engine_arr == e
            if not mask.any():
                print("REFUSED: no picks of engine %s in the watchlist" % e)
                return 3
            books[e] = book.take(mask, e)
        info["picks"] = {e: b.n for e, b in books.items()}
        del book
        cmd_run_multi(books, out, log=log, with_confluence=a.confluence)
    info["minutes"] = round((time.time() - t0) / 60, 1)
    (out / "RUN.json").write_text(json.dumps(info, indent=1, default=str), encoding="utf-8")
    log(" DONE in %.1f minutes - %s" % (info["minutes"], out))
    return 0


if __name__ == "__main__":
    sys.exit(main())
