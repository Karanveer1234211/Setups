"""Ordered condition evaluation and auditable fills for long-only scenarios."""
from collections import defaultdict
from risk import trade_dd,realized_dd
from math import isfinite
import operator
import numpy as np
import pandas as pd

OPS={'>':operator.gt,'>=':operator.ge,'<':operator.lt,'<=':operator.le,'=':operator.eq,'!=':operator.ne}
PHASES={'open':{'snapshot','open'},'intraday':{'snapshot','open','intraday'},'close':{'snapshot','open','close'}}
class Missing(Exception):pass

def numeric(x):
    try:return isfinite(float(x))
    except (ValueError,TypeError):return False

def validate(feed,c):
    for k,lo,hi in [('window',1,30),('hold',1,30),('rank',1,3)]:
        if not isinstance(c.get(k),int) or not lo<=c[k]<=hi:raise ValueError(f'{k} must be an integer from {lo} to {hi}')
    for k in ['cost','tp','sl','size']:
        if not numeric(c.get(k)) or c[k]<0:raise ValueError('Invalid '+k)
    if c['size']<=0 or c['cost']>=100:raise ValueError('Check position size and cost.')
    if c.get('unit') not in ['pct','atr']:raise ValueError('Unknown target/stop unit.')
    if not c.get('steps'):raise ValueError('Add at least one event.')
    for s in c['steps']:
        if s.get('phase') not in PHASES or s.get('logic') not in ['all','any'] or not s.get('rules'):raise ValueError('Each event needs a clock, logic and condition.')
        if s['phase']=='intraday' and not feed.has_bars:raise ValueError('Connect timestamped intraday OHLCV to use intraday events.')
        capture=s.get('capture')
        if capture and (capture not in feed.fields or feed.fields[capture][1] not in PHASES[s['phase']]):raise ValueError('Captured field must be available at this event clock.')
        for rule in s['rules']:
            if rule.get('op') not in OPS:raise ValueError('Unknown comparison.')
            for f in [rule['field']]+([rule['rhs']] if rule.get('rhs') else []):
                if f not in feed.fields or feed.fields[f][1] not in PHASES[s['phase']]:raise ValueError(f'{f} is unavailable at the {s["phase"]} clock.')
                if feed.panel is None and f in ['high','low','volume','rvol20','rsi14','atr14','ema20','ema50','prior_high','prior_low']:raise ValueError(f'{f} requires the daily OHLCV panel. Signal snapshot fields work offline.')
            if rule.get('rhs') and not numeric(rule.get('factor',1)):raise ValueError('Invalid field multiplier.')
    if feed.panel is None and c['window']+c['hold']-1>10:raise ValueError('The bundled path contains ten sessions. Shorten the window/hold or attach the panel.')

def matches(step,ctx):
    vals=[]
    for r in step['rules']:
        a=ctx.get(r['field']); b=ctx.get(r['rhs']) if r.get('rhs') else r.get('value')
        if pd.isna(a) or pd.isna(b):vals.append(None);continue
        if numeric(a) and numeric(b):
            a,b=round(float(a),9),round(float(b)*float(r.get('factor',1) if r.get('rhs') else 1),9)
        else:
            if r['op'] not in ['=','!=']:raise ValueError('Use equality for categorical conditions.')
            a,b=str(a).lower(),str(b).lower()
        vals.append(OPS[r['op']](a,b))
    if step['logic']=='all':
        if False in vals:return False
        if None in vals:raise Missing('Condition value unavailable')
        return True
    if True in vals:return True
    if None in vals:raise Missing('Condition value unavailable')
    return False

def fullbars(feed,sym,date):
    bars=feed.intrabars(sym,date);expected=pd.date_range(date+pd.Timedelta(hours=9,minutes=15),date+pd.Timedelta(hours=15,minutes=30),freq=f'{feed.minutes}min',inclusive='left')
    if len(bars)!=len(expected) or any(x['date']!=t for t,x in zip(expected,bars)):raise Missing('Incomplete intraday session')
    if any(not all(numeric(b[k]) for k in ['open','high','low','close','volume']) or not 0<b['low']<=min(b['open'],b['close'])<=max(b['open'],b['close'])<=b['high'] for b in bars):raise Missing('Invalid intraday prices')
    return bars

def trigger(feed,r,c):
    step=0; trace=[];laststamp=None;saved=None; intraday=any(s['phase']=='intraday' for s in c['steps'])
    def consume(phase,ctx,stamp):
        nonlocal step,laststamp,saved
        s=c['steps'][step]
        context={**r,**ctx,'event_value':saved}
        if stamp==laststamp or phase!=s['phase'] or not matches(s,context):return False
        if s.get('capture'):
            saved=context.get(s['capture'])
            if not numeric(saved):raise Missing('Captured numeric level unavailable')
        trace.append(f'{phase} {stamp}');step+=1;laststamp=stamp
        return step==len(c['steps'])
    def fill(day,session,price,ts,offset=0):
        if not numeric(price) or price<=0:raise Missing('Missing entry price')
        return dict(day=day,date=str(session['date'].date()),price=float(price),time=str(ts),offset=offset,trace=' → '.join(trace))
    pending=False
    for day in range(1,c['window']+1):
        s=feed.session(r,day)
        if s is None:raise Missing('Watch session unavailable')
        date=s['date'];op=date+pd.Timedelta(hours=9,minutes=15)
        if pending or consume('open',s,op):return fill(day,s,s['open'],op)
        if intraday:
            bars=fullbars(feed,r['symbol'],date);n=15//feed.minutes
            if abs(bars[0]['open']/s['open']-1)>.005:raise Missing('Intraday and daily opens differ by more than 0.5%')
            hi=max(x['high'] for x in bars[:n]);lo=min(x['low'] for x in bars[:n])
            for j,b in enumerate(bars):
                if j+1<n:continue
                end=b['date']+pd.Timedelta(minutes=feed.minutes)
                ctx={**s,'or_high':hi,'or_low':lo,**{'bar_'+k:b[k] for k in ['close','high','low','volume']}}
                if consume('intraday',ctx,end):
                    if j+1<len(bars):return fill(day,s,bars[j+1]['open'],end,j+1)
                    pending=True;break
        if not pending and consume('close',s,date+pd.Timedelta(hours=15,minutes=30)):pending=True
    return None

def exit_trade(feed,r,c,e):
    day=e['day'];end=day+c['hold']-1; ep=e['price'];intrabar=e['offset']>0
    def net(price):return (price/ep-1)*100-c['cost']
    def result(price,reason,s,ambiguous=False):
        exit_date=None;dd=None
        if s is not None:
            path=[feed.session(r,k) for k in range(day,s+1)]
            if all(b is not None for b in path):
                exit_date=str(path[-1]['date'].date())
                dd=trade_dd([ep]+[b['close'] for b in path[:-1]]+[price])
        return dict(exit_date=exit_date,trade_dd=dd,ret=net(price),exit=price,exit_day=s,reason=reason,ambiguous=ambiguous)
    target,stop=c['tp'],c['sl']
    if c['unit']=='atr' and (target or stop):
        atr=feed.session(r,day).get('prev_atr14')
        if not numeric(atr) or atr<=0:raise Missing('Prior ATR unavailable')
        unit=atr
    else:unit=ep/100
    tp=ep+target*unit if target else None;sl=ep-stop*unit if stop else None
    if sl is not None and sl<=0:raise Missing('Stop outside positive price range')
    if feed.panel is None and not feed.has_bars and (tp or sl):
        if day==1 and end==5 and not intrabar and tp and not sl:
            if not numeric(r['mfe']):raise Missing('Five-session high unavailable')
            if r['mfe']+1e-12>=tp/ep-1:return result(tp,'TP · touch day unknown',None)
        else:raise Missing('This exit needs daily highs/lows or intraday bars')
    for j in range(day,end+1):
        s=feed.session(r,j)
        if s is None or not numeric(s['close']):raise Missing('Exit horizon unavailable')
        if (tp or sl) and (feed.panel is not None or feed.has_bars):
            bars=fullbars(feed,r['symbol'],s['date']) if (intrabar and j==day) or feed.panel is None else [s]
            for b in bars[e['offset'] if intrabar and j==day else 0:]:
                if sl and b['open']<=sl:return result(b['open'],'Gap stop',j)
                if tp and b['open']>=tp:return result(tp,'TP',j)
                stop_hit=bool(sl and b['low']<=sl);target_hit=bool(tp and b['high']>=tp)
                if stop_hit:return result(sl,'SL',j,target_hit)
                if target_hit:return result(tp,'TP',j)
    return result(s['close'],'Time',end)

def run(feed,c):
    validate(feed,c);records=[]; candidates=[]
    states=c.get('states') or ([c['state']] if c.get('state') else [])
    known={p['pre_state'] for p in feed.picks}
    if not isinstance(states,list) or set(states)-known:raise ValueError('Unknown stock state selection')
    for r in feed.picks:
        if r['engine']!=c.get('engine','D') or r['rank']>c['rank'] or states and r['pre_state'] not in states or c.get('market') and r['pre_env_direction']!=c['market']:continue
        rec={k:r[k] for k in ['trade_id','symbol','rank','pre_state','signal_day']};rec['signal_day']=str(pd.Timestamp(rec['signal_day']).date());rec['market']=str(r['pre_env_direction']);records.append(rec)
        if r['status']=='ok' and numeric(r['net_bp']):rec['original']=r['net_bp']/100+.35-c['cost']
        if pd.notna(r.get('exit_day')) and pd.notna(r.get('exit_price')):
            ed=pd.Timestamp(r['exit_day']);rec['plan_exit_date']=str(ed.date())
            n=feed.dates.get(ed,-100)-feed.dates[pd.Timestamp(r['entry_day'])]
            if 0<=n<=10:rec['plan_trade_dd']=trade_dd([r['entry']]+[r['entry']*(1+r[f'close_{k}']) for k in range(1,n+1)]+[r['exit_price']])
        if r.get('open6_status')=='ok' and numeric(r.get('open6_net_bp')):rec['open6']=r['open6_net_bp']/100+.35-c['cost']
        if r['status']!='ok':rec['status']='Unsettled';continue
        try:e=trigger(feed,r,c)
        except Missing as exc:rec.update(status='Missing signal data',reason=str(exc));continue
        if not e:rec['status']='No entry';continue
        rec.update(e);candidates.append((rec,r))
    # Apply capacity before looking at exits; same-symbol repeat nominations are independent.
    used=set()
    for rec,r in sorted(candidates,key=lambda pair:(pair[0]['time'],pair[0]['rank'],pair[0]['signal_day'],pair[0]['trade_id'])):
        if c.get('one') and rec['date'] in used:rec['status']='Daily cap';continue
        used.add(rec['date'])
        try:rec.update(exit_trade(feed,r,c,rec),status='Filled',baseline=(r['net_bp']/100+.35-c['cost']))
        except Missing as exc:rec.update(status='Missing exit data',reason=str(exc))
    done=[r for r in records if r['status']=='Filled'];vals=np.array([r['ret'] for r in done])
    counts=dict(pd.Series([r['status'] for r in records],dtype='object').value_counts().items())
    counts={k:int(v) for k,v in counts.items()};eligible=len(records)-counts.get('Unsettled',0)
    missing=sum(v for k,v in counts.items() if k.startswith('Missing'))
    for r in done:r['pnl']=r['ret']*c['size']/100
    annual=defaultdict(list)
    for r in done:annual[r['date'][:4]].append(r['ret'])
    diagnostics={};consolidated={}
    for state in [None,*sorted({r['pre_state'] for r in records})]:
        cohort=[r for r in records if (state is None or r['pre_state']==state) and 'original' in r]
        if not cohort:continue
        filled=[r for r in cohort if r['status']=='Filled']
        skipped=[r for r in cohort if r['status'] in ('No entry','Daily cap')]
        unknown=len(cohort)-len(filled)-len(skipped)
        execution=sum(r['ret']-r['original'] for r in filled)
        avoided=sum(max(-r['original'],0) for r in skipped)
        foregone=sum(max(r['original'],0) for r in skipped)
        n=len(cohort)
        years={};year_report={}
        for yr in ['All years',*sorted({q['signal_day'][:4] for q in cohort})]:
            part=[q for q in cohort if yr=='All years' or q['signal_day'].startswith(yr)]
            fills=[q for q in part if q['status']=='Filled']
            absent=sum(q['status'].startswith('Missing') for q in part)
            total=sum(q['ret'] for q in fills);base=sum(q['original'] for q in part)/len(part)
            strategy=None if absent else total/len(part)
            open6_missing=sum('open6' not in q for q in part)
            open6=None if open6_missing else sum(q['open6'] for q in part)/len(part)
            year_report[yr]=dict(realized_dd=realized_dd(part,c['size'],'scenario'),plan_realized_dd=realized_dd(part,c['size'],'plan'),open6=open6,open6_missing=open6_missing,lift_open6=None if strategy is None or open6 is None else strategy-open6,eligible=len(part),fills=len(fills),missing=absent,
                filled_original=sum(q['original'] for q in fills)/len(fills) if fills else None,mean=total/len(fills) if fills else None,win=100*sum(q['ret']>0 for q in fills)/len(fills) if fills else None,
                strategy=strategy,original=base,lift=None if absent else strategy-base)
            if absent or yr=='All years':continue
            years[yr]=sum(q.get('ret',0)-q['original'] for q in part)/len(part)
        if state is None:
            consolidated=dict(scope='Selected: '+', '.join(states) if states else 'All states',year_report=year_report)
            continue
        diagnostics[state]=dict(years=years,year_report=year_report,n=n,fills=len(filled),missing=unknown,
            execution=execution/n,avoided=avoided/n,foregone=foregone/n,
            lift=None if unknown else (execution+avoided-foregone)/n,
            original=sum(r['original'] for r in cohort)/n,
            strategy=None if unknown else sum(r['ret'] for r in filled)/n,
            missed_big=sum(r['original']>=5 for r in skipped),
            avoided_severe=sum(r['original']<=-5 for r in skipped))
    return {'consolidated':consolidated,'diagnostics':diagnostics,'counts':counts,'n':len(done),'eligible':eligible,'missing':missing,'mean':float(vals.mean()) if len(vals) else None,'median':float(np.median(vals)) if len(vals) else None,'win':float((vals>0).mean()*100) if len(vals) else None,'severe':int(sum(vals<=-5)),'pnl':float(vals.sum()*c['size']/100),'baseline':float(np.mean([r['baseline'] for r in done])) if done else None,'per_pick':float(vals.sum()/eligible) if eligible and not missing else None,'annual':{y:[len(v),float(np.mean(v))] for y,v in sorted(annual.items())},'rows':records}
