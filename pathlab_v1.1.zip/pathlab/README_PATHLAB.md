# pathlab v1.1 (sealed discovery map, 31 Oct 2026)

Phase 1 of the BigMove behavioural path research: the Behavioural Path Atlas, built as the **sealed discovery map**.
Families, atlas and report read T0 from 2020-01-01 to 2022-12-31 only; the 2023-25 pages stay closed until you freeze
the candidate list. `unseal` is refused in this build.

New in v1.1: freeze command; the seal; event pages (state x tl_state event:status x event age); 10-session horizon and
the delay curve (entry at the open of T+d, exit at the open of T+d+5, net of 35 bp, d = 1..10); picks ranks 4-10;
ETFs out of the atlas (own table); the state x regime interaction inside the false-discovery control; state-floor
sampling for the families; Student's t p-values. Not in this build (listed in the declaration's "deferred"): the
walk-forward folds and 2026 labels (they come with `unseal`), the two new nulls, empirical-Bayes pooling and rare-path
rates, the 12-number event lens and 14-point intraday grid, the survivorship rerun (0 stocks stop inside the cache).

## Install

Copy the whole `pathlab` folder over `C:\Users\karanvsi\PyCharmMiscProject\pathlab\` (replace every file). tradelab
v1.3.1 stays as it is. Libraries: numpy, pandas, pyarrow, scipy.

## Commands (cmd)

```
call C:\Users\karanvsi\PyCharmMiscProject\pathlab\env_pathlab.bat
python tests\test_pathlab.py quick
python pathlab.py freeze
python pathlab.py run --root %CACHE_DAILY_ROOT%
```

- quick tests: about 3 minutes, last line `ALL 9 TESTS PASSED`.
- `freeze` prints what it freezes (seal date, families and atlas settings) and records the declaration's fingerprint
  in `C:\QuantData\pathlab\pathlab_ledger.jsonl`. `run` is refused before it. Any later change to the declaration
  needs `python pathlab.py freeze --amend "<reason>"` and is printed on every report.
- `run` = audit, build (sealed: nothing after the sealed windows is built), families, atlas, report. It resumes where
  it stopped: `python pathlab.py run --root %CACHE_DAILY_ROOT% --resume PL_YYYYMMDD_NNN`.
- The report: `C:\QuantData\pathlab\runs\PL_YYYYMMDD_NNN\ATLAS.html` (and ATLAS.md).

## What to send back

```
cd /d C:\QuantData\pathlab\runs
tar -a -c -f PL.zip --exclude=*.parquet PL_YYYYMMDD_NNN
```

plus the last 30 lines `run` printed.

## What pathlab never does

It reads the cache, the panel, pick_meta's run, the 3-minute bars and tradelab's code READ ONLY and writes only under
`PATHLAB_OUT` (`C:\QuantData\pathlab`). No default cache path (`--root` is required); `CACHE_HISTORY_ANCHOR` is never
touched; production's `research_ledger.jsonl` is never touched.
