# MANIFEST - pathlab v1.1, sealed discovery map (31 Oct 2026)

Copy every file below over `C:\Users\karanvsi\PyCharmMiscProject\pathlab\` (same folders). Nothing to ignore.
Not shipped: `__pycache__`, `tests\fingerprint.json` (the tests write it). Your copy of
`Phase 1 - Behavioural Path Atlas Audit and Protocol.md` stays as it is.

| file | sha256 (first 16) | bytes | role |
|---|---|---|---|
| `pathlab.py` | f591117ca25f6b33 | 14,207 | command line: audit, coverage, freeze, run (and its stages), status; unseal refused |
| `pl_common.py` | 8eb23461e3a00d54 | 22,674 | shared: declaration, lock and freeze record, seal filter, guards, ledger, bootstrap, BH, t p-values |
| `pl_build.py` | b3e0fcaddd0d2cfe | 51,484 | audit and build: rows (event age, 15-session window, delay curve), nulls, ETF list, integrity |
| `pl_coverage.py` | d99c372eb4a1e11d | 17,260 | the outcome-blind coverage audit (unchanged) |
| `pl_atlas.py` | 9f410a2daa253c29 | 77,214 | the atlas: cells, interaction, event pages, delay curve, picks 1-3 / 4-10, ETF table, sealed labels |
| `pl_families.py` | f5966797cf6a787a | 37,124 | family search: greedy seeding, state floor, split-half reproduction under the seal |
| `pl_paths.py` | c1c6874f69688e38 | 22,228 | five-day path measures (unchanged) |
| `pl_intraday.py` | d1860753b834e6f9 | 5,252 | 3-minute reader with tradelab's usable-session test (unchanged) |
| `pl_report.py` | a6ad75237a2eb66e | 62,877 | report: sealed map, candidates, event pages, delay curve, ETFs |
| `PATHLAB_DECLARATION.json` | 9c262801f0c0d1c6 | 15,442 | settings, READY TO FREEZE (seal on, 2020-01-01 to 2022-12-31) |
| `env_pathlab.bat` | 2172cf2cb353bd3a | 1,624 | session setup (CRLF, unchanged) |
| `README_PATHLAB.md` | ff829eeda4607547 | 2,597 | install, commands, what to send back |
| `MANIFEST_PATHLAB.md` | - | - | this file |
| `tests/test_pathlab.py` | 4aa6eb6181da0a8f | 46,198 | tests (quick: python tests\test_pathlab.py quick) |
| `tests/pl_world.py` | ca8c29e4c36b73f7 | 25,827 | synthetic worlds for the tests |

Requires tradelab v1.3.1 unchanged. Full suite (20 tests) passes on pandas 2.3.3 / numpy 2.4.1 / Python 3.12 (yours) and pandas 3.0.5 / numpy 2.5.3 / Python 3.13, from a clean extraction of the zip.
