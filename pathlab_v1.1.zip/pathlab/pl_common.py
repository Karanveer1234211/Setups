"""
pl_common.py - pathlab v1.1: shared pieces (version, declaration and its lock, paths and guards, ledger, logging,
the date-block bootstrap, multiple-comparison control, small statistics).

pathlab reads production data READ ONLY through tradelab v1.3.1's readers (stage E's bar loader, the 3-minute
store, the panel, pick_meta's run) and tradelab's state and regime code. It writes only under its own output folder
(PATHLAB_OUT, e.g. C:\\QuantData\\pathlab); the guards below refuse an output folder inside the cache, the
production code, tradelab's code or tradelab's output folder.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import math
import os
import platform
import sys
import time
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

VERSION = "pathlab v1.1"
HERE = Path(__file__).resolve().parent
DECLARATION_FILE = HERE / "PATHLAB_DECLARATION.json"
LEDGER_NAME = "pathlab_ledger.jsonl"
TRADELAB_WANTED = "tradelab v1.3.1"

# state and regime codes used in every table (the names come from tradelab)
STATE_CODES = {"INSUFFICIENT_DATA": -1, "UNKNOWN": 0, "S01": 1, "S02": 2, "S03": 3, "S06": 6, "S07": 7, "S08": 8,
               "S09": 9, "S12": 12}
STATE_FROM_CODE = {v: k for k, v in STATE_CODES.items()}
CELL_STATES = ("S01", "S02", "S03", "S06", "S07", "S08", "S09", "S12", "UNKNOWN")
REGIMES = ("broad_bullish", "narrow_bullish", "mixed", "broad_bearish", "high_stress")
REGIME_CODES = {k: i for i, k in enumerate(REGIMES)}
STATE_SHORT = {"S01": "Strong bull", "S02": "Emerging bull", "S03": "Bull consolidation", "S06": "Reversal attempt",
               "S07": "Neutral range", "S08": "Bear continuation", "S09": "Emerging bear", "S12": "Unstable",
               "UNKNOWN": "Unknown"}
REGIME_TEXT = {"broad_bullish": "Broad bullish", "narrow_bullish": "Narrow bullish", "mixed": "Mixed",
               "broad_bearish": "Broad bearish", "high_stress": "High stress"}
STAGE_NAMES = {1: "Up", 2: "Down", 3: "Quiet", 4: "Churn", 5: "Flat"}
# tl_state v1.1 (tradelab v1.3.1) EVENT_NUM: the build checks tradelab's own table against this one
EVENT_CODES = {"": 0, "BREAKOUT:NEW": 1, "BREAKOUT:CONFIRMED": 2, "BREAKOUT:STALLED": 3, "FAILED_BREAKOUT:FAILED": 4,
               "BREAKDOWN:NEW": 5, "BREAKDOWN:CONFIRMED": 6, "BREAKDOWN:STALLED": 7, "FAILED_BREAKDOWN:FAILED": 8}
EVENT_TEXT = {1: "S04 breakout NEW", 2: "S04 breakout CONFIRMED", 3: "S04 breakout STALLED",
              4: "S11 failed breakout", 5: "S10 breakdown NEW", 6: "S10 breakdown CONFIRMED", 7: "S10 breakdown STALLED",
              8: "failed breakdown (bear trap)"}


class PLError(RuntimeError):
    """A precondition or user error: printed, exit code 2, nothing written."""


class PLStop(RuntimeError):
    """A safety stop (integrity check failed, declaration changed): exit code 3, STOPPED.txt written."""


# ----------------------------------------------------------------------
# tradelab (read only)
# ----------------------------------------------------------------------
def tradelab(any_version: bool = False):
    """Import tradelab's modules. pathlab was built and tested against tradelab v1.3.1."""
    try:
        import tl_common as TC
        import tl_data as TD
        import tl_state as TS
        import tl_context as TX
    except ImportError as e:
        raise PLError(f"cannot import tradelab ({e}). Start with env_pathlab.bat: it puts tradelab and "
                      f"bigmove_deploy\\open_close on PYTHONPATH (read only)") from e
    if TC.VERSION != TRADELAB_WANTED and not any_version:
        raise PLError(f"tradelab at {Path(TC.__file__).parent} is {TC.VERSION}; pathlab v1.0 was tested against "
                      f"{TRADELAB_WANTED}. Pass --tradelab-any to accept it knowingly.")
    return TC, TD, TS, TX


# ----------------------------------------------------------------------
# hashing, files
# ----------------------------------------------------------------------
def sha256_file(p) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def sha16_text(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()[:16]


def canon(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str)


def file_sig(p: Path) -> Optional[List[int]]:
    """(size, mtime in ns) of a file, None when absent - a cheap change detector for resumable stages."""
    try:
        st = Path(p).stat()
    except OSError:
        return None
    return [int(st.st_size), int(st.st_mtime_ns)]


def write_parquet_atomic(df: pd.DataFrame, path: Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    df.to_parquet(tmp, index=False)
    os.replace(tmp, path)


def write_json_atomic(obj, path: Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, default=str, sort_keys=False), encoding="utf-8")
    os.replace(tmp, path)


def read_json(path: Path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def write_table(df: pd.DataFrame, path_no_ext: Path, csv: bool = True, parquet: bool = True) -> None:
    path_no_ext = Path(path_no_ext)
    path_no_ext.parent.mkdir(parents=True, exist_ok=True)
    if parquet:
        write_parquet_atomic(df, path_no_ext.with_suffix(".parquet"))
    if csv:
        df.to_csv(path_no_ext.with_suffix(".csv"), index=False, float_format="%.8g")


def write_outputs_sha(run_dir: Path) -> None:
    lines = []
    for p in sorted(Path(run_dir).rglob("*")):
        if p.is_file() and p.name != "outputs.sha256":
            lines.append(f"{sha256_file(p)}  {p.relative_to(run_dir).as_posix()}")
    (Path(run_dir) / "outputs.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")


# ----------------------------------------------------------------------
# declaration and its lock
# ----------------------------------------------------------------------
def load_declaration(path: Optional[str] = None) -> Tuple[dict, str, Path]:
    p = Path(path) if path else DECLARATION_FILE
    if not p.exists():
        raise PLError(f"declaration {p} not found")
    try:
        decl = json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise PLError(f"declaration {p} is not valid JSON ({e})") from e
    return decl, sha16_text(canon(decl)), p


def sealed(D: dict) -> bool:
    """The discovery seal (Karan, 31 Oct): families, atlas and report read only T0 up to seal.last_t0."""
    return bool((D.get("seal") or {}).get("active"))


def seal_last(D: dict) -> np.datetime64:
    return day(D["seal"]["last_t0"])


def seal_filter(D: dict):
    """A pyarrow row filter for load_rows: rows with T0 after the seal are never read (None when not sealed)."""
    if not sealed(D):
        return None
    import pyarrow as pa
    import pyarrow.compute as pcm
    lim_ns = int((seal_last(D) + np.timedelta64(1, "D")).astype("datetime64[ns]").astype(np.int64))

    def filt(t):
        if "t0" not in t.column_names or not pa.types.is_timestamp(t["t0"].type):
            raise PLError("a cache file has no timestamp t0 column - the seal cannot be applied; rebuild that stock")
        ns = pcm.cast(pcm.cast(t["t0"], pa.timestamp("ns")), pa.int64())
        return t.filter(pcm.less(ns, pa.scalar(lim_ns, pa.int64())))
    return filt


def frozen_record(base: Path, fp: str) -> Optional[dict]:
    """The ledger's 'protocol_frozen' record for this declaration fingerprint (None = not frozen)."""
    recs = [r for r in ledger_read(base) if r.get("event") == "protocol_frozen" and r.get("fingerprint") == fp]
    return recs[-1] if recs else None


def check_lock(base: Path, fp: str, decl_path: Path, amend: Optional[str], log) -> dict:
    """The first build on an output folder locks the declaration's fingerprint. A different fingerprint later is
    refused unless --amend gives a written reason (logged; every report prints it)."""
    recs = ledger_read(base)
    locks = [r for r in recs if r.get("event") == "declaration_locked"]
    amends = [r for r in recs if r.get("event") == "declaration_amended"]
    current = amends[-1]["new"] if amends else (locks[0]["fingerprint"] if locks else None)
    if current is None:
        ledger_append(base, {"event": "declaration_locked", "fingerprint": fp, "file": str(decl_path)})
        log(f"   declaration {fp} locked for {base} (first build)")
        return {"fingerprint": fp, "locked_now": True, "amendments": []}
    if fp == current:
        return {"fingerprint": fp, "locked_now": False, "amendments": amends}
    if not amend:
        raise PLStop(f"PATHLAB_DECLARATION.json changed: fingerprint {fp}, locked {current}. The declaration is fixed "
                     f"after the first build. If the change is a real correction (not a tweak to improve a result), "
                     f"run again with --amend \"<the reason>\"; it is logged and printed on every report.")
    ledger_append(base, {"event": "declaration_amended", "old": current, "new": fp, "reason": amend,
                         "file": str(decl_path)})
    log(f"   declaration amended {current} -> {fp}: {amend}")
    return {"fingerprint": fp, "locked_now": False, "amendments": amends + [{"old": current, "new": fp,
                                                                            "reason": amend}]}


def amendments(base: Path) -> List[dict]:
    return [r for r in ledger_read(base) if r.get("event") == "declaration_amended"]


# ----------------------------------------------------------------------
# paths and guards
# ----------------------------------------------------------------------
def require_root(root_arg: Optional[str]) -> Path:
    """The cache root must be given explicitly (--root %CACHE_DAILY_ROOT%). No silent default."""
    if not root_arg:
        raise PLError("--root is required (use --root %CACHE_DAILY_ROOT% after call env_pathlab.bat)")
    root = Path(root_arg)
    if not root.is_dir():
        raise PLError(f"--root {root} is not a folder")
    return root


def _inside(child: Path, parent: Path) -> bool:
    try:
        child, parent = child.resolve(), parent.resolve()
    except OSError:
        return False
    return child == parent or parent in child.parents


def out_base(out_arg: Optional[str], root: Optional[Path] = None) -> Path:
    v = out_arg or os.environ.get("PATHLAB_OUT")
    if not v:
        raise PLError("no output folder: pass --out or start with env_pathlab.bat (sets PATHLAB_OUT)")
    base = Path(v)
    guards = []
    if root is not None:
        guards.append(("the cache root (--root)", Path(root)))
    for name, env in (("the cache (CACHE_DAILY_ROOT)", "CACHE_DAILY_ROOT"), ("production code (BIGMOVE_DIR)", "BIGMOVE_DIR"),
                      ("tradelab's code (TRADELAB_DIR)", "TRADELAB_DIR"), ("tradelab's outputs (TRADELAB_OUT)", "TRADELAB_OUT")):
        if os.environ.get(env):
            guards.append((name, Path(os.environ[env])))
    guards.append(("pathlab's own code", HERE))
    for name, g in guards:
        if _inside(base, g):
            raise PLError(f"output folder {base} is inside {name} ({g}); pathlab never writes there")
    base.mkdir(parents=True, exist_ok=True)
    return base


def new_run_dir(base: Path, prefix: str = "PL") -> Path:
    d = Path(base) / "runs"
    d.mkdir(parents=True, exist_ok=True)
    stamp = dt.datetime.now().strftime("%Y%m%d")
    n = 1
    while (d / f"{prefix}_{stamp}_{n:03d}").exists():
        n += 1
    p = d / f"{prefix}_{stamp}_{n:03d}"
    p.mkdir()
    return p


def find_run_dir(base: Path, run: str) -> Path:
    p = Path(base) / "runs" / run
    if not p.is_dir():
        raise PLError(f"run {run} not found under {Path(base) / 'runs'}")
    return p


# ----------------------------------------------------------------------
# ledger (pathlab's own; production's research_ledger.jsonl and tradelab's ledger are never touched)
# ----------------------------------------------------------------------
def ledger_append(base: Path, rec: dict) -> None:
    rec = dict(rec)
    rec.setdefault("time", dt.datetime.now().isoformat(timespec="seconds"))
    rec.setdefault("version", VERSION)
    with open(Path(base) / LEDGER_NAME, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, default=str) + "\n")


def ledger_read(base: Path) -> List[dict]:
    p = Path(base) / LEDGER_NAME
    if not p.exists():
        return []
    out = []
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                out.append({"unreadable": line[:200]})
    return out


# ----------------------------------------------------------------------
# logging
# ----------------------------------------------------------------------
class Log:
    """Prints and appends to a log file (the run folder's log.txt)."""

    def __init__(self, path: Optional[Path] = None, quiet: bool = False):
        self.path = Path(path) if path else None
        self.quiet = quiet
        self.t0 = time.time()

    def __call__(self, msg: str) -> None:
        if not self.quiet:
            print(msg, flush=True)
        if self.path is not None:
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(msg + "\n")

    def elapsed(self) -> str:
        s = time.time() - self.t0
        return f"{s / 60:.1f} min" if s >= 120 else f"{s:.0f} s"


def provenance(extra: Optional[dict] = None) -> dict:
    files = {p.name: sha256_file(p)[:16] for p in sorted(HERE.glob("pl_*.py"))}
    files["pathlab.py"] = sha256_file(HERE / "pathlab.py")[:16] if (HERE / "pathlab.py").exists() else None
    d = {"version": VERSION, "python": sys.version.split()[0], "platform": platform.platform(),
         "numpy": np.__version__, "pandas": pd.__version__, "code_sha16": files,
         "created": dt.datetime.now().isoformat(timespec="seconds")}
    for mod in ("pyarrow", "scipy"):
        try:
            d[mod] = __import__(mod).__version__
        except Exception:  # noqa: BLE001
            d[mod] = None
    if extra:
        d.update(extra)
    return d


# ----------------------------------------------------------------------
# the date-block bootstrap
# ----------------------------------------------------------------------
def circular_block_index(n: int, B: int, block: int, seed: int) -> np.ndarray:
    """B x n positions drawn as circular blocks of `block` consecutive dates (tradelab's convention, same draws)."""
    if n <= 0:
        return np.zeros((B, 0), dtype=np.int64)
    rng = np.random.default_rng(seed)
    k = int(np.ceil(n / block))
    starts = rng.integers(0, n, size=(B, k))
    idx = (starts[:, :, None] + np.arange(block)[None, None, :]) % n
    return idx.reshape(B, k * block)[:, :n]


def block_weights(n: int, B: int, block: int, seed: int) -> np.ndarray:
    """B x n matrix: how many times each date is drawn in each resample (float64)."""
    I = circular_block_index(n, B, block, seed)
    W = np.zeros((B, max(n, 1)), dtype=np.float64)
    if n:
        rows = np.repeat(np.arange(B), I.shape[1])
        np.add.at(W, (rows, I.ravel()), 1.0)
    return W[:, :n]


def ratio_boot(S: np.ndarray, N: np.ndarray, W: np.ndarray, chunk: int = 1500) -> np.ndarray:
    """Per-date sums S and counts N (dates x m) -> B x m bootstrap ratios sum(S)/sum(N) (NaN where no count)."""
    S = np.asarray(S, dtype=np.float64)
    N = np.asarray(N, dtype=np.float64)
    out = np.empty((W.shape[0], S.shape[1]), dtype=np.float64)
    for a in range(0, S.shape[1], chunk):
        b = min(S.shape[1], a + chunk)
        num = W @ S[:, a:b]
        den = W @ N[:, a:b]
        with np.errstate(divide="ignore", invalid="ignore"):
            out[:, a:b] = np.where(den > 0, num / np.where(den > 0, den, 1.0), np.nan)
    return out


def interval(boot: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """2.5% / 97.5% percentiles and the standard deviation of bootstrap columns (NaN-safe)."""
    with np.errstate(invalid="ignore"):
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            lo = np.nanpercentile(boot, 2.5, axis=0)
            hi = np.nanpercentile(boot, 97.5, axis=0)
            sd = np.nanstd(boot, axis=0, ddof=1)
    return lo, hi, sd


def nanpct(x: np.ndarray, q, axis=0) -> np.ndarray:
    """np.nanpercentile without the all-NaN warnings (an empty group gives NaN)."""
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        return np.nanpercentile(x, q, axis=axis)


def p_two_sided(z: np.ndarray) -> np.ndarray:
    z = np.asarray(z, dtype=float)
    out = np.full(z.shape, np.nan)
    ok = np.isfinite(z)
    out[ok] = np.array([math.erfc(abs(v) / math.sqrt(2.0)) for v in z[ok]])
    return out


def p_two_sided_t(z: np.ndarray, df: np.ndarray) -> np.ndarray:
    """Two-sided p from Student's t with df degrees of freedom (df = separate 10-session stretches - 1): the
    bootstrap standard error is itself estimated from that many independent stretches, and the normal reference
    made 3- and 4-sigma results in synthetic no-effect worlds look rarer than they are."""
    from scipy.special import stdtr
    z = np.asarray(z, dtype=float)
    df = np.maximum(np.asarray(df, dtype=float), 1.0)
    out = np.full(np.broadcast(z, df).shape, np.nan)
    ok = np.isfinite(z) & np.isfinite(df) & np.ones_like(out, bool)
    zz, dd = np.broadcast_arrays(z, df)
    out[ok] = 2.0 * stdtr(dd[ok], -np.abs(zz[ok]))
    return out


def bh(p: np.ndarray, q: float) -> Tuple[np.ndarray, np.ndarray]:
    """Benjamini-Hochberg: (reject mask, adjusted q-values). NaN p-values are never rejected."""
    p = np.asarray(p, dtype=float)
    rej = np.zeros(p.shape, dtype=bool)
    qv = np.full(p.shape, np.nan)
    ok = np.flatnonzero(np.isfinite(p))
    m = len(ok)
    if m == 0:
        return rej, qv
    order = ok[np.argsort(p[ok], kind="mergesort")]
    ps = p[order]
    ranks = np.arange(1, m + 1)
    adj = np.minimum.accumulate((ps * m / ranks)[::-1])[::-1]
    qv[order] = np.minimum(adj, 1.0)
    passed = np.flatnonzero(ps <= ranks / m * q)
    if len(passed):
        rej[order[: passed[-1] + 1]] = True
    return rej, qv


# ----------------------------------------------------------------------
# small statistics
# ----------------------------------------------------------------------
def ari(a: np.ndarray, b: np.ndarray) -> float:
    """Adjusted Rand index of two labelings (1 = identical partitions, about 0 = chance)."""
    a = np.asarray(a)
    b = np.asarray(b)
    n = len(a)
    if n < 2:
        return float("nan")
    _, ai = np.unique(a, return_inverse=True)
    _, bi = np.unique(b, return_inverse=True)
    ka, kb = ai.max() + 1, bi.max() + 1
    cont = np.bincount(ai * kb + bi, minlength=ka * kb).reshape(ka, kb).astype(np.float64)

    def c2(x):
        return x * (x - 1) / 2.0

    s_ij = c2(cont).sum()
    s_a = c2(cont.sum(axis=1)).sum()
    s_b = c2(cont.sum(axis=0)).sum()
    exp = s_a * s_b / c2(float(n))
    mx = 0.5 * (s_a + s_b)
    if mx == exp:
        return 1.0
    return float((s_ij - exp) / (mx - exp))


def mutual_info(x: np.ndarray, y: np.ndarray, kx: int, ky: int) -> float:
    """Mutual information in bits of two integer labelings coded 0..kx-1 and 0..ky-1."""
    n = len(x)
    if n == 0:
        return float("nan")
    t = np.bincount(x * ky + y, minlength=kx * ky).reshape(kx, ky).astype(np.float64) / n
    px = t.sum(axis=1, keepdims=True)
    py = t.sum(axis=0, keepdims=True)
    with np.errstate(divide="ignore", invalid="ignore"):
        r = np.where(t > 0, t * np.log2(t / (px @ py)), 0.0)
    return float(r.sum())


def quantiles_from_cdf(grid: np.ndarray, cdf: np.ndarray, qs: Sequence[float]) -> np.ndarray:
    """cdf: (..., len(grid)) non-decreasing values at grid points (P(X <= g)); returns (..., len(qs)) linear
    interpolation of the first crossing of each q. Values below the grid give grid[0], above give grid[-1]."""
    cdf = np.asarray(cdf, dtype=float)
    out = np.full(cdf.shape[:-1] + (len(qs),), np.nan)
    flat = cdf.reshape(-1, cdf.shape[-1])
    o = out.reshape(-1, len(qs))
    for r in range(flat.shape[0]):
        f = flat[r]
        if not np.isfinite(f).all():
            continue
        f = np.maximum.accumulate(f)
        for j, q in enumerate(qs):
            k = int(np.searchsorted(f, q, side="left"))
            if k <= 0:
                o[r, j] = grid[0]
            elif k >= len(grid):
                o[r, j] = grid[-1]
            else:
                f0, f1 = f[k - 1], f[k]
                w = 0.0 if f1 <= f0 else (q - f0) / (f1 - f0)
                o[r, j] = grid[k - 1] + w * (grid[k] - grid[k - 1])
    return out


def fmt(x, nd: int = 3, pct: bool = False, sign: bool = True) -> str:
    try:
        if x is None or not np.isfinite(float(x)):
            return "n/a"
    except (TypeError, ValueError):
        return str(x)
    v = float(x) * (100.0 if pct else 1.0)
    s = f"{v:+.{nd}f}" if sign else f"{v:.{nd}f}"
    return s + ("%" if pct else "")


def fmt_ci(m, lo, hi, nd: int = 3, pct: bool = False, sign: bool = True) -> str:
    a = fmt(m, nd, pct, sign)
    if lo is None or hi is None or not (np.isfinite(lo) and np.isfinite(hi)):
        return a
    return f"{a} [{fmt(lo, nd, pct, sign)}, {fmt(hi, nd, pct, sign)}]"


def to_day(x) -> np.ndarray:
    """Any timestamps (tz-aware -> IST) -> numpy datetime64[D] (IST calendar day)."""
    s = pd.to_datetime(pd.Series(x))
    if getattr(s.dt, "tz", None) is not None:
        s = s.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
    return s.to_numpy(dtype="datetime64[ns]").astype("datetime64[D]")


def day(s: str) -> np.datetime64:
    try:
        return np.datetime64(dt.date.fromisoformat(str(s)), "D")
    except ValueError:
        raise PLError(f"date '{s}' is not YYYY-MM-DD") from None


def sym_seed(seed: int, sym: str) -> int:
    """A per-symbol seed that does not depend on the order symbols are processed in."""
    return int(hashlib.sha256(f"{seed}:{sym}".encode("utf-8")).hexdigest()[:12], 16)
