"""
pathlab.py - pathlab v1.1: Phase 1 of the BigMove behavioural path research (the Behavioural Path Atlas).

Start a session with env_pathlab.bat, then:

    python pathlab.py audit --root %CACHE_DAILY_ROOT%          what exists, what is missing (computes no path)
    python pathlab.py coverage --root %CACHE_DAILY_ROOT%       counts per state x regime x year (reads nothing after T0)
    python pathlab.py freeze                                    record the declaration's fingerprint (once, before any run)
    python pathlab.py run   --root %CACHE_DAILY_ROOT%          audit -> build -> families -> atlas -> report
    python pathlab.py run   --root %CACHE_DAILY_ROOT% --resume PL_20261026_001     finish a stopped run
    python pathlab.py status                                    runs, the build caches, the declaration lock

One stage at a time (the same run folder): build | families --run PL_... | atlas --run PL_... | report --run PL_...

pathlab reads production data READ ONLY through tradelab v1.3.1 (stage E's bar loader, the 3-minute store, the panel,
pick_meta's run, tl_state, tl_context) and writes only under PATHLAB_OUT. The settings are PATHLAB_DECLARATION.json;
the first build locks its fingerprint, and a changed declaration is refused unless --amend "<reason>" (printed on
every report). Every stage saves its work: a stopped run resumes where it stopped.

The discovery seal (declaration "seal"): families, atlas and report read only T0 up to 2022-12-31. The 2023-25 pages
stay closed until the candidate list is frozen; 'unseal' is refused in this build.

Exit codes: 0 done, 2 a precondition failed (nothing written), 3 a safety stop (STOPPED.txt in the run folder).
"""
from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import pl_common as PC



def _args(argv=None):
    ap = argparse.ArgumentParser(prog="pathlab", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    def common(p, root=True):
        if root:
            p.add_argument("--root", help="the cache root: %%CACHE_DAILY_ROOT%% (required, no default)")
            p.add_argument("--tlx", help="tradelab's export folder for the integrity check (default: "
                                         "%%TRADELAB_OUT%%\\export\\<the declaration's tlx_export>)")
            p.add_argument("--stage-e-any", action="store_true", help="accept a stage_e_execution.py that is not the shipped v1.2")
        p.add_argument("--out", help="output folder (default %%PATHLAB_OUT%%)")
        p.add_argument("--declaration", help="a declaration file other than PATHLAB_DECLARATION.json (tests)")
        p.add_argument("--amend", help="accept a changed declaration, with this reason (logged, printed on every report)")
        p.add_argument("--tradelab-any", action="store_true", help="accept a tradelab version other than v1.3.1")

    p = sub.add_parser("audit", help="read everything, print what exists and what is missing")
    common(p)
    p = sub.add_parser("coverage", help="outcome-blind counts per state x regime x year and window")
    common(p)
    p = sub.add_parser("run", help="audit, build, families, atlas, report")
    common(p)
    p.add_argument("--resume", help="an existing run folder name (PL_YYYYMMDD_NNN) to finish")
    p = sub.add_parser("build", help="the per-stock path rows (resumable) and the integrity check")
    common(p)
    for nm in ("families", "atlas", "report"):
        p = sub.add_parser(nm, help=f"the {nm} stage of an existing run")
        common(p, root=False)
        p.add_argument("--run", required=True, help="the run folder name (PL_YYYYMMDD_NNN)")
    p = sub.add_parser("status", help="runs, build caches and the declaration lock")
    common(p, root=False)
    p = sub.add_parser("freeze", help="record the declaration's fingerprint as the frozen protocol (before any run)")
    common(p, root=False)
    p = sub.add_parser("unseal", help="open the 2023-25 pages (refused until the candidate list is frozen)")
    common(p, root=False)
    # test hooks (not for production use)
    for p in sub.choices.values():
        p.add_argument("--max-symbols", type=int, help=argparse.SUPPRESS)
        p.add_argument("--test-stop-after", type=int, help=argparse.SUPPRESS)
        p.add_argument("--allow-unfrozen", action="store_true", help=argparse.SUPPRESS)
    return ap.parse_args(argv)


def _tlx(a, D) -> Path:
    if a.tlx:
        p = Path(a.tlx)
    else:
        tout = os.environ.get("TRADELAB_OUT")
        if not tout:
            raise PC.PLError("--tlx is required (or set TRADELAB_OUT: env_pathlab.bat does)")
        p = Path(tout) / "export" / D["inputs"]["tlx_export"]
    if not (p / "trades.parquet").exists():
        raise PC.PLError(f"TLX export {p} has no trades.parquet (pass --tlx <the export folder>)")
    return p


def main(argv=None) -> int:
    a = _args(argv)
    t0 = time.time()
    run_dir = None
    try:
        decl, fp, dpath = PC.load_declaration(a.declaration)
        root = PC.require_root(a.root) if getattr(a, "root", None) is not None or a.cmd in ("audit", "run", "build", "coverage") else None
        base = PC.out_base(a.out, root)
        if a.cmd == "status":
            return status(base, fp)
        if a.cmd == "freeze":
            return freeze(base, decl, fp, dpath, a.amend)
        if a.cmd == "unseal":
            raise PC.PLError("the 2023-25 pages stay closed until the candidate list (setup ideas from the 2020-22 "
                             "pages) is frozen; the unseal stage (walk-forward 2023, 2024, 2025 on the frozen list) "
                             "is not in this build")
        if a.cmd in ("run", "build", "families", "atlas", "report") and not a.allow_unfrozen and \
                not PC.frozen_record(base, fp):
            raise PC.PLError(f"the declaration {fp} is not frozen for {base}: run 'python pathlab.py freeze' first "
                             f"(it prints what you are freezing)")
        if a.cmd == "coverage":
            import pl_coverage as PV
            PV.run_coverage(root, decl, base, None, a.stage_e_any, a.tradelab_any)
            return 0
        if a.cmd in ("families", "atlas", "report"):
            run_dir = PC.find_run_dir(base, a.run)
        elif a.cmd == "run" and a.resume:
            run_dir = PC.find_run_dir(base, a.resume)
        elif a.cmd in ("run", "audit"):
            run_dir = PC.new_run_dir(base)
        log = PC.Log(run_dir / "log.txt" if run_dir else base / "build_log.txt")
        log(f"{PC.VERSION} {a.cmd} | declaration {fp} ({dpath.name}) | output {base}" +
            (f" | run {run_dir.name}" if run_dir else ""))
        if a.cmd == "audit":
            import pl_build as PB
            PB.audit(root, decl, base, run_dir, _tlx_or_none(a, decl), log, a.stage_e_any, a.tradelab_any)
            return 0
        if a.cmd in ("run", "build"):
            import pl_build as PB
            tlx = _tlx(a, decl)
            if a.cmd == "run" and not (run_dir / "audit" / "audit.json").exists():
                PB.audit(root, decl, base, run_dir, tlx, log, a.stage_e_any, a.tradelab_any)
            lock = PC.check_lock(base, fp, dpath, a.amend, log)
            world = PB.World(root, decl, a.stage_e_any, a.tradelab_any, log)
            cdir = PB.build(world, base, fp, tlx, log, max_symbols=a.max_symbols, stop_after=a.test_stop_after)
            if a.cmd == "build":
                return 0
            meta = PC.read_json(run_dir / "run.json", {}) or {}
            if meta.get("cache") and Path(meta["cache"]) != cdir:
                raise PC.PLStop(f"this run started on build {Path(meta['cache']).name}; the data or code now gives "
                                f"{cdir.name}. Start a new run (python pathlab.py run ...) instead of resuming.")
            PC.write_json_atomic({"cache": str(cdir), "declaration": fp, "lock": {k: v for k, v in lock.items() if k != "amendments"},
                                  "root": str(root), "tlx": str(tlx), "started": meta.get("started") or time.strftime("%Y-%m-%d %H:%M:%S")},
                                 run_dir / "run.json")
            stages_after_build(run_dir, cdir, decl, base, fp, log, ("families", "atlas", "report"))
            log(f"{PC.VERSION} run {run_dir.name} finished in {log.elapsed()}: open {run_dir / 'ATLAS.html'}")
            return 0
        meta = PC.read_json(run_dir / "run.json", {}) or {}
        if not meta.get("cache"):
            raise PC.PLError(f"{run_dir.name} has no build yet (run.json missing) - use python pathlab.py run --resume {run_dir.name}")
        if meta.get("declaration") != fp:
            raise PC.PLStop(f"{run_dir.name} was built under declaration {meta.get('declaration')}; this one is {fp}")
        stages_after_build(run_dir, Path(meta["cache"]), decl, base, fp, log, (a.cmd,))
        return 0
    except KeyboardInterrupt as e:
        print(f"stopped ({e}); run again with --resume to continue", flush=True)
        return 130
    except PC.PLStop as e:
        print(f"STOPPED: {e}", flush=True)
        if run_dir is not None:
            (run_dir / "STOPPED.txt").write_text(str(e) + "\n", encoding="utf-8")
        return 3
    except PC.PLError as e:
        print(f"ERROR: {e}", flush=True)
        return 2
    except Exception as e:  # noqa: BLE001 - tradelab's own errors (TLError, StopRun) carry their fix in the text
        nm = type(e).__name__
        if nm == "StopRun":
            print(f"STOPPED: {e}", flush=True)
            if run_dir is not None:
                (run_dir / "STOPPED.txt").write_text(str(e) + "\n", encoding="utf-8")
            return 3
        if nm == "TLError":
            print(f"ERROR: {e}", flush=True)
            return 2
        raise


def _tlx_or_none(a, D):
    try:
        return _tlx(a, D)
    except PC.PLError:
        return None


def freeze(base: Path, D: dict, fp: str, dpath: Path, amend) -> int:
    """Lock the declaration (or amend the lock, with a reason) and record it as the frozen protocol."""
    got = PC.frozen_record(base, fp)
    if got:
        print(f"already frozen: declaration {fp} on {got.get('time')} ({base})")
        return 0
    log = PC.Log(base / "build_log.txt")
    PC.check_lock(base, fp, dpath, amend, log)
    sp, se = D["span"], D.get("seal") or {}
    F, A = D["families"], D["atlas"]
    lines = [f"freezing declaration {fp} ({dpath})",
             f"  seal: {'ON - families, atlas and report read T0 up to ' + str(se.get('last_t0')) if PC.sealed(D) else 'OFF'}",
             f"  T0 {sp['t0_first']} to {sp['t0_last']}; 3-minute paths from {sp['intraday_first']}",
             f"  window {D['window']['sessions']} sessions; long horizon {D['window'].get('horizon_long')}; delay curve "
             f"d = 1..{(D['window'].get('delay') or {}).get('max_d')}",
             f"  families k {F['k_min']}-{F['k_max']}, stability ARI >= {F['stability_min_ari']}, valley <= "
             f"{F['separation_valley_max']}, state floor {F.get('state_floor')}",
             f"  atlas: bootstrap B {A['boot_B']}, blocks {A['boot_block']}, seed {A['boot_seed']}; BH {A['fdr_q']}; period "
             f"minimums {A['period_min_dates']} dates / {A['period_min_obs']} paths / {A['period_min_stretches']} stretches",
             f"  costs {D['costs_bp_round_trip']} bp round trip"]
    for ln in lines:
        log(ln)
    PC.ledger_append(base, {"event": "protocol_frozen", "fingerprint": fp, "file": str(dpath), "seal": se,
                            "reason": amend})
    log(f"frozen: {fp}. Change nothing in the declaration from here; a change needs 'freeze --amend \"<reason>\"'.")
    return 0


def stages_after_build(run_dir: Path, cdir: Path, decl: dict, base: Path, fp: str, log, stages) -> None:
    if "families" in stages:
        import pl_families as PF
        PF.run_families(cdir, run_dir, decl, log)
    if "atlas" in stages:
        import pl_atlas as PA
        PA.run_atlas(cdir, run_dir, decl, log)
    if "report" in stages:
        import pl_report as PR
        PR.run_report(cdir, run_dir, decl, base, fp, log)


def status(base: Path, fp: str) -> int:
    recs = PC.ledger_read(base)
    locks = [r for r in recs if r.get("event") == "declaration_locked"]
    am = [r for r in recs if r.get("event") == "declaration_amended"]
    print(f"{PC.VERSION} - output folder {base}")
    if locks:
        cur = am[-1]["new"] if am else locks[0]["fingerprint"]
        print(f"  declaration locked {locks[0].get('time')} as {locks[0]['fingerprint']}; current {cur}; this file {fp} "
              f"({'matches' if cur == fp else 'DIFFERS - a build would be refused without --amend'})")
        for r in am:
            print(f"  amended {r.get('time')}: {r.get('old')} -> {r.get('new')}: {r.get('reason')}")
    else:
        print(f"  declaration not locked yet (the first build locks {fp})")
    fr = PC.frozen_record(base, fp)
    print(f"  protocol {'FROZEN ' + str(fr.get('time')) if fr else 'NOT frozen (python pathlab.py freeze)'}; seal "
          f"{'ON' if (fr or {}).get('seal', {}).get('active') else 'see the declaration'}")
    for c in sorted((base / "cache").glob("*")) if (base / "cache").exists() else []:
        done = PC.read_json(c / "BUILD_DONE.json")
        n = len(list((c / "done").glob("*.json"))) if (c / "done").exists() else 0
        print(f"  build {c.name}: {n:,} stocks built" + (f", finished ({done.get('rows', 0):,} rows, integrity "
                                                         f"{(done.get('integrity') or {}).get('status')})" if done else ", NOT finished"))
    for r in sorted((base / "runs").glob("PL_*")) if (base / "runs").exists() else []:
        st = [s for s in ("audit", "families", "atlas") if (r / s).exists()]
        rep = (r / "ATLAS.html").exists()
        stop = (r / "STOPPED.txt").exists()
        print(f"  run {r.name}: {', '.join(st) or 'started'}{' -> report' if rep else ''}{'  STOPPED' if stop else ''}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
