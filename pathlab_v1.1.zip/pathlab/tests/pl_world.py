"""
tests/pl_world.py - synthetic worlds for pathlab's tests (nothing here is shipped to production).

make_cache_world(root)   a fake production cache (the layout tradelab reads) from mid-2019 to October 2026:
    NIFTY50 / NIFTYMIDCAP150 / NIFTYSMLCAP250 / INDIAVIX daily files (a market factor with bull, bear, sideways and
    crash blocks, so the regime labels move), ~30 stocks (beta x market + own noise), 3-minute files for some of
    them from 2021-10-01 (bars that reproduce each daily bar exactly, with planted unusable sessions), panel_oc,
    pick_meta's PM_TEST_001 (D and ENS ranks 1-10), a TLX export (trades.parquet) computed by an INDEPENDENT hand
    implementation, <SYMBOL>_daily.ok.json files, and tradelab's stand-in production modules (tests/tl_world.py).
    Planted cases: SPLITSYM (an unadjusted split, listed in its ok.json), SUSPSYM (3 sessions missing), LATESYM
    (lists in 2021), GONESYM (delisted in 2024), CASHFUND (a money-market fund: tiny ranges), LOCKSYM (sessions with
    high = low), HANDSYM (hand-written bars after one T0, checked number by number).

make_rows_world(cdir, kind)   a fake pathlab BUILD cache (rows / null files) for the family and atlas tests:
    'planted'  six path families at known shares; S01 and high-stress change the family odds by known amounts
    'nolift'   the same families, nothing depends on state or regime
    'absent'   every path a random walk: no families beyond what a random walk makes, no state or regime effect
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
PL = HERE.parent
def _tradelab_dir() -> Path:
    import os
    for c in (os.environ.get("TRADELAB_DIR"), PL.parent / "tradelab", PL.parent / "ref" / "tradelab"):
        if c and (Path(c) / "tl_common.py").exists():
            return Path(c)
    raise RuntimeError("tradelab not found: set TRADELAB_DIR (env_pathlab.bat does)")


TRADELAB_DIR = _tradelab_dir()
TRADELAB_TESTS = TRADELAB_DIR / "tests"
for p in (str(PL), str(TRADELAB_TESTS), str(TRADELAB_TESTS.parent)):
    if p not in sys.path:
        sys.path.insert(0, p)

import tl_world as TW            # noqa: E402  (tradelab's stand-in production modules)

IST = "Asia/Kolkata"
NB = 125
HAND_T0 = "2023-06-14"
# session -> (open, high, low, close) after HANDSYM's T0 (session 0 = T0 itself)
HAND = {0: (99.0, 100.5, 98.5, 100.0), 1: (101.0, 103.0, 99.5, 102.0), 2: (102.0, 102.5, 97.5, 98.0),
        3: (98.0, 99.0, 95.5, 96.0), 4: (96.5, 101.0, 96.0, 100.5), 5: (100.5, 104.5, 100.0, 104.0)}


def _calendar(rng) -> pd.DatetimeIndex:
    d = pd.bdate_range("2019-07-01", "2026-10-09")
    drop = rng.choice(len(d), size=int(len(d) * 0.02), replace=False)      # holidays
    keep = np.ones(len(d), bool)
    keep[drop] = False
    keep[d.get_loc(pd.Timestamp(HAND_T0))] = True
    for k in range(1, 8):
        keep[d.get_loc(pd.Timestamp(HAND_T0)) + k] = True
    return d[keep]


def _market(rng, n):
    """Daily market return with persistent blocks: bull, bear, sideways, a crash."""
    mu = np.zeros(n)
    sd = np.zeros(n)
    t = 0
    kinds = [("bull", 0.0012, 0.008), ("bear", -0.0015, 0.013), ("side", 0.0, 0.009), ("crash", -0.006, 0.03)]
    while t < n:
        k = kinds[int(rng.choice(4, p=[0.42, 0.25, 0.28, 0.05]))]
        L = int(rng.integers(15, 25)) if k[0] == "crash" else int(rng.integers(60, 160))
        mu[t:t + L], sd[t:t + L] = k[1], k[2]
        t += L
    return rng.normal(mu, sd)


def _ohlc_from_returns(rng, p0, r, gap_share, noise):
    n = len(r)
    c = p0 * np.cumprod(1 + r)
    prev = np.r_[p0, c[:-1]]
    o = prev * (1 + gap_share * r + rng.normal(0, noise * 0.2, n))
    h = np.maximum(o, c) * (1 + np.abs(rng.normal(0, noise * 0.5, n)))
    l = np.minimum(o, c) * (1 - np.abs(rng.normal(0, noise * 0.5, n)))
    return o, h, l, c


def bars_from_daily(rng, o, h, l, c, frac_noise=0.15):
    """3-minute bars through the daily open, high, low and close (the knots), Brownian wiggles kept inside the range:
    the first open, highest high and lowest low equal the daily bar exactly."""
    n = len(o)
    O = np.empty((n, NB)); H = np.empty((n, NB)); L = np.empty((n, NB)); C = np.empty((n, NB))
    x = np.linspace(0, 1, NB + 1)
    for i in range(n):
        t1, t2 = sorted(rng.uniform(0.05, 0.95, 2))
        hi_first = rng.random() < 0.5
        k1, k2 = (h[i], l[i]) if hi_first else (l[i], h[i])
        path = np.interp(x, [0, t1, t2, 1.0], [o[i], k1, k2, c[i]])
        w = np.cumsum(rng.normal(0, 1, NB + 1))
        w = w - x * w[-1]
        w[0] = 0
        amp = frac_noise * (h[i] - l[i]) / (np.abs(w).max() + 1e-12)
        path = np.clip(path + amp * w * np.sin(np.pi * x), l[i], h[i])
        path[0], path[-1] = o[i], c[i]
        j1, j2 = int(round(t1 * NB)), int(round(t2 * NB))
        if j2 <= j1:                                     # two knots in one bar would lose the high or the low
            j2 = j1 + 1
        path[j1] = k1
        path[j2] = k2
        O[i], C[i] = path[:-1], path[1:]
        H[i] = np.maximum(O[i], C[i])
        L[i] = np.minimum(O[i], C[i])
    return O, H, L, C


def make_cache_world(root, seed: int = 3, n_regular: int = 22, n_3m: int = 10) -> dict:
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    TW.write_mods(root)
    rng = np.random.default_rng(seed)
    days = _calendar(rng)
    n = len(days)
    m = _market(rng, n)
    daily: Dict[str, pd.DataFrame] = {}

    def put(sym, o, h, l, c, v, mask=None):
        df = pd.DataFrame({"timestamp": days.tz_localize(IST), "open": o, "high": h, "low": l, "close": c, "volume": v})
        if mask is not None:
            df = df[mask].reset_index(drop=True)
        daily[sym] = df

    # indices and VIX
    for sym, b, s_ in (("NIFTY50", 1.0, 0.002), ("NIFTYMIDCAP150", 1.15, 0.004), ("NIFTYSMLCAP250", 1.3, 0.005)):
        r = b * m + rng.normal(0, s_, n)
        o, h, l, c = _ohlc_from_returns(rng, 10000.0, r, 0.3, 0.004)
        put(sym, o, h, l, c, np.full(n, np.nan))
    vix = np.empty(n)
    v = 15.0
    for t in range(n):
        v = max(9.0, 15 + 0.93 * (v - 15) - 160 * m[t] + rng.normal(0, 0.5))
        vix[t] = v
    put("INDIAVIX", vix * 1.01, vix * 1.04, vix * 0.97, vix, np.full(n, np.nan))
    # stocks
    names = [f"STK{k:02d}" for k in range(n_regular)]
    spec = {s: {"beta": float(rng.uniform(0.6, 1.4)), "sig": float(rng.uniform(0.012, 0.03))} for s in names}
    for s in ("SPLITSYM", "SUSPSYM", "LATESYM", "GONESYM", "LOCKSYM", "HANDSYM"):
        spec[s] = {"beta": 1.0, "sig": 0.018}
    spec["GOLDBEES"] = {"beta": 0.1, "sig": 0.008}          # a gold ETF (named like one: the ETF rule must find it)
    for s, sp in spec.items():
        r = sp["beta"] * m + rng.normal(0, sp["sig"], n)
        o, h, l, c = _ohlc_from_returns(rng, float(rng.uniform(80, 1500)), r, 0.35, sp["sig"])
        vol = np.exp(rng.normal(13, 0.4, n))
        mask = None
        if s == "SPLITSYM":                       # an unadjusted 1:2 split on a 2023 session
            k = days.get_loc(pd.Timestamp("2023-03-15")) if pd.Timestamp("2023-03-15") in days else int(n * 0.55)
            o[k:], h[k:], l[k:], c[k:] = o[k:] / 2, h[k:] / 2, l[k:] / 2, c[k:] / 2
            vol[k:] *= 2
            o[k] = c[k - 1] / 2 * (1 + 0.002)
            h[k] = max(h[k], o[k]); l[k] = min(l[k], o[k])
            spec[s]["split_day"] = str(days[k].date())
        if s == "SUSPSYM":
            mask = np.ones(n, bool)
            k = int(n * 0.4)
            mask[k:k + 3] = False
            spec[s]["missing"] = [str(d.date()) for d in days[k:k + 3]]
        if s == "LATESYM":
            mask = days >= pd.Timestamp("2021-03-01")
        if s == "GONESYM":
            mask = days <= pd.Timestamp("2024-05-31")
        if s == "LOCKSYM":
            for k in rng.choice(np.arange(200, n - 10), size=12, replace=False):
                px = c[k - 1] * (1.05 if rng.random() < 0.5 else 0.95)
                o[k] = h[k] = l[k] = c[k] = px
        if s == "HANDSYM":
            k0 = days.get_loc(pd.Timestamp(HAND_T0))
            scale = c[k0 - 1] / 99.0
            for j, (a_, b_, c_, d_) in HAND.items():
                o[k0 + j], h[k0 + j], l[k0 + j], c[k0 + j] = a_, b_, c_, d_
            # the bars after the hand-written ones continue from 104
            rest = c[k0 + 5] * np.cumprod(1 + r[k0 + 6:])
            prev = np.r_[c[k0 + 5], rest[:-1]]
            o[k0 + 6:] = prev * (1 + 0.001)
            c[k0 + 6:] = rest
            h[k0 + 6:] = np.maximum(o[k0 + 6:], c[k0 + 6:]) * 1.004
            l[k0 + 6:] = np.minimum(o[k0 + 6:], c[k0 + 6:]) * 0.996
            # the bars before scale to meet 99 at T0's open
            pre = slice(0, k0)
            o[pre], h[pre], l[pre], c[pre] = o[pre] / scale, h[pre] / scale, l[pre] / scale, c[pre] / scale
        put(s, o, h, l, c, vol, mask)
    # a money-market fund: tiny ranges (the cash-like rule must remove it)
    cf = 1000 * np.cumprod(1 + np.full(n, 0.00025))
    put("CASHFUND", cf * 0.9999, cf * 1.0002, cf * 0.9997, cf, np.exp(rng.normal(14, 0.3, n)))
    for s, df in daily.items():
        df.to_parquet(root / f"{s}_daily.parquet", index=False)
    # ok.json: every stock gets one; SPLITSYM lists its split; GONESYM has none (the 35% fallback is used)
    for s in daily:
        if s in ("NIFTY50", "NIFTYMIDCAP150", "NIFTYSMLCAP250", "INDIAVIX", "GONESYM"):
            continue
        sus = []
        if s == "SPLITSYM":
            sus = [{"timestamp": pd.Timestamp(spec[s]["split_day"]).tz_localize(IST).isoformat(), "ratio": 2.0,
                    "nearest_split": 2.0, "confidence": "high"}]
        (root / f"{s}_daily.ok.json").write_text(json.dumps({"schema_version": 20, "corporate_action_suspects": sus}),
                                                 encoding="utf-8")
    # 3-minute files from 2021-10-01
    idir = root / "intraday_3m"
    idir.mkdir(exist_ok=True)
    three = names[:n_3m - 3] + ["HANDSYM", "SPLITSYM", "SUSPSYM"]
    offs = pd.to_timedelta(9 * 60 + 15 + 3 * np.arange(NB), unit="m")
    bad_sessions: Dict[str, Dict[str, str]] = {}
    for s in three:
        df = daily[s]
        dd = pd.DatetimeIndex(df["timestamp"]).tz_convert(IST).tz_localize(None)
        sel = (dd >= pd.Timestamp("2021-10-01")) & (dd <= pd.Timestamp("2026-10-06"))
        D3 = df[sel].reset_index(drop=True)
        d3 = dd[sel]
        O, H, L, C = bars_from_daily(rng, *(D3[k].to_numpy(float) for k in ("open", "high", "low", "close")))
        V = np.exp(rng.normal(8, 0.6, O.shape))
        present = np.ones(O.shape, bool)
        bad = {}
        for i in rng.choice(len(d3), size=6, replace=False):
            kind = ["few", "no0915", "off", "nan", "few", "off"][len(bad) % 6]
            key = str(d3[i].date())
            if kind == "few":
                present[i, rng.choice(np.arange(1, NB), size=40, replace=False)] = False
            elif kind == "no0915":
                present[i, 0] = False
            elif kind == "off":
                O[i] *= 1.012; H[i] *= 1.012; L[i] *= 1.012; C[i] *= 1.012
            elif kind == "nan":
                H[i, 50] = np.nan
            bad[key] = kind
        bad_sessions[s] = bad
        ts = (d3.values[:, None] + offs.values[None, :])
        F = pd.DataFrame({"timestamp": pd.DatetimeIndex(ts.reshape(-1)).tz_localize(IST), "open": O.reshape(-1),
                          "high": H.reshape(-1), "low": L.reshape(-1), "close": C.reshape(-1), "volume": V.reshape(-1)})
        F = F[present.reshape(-1)].reset_index(drop=True)
        dup = F.iloc[[10, 500]].copy()                    # a repeated stamp: the LAST row must win
        dup["close"] = dup["close"] * 1.0
        F = pd.concat([F, dup], ignore_index=True)
        F.to_parquet(idir / f"{s}_3m.parquet", index=False)
    # panel_oc: every stock-day from the stock's 30th session (so some have under 60 sessions), a few holes
    parts = []
    stocks = [s for s in daily if s not in ("NIFTY50", "NIFTYMIDCAP150", "NIFTYSMLCAP250", "INDIAVIX")]
    for s in stocks:
        df = daily[s]
        t = pd.DatetimeIndex(df["timestamp"])
        keep = np.arange(len(df)) >= 30
        keep &= rng.random(len(df)) > 0.01
        parts.append(pd.DataFrame({"timestamp": t[keep], "symbol": s, "D_rsi14": rng.uniform(20, 80, keep.sum()),
                                   "label_exit_ret": rng.normal(0, 1, keep.sum())}))
    P = pd.concat(parts, ignore_index=True)
    (root / "panel_oc").mkdir(exist_ok=True)
    P.to_parquet(root / "panel_oc" / "panel.parquet", index=False)
    # picks: D and ENS ranks 1-10 every day from 2020-01-16 to 2026-09-15, from the panel's stocks that day
    pday = PCday(P["timestamp"])
    by_day: Dict[object, list] = {}
    for d_, s_ in zip(pday.tolist(), P["symbol"].tolist()):
        by_day.setdefault(d_, []).append(s_)
    lo_, hi_ = np.datetime64("2020-01-16").item(), np.datetime64("2026-09-15").item()
    pdays = sorted(d_ for d_ in by_day if lo_ <= d_ <= hi_)
    rows = []
    for d in pdays:
        pool = by_day.get(d, [])
        if len(pool) < 10:
            continue
        for eng in ("D", "ENS"):
            ch = list(rng.choice(pool, size=10, replace=False))
            if d == np.datetime64(HAND_T0).item() and eng == "D":
                ch = ["HANDSYM"] + [x for x in ch if x != "HANDSYM"][:9]
            for rk, s in enumerate(ch, start=1):
                rows.append((eng, d, s, rk))
    picks = pd.DataFrame(rows, columns=["engine", "signal_day", "symbol", "rank"])
    _write_picks_and_tlx(root, picks, daily)
    return {"root": root, "days": days, "daily": daily, "spec": spec, "three": three, "bad_sessions": bad_sessions,
            "picks": picks}


def PCday(x) -> np.ndarray:
    s = pd.to_datetime(pd.Series(x))
    if getattr(s.dt, "tz", None) is not None:
        s = s.dt.tz_convert(IST).dt.tz_localize(None)
    return s.to_numpy(dtype="datetime64[ns]").astype("datetime64[D]")


def hand_trade(df: pd.DataFrame, sig_pos: int) -> dict:
    """INDEPENDENT hand implementation of TLX's columns: sessions 1-5 = the stock's next five bars."""
    o, h, l, c = (df[k].to_numpy(float) for k in ("open", "high", "low", "close"))
    if sig_pos + 5 >= len(c):
        return {}
    e = o[sig_pos + 1]
    out = {"entry": e, "mfe": max(h[sig_pos + 1: sig_pos + 6]) / e - 1, "mae": min(l[sig_pos + 1: sig_pos + 6]) / e - 1}
    for k in range(1, 6):
        out[f"close_ret_s{k}"] = c[sig_pos + k] / e - 1
    return out


def _write_picks_and_tlx(root: Path, picks: pd.DataFrame, daily: Dict[str, pd.DataFrame]) -> None:
    pos = {s: {d: i for i, d in enumerate(PCday(df["timestamp"]).tolist())} for s, df in daily.items()}
    rows, trades = [], []
    for eng, d, s, rk in picks.itertuples(index=False):
        i = pos[s].get(np.datetime64(d, "D").item())
        ht = hand_trade(daily[s], i) if i is not None else {}
        rows.append({"engine": eng, "signal_day": pd.Timestamp(d), "symbol": s, "rank": int(rk), "score": 1 - rk / 20,
                     "fold": float(pd.Timestamp(d).year), "status": "ok" if ht else "pending",
                     "net": ht.get("close_ret_s5", np.nan) - 0.0035 if ht else np.nan,
                     "mfe": ht.get("mfe", np.nan), "mae": ht.get("mae", np.nan)})
        if ht:
            trades.append({"engine": eng, "signal_day": pd.Timestamp(d), "symbol": s, "rank": int(rk), **ht})
    Pm = pd.DataFrame(rows)
    rdir = root / "research2" / "pick_meta" / "PM_TEST_001"
    rdir.mkdir(parents=True, exist_ok=True)
    Pm.to_parquet(rdir / "predictions.parquet", index=False)
    sha = hashlib.sha256((rdir / "predictions.parquet").read_bytes()).hexdigest()
    (rdir / "outputs.sha256").write_text(f"{sha}  predictions.parquet\n", encoding="utf-8")
    tdir = root.parent / f"{root.name}_tlx" / "TLX_TEST_001"
    tdir.mkdir(parents=True, exist_ok=True)
    T = pd.DataFrame(trades)
    T.to_parquet(tdir / "trades.parquet", index=False)
    sha = hashlib.sha256((tdir / "trades.parquet").read_bytes()).hexdigest()
    (tdir / "outputs.sha256").write_text(f"{sha}  trades.parquet\n", encoding="utf-8")


def tlx_dir(root: Path) -> Path:
    return Path(root).parent / f"{Path(root).name}_tlx" / "TLX_TEST_001"


def corrupt_tlx(root: Path, share: float, seed: int = 1) -> None:
    """Change MFE on `share` of the TLX trades (and fix the hash, so only the integrity check can catch it)."""
    d = tlx_dir(root)
    T = pd.read_parquet(d / "trades.parquet")
    rng = np.random.default_rng(seed)
    k = rng.choice(len(T), size=max(1, int(share * len(T))), replace=False)
    T.loc[T.index[k], "mfe"] = T.loc[T.index[k], "mfe"] + 0.01
    T.to_parquet(d / "trades.parquet", index=False)
    sha = hashlib.sha256((d / "trades.parquet").read_bytes()).hexdigest()
    (d / "outputs.sha256").write_text(f"{sha}  trades.parquet\n", encoding="utf-8")


# ======================================================================
# a fake build cache for the family and atlas tests
# ======================================================================
TEMPLATES = {   # closes C1..C5 in ATR units (the rest of the bar is built around them)
    "up":       [0.9, 1.7, 2.4, 3.0, 3.6],
    "down":     [-0.9, -1.7, -2.4, -3.0, -3.6],
    "dip_rec":  [-1.4, -2.2, -1.2, 0.2, 1.2],
    "rally_rev": [1.4, 2.2, 1.2, -0.2, -1.2],
    "quiet":    [0.1, -0.1, 0.15, 0.0, 0.1],
    "late_up":  [0.0, 0.0, 0.4, 3.0, 5.6],   # was 0.0, 0.1, 0.9, 2.2, 3.4: no density valley against 'up' (true-label
}                                            # valley ratio 1.00, Ashman D 1.90) - only 5 separated families planted
P0 = np.array([0.25, 0.20, 0.17, 0.15, 0.15, 0.08])


def _paths_from_closes(rng, Cc: np.ndarray, noise: float):
    """O, H, L, C (n, 5) in ATR units around C0 = 0 from close paths."""
    n = len(Cc)
    C = Cc + rng.normal(0, noise, Cc.shape)
    prev = np.column_stack([np.zeros(n), C[:, :4]])
    O = prev + 0.3 * (C - prev) + rng.normal(0, noise * 0.3, C.shape)
    H = np.maximum(O, C) + np.abs(rng.normal(0.3, 0.15, C.shape))
    L = np.minimum(O, C) - np.abs(rng.normal(0.3, 0.15, C.shape))
    return O, H, L, C


EXTRA_EVENT = (8, 8, 0)          # planted event page: S08 x failed breakdown (event code 8) x age bin 0 (0-2 sessions)
EXTRA_DELAY_STATE = 9           # planted delay effect: in S09 waiting helps (dly_d rises with d)


def _extras(rng, nd: int, st: np.ndarray, kind: str, C5: np.ndarray, H: np.ndarray, L: np.ndarray) -> dict:
    """v1.1 columns for the rows world: tl_state-like event codes and ages, the 10-session horizon and the delay
    curve (net of 35 bp). Planted (kind == 'planted' only): the EXTRA_EVENT page gets +1.0 ATR on its 10-day close; in
    EXTRA_DELAY_STATE each later entry gains 0.05% per session of delay (dly10 - dly1 = +0.45%)."""
    u = rng.random(nd)                                   # no event 50%; failed breakdown (8) 25%; codes 1-7 25%
    ev = np.where(u < 0.5, 0, np.where(u < 0.75, 8, rng.integers(1, 8, nd))).astype(np.int8)
    age = np.where(ev > 0, rng.integers(0, 6, nd), -1).astype(np.int16)
    tail = rng.normal(0, 1.2, nd)                        # sessions 6-10 after the 5-day path
    r10 = C5 + tail
    if kind == "planted":
        m = (st == EXTRA_EVENT[0]) & (ev == EXTRA_EVENT[1]) & (age >= 0) & (age <= 2)
        r10 = r10 + np.where(m, 1.0, 0.0)
    out = {"event0": ev, "ev_age0": age, "x_ok": np.ones(nd, np.int8), "r10_a": r10,
           "mfe10_a": np.maximum(H.max(axis=1), r10 + np.abs(rng.normal(0.4, 0.2, nd))),
           "mae10_a": np.minimum(L.min(axis=1), r10 - np.abs(rng.normal(0.4, 0.2, nd)))}
    base = rng.normal(0.0, 0.03, nd)                     # shared by every d of a path (paths, not d, vary)
    for d in range(1, 11):
        v = base + rng.normal(0.0, 0.01, nd) - 0.0035
        if kind == "planted":
            v = v + np.where(st == EXTRA_DELAY_STATE, 0.0005 * (d - 1), 0.0)
        out[f"dly{d}"] = v
    return out


def make_rows_world(cdir, kind: str = "planted", seed: int = 11, n_stocks: int = 120, decl: dict = None,
                    start: str = "2020-01-01", end: str = "2026-09-15", extras: bool = False) -> dict:
    """Writes cdir/rows/*.parquet, cdir/null/*.parquet, cdir/market.parquet and integrity.json (passed)."""
    import pl_paths as PP
    import pl_common as PC
    cdir = Path(cdir)
    for sub in ("rows", "null", "inull", "done"):
        (cdir / sub).mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    days = pd.bdate_range(start, end)
    nd = len(days)
    # regimes: persistent runs; states: per stock, persistent
    seq: List[int] = []
    while len(seq) < nd:                                       # every regime in many runs of 8-24 sessions
        for r in rng.permutation(5):
            seq += [int(r)] * int(rng.integers(8, 25))
    reg = np.array(seq[:nd], dtype=np.int8)
    states = [1, 2, 3, 6, 7, 8, 9, 12, 0]
    date_shock = rng.normal(0, 0.35, (nd, 5))                  # all stocks of a date move together a little, each
    #                                                              session on its own (no serial structure from it)
    tmpl = np.array(list(TEMPLATES.values()))
    rows, nulls = [], []
    for k in range(n_stocks):
        sym = f"R{k:03d}"
        st = np.empty(nd, np.int64)
        s = int(rng.choice(states))
        for t in range(nd):
            if t == 0 or rng.random() < 0.08:
                s = int(rng.choice(states, p=[0.13, 0.12, 0.10, 0.10, 0.17, 0.12, 0.11, 0.05, 0.10]))
            st[t] = s
        p = np.tile(P0, (nd, 1))
        if kind == "planted":
            m1 = st == 1                                         # S01: more 'up', fewer 'down' (+0.10 / -0.10)
            p[m1, 0] += 0.10
            p[m1, 1] -= 0.10
            m4 = reg == 4                                        # high stress: more 'rally_rev', fewer 'quiet'
            p[m4, 3] += 0.10
            p[m4, 4] -= 0.10
        if kind == "absent":
            steps = rng.normal(0, 1.0, (nd, 5))
            Cc = np.cumsum(steps, axis=1)
            fam_true = np.full(nd, -1)
        else:
            u = rng.random(nd)
            fam_true = (u[:, None] > np.cumsum(p, axis=1)).sum(axis=1)
            Cc = tmpl[fam_true]
        Cc = Cc + np.cumsum(date_shock, axis=1)
        O, H, L, C = _paths_from_closes(rng, Cc, 0.25)
        A0 = 2.0
        C0 = np.full(nd, 100.0)
        mm = PP.daily_measures(C0, np.full(nd, A0), C0[:, None] + A0 * O, C0[:, None] + A0 * H, C0[:, None] + A0 * L,
                               C0[:, None] + A0 * C, decl)
        R = {"sym": np.full(nd, sym), "t0": days.values.astype("datetime64[ns]"), "cal_pos": np.arange(nd, dtype=np.int32),
             "year": days.year.to_numpy().astype(np.int16), "in_univ": np.ones(nd, np.int8), "cash_like": np.zeros(nd, np.int8),
             "insuff": np.zeros(nd, np.int8), "eligible": np.ones(nd, np.int8), "complete": np.ones(nd, np.int8),
             "ca": np.zeros(nd, np.int8), "state0": st.astype(np.int8), "reg0": reg, "liq": np.exp(rng.normal(18 + k % 3, 0.3, nd)),
             "pk_D": np.where(rng.random(nd) < 0.02, 1, 0).astype(np.int8), "pk_ENS": np.zeros(nd, np.int8),
             "phase0": np.zeros(nd, np.int8), "overext0": np.zeros(nd, np.int8), "event0": np.zeros(nd, np.int8),
             "n_present": np.full(nd, 5, np.int8), "st1": st.astype(np.int8), "st2": st.astype(np.int8),
             "st3": st.astype(np.int8), "st4": st.astype(np.int8), "st5": st.astype(np.int8),
             "st_first_change": np.zeros(nd, np.int8), "rg_class": np.zeros(nd, np.int8), "rg_first_change": np.zeros(nd, np.int8),
             "nifty_r5": rng.normal(0, 0.02, nd), "fam_true": fam_true.astype(np.int8)}
        R.update({k_: v for k_, v in mm.items()})
        if extras:
            R.update(_extras(np.random.default_rng([seed, 99, k]), nd, st, kind, C[:, -1], H, L))
        rows.append(pd.DataFrame(R))
        # null: each session from a random other date of the same stock (whole session moves in ATR units)
        don = rng.integers(0, nd, size=(nd, 5))
        dO = O - np.column_stack([np.zeros(nd), C[:, :4]])
        dH = H - np.column_stack([np.zeros(nd), C[:, :4]])
        dL = L - np.column_stack([np.zeros(nd), C[:, :4]])
        dC = C - np.column_stack([np.zeros(nd), C[:, :4]])
        jj = rng.integers(0, 5, size=(nd, 5))
        Pp = np.zeros(nd)
        On, Hn, Ln, Cn = (np.zeros((nd, 5)) for _ in range(4))
        for j in range(5):
            a, b = don[:, j], jj[:, j]
            On[:, j] = Pp + dO[a, b]
            Hn[:, j] = Pp + dH[a, b]
            Ln[:, j] = Pp + dL[a, b]
            Cn[:, j] = Pp + dC[a, b]
            Pp = Cn[:, j]
        mn = PP.daily_measures(C0, np.full(nd, A0), C0[:, None] + A0 * On, C0[:, None] + A0 * Hn,
                               C0[:, None] + A0 * Ln, C0[:, None] + A0 * Cn, decl)
        Nn = {"sym": np.full(nd, sym), "t0": days.values.astype("datetime64[ns]"), "cal_pos": np.arange(nd, dtype=np.int32)}
        Nn.update(mn)
        nulls.append(pd.DataFrame(Nn))
    for df, sub in ((rows, "rows"), (nulls, "null")):
        for d_ in df:
            d_ = d_.copy()
            for c in d_.columns:
                if d_[c].dtype.kind == "f" and c not in ("liq",):
                    d_[c] = d_[c].astype(np.float32)
            d_.to_parquet(cdir / sub / f"{d_['sym'].iloc[0]}.parquet", index=False)
    M = pd.DataFrame({"date": days, "env": reg, "nifty_close": 1.0, "mid_close": 1.0, "small_close": 1.0})
    M.to_parquet(cdir / "market.parquet", index=False)
    PC.write_json_atomic({"status": "passed", "note": "synthetic rows world"}, cdir / "integrity.json")
    return {"days": days, "regimes": reg, "kind": kind, "templates": TEMPLATES, "p0": P0}
