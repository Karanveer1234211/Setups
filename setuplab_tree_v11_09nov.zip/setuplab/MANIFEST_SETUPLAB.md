# MANIFEST - setuplab v1.1 (9 Nov 2026: the entry tree - calm / jumpy tags, the tree's orders in the nightly scan, a forward scoreboard; on top of v1.0's nodip, v0.9's runners and v0.8's frozen setups, zones and TradingView indicator)

Folder: C:\Users\karanvsi\PyCharmMiscProject\setuplab\ (tests in setuplab\tests\). v1.1 changes three files and adds TREE.json: setuplab.py, tests\test_setuplab.py, README_SETUPLAB.md (and this manifest); the others are v1.0's, unchanged. FROZEN_SETUPS.json and TREE.json are freezes (never edit them: a changed copy is refused). Writes only under --out (C:\QuantData\setuplab). The scan, the zones, the runners and nodip read tradelab's readers (tradelab with the setups add-on on PYTHONPATH: env_tradelab.bat or env_playbook.bat); the self-test also reads production's features_daily.py (bigmove_deploy on PYTHONPATH). Python with numpy, pandas, pyarrow. BigMove_Setups.pine goes into TradingView's Pine Editor.

| file | sha256 (first 16) | bytes | lines | v1.1 |
|---|---|---|---|---|
| setuplab.py | 9979d418aecec6de | 359876 | 6439 | changed: the tree command, the Tree section of the nightly scan, the tree ledger and forward books |
| TREE.json | 5b447d0ff7eb16f7 | 5671 | 167 | NEW: the entry tree (frozen 9 Nov 2026; never edit it - a changed copy is refused) |
| FROZEN_SETUPS.json | bed8fd610cf686af | 24439 | 935 | unchanged |
| BigMove_Setups.pine | 1904f972378eb49c | 24113 | 588 | unchanged |
| features_final.txt | bcb6c16bdfd7513d | 1689 | 60 | unchanged |
| README_SETUPLAB.md | a8cb14fd43429aaa | 41872 | 518 | changed: the v1.1 section |
| tests\test_setuplab.py | 6963f692ec714a16 | 131915 | 2059 | changed: tr1-tr8 |
| tests\pine_mirror.py | 326cb336f1c7e96c | 13337 | 337 | unchanged |

FROZEN_SETUPS.json's own sha256 (inside the file): 483f1539324f3ae5... (`python setuplab.py frozen` prints FROZEN FILE OK). TREE.json's own sha256 (inside the file): 5cd4571765c2de80...

Verified where it was built: 88 self-test checks, 0 failed, with pandas 2.3.3 / numpy 2.4.1 on Python 3.12 and 3.13 (Karan's versions) and pandas 3.0.5 / numpy 2.5.3. v0.6's 38; v0.7's f1-f14; v0.8's z1-z6 and p1-p3; v0.9's r1-r7; v1.0's n1-n5; v1.1's tr1-tr8 (9 checks): the tree file and the ETF rule; the cut-off and the lanes by hand; the tree by hand and the first setup by hand; the 3-position book by hand; the tree command on a planted world (DIFFERS / RECONCILED); the nightly tree evening by evening = the history on the same picks (trades, entries, nets, the book's choices, the D order, every setup trade named the evening before, a LATE evening in no book); a world where no setup fires; the scan with the tree (one record an evening, a changed tree file leaves the scan running, the yearly cut-off once). Planted bugs caught: v0.8 5 of 5; v0.9 8 of 8; v1.0 7 of 7; v1.1 10 of 10. On Karan's watchlist (WL_R1_10, TAGS 25eb8831) the tree command prints TREE RECONCILED in 18 s. The Pine has not been compiled by TradingView.
