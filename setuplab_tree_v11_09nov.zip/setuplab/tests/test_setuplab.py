"""
test_setuplab.py - setuplab's checks: hand-computed trades, the engine's edge cases, and three planted worlds.

  world R ("real setup"): every pick falls for 1-3 days then bounces; feature x turns down exactly on the last
          falling day, feature y is noise. x must beat D1 AND beat the price-only dip entry on the same trades;
          y must not beat the dip entry.
  world W ("waiting world"): the same fall-then-bounce prices, x and y both noise. Noise setups DO beat D1 here
          (just by waiting) - the trap - but must NOT beat the price-only dip entry.
  world N ("null"): random-walk prices, noise features: nothing beats D1.
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import setuplab as S  # noqa: E402

FAILS = []
COUNT = [0]


def check(name, ok, detail=""):
    COUNT[0] += 1
    print(("  ok    " if ok else "  FAIL  ") + name + ("" if ok else "   <- %s" % (detail,)))
    if not ok:
        FAILS.append(name)


def make_world(kind, n_days=520, per_day=3, seed=1):
    """kind R / W / N. Each pick its own symbol; features given per symbol-date with explicit *_change."""
    rng = np.random.default_rng(seed)
    cal = pd.bdate_range("2021-01-01", periods=n_days + 15)
    wl, fe = [], []
    t = 0
    for d in range(2, n_days):
        for r in range(1, per_day + 1):
            t += 1
            sym = "S%05d" % t
            sc = 100.0
            ent = sc * (1 + rng.normal(0, 0.005))
            b = int(rng.integers(1, 4))                      # last falling day
            lr = rng.normal(0, 0.012, 10)
            if kind in ("R", "W"):
                lr[:b] -= 0.02
                lr[b:b + 4] += 0.015
            # closes relative to the D1 open; D1 open = entry; opens of later days = previous close (no gap) + noise
            C = np.empty(11)
            O = np.empty(11)
            O[1] = ent
            C[1] = ent * np.exp(lr[0])
            for k in range(2, 11):
                O[k] = C[k - 1] * (1 + rng.normal(0, 0.002))
                C[k] = O[k] * np.exp(lr[k - 1])
            row = {"trade_id": "D-%s-%d" % (cal[d].strftime("%Y%m%d"), r), "symbol": sym, "rank": r,
                   "signal_day": cal[d], "entry_day": cal[d + 1].strftime("%Y-%m-%d"), "signal_close": sc,
                   "status": "ok", "entry": ent, "net_bp": 0.0, "engine": "D", "pre_state": "S01",
                   "s_atr14": 0.02, "pre_state_bearish": int(rng.integers(0, 2)), "pre_state_bullish": 0,
                   "pre_nifty_vs_ma50": float(rng.normal()), "pre_env_code": int(rng.integers(0, 4)),
                   "pre_vix_pct250": float(rng.random()), "pre_ad_ratio_10": float(rng.random()),
                   "pre_state_overextended": 0, "pre_state_vol_elevated": int(rng.integers(0, 2))}
            for k in range(1, 11):
                row["close_%d" % k] = C[k] / ent - 1
                row["overnight_%d" % k] = (O[k] / (sc if k == 1 else C[k - 1]) - 1) if k > 1 else 0.0
            wl.append(row)
            # features on the signal day (D0) and D1..D6 dates: change at the date of day k is read at day k+1's open
            for k in range(0, 8):
                date = cal[d + k]
                if kind == "R":
                    xc = -1.0 if k == b else 1.0
                else:
                    xc = float(rng.choice([-1.0, 1.0]))
                yc = float(rng.choice([-1.0, 1.0]))
                fe.append({"symbol": sym, "timestamp": date, "x": xc, "x_change": xc, "y": yc, "y_change": yc})
    W = pd.DataFrame(wl)
    F = pd.DataFrame(fe)
    return S.Book(W, pd.Series(cal), F, "D"), W, F


def t_hand():
    """A three-pick hand world: every number below computed by hand."""
    cal = pd.bdate_range("2024-01-01", periods=20)
    rows = []

    def pick(i, closes, over, sc=100.0, ent=100.0):
        r = {"trade_id": "D-T-%d" % i, "symbol": "H%d" % i, "rank": 1, "signal_day": cal[2],
             "entry_day": cal[3].strftime("%Y-%m-%d"), "signal_close": sc, "status": "ok", "entry": ent,
             "net_bp": 0.0, "engine": "D", "pre_state": "S01", "s_atr14": 0.02,
             "pre_state_bearish": {1: 1, 2: 0, 3: np.nan}[i]}
        for k in range(1, 11):
            r["close_%d" % k] = closes[k - 1] / ent - 1
            r["overnight_%d" % k] = over[k - 1]
        return r
    cl = [98, 96, 97, 99, 101, 102, 103, 104, 105, 106]
    rows.append(pick(1, cl, [0] * 10))
    rows.append(pick(2, cl, [0, 0.01, 0, 0, 0, 0, 0, 0, 0, 0]))
    rows.append(pick(3, cl, [0] * 10))
    W = pd.DataFrame(rows)
    fe = []
    # feature f: change sequence by date index cal[2+k] (k = 0 is D0): pick 1 turns down at D2 (read at D3's open)
    seq = {1: [1, 1, -1, 1, 1, 1, 1], 2: [1, -1, 1, 1, 1, 1, 1], 3: [1, 0, 0, np.nan, 1, -1, 1]}
    for i, sq in seq.items():
        for k, v in enumerate(sq):
            fe.append({"symbol": "H%d" % i, "timestamp": cal[2 + k], "f": v, "f_change": v})
    book = S.Book(W, pd.Series(cal), pd.DataFrame(fe), "D")
    c = [("f_change", "<", 0)]
    L = S.replay(book, c, "original_d5").set_index("trade_id")
    Lf = S.replay(book, c, "fresh").set_index("trade_id")
    # pick 1: f falls at D2 -> enter D3 open = D2 close 96 (no gap) -> original exit D5 close 101
    check("h1 entry at the first open after the condition (D3 open = 96)", L.loc["D-T-1", "day"] == 3 and
          abs(L.loc["D-T-1", "price"] - 96) < 1e-9, L.loc["D-T-1"].to_dict())
    check("h2 original_d5 net = 101/96 - 1 - 0.35 pp", abs(L.loc["D-T-1", "ret"] - ((101 / 96 - 1) * 100 - 0.35)) < 1e-9)
    check("h3 fresh net = the close 4 sessions after entry (D7 = 103)",
          abs(Lf.loc["D-T-1", "ret"] - ((103 / 96 - 1) * 100 - 0.35)) < 1e-9 and Lf.loc["D-T-1", "exit_day"] == 7)
    # pick 2: f falls at D1 -> D2 open = D1 close 98 x 1.01 (gap) = 98.98
    check("h4 a gap is in the entry price (D2 open = 98 x 1.01)", abs(L.loc["D-T-2", "price"] - 98.98) < 1e-9)
    dd = 100 * (1 - 96 / 98.98)
    check("h5 trade drawdown = peak-to-trough over entry and closes", abs(L.loc["D-T-2", "trade_dd"] - dd) < 1e-9,
          (L.loc["D-T-2", "trade_dd"], dd))
    # pick 3: zero changes do not pass, then a missing value with no False -> Missing signal data
    check("h6 a zero change does not pass; a missing value then makes the trade 'Missing signal data'",
          L.loc["D-T-3", "status"] == "Missing signal data", L.loc["D-T-3", "status"])
    # condition with a False beside the missing value -> skip that day, not missing
    c2 = [("f_change", "<", 0), ("gap_pct", ">", 5)]
    L2 = S.replay(book, c2, "original_d5").set_index("trade_id")
    check("h7 a False beside a missing value = just not today (No entry, not Missing)",
          L2.loc["D-T-3", "status"] == "No entry", L2.loc["D-T-3", "status"])
    # blind D5 under original_d5: enter and exit the same session (open -> close)
    L3 = S.replay(book, [("day", ">=", 5), ("day", "<=", 5)], "original_d5").set_index("trade_id")
    check("h8 entry on D5 under original_d5 = D5 open to D5 close",
          abs(L3.loc["D-T-1", "ret"] - ((101 / 99 - 1) * 100 - 0.35)) < 1e-9)
    # fresh exit past D10 -> Missing exit data
    L4 = S.replay(book, [("day", ">=", 5), ("day", "<=", 5)], "fresh").set_index("trade_id")
    check("h9 fresh exit inside the 10-session path (D5 entry -> D9 close)",
          L4.loc["D-T-1", "status"] == "Filled" and L4.loc["D-T-1", "exit_day"] == 9)
    # dip control: pc_vs_d1 on D1 is never a dip; D2 open after D1 close 98 < 100 -> DIP_0 enters D2
    L5 = S.replay(book, S.control_setups()["DIP_0"], "original_d5").set_index("trade_id")
    L6 = S.replay(book, S.control_setups()["DIP_3"], "original_d5").set_index("trade_id")
    check("h10 price-only dip: DIP_0 enters D2 (98 < 100), DIP_3 waits for a close under 97 (D2 close 96 -> D3)",
          L5.loc["D-T-1", "day"] == 2 and L6.loc["D-T-1", "day"] == 3, (L5.loc["D-T-1", "day"], L6.loc["D-T-1", "day"]))
    L7 = S.replay(book, S.control_setups()["BOUNCE_upclose"], "original_d5").set_index("trade_id")
    L8 = S.replay(book, S.control_setups()["DIPATR_1"], "original_d5").set_index("trade_id")
    check("h12 ATR dip: ATR 2%%; D1 close 98 = exactly -1 ATR does not pass '< -1'; D2 close 96 (-2 ATR) -> enter D3",
          L8.loc["D-T-1", "day"] == 3, L8.loc["D-T-1", "day"])
    L9 = S.replay(book, S.control_setups()["TUE"], "original_d5").set_index("trade_id")
    exp = next((k for k in range(1, 6) if cal[3 + k - 1].weekday() == 1), 0)      # sessions, not calendar days
    check("h13 TUE control enters the first Tuesday open of D1..D5 (D1 = %s)" % cal[3].day_name(),
          (L9.loc["D-T-1", "day"] if L9.loc["D-T-1", "status"] == "Filled" else 0) == exp, (L9.loc["D-T-1", "day"], exp))
    L10 = S.replay(book, [("snap:pre_state_bearish", ">", 0.5)], "original_d5").set_index("trade_id")
    check("h14 snapshot field (the pick's state at the signal): 1 -> enter D1, 0 -> No entry, missing -> Missing",
          L10.loc["D-T-1", "day"] == 1 and L10.loc["D-T-2", "status"] == "No entry" and
          L10.loc["D-T-3", "status"] == "Missing signal data", L10["status"].to_dict())
    check("h11 bounce marker: under the D1 open, then an up close (D3 close 97 > 96 -> enter D4)",
          L7.loc["D-T-1", "day"] == 4, L7.loc["D-T-1", "day"])


def t_worlds():
    res = {}
    for kind in ("R", "W", "N"):
        book, _, _ = make_world(kind, seed={"R": 3, "W": 4, "N": 5}[kind])
        boot = S.Boot(book.signal_day[book.ok])
        setups = {"X": [("x_change", "<", 0)], "Y": [("y_change", "<", 0)], **S.control_setups()}
        led = S.run_all(book, setups, boot)
        res[kind] = {}
        for nm in ("X", "Y"):
            for ctl in ("Blind_D1", "DIP_0"):
                res[kind][(nm, ctl)] = S.paired(led[(nm, "original_d5")], led[(ctl, "original_d5")], boot)
                res[kind][(nm, ctl, "fresh")] = S.paired(led[(nm, "fresh")], led[(ctl, "fresh")], boot)
    R, Wd, N = res["R"], res["W"], res["N"]
    f = lambda r: "lift %+.3f [%+.3f, %+.3f] n %d" % (r["lift_pp"], r["lo"], r["hi"], r["n"])
    check("w1 world R: the planted setup beats D1 on its own trades (interval above 0)", R[("X", "Blind_D1")]["lo"] > 0,
          f(R[("X", "Blind_D1")]))
    check("w2 world R: the planted setup beats the price-only dip entry on the same trades (both exits)",
          R[("X", "DIP_0")]["lo"] > 0 and R[("X", "DIP_0", "fresh")]["lo"] > 0,
          (f(R[("X", "DIP_0")]), f(R[("X", "DIP_0", "fresh")])))
    check("w3 world R: the noise feature does not beat the dip entry", not R[("Y", "DIP_0")]["lo"] > 0,
          f(R[("Y", "DIP_0")]))
    check("w4 world W (fall-then-bounce, noise features): noise setups DO beat D1 - waiting alone pays (the trap)",
          Wd[("X", "Blind_D1")]["lo"] > 0 and Wd[("Y", "Blind_D1")]["lo"] > 0,
          (f(Wd[("X", "Blind_D1")]), f(Wd[("Y", "Blind_D1")])))
    check("w5 world W: ... but they do NOT beat the price-only dip entry (the control catches the trap)",
          not Wd[("X", "DIP_0")]["lo"] > 0 and not Wd[("Y", "DIP_0")]["lo"] > 0,
          (f(Wd[("X", "DIP_0")]), f(Wd[("Y", "DIP_0")])))
    check("w6 world N (random walk, noise): no setup beats D1", all(not (N[(k, "Blind_D1")]["lo"] > 0) and
                                                                   not (N[(k, "Blind_D1")]["hi"] < 0) for k in "XY"),
          (f(N[("X", "Blind_D1")]), f(N[("Y", "Blind_D1")])))


def t_space():
    book, _, _ = make_world("N", n_days=200, seed=9)
    sp = S.space_setups(["x", "y"])
    check("s1 the pair space of 2 features = 4 singles... (2 x 2 singles + 1 pair x 4 directions = 8 setups)",
          len(sp) == 8, len(sp))
    abc = S.abc_setups()
    check("s2 A/B/C x 4 confirmations = 28 setups; A+C and A+B+C identical conditions",
          len(abc) == 28 and set(abc["A+C__none"]) == set(abc["A+B+C__none"]))


def t_confluence():
    import tempfile
    tmp = Path(tempfile.mkdtemp(prefix="sl_conf_"))
    pd.DataFrame({"engine": ["D"] * 6, "feature": ["D_sma200", "D_ema20_angle_deg", "Comb_X", "D_missing",
                                                   "W_ret_13w", "D_rsi14"],
                  "importance": [6, 5, 4, 3, 2, 1]}).to_csv(tmp / "why.csv", index=False)
    pd.DataFrame({"symbol": ["A"], "timestamp": [pd.Timestamp("2024-01-01")], "D_sma200": [1.0],
                  "D_ema20_angle_deg": [1.0], "Comb_X": [1.0], "W_ret_13w": [1.0], "D_rsi14": [1.0]}).to_parquet(
        tmp / "panel.parquet")
    ch, sk = S.pick_features(tmp / "why.csv", 2, tmp / "panel.parquet")
    check("c1 feature picker: by importance, skipping raw levels (D_sma200), combined flags and absent features",
          ch == ["D_ema20_angle_deg", "W_ret_13w"] and [x[0] for x in sk] == ["D_sma200", "Comb_X", "D_missing"],
          (ch, sk))
    book, _, _ = make_world("R", n_days=300, seed=21)
    import io
    from contextlib import redirect_stdout
    with redirect_stdout(io.StringIO()):
        v1, _ = S.cmd_run(book, tmp / "run", log=lambda *a: None, with_confluence=True)
    X = pd.read_csv(tmp / "run" / "confluence.csv")
    r = X[(X.setup == "x_change<0") & (X.confluence == "BEARSTATE") & (X.exit == "original_d5")] if \
        "x_change<0" in set(X.setup) else X.iloc[0:0]
    if r.empty:      # the pool names pairs only; the planted single x lives inside a pair with y
        r = X[X.setup.str.contains("x_change<0") & (X.confluence == "BEARSTATE") & (X.exit == "original_d5")]
    check("c2 confluence stage runs: NONE baselines, every context confluence, price x context pairs, 'adds' column",
          (X.setup == "NONE").any() and {"BEARSTATE", "DIP2&BEARSTATE", "MKT_BEARISH"} <= set(X.confluence) and
          X["adds_over_conf"].notna().any() and (tmp / "run" / "CONFLUENCE.md").is_file(), X.shape)
    check("c3 world R: a setup built on the planted feature adds over the confluence alone (BEARSTATE)",
          len(r) > 0 and (r.adds_lo > 0).all(), r[["setup", "adds_over_conf", "adds_lo", "adds_hi"]].to_dict("records")
          if len(r) else "no row")
    # c4-c5 (v0.6 rule 6): a context filter is judged by the trades it keeps vs those it drops on its parent setup.
    # Planted: picks flagged bearish earn +3% on every exit (closes D5-D10 raised; entries and signals read D1-D4
    # only, so they do not move). VOL_ELEVATED stays a coin flip. Absent: the same world unplanted.
    _, W0, F0 = make_world("R", n_days=300, seed=21)
    W1 = W0.copy()
    bear = W1["pre_state_bearish"].to_numpy() == 1
    for k in range(5, 11):
        W1.loc[bear, "close_%d" % k] = (1 + W1.loc[bear, "close_%d" % k]) * 1.03 - 1
    cal = pd.Series(pd.bdate_range("2021-01-01", periods=300 + 15))
    pool = {"NONE": [], "x_change<0": [("x_change", "<", 0)]}
    got, why = {}, {}
    for nm, W_ in (("planted", W1), ("absent", W0)):
        bk = S.Book(W_, cal, F0, "D")
        (tmp / nm / "D").mkdir(parents=True)
        with redirect_stdout(io.StringIO()):
            got[nm] = S.confluence(bk, None, S.Boot(bk.signal_day[bk.ok]), tmp / nm / "D", log=lambda *a: None,
                                   pool=pool)
        RR = S.rank_rows(S.lb_table(tmp / nm, ["D"]), ["D"], min_n=50, min_years=1).set_index(["setup", "exit"])
        why[nm] = {c: "context filter" in RR.loc[("x_change<0 || %s" % c, "original_d5"), "why_not"]
                   for c in ("BEARSTATE", "VOL_ELEVATED", "DIP1&BEARSTATE")}
    P, A = got["planted"], got["absent"]
    pb = P[(P.confluence == "BEARSTATE")]
    pp = P[P.confluence.str.endswith("&BEARSTATE") & (P.filter_kept >= 30) & (P.filter_dropped >= 30)]
    po = P[~P.confluence.str.endswith("BEARSTATE") & P.filter_q.notna()]
    an = A[A.filter_q.notna()]
    check("c4 rule 6, planted: the bearish filter keeps better trades (+3%) on its parents (alone and with each "
          "price confluence) at a 5% false discovery rate; the coin-flip filters do not; the leaderboard agrees",
          len(pb) == 4 and (pb.filter_q <= 0.05).all() and pb.filter_gain.between(2.0, 4.0).all() and
          (pb.filter_lo > 0).all() and len(pp) >= 8 and (pp.filter_q <= 0.05).mean() >= 0.9 and
          (po.filter_q <= 0.05).mean() <= 0.02 and
          why["planted"] == {"BEARSTATE": False, "VOL_ELEVATED": True, "DIP1&BEARSTATE": False},
          (pb[["setup", "exit", "filter_gain", "filter_q"]].to_dict("records"), len(pp),
           (pp.filter_q <= 0.05).mean() if len(pp) else None, (po.filter_q <= 0.05).mean(), why["planted"]))
    check("c5 rule 6, absent: no context filter passes the false discovery rate (the plain 95% interval lets "
          "about 2.5% through by luck) and the leaderboard flags the bearish filter",
          len(an) > 100 and (an.filter_q <= 0.05).sum() == 0 and why["absent"]["BEARSTATE"] and
          why["absent"]["DIP1&BEARSTATE"], (len(an), int((an.filter_q <= 0.05).sum()), (an.filter_lo > 0).mean(),
                                            why["absent"]))
    pv = np.array([0.001, 0.008, 0.039, 0.041, 0.042, 0.06, 0.074, 0.205, 0.212, 0.216])   # a textbook example
    check("c6 Benjamini-Hochberg q-values on a hand example; p from the bootstrap sd (z = 1.96 -> 0.025)",
          np.allclose(S.bh_q(pv), [0.01, 0.04, 0.084, 0.084, 0.084, 0.1, 0.10571429, 0.216, 0.216, 0.216]) and
          abs(S.filter_p([1.96], [1.0])[0] - 0.025) < 1e-3 and np.isnan(S.bh_q([np.nan, 0.01])[0]),
          S.bh_q(pv))


def t_build():
    # b1: hand bars with a missing session and a pick near the data's end
    cal = pd.bdate_range("2024-01-01", periods=20)
    o = np.array([10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21], float)
    c = o + 0.5
    ci = np.array([0, 1, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12])          # session 3 missing for this stock
    W = S.watchlist_rows([{"trade_id": "D-X-1", "engine": "D", "rank": 4, "symbol": "Q", "signal_day": cal[1], "j": 1},
                          {"trade_id": "D-X-2", "engine": "D", "rank": 9, "symbol": "Q", "signal_day": cal[10], "j": 8}],
                         {"Q": (o, c, ci)}, cal.to_numpy()).set_index("trade_id")
    r = W.loc["D-X-1"]
    check("b1 build from own bars: entry = next bar's open, close_k / entry - 1, gaps, the entry day after a missing "
          "session, NaN past the data's end",
          r.entry == 12 and r.signal_close == 11.5 and abs(r.close_1 - (12.5 / 12 - 1)) < 1e-12 and
          abs(r.overnight_2 - (13 / 12.5 - 1)) < 1e-12 and r.entry_day == str(cal[2].date()) and
          W.loc["D-X-2", "entry_day"] == str(cal[10].date()) and np.isfinite(W.loc["D-X-2", "close_3"]) and
          np.isnan(W.loc["D-X-2", "close_4"]), W.T.to_dict())
    # b2: a world rebuilt through watchlist_rows replays identically (the build's format = the backtester's)
    book, W0, F = make_world("R", n_days=150, seed=31)
    P, bars = [], {}
    for i in range(book.n):
        sym = "Z%05d" % i
        oo = np.concatenate([[book.sc[i]], book.O[i, 1:]])
        cc = np.concatenate([[book.sc[i]], book.C[i, 1:]])
        bars[sym] = (oo, cc, book.i1[i] - 1 + np.arange(len(oo)))
        P.append({"trade_id": book.ids[i], "engine": "D", "rank": int(book.rank[i]), "symbol": sym,
                  "signal_day": book.signal_day[i], "j": 0})
    W1 = S.watchlist_rows(P, bars, book.cal)
    keep = W0.set_index("trade_id")[["status", "net_bp", "pre_state", "s_atr14", "symbol"]]
    W1 = W1.drop(columns="symbol").join(keep, on="trade_id")
    b2 = S.Book(W1, pd.Series(book.cal), F, "D")
    same = True
    for conds in ([("x_change", "<", 0)], S.control_setups()["DIP_2"], [("day", "<=", 1), ("day", ">=", 1)]):
        for m in S.EXITS:
            x, y = S.replay(book, conds, m), S.replay(b2, conds, m)
            same &= (x.status.values == y.status.values).all() and np.allclose(x.ret, y.ret, equal_nan=True,
                                                                                 atol=1e-9)
    check("b2 a watchlist rebuilt from bars replays identically (setups, dips, D1; both exits)", bool(same))
    # b3: ranks filter and the by-rank view
    bk = S.Book(W0, pd.Series(book.cal), F, "D", ranks=[1, 2])
    import tempfile, io
    from contextlib import redirect_stdout
    tmp = Path(tempfile.mkdtemp(prefix="sl_rank_"))
    with redirect_stdout(io.StringIO()):
        S.cmd_run(book, tmp, log=lambda *a: None)
    rk = pd.read_csv(tmp / "by_rank.csv") if (tmp / "by_rank.csv").is_file() else pd.DataFrame()
    check("b3 --ranks keeps only those ranks; the by-rank view has the 1-3 band and each rank",
          set(bk.rank) == {1, 2} and len(rk) > 0 and {"ranks 1-3", "rank 01", "rank 03"} <= set(rk.group),
          (set(bk.rank), sorted(set(rk.group)) if len(rk) else None))


def t_v06():
    import io
    import json
    import tempfile
    from contextlib import redirect_stdout
    rng = np.random.default_rng(5)
    # v1: the count-matrix bootstrap = the index bootstrap
    days = pd.bdate_range("2021-01-01", periods=400).to_numpy()
    bt = S.Boot(days)
    di = rng.integers(0, 400, 3000)
    v = rng.normal(size=3000)
    s_ = np.bincount(di, weights=v, minlength=400)
    c_ = np.bincount(di, minlength=400).astype(float)
    old = s_[bt.ix].sum(1) / c_[bt.ix].sum(1)
    lo, hi = bt.ci_idx(di, v)
    check("v1 the count-matrix bootstrap gives the index bootstrap's interval",
          abs(lo - np.percentile(old, 2.5)) < 1e-9 and abs(hi - np.percentile(old, 97.5)) < 1e-9, (lo, hi))
    # v2: stats = paired_fast + years / halves / twin, computed by hand
    book, W0, F = make_world("R", n_days=400, seed=41)
    boot = S.Boot(book.signal_day[book.ok])
    di = boot.index(book.signal_day)
    X = S.replay2(book, [("x_change", "<", 0)])
    D1 = S.replay2(book, [("day", "<=", 1), ("day", ">=", 1)])
    DIP = S.replay2(book, [("pc_vs_d1", "<", -2)])
    q = S.stats(X["fresh"], D1["fresh"], boot, di, book, DIP["fresh"])
    pf = S.paired_fast(X["fresh"], D1["fresh"], boot, di)
    pt = S.paired_fast(X["fresh"], DIP["fresh"], boot, di)
    m = X["fresh"]["f"] & D1["fresh"]["f"]
    yrs = pd.DatetimeIndex(book.signal_day[m]).year
    ynet = pd.Series(X["fresh"]["ret"][m]).groupby(yrs).mean()
    h2 = X["fresh"]["ret"][m & (book.signal_day > book.split_day)].mean()
    check("v2 stats(): the paired numbers, net interval around net, years, halves, what the indicators add",
          all(abs(q[k] - pf[k]) < 1e-12 for k in ("n", "setup_net", "lift_pp", "lo", "hi")) and
          q["net_lo"] < q["setup_net"] < q["net_hi"] and q["years"] == len(ynet) and
          q["years_net_pos"] == int((ynet > 0).sum()) and abs(q["half2_net"] - h2) < 1e-12 and
          abs(q["adds"] - pt["lift_pp"]) < 1e-12 and abs(q["adds_lo"] - pt["lo"]) < 1e-12, (q, pf, pt))
    # v3: one book of every engine, split by engine = each engine's own book; the chunked reader = the in-memory join
    tmp = Path(tempfile.mkdtemp(prefix="sl_v06_"))
    W2 = W0.copy()
    W2["engine"] = "ENS"
    W2["trade_id"] = "E" + W2["trade_id"].str[1:]
    WL = pd.concat([W0, W2], ignore_index=True)
    allb = S.Book(WL, pd.Series(book.cal), F, None)
    eb = allb.take(allb.engine_arr == "ENS", "ENS")
    ens = S.Book(WL, pd.Series(book.cal), F, "ENS")
    a1, a2 = S.replay(eb, [("x_change", "<", 0)], "fresh"), S.replay(ens, [("x_change", "<", 0)], "fresh")
    F.to_parquet(tmp / "f.parquet", index=False)
    ck = S.Book(W0, pd.Series(book.cal), None, "D")
    ck.attach(tmp / "f.parquet", ["x", "y"], chunk=1)
    same_f = all(np.array_equal(ck.F[k], book.F[k], equal_nan=True) for k in book.F)
    check("v3 Book.take(engine) = the engine's own book; the chunked panel reader = the in-memory join",
          eb.n == ens.n and (a1.status.values == a2.status.values).all() and
          np.allclose(a1.ret, a2.ret, equal_nan=True) and same_f and ck.features == ["x", "y"], (eb.n, ens.n, same_f))
    # v4: the declared eligibility and score, on a crafted table
    base = {"n": 400, "lo": 0.5, "adds_lo": 0.2, "years": 7, "years_net_pos": 6, "half1_net": 1, "half2_net": 1,
            "net_lo": 0.8, "setup_net": 1.2}
    rows = []
    for name, chg, twin in (("good", {}, "t"), ("small", {"E2:n": 250}, ""), ("noadd", {"E1:adds_lo": -0.1}, "t"),
                            ("noadd-notwin", {"E1:adds_lo": -0.1}, ""), ("twoyears", {"E2:years_net_pos": 5}, ""),
                            ("half", {"E1:half2_net": -0.2}, ""), ("weak", {"E2:net_lo": 0.1}, ""),
                            ('[["snap:pre_state_bearish", ">", 0.5]]', {"E2:filter_q": 0.2}, ""),
                            ('[["snap:rank", "<=", 3.0]]', {}, "")):
        r = {"conds": name, "exit": "fresh", "family": "x", "setup": name, "twin": twin, "twin_conds": twin}
        for e in ("E1", "E2"):
            r.update({"%s:%s" % (e, k): v for k, v in base.items()})
            r["%s:filter_q" % e] = 0.01
        r.update(chg)
        rows.append(r)
    RR = S.rank_rows(pd.DataFrame(rows), ["E1", "E2"]).set_index("conds")
    check("v4 the rule: n, lift, indicators-add (only with a twin), years, halves; score = the worse engine's low end",
          list(RR.index[RR.eligible]) == ["good", "noadd-notwin", "weak", '[["snap:rank", "<=", 3.0]]'] and
          RR.loc["weak", "score"] == 0.1 and "filter does not" in RR.loc['[["snap:pre_state_bearish", ">", 0.5]]', "why_not"] and
          RR.loc["good", "score"] == 0.8 and "E2: fewer than 300" in RR.loc["small", "why_not"],
          RR[["eligible", "why_not", "score"]].to_dict())
    sets = {"a": set(range(100)), "b": set(range(10, 110)), "c": set(range(200, 260)), "d": set(range(300, 340))}
    j = lambda *cs: json.dumps(sorted([list(c) for c in cs]))
    p1 = j(["x_change", "<", 0], ["pc_vs_d1", "<", -2])
    p2 = j(["x_change", "<", 0], ["pc_vs_d1", "<", -2], ["snap:pre_state_bearish", ">", 0.5])   # + a filter
    p3 = j(["x_change", "<", 0], ["pc_vs_d1", "<", -2], ["y_change", ">", 0])                   # + a condition
    p4 = j(["y_change", "<", 0])
    ids2 = {p1: set(range(0, 50)), p2: set(range(100, 130)), p3: set(range(200, 230)), p4: set(range(300, 400))}
    check("v5 versions: 70%-shared trades, a rule that only adds conditions or context filters to a chosen one",
          S.pick_diverse(["a", "b", "c", "d"], sets.get) == ["a", "c", "d"] and
          S.overlap({1, 2}, {1, 2, 3, 4, 5}) == 1.0 and S.pick_diverse([p1, p2, p3, p4], ids2.get) == [p1, p4])
    # v6: a full two-engine run from the command line: union pool, leaderboard, freeze file, resume, refusals
    book6, W6, F6 = make_world("R", n_days=1650, per_day=1, seed=61)
    W7 = W6.copy()
    W7["engine"] = "ENS"
    W7["trade_id"] = "E" + W7["trade_id"].str[1:]
    d = tmp / "data"
    d.mkdir()
    pd.concat([W6, W7], ignore_index=True).to_parquet(d / "watchlist.parquet", index=False)
    pd.DataFrame({"date": pd.to_datetime(book6.cal)}).to_parquet(d / "calendar.parquet", index=False)
    F6.to_parquet(tmp / "f6.parquet", index=False)
    (tmp / "cols.txt").write_text("# test\nx\ny  # both\nzz_not_there\n", encoding="utf-8")
    cmd = ["run", "--data", str(d), "--features", str(tmp / "f6.parquet"), "--columns-file", str(tmp / "cols.txt"),
           "--engine", "D,ENS", "--confluence", "--check", str(d / "watchlist.parquet"), "--out", str(tmp / "run")]
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = S.main(cmd)
    o = tmp / "run"
    fz = json.loads((o / "FREEZE_CANDIDATES.json").read_text()) if (o / "FREEZE_CANDIDATES.json").is_file() else {}
    sd = set(pd.read_csv(o / "D" / "setups_confluence.csv").conds) if (o / "D" / "setups_confluence.csv").is_file() \
        else set()
    se = set(pd.read_csv(o / "ENS" / "setups_confluence.csv").conds) if (o / "ENS" / "setups_confluence.csv").is_file() \
        else {1}
    top = fz.get("lists", {}).get("both exits", [])
    has_x = bool(top) and any(c[0] == "x_change" and c[1] == "<" for c in top[0]["conds"]) and \
        not any(str(c[0]).startswith("snap:") for c in top[0]["conds"])      # the world's contexts are noise
    info = json.loads((o / "RUN.json").read_text()) if (o / "RUN.json").is_file() else {}
    check("v6 two engines in one run: the same confluence combinations in both, a leaderboard, the freeze file; "
          "the planted feature leads; a missing column is skipped and listed; the watchlist check runs",
          rc == 0 and sd == se and (o / "LEADERBOARD.md").is_file() and (o / "POOL.json").is_file() and has_x and
          1 <= len(top) <= 3 and info.get("features_missing") == ["zz_not_there"] and
          info.get("watchlist_check", {}).get("verdict") == "MATCHED",
          (rc, len(sd), len(se), top[:1], info.get("features_missing"), buf.getvalue()[-600:]))
    lb1 = (o / "LEADERBOARD.md").read_text()
    buf2 = io.StringIO()
    with redirect_stdout(buf2):
        rc2 = S.main(cmd)
    lb2 = (o / "LEADERBOARD.md").read_text()
    with redirect_stdout(io.StringIO()):
        rc3 = S.main(cmd[:-1] + [str(o)] if False else [x if x != "D,ENS" else "D" for x in cmd])
    check("v7 the same command again resumes (stage 1 and the confluences kept, the same leaderboard); other settings "
          "in the same folder are refused", rc2 == 0 and "already done" in buf2.getvalue() and lb1 == lb2 and rc3 == 3,
          (rc2, rc3, buf2.getvalue()[-400:]))


# ======================================================================================== v0.7: frozen setups
DAILY_F = ["d_wq_16", "d_mdi14_diff5", "d_wq_40", "d_mdi14", "d_ema20_angle_deg", "d_bb_bw_20", "d_wq_44"]


class FakeLive:
    """Stands in for tradelab's readers in the scan (bars, calendar, panel path, cache root)."""

    def __init__(self, root, cal, bars, panel):
        self.root, self.cal, self._bars, self.panel = Path(root), cal, bars, Path(panel)

    def bars(self, symbols):
        return {s: self._bars[s] for s in symbols if s in self._bars}

    def ohlcv(self, symbols):
        out = {}
        for s in symbols:
            if s in self._bars:
                d, o, c = self._bars[s]
                h, lo = _hl(o, c)
                out[s] = (d, o, h, lo, c, 1e6 + (np.arange(len(c)) % 5) * 1e5)
        return out


def _hl(o, c):
    """The test worlds' highs and lows (the bars only carry opens and closes)."""
    return np.maximum(o, c) * 1.004, np.minimum(o, c) * 0.996


def live_world(tmp, kind="planted", seed=5, n_sess=48):
    """A cache-like world: own bars for every session, a paper ledger (D ranks 1-3, ENS ranks 1-2 a day) and a
    panel with every feature the frozen setups read. 'planted': dips after the pick, random gaps, the weekly
    13-week return falling on some Mondays (posted on the week's first session only) - every setup fires somewhere.
    'absent': prices only rise, opens gap up, the 13-week return never falls, %b > 0 - no setup can fire."""
    rng = np.random.default_rng(seed)
    cal = pd.bdate_range("2026-01-05", periods=n_sess)          # a Monday; no holidays
    days = cal.to_numpy().astype("datetime64[D]")
    mondays = np.array([d.weekday() == 0 for d in cal])
    led, bars, rows = [], {}, []
    names = ["M&M", "BAJAJ-AUTO"]
    t = 0
    for d in range(3, n_sess - 11):
        for eng, nr in (("D", 3), ("ENS", 2)):
            for r in range(1, nr + 1):
                t += 1
                sym = names[t - 1] if t <= len(names) else "Q%04d" % t
                if kind == "planted":
                    lr = rng.normal(0, 0.012, n_sess)
                    lr[d + 1:d + 4] -= rng.uniform(0, 0.03)
                    o = np.empty(n_sess)
                    c = 100 * np.exp(np.cumsum(lr))
                    o[0] = 100.0
                    o[1:] = c[:-1] * (1 + rng.normal(0, 0.006, n_sess - 1))
                    wstep = rng.choice([-1.0, 1.0], n_sess)
                    pctb = rng.uniform(-1, 1, n_sess)
                else:
                    lr = np.abs(rng.normal(0, 0.004, n_sess)) + 0.002
                    c = 100 * np.exp(np.cumsum(lr))
                    o = np.empty(n_sess)
                    o[0] = 100.0
                    o[1:] = c[:-1] * (1 + np.abs(rng.normal(0, 0.002, n_sess - 1)) + 1e-4)
                    wstep = np.ones(n_sess)
                    pctb = rng.uniform(0.1, 1, n_sess)
                bars[sym] = (days.copy(), o, c)
                led.append({"date": str(cal[d].date()), "engine": eng, "rank": r, "symbol": sym,
                            "score": float(rng.random()), "recorded_at": "2026-01-01T20:00:00+05:30"})
                w = np.cumsum(np.where(mondays, wstep, 0.0)) + 50.0
                F = {f: np.cumsum(rng.choice([-1.0, 1.0], n_sess)) for f in DAILY_F}
                for i in range(n_sess):
                    rows.append({"symbol": sym, "timestamp": cal[i], "w_ret_13w": w[i], "d_bb_pctb_20": pctb[i],
                                 "d_atr_pct": 2.0, **{f: F[f][i] for f in DAILY_F}})
    root = Path(tmp) / ("root_" + kind)
    (root / "paper").mkdir(parents=True, exist_ok=True)
    lines = [json.dumps(x) for x in led]
    lines.insert(1, "not json")                                             # an unreadable line is skipped
    lines.append(json.dumps(dict(led[0], symbol="DUPLICATE")))              # a later duplicate is ignored
    (root / "paper" / "ledger.jsonl").write_text("\n".join(lines) + "\n", encoding="utf-8")
    panel = root / "panel_live" / "panel.parquet"
    panel.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_parquet(panel, index=False)
    # the backtest's watchlist of the same picks, built from the same bars (the research route)
    P, wb = [], {}
    for x in led:
        sd = np.datetime64(x["date"], "D")
        j = int(np.flatnonzero(days == sd)[0])
        P.append({"trade_id": "%s-%s-%d" % (x["engine"], x["date"].replace("-", ""), x["rank"]),
                  "engine": x["engine"], "rank": x["rank"], "symbol": x["symbol"], "signal_day": pd.Timestamp(sd),
                  "j": j})
        o, c = bars[x["symbol"]][1], bars[x["symbol"]][2]
        wb[x["symbol"]] = (o, c, np.arange(n_sess))
    W = S.watchlist_rows(P, wb, days)
    W["status"], W["net_bp"], W["pre_state"] = "ok", 0.0, ""
    # s_atr14 as pick_meta records it: the simple 14-session ATR / close at the signal day (blank in the first 14)
    W["s_atr14"] = [float(S.atr_simple(*_hl(*bars[p["symbol"]][1:]), bars[p["symbol"]][2])[p["j"]]) for p in P]
    data = root / "wl"
    data.mkdir(exist_ok=True)
    W.to_parquet(data / "watchlist.parquet", index=False)
    pd.DataFrame({"date": cal}).to_parquet(data / "calendar.parquet", index=False)
    return {"root": root, "cal": days, "bars": bars, "panel": panel, "data": data, "led": led}


def test_freeze(doc, final_from=None):
    """A copy of the freeze with other setups / numbers, hashed like the real one (for the tests only)."""
    d = json.loads(json.dumps(doc))
    d.pop("sha256", None)
    if final_from is not None:
        for s in d["setups"]:
            s["final_001"] = final_from[s["id"]]
    d["sha256"] = S.frozen_hash(d)
    return d


def t_v07():
    import io
    import tempfile
    from contextlib import redirect_stdout
    tmp = Path(tempfile.mkdtemp(prefix="sl_v07_"))
    # ---- the freeze file
    fp, doc = S.load_frozen()
    ids = [x["id"] for x in doc["setups"]]
    bad = json.loads(fp.read_text(encoding="utf-8"))
    bad["setups"][0]["conds"][1][2] = -2.0
    (tmp / "bad.json").write_text(json.dumps(bad), encoding="utf-8")
    bad2 = json.loads(fp.read_text(encoding="utf-8"))
    bad2["setups"][2]["conds"][0][2] = 0.5
    bad2["sha256"] = S.frozen_hash(bad2)                    # file hash redone, the setup's own hash not
    (tmp / "bad2.json").write_text(json.dumps(bad2), encoding="utf-8")
    ref = []
    for f in ("bad.json", "bad2.json"):
        try:
            S.load_frozen(tmp / f)
            ref.append(False)
        except ValueError:
            ref.append(True)
    check("f1 the freeze file: 7 setups S1 S2 S3 C1 C2 C3 N1 with their sha256; a changed threshold is refused, and "
          "so is a re-hashed file whose setup no longer matches its own hash",
          ids == ["S1", "S2", "S3", "C1", "C2", "C3", "N1"] and all(ref) and
          [x["primary_exit"] for x in doc["setups"]] == ["original_d5"] * 6 + ["fresh"] and
          sorted(S.frozen_features(doc)) == sorted(DAILY_F + ["w_ret_13w", "d_bb_pctb_20"]), (ids, ref))
    conds, feats = S.frozen_conds(doc), S.frozen_features(doc)
    # ---- the planted world: the nightly scan, evening by evening, against the backtest on the full data
    w = live_world(tmp, "planted")
    data = FakeLive(w["root"], w["cal"], w["bars"], w["panel"])
    L = S.read_paper_ledger(w["root"])
    check("f2 the paper ledger reader: unreadable lines skipped, the first record of a day / engine / rank kept",
          len(L) == len(w["led"]) and "DUPLICATE" not in set(L.symbol), (len(L), len(w["led"])))
    truth = {}
    for e in ("D", "ENS"):
        with redirect_stdout(io.StringIO()):
            book = S.load(w["data"], w["panel"], e, feats + ["d_atr_pct"], None)
        for sid, cc in conds.items():
            day, st = S.trigger(book, cc)
            for i in np.flatnonzero(st == "Filled"):
                truth[(book.ids[i], sid)] = (int(day[i]), float(book.O[i, day[i]]))
    ann, entered, statuses, tonight_dip = {}, {}, set(), []
    pos = {d: i for i, d in enumerate(w["cal"])}
    out = tmp / "scan_planted"
    for T in w["cal"][3:]:
        Sx, P = S.scan_day(T, doc, conds, feats, L, data, out)
        statuses |= set(Sx.status)
        for r in Sx.itertuples(index=False):
            if r.status in ("FIRES", "ARMED"):
                ann.setdefault((r.trade_id, r.setup), []).append((T, r.status, int(r.next_watch_day),
                                                                  float(r.open_threshold)))
                if int(r.next_watch_day) == 1 and any(f.startswith("pc_vs_d1") for f, _, _ in conds[r.setup]):
                    tonight_dip.append(r)
            if r.status == "ENTERED":
                entered[(r.trade_id, r.setup)] = (int(r.entered_day), float(r.entry))
    # every backtest entry was named the evening before, with its watch day
    sig = {}
    for x in w["led"]:
        sig["%s-%s-%d" % (x["engine"], x["date"].replace("-", ""), x["rank"])] = (pos[np.datetime64(x["date"], "D")],
                                                                                  x["symbol"])
    miss_named, false_fires, armed_bad, armed_n = [], [], [], 0
    for key, (k, px) in truth.items():
        si = sig[key[0]][0]
        ok = any(pos[T] == si + k - 1 and wd == k for T, stt, wd, thr in ann.get(key, []))
        if not ok:
            miss_named.append(key)
    for key, lst in ann.items():
        for T, stt, wd, thr in lst:
            si, sym = sig[key[0]]
            t_open = w["bars"][sym][1][pos[T] + 1]
            if stt == "FIRES" and truth.get(key, (None,))[0] != wd:
                false_fires.append((key, T))
            if stt == "ARMED":
                armed_n += 1
                hit = truth.get(key, (None,))[0] == wd
                if hit != (t_open < thr):
                    armed_bad.append((key, T, t_open, thr))
    check("f3 the scan, evening by evening, names EVERY backtest entry of every setup the evening before it, with the "
          "same watch day (%d entries in both engines, all 7 setups)" % len(truth),
          len(truth) > 100 and not miss_named and {k[1] for k in truth} == set(ids), miss_named[:5])
    check("f4 no false FIRES: every FIRES became the backtest's entry on that watch day", not false_fires,
          false_fires[:5])
    check("f5 ARMED (gap-down setup S2): entered exactly when the next open was below tonight's close (%d named)"
          % armed_n, armed_n > 5 and not armed_bad, armed_bad[:5])
    same_ent = all(entered.get(k) is not None and entered[k][0] == v[0] and abs(entered[k][1] - v[1]) < 1e-9
                   for k, v in truth.items() if sig[k[0]][0] + v[0] - 1 < len(w["cal"]) - 1)
    check("f6 ENTERED on later evenings shows the backtest's entry day and price; no dip setup ever fires at D1",
          same_ent and not tonight_dip and {"FIRES", "ARMED", "ENTERED", "WATCHING", "EXPIRED"} <= statuses,
          (same_ent, len(tonight_dip), statuses))
    # forward record: every evening recorded on time -> the named entries = the backtest's trades and nets
    lp = tmp / "fwd_ledger.jsonl"
    for T in w["cal"][3:]:
        Sx, _ = S.scan_day(T, doc, conds, feats, L, data, out)
        named = [{"setup": r.setup, "status": r.status, "trade_id": r.trade_id, "symbol": r.symbol,
                  "watch_day": int(r.next_watch_day), "close_tonight": float(r.close_tonight),
                  "rule_at_open": r.rule_at_open} for r in Sx[Sx.status.isin(["FIRES", "ARMED"])].itertuples()]
        S.ledger_append(lp, {"event": "scan", "scan_date": str(pd.Timestamp(T).date()), "on_time": True,
                             "named": named})
    Fw = S.forward_record(L, data, doc, conds, feats, lp, w["cal"][-1], since="2026-01-01")
    nets = {}
    for e in ("D", "ENS"):
        with redirect_stdout(io.StringIO()):
            book = S.load(w["data"], w["panel"], e, feats + ["d_atr_pct"], None)
        for sid, cc in conds.items():
            R = S.replay2(book, cc)
            for i in np.flatnonzero(R["original_d5"]["f"]):
                nets[(book.ids[i], sid)] = (R["original_d5"]["ret"][i], R["fresh"]["ret"][i])
    E = Fw[Fw.entered]
    fwd_ok = len(E) == len(truth) and all(
        abs(r.net_d5 - nets[(r.trade_id, r.setup)][0]) < 1e-9 and
        (np.isnan(r.net_fresh) or abs(r.net_fresh - nets[(r.trade_id, r.setup)][1]) < 1e-9)
        for r in E.itertuples() if (r.trade_id, r.setup) in nets)
    check("f7 the forward record (on-time names only) = the backtest's trades, with the same net on both exits",
          fwd_ok and int((~Fw.entered).sum()) == sum(1 for v in ann.values() for x in v if x[1] == "ARMED") -
          sum(1 for k, v in ann.items() for x in v if x[1] == "ARMED" and truth.get(k, (0,))[0] == x[2]),
          (len(E), len(truth)))
    # ---- the absent world: nothing can fire
    a = live_world(tmp, "absent", seed=6)
    da = FakeLive(a["root"], a["cal"], a["bars"], a["panel"])
    La = S.read_paper_ledger(a["root"])
    st_a = set()
    for T in a["cal"][3:]:
        Sx, _ = S.scan_day(T, doc, conds, feats, La, da, tmp / "scan_absent")
        st_a |= set(Sx.status)
    n_bt = 0
    for e in ("D", "ENS"):
        with redirect_stdout(io.StringIO()):
            book = S.load(a["data"], a["panel"], e, feats + ["d_atr_pct"], None)
        n_bt += sum(int((S.trigger(book, cc)[1] == "Filled").sum()) for cc in conds.values())
    check("f8 absent world (no weekly drop, no dip, %b > 0): no backtest entry and the scan never names one",
          n_bt == 0 and st_a <= {"WATCHING", "EXPIRED"}, (n_bt, st_a))
    # ---- the ledger: hash chain, on-time deadline
    ed = lp.read_text(encoding="utf-8").splitlines()
    rec = json.loads(ed[2])
    rec["named"] = []
    ed[2] = json.dumps(rec, sort_keys=True)
    lp2 = tmp / "edited.jsonl"
    lp2.write_text("\n".join(ed) + "\n", encoding="utf-8")
    try:
        S.ledger_append(lp2, {"event": "scan", "scan_date": "x"})
        chain = False
    except ValueError:
        chain = True
    fri = np.datetime64("2026-01-09", "D")
    d1 = S.on_time_deadline(fri, w["cal"][w["cal"] <= fri])
    d2 = S.on_time_deadline(np.datetime64("2026-01-06", "D"), w["cal"])
    check("f9 the setup ledger is hash-chained (an edited record is refused); on time = before 09:00 IST of the next "
          "session (Friday -> Monday; a late scan uses the known next session)",
          chain and d1.isoformat() == "2026-01-12T09:00:00+05:30" and d2.isoformat() == "2026-01-07T09:00:00+05:30",
          (chain, d1, d2))
    # ---- TradingView import text
    Sx, _ = S.scan_day(w["cal"][6], doc, conds, feats, L, data, out)
    tv = S.tv_text(pd.DataFrame([{"setup": "S2", "status": "ARMED", "symbol": "M&M"},
                                 {"setup": "S2", "status": "ARMED", "symbol": "M&M"},
                                 {"setup": "C1", "status": "FIRES", "symbol": "BAJAJ-AUTO"},
                                 {"setup": "C1", "status": "ENTERED", "symbol": "ABC"}]))
    check("f10 TradingView import: one section per setup and action, NSE tickers (M&M -> NSE:M_M), no duplicates",
          tv == "###C1 buy at open,NSE:BAJAJ_AUTO,###S2 buy if the open meets its rule,NSE:M_M,"
                "###Entered (open setup positions),NSE:ABC", tv)
    # ---- tag: the whole history, reconciled against the freeze's numbers
    fin = {}
    for e in ("D", "ENS"):
        with redirect_stdout(io.StringIO()):
            book = S.load(w["data"], w["panel"], e, feats + ["d_atr_pct"], None)
        d1 = S.replay2(book, S.D1_CONDS)
        for sid, cc in conds.items():
            R = S.replay2(book, cc)
            for m in S.EXITS:
                mm = R[m]["f"] & d1[m]["f"]
                fin.setdefault(sid, {})["%s %s" % (e, m)] = {"n": float(mm.sum()),
                                                              "setup_net": round(float(R[m]["ret"][mm].mean()), 6)}
    tf = tmp / "freeze_world.json"
    tf.write_text(json.dumps(test_freeze(doc, fin), indent=1), encoding="utf-8")
    rcs = []
    for frz in (str(tf), None):
        args = ["tag", "--data", str(w["data"]), "--features", str(w["panel"]), "--out", str(tmp / "tags")]
        if frz:
            args += ["--frozen", frz]
        buf = io.StringIO()
        with redirect_stdout(buf):
            rcs.append((S.main(args), buf.getvalue()))
    runs = sorted((tmp / "tags" / "TAGS").glob("TAGS_*"))
    Wt = pd.read_parquet(runs[0] / "setup_tags.parquet")
    Lt = pd.read_parquet(runs[0] / "setup_trades.parquet")
    js = json.loads((runs[0] / "TAGS.json").read_text(encoding="utf-8"))
    hashes_ok = all(__import__("hashlib").sha256((runs[0] / ln.split("  ")[1]).read_bytes()).hexdigest() ==
                    ln.split("  ")[0] for ln in (runs[0] / "outputs.sha256").read_text().splitlines())
    tag_same = set(zip(Lt.trade_id, Lt.setup)) == set(truth) and all(
        int(Wt.set_index("trade_id").at[t, "su_%s_day" % s]) == truth[(t, s)][0] for t, s in truth)
    txt_ok = all(set(x.split()) == {"%s@D%d" % (s, d) for (t, s), (d, _) in truth.items() if t == tid}
                 for tid, x in zip(Wt.trade_id, Wt.setups.fillna("")))
    check("f11 tag: every past pick's setups (watch day, price, both exits) = the backtest's; the 'setups' text, the "
          "long table and the hashes agree; RECONCILED against matching numbers, DIFFERS against FINAL_001's",
          rcs[0][0] == 0 and "TAGS RECONCILED" in rcs[0][1] and rcs[1][0] == 0 and "TAGS WRITTEN" in rcs[1][1] and
          js["reconciled_with_final_001"] and tag_same and txt_ok and hashes_ok and len(js["atr_check"]) == 2,
          (rcs[0][1][-200:], tag_same, txt_ok, hashes_ok, js.get("atr_check")))
    # ---- the command: outputs, a second run skipped, --force rescans but the ledger keeps its first record
    real = S.LiveData
    S.LiveData = lambda root, any_=False, panel="panel_live": FakeLive(w["root"], w["cal"], w["bars"], w["panel"])
    try:
        d = str(pd.Timestamp(w["cal"][10]).date())
        o = tmp / "cmd"
        r1 = S.main(["scan", "--root", str(w["root"]), "--out", str(o), "--date", d])
        n1 = len((o / "scan" / "setup_ledger.jsonl").read_text().splitlines())
        buf = io.StringIO()
        with redirect_stdout(buf):
            r2 = S.main(["scan", "--root", str(w["root"]), "--out", str(o), "--date", d])
        r3 = S.main(["scan", "--root", str(w["root"]), "--out", str(o), "--date", d, "--force"])
        n3 = len((o / "scan" / "setup_ledger.jsonl").read_text().splitlines())
        tag = d.replace("-", "")
        files = all((o / "scan" / f).is_file() for f in ("SCAN_%s.md" % tag, "scan_%s.csv" % tag, "tv_%s.txt" % tag))
        page = (o / "scan" / ("SCAN_%s.md" % tag)).read_text(encoding="utf-8")
        rec = json.loads((o / "scan" / "setup_ledger.jsonl").read_text().splitlines()[0])
    finally:
        S.LiveData = real
    # the nightly panel not yet updated for the evening: refused (retried by --all-missing), never NO DATA guesses
    cut = w["cal"][20]
    pp = pd.read_parquet(w["panel"])
    pp[pd.to_datetime(pp["timestamp"]) <= pd.Timestamp(cut)].to_parquet(tmp / "panel_cut.parquet", index=False)
    try:
        S.scan_day(w["cal"][21], doc, conds, feats, L, FakeLive(w["root"], w["cal"], w["bars"], tmp / "panel_cut.parquet"),
                   tmp / "scan_cut")
        cut_ok = False
    except ValueError as e:
        cut_ok = "has no row for 2026-02-03" in str(e)
    check("f13 an evening the nightly panel has not reached yet is refused (the scan never decides on missing features)",
          cut_ok)
    check("f12 the scan command: page, CSV, TradingView file and a ledger record (late: the evening was long past); "
          "the same evening again is skipped; --force rescans and the ledger keeps the first record",
          r1 == 0 and r2 == 0 and r3 == 0 and files and n1 == 1 and n3 == 1 and "already scanned" in buf.getvalue()
          and rec["on_time"] is False and "## At the next open" in page and "Forward record" in page,
          (r1, r2, r3, files, n1, n3, rec.get("on_time")))
    # ---- tradelab's reader (tl_setups, setups add-on) on the REAL outputs written above: the tags and the scan
    try:
        import tl_setups as SU
    except ImportError as e:
        check("f14 tradelab's tl_setups reads these tags and this scan", False,
              "tradelab's tl_setups is not importable (%s) - run the self-test after env_playbook.bat or "
              "env_tradelab.bat (tradelab with the setups add-on on PYTHONPATH)" % e)
        return
    Tt, ti = SU.load_tags(tmp / "tags", need=True)
    Lt2 = pd.read_parquet(Path(ti["folder"]) / "setup_trades.parquet")
    lp = {(str(t), s): int(dd) for t, s, dd in zip(Lt2.trade_id, Lt2.setup, Lt2.watch_day)}
    sp = {(t, s): dd for t, m in SU.setup_days(Tt, ti["setups"]).items() for s, dd in m.items()}
    tids = list(Tt.trade_id) + ["D-20990101-1"]
    X = SU.tag_columns(pd.DataFrame({"trade_id": tids}), Tt, ti["setups"], ti["primary_exit"], nets=True)
    Ti = Tt.set_index("trade_id")
    nets_ok = all(np.allclose(X["su_%s_net" % s].to_numpy(float)[:-1], Ti["su_%s_net_%s" % (
        s, "d5" if ti["primary_exit"][s] == "original_d5" else "fresh")].to_numpy(float), equal_nan=True)
        for s in ti["setups"])
    Sx, si = SU.read_scan(o, d)
    sc = pd.read_csv(o / "scan" / ("scan_%s.csv" % tag), dtype={"trade_id": str})
    act = SU.action_rows(Sx)
    words_ok = all(SU.scan_words(r) and SU.scan_words(r) in SU.pick_setups_text(
        Sx, r["engine"], int(r["rank"]), r["symbol"], r["signal_day"]) for r in act if r["status"] != "ENTERED")
    check("f14 tradelab's tl_setups reads these tags and this scan: the 7 setups and their primary exits, every "
          "entry's watch day (= the long table), each pick's net at its primary exit, an uncovered pick left blank; "
          "the scan's rows, its ledger record (LATE) and every action worded on its pick",
          ti["setups"] == ids and ti["primary_exit"]["N1"] == "fresh" and sp == lp and len(lp) == len(truth) and
          nets_ok and not bool(X.iloc[-1]["setups_tagged"]) and si["found"] and si["on_time"] is False and
          len(Sx) == len(sc) and len(act) == int(sc.status.isin(["FIRES", "ARMED", "ENTERED"]).sum()) > 0 and
          words_ok, (ti["setups"], len(lp), len(truth), nets_ok, si, len(act)))


# ======================================================================================== v0.8: zones and the chart
def _syn_stock(seed, n=900, flat=False):
    """A synthetic daily stock from 2015 (a holiday, continuous volumes; flat=True adds a 40-day stuck stretch)."""
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2015-01-05", periods=n)
    dates = dates[~((dates.month == 8) & (dates.day == 15))]
    n = len(dates)
    lr = rng.normal(0, 0.02, n)
    if flat:
        lr[300:340] = 0.0
    c = 100 * np.exp(np.cumsum(lr))
    o = c * (1 + rng.normal(0, 0.008, n))
    h = np.maximum(o, c) * (1 + np.abs(rng.normal(0, 0.01, n)))
    lo = np.minimum(o, c) * (1 - np.abs(rng.normal(0, 0.01, n)))
    if flat:
        o[300:340] = h[300:340] = lo[300:340] = c[300:340]
    v = np.round(rng.lognormal(13, 0.6, n))
    return dates, o, h, lo, c, v


def _idx_series(seed, n=900):
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2015-01-05", periods=n)
    return dates.to_numpy().astype("datetime64[D]"), 1000 * np.exp(np.cumsum(rng.normal(0, 0.012, n)))


def _fx():
    """Production's features_daily (bigmove_deploy, on PYTHONPATH through env_tradelab.bat / env_playbook.bat)."""
    try:
        import features_daily as FX
        return FX
    except ImportError:
        return None


class FakeZoneLive(FakeLive):
    """FakeLive with the v0.8 readers: index closes (synthetic, on the world's calendar), forget."""

    def __init__(self, w):
        super().__init__(w["root"], w["cal"], w["bars"], w["panel"])
        rng = np.random.default_rng(3)
        self._idx = {k: (w["cal"], 100 * np.exp(np.cumsum(rng.normal(0, 0.01, len(w["cal"])))))
                     for k, _ in S.ZONE_INDEX}

    def index_closes(self, names):
        return {k: self._idx[k] for k in names}

    def forget(self, symbols):
        pass


def t_v08():
    import io
    import tempfile
    from contextlib import redirect_stdout
    sys.path.insert(0, str(HERE))
    import pine_mirror as PM
    tmp = Path(tempfile.mkdtemp(prefix="sl_v08_"))
    fp, doc = S.load_frozen()
    conds, feats = S.frozen_conds(doc), S.frozen_features(doc)
    # ---- z1 the zone values: setuplab's vectorised code = the Pine's bar-by-bar mirror (stock and index measures)
    worst = 0.0
    for seed in (1, 2, 3):
        dates, o, h, lo, c, v = _syn_stock(seed)
        days = ((dates.to_numpy().astype("datetime64[D]") - np.datetime64("1970-01-01")).astype(int)).tolist()
        M = PM.features(days, list(o), list(h), list(lo), list(c), list(v))
        sd = S.stock_dims(o, h, lo, c, v)
        sd["s_atr"] = S.atr_simple(h, lo, c)
        for k in ("ATRP", "ATRX", "TREND", "RET20", "RSI14", "DD52", "RVOL", "s_atr"):
            if not np.array_equal(np.isnan(sd[k]), np.isnan(M[k])):
                worst = np.inf
            else:
                worst = max(worst, float(np.nanmax(np.abs(sd[k] - M[k]))))
    idx = {k: _idx_series(10 + i) for i, (k, _) in enumerate(S.ZONE_INDEX)}
    MD = S.market_dims(idx)
    mi = {k: PM.index_dims(list(cl), k) for k, (_, cl) in idx.items()}
    up = np.array([mi[k]["up"] for k in ("nifty", "mid", "small")])
    idx_ok = (np.allclose(MD["IDX"].to_numpy(), np.where(np.isnan(up).any(0), np.nan, up.sum(0)), equal_nan=True) and
              np.allclose(MD["VIXP"].to_numpy(), mi["vix"]["vixp"], equal_nan=True) and
              np.allclose(MD["VIX5"].to_numpy(), mi["vix"]["vix5"], equal_nan=True) and
              np.allclose(MD["NIFTY20"].to_numpy(), mi["nifty"]["ret20"], equal_nan=True) and
              np.allclose(MD["SMALL20"].to_numpy(), mi["small"]["ret20"], equal_nan=True))
    bk = S.zone_buckets({d[0]: np.array([1.99, 2.0, 4.5, np.nan] if d[0] == "ATRP" else [0, 1, 2, np.nan]
                                        if d[0] in ("TREND", "IDX") else [np.nan] * 4) for d in S.ZONE_DIMS})
    check("z1 the zone values: setuplab's vectorised measures = the Pine's bar-by-bar mirror on 3 stocks of 900 "
          "sessions (largest difference %.1e), pick_meta's simple ATR for S1 too, and on the four indices (IDX, VIX percentile, VIX 5-day, NIFTY and "
          "Smallcap 20-day); buckets: an edge counts upward (ATR%% 2.0 -> '2-3'), unknown = -1" % worst,
          worst < 1e-9 and idx_ok and list(bk["ATRP"]) == [0, 1, 3, -1] and list(bk["TREND"]) == [0, 1, 2, -1],
          (worst, idx_ok, list(bk["ATRP"])))
    # ---- z2 the whole-market engine = setuplab's own replay with every stock-day as a pick
    w = live_world(tmp, "planted", seed=5, n_sess=48)
    P = pd.read_parquet(w["panel"])
    P.columns = [x.lower() for x in P.columns]
    P["date"] = pd.to_datetime(P["timestamp"]).dt.normalize().to_numpy().astype("datetime64[D]")
    want = list(dict.fromkeys([f.lower() for f in feats] + ["d_atr_pct"]))
    picks, wb = [], {}
    for s_, (dd, o, c) in w["bars"].items():
        wb[s_] = (o, c, np.arange(len(c)))
        for j in range(len(c) - 1):
            picks.append({"trade_id": "X-%s-%d" % (s_, j), "engine": "X", "rank": 1, "symbol": s_,
                          "signal_day": pd.Timestamp(dd[j]), "j": j})
    W = S.watchlist_rows(picks, wb, w["cal"])
    W["status"], W["net_bp"], W["pre_state"] = "ok", 0.0, ""
    W["s_atr14"] = [float(S.atr_simple(*_hl(*w["bars"][p_["symbol"]][1:]), w["bars"][p_["symbol"]][2])[p_["j"]])
                    for p_ in picks]
    (tmp / "allwl").mkdir()
    W.to_parquet(tmp / "allwl" / "watchlist.parquet", index=False)
    pd.DataFrame({"date": pd.DatetimeIndex(w["cal"])}).to_parquet(tmp / "allwl" / "calendar.parquet", index=False)
    with redirect_stdout(io.StringIO()):
        book = S.load(tmp / "allwl", w["panel"], "X", feats + ["d_atr_pct"], None)
    ref = {}
    for sid, cc in conds.items():
        R = S.replay2(book, cc)["fresh"]
        for i in np.flatnonzero(R["f"]):
            j = int(book.wl["trade_id"].iloc[i].rsplit("-", 1)[1])
            ref.setdefault((sid, book.symbols[i], j + int(R["day"][i])), set()).add(round(float(R["ret"][i]), 9))
    mine = {}
    for s_, (dd, o, c) in w["bars"].items():
        F, have = S.align_panel(P[P["symbol"] == s_].sort_values("date"), want, dd)
        for sid, e in S.market_entries(dd, o, c, F, S.atr_simple(*_hl(o, c), c), conds, have).items():
            for x in e[e + 4 < len(c)]:
                mine[(sid, s_, int(x))] = round((c[x + 4] / o[x] - 1) * 100 - S.COST, 9)
    check("z2 the whole market: every stock-day as a pseudo-pick gives exactly setuplab's own replay (every stock-day "
          "as a pick in a Book): %d entries, the same entry day and the same net held 5 sessions" % len(mine),
          set(ref) == set(mine) and all(len(x) == 1 and abs(next(iter(x)) - mine[k]) < 1e-7 for k, x in ref.items())
          and len(mine) > 500, (len(ref), len(mine)))
    # ---- z3 the search: a planted zone is found and holds out of sample; an absent one does not hold
    def zworld(effect, seed, n=4000):
        rng = np.random.default_rng(seed)
        cal = pd.bdate_range("2020-01-01", "2026-09-30").to_numpy().astype("datetime64[D]")
        pops = []
        for nm in ("D", "ENS"):
            day = np.sort(rng.choice(cal[:-10], n))
            B = {d[0]: rng.integers(0, len(d[3]), n).astype(np.int8) for d in S.ZONE_DIMS}
            net = rng.normal(0.5, 6.0, n) + rng.normal(0, 2, len(cal))[np.searchsorted(cal, day)]
            if effect:
                net += np.where(B["ATRP"] >= 2, 2.5, -0.5)
            pops.append(S._pop(nm, day, day + np.timedelta64(7, "D"), net, net + 3.0, B))
        return pops
    zp, evp, Tp, _ = S.choose_zone(zworld(True, 3))
    _, wrp = S.walk_forward(zworld(True, 3))
    za, eva, Ta, _ = S.choose_zone(zworld(False, 3))
    _, wra = S.walk_forward(zworld(False, 3))
    atr_in = zp is not None and any(r[0] == "ATRP" and r[1] >= 2 and r[2] == 3 for r in zp)
    # qualifying = the 95% intervals, not the point estimates: absent-world finalists with inside > outside whose
    # interval reaches 0 exist and do not qualify; every interval brackets its estimate
    rule = all(bool(r["qualifies"]) == all(r["%s_diff_lo" % p_] > 0 and r["%s_chk_lo" % p_] > 0 for p_ in ("D", "ENS"))
               for r in Ta.to_dict("records") if all(r["%s_n" % p_] >= 40 * 6.0 for p_ in ("D", "ENS")))
    wide = bool(((Ta["D_diff"] > 0) & (Ta["D_diff_lo"] <= 0) & ~Ta["qualifies"]).any())
    brackets = bool(((Ta["D_diff_lo"] <= Ta["D_diff"]) & (Ta["D_diff"] <= Ta["D_diff_hi"]) &
                     (Ta["D_lo"] <= Ta["D_net"]) & (Ta["D_net"] <= Ta["D_hi"])).all())
    check("z3 the zone search: planted (net +2.5 when ATR%% >= 3, else -0.5; noise and day shocks) -> '%s', out of "
          "sample %s; absent (no effect) -> %s with %d qualifying finalists in sample (luck) - out of sample %s, so it "
          "does not hold" % (S.zone_text(zp), "/".join(v["verdict"] for v in wrp.values()), S.zone_text(za),
                             int(Ta["qualifies"].sum()) if len(Ta) else 0,
                             "/".join(v["verdict"] for v in wra.values())),
          atr_in and all(v["verdict"] == "HOLDS" for v in wrp.values()) and
          not all(v["verdict"] == "HOLDS" for v in wra.values()) and rule and wide and brackets,
          (zp, wrp, za, wra, rule, wide, brackets))
    # ---- z4 the command end to end (planted world: picks from a tag run + the whole market)
    out = tmp / "out"
    with redirect_stdout(io.StringIO()):
        rc_tag = S.main(["tag", "--data", str(w["data"]), "--features", str(w["panel"]), "--out", str(out)])
    a = type("A", (), {"frozen": None, "out": str(out), "features": str(w["panel"]), "picks_only": False,
                       "root": str(w["root"]), "stage_e_any": False, "data": str(w["data"])})()
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = S.cmd_zones(a, data=FakeZoneLive(w))
    zrun, zdoc = S.load_zones(out)
    files = all((zrun / f).is_file() for f in ("ZONES.md", "SETUP_ZONES.json", "PINE_ZONE_CODE.txt",
                                              "zone_finalists.csv", "walk_forward.csv", "market_zone_trades.parquet"))
    code = (zrun / "PINE_ZONE_CODE.txt").read_text().strip()
    bad = json.loads((zrun / "SETUP_ZONES.json").read_text())
    bad["setups"]["S1"]["picks"]["zone"] = "ATRP:3:3"
    (zrun / "SETUP_ZONES.json").write_text(json.dumps(bad))
    try:
        S.load_zones(out)
        tamper = False
    except ValueError:
        tamper = True
    (zrun / "SETUP_ZONES.json").write_text(json.dumps(zdoc, indent=1))
    MT = pd.read_parquet(zrun / "market_zone_trades.parquet")
    check("z4 the zones command: the tag run's picks and the whole market (%d trades) searched, ZONES.md, "
          "SETUP_ZONES.json (hash-checked: an edited zone is refused), the finalists, the walk-forward and the Pine "
          "code '%s...'" % (len(MT), code[:40]),
          rc_tag == 0 and rc == 0 and files and tamper and code.startswith("BMSZ1|S1=") and code.count("|") == 7 and
          "ZONES WRITTEN" in buf.getvalue() and len(MT) > 300 and np.isfinite(MT["chk"]).all() and
          "WARNING" not in zdoc["atr_check"] and "= the simple ATR14" in zdoc["atr_check"],
          (rc_tag, rc, files, tamper, code, buf.getvalue()[-300:]))
    # ---- z5 the nightly scan with zones: IN / OUT at the close before the entry, in the ledger, the forward record,
    #      the page and tradelab's wording
    zd = json.loads(json.dumps(zdoc))
    for sid in zd["setups"]:
        zd["setups"][sid]["picks"] = {"zone": "RET20:0:1", "text": S.zone_text(S.zone_parse("RET20:0:1")),
                                      "out_of_sample": {"D": {"verdict": "NOT SHOWN"}, "ENS": {"verdict": "NOT SHOWN"}}}
    zd.pop("sha256")
    zd["sha256"] = S.zones_hash(zd)
    zr2 = S.new_run_dir(out / "ZONES", "ZONES")
    (zr2 / S.ZONES_FILE).write_text(json.dumps(zd, indent=1))
    real = S.LiveData
    fz = FakeZoneLive(w)
    S.LiveData = lambda root, any_=False, panel="panel_live": fz
    try:
        d = str(pd.Timestamp(w["cal"][30]).date())
        with redirect_stdout(io.StringIO()):
            r1 = S.main(["scan", "--root", str(w["root"]), "--out", str(out), "--date", d])
    finally:
        S.LiveData = real
    Sx = pd.read_csv(out / "scan" / ("scan_%s.csv" % d.replace("-", "")), dtype={"trade_id": str})
    act = Sx[Sx["status"].isin(["FIRES", "ARMED", "ENTERED"])]
    bars = fz.ohlcv(sorted(act["symbol"].unique()))
    Mz = S.market_dims(fz.index_closes(dict(S.ZONE_INDEX)))
    hand = []
    for r in act.itertuples(index=False):
        dd, o, h, lo, c, v = bars[r.symbol]
        z = S.zone_buckets(S.zone_values(dd, o, h, lo, c, v, Mz))
        j = (int(np.searchsorted(dd, np.datetime64(r.entry_date, "D"))) - 1 if r.status == "ENTERED" else
             int(np.flatnonzero(dd == np.datetime64(d, "D"))[0]))
        hand.append("IN" if 0 <= z["RET20"][j] <= 1 else "OUT")
    rec = [json.loads(x) for x in (out / "scan" / "setup_ledger.jsonl").read_text().splitlines()][-1]
    page = (out / "scan" / ("SCAN_%s.md" % d.replace("-", ""))).read_text(encoding="utf-8")
    try:
        import tl_setups as SU
        words = [SU.scan_words(r) for r in act.to_dict("records")]
        words_ok = all(("in its zone" in wd) == (r["zone"] == "IN") and ("outside its zone" in wd) ==
                       (r["zone"] == "OUT") for wd, r in zip(words, act.to_dict("records")))
    except ImportError:
        words_ok = False
    check("z5 the scan with zones: every FIRES / ARMED / ENTERED row IN or OUT exactly as the zone at the close before "
          "its entry, by hand (%d rows, %d IN); the ledger keeps each named entry's zone and the zones file's hash; "
          "the page says IN / OUT; tradelab's watch page words it ('in its zone' / 'outside its zone')" % (
              len(act), sum(x == "IN" for x in hand)),
          r1 == 0 and len(act) > 0 and list(act["zone"]) == hand and 0 < sum(x == "IN" for x in hand) < len(hand) and
          rec.get("zones_sha256") == zd["sha256"] and all("zone" in x for x in rec["named"]) and "| zone |" in page
          and words_ok, (r1, list(act["zone"]), hand, rec.get("zones_sha256"), words_ok))
    # ---- z6 a zone problem (an index file missing) never stops the nightly scan: rows without a zone, said in the log
    class Broken(FakeZoneLive):
        def index_closes(self, names):
            raise ValueError("INDIAVIX daily bars are not in the cache")
    fb = Broken(w)
    S.LiveData = lambda root, any_=False, panel="panel_live": fb
    try:
        d2 = str(pd.Timestamp(w["cal"][31]).date())
        buf = io.StringIO()
        with redirect_stdout(buf):
            r2 = S.main(["scan", "--root", str(w["root"]), "--out", str(out), "--date", d2])
    finally:
        S.LiveData = real
    S2 = pd.read_csv(out / "scan" / ("scan_%s.csv" % d2.replace("-", "")), dtype={"trade_id": str})
    check("z6 a zone problem (an index file missing) never stops the nightly scan: the evening is scanned, its rows "
          "have no zone and the log says why",
          r2 == 0 and S2["zone"].isna().all() and "zones not applied" in buf.getvalue() and
          (out / "scan" / ("SCAN_%s.md" % d2.replace("-", ""))).is_file(), (r2, buf.getvalue()[-300:]))
    # ---- p1 the Pine mirror's features = production's features_daily on the same bars
    FX = _fx()
    pairs = {"d_mdi14": "D_mdi14", "d_mdi14_diff5": "D_mdi14_diff5", "d_ema20_angle_deg": "D_ema20_angle_deg",
             "d_bb_bw_20": "D_bb_bw_20", "d_bb_pctb_20": "D_bb_pctB_20", "w_ret_13w": "W_ret_13w",
             "d_wq_16": "D_WQ_16", "d_wq_40": "D_WQ_40", "d_wq_44": "D_WQ_44", "d_atr_pct": "D_atr_pct",
             "RSI14": "D_rsi14"}
    worst, nan_ok, n_cmp, mk_ok, tn_ok, n_marks, n_tn = 0.0, True, 0, True, True, 0, 0
    if FX is not None:
        for seed in (1, 2, 3):
            dates, o, h, lo, c, v = _syn_stock(seed)
            X = FX.compute_daily_indicators(pd.DataFrame({"timestamp": dates, "open": o, "high": h, "low": lo,
                                                          "close": c, "volume": v}))
            days = ((dates.to_numpy().astype("datetime64[D]") - np.datetime64("1970-01-01")).astype(int)).tolist()
            M = PM.features(days, list(o), list(h), list(lo), list(c), list(v))
            for a_, b_ in pairs.items():
                x, y = M[a_], X[b_].to_numpy(float)
                nan_ok &= np.array_equal(np.isnan(x), np.isnan(y))
                worst = max(worst, float(np.nanmax(np.abs(x - y) / np.maximum(1, np.abs(y)))))
                n_cmp += int(np.isfinite(y).sum())
            # p2 the marks: the mirror on its own features = market_entries on production's (panel rows from 312)
            have = np.arange(len(c)) >= PM.WARMUP
            F = {}
            for f in PM.FEATS + ("d_atr_pct",):
                vv = np.where(have, X[pairs[f]].to_numpy(float), np.nan)
                F[f] = vv
                F[f + "_change"] = np.concatenate([[np.nan], vv[1:] - vv[:-1]])
            ent = S.market_entries(dates.to_numpy().astype("datetime64[D]"), o, c, F, S.atr_simple(h, lo, c), conds,
                                   have)
            mk = PM.marks(M, conds, list(o), list(c))
            mk_ok &= all(list(ent[s_]) == mk[s_] for s_ in conds)
            n_marks += sum(len(x) for x in mk.values())
            # tonight at every cut: FIRES -> marked the next session; ARMED -> marked iff the next open met the gap
            for t in range(PM.WARMUP + 2, len(c) - 1, 7):
                Mt = {k: x[:t] for k, x in M.items()}
                tn = PM.tonight(Mt, conds, list(o[:t]), list(c[:t]))
                for s_ in conds:
                    nxt = t in mk[s_]
                    if tn[s_] == "FIRES":
                        tn_ok &= nxt
                    elif tn[s_] == "ARMED":
                        tn_ok &= nxt == bool(o[t] < c[t - 1])
                    else:
                        tn_ok &= not nxt
                    n_tn += 1
    check("p1 the Pine's features (its bar-by-bar mirror) = production's features_daily on 3 stocks of 900 sessions: "
          "-DI 14 and its 5-day change, EMA20 angle, Bollinger width and %%b, the 13-week return of the last week, "
          "WorldQuant 16 / 40 / 44, ATR %%, RSI (%d values; largest relative difference %.1e)" % (n_cmp, worst),
          FX is not None and nan_ok and worst < 1e-9,
          "features_daily not importable: run the self-test after env_tradelab.bat (bigmove_deploy on PYTHONPATH)"
          if FX is None else (nan_ok, worst))
    check("p2 the Pine's marks = the whole-market engine on production's features (%d marks: the first qualifying open "
          "of every pseudo-pick past the 312-session warm-up); its next-open table = the next session's marks at %d "
          "cuts (FIRES -> marked; ARMED -> marked exactly when the open was below the close)" % (n_marks, n_tn),
          FX is not None and mk_ok and tn_ok and n_marks > 100, (mk_ok, tn_ok, n_marks))
    # ---- p3 the Pine file: its setups, dimensions, features and warm-up = the freeze, ZONE_DIMS and the mirror
    pine = (HERE.parent / "BigMove_Setups.pine").read_text(encoding="utf-8")
    line = lambda k: next(x for x in pine.splitlines() if x.startswith(k + " = ")).split(" = ", 1)[1].strip('"')
    want_s = "|".join("%s:%s" % (s_["id"], ",".join("%s%s%s" % (f, op, ("%g" % v)) for f, op, v in s_["conds"]))
                      for s_ in doc["setups"])
    want_d = "|".join("%s:%s" % (d_[0], "#%d" % len(d_[3]) if d_[2] is None else ",".join(repr(float(e)) if
                      float(e) != int(e) else "%g" % e for e in d_[2])) for d_ in S.ZONE_DIMS)
    lint = "not linted (pynescript and the playbook's pine_lint are not installed here)"
    lint_ok = True
    try:
        sys.path.insert(0, str(HERE.parent.parent / "playbook" / "tests"))
        import pine_lint as PL
        import pynescript  # noqa: F401
        IK = PL.INPUT_KW
        PL.NS |= {"request", "ta", "math", "str", "array"}
        PL.FUNCS.update({
            "indicator": {"title", "shorttitle", "overlay", "max_labels_count", "max_bars_back"},
            "input.time": IK, "input.text_area": IK, "input.string": IK | {"options"}, "input.bool": IK,
            "timestamp": set(), "math.floor": set(), "math.round": set(), "math.sqrt": set(), "math.atan": set(),
            "math.todegrees": set(), "array.insert": set(), "array.indexof": set(), "array.set": set(),
            "array.get": set(), "array.push": set(), "array.size": set(), "str.endswith": set(),
            "str.format": set(), "request.security": {"symbol", "timeframe", "expression", "gaps", "lookahead"},
            "ta.sma": {"source", "length"}})
        errs = PL.lint(pine)
        lint, lint_ok = ("linted: clean" if not errs else "lint: " + "; ".join(errs[:5])), not errs
    except ImportError:
        pass
    check("p3 BigMove_Setups.pine: its SETUPS line = FROZEN_SETUPS.json, its DIMS line = ZONE_DIMS, its features = "
          "the mirror's, warm-up 312, zone code tag %s; %s" % (S.PINE_CODE_TAG, lint),
          line("SETUPS") == want_s and line("DIMS") == want_d and line("FEATS") == ",".join(PM.FEATS) and
          line("WARMUP") == "312" and '"BMSZ1|S1=|S2=|S3=|C1=|C2=|C3=|N1="' in pine and lint_ok,
          (line("SETUPS") == want_s, line("DIMS"), want_d, lint))


def _pworld(effect, seed, years=6, per_day=6, until=None):
    """A pick table as runner_table makes it, two engines of independent picks. effect=True: every pick whose x rose
    on the signal day climbs ~1.2% a session (a runner, no dip) - only before `until` if given (a fading edge); all
    others (and every pick with effect=False) walk randomly."""
    rng = np.random.default_rng(seed)
    days = pd.bdate_range("2019-01-01", periods=int(years * 261)).to_numpy().astype("datetime64[D]")
    Ps = []
    for e in ("D", "ENS"):
        n = len(days) * per_day
        day = np.repeat(days, per_day)
        x, y = rng.normal(0, 1, n), rng.normal(0, 1, n)
        lr = rng.normal(0.0, 0.02, (n, 5))
        if effect:
            up = (x > 0) & ((day < np.datetime64(until)) if until else True)
            lr[up] = rng.normal(0.012, 0.01, (int(up.sum()), 5))
        O1 = np.full(n, 100.0)
        C = np.empty((n, 6))
        C[:, 1:] = 100.0 * np.exp(np.cumsum(lr, 1))
        gap = rng.normal(0, 1.0, n)
        C[:, 0] = O1 / (1 + gap / 100)
        O = np.full((n, 11), np.nan)
        O[:, 1], O[:, 2] = O1, C[:, 1] * (1 + rng.normal(0, 0.003, n))
        zv = {d: (rng.integers(0, len(lab), n).astype(float) if ed is None else rng.uniform(ed[0] - 1, ed[-1] + 1, n))
              for d, _, ed, lab in S.ZONE_DIMS}
        rank = np.tile(np.arange(1, per_day + 1), len(days)).astype(float)
        agree = rng.random(n) < 0.2
        d1 = np.busday_offset(day, 1, roll="forward")
        P = {"name": e, "ids": np.array(["%s%d" % (e, i) for i in range(n)]),
             "symbols": np.array(["S%d" % i for i in range(n)]), "day": day, "d5": day + 7, "rank": rank,
             "atr": np.full(n, 0.02), "O": O, "C": C, "H": C * 1.01, "L": C * 0.99, "gap_d1": gap,
             "weekday_d1": pd.DatetimeIndex(d1).weekday.to_numpy().astype(float), "agree": agree.astype(float),
             "agree3": (agree & (rank <= 3)).astype(float), "fc": {"x": x, "y": y},
             "fv": {"x": rng.normal(0, 1, n), "y": rng.normal(0, 1, n)}, "zv": zv, "zb": S.zone_buckets(zv),
             "snap": {"pre_env_code": rng.integers(0, 5, n).astype(float), "pre_vix_pct250": rng.random(n)}}
        P.update(S.runner_labels(O1, C, P["H"], P["L"], P["atr"]))
        Ps.append(S.run_index(P))
    return Ps


def t_v09():
    import io
    import tempfile
    from contextlib import redirect_stdout
    tmp = Path(tempfile.mkdtemp(prefix="sl_v09_"))
    # ---- r1 the labels by hand: a dip is a CLOSE on D1-D4 2% below the D1 open (D5's close is the exit, not a dip)
    C = np.array([[99, 99, 98.5, 101, 103, 106], [100, 99, 97.9, 105, 106, 107], [100, 100, 100, 100, 100, 97],
                  [100, 99, 99, 99, 99, 111]], float)
    L = C - 0.3
    L[2, 1:5], L[2, 5] = 99.7, 96.7
    lab = S.runner_labels(np.full(4, 100.0), C, C + 0.5, L, np.array([0.01, 0.01, 0.01, np.nan]))
    want = {"dip": [0, 1, 0, 0], "dip_low": [0, 1, 1, 0], "dip_atr": [1, 1, 0, 0], "rt5": [1, 1, 0, 1],
            "rt10": [0, 0, 0, 1], "runner": [1, 0, 0, 1]}
    got = {k: [int(v) for v in lab[k]] for k in want}
    check("r1 the labels by hand: a close 2% below the D1 open on D1-D4 = a dip (98.5 no, 97.9 yes; a D5 close of 97 "
          "is the exit, not a dip), the intraday low 2% below on D1-D5, 1 ATR below; the D5 close +5% / +10%; runner = "
          "no dip and +5%; net = D5 close / D1 open - 1 - 0.35",
          got == want and np.allclose(lab["net"], [5.65, 6.65, -3.35, 10.65]) and
          np.allclose(lab["mae"], [-1.8, -2.4, -3.3, -1.3]), (got, lab["net"], lab["mae"]))
    # ---- r2 the lift: net minus the day's mean over every pick - a rule that only finds good DAYS has no lift
    P = {"day": np.repeat(np.array(["2024-01-01", "2024-01-02"], "datetime64[D]"), 3),
         "net": np.array([1.0, 2.0, 3.0, 10.0, 10.0, 10.0])}
    S.run_index(P)
    P.update({"dip": np.zeros(6, bool), "runner": np.zeros(6, bool), "rt5": np.zeros(6, bool),
              "rt10": np.zeros(6, bool), "dip_low": np.zeros(6, bool), "mae": np.zeros(6)})
    ev = S.run_eval(S.Boot(P["day"], B=200), P, np.r_[False, False, False, True, True, True])
    check("r2 the lift = net minus the same day's mean over every pick (day 1: 1 / 2 / 3 -> -1 / 0 / +1); a rule that "
          "only picks the good day has net +10 but lift 0",
          np.allclose(P["lift"], [-1, 0, 1, 0, 0, 0]) and abs(ev["net"] - 10) < 1e-12 and abs(ev["lift"]) < 1e-12,
          (P["lift"], ev))
    rng = np.random.default_rng(5)
    x, y, wt = rng.integers(0, 6, 120).astype(float), rng.random(120) < 0.4, rng.integers(0, 3, (3, 120)).astype(float)
    bf = [sum(wt[b, i] * wt[b, j] * ((x[i] > x[j]) + 0.5 * (x[i] == x[j])) for i in np.flatnonzero(y)
              for j in np.flatnonzero(~y)) / (wt[b, y].sum() * wt[b, ~y].sum()) for b in range(3)]
    check("r2 the weighted AUC (what marks a runner) = the brute-force pair count with ties counted half, on 3 sets of "
          "day weights", np.allclose(S.wauc(x, y, wt), bf), (S.wauc(x, y, wt), bf))
    # ---- r3 the entries by hand
    O = np.full((4, 11), np.nan)
    O[:, 1], O[:, 2] = [101, 104, 100, 100], [102.9, 103, 103, 99]
    Cx = np.array([[100, 102.8, 103.5, 104, 105, 108], [101, 103.2, 103, 104, 105, 106],
                   [99, 101, 103.5, 104, 104, 105], [99, 99.5, 100, 100, 100, 101]], float)
    Hx = Cx + 0.5
    Hx[:, 0] = 102.0
    Hx[:, 1], Hx[:, 2] = [103, 105, 101.5, 101], [104, 104, 104, 102]
    Lx = Cx - 0.5
    Lx[:, 1] = [100.5, 103, 99, 99]
    E = S.run_events({"O": O, "C": Cx, "H": Hx, "L": Lx, "net": (Cx[:, 5] / O[:, 1] - 1) * 100 - S.COST})
    stop = 102 * 1.0005
    w1 = [(108 / stop - 1) * 100 - .35, (106 / 104 - 1) * 100 - .35, (105 / 103 - 1) * 100 - .35]
    check("r3 the entries by hand: the breakout fills at the stop (102.051 = the signal-day high + 0.05%) on D1, at "
          "the open when D1 gaps above it (104), on D2 at max(open, stop) (103), not at all when D1-D2 stay below; a "
          "strong D1 (green, close in the top 30% of its range) buys the D2 open / the D1 close; a red D1 "
          "does not",
          list(E["E1"][0]) == [True, True, True, False] and np.allclose(E["E1"][1][:3], w1) and
          list(E["E2"][0]) == [True, False, True, False] and list(E["E3"][0]) == [True, False, True, False] and
          np.allclose(E["E2"][1][[0, 2]], [(108 / 102.9 - 1) * 100 - .35, (105 / 103 - 1) * 100 - .35]) and
          np.allclose(E["E3"][1][[0, 2]], [(108 / 102.8 - 1) * 100 - .35, (105 / 101 - 1) * 100 - .35]),
          {k: (list(v[0]), v[1]) for k, v in E.items()})
    # ---- r4 the money sim by hand
    cal = np.arange(np.datetime64("2026-01-05"), np.datetime64("2026-01-10"))
    A = lambda *x: np.array(x)
    e1, n1, _ = S.run_sim(A(0), A(2), A(10.0), A(1.0), A("A"), 0, 4, cal, 2)
    e2, _, _ = S.run_sim(A(0), A(2), A(10.0), A(1.0), A("A"), 0, 4, cal, 2, lev=2)
    e3, n3, k3 = S.run_sim(A(0, 0, 0), A(1, 1, 1), A(0.0, 0.0, 100.0), A(1.0, 2.0, 3.0), A("A", "B", "C"), 0, 4, cal,
                           2)
    e4, n4, k4 = S.run_sim(A(0, 1, 2), A(1, 2, 3), A(0.0, 50.0, 0.0), A(1.0, 1.0, 1.0), A("A", "B", "C"), 0, 4, cal, 1)
    dd = S.run_book_stats(np.array([1.0, 0.5, 1.0]), 2, 0, 1.0)
    T = pd.DataFrame({"pick": ["p1", "p1", "p2", "p2"], "ent": [3, 1, 2, 2], "prio": [5.0, 9.0, 2.0, 1.0]})
    dk = S.run_dedupe(T)
    check("r4 the money sim by hand: +10% in one of 2 slots -> 1.05; MTF 2x -> 1 + 0.5 x (20% - 0.04% x 2 days) = "
          "1.0996; 3 at one open in 2 slots -> the worst priority skipped (its +100% never counts); a slot freed at a "
          "close is free at the NEXT open; the worst fall 50%; one position per pick = its earliest entry",
          abs(e1[-1] - 1.05) < 1e-12 and n1 == 1 and abs(e2[-1] - 1.0996) < 1e-12 and k3 == 1 and n3 == 2 and
          abs(e3[-1] - 1) < 1e-12 and n4 == 2 and k4 == 1 and abs(e4[-1] - 1) < 1e-12 and abs(dd["worst_fall"] - 50)
          < 1e-9 and sorted(zip(dk["pick"], dk["ent"], dk["prio"])) == [("p1", 1, 9.0), ("p2", 2, 1.0)],
          (e1[-1], e2[-1], e3[-1], k3, e4[-1], n4, k4, dd, dk.to_dict("records")))
    # ---- r5 the planted world: x rising on the signal day = a steady climb with no dip; found, qualified in both
    #      engines, it holds out of sample, and the anatomy names x; the absent world: none of it
    out5 = {}
    for kind, eff, seed, until in (("planted", True, 11, None), ("absent", False, 12, None),
                                   ("fading", True, 13, "2022-01-01")):
        Ps = _pworld(eff, seed, until=until)
        atoms = S.run_atoms(Ps[0])
        T, AMs = S.run_search(Ps, atoms)
        top = S.run_pick_top(T, AMs)
        WF, wfres = S.run_walk_forward(Ps, atoms, years=(2022, 2023, 2024))
        AN = S.run_anatomy(Ps, "runner", "runners", B=200)
        sh = AN[AN["shown"]]
        out5[kind] = {"top": ["+".join(atoms[i][0] for i in c) for c in top], "wf": {e: v["verdict"] for e, v in
                                                                                     wfres.items()},
                      "x_shown": "x (change on the signal day)" in set(sh["measure"]),
                      "x_dir": "".join(sh.loc[sh["measure"] == "x (change on the signal day)", "direction"]),
                      "shown": list(sh["measure"]), "wf_rules": list(WF.get("rules", [])),
                      "nodip": [float(100 - T.iloc[0]["%s_dip" % e]) for e in ("D", "ENS")] if len(T) else []}
    p_, a_, f_ = out5["planted"], out5["absent"], out5["fading"]
    check("r5 the planted world: 'x rose on the signal day' is the only candidate (narrower rules inside it do not "
          "earn their extra condition, however lucky in-sample), it qualifies in both engines with no dips, the replay chooses it every year and "
          "HOLDS in both engines; the anatomy shows x's change (higher -> more runners) and nothing else",
          p_["top"] and p_["top"][0] == "F|x>0" and len(p_["top"]) == 1 and min(p_["nodip"]) > 99 and
          p_["wf"] == {"D": "HOLDS", "ENS": "HOLDS"} and all(r == "F|x>0" for r in p_["wf_rules"]) and
          p_["x_shown"] and p_["x_dir"] == "higher -> more runners" and p_["shown"] == ["x (change on the signal day)"],
          p_)
    check("r5 the absent world (x is noise): no rule qualifies (%d candidates), the replay chooses none (%s), the "
          "anatomy shows nothing" % (len(a_["top"]), a_["wf"]),
          not a_["top"] and not any(v == "HOLDS" for v in a_["wf"].values()) and not a_["shown"], a_)
    check("r5 the fading world (x's edge stops in 2022): the replay chooses 'x rose' every year from the years before, "
          "and judges it on the year itself: %s - the replay catches an edge that does not last" % f_["wf"],
          len(f_["wf_rules"]) == 3 and all("F|x>0" in r.split("; ") for r in f_["wf_rules"]) and
          not any(v == "HOLDS" for v in f_["wf"].values()), f_)
    # ---- r6 the command end to end: the tag and zones runs of the planted live world, then runners
    w = live_world(tmp, "planted", seed=5, n_sess=48)
    out = tmp / "out"
    cf = tmp / "cols.txt"
    cf.write_text("\n".join(DAILY_F) + "\n")
    with redirect_stdout(io.StringIO()):
        rc_tag = S.main(["tag", "--data", str(w["data"]), "--features", str(w["panel"]), "--out", str(out)])
        a = type("A", (), {"frozen": None, "out": str(out), "features": str(w["panel"]), "picks_only": True,
                           "root": str(w["root"]), "stage_e_any": False, "data": str(w["data"]),
                           "columns_file": str(cf), "chunk": 8})()
        rc_z = S.cmd_zones(a, data=FakeZoneLive(w))
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = S.cmd_runners(a, data=FakeZoneLive(w))
    run = S.latest_run(out, "RUNNERS", [S.RUN_FILE])
    names = [S.RUN_FILE, "RUNNERS.md", "runner_finalists.csv", "runner_walk_forward.csv", "runner_anatomy.csv",
             "dip_anatomy.csv", "runner_events.csv", "runner_money.csv", "runner_picks.parquet"]
    try:
        S.read_hashed_run(run, names)
        hashed = True
    except (ValueError, OSError, TypeError):
        hashed = False
    rr, doc = S.load_runners(out)
    bad = json.loads((run / S.RUN_FILE).read_text())
    bad["rule"] += " (edited)"
    (run / S.RUN_FILE).write_text(json.dumps(bad))
    try:
        S.load_runners(out)
        tamper = False
    except ValueError:
        tamper = True
    (run / S.RUN_FILE).write_text(json.dumps(doc, indent=1))
    RP = pd.read_parquet(run / "runner_picks.parquet")
    wl = pd.read_parquet(w["data"] / "watchlist.parquet")
    jmap = {(t_, s_): int(np.flatnonzero(w["cal"] == np.datetime64(pd.Timestamp(d_).date(), "D"))[0])
            for t_, s_, d_ in zip(wl["trade_id"], wl["symbol"], wl["signal_day"])}
    hand_ok = True
    for r in RP.itertuples(index=False):
        j = jmap[(r.trade_id, r.symbol)]
        _, o, c = w["bars"][r.symbol]
        o1 = o[j + 1]
        dip = c[j + 1:j + 5].min() <= o1 * 0.98
        hand_ok &= (bool(r.dip) == dip and bool(r.runner) == (not dip and c[j + 5] >= o1 * 1.05) and
                    abs(r.net - ((c[j + 5] / o1 - 1) * 100 - 0.35)) < 1e-9 and
                    abs(r.gap_d1 - (o1 / c[j] - 1) * 100) < 1e-9)
    MO = pd.read_csv(run / "runner_money.csv")
    md = (run / "RUNNERS.md").read_text(encoding="utf-8")
    counts = doc["counts"]
    check("r6 the runners command end to end (planted live world after tag and zones): RUNNERS.md and 8 files, all "
          "hash-listed; RUNNER_CANDIDATES.json hash-checked (an edit is refused); every settled pick complete (%s); "
          "each of %d picks' dip / runner / net / gap = its own bars by hand; the money view has the plan and the dip "
          "arm (from the ZONES run)" % ("; ".join("%s %d of %d" % (e, v["complete"], v["settled"])
                                                  for e, v in counts.items()), len(RP)),
          rc_tag == 0 and rc_z == 0 and rc == 0 and "RUNNERS WRITTEN" in buf.getvalue() and hashed and rr == run and
          tamper and all(v["complete"] == v["settled"] > 0 for v in counts.values()) and len(RP) > 100 and hand_ok
          and {"plan: ranks 1-3 at the D1 open", "dip arm: all 7 setups (in-zone first)"} <= set(MO["book"]) and
          "ZONES_" in doc["dip_arm"] and all(s_ in md for s_ in ("## Verdict", "## The year-by-year replay",
                                                                 "## Entries", "## Money")),
          (rc_tag, rc_z, rc, hashed, tamper, counts, hand_ok, sorted(set(MO["book"])), doc.get("dip_arm"),
           buf.getvalue()[-600:]))
    # ---- r7 point in time and the zone values: three picks of a 900-session stock - run_bars' zone values = the
    #      stock's own at the signal close (all 12, none blank), and rewriting the bars after each signal day moves its
    #      D1-D5 prices, never its zone values
    dates, o, h, lo, c, v = _syn_stock(4)
    dates = dates.to_numpy().astype("datetime64[D]")
    Mz = S.market_dims({k: _idx_series(20 + i) for i, (k, _) in enumerate(S.ZONE_INDEX)})
    js = np.array([600, 700, 800])
    bk = type("B", (), {"n": 3, "signal_day": dates[js], "symbols": np.array(["ZZ"] * 3)})()
    feed = lambda bars: (lambda syms: {s_: bars for s_ in syms if s_ == "ZZ"})
    b0 = S.run_bars(bk, feed((dates, o, h, lo, c, v)), lambda s_: None, Mz)
    zz = S.zone_values(dates, o, h, lo, c, v, Mz)
    hand = all(np.isfinite(b0["Z"][k]).all() and np.allclose(b0["Z"][k], zz[k][js]) for k in b0["Z"]) and \
        len(b0["Z"]) == 12
    same, moved = True, True
    for i, j0 in enumerate(js):
        o2, h2, l2, c2 = (x.copy() for x in (o, h, lo, c))
        for x in (o2, h2, l2, c2):
            x[j0 + 1:] *= 1.5
        b1 = S.run_bars(bk, feed((dates, o2, h2, l2, c2, v)), lambda s_: None, Mz)
        same &= all(b1["Z"][k][i] == b0["Z"][k][i] for k in b0["Z"])
        moved &= bool(np.allclose(b1["Cb"][i, 1:], b0["Cb"][i, 1:] * 1.5) and b1["Cb"][i, 0] == b0["Cb"][i, 0])
    check("r7 point in time: run_bars' 12 zone values = the stock's own at the signal close (3 picks of a 900-session "
          "stock, none blank); rewriting the bars after each signal day (x1.5) moves its D1-D5 prices, never its zone "
          "values", hand and same and moved, (hand, same, moved))


def _ndworld(effect, seed, until=None, years=6, K=8, drift=(0.012, 0.008)):
    """Two engines' pick tables as nd_engine makes them, from one pool of K stock-days a day: D takes candidates 0-5
    (ranks 1-6), ENS candidates 2-7 (ranks 1-6), so 4 a day are picked by both. effect=True: a stock-day with x in its
    high third AND y turned up (fell the session before the pick, rose on the signal day) climbs ~1.2% a session with
    no dip - only before `until` if given; everything else walks randomly."""
    rng = np.random.default_rng(seed)
    cal = pd.bdate_range("2019-01-01", periods=int(years * 261) + 10).to_numpy().astype("datetime64[D]")
    nd_ = int(years * 261)
    n = nd_ * K
    di = np.repeat(np.arange(nd_), K)
    day = cal[di]
    x, y = rng.normal(0, 1, n), rng.normal(0, 1, n)
    cx, cy, cx1, cy1 = (rng.normal(0, 1, n) for _ in range(4))
    up = (x > 0.4307) & (cy1 < 0) & (cy > 0)
    if until:
        up &= day < np.datetime64(until)
    lr = rng.normal(0.0, 0.02, (n, 5))
    if effect:
        lr[up] = rng.normal(drift[0], drift[1], (int(up.sum()), 5))
    C = np.empty((n, 6))
    C[:, 1:] = 100.0 * np.exp(np.cumsum(lr, 1))
    gap = rng.normal(0, 1.0, n)
    C[:, 0] = 100.0 / (1 + gap / 100)
    O = np.full((n, 11), np.nan)
    O[:, 1], O[:, 2] = 100.0, C[:, 1] * (1 + rng.normal(0, 0.003, n))
    zv = {d: (rng.integers(0, len(lab), n).astype(float) if ed is None else rng.uniform(ed[0] - 1, ed[-1] + 1, n))
          for d, _, ed, lab in S.ZONE_DIMS}
    px = {"body0": rng.normal(0, 1, n), "pos0": rng.random(n), "gap0": rng.normal(0, 1, n), "ret1": rng.normal(0, 2, n),
          "ret3": rng.normal(0, 3, n), "run": rng.choice([-2.0, 0.0, 2.0], n)}
    ent = di + 1
    base = {"day": day, "d1": cal[ent], "d5": cal[ent + 4], "ent": ent.astype(np.int64), "ex": (ent + 4).astype(np.int64),
            "symbols": np.array(["S%d" % i for i in range(n)], dtype=object), "atr": np.full(n, 0.02), "O": O, "C": C,
            "H": C * 1.01, "L": C * 0.99, "gap_d1": gap,
            "weekday_d1": pd.DatetimeIndex(cal[ent]).weekday.to_numpy().astype(float),
            "fv": {"x": x, "y": y}, "fc": {"x": cx, "y": cy}, "fcp": {"x": cx1, "y": cy1},
            "fvp": {"x": x - cx, "y": rng.normal(0, 1, n)}, "zv": zv, "zb": S.zone_buckets(zv), "px": px,
            "snap": {"pre_env_code": rng.integers(0, 5, n).astype(float), "pre_vix_pct250": rng.random(n)}}
    base.update(S.runner_labels(np.full(n, 100.0), C, C * 1.01, C * 0.99, base["atr"]))
    j = np.tile(np.arange(K), nd_)
    Es = []
    for e, lo, hi in (("D", 0, 5), ("ENS", 2, 7)):
        m = (j >= lo) & (j <= hi)
        E = S.run_sub(base, m)
        E.update({"name": e, "ids": np.array(["%s%d" % (e, i) for i in range(int(m.sum()))]),
                  "rank": (j[m] - lo + 1).astype(float), "counts": {}})
        Es.append(E)
    for E, F in ((Es[0], Es[1]), (Es[1], Es[0])):
        other = set(F["symbols"])
        E["agree"] = np.array([s_ in other for s_ in E["symbols"]], float)
        E["agree3"] = np.zeros(len(E["net"]))
    return [S.nd_engine(E) for E in Es], cal


def t_v10():
    import io
    import tempfile
    from contextlib import redirect_stdout
    tmp = Path(tempfile.mkdtemp(prefix="sl_v10_"))
    # ---- n1 pooling: a stock-day picked by both engines counts once, with its best rank
    Es, cal = _ndworld(False, 21, years=2)
    U = S.nd_pool(Es)
    kD, kE = dict(zip(Es[0]["key"], Es[0]["rank"])), dict(zip(Es[1]["key"], Es[1]["rank"]))
    shared = set(kD) & set(kE)
    ok_rank = all(U["rank"][i] == min(kD.get(k, 99), kE.get(k, 99)) for i, k in enumerate(U["key"]))
    ok_ag = all((U["agree"][i] == 1) == (k in shared) for i, k in enumerate(U["key"])) and \
        all((U["agree3"][i] == 1) == (k in shared and kD[k] <= 3 and kE[k] <= 3) for i, k in enumerate(U["key"]))
    check("n1 pooling: %d D + %d ENS picks -> %d stock-days (%d picked by both, counted once), each with its best rank; "
          "'both engines' and 'both in their ranks 1-3' by hand" % (len(kD), len(kE), len(U["key"]), len(shared)),
          len(U["key"]) == len(set(kD) | set(kE)) == len(set(U["key"])) and ok_rank and ok_ag and
          int(U["agree"].sum()) == len(shared), (len(U["key"]), len(shared), ok_rank, ok_ag))
    # ---- n2 the conditions by hand: levels by the reference picks' thirds and halves, the moves, the patterns
    spec = S.nd_atoms(U)
    at = {a[0]: a for a in S.nd_resolve(spec, U)}
    xv = U["fv"]["x"]
    q = np.quantile(xv, [1 / 3, 0.5, 2 / 3])
    m = lambda aid: S.nd_mask(at[aid][2], U)
    cy, cy1 = U["fc"]["y"], U["fcp"]["y"]
    check("n2 the conditions by hand: x's low / high third and lower / upper half = the reference picks' quantiles; "
          "y rose / fell on the signal day and on the session before; the four patterns (rose twice, fell twice, "
          "turned up, turned down); a candle condition",
          np.array_equal(m("V|x:L3"), xv <= q[0]) and np.array_equal(m("V|x:H3"), xv > q[2]) and
          np.array_equal(m("V|x:LO"), xv <= q[1]) and np.array_equal(m("V|x:HI"), xv > q[1]) and
          np.array_equal(m("B|y:up0"), cy > 0) and np.array_equal(m("B|y:dn1"), cy1 < 0) and
          np.array_equal(m("B|y:upup"), (cy1 > 0) & (cy > 0)) and np.array_equal(m("B|y:dndn"), (cy1 < 0) & (cy < 0))
          and np.array_equal(m("B|y:dnup"), (cy1 < 0) & (cy > 0)) and np.array_equal(m("B|y:updn"), (cy1 > 0) & (cy < 0))
          and np.array_equal(m("X|top3rd"), U["px"]["pos0"] >= 2 / 3), sorted(at)[:6])
    # ---- n3 the three worlds
    out3 = {}
    for kind, eff, seed, until in (("planted", True, 31, None), ("absent", False, 32, None),
                                   ("fading", True, 33, "2022-01-01")):
        Es, cal = _ndworld(eff, seed, until=until)
        U = S.nd_pool(Es)
        spec = S.nd_atoms(U)
        atoms = S.nd_resolve(spec, U)
        tables, AM, _ = S.nd_search(U, atoms, Es)
        top = {t: S.run_pick_top(tables[t], [AM]) for t in S.ND_LISTS}
        WF, ver, sel, RR = S.nd_walk_forward(U, Es, spec, years=(2022, 2023, 2024))
        ev0 = S.nd_evidence(U, AM, top["nodip"][0], "nodip", RR, " & ".join(atoms[i][0] for i in top["nodip"][0])) \
            if top["nodip"] else {}
        T = tables["nodip"]
        r0 = T.iloc[0] if len(T) else None
        tr = S.nd_index(S.run_sub(U, U["d5"] < np.datetime64("2022-01-01")))
        qx = np.quantile(tr["fv"]["x"], 2 / 3)
        conds22 = json.loads(WF.loc[WF["year"] == 2022, "nodip_conds"].iloc[0]) if "nodip_conds" in WF else []
        cut_ok = any(cc[0] == "fv" and cc[1] == "x" and cc[2] == qx for rule in conds22 for cc in rule)
        tops_in = {t: (S._union(AM, top[t], len(U["net"])), top[t], [], []) for t in S.ND_LISTS}
        Mo = S.run_money(S.nd_books(Es[0], tops_in, sel, U, None), cal)
        g = lambda b: Mo[(Mo["book"] == b) & (Mo["slots"] == 3) & (Mo["mtf"] == "none")]["cagr"]
        out3[kind] = {"nodip_top": ["+".join(atoms[i][0] for i in c) for c in top["nodip"]],
                      "verdicts": {t: v["verdict"] for t, v in ver.items()},
                      "r0": None if r0 is None else (r0["rule"], bool(r0["qualifies"]), round(float(r0["nodip"]), 3)),
                      "wf_rules": list(WF.get("nodip_rules", [])), "cut_ok": cut_ok, "ev0": ev0,
                      "oos_before_2022": int((sel["nodip"] & (U["day"] < np.datetime64("2022-01-01"))).sum()),
                      "oos_nodip": float(U["nodip"][sel["nodip"]].mean()) if sel["nodip"].any() else np.nan,
                      "base_nodip": float(U["nodip"][U["day"] >= np.datetime64("2022-01-01")].mean()),
                      "cagr_base": float(g("baseline: ranks 1-3 at the D1 open").iloc[0]),
                      "cagr_oos": float(g("no-dip arm, out of sample").iloc[0]) if len(g("no-dip arm, out of sample"))
                      else np.nan}
    p_, a_, f_ = out3["planted"], out3["absent"], out3["fading"]
    uses_xy = lambda rule: any(p.split("|", 1)[1].split(":", 1)[0] in ("x", "y") for p in rule.split("+")
                               if p[:2] in ("V|", "B|"))
    check("n3 the planted world (x in its high third AND y turned up -> no dip): the no-dip list's FIRST candidate is "
          "exactly that pair and qualifies, beat all picks in every year, and its track record shows the replay chose "
          "it in 2022, 2023 and 2024 and it beat all picks each time; the other candidates are narrower variants that still use x or y (plain "
          "95%: no pure-noise rule makes the list); the replay puts the pair first every year with x's cut-off from the "
          "training years only (2022: the 2019-21 picks' 2/3 quantile), HOLDS, selects nothing before 2022, its picks "
          "avoid the dip far more often than all picks, and the out-of-sample arm beats the baseline (3 slots)",
          p_["nodip_top"][:1] == ["V|x:H3+B|y:dnup"] and all(uses_xy(r) for r in p_["nodip_top"]) and p_["r0"][1] and
          p_["r0"][2] > 0.95 and p_["verdicts"].get("nodip") == "HOLDS" and
          all(r.split("; ")[0] == "V|x:H3 & B|y:dnup" for r in p_["wf_rules"]) and len(p_["wf_rules"]) == 3 and
          p_["cut_ok"] and p_["oos_before_2022"] == 0 and p_["oos_nodip"] > p_["base_nodip"] + 0.15 and
          p_["cagr_oos"] > p_["cagr_base"] and p_["ev0"]["years_better"] == p_["ev0"]["years"] >= 5 and
          [x["year"] for x in p_["ev0"]["replay"]] == [2022, 2023, 2024] and
          all(x["diff"] > 0.3 for x in p_["ev0"]["replay"]), p_)
    check("n3 the absent world: no list has a candidate and no replay verdict HOLDS (%s)" % a_["verdicts"],
          not a_["nodip_top"] and not any(v == "HOLDS" for v in a_["verdicts"].values()), a_)
    check("n3 the fading world (the edge stops in 2022): the replay still chooses the pair from the years before, and "
          "out of sample it does not hold (%s)" % f_["verdicts"].get("nodip"),
          any("V|x:H3 & B|y:dnup" in r for r in f_["wf_rules"]) and f_["verdicts"].get("nodip") != "HOLDS", f_)
    # ---- n3 a moderate edge (+0.4% a session, noise 2%): lucky narrower rules can beat the true pair on the score;
    #      every condition earning its place is what keeps the true pair first
    Es, cal = _ndworld(True, 41, drift=(0.004, 0.02))
    U = S.nd_pool(Es)
    atoms = S.nd_resolve(S.nd_atoms(U), U)
    tables, AM, _ = S.nd_search(U, atoms, Es)
    topm = ["+".join(atoms[i][0] for i in c) for c in S.run_pick_top(tables["nodip"], [AM])]
    check("n3 a moderate edge (no dip 66% vs 57%): the no-dip list's first candidate is still exactly the planted pair "
          "(without the earn-its-place test a lucky triple or a noise rule takes first place)",
          topm[:1] == ["V|x:H3+B|y:dnup"], topm)
    # ---- n4 the session before the pick and the candles into it, from the panel and the bars by hand
    w = live_world(tmp, "planted", seed=6, n_sess=48)
    with redirect_stdout(io.StringIO()):
        b0 = S.load(w["data"], w["panel"], None, DAILY_F, None)
        b1 = S.load(w["data"], w["panel"], None, DAILY_F, None, prev=True)
    fz = FakeZoneLive(w)
    Mz = S.market_dims(fz.index_closes(dict(S.ZONE_INDEX)))
    bars = S.run_bars(b1, fz.ohlcv, fz.forget, Mz, before=S.ND_BEFORE)
    m = b1.engine_arr == "D"
    sub = {"H": bars["H"][m], "L": bars["L"][m], "Cb": bars["Cb"][m], "Ob": bars["Ob"][m], "before": S.ND_BEFORE,
           "Z": {k: v[m] for k, v in bars["Z"].items()}}
    E = S.runner_table(b1.take(m, "D"), sub, {}, "D")
    pan = pd.read_parquet(w["panel"])
    pan["date"] = pd.to_datetime(pan[[c for c in pan.columns if c in ("date", "timestamp")][0]]).dt.normalize()
    f0 = DAILY_F[0]
    same_d0 = all(np.array_equal(b0.F[c][:, 1:], b1.F[c][:, 1:], equal_nan=True) for c in b0.F)
    prev_ok, px_ok = True, True
    for i in range(0, len(E["net"]), 7):
        sym, sd = E["symbols"][i], E["day"][i]
        j = int(np.flatnonzero(w["cal"] == sd)[0])
        g = pan[pan["symbol"] == sym].set_index("date")[f0]
        v1, v2 = g.get(pd.Timestamp(w["cal"][j - 1])), g.get(pd.Timestamp(w["cal"][j - 2]))
        prev_ok &= abs(E["fvp"][f0][i] - v1) < 1e-9 and abs(E["fcp"][f0][i] - (v1 - v2)) < 1e-9
        _, o, c = w["bars"][sym]
        h, l = _hl(o, c)
        px_ok &= (abs(E["px"]["ret3"][i] - (c[j] / c[j - 3] - 1) * 100) < 1e-9 and
                  abs(E["px"]["gap0"][i] - (o[j] / c[j - 1] - 1) * 100) < 1e-9 and
                  abs(E["px"]["pos0"][i] - (c[j] - l[j]) / (h[j] - l[j])) < 1e-9 and
                  E["px"]["run"][i] == (2.0 if c[j] > c[j - 1] > c[j - 2] else -2.0 if c[j] < c[j - 1] < c[j - 2]
                                        else 0.0))
    check("n4 the session before the pick = the panel's value and change on that session (by hand); the signal-day "
          "values are unchanged by reading it; the candles into the pick (3-session move, signal-day gap, close in its "
          "range, two closes in a row) = the stock's own bars by hand", same_d0 and prev_ok and px_ok,
          (same_d0, prev_ok, px_ok))
    # ---- n5 the command end to end (after tag and zones)
    out = tmp / "out"
    cf = tmp / "cols.txt"
    cf.write_text("\n".join(DAILY_F) + "\n")
    with redirect_stdout(io.StringIO()):
        rc_t = S.main(["tag", "--data", str(w["data"]), "--features", str(w["panel"]), "--out", str(out)])
        a = type("A", (), {"frozen": None, "out": str(out), "features": str(w["panel"]), "picks_only": True,
                           "root": str(w["root"]), "stage_e_any": False, "data": str(w["data"]),
                           "columns_file": str(cf), "chunk": 8})()
        rc_z = S.cmd_zones(a, data=FakeZoneLive(w))
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = S.cmd_nodip(a, data=FakeZoneLive(w))
    run = S.latest_run(out, "NODIP", [S.ND_FILE])
    names = [S.ND_FILE, "NODIP.md", "nodip_finalists.csv", "nodip_stage1.csv", "nodip_walk_forward.csv",
             "nodip_why_pairs.csv", "nodip_events.csv", "nodip_money.csv", "nodip_table.parquet"]
    try:
        S.read_hashed_run(run, names)
        hashed = True
    except (ValueError, OSError, TypeError):
        hashed = False
    rr, doc = S.load_nodip(out)
    bad = json.loads((run / S.ND_FILE).read_text())
    bad["rule"] += " (edited)"
    (run / S.ND_FILE).write_text(json.dumps(bad))
    try:
        S.load_nodip(out)
        tamper = False
    except ValueError:
        tamper = True
    (run / S.ND_FILE).write_text(json.dumps(doc, indent=1))
    TB = pd.read_parquet(run / "nodip_table.parquet")
    hand = True
    for r in TB.itertuples(index=False):
        _, o, c = w["bars"][r.symbol]
        j = int(np.flatnonzero(w["cal"] == np.datetime64(pd.Timestamp(r.day).date(), "D"))[0])
        dip = c[j + 1:j + 5].min() <= o[j + 1] * 0.98
        hand &= (r.nodip == (0.0 if dip else 1.0) and abs(r.net - ((c[j + 5] / o[j + 1] - 1) * 100 - 0.35)) < 1e-4)
    md = (run / "NODIP.md").read_text(encoding="utf-8")
    MO = pd.read_csv(run / "nodip_money.csv")
    have_cols = all(any(k.startswith(p_) for k in TB.columns) for p_ in ("lvl:", "chg0:", "chg_prev:", "lvl_prev:",
                                                                         "px:", "zone:"))
    check("n5 the nodip command end to end (live world after tag and zones): NODIP.md and 8 files hash-listed; the "
          "candidates file hash-checked (an edit is refused); the pooled table carries every condition's input (levels, "
          "both sessions' moves, candles, zones) and each of its %d stock-days' no-dip label and net = its own bars by "
          "hand; the money view has the baseline" % len(TB),
          rc_t == 0 and rc_z == 0 and rc == 0 and "NODIP WRITTEN" in buf.getvalue() and hashed and rr == run and tamper
          and have_cols and hand and len(TB) > 100 and "baseline: ranks 1-3 at the D1 open" in set(MO["book"]) and
          all(s_ in md for s_ in ("## At a glance", "## The no-dip list", "## The year-by-year replay", "## Stage 1",
                                  "## Money in full")),
          (rc_t, rc_z, rc, hashed, tamper, have_cols, hand, len(TB), buf.getvalue()[-800:]))


# ======================================================================================== v1.1: the entry tree
def _tree_doc(cuts, ref=None):
    """A copy of TREE.json with other cut-offs (and history numbers), hashed like the real one (tests only)."""
    _, d = S.load_tree()
    d = json.loads(json.dumps(d))
    d.pop("sha256", None)
    d["lane"]["cutoffs"] = {str(k): float(v) for k, v in cuts.items()}
    if ref is not None:
        d["history_reference"] = ref
    d["sha256"] = S.frozen_hash(d)
    return d


def _named(Sx):
    return [{"setup": r.setup, "status": r.status, "trade_id": r.trade_id, "symbol": r.symbol,
             "watch_day": int(r.next_watch_day), "close_tonight": float(r.close_tonight),
             "rule_at_open": r.rule_at_open} for r in Sx[Sx.status.isin(["FIRES", "ARMED"])].itertuples()]


def t_v11():
    import datetime as dt
    import hashlib
    import io
    import tempfile
    from contextlib import redirect_stdout
    tmp = Path(tempfile.mkdtemp(prefix="sl_v11_"))
    # ---- tr1 the tree file and the ETF rule
    tp, tdoc = S.load_tree()
    bad = json.loads(tp.read_text(encoding="utf-8"))
    bad["lane"]["cutoffs"]["2026"] = 0.06
    (tmp / "bad_tree.json").write_text(json.dumps(bad), encoding="utf-8")
    try:
        S.load_tree(tmp / "bad_tree.json")
        refused = False
    except ValueError:
        refused = True
    (tmp / "etfroot" / "sectors").mkdir(parents=True)
    (tmp / "etfroot" / "sectors" / "eq_etfseclist.csv").write_text("Symbol,Underlying\nXYZFUND,gold\n", encoding="utf-8")
    listed = S.etf_list(tmp / "etfroot")
    e1 = S.tree_etf(["NIFTYBEES", "GOLDIETF", "SBIETF", "LIQUIDCASE", "SILVERADD", "RELIANCE", "XYZFUND", "M&M"], tdoc,
                    listed)
    e2 = S.tree_etf(["XYZFUND"], tdoc, None)
    (tmp / "noetf" / "sectors").mkdir(parents=True)
    (tmp / "noetf" / "sectors" / "eq_etfseclist.csv").write_text("Name\nA\n", encoding="utf-8")
    try:
        S.etf_list(tmp / "noetf")
        bad_list = False
    except ValueError:
        bad_list = True
    check("tr1 TREE.json: the declared 2021-2026 cut-offs, D and ENS ranks 1-3, 3 positions; a changed cut-off is "
          "refused. ETFs: the name rule (BEES / IETF / ETF endings), TREE.json's names (LIQUIDCASE, SILVERADD) and NSE's "
          "list when present (a file without a Symbol column is an error, no file = None); a stock is never one",
          refused and abs(tdoc["lane"]["cutoffs"]["2026"] - 0.05521984442292925) < 1e-15 and
          sorted(tdoc["lane"]["cutoffs"]) == [str(y) for y in range(2021, 2027)] and tdoc["positions_per_book"] == 3 and
          list(e1) == [True, True, True, True, True, False, True, False] and list(e2) == [False] and bad_list and
          S.etf_list(tmp / "nowhere") is None, (refused, list(e1), list(e2), bad_list))
    # ---- tr2 the cut-off and the lanes by hand
    rng = np.random.default_rng(3)
    sday = np.array(["2024-03-01"] * 300 + ["2025-06-02"] * 300, dtype="datetime64[D]")
    atr = rng.uniform(0.01, 0.09, 600)
    comp = np.ones(600, bool)
    comp[::7] = False
    v25, n25 = S.tree_cutoff(atr, sday, comp, 2025)
    ref = np.sort(atr[:300][comp[:300]])
    pos = (len(ref) - 1) * 2 / 3
    lo = int(np.floor(pos))
    hand = ref[lo] + (ref[lo + 1] - ref[lo]) * (pos - lo)
    v24, _ = S.tree_cutoff(atr, sday, comp, 2024)
    v_few, _ = S.tree_cutoff(atr[:50], sday[:50], comp[:50], 2025)
    lanes = S.tree_lanes(np.array([v25, v25 + 1e-9, np.nan, 0.01, 0.01]), np.array([2025, 2025, 2025, 2025, 2027]),
                         {2025: v25})
    tl = tmp / "cut_ledger.jsonl"
    S.ledger_append(tl, {"event": "cutoff", "year": 2027, "cutoff": 0.05})
    S.ledger_append(tl, {"event": "cutoff", "year": 2027, "cutoff": 0.07})
    S.ledger_append(tl, {"event": "cutoff", "year": 2026, "cutoff": 0.09})
    cc = S.tree_cutoffs(tdoc, tl)
    check("tr2 the cut-off = the 2/3 quantile of the complete picks before 1 January (by hand %.6f, %d picks); none "
          "from fewer than 100 or with no earlier picks; at the cut-off = CALM, above = JUMPY, no ATR = NO ATR, a year "
          "without one = NO CUT-OFF; a recorded cut-off adds a year (the first record wins) and never replaces a "
          "declared one" % (hand, len(ref)),
          abs(v25 - hand) < 1e-15 and n25 == len(ref) and np.isnan(v24) and np.isnan(v_few) and
          list(lanes) == ["CALM", "JUMPY", "NO ATR", "CALM", "NO CUT-OFF"] and cc[2027] == 0.05 and
          abs(cc[2026] - tdoc["lane"]["cutoffs"]["2026"]) < 1e-15, (v25, hand, list(lanes), cc))
    # ---- tr3 the tree by hand
    rows = []

    def pk(tid, eng, rk, day, i1, o1, sc, c5, lane, etf=False, su=None):
        r = {"trade_id": tid, "engine": eng, "rank": rk, "symbol": tid.split("-")[-1],
             "sday": np.datetime64(day, "D").astype("datetime64[ns]"), "i1": i1, "o1": o1, "sc": sc, "c5": c5,
             "lane": lane, "etf": etf, "su_id": "", "su_k": 0, "su_ent": -1, "su_ex": -1, "su_net": np.nan}
        if su:
            r.update(su_id=su[0], su_k=su[1], su_ent=i1 + su[1] - 1,
                     su_ex=(i1 + su[1] + 3) if su[0] == "N1" else i1 + 4, su_net=su[2])
        rows.append(r)
    pk("D1a-A", "D", 1, "2026-03-02", 10, 99.0, 100.0, 104.0, "CALM", su=("S1", 3, 2.5))
    pk("D1b-B", "D", 2, "2026-03-02", 10, 101.0, 100.0, 103.0, "CALM")
    pk("D1c-C", "D", 3, "2026-03-02", 10, 102.0, 100.0, 99.0, "CALM")
    pk("D2a-E", "D", 1, "2026-03-03", 11, 50.0, 49.0, 55.0, "JUMPY", su=("C3", 1, 1.2))
    pk("D2b-F", "D", 2, "2026-03-03", 11, 20.0, 19.0, 21.0, "CALM", etf=True)
    pk("D2c-G", "D", 3, "2026-03-03", 11, 30.0, 30.0, 33.0, "CALM")
    pk("E1a-H", "ENS", 1, "2026-03-02", 10, 99.0, 100.0, 101.0, "CALM", su=("S2", 1, 4.0))
    pk("E1b-I", "ENS", 2, "2026-03-02", 10, 10.0, 10.0, 9.0, "JUMPY", su=("N1", 2, -1.5))
    pk("E1c-J", "ENS", 3, "2026-03-02", 10, 10.0, 10.0, 9.0, "NO ATR")
    pk("E2a-K", "ENS", 1, "2026-03-03", 11, np.nan, 10.0, 11.0, "CALM", su=("S1", 3, 3.0))
    P = pd.DataFrame(rows)
    pl, Tt, Tb = S.tree_plan(P[S.TREE_COLS])
    got = {r.trade_id: (r.how, int(r.ent), int(r.ex), int(r.ek), round(float(r.net), 9)) for r in Tt.itertuples()}
    want = {"D1a-A": ("S1@D3", 12, 14, 3, 2.5), "D1b-B": ("open", 10, 14, 1, round((103 / 101 - 1) * 100 - 0.35, 9)),
            "D2a-E": ("C3@D1", 11, 15, 1, 1.2), "D2c-G": ("open", 11, 15, 1, round((33 / 30 - 1) * 100 - 0.35, 9)),
            "E1a-H": ("open", 10, 14, 1, round((101 / 99 - 1) * 100 - 0.35, 9)), "E1b-I": ("N1@D2", 11, 15, 2, -1.5)}
    acts = dict(zip(pl.trade_id, pl.action))
    P2 = P.copy()
    P2["o1"], P2["c5"], P2["su_ent"], P2["su_k"], P2["su_id"] = np.nan, np.nan, -1, 0, ""
    pl2, Tt2, Tb2 = S.tree_plan(P2[S.TREE_COLS], final=False)
    a2 = dict(zip(pl2.trade_id, pl2.action))
    check("tr3 the tree by hand: D buys only the best-ranked calm pick that opened at or above its close (rank 2 when "
          "rank 1 opened lower; an open equal to the close counts as up), the others only through their first setup (S1 "
          "at D3; jumpy C3 at D1), an ETF is skipped; ENS buys calm at the open (its own setup ignored), jumpy through "
          "N1 (exit 4 sessions after its entry), no ATR without a setup = skipped, a calm ENS pick without a D1 open takes no "
          "setup; the baseline = every non-ETF pick at "
          "the open; with tonight's opens unknown nothing is traded and D's calm picks are named with their close",
          got == want and acts["D1a-A"] == "WAIT: calm, opened lower -> S1@D3" and
          acts["D1c-C"] == "WAIT: calm, a better-ranked calm pick opened up -> no setup: skipped" and
          acts["D2b-F"] == "SKIP: ETF" and acts["E1c-J"] == "WAIT: no ATR -> no setup: skipped" and
          acts["E1a-H"] == "BUY AT OPEN (calm)" and acts["D2c-G"] == "BUY AT OPEN (calm, opened up)" and
          set(Tb.trade_id) == set(P.trade_id) - {"D2b-F", "E2a-K"} and len(Tt2) == 0 and len(Tb2) == 0 and
          a2["D1b-B"].startswith("CALM: buy at the open if it opens at or above 100.00") and
          a2["E1a-H"] == "BUY AT OPEN (calm)" and a2["E1b-I"] == "WAIT: jumpy (watching for a setup)", (got, acts, a2))
    # the first setup per pick by hand: the earliest fill, a tie by the freeze's order; N1's exit 4 sessions after its
    # own entry, the others at the D5 close
    fp_, fdoc_ = S.load_frozen()
    prim = {x["id"]: x["primary_exit"] for x in fdoc_["setups"]}
    nan = np.nan
    su_h = {"S1": ([1, 0, 1, 0], [3, nan, 4, nan], [1.0, nan, 2.0, nan]),
            "C3": ([1, 1, 0, 0], [3, 2, nan, nan], [5.0, 6.0, nan, nan]),
            "N1": ([0, 0, 1, 1], [nan, nan, 2, 5], [nan, nan, 7.0, 8.0])}
    sid, sk, sent, sex, snet = S.tree_first_setup(su_h, np.array([10, 20, 30, 40]), prim)
    check("tr3b the first setup by hand: S1 and C3 on the same day -> S1 (the freeze's order); N1 at D2 before S1 at "
          "D4 -> N1, its exit 4 sessions after its entry (D6); S1 / C3 exit at the D5 close",
          prim["N1"] == "fresh" and list(sid) == ["S1", "C3", "N1", "N1"] and list(sk) == [3, 2, 2, 5] and
          list(sent) == [12, 21, 31, 44] and list(sex) == [14, 24, 35, 48] and list(snet) == [1.0, 6.0, 7.0, 8.0],
          (list(sid), list(sk), list(sent), list(sex), list(snet), prim))
    # ---- tr4 the book by hand
    nP = 6
    O = np.full((nP, S.PATH + 1), np.nan)
    C = np.full((nP, S.PATH + 1), np.nan)
    i1 = np.array([1, 1, 1, 1, 5, 6])
    for r in range(nP):
        O[r, 1:] = 100.0
        C[r, 1:] = 100.0 + np.arange(1, S.PATH + 1) * (r + 1) * 0.1
    Tq = pd.DataFrame({"row": range(nP), "trade_id": ["t%d" % r for r in range(nP)], "rank": [1, 2, 3, 1, 1, 2],
                       "symbol": ["ZZZ", "BBB", "AAA", "ABB", "DDD", "EEE"], "ent": i1, "ex": i1 + 4, "ek": 1,
                       "net": [10.0, 20.0, -10.0, 5.0, 0.0, 2.0], "how": "open"})
    eqc, eqm, tk = S.tree_sim(Tq, np.arange(nP), O, C, i1, 0, 11)
    v5 = 1 + (0.10 + 0.05 + 0.20) / 3
    check("tr4 the book by hand: 3 positions; four buys on one open -> lower rank first, then the symbol (rank 1 ABB "
          "and ZZZ, then rank 2 BBB; rank 3 AAA skipped); a buy on the exit session is skipped (the position frees at the next open), the next "
          "session's is taken; each entry 1/3 of the closed value; marked = the positions at their own close",
          list(tk) == [3, 0, 1, 5] and abs(eqc[4] - 1.0) < 1e-12 and abs(eqc[5] - v5) < 1e-12 and
          abs(eqc[-1] - v5 * (1 + 0.02 / 3)) < 1e-12 and abs(eqm[2] - (1.002 + 1.008 + 1.004) / 3) < 1e-12,
          (list(tk), eqc[4:6], eqc[-1], eqm[2]))
    # ---- tr5 the history command on the planted world
    w = live_world(tmp, "planted", seed=5)
    fp, fdoc = S.load_frozen()
    conds, feats = S.frozen_conds(fdoc), S.frozen_features(fdoc)
    o5 = tmp / "o5"
    with redirect_stdout(io.StringIO()):
        S.main(["tag", "--data", str(w["data"]), "--features", str(w["panel"]), "--out", str(o5)])
    Wl = pd.read_parquet(w["data"] / "watchlist.parquet")
    cut = float(np.nanmedian(Wl["s_atr14"]))
    (tmp / "tree_w.json").write_text(json.dumps(_tree_doc({2026: cut}), indent=1), encoding="utf-8")
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = S.main(["tree", "--data", str(w["data"]), "--out", str(o5), "--tree", str(tmp / "tree_w.json"),
                     "--reruns", "10"])
    run = sorted((o5 / "TREE").glob("TREE_*"))[-1]
    Tg = pd.read_parquet(run / "tree_tags.parquet")
    js = json.loads((run / "TREE_RUN.json").read_text(encoding="utf-8"))
    hashes_ok = all(hashlib.sha256((run / ln.split("  ")[1]).read_bytes()).hexdigest() == ln.split("  ")[0]
                    for ln in (run / "outputs.sha256").read_text().splitlines())
    lanes_ok = all((ln == "NO ATR") if not np.isfinite(a) else (ln == ("JUMPY" if a > cut else "CALM"))
                   for a, ln in zip(Tg.s_atr14, Tg.lane))
    g3 = Tg[(Tg["rank"] <= 3) & Tg["complete"]]
    rule_ok, n_buy = True, 0
    for (e, d), g in g3.groupby(["engine", "signal_day"]):
        if e == "D":
            up = g[(g.lane == "CALM") & g.opened_up]
            b = g[g.action == "BUY AT OPEN (calm, opened up)"]
            rule_ok &= (len(b) == min(1, len(up))) and (len(b) == 0 or int(b["rank"].iloc[0]) == int(up["rank"].min()))
            n_buy += len(b)
        else:
            rule_ok &= bool((g.loc[g.lane == "CALM", "action"] == "BUY AT OPEN (calm)").all())
        for r in g[g.action.str.startswith("WAIT")].itertuples():
            rule_ok &= r.action.endswith("-> " + r.first_setup) if r.first_setup else \
                r.action.endswith("no setup: skipped")
    ref5 = {"window": js["window"]}
    for gname, v in js["books"].items():
        ref5[gname] = {"a_year_pct": v["a_year_pct"], "worst_fall_pct": v["worst_fall_pct"]}
    (tmp / "tree_w2.json").write_text(json.dumps(_tree_doc({2026: cut}, ref=ref5), indent=1), encoding="utf-8")
    buf2 = io.StringIO()
    with redirect_stdout(buf2):
        rc2 = S.main(["tree", "--data", str(w["data"]), "--out", str(o5), "--tree", str(tmp / "tree_w2.json"),
                      "--reruns", "10"])
    md = (run / "TREE.md").read_text(encoding="utf-8")
    check("tr5 the tree command on the planted world: tags for every pick (lanes = s_atr14 against the cut-off by "
          "hand), the tree's action on every complete ranks 1-3 pick by its rule (D: one buy a day, the best-ranked calm "
          "pick that opened up - %d; ENS: every calm pick; a waiting pick names its first setup or is skipped); TREE.md "
          "and the files hash-listed; DIFFERS against TREE.json's real history, RECONCILED against matching numbers"
          % n_buy, rc == 0 and "TREE WRITTEN" in buf.getvalue() and rc2 == 0 and "TREE RECONCILED" in buf2.getvalue()
          and hashes_ok and lanes_ok and rule_ok and n_buy > 5 and "## Money" in md and "## Year by year" in md and
          "reruns" in md, (rc, rc2, hashes_ok, lanes_ok, rule_ok, n_buy, buf.getvalue()[-300:]))
    # ---- tr6 the nightly tree, evening by evening, against the history on the same picks
    data = FakeLive(w["root"], w["cal"], w["bars"], w["panel"])
    L = S.read_paper_ledger(w["root"])
    lp = tmp / "fwd6.jsonl"
    out6 = tmp / "scan6"
    out6.mkdir()
    td_f = _tree_doc({2026: cut})
    early = dt.datetime(2020, 1, 1, tzinfo=S.IST)
    late_day = w["cal"][12]
    for T in w["cal"][3:]:
        Sx, _ = S.scan_day(T, fdoc, conds, feats, L, data, out6)
        S.ledger_append(lp, {"event": "scan", "scan_date": str(pd.Timestamp(T).date()), "on_time": True,
                             "named": _named(Sx)})
        F = S.forward_record(L, data, fdoc, conds, feats, lp, T, since="2026-01-01")
        now = dt.datetime(2031, 1, 1, tzinfo=S.IST) if T == late_day else early
        txt, rec = S.tree_evening(T, td_f, fdoc, L, data, Sx, F, out6, None, now=now, since="2026-01-01")
    Tlast = w["cal"][-1]
    tlp = out6 / "tree_ledger.jsonl"
    recs = [r for r in S.ledger_lines(tlp) if r.get("event") == "tree" and r.get("on_time")]
    F = S.forward_record(L, data, fdoc, conds, feats, lp, Tlast, since="2026-01-01")
    fw = S.tree_forward(recs, L, data, Tlast, F, fdoc, td_f, S.tree_cutoffs(td_f, tlp), None)
    hb = S.load(w["data"], None, None)
    Ph = S.tree_history_picks(hb, S.newest_tags(o5)[1], fdoc, td_f, {2026: cut})
    late_ids = {x["trade_id"] for r in S.ledger_lines(tlp) if not r.get("on_time") for x in r["picks"]}
    keep = (Ph["rank"] <= 3) & Ph["trade_id"].isin({x["trade_id"] for r in recs for x in r["picks"]})
    plh, Tth, Tbh = S.tree_plan(Ph[keep][S.TREE_COLS])
    lastd = np.datetime64(pd.Timestamp(Tlast).date(), "D")

    def as_set(T_, cal):
        T_ = T_[np.isfinite(T_["net"].to_numpy(float))]
        dd = pd.DatetimeIndex(np.asarray(cal)[T_["ex"].to_numpy(np.int64)]).to_numpy().astype("datetime64[D]")
        T_ = T_[dd <= lastd]
        return {(r.trade_id, r.how, str(pd.Timestamp(np.asarray(cal)[int(r.ent)]).date()), round(float(r.net), 9))
                for r in T_.itertuples()}
    fb = fw["book"]
    tb_csv = pd.read_csv(out6 / "tree_book.csv")
    csv_ok = (set(zip(tb_csv["book"], tb_csv["trade_id"])) == set(zip(fw["trades"]["book"], fw["trades"]["trade_id"]))
              and not (late_ids & set(tb_csv["trade_id"])))
    h_tree, f_tree = as_set(Tth, hb.cal), as_set(fw["cand_tree"], fb.cal)
    h_base, f_base = as_set(Tbh, hb.cal), as_set(fw["cand_base"], fb.cal)
    # the D orders each evening: the history's buy is the first in the named order that opened at or above its close
    hbuy = {r.trade_id for r in plh.itertuples() if r.action == "BUY AT OPEN (calm, opened up)"}
    ord_ok, n_ord = True, 0
    opens = dict(zip(Ph["trade_id"], Ph["o1"]))
    closes = dict(zip(Ph["trade_id"], Ph["sc"]))
    for r in recs:
        lst = r["orders"]["D_calm_in_rank_order"]
        first_up = next((t for t in lst if np.isfinite(opens.get(t, np.nan)) and opens[t] >= closes[t]), None)
        if first_up is not None:
            n_ord += 1
            ord_ok &= first_up in hbuy
        ord_ok &= not (set(lst) & hbuy - ({first_up} if first_up else set()))
    # the books themselves: the forward book's trades = the history trades run through the same book on the same days
    taken_ok = True
    for e in ("D", "ENS"):
        Xf = fw["books"]["%s tree" % e]["taken"]
        ids_f = set(Xf["trade_id"]) if len(Xf) else set()
        Th = Tth[(Tth["engine"] == e) & np.isfinite(Tth["net"].to_numpy(float))].reset_index(drop=True)
        s0d = pd.Timestamp(np.asarray(fb.cal)[fw["P"]["i1"].min()]).date()
        s0h = int(np.searchsorted(hb.cal, np.datetime64(s0d)))
        t1h = int(np.searchsorted(hb.cal, np.datetime64(pd.Timestamp(Tlast).date()), side="right")) - 1
        _, _, tkh = S.tree_sim(Th, Ph[keep].index.to_numpy(), hb.O, hb.C, hb.i1, s0h, t1h)
        taken_ok &= ids_f == set(Th.iloc[tkh]["trade_id"])
    # the setup buys each evening's record (= its page) named: every history setup trade was named the evening before
    # its open; a named setup that was the pick's first fill at that open is a history trade (or the calm buy there);
    # nothing is named for a pick already bought at an open or through an earlier setup
    hcal = np.asarray(hb.cal).astype("datetime64[D]")
    wcal = np.asarray(w["cal"]).astype("datetime64[D]")
    tt_of = {r.trade_id: (r.how, hcal[int(r.ent)]) for r in Tth.itertuples()}
    su_first = {r.trade_id: (r.su_id, hcal[int(r.su_ent)]) for r in Ph[keep].itertuples() if r.su_k > 0}
    by_eve = {r["scan_date"]: r for r in recs}
    named_ok, n_su, n_named, n_alt = True, 0, 0, 0
    for r in Tth.itertuples():
        if r.how == "open":
            continue
        j = int(np.searchsorted(wcal, hcal[int(r.ent)])) - 1
        if j < 0 or str(wcal[j]) not in by_eve:
            continue
        n_su += 1
        sb = {(x["trade_id"], x["setup"]) for x in by_eve[str(wcal[j])]["orders"]["setup_buys"]}
        named_ok &= (r.trade_id, r.how.split("@")[0]) in sb
    for eve, rr in by_eve.items():
        j = int(np.searchsorted(wcal, np.datetime64(eve)))
        if j + 1 >= len(wcal):
            continue
        nxt, ev = wcal[j + 1], wcal[j]
        sb = rr["orders"]["setup_buys"]
        n_alt += len(sb) - len({x["trade_id"] for x in sb})
        for x in sb:
            n_named += 1
            fs, h = su_first.get(x["trade_id"]), tt_of.get(x["trade_id"])
            named_ok &= not (fs is not None and fs[1] <= ev)
            if h is not None and h[0] == "open":
                named_ok &= h[1] > ev and (h[1] != nxt or x["unless_calm_buy"])
            if fs is not None and fs[0] == x["setup"] and fs[1] == nxt:
                named_ok &= h is not None and h[1] == nxt and (h[0].startswith(x["setup"] + "@") or
                                                              (x["unless_calm_buy"] and h[0] == "open"))
    check("tr6 the nightly tree, evening by evening (records on time, one evening LATE): the forward books' trades on "
          "the recorded picks = the history's (tree %d, baseline %d settled trades: the same stocks, how, entry day and "
          "net), the book takes the same trades as the history book on the same days, the D order named each evening "
          "leads to the history's buy (%d evenings), every setup trade was named the evening before (%d; %d setup rows "
          "named, %d alternatives on one stock) and nothing named for a pick already in, and the LATE evening's picks "
          "are in no forward book (the scan's own tree_book.csv included)" % (len(h_tree), len(h_base), n_ord, n_su, n_named, n_alt),
          len(h_tree) > 20 and h_tree == f_tree and h_base == f_base and taken_ok and ord_ok and n_ord > 5 and
          named_ok and n_su > 5 and
          late_ids and not (late_ids & set(fw["trades"]["trade_id"])) and csv_ok and
          not (late_ids & {t for t, *_ in f_tree}),
          (len(h_tree), len(f_tree), len(h_tree ^ f_tree), list(h_tree ^ f_tree)[:4], len(h_base ^ f_base), taken_ok,
           ord_ok, n_ord, named_ok, n_su, n_named))
    # ---- tr7 the absent world: no setup ever fires; opens gap up
    a = live_world(tmp, "absent", seed=6)
    o7 = tmp / "o7"
    with redirect_stdout(io.StringIO()):
        S.main(["tag", "--data", str(a["data"]), "--features", str(a["panel"]), "--out", str(o7)])
    Wa = pd.read_parquet(a["data"] / "watchlist.parquet")
    cut_a = float(np.nanmedian(Wa["s_atr14"]))
    (tmp / "tree_a.json").write_text(json.dumps(_tree_doc({2026: cut_a}), indent=1), encoding="utf-8")
    with redirect_stdout(io.StringIO()):
        rc7 = S.main(["tree", "--data", str(a["data"]), "--out", str(o7), "--tree", str(tmp / "tree_a.json"),
                      "--reruns", "5"])
    Ta = pd.read_parquet(sorted((o7 / "TREE").glob("TREE_*"))[-1] / "tree_tags.parquet")
    a3 = Ta[(Ta["rank"] <= 3) & Ta["complete"]]
    dD = int(a3[a3.engine == "D"].assign(c_=lambda x: x.lane == "CALM").groupby("signal_day")["c_"].any().sum())
    check("tr7 the absent world (no setup can fire, every open gaps up): D buys the best-ranked calm pick every day "
          "that has one (%d), ENS every calm pick; every jumpy pick is skipped; no pick waits for a setup that came"
          % dD, rc7 == 0 and int((a3.action == "BUY AT OPEN (calm, opened up)").sum()) == dD and dD > 5 and
          bool((a3.loc[(a3.engine == "ENS") & (a3.lane == "CALM"), "action"] == "BUY AT OPEN (calm)").all()) and
          bool(a3.loc[a3.lane == "JUMPY", "action"].str.endswith("no setup: skipped").all()) and
          a3.first_setup.eq("").all(), (rc7, dD, a3.action.value_counts().to_dict()))
    # ---- tr8 the scan command with the tree: the page, the CSV, one record an evening; no tree file = no section
    real, real_from = S.LiveData, S.TREE_FROM
    S.LiveData = lambda root, any_=False, panel="panel_live": FakeLive(w["root"], w["cal"], w["bars"], w["panel"])
    S.TREE_FROM = "2026-01-01"
    try:
        d = str(pd.Timestamp(w["cal"][20]).date())
        tag = d.replace("-", "")
        o8 = tmp / "o8"
        b1 = io.StringIO()
        with redirect_stdout(b1):
            r1 = S.main(["scan", "--root", str(w["root"]), "--out", str(o8), "--date", d, "--tree",
                         str(tmp / "tree_w.json")])
            r2 = S.main(["scan", "--root", str(w["root"]), "--out", str(o8), "--date", d, "--tree",
                         str(tmp / "tree_w.json"), "--force"])
        page = (o8 / "scan" / ("SCAN_%s.md" % tag)).read_text(encoding="utf-8")
        tcsv = pd.read_csv(o8 / "scan" / ("tree_%s.csv" % tag))
        trec = [r for r in S.ledger_lines(o8 / "scan" / "tree_ledger.jsonl") if r.get("event") == "tree"]
        o9 = tmp / "o9"
        b2 = io.StringIO()
        with redirect_stdout(b2):
            r3 = S.main(["scan", "--root", str(w["root"]), "--out", str(o9), "--date", d, "--tree",
                         str(tmp / "bad_tree.json")])
        page9 = (o9 / "scan" / ("SCAN_%s.md" % tag)).read_text(encoding="utf-8")
        # a year without a cut-off: no orders, the command to record it
        Sx, _ = S.scan_day(w["cal"][20], fdoc, conds, feats, L, data, tmp / "o10")
        txt10, rec10 = S.tree_evening(w["cal"][20], _tree_doc({2025: cut}), fdoc, L, data, Sx, None, tmp / "o10")
    finally:
        S.LiveData, S.TREE_FROM = real, real_from
    # --cutoff-year: recorded once, by hand, then refused; the scan reads it
    o11 = tmp / "o11"
    c1, c2 = io.StringIO(), io.StringIO()
    with redirect_stdout(c1):
        k1 = S.main(["tree", "--data", str(w["data"]), "--out", str(o11), "--tree", str(tmp / "tree_w.json"),
                     "--cutoff-year", "2027"])
    with redirect_stdout(c2):
        k2 = S.main(["tree", "--data", str(w["data"]), "--out", str(o11), "--tree", str(tmp / "tree_w.json"),
                     "--cutoff-year", "2027"])
    cmp_ = S.tree_complete(hb)
    hand27 = float(np.quantile(hb.atr[cmp_], 2 / 3))
    got27 = S.tree_cutoffs(_tree_doc({2026: cut}), o11 / "scan" / "tree_ledger.jsonl").get(2027)
    check("tr8 the scan with the tree: the page leads with the Tree section (both books, tonight's tags, the "
          "scoreboard), tree_<date>.csv has every pick of the evening, ONE tree record an evening (--force adds none); a "
          "changed tree file is refused and the scan still writes its page without a Tree section; a year without a "
          "cut-off names no orders and prints the command; --cutoff-year records the year's cut-off once (by hand "
          "%.6f) and refuses a second" % hand27,
          r1 == 0 and r2 == 0 and r3 == 0 and page.startswith("## Tree - orders for the next open") and
          "### D book" in page and "### ENS book" in page and "Tonight's tags" in page and "Scoreboard since" in page
          and "# Setup scan" in page and len(tcsv) == 5 and set(tcsv["lane"]) <= {"CALM", "JUMPY", "NO ATR"} and
          len(trec) == 1 and "tree NOT used" in b2.getvalue() and "## Tree" not in page9 and
          txt10.startswith("## Tree - NO ORDERS") and "--cutoff-year 2026" in txt10 and rec10 is None and
          k1 == 0 and "CUTOFF RECORDED 2027" in c1.getvalue() and k2 == 3 and "REFUSED" in c2.getvalue() and
          got27 is not None and abs(got27 - hand27) < 1e-15,
          (r1, r2, r3, page[:60], len(tcsv), len(trec), txt10[:40], k1, k2, got27, hand27))


def main():
    t0 = time.time()
    print("%s self-test" % S.VERSION)
    t_hand()
    t_space()
    t_worlds()
    t_confluence()
    t_build()
    t_v06()
    t_v07()
    t_v08()
    t_v09()
    t_v10()
    t_v11()
    print("%d checks, %d failed (%.0f s)" % (COUNT[0], len(FAILS), time.time() - t0))
    print("VERIFIED (%s)" % S.VERSION if not FAILS else "NOT VERIFIED")
    return 0 if not FAILS else 1


if __name__ == "__main__":
    sys.exit(main())
