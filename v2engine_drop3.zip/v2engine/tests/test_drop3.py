r"""test_drop3.py - drop 3 checks (cost model, money view, trailing exits, ledger, capture, architectures, the seal
and freeze, the real-data adapter on a fake production cache). Registered into test_v2's suite by bind()."""
import copy
import json
import os
import sys
import tempfile
import textwrap
import types
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent

import v2_arch as A  # noqa: E402
import v2_book2 as B  # noqa: E402
import v2_core as C  # noqa: E402
import v2_ctx as X  # noqa: E402
import v2_eval as E  # noqa: E402
import v2_lab as LB  # noqa: E402
import v2_money as M  # noqa: E402
from v2_families import Confirm  # noqa: E402
from v2_research import Budget, check_budget, fill_rate  # noqa: E402
from v2_stats import DayBoot  # noqa: E402

H = {}


def bind(mod):
    """test_v2 hands over its check / helpers (one RESULTS list whichever way the suite was started)."""
    for k in ("check", "raises", "defaults", "bars_on", "flat"):
        H[k] = getattr(mod, k)


def check(*a):
    H["check"](*a)


def reset():
    H["defaults"]()
    M.uninstall()
    C.set_exit_slip(0.0)


# stage E's cost code, VERBATIM from stage_e_execution.py v1.2 (sha16 158883f0af70728d), with a stub tick table
STAGE_E_COSTS = '''
import math
from dataclasses import dataclass
from typing import Dict, Optional
import numpy as np
CFG = {"engine": "D", "target": "label_oc_5", "n_per_day": 3, "hold": 5, "capital": 1000000,
       "sizing": "equal_tranche", "integer_shares": True, "reserve_depth": 20, "duplicates": True,
       "liquidity_cap_frac": 0.02, "costs": "zerodha_base", "stop_pct": None,
       "impact_k": {"zerodha_base": 0.5, "zerodha_stress": 1.0},
       "grid_n": [1, 2, 3, 5, 10], "grid_hold": [1, 2, 3, 5, 7, 10],
       "capital_sweep": [200000, 500000, 1000000, 2500000, 5000000, 10000000, 25000000, 50000000],
       "stops": [0.05, 0.08, 0.12], "random_seeds": 10, "boot_B": 2000, "boot_block": 10, "seed": 7}
STAT = {"stt": 0.001, "stamp_buy": 0.00015, "txn": 0.0000322, "sebi": 0.000001, "gst": 0.18, "dp": 15.93}
class SF:
    @staticmethod
    def tick_size(dates, prices):
        return np.full(len(prices), 0.05)
@dataclass(frozen=True)
class Scenario:
    name: str
    engine: str = "D"
    n: int = 3
    hold: int = 5
    capital: float = 1_000_000.0
    costs: str = "zerodha_base"
    integer_shares: bool = True
    liquidity_cap: Optional[float] = 0.02
    duplicates: bool = True
    stop: Optional[float] = None
    depth: int = 20
    random_seed: Optional[int] = None
    min_order_frac: Optional[float] = None
def primary_scenario() -> Scenario:
    return Scenario("PRIMARY", engine=CFG["engine"], n=CFG["n_per_day"], hold=CFG["hold"], capital=CFG["capital"],
                    costs=CFG["costs"], integer_shares=CFG["integer_shares"], liquidity_cap=CFG["liquidity_cap_frac"],
                    duplicates=CFG["duplicates"], stop=CFG["stop_pct"], depth=CFG["reserve_depth"])
def buy_costs(value: float, sc: Scenario) -> Dict[str, float]:
    if sc.costs == "flat35":
        return {"stt": 0.0, "stamp": 0.0, "txn": 0.0, "sebi": 0.0, "gst": 0.0}
    txn, sebi = value * STAT["txn"], value * STAT["sebi"]
    return {"stt": value * STAT["stt"], "stamp": value * STAT["stamp_buy"], "txn": txn, "sebi": sebi,
            "gst": STAT["gst"] * (txn + sebi)}
def sell_costs(value: float, sc: Scenario, dp_due: bool, buy_value: float) -> Dict[str, float]:
    if sc.costs == "flat35":
        return {"stt": 0.0, "txn": 0.0, "sebi": 0.0, "gst": 0.0, "dp": 0.0, "flat": 0.0035 * buy_value}
    txn, sebi = value * STAT["txn"], value * STAT["sebi"]
    return {"stt": value * STAT["stt"], "txn": txn, "sebi": sebi, "gst": STAT["gst"] * (txn + sebi),
            "dp": STAT["dp"] if dp_due else 0.0, "flat": 0.0}
def impact_frac(sc: Scenario, value: float, adv: float, vol: float) -> float:
    k = CFG["impact_k"].get(sc.costs, 0.0)
    if k <= 0 or not (np.isfinite(adv) and adv > 0 and np.isfinite(vol)):
        return 0.0
    return float(k * vol * math.sqrt(max(value, 0.0) / adv))
def tick_frac(sc: Scenario, date, price: float, side: str) -> float:
    ticks = {"zerodha_base": {"entry": 0, "exit": 1}, "zerodha_stress": {"entry": 1, "exit": 1}}.get(sc.costs, {})
    k = ticks.get(side, 0)
    if k == 0 or not (price > 0):
        return 0.0
    return float(k * SF.tick_size(np.array([date], dtype="datetime64[ns]"), np.array([price]))[0] / price)
'''


def stage_e_standin(mutate=None):
    m = types.ModuleType("stage_e_costs_standin")
    exec(textwrap.dedent(STAGE_E_COSTS), m.__dict__)
    if mutate:
        mutate(m)
    return m


# ---------------------------------------------------------------------------------------------- t23
def t23_costs():
    reset()
    cal = C.SessionCalendar([np.datetime64("2024-01-01") + np.timedelta64(k, "D") for k in range(30)])
    b = {"adv": np.full(30, 1e8), "vol20": np.full(30, 0.02)}
    cm = M.CostModel(cal.days)
    t = cm.trade(b, 10, 100.0, 15, 110.0)
    # by hand (independent arithmetic)
    v = 125000.0
    imp = 0.5 * 0.02 * (v / 1e8) ** 0.5
    f_in = 100.0 * (1 + imp)
    f_out = 110.0 * (1 - imp - 0.05 / 110.0)
    txn_b, sebi_b = v * 0.0000322, v * 0.000001
    bc = v * 0.001 + v * 0.00015 + txn_b + sebi_b + 0.18 * (txn_b + sebi_b)
    sv = v * f_out / f_in
    txn_s, sebi_s = sv * 0.0000322, sv * 0.000001
    sc = sv * 0.001 + txn_s + sebi_s + 0.18 * (txn_s + sebi_s) + 15.93
    want = (sv - sc - v - bc) / (v + bc)
    check("t23a fully net by hand: STT both sides, stamp, exchange, SEBI, GST, DP, sqrt impact both sides, exit tick",
          abs(t["net"] - want) < 1e-13 and abs(t["gross"] - 0.10) < 1e-15 and abs(t["cost_frac"] - (0.10 - want)) < 1e-13,
          (t, want))
    b2 = {"adv": np.full(30, 1e6), "vol20": np.full(30, 0.02)}
    t2 = cm.trade(b2, 10, 100.0, 15, 110.0)
    check("t23b the order is capped at 2% of ADV (impact and fees on the capped value)",
          abs(t2["value"] - 20000.0) < 1e-9 and t2["net"] < t["net"], t2)
    check("t23c the replica equals stage E's own cost functions (verbatim stand-in)",
          M.check_against_stage_e(stage_e_standin()))

    def bad_stat(m):
        m.STAT = dict(m.STAT, stt=0.0011)

    def bad_k(m):
        m.CFG = dict(m.CFG, impact_k={"zerodha_base": 0.6})
    check("t23d a stage E with other costs is refused (STT, impact k)",
          H["raises"](lambda: M.check_against_stage_e(stage_e_standin(bad_stat))) and
          H["raises"](lambda: M.check_against_stage_e(stage_e_standin(bad_k))))
    cmse = M.CostModel(cal.days, stage_e=stage_e_standin())
    t3 = cmse.trade(b, 10, 100.0, 15, 110.0)
    check("t23e stage E's functions and the replica give the same trade", abs(t3["net"] - t["net"]) < 1e-12, (t3, t))
    o, h, lo, c = H["flat"](cal)
    o[11], c[15] = 100.0, 104.0
    h[15] = 104.5
    bs, bb = H["bars_on"](cal, o, h, lo, c)
    M.prepare_bars(bb)
    M.install(cm)
    d = C.plan_detail(bb, cal, 10, "CLOSE5")
    check("t23f PLAN under the cost model: gross = raw exit / raw entry - 1, net from the model",
          abs(d["gross"] - 0.04) < 1e-12 and abs(d["net"] - cm.net(bb, 11, 100.0, 15, 104.0)) < 1e-15 and d["net"] < 0.04,
          d)
    reset()


# ---------------------------------------------------------------------------------------------- t24
def t24_money():
    reset()
    cal = C.SessionCalendar([np.datetime64("2024-01-01") + np.timedelta64(k, "D") for k in range(40)])
    o, h, lo, c = H["flat"](cal)
    bs = C.BarStore(cal)
    for s, px in (("AAA", 100.0), ("BBB", 250.0), ("THIN", 50.0)):
        n = cal.n
        rec = {"open": np.full(n, px), "high": np.full(n, px * 1.01), "low": np.full(n, px * 0.99),
               "close": np.full(n, px), "volume": np.full(n, 1e6)}
        bs.put_arrays(s, rec)
        bs[s]["adv"] = np.full(n, px * 1e6)
        bs[s]["vol20"] = np.full(n, 0.02)
    bs["THIN"]["adv"] = np.full(cal.n, np.nan)
    bs["BBB"]["close"][12:] = 275.0
    cm = M.CostModel(cal.days)
    trades = [{"sid": "a", "symbol": "AAA", "entry_idx": 10, "entry_raw": 100.0, "exit_idx": 15, "exit_raw": 100.0,
               "timing": "open"},
              {"sid": "b", "symbol": "BBB", "entry_idx": 10, "entry_raw": 250.0, "exit_idx": 20, "exit_raw": 275.0,
               "timing": "close"},
              {"sid": "t", "symbol": "THIN", "entry_idx": 11, "entry_raw": 50.0, "exit_idx": 14, "exit_raw": 50.0,
               "timing": "open"}]
    sim = M.simulate(cal, bs, trades, cm, capital=1e6, slots=8, t_lo=5, t_hi=30)
    per = 1e6 / 8
    imp_a = 0.5 * 0.02 * (per / 1e8) ** 0.5
    sh_a = int(per // (100.0 * (1 + imp_a)))
    done = {t["sid"]: t for t in sim["trades"]}
    check("t24a integer shares at equity / 8 (impact on the fill); no ADV -> not traded (NO_LIQ)",
          done["a"]["shares"] == sh_a and [s["why"] for s in sim["skipped"]] == ["NO_LIQ"], (done, sim["skipped"]))
    eq = sim["equity"]
    pf = M.perf(sim, cal.days)
    want_end = 1e6 + done["a"]["pnl"] + done["b"]["pnl"]
    check("t24b equity = cash + marked positions; the final equity = capital + every trade's rupee P&L",
          abs(eq[-1] - want_end) < 1e-6 and abs(pf["final_equity"] - want_end) < 1e-6 and pf["trades"] == 2, (eq[-1], want_end))
    check("t24c a flat round trip loses exactly its costs (fees + DP + impact + 1 exit tick)",
          done["a"]["pnl"] < 0 and abs(done["a"]["gross"]) < 1e-15 and done["a"]["ret"] > -0.006, done["a"])
    dd = pf["max_dd"]
    check("t24d max drawdown and utilisation are measured on the path", dd <= 0 and 0 < pf["utilisation"] < 1, pf)
    reset()


# ---------------------------------------------------------------------------------------------- t25
def t25_trailing():
    reset()
    C.set_cost(0.0035)
    cal = C.SessionCalendar([np.datetime64("2024-01-01") + np.timedelta64(k, "D") for k in range(90)])
    o, h, lo, c = H["flat"](cal)
    # entry at the open of 30 (100); closes rise to 103.5 at 31 (a completed close above +3% arms the trail)
    o2, h2, lo2, c2 = [x.copy() for x in (o, h, lo, c)]
    c2[30], h2[30] = 101.0, 101.5
    o2[31], c2[31], h2[31], lo2[31] = 101.0, 103.5, 104.0, 98.4      # 98.4 is below the would-be trail: not active yet
    o2[32], c2[32], h2[32], lo2[32] = 103.5, 104.0, 104.5, 103.0
    for k in range(33, 37):                                             # holds up above the trail to the base limit
        o2[k], c2[k], h2[k], lo2[k] = 104.0, 104.0, 104.5, 103.6
    bs2, b2 = H["bars_on"](cal, o2, h2, lo2, c2)
    a31 = b2["atr"][31]
    trail = max(95.0, 100.0 * 1.0035, 103.5 - 2.0 * a31)
    ex = C.run_exit(b2, cal, 30, 100.0, "open", C.X6_V1, stop=95.0)
    check("t25a V1: no stop is hit before the trail is active; after the base limit it sells at the open (as V0)",
          ex["exit_idx"] == 35 and ex["reason"] == "TIME" and ex["timing"] == "open", ex)
    o3, h3, lo3, c3 = [x.copy() for x in (o2, h2, lo2, c2)]
    lo3[32] = trail - 0.01
    bs3, b3 = H["bars_on"](cal, o3, h3, lo3, c3)
    trail3 = max(95.0, 100.0 * 1.0035, 103.5 - 2.0 * b3["atr"][31])
    ex3 = C.run_exit(b3, cal, 30, 100.0, "open", C.X6_V1, stop=95.0)
    check("t25b the trail acts from the session after the completed close, at the stop (sell-stop slippage 0 here)",
          ex3["exit_idx"] == 32 and ex3["reason"] == "TRAIL_STOP" and abs(ex3["exit_px"] - trail3) < 1e-12 and
          ex3["timing"] == "intraday", (ex3, trail3))
    o4, h4, lo4, c4 = [x.copy() for x in (o2, h2, lo2, c2)]
    o4[32], lo4[32], h4[32], c4[32] = trail3 - 2.0, trail3 - 3.0, trail3 - 1.0, trail3 - 2.5
    bs4, b4 = H["bars_on"](cal, o4, h4, lo4, c4)
    ex4 = C.run_exit(b4, cal, 30, 100.0, "open", C.X6_V1, stop=95.0)
    check("t25c a gap through the trail fills at the open, never at the stop", ex4["exit_idx"] == 32 and
          ex4["reason"] == "STOP_GAP" and abs(ex4["exit_px"] - (trail3 - 2.0)) < 1e-12, ex4)
    o5, h5, lo5, c5 = [x.copy() for x in (o, h, lo, c)]
    h5[31] = 104.0                                                      # an intraday high above +3%, close 100
    lo5[32] = 96.0
    bs5, b5 = H["bars_on"](cal, o5, h5, lo5, c5)
    ex5 = C.run_exit(b5, cal, 30, 100.0, "open", C.X6_V1, stop=95.0)
    check("t25d only a COMPLETED close above +3% arms the trail (an intraday high does not)",
          ex5["exit_idx"] == 35 and ex5["reason"] == "TIME", ex5)
    # V2: an armed trade is held past the base limit; never loosened: the stop only rises
    o6, h6, lo6, c6 = [x.copy() for x in (o2, h2, lo2, c2)]
    for k in range(33, 45):
        o6[k], c6[k], h6[k], lo6[k] = 104.0 + 0.3 * (k - 33), 104.3 + 0.3 * (k - 33), 104.8 + 0.3 * (k - 33), 103.8 + 0.3 * (k - 33)
    c6[40], lo6[40] = 104.0, 103.9                                       # a lower close: the stop must not fall
    bs6, b6 = H["bars_on"](cal, o6, h6, lo6, c6)

    def v2_stop_at(bb, upto):
        """The V2 stop in force during session `upto`, replayed from the closes (never lowered)."""
        hi_c, armed, stop = 100.0, False, 95.0
        for k in range(30, upto):
            hi_c = max(hi_c, c6[k])
            armed = armed or c6[k] > 103.0
            if armed:
                stop = max(stop, 100.0 * 1.0035, hi_c - 2.0 * bb["atr"][k])
        return stop
    lo6[41] = v2_stop_at(b6, 41) - 0.02          # under the stop held since session 39, above a stop lowered at 40
    bs6, b6 = H["bars_on"](cal, o6, h6, lo6, c6)
    ex6 = C.run_exit(b6, cal, 30, 100.0, "open", C.X6_V2, stop=95.0)
    check("t25e V2: a trade whose trail is active is held past the base limit; a lower close never lowers the stop "
          "(sold at session 41 on the stop held since 39)", ex6["exit_idx"] == 41 and ex6["reason"] == "TRAIL_STOP", ex6)
    ex6b = C.run_exit(b5, cal, 30, 100.0, "open", C.X6_V2, stop=95.0)
    check("t25f V2: a trade whose trail never activated leaves at the base limit", ex6b["exit_idx"] == 35 and
          ex6b["reason"] == "TIME", ex6b)
    # an independent replay of V2 session by session (stop checked first; decisions at the close act next session)
    hi_c, armed, stop, path, got = 100.0, False, 95.0, [], None
    for k in range(30, cal.n):
        path.append(stop)
        if k > 30 and o6[k] <= stop:
            got = (k, "STOP_GAP", o6[k])
            break
        if lo6[k] <= stop:
            got = (k, "TRAIL_STOP" if armed else "STOP", stop)
            break
        if k == 70:
            got = (k, "BACKSTOP", c6[k])
            break
        hi_c = max(hi_c, c6[k])
        armed = armed or c6[k] > 103.0
        if armed:
            stop = max(stop, 100.0 * 1.0035, hi_c - 2.0 * b6["atr"][k])
    check("t25g V2 matches an independent replay (exit session, reason, price) and its stop never falls",
          got is not None and ex6["exit_idx"] == got[0] and ex6["reason"] == got[1] and abs(ex6["exit_px"] - got[2]) < 1e-12
          and all(path[i + 1] >= path[i] for i in range(len(path) - 1)), (ex6, got))
    # the trail hangs under the HIGHEST close: closes just below the peak with a shrinking ATR raise it
    o7, h7, lo7, c7 = [x.copy() for x in (o, h, lo, c)]
    o7[31], h7[31], lo7[31], c7[31] = 100.5, 104.2, 100.4, 104.0
    for k in range(32, 50):
        o7[k], h7[k], lo7[k], c7[k] = 103.5, 103.6, 103.4, 103.5
    bs7, b7 = H["bars_on"](cal, o7, h7, lo7, c7)
    hi_c, stop = 100.0, 95.0
    for k in range(30, 41):
        hi_c = max(hi_c, c7[k])
        if hi_c > 103.0:
            stop = max(stop, 100.35, hi_c - 2.0 * b7["atr"][k])
    lo7[41] = stop - 0.01
    bs7, b7 = H["bars_on"](cal, o7, h7, lo7, c7)
    ex7 = C.run_exit(b7, cal, 30, 100.0, "open", C.X6_V2, stop=95.0)
    check("t25h the trail hangs 2 ATR under the highest close (a falling ATR lifts it even below the peak)",
          ex7["exit_idx"] == 41 and ex7["reason"] == "TRAIL_STOP" and abs(ex7["exit_px"] - stop) < 1e-12, (ex7, stop))
    reset()


# ---------------------------------------------------------------------------------------------- t26
def _w3(effect="context", n_days=700, n_sym=80, seed=3):
    from v2_world3 import make_world3
    return make_world3(effect, n_days=n_days, n_sym=n_sym, seed=seed)


def t26_ledger():
    reset()
    w = _w3("context", 600, 60, 4)
    cal, bars, reg = w["cal"], w["bars"], w["registry"]
    cm = M.CostModel(cal.days)
    M.install(cm)
    C.set_exit_slip(0.05)
    pool = LB.Pool(reg, engines=("D",), ranks=(1, 2, 3))
    fam = Confirm()
    from v2_families import SqueezeBurst, TurnAfterDip
    ok_all, budget_ok, served_ok = True, True, True
    details = {}
    runs = [(m, fam, p) for m in ("trigger", "open_at_arm", "open_T1", "plan") for p in (C.X1, C.X6_V1, C.X6_V2)
            if not (m == "plan" and p is not C.X1)]
    runs += [("trigger", SqueezeBurst(), C.X1), ("trigger", TurnAfterDip(), C.X6_V1)]
    for mode, fm, pol in runs:
        if True:
            bk = B.run_book2(cal, bars, pool, mode, fm if mode != "plan" else None, pol)
            led = bk["ledger"]
            sids = {s.sid for s in pool.active()}
            ok_all &= set(led) == sids and all(v["status"] in B.LEDGER for v in led.values())
            bad = check_budget(cal, bk["trades"], Budget())
            budget_ok &= not bad
            for k, t in enumerate(bk["trades"]):
                served_ok &= all(led[sid]["status"] in ("TRADED", "MERGED") and led[sid]["trade"] == k for sid in t["served"])
            details[(mode, fm.key if fm is not None else "", pol.name())] = B.ledger_counts(bk)
    seen = {k for d in details.values() for k, v in d.items() if v}
    check("t26a every selection has exactly one ledger line in every book (no-fill opportunities stay visible)",
          ok_all and {"TRADED", "NO_FILL", "NOT_ARMED", "INELIGIBLE", "NO_ROOM"} <= seen, (seen, details))
    check("t26b the budget holds in every book, cancelled extra fills included (2 a day, 6 in 5, 8 open, 1 a stock)",
          budget_ok)
    check("t26c every trade's served selections are TRADED / MERGED and point at it", served_ok)
    tr = B.run_book2(cal, bars, pool, "trigger", fam, C.X1)
    nf = [v for v in tr["ledger"].values() if v["status"] == "NO_FILL"]
    check("t26d NO_FILL lines carry their orders and why they failed",
          nf and all(v["orders"] > 0 and sum(v["fills"].values()) > 0 for v in nf), nf[:3])
    b2t = B.run_book2(cal, bars, pool, "open_T1", fam, C.X1)
    fin = B.finished(b2t)
    eq = all(abs(t["net"] - C.plan_detail(bars[t["symbol"]], cal, t["t_idx"], "OPEN6")["net"]) < 1e-12 and
             t["entry_idx"] == t["t_idx"] + 1 for t in fin) and len(fin) > 50
    check("t26e B2T x V0 is OPEN6: every finished trade buys T+1's open and sells T+6's open", eq)
    b2a = B.run_book2(cal, bars, pool, "open_at_arm", fam, C.X1)
    timing = all(t["entry_idx"] == t["arm_idx"] + 1 and
                 fam.arm(bars[t["symbol"]], cal, reg.by_sid[t["sid"]], t["arm_idx"]) is not None for t in b2a["trades"])
    check("t26f B2a acts at the open after a close where the family armed (the same information)", timing)
    poolx = LB.Pool(reg, engines=("D",), ranks=(1, 2, 3), exclude=lambda s: s.snap()["pm_prob_trap"] >= 0.10)
    bx = B.run_book2(cal, bars, poolx, "trigger", fam, C.X1)
    nx = sum(1 for v in bx["ledger"].values() if v["status"] == "EXCLUDED")
    check("t26g an E4 exclusion is in the ledger as EXCLUDED, never dropped",
          nx == len(poolx.excluded) and nx > 0 and len(bx["ledger"]) == len(pool.active()), (nx, len(poolx.excluded)))
    reset()


# ---------------------------------------------------------------------------------------------- t27
def t27_capture():
    plan_tab = {"s1": {"net": 0.12}, "s2": {"net": 0.10}, "s3": {"net": 0.02}, "s4": {"net": 0.09}, "s5": {"net": np.nan}}
    book = {"trades": [{"net": 0.15}, {"net": -0.02}],
            "ledger": {"s1": {"status": "TRADED", "trade": 0, "t_idx": 1}, "s2": {"status": "MERGED", "trade": 0, "t_idx": 1},
                       "s3": {"status": "TRADED", "trade": 1, "t_idx": 2}, "s4": {"status": "HELD_SYMBOL", "trade": None, "t_idx": 3},
                       "s5": {"status": "NO_FILL", "trade": None, "t_idx": 4}}}
    c = B.capture(book, plan_tab, ["s1", "s2", "s3", "s4", "s5"])
    check("t27 capture by hand: majors s1, s2, s4 (> +8% net); the shared trade counts once; held is missed, not credited",
          c["major_winners"] == 3 and abs(c["original_profit"] - 0.31) < 1e-12 and abs(c["captured_profit"] - 0.15) < 1e-12
          and abs(c["capture_share"] - 0.15 / 0.31) < 1e-12 and c["missed"] == 1 and c["missed_but_held"] == 1, c)


# ---------------------------------------------------------------------------------------------- t28
def t28_context():
    """The critical requirement: the SAME trigger behaves differently by context. A1 averages; A2 learns."""
    reset()
    res = {}
    for eff in ("context", "absent", "universal"):
        w = _w3(eff, 1300, 150, 11)
        cal, bars, reg = w["cal"], w["bars"], w["registry"]
        cm = M.CostModel(cal.days)
        M.install(cm)
        C.set_exit_slip(0.05)
        half = cal.n // 2
        pool_tr = LB.Pool(reg, engines=("D", "ENS"), ranks=(1, 2, 3), t_hi=half)
        fam = Confirm()
        rows, _ = LB.research3(cal, bars, pool_tr, fam, C.X1, None, w["ctx"], w["regime"])
        armed = [r for r in rows if r.get("armed")]
        f = fill_rate(armed)
        boot = DayBoot(cal.n, B=1000, seed=7)
        cx = A.context_tests(rows, f, boot)
        a2 = A.learn_a2(rows, f, boot)
        itt = LB.itt_tests(rows, f, boot)
        # test half: A1 vs A2 books on the same span
        pool_te = LB.Pool(reg, engines=("D",), ranks=(1, 2, 3))
        t_lo = half
        t_hi = cal.n - 60
        kw = dict(t_lo=t_lo, t_hi=t_hi)
        a1b = B.run_book2(cal, bars, pool_te, "trigger", A.ArchFamily(fam, "A1"), C.X1, **kw)
        a2b = B.run_book2(cal, bars, pool_te, "trigger", A.ArchFamily(fam, "A2", w["ctx"], w["regime"],
                                                                       eligible=a2["eligible"], risk=a2["risk"]), C.X1, **kw)
        b2t = B.run_book2(cal, bars, pool_te, "open_T1", fam, C.X1, **kw)
        sels = [s for s in pool_te.active() if t_lo <= s.t_idx <= t_hi]
        pt = B.plan_table(cal, bars, sels)
        sp = E.Span(cal, t_lo, t_hi, 60)
        v1 = E.book_view(cal, bars, a1b, cm, sp, pt, [s.sid for s in sels], 8)
        v2 = E.book_view(cal, bars, a2b, cm, sp, pt, [s.sid for s in sels], 8)
        vb = E.book_view(cal, bars, b2t, cm, sp, pt, [s.sid for s in sels], 8)
        cmp = E.Compare(sp, B_=1000)
        from v2_stats import summary
        d21 = summary(*cmp.diff(v2, v1, "per_trade"))
        d1b = summary(*cmp.diff(v1, vb, "daily"))
        res[eff] = {"P2": cx["pairs_arming"].get("P2 bull+up vs bear+down", {}), "inel": [g for g, v in a2["eligible"].items() if not v],
                    "a2_minus_a1_per_trade": d21, "a1_minus_b2t_daily": d1b, "itt": itt.get("money_vs_b2", {})}
        print("     %-9s P2 %s p=%s | A2 ineligible %s | A2-A1 per trade %+.1f bp [%+.1f, %+.1f] | A1-B2T daily %+.1f bp" % (
            eff, "%+.1f bp" % (res[eff]["P2"].get("a_minus_b", {}).get("mean", np.nan) * 1e4),
            "%.4f" % res[eff]["P2"].get("p_two_sided", np.nan), res[eff]["inel"], d21["mean"] * 1e4, d21["lo"] * 1e4,
            d21["hi"] * 1e4, d1b["mean"] * 1e4))
        reset()
    c, a, u = res["context"], res["absent"], res["universal"]
    check("t28a context world: the same trigger, bull+up minus bear+down, is positive and significant (P2)",
          c["P2"].get("p_two_sided", 1) < 0.01 and c["P2"]["a_minus_b"]["lo"] > 0, c["P2"])
    check("t28b context world: A2 marks bear+down groups ineligible and keeps bull+up ones",
          any(g[0] == "bear" and g[1] == "down" for g in c["inel"]) and
          not any(g[0] == "bull" and g[1] == "up" for g in c["inel"]), c["inel"])
    check("t28c context world: A2 beats A1 per trade on unseen sessions (interval above 0)",
          c["a2_minus_a1_per_trade"]["lo"] > 0, c["a2_minus_a1_per_trade"])
    check("t28d no-effect world: the pair is not significant", a["P2"].get("p_two_sided", 0) > 0.05, a["P2"])
    check("t28e universal world: the trigger beats acting at once per armed order everywhere, and the pair is not "
          "significant", u["itt"].get("lo", -1) > 0 and u["P2"].get("p_two_sided", 0) > 0.05, (u["itt"], u["P2"]))


# ---------------------------------------------------------------------------------------------- t29
def t29_seal_freeze():
    reset()
    import v2_run as R
    from v2_synth_data import synthetic_data
    w = _w3("context", 760, 60, 5)
    decl, sha, _ = R.load_decl()
    decl = copy.deepcopy(decl)
    decl["periods"]["discovery"].update({"first_signal_day": "2020-04-01", "last_signal_day": "2021-06-30",
                                         "seal_end": "2021-06-30"})
    decl["periods"]["forecast_experiments_discovery"].update({"first_signal_day": "2021-01-01",
                                                              "last_signal_day": "2021-06-30"})
    decl["periods"]["evaluation"].update({"first_signal_day": "2021-07-01", "last_signal_day": "2022-09-30"})
    out = Path(tempfile.mkdtemp(prefix="v2t29_"))
    log = lambda *a: None
    full = synthetic_data(w)
    sealed = synthetic_data(w, seal_end="2021-06-30")
    check("t29a the sealed data ends at the seal (calendar, bars, selections)",
          str(sealed.cal.days[-1]) <= "2021-06-30" and all(len(sealed.bars[s]["close"]) == sealed.cal.n
                                                            for s in sealed.bars.symbols()) and
          max(s.t_idx for s in sealed.registry.active()) < sealed.cal.n)
    check("t29b discovery refuses unsealed data", H["raises"](lambda: R.discover(full, decl, "d", out, log)))
    rdir = R.discover(sealed, decl, "d", out, log)
    check("t29c evaluation is refused before the freeze", H["raises"](lambda: R.evaluate(full, decl, "d", rdir, out, log)))
    R.freeze(rdir, "d", out, log)
    check("t29d a freeze is never rewritten", H["raises"](lambda: R.freeze(rdir, "d", out, log)))
    check("t29e evaluation is refused on sealed data and with another declaration",
          H["raises"](lambda: R.evaluate(sealed, decl, "d", rdir, out, log)) and
          H["raises"](lambda: R.evaluate(full, decl, "other", rdir, out, log)))
    tb = rdir / "tables.json"
    raw = tb.read_bytes()
    tb.write_bytes(raw.replace(b'"f_train"', b'"f_train_x"', 1))
    check("t29f evaluation is refused when the learned tables changed after the freeze",
          H["raises"](lambda: R.evaluate(full, decl, "d", rdir, out, log)))
    tb.write_bytes(raw)
    edir = R.evaluate(full, decl, "d", rdir, out, log)
    ev = json.loads((edir / "evaluation.json").read_text(encoding="utf-8"))
    led = [json.loads(x) for x in (out / "v2_ledger.jsonl").read_text(encoding="utf-8").splitlines()]
    g = ev["engines"]["D"]["books"]["gates"]
    check("t29g evaluation runs with the frozen tables: 9 candidates gated, the ledger holds discover / freeze / evaluate",
          len(g) == 9 and [x["kind"] for x in led] == ["discover", "protocol_frozen", "evaluate"] and
          (edir / "REPORT_EVALUATION.md").exists(), [x["kind"] for x in led])
    reset()


# ---------------------------------------------------------------------------------------------- t30
def _find(name, env):
    """PATHLAB_DIR / TRADELAB_DIR (env_v2.bat sets them), else the sibling folder of v2engine."""
    for c in (os.environ.get(env), ROOT.parent / name):
        if c and (Path(c) / ("pathlab.py" if name == "pathlab" else "tl_common.py")).exists():
            return Path(c)
    return None


def t30_adapter():
    """v2_data on a fake production cache (pathlab's test world: tradelab's stand-in production modules)."""
    reset()
    pdir, tdir = _find("pathlab", "PATHLAB_DIR"), _find("tradelab", "TRADELAB_DIR")
    if pdir is None or tdir is None:
        check("t30 the adapter test needs pathlab and tradelab folders (PATHLAB_DIR / TRADELAB_DIR)", False,
              (pdir, tdir))
        return
    os.environ["TRADELAB_DIR"] = str(tdir)
    saved = {k: os.environ.pop(k, None) for k in ("TRADELAB_OUT", "PATHLAB_OUT", "V2_OUT")}
    for p in (str(pdir / "tests"), str(pdir), str(tdir / "tests"), str(tdir)):
        if p not in sys.path:
            sys.path.insert(0, p)
    import pl_world as W
    import tl_world as TW
    tmp = Path(tempfile.mkdtemp(prefix="v2t30_"))
    try:
        w = W.make_cache_world(tmp / "w1", n_regular=14, n_3m=3)
        TW.use_mods(w["root"])
        os.environ["V2_OUT"] = str(tmp / "v2out")
        import v2_data as VD
        q = lambda *a: None
        Ds = VD.load_real(w["root"], "PM_TEST_001", seal_end="2022-12-31", stage_e_any=True, costs="replica", log=q)
        Df = VD.load_real(w["root"], "PM_TEST_001", t_first="2020-01-01", stage_e_any=True, costs="replica", log=q)
        check("t30a sealed: the calendar ends at the seal, every array has its length, no selection after it",
              str(Ds.cal.days[-1]) <= "2022-12-31" and all(len(Ds.bars[s]["close"]) == Ds.cal.n for s in Ds.bars.symbols())
              and max(s.T for s in Ds.registry.active()) <= "2022-12-31" and str(Df.cal.days[-1]) > "2023-01-01")
        k = Ds.cal.n
        same = True
        for s in Ds.bars.symbols():
            for f in ("open", "close", "atr", "adv", "vol20", "ll_close", "ll_open", "lower_locked"):
                a, bb = np.asarray(Ds.bars[s][f]), np.asarray(Df.bars[s][f])[:k]
                same &= bool(np.array_equal(a, bb, equal_nan=True)) if a.dtype.kind == "f" else bool(np.array_equal(a, bb))
            for f in ("state", "event", "age"):
                same &= bool(np.array_equal(Ds.ctx[s][f], Df.ctx[s][f][:k]))
            for f in ("s04_start", "s10_start", "s04_status", "s10_status"):
                same &= bool(np.array_equal(Ds.events[s][f], Df.events[s][f][:k]))
        same &= bool(np.array_equal(Ds.regime, Df.regime[:k]))
        check("t30b point in time: the sealed inputs equal the unsealed ones up to the seal (bars, ATR, ADV, locks, "
              "states, events, regimes)", same)
        import tl_data as TD
        import tl_state as TS
        prod = TD.Production(stage_e_any=True)
        mk = TD.Market(w["root"], prod)
        ds = mk.series("LOCKSYM")
        days = Df.cal.days
        lk_ok = True
        for j in range(1, len(ds.dates)):
            i = int(np.searchsorted(days, ds.dates[j]))
            if i >= len(days) or days[i] != ds.dates[j]:
                continue
            lk_ok &= bool(Df.bars["LOCKSYM"]["ll_close"][i]) == ds.locked(j, "close")
            lk_ok &= bool(Df.bars["LOCKSYM"]["ll_open"][i]) == ds.locked(j, "open")
            lk_ok &= bool(Df.bars["LOCKSYM"]["lower_locked"][i]) == ds.frozen(j)
        check("t30c lock flags equal stage E's rule on every bar (the pre-filter loses nothing)",
              lk_ok and Df.info["bars"]["ll_close"] > 0, Df.info["bars"])
        ss = TS.StateSeries("STK03", *(getattr(mk.series("STK03"), a) for a in ("dates", "o", "h", "l", "c", "v")))
        d3 = mk.series("STK03")
        jj = np.searchsorted(days, d3.dates)
        okj = (jj < len(days))
        okj[okj] = days[jj[okj]] == d3.dates[okj]
        st_ok = all(Df.ctx["STK03"]["state"][jj[j]] == X.STATE_CODES.get(ss.state[j], 0) for j in np.flatnonzero(okj))
        ev_ok = all(Df.ctx["STK03"]["event"][jj[j]] == X.EVENT_NUM.get(
            "%s:%s" % (ss.ev_kind[j], ss.ev_status[j]) if ss.ev_kind[j] else "", 0) for j in np.flatnonzero(okj))
        check("t30d contexts equal tl_state's own state and shown event at every bar", st_ok and ev_ok)
        sel_ok = all(s.snap()["state"] == int(Df.ctx[s.symbol]["state"][s.t_idx]) and
                     s.snap()["regime"] == int(Df.regime[s.t_idx]) for s in Df.registry.active())
        etf_out = all(s.symbol != "GOLDBEES" for s in Df.registry.active())
        check("t30e each selection carries the context known at T; ETFs are left out", sel_ok and etf_out and
              Df.info["etf"]["count"] >= 1)
        check("t30f regimes are tl_context's environments (codes 0-4, -1 unknown) and vary",
              set(np.unique(Df.regime)) <= {-1, 0, 1, 2, 3, 4} and len(set(np.unique(Df.regime)) - {-1}) >= 3)
    finally:
        for k_, v_ in saved.items():
            if v_ is not None:
                os.environ[k_] = v_
        os.environ.pop("V2_OUT", None)
    reset()


# ---------------------------------------------------------------------------------------------- t31
def t31_same_moment():
    """Proposal 3 by hand: the filled pick from the close of its fill session to 5 sessions later, minus the same
    day's picks that had not filled by then (over the same sessions), paired by signal day."""
    reset()
    cal = C.SessionCalendar([np.datetime64("2024-01-01") + np.timedelta64(k, "D") for k in range(40)])
    bs = C.BarStore(cal)
    n = cal.n
    for s, g in (("A", 0.05), ("B", 0.01), ("Cc", -0.01), ("D", 0.02)):
        c = np.full(n, 100.0)
        c[17:] = 100.0 * (1 + g)                     # the move from close 12 to close 17 (A fills at session 12)
        bs.put_arrays(s, {"open": c.copy(), "high": c * 1.01, "low": c * 0.99, "close": c, "volume": np.ones(n)})
    rows = [{"sid": "a", "engine": "D", "t_idx": 10, "symbol": "A", "filled": True, "fill_idx": 12, "fill_px": 99.0},
            {"sid": "b", "engine": "D", "t_idx": 10, "symbol": "B", "filled": False, "fill_idx": None},
            {"sid": "c", "engine": "D", "t_idx": 10, "symbol": "Cc", "filled": True, "fill_idx": 15, "fill_px": 100.0},
            {"sid": "d", "engine": "ENS", "t_idx": 10, "symbol": "D", "filled": False, "fill_idx": None}]
    out = LB.same_moment(cal, bs, rows, h=5)
    # A at 12: peers not filled by 12 = B and Cc (Cc fills later, at 15); D is another engine's pick
    # Cc at 15: its own 15 -> 20 is 0 (the move came at 17 for everyone: Cc -1%), peers B (+1%)
    want_a = 0.05 - (0.01 + -0.01) / 2.0
    want_c = -0.01 - 0.01
    check("t31 same-moment selection test by hand: filled pick minus the same day's not-yet-filled picks (same engine)",
          out["fills_with_peers"] == 2 and abs(out["selection_skill"]["mean"] - (want_a + want_c) / 2.0) < 1e-12 and
          abs(out["entry_component_mean"] - ((100.0 / 99.0 - 1.0) + 0.0) / 2.0) < 1e-12, out)


QUICK = [t23_costs, t24_money, t25_trailing, t26_ledger, t27_capture, t28_context, t29_seal_freeze, t30_adapter,
         t31_same_moment]
