r"""v2_world3.py - synthetic worlds for drop 3 (nothing here is shipped to production).

The price engine of v2_world (a martingale from 16-step intraday paths, highs and lows the continuous path's
extremes, so a buy-stop filled at a level the high reached is fair), keyed to T1-0's trigger: the selection day's
high + 0.1 ATR(T), fixed for the window T+1 .. T+10.

Every stock has a context that holds for blocks of 40-90 sessions (a tl_state primary state code, an event code
and its age) and the market has a regime in blocks; selections record the context at T. Effects:
  absent      no drift anywhere
  universal   every stock: -delta a session while it waits below the trigger, +delta for 5 sessions from the
              crossing (the trigger avoids the wait and buys the move)
  context     the SAME trigger behaves differently by context: in (bull state, up event) the universal effect;
              in (bear state, down event) a false break (no drift while waiting, -delta for 5 sessions after the
              crossing); nothing elsewhere. A1 averages the two; A2 should learn to trade only the first.
  majors      no trigger effect; one pick in 12 is a large winner (+2.5% a session for 5 sessions from T+1's open)
Volume: about Rs 5 crore of turnover a session (so the cost model's impact and the 2% cap are realistic).
"""
import math

import numpy as np

import v2_money as M
from v2_core import BarStore, SelectionRegistry, SessionCalendar
from v2_world import business_days, _wilder_step

STATE_POOL = (1, 8, 7, 2, 9)            # S01, S08, S07, S02, S09
EVENT_POOL = (1, 5, 0, 2, 6)            # BREAKOUT:NEW, BREAKDOWN:NEW, none, BREAKOUT:CONFIRMED, BREAKDOWN:CONFIRMED


def _blocks(rng, n, pool, lo=40, hi=90, p=None):
    out = np.empty(n, dtype=int)
    starts = []
    t = 0
    while t < n:
        L = int(rng.integers(lo, hi))
        out[t:t + L] = pool[int(rng.choice(len(pool), p=p))]
        starts.append(t)
        t += L
    return out, starts


def effect_of(state, event, effect):
    """'planted' / 'reverse' / 'absent' for a context, per world effect."""
    if effect == "absent" or effect == "majors":
        return "absent"
    if effect == "universal":
        return "planted"
    bull, bear = state in (1, 2, 3), state in (8, 9)
    up, down = event in (1, 2, 3, 8), event in (4, 5, 6, 7)
    if bull and up:
        return "planted"
    if bear and down:
        return "reverse"
    return "absent"


def make_world3(effect="absent", n_days=900, n_sym=120, delta=0.006, sigma=0.022, gap_sd=0.006, steps=16, picks=3,
                seed=1, post_len=5, offset_atr=0.1, warmup=70, pick_run="PM_SYN3", major_every=12, major_mu=0.025):
    if effect not in ("absent", "universal", "context", "majors"):
        raise ValueError(effect)
    days = business_days("2020-01-01", n_days)
    cal = SessionCalendar(days)
    rng = np.random.default_rng(seed)
    n, S = cal.n, n_sym
    ctx_state = np.zeros((S, n), dtype=int)
    ctx_event = np.zeros((S, n), dtype=int)
    ctx_age = np.zeros((S, n), dtype=int)
    for k in range(S):
        st, _ = _blocks(rng, n, STATE_POOL)
        ev, starts = _blocks(rng, n, EVENT_POOL)
        ctx_state[k], ctx_event[k] = st, ev
        age = np.zeros(n, dtype=int)
        bs = np.zeros(n, dtype=int)
        for s0 in starts:
            bs[s0:] = s0
        age = np.arange(n) - bs
        ctx_age[k] = np.where(ev == 0, -1, age)
    regime, _ = _blocks(rng, n, (0, 1, 2, 3, 4), 50, 120, p=[0.3, 0.2, 0.25, 0.2, 0.05])
    O, H, L, C = (np.full((S, n), np.nan) for _ in range(4))
    atr = np.full(S, np.nan)
    acc, cnt = np.zeros(S), np.zeros(S)
    state = np.zeros(S, dtype=int)            # 0 idle, 1 waiting for the trigger, 2 after the crossing, 3 major run
    watch_end = np.full(S, -1)
    post_end = np.full(S, -1)
    level = np.full(S, np.nan)
    mu_watch = np.zeros(S)
    mu_post = np.zeros(S)
    sd_step = sigma / math.sqrt(steps)
    price0 = 100.0 * np.exp(rng.normal(0.0, 0.6, S))
    sels = []
    crossings = majors = 0
    for s in range(n):
        state = np.where((state == 1) & (s > watch_end), 0, state)
        state = np.where(((state == 2) | (state == 3)) & (s > post_end), 0, state)
        o = price0 if s == 0 else C[:, s - 1] * np.exp(rng.normal(-gap_sd ** 2 / 2.0, gap_sd, S))
        x = np.log(o)
        hi, lo = x.copy(), x.copy()
        logL = np.log(np.where(np.isnan(level), np.inf, level))
        hit0 = (state == 1) & (x >= logL)
        if hit0.any():
            crossings += int(hit0.sum())
            state = np.where(hit0, 2, state)
            post_end = np.where(hit0, s + post_len - 1, post_end)
        v = sd_step ** 2
        for j in range(steps):
            mu = np.where(state == 2, mu_post, np.where(state == 1, mu_watch, np.where(state == 3, major_mu, 0.0)))
            x1 = x + rng.normal(mu / steps - v / 2.0, sd_step, S)
            u1, u2 = rng.random(S), rng.random(S)
            bmax = (x + x1 + np.sqrt((x1 - x) ** 2 - 2.0 * v * np.log(u1))) / 2.0
            bmin = (x + x1 - np.sqrt((x1 - x) ** 2 - 2.0 * v * np.log(u2))) / 2.0
            hit = (state == 1) & (bmax >= logL)
            if hit.any():
                crossings += int(hit.sum())
                state = np.where(hit, 2, state)
                post_end = np.where(hit, s + post_len - 1, post_end)
            hi, lo = np.maximum(hi, bmax), np.minimum(lo, bmin)
            x = x1
        O[:, s], H[:, s], L[:, s], C[:, s] = o, np.exp(hi), np.exp(lo), np.exp(x)
        tr = H[:, s] - L[:, s] if s == 0 else np.maximum(H[:, s] - L[:, s], np.maximum(np.abs(H[:, s] - C[:, s - 1]),
                                                                                       np.abs(L[:, s] - C[:, s - 1])))
        atr, acc, cnt = _wilder_step(atr, acc, cnt, tr)
        if s < warmup or s >= n - 1:
            continue
        chosen = {}
        for eng in ("D", "ENS"):
            lst = []
            while len(lst) < picks:
                c = int(rng.integers(0, S))
                if eng == "ENS" and rng.random() < 0.34 and chosen.get("D"):
                    c = int(rng.choice(chosen["D"]))
                if c not in lst:
                    lst.append(c)
            chosen[eng] = lst
            scores = rng.random(len(lst))
            for rank, kk in enumerate(np.argsort(-scores), start=1):
                sym = lst[kk]
                snap = {"state": int(ctx_state[sym, s]), "event": int(ctx_event[sym, s]),
                        "age": int(ctx_age[sym, s]), "regime": int(regime[s]),
                        "pm_prob_trap": float(rng.uniform(0, 0.2)), "pm_pred_edge": float(rng.normal(0, 0.01))}
                sels.append((eng, rank, cal.date(s), "S%03d" % sym, float(scores[kk]), snap))
        for sym in set(chosen["D"]) | set(chosen["ENS"]):
            if state[sym] != 0:
                continue
            if effect == "majors" and rng.random() < 1.0 / major_every:
                state[sym] = 3
                post_end[sym] = s + post_len
                majors += 1
                continue
            mode = effect_of(int(ctx_state[sym, s]), int(ctx_event[sym, s]), effect)
            if mode == "absent":
                continue
            state[sym] = 1
            watch_end[sym] = s + 10
            level[sym] = H[sym, s] + offset_atr * atr[sym]
            mu_watch[sym] = -delta if mode == "planted" else 0.0
            mu_post[sym] = delta if mode == "planted" else -delta
    bars = BarStore(cal)
    ctx_by_sym = {}
    for k in range(S):
        sym = "S%03d" % k
        turnover = 5e7 * np.exp(rng.normal(0, 0.3, n))
        bars.put_arrays(sym, {"open": O[k], "high": H[k], "low": L[k], "close": C[k], "volume": turnover / C[k]})
        M.prepare_bars(bars[sym])
        ctx_by_sym[sym] = {"state": ctx_state[k], "event": ctx_event[k], "age": ctx_age[k]}
    reg = SelectionRegistry(cal)
    for eng, rank, T, sym, score, snap in sels:
        reg.add(pick_run, eng, rank, T, sym, score, snap)
    return {"cal": cal, "bars": bars, "registry": reg, "ctx": ctx_by_sym, "regime": regime, "effect": effect,
            "crossings": crossings, "majors": majors}
