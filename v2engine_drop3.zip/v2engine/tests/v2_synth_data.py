r"""v2_synth_data.py - a v2_data.Data object from a synthetic drop 3 world, sealed or not (tests only)."""
import numpy as np

import v2_core as C
import v2_money as M
from v2_data import Data


def synthetic_data(w, seal_end=None):
    """w: make_world3(...). seal_end: cut the calendar, bars, contexts, regimes and selections there."""
    cal0 = w["cal"]
    n0 = cal0.n
    k = n0 if seal_end is None else int(np.searchsorted(cal0.days, np.datetime64(seal_end, "D"), side="right"))
    D = Data()
    D.cal = C.SessionCalendar(cal0.days[:k].tolist())
    D.sealed_end = str(np.datetime64(seal_end, "D")) if seal_end else None
    bars = C.BarStore(D.cal)
    for s in w["bars"].symbols():
        b = w["bars"][s]
        rec = {f: np.asarray(b[f])[:k].copy() for f in ("open", "high", "low", "close", "volume", "upper_locked",
                                                         "lower_locked")}
        for f in ("ll_open", "ll_close"):
            if f in b:
                rec[f] = np.asarray(b[f])[:k].copy()
        bars.put_arrays(s, rec)
        M.prepare_bars(bars[s])
    D.bars = bars
    reg = C.SelectionRegistry(D.cal)
    for s in w["registry"].active():
        if s.t_idx < k:
            reg.add(s.pick_run, s.engine, s.rank, s.T, s.symbol, s.raw_score, s.snap())
    D.registry = reg
    D.ctx = {s: {kk: np.asarray(v)[:k].copy() for kk, v in c.items()} for s, c in w["ctx"].items()}
    D.regime = np.asarray(w["regime"])[:k].copy()
    D.events = {}
    D.cm = M.CostModel(D.cal.days)
    D.info = {"version": C.VERSION, "calendar": [str(D.cal.days[0]), str(D.cal.days[-1]), D.cal.n],
              "sealed_end": D.sealed_end, "costs": "replica", "synthetic": w["effect"]}
    return D
