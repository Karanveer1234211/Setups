r"""v2_ctx.py - contexts for drop 3: what was known at a close about the stock and the market.

Per symbol, on the session index (built from tl_state / tl_context by v2_data; synthetic in the tests):
    state[i]   tl_state primary state code at close i (STATE_CODES; -1 = insufficient data)
    event[i]   tl_state's event shown at close i, kind:status coded as tl_state's EVENT_NUM (0 = none)
    age[i]     sessions since that event started (-1 = no event)
Per session: regime[i] = tl_context's environment at close i (0..4 in REGIMES order; -1 = unknown).

Keys (declared 31 Oct, v2.4):
    Level 1  (state group, event group, regime group)          4 x 3 x 3 = 36 groups, high power
    Level 2  (exact state, exact event:status, age bin, exact regime)   tested only where support allows
Declared pairs (the critical requirement: does the SAME trigger behave differently by context?):
    P1  S01 with an S04 breakout NEW/CONFIRMED          vs  S08 with an S10 breakdown NEW/CONFIRMED
    P2  bull state with an up event                       vs  bear state with a down event (Level 1, all regimes)
    P3  bullish market (broad / narrow bullish)           vs  bearish market (broad bearish / high stress)
    P4  bear state with a failed breakdown (bear trap)    vs  bear state with no event
"""
import numpy as np

STATE_CODES = {"INSUFFICIENT_DATA": -1, "UNKNOWN": 0, "S01": 1, "S02": 2, "S03": 3, "S06": 6, "S07": 7, "S08": 8,
               "S09": 9, "S12": 12}
STATE_NAME = {v: k for k, v in STATE_CODES.items()}
EVENT_NUM = {"": 0, "BREAKOUT:NEW": 1, "BREAKOUT:CONFIRMED": 2, "BREAKOUT:STALLED": 3, "FAILED_BREAKOUT:FAILED": 4,
             "BREAKDOWN:NEW": 5, "BREAKDOWN:CONFIRMED": 6, "BREAKDOWN:STALLED": 7, "FAILED_BREAKDOWN:FAILED": 8}
EVENT_NAME = {v: k for k, v in EVENT_NUM.items()}
REGIMES = ("broad_bullish", "narrow_bullish", "mixed", "broad_bearish", "high_stress")
AGE_BINS = ((0, 2), (3, 5), (6, 10), (11, 99))


def state_group(code):
    if code in (1, 2, 3):
        return "bull"
    if code in (6, 7):
        return "turn_flat"
    if code in (8, 9):
        return "bear"
    return "other"


def event_group(code):
    if code in (1, 2, 3, 8):
        return "up"
    if code in (4, 5, 6, 7):
        return "down"
    return "none"


def regime_group(code):
    if code in (0, 1):
        return "bull_mkt"
    if code == 2:
        return "mixed"
    if code in (3, 4):
        return "bear_mkt"
    return "unknown"


def age_bin(age):
    if age is None or age < 0:
        return "none"
    for a, b in AGE_BINS:
        if a <= age <= b:
            return "%d-%d" % (a, b) if b < 99 else "%d+" % a
    return "%d+" % AGE_BINS[-1][0]


def snapshot(ctx, regime, i):
    """The context known at close i: a plain dict (stored on the selection record at T)."""
    s = int(ctx["state"][i]) if i >= 0 else -1
    e = int(ctx["event"][i]) if i >= 0 else 0
    a = int(ctx["age"][i]) if i >= 0 else -1
    r = int(regime[i]) if i >= 0 else -1
    return {"state": s, "event": e, "age": a, "regime": r}


def level1(snap):
    return (state_group(snap["state"]), event_group(snap["event"]), regime_group(snap["regime"]))


def level1_no_regime(snap):
    return (state_group(snap["state"]), event_group(snap["event"]))


def level2(snap):
    return (STATE_NAME.get(snap["state"], "?"), EVENT_NAME.get(snap["event"], "?") or "none", age_bin(snap["age"]),
            REGIMES[snap["regime"]] if 0 <= snap["regime"] < len(REGIMES) else "unknown")


def level2_parent(cell):
    """Level 2 cell -> its Level 1 group (for empirical-Bayes pooling)."""
    st, ev, _age, rg = cell
    s = STATE_CODES.get(st, -1)
    e = EVENT_NUM.get("" if ev == "none" else ev, 0)
    r = REGIMES.index(rg) if rg in REGIMES else -1
    return (state_group(s), event_group(e), regime_group(r))


def _p1(snap):
    if snap["state"] == 1 and snap["event"] in (1, 2):
        return "A"
    if snap["state"] == 8 and snap["event"] in (5, 6):
        return "B"
    return None


def _p2(snap):
    g = level1_no_regime(snap)
    if g == ("bull", "up"):
        return "A"
    if g == ("bear", "down"):
        return "B"
    return None


def _p3(snap):
    rg = regime_group(snap["regime"])
    return {"bull_mkt": "A", "bear_mkt": "B"}.get(rg)


def _p4(snap):
    if state_group(snap["state"]) != "bear":
        return None
    if snap["event"] == 8:
        return "A"
    if snap["event"] == 0:
        return "B"
    return None


PAIRS = {"P1 S01+S04 vs S08+S10": _p1, "P2 bull+up vs bear+down": _p2, "P3 bullish vs bearish market": _p3,
         "P4 bear trap vs bear, no event": _p4}
