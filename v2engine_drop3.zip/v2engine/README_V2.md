# v2engine 0.3 (drop 3) - BigMove v2 execution engine, daily

Built 31 Oct 2026 from Spec v2.4 ("BigMove Execution Engine - Spec v2", Claude Doc, sections 13-14).
Judges every way of entering BigMove's picks on its large winners, fully net expectancy and portfolio drawdown,
against the original BigMove and a same-budget open entry. Reads production READ ONLY (through tradelab);
writes only under `%V2_OUT%`. Nothing in bigmove_deploy, tradelab or pathlab is touched.

## Install (cmd)

Unzip so that `C:\Users\karanvsi\PyCharmMiscProject\v2engine\` is replaced by the zip's `v2engine` folder (delete
the old folder first: drop 2's `V2_DECLARATION_DRAFT.json` is superseded by `V2_DROP3_DECLARATION.json`).

    call C:\Users\karanvsi\PyCharmMiscProject\v2engine\env_v2.bat
    python v2engine.py --selftest quick

Expected last line: `VERIFIED (v2engine 0.3 (drop 3))` (117 checks, about 2 minutes; `--selftest` without `quick` adds
the 20 calibration worlds: 118 checks). `env_v2.bat` sets
PYTHONPATH to v2engine, pathlab, tradelab and bigmove_deploy\open_close, and V2_OUT=C:\QuantData\v2engine.
Edit the paths at its top if your folders differ.

## Run

    python v2engine.py discover --root %CACHE_DAILY_ROOT% --out %V2_OUT%

Sealed at 2022-12-31: nothing after the seal is loaded. Writes `%V2_OUT%\discover_<date_time>\` with
REPORT_DISCOVERY.md, discovery.json, tables.json (the learned A2 / A3 tables). In-sample: descriptive only.
**Send me REPORT_DISCOVERY.md before freezing**, with your answer on the four defaults in Spec section 14.

After you confirm (once, and never again for this protocol):

    python v2engine.py freeze --discovery %V2_OUT%\discover_<date_time> --out %V2_OUT%
    python v2engine.py evaluate --discovery %V2_OUT%\discover_<date_time> --root %CACHE_DAILY_ROOT% --out %V2_OUT%

`evaluate` is refused unless the declaration, the tables and every module still match the freeze. It writes
`%V2_OUT%\evaluate_<date_time>\REPORT_EVALUATION.md`. Every run appends a line to `%V2_OUT%\v2_ledger.jsonl`.
Time: about 10-30 minutes per run (an estimate from the test cache, not measured on your data). The regime needs
breadth: tradelab's or pathlab's saved copy is reused; without one it is counted once and saved under V2_OUT.

Options: `--stage-e-any` / `--tradelab-any` accept a stage_e_execution / tradelab other than the tested versions
(v1.2 sha16 158883f0af70728d / v1.3.1), knowingly; `--max-symbols N` is a quick look on N symbols (marked PARTIAL,
never frozen).

## Files

| File | What it does |
|---|---|
| v2engine.py | Command line: --selftest, --version, discover, freeze, evaluate (no default cache path) |
| v2_run.py | discover / freeze / evaluate; families, architectures, books, experiments per engine |
| v2_data.py | Real data through tradelab: NIFTY 50 calendar, stage E's bars and lock rule, tl_state contexts and events, tl_context regimes, pick_meta picks (SHA-checked, ETFs out), home index |
| v2_money.py | Stage E's zerodha_base costs (its own functions on real data, checked at load); the money view (Rs 10 lakh, slots, integer shares, 2% ADV cap, cash) |
| v2_book2.py | Budgeted books (trigger, B2a, B2T, PLAN_B, PLAN_native) with the selection ledger; major-winner capture |
| v2_eval.py | Paired bootstrap comparisons, gates G1 / G2a / G2b / G3, max-t across candidates |
| v2_arch.py | A1 / A2 / A3, A2 / A3 learning, the context tests (Level 1, pairs P1-P4, Level 2 pooled) |
| v2_ctx.py | Context keys: Level 1 groups, Level 2 cells, the declared pairs |
| v2_lab.py | Research rows for every selection (armed or not), quality profile, same-moment test |
| v2_report.py | The Markdown report |
| v2_core.py, v2_families.py, v2_research.py, v2_learn.py, v2_stats.py | Drops 1-2: calendar, registry, fills, exits (+ V1 / V2 trailing), families (+ T1-0), trigger tests, bootstrap |
| V2_DROP3_DECLARATION.json | Every declared rule, period, gate and experiment (hashed at the freeze) |
| env_v2.bat | Session setup (CRLF) |
| tests\ | test_v2.py + test_drop3.py (the suite), synthetic worlds, the fake-cache adapter test (uses pathlab's and tradelab's test worlds) |

## Verified here

118 checks (full suite), 0 failed, on Python 3.13 / numpy 2.5.3 / pandas 3.0.5 and on Python 3.12 / numpy 2.4.1 /
pandas 2.3.3; both print the same numbers. 19 planted bugs, each caught: the trail armed on an intraday high; the
trail loosened (two ways); the trail under the latest instead of the highest close; a gap through the trail filled
at the stop; V2 extending a trade whose trail never armed; the DP charge, the exit impact or the 2% cap dropped;
fractional shares; never-armed selections dropped from the ledger; fills beyond the budget kept; B2T a session late;
a shared trade counted twice in capture; A2 ignoring its table; the adapter not cut at the seal; a lock pre-filter
that misses locks; contexts shifted a session; a freeze that ignores changed tables.
The adapter has run only on a fake production cache; your cache has not been read yet.
