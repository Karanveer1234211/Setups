r"""v2_eval.py - portfolio-level comparisons and the acceptance gates (drop 3, spec v2.4).

Every comparison runs on one span of sessions shared by every book, with one circular block bootstrap of those
sessions (10-session blocks, 2,000 draws, seed 7): each book's daily money-view return, its per-trade fully net
results (keyed by entry session) and its major-winner capture (keyed by signal day) are resampled on the SAME draws,
so every difference keeps its pairing.

Gates (declared before the 2023-25 evaluation; a candidate is ACCEPTED for the forward paper test only if all hold):
  G1  large winners: capture share (fully net profit of the original BigMove's > +8% trades that the book took)
      minus PLAN_B's (the original trades under the same budget) - 95% lower bound above -0.10 (non-inferiority)
  G2a fully net expectancy per trade minus the original BigMove's (PLAN_native) - 95% interval above 0
  G2b money-view mean daily return minus the matched same-budget open entry (B2T, same exit) - 95% interval above 0
      (G2a / G2b: max-t across every declared candidate of the engine, one-sided; the adjusted p must be < 0.05)
  G3  money-view maximum drawdown smaller than the original BigMove's (PLAN_native), point estimate
Win rate is reported, never a gate.
"""
import numpy as np

import v2_book2 as B
import v2_money as M
from v2_lab import quality
from v2_stats import DayBoot, max_t, summary

G1_MARGIN = 0.10
ALPHA = 0.05


class Span:
    """The money-view span: from the first selection session to the last session any trade can need."""

    def __init__(self, cal, t_lo, t_hi, tail):
        self.lo = int(t_lo)
        self.hi = int(min(cal.n - 1, t_hi + tail))
        self.n = self.hi - self.lo + 1


def book_view(cal, bars, book, cm, span, plan_tab, sids, slots):
    """Everything about one book on the span."""
    sim = M.simulate(cal, bars, book["trades"], cm, slots=slots, t_lo=span.lo, t_hi=span.hi)
    r = M.daily_returns(sim)
    tr = B.finished(book, span.hi)
    gross = np.array([t["gross"] for t in tr], dtype=float)
    net = np.array([t["net"] for t in tr], dtype=float)
    ent = np.array([t["entry_idx"] - span.lo for t in tr], dtype=int)
    cap = B.capture(book, plan_tab, sids)
    # capture components by signal day (numerator: the serving trade's net once; denominator: original net)
    majors = [sid for sid in sids if np.isfinite(plan_tab[sid]["net"]) and plan_tab[sid]["net"] > 0.08]
    num = np.zeros(span.n)
    den = np.zeros(span.n)
    used = set()
    for sid in majors:
        led = book["ledger"].get(sid)
        k = int(led["t_idx"]) - span.lo if led else None
        if k is None or not (0 <= k < span.n):
            continue
        den[k] += plan_tab[sid]["net"]
        if led["status"] in ("TRADED", "MERGED") and led["trade"] is not None and led["trade"] not in used:
            used.add(led["trade"])
            num[k] += book["trades"][led["trade"]]["net"]
    return {"name": book["name"], "sim": sim, "perf": M.perf(sim, cal.days), "r": r, "net": net, "gross": gross,
            "entry": ent, "quality": quality(gross, net), "capture": cap, "cap_num": num, "cap_den": den,
            "ledger": B.ledger_counts(book)}


class Compare:
    """Paired comparisons of book views on one bootstrap of the span's sessions."""

    def __init__(self, span, B_=2000, seed=7, block=10):
        self.span = span
        self.boot = DayBoot(span.n, block=block, B=B_, seed=seed)

    def daily(self, v):
        return self.boot.mean(v["r"], np.ones(self.span.n))

    def per_trade(self, v):
        s, c = self.boot.by_day(v["entry"], v["net"]) if len(v["net"]) else (np.zeros(self.span.n), np.zeros(self.span.n))
        return self.boot.mean(s, c)

    def capture(self, v):
        return self.boot.ratio(v["cap_num"], v["cap_den"])

    def diff(self, a, b, what):
        f = {"daily": self.daily, "per_trade": self.per_trade, "capture": self.capture}[what]
        ma, ba = f(a)
        mb, bb = f(b)
        return ma - mb, ba - bb


def gates(cmp, cand, plan_b, plan_native, b2t):
    """The four gates for one candidate (G2 unadjusted here; the max-t adjustment is applied by adjust())."""
    out = {}
    d, bs = cmp.diff(cand, plan_b, "capture")
    s = summary(d, bs)
    out["G1"] = {"capture": cand["capture"]["capture_share"], "capture_plan_b": plan_b["capture"]["capture_share"],
                 "diff": s, "pass": bool(s["lo"] > -G1_MARGIN)}
    d, bs = cmp.diff(cand, plan_native, "per_trade")
    out["G2a"] = {"diff": summary(d, bs), "obs": d, "boots": bs}
    d, bs = cmp.diff(cand, b2t, "daily")
    out["G2b"] = {"diff": summary(d, bs), "obs": d, "boots": bs}
    out["G3"] = {"max_dd": cand["perf"]["max_dd"], "max_dd_plan_native": plan_native["perf"]["max_dd"],
                 "pass": bool(cand["perf"]["max_dd"] > plan_native["perf"]["max_dd"])}
    return out


def adjust(gate_list, alpha=ALPHA):
    """Max-t (one-sided, H1: difference > 0) across every candidate for G2a and G2b."""
    for g in ("G2a", "G2b"):
        obs = [x[g]["obs"] for x in gate_list]
        boots = [x[g]["boots"] for x in gate_list]
        ok = [i for i, b in enumerate(boots) if np.sum(np.isfinite(b)) > 10 and np.nanstd(b) > 0]
        p = np.ones(len(gate_list))
        if ok:
            t, pp = max_t([obs[i] for i in ok], [boots[i] for i in ok], two_sided=False)
            for i, pv in zip(ok, pp):
                p[i] = pv
        for x, pv in zip(gate_list, p):
            x[g]["p_maxt"] = float(pv)
            x[g]["pass"] = bool(pv < alpha and x[g]["diff"]["lo"] > 0)
    for x in gate_list:
        x["accepted"] = bool(x["G1"]["pass"] and x["G2a"]["pass"] and x["G2b"]["pass"] and x["G3"]["pass"])
        for g in ("G2a", "G2b"):
            x[g].pop("boots", None)
    return gate_list


def by_year(cal, view, span):
    """Descriptive: per calendar year of the entry session, trades and fully net expectancy; money-view return."""
    yrs = np.asarray(cal.days[span.lo:span.hi + 1]).astype("datetime64[Y]").astype(int) + 1970
    out = {}
    for y in sorted(set(yrs.tolist())):
        m = yrs == y
        rr = view["r"][m]
        sel = np.isin(view["entry"], np.flatnonzero(m))
        out[int(y)] = {"return": float(np.prod(1 + rr) - 1), "sessions": int(m.sum()), "trades": int(sel.sum()),
                       "expectancy": float(view["net"][sel].mean()) if sel.any() else np.nan}
    return out
