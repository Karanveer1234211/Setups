r"""v2_research.py - the two comparisons of spec v2.3, kept apart (drop 1).

Research mode (per armed order, no budget): for each selection a family arms, the trigger's outcome
(a filled trade at its net result, an unfilled order at zero) beside baselines fixed at the FIRST
arming close from what was known then:
  B2   act now: buy at the next open (pre-open order), same stop and exit policy
  B2p  act now with the family's training-year fill rate (participation-matched; applied as f x B2)
  B3b  traded with the training-year fill rate at the open of a session drawn at random from the rest
       of the window, decided at arming; tested paired against its expected outcome per armed order
       (the 1,000-draw percentile is reported as descriptive)
  B4   the same order entered at the open of T+d (d = 2, 3, 5), never before the first arming
  B0 / B0' original BigMove for the same selection (T+1 open to the 5th close / the 6th open)
Nothing about whether or when the trigger later fired chooses, counts or times a baseline.

Book mode (budget): the allocator arms at most the remaining budget each evening (2 a day, 6 in any
5 sessions, 8 open, one position per stock; same-stock selections merged into one order, the first in
priority). The trigger book and the act-now (B2) book use the same allocator, budget and exits; they
are compared on net return per session on the capital in use.
"""
from collections import Counter, defaultdict
from dataclasses import dataclass

import numpy as np

from v2_core import (BLOCKED, cost, FILLED, GAPPED_OVER, INVALID_AT_OPEN, WINDOW, fill_buy_stop,
                     fill_preopen, plan_trade, run_exit, structure_target)
from v2_stats import DayBoot, summary

CAP_ATR = 1.0           # pre-open orders: limit at the previous close + 1.0 ATR (declared)


def do_exit(b, cal, i, px, kind, policy, stop, ev):
    """run_exit with the symbol's event input: ev is None, a boolean exit array, or a dict holding
    'exit' (boolean array: a declared exit event at that close) and 'swing_highs' (for X4)."""
    exit_arr = ev.get("exit") if isinstance(ev, dict) else ev
    if policy.kind == "X6":                       # drop 3: the trailing exits V1 / V2 read prices only
        return run_exit(b, cal, i, px, kind, policy, stop, None, np.nan)
    tgt = np.nan
    if policy.kind == "X4" and isinstance(ev, dict):
        tgt = structure_target(ev.get("swing_highs", []), i, px, stop)
    return run_exit(b, cal, i, px, kind, policy, stop, exit_arr, tgt)


def armed_order(family, b, cal, sel, a):
    """The family's order at close a, with the general rule enforced again here: a buy-stop is armed
    only while its trigger sits above the last close (a trigger at or below it is 'already through')."""
    o = family.arm(b, cal, sel, a)
    if o is None:
        return None
    if o.arm_idx != a:
        raise ValueError("%s armed at %d but reported arm_idx %d" % (family.key, a, o.arm_idx))
    if o.kind == "stop" and not (o.trigger > b["close"][a]):
        return None
    return o


def preopen_outcome(b, cal, i, stop, policy, events, cap_atr=CAP_ATR):
    """Net result of a pre-open buy at session i with the given stop; 0 when it cannot be bought."""
    if i > cal.n - 1 or not cal.entry_ok[i]:
        return np.nan, "OUTSIDE"
    st, px = fill_preopen(b, i, cap_atr)
    if st != FILLED:
        return 0.0, st
    if not (stop < px):
        return 0.0, INVALID_AT_OPEN
    ex = do_exit(b, cal, i, px, "open", policy, stop, events)
    return ex["net"], ex["reason"]


def research(cal, bars, registry, family, policy, events_by_sym=None, cap_atr=CAP_ATR, delays=(2, 3, 5)):
    """One row per armed selection (the family armed it at least once inside its window)."""
    rows, counts = [], Counter()
    flags = registry.flags()
    act_now_at_T = getattr(family, "act_now_at_selection", family.name == "T1-1")
    for sel in registry.active():
        b = bars[sel.symbol]
        ev = events_by_sym.get(sel.symbol) if events_by_sym else None
        if not family.eligible(b, cal, sel):
            counts["ineligible"] += 1
            continue
        first, fill_i, fill_px = None, None, np.nan
        trig, reason, mfe, mae = 0.0, "EXPIRED", np.nan, np.nan
        trig_gross, exit_i, exit_px = np.nan, None, np.nan
        n_blocked = n_gapped = n_armed = 0
        for a in cal.arming_closes(sel.t_idx):
            o = armed_order(family, b, cal, sel, a)
            if o is None:
                continue
            n_armed += 1
            if first is None:
                first = o
            i = a + 1
            if o.kind == "stop":
                st, px = fill_buy_stop(b, i, o.trigger, o.limit)
            else:
                st, px = fill_preopen(b, i, cap_atr)
                if st == FILLED and not (o.stop < px):
                    st = INVALID_AT_OPEN
            if st == FILLED:
                ex = do_exit(b, cal, i, px, "stop" if o.kind == "stop" else "open", policy, o.stop, ev)
                trig, reason, fill_i, fill_px, mfe, mae = ex["net"], ex["reason"], i, px, ex["mfe"], ex["mae"]
                trig_gross, exit_i, exit_px = ex["r_px"], ex["exit_idx"], ex["exit_px"]
                break
            n_blocked += st == BLOCKED
            n_gapped += st == GAPPED_OVER
            if o.kind == "preopen":
                reason = st
                break
        if first is None:
            counts["never_armed"] += 1
            continue
        a0 = first.arm_idx
        base_i = sel.t_idx + 1 if act_now_at_T else a0 + 1
        b2, b2_reason = preopen_outcome(b, cal, base_i, first.stop, policy, ev, cap_atr)
        last = min(sel.t_idx + WINDOW, cal.n - 1)
        opts = [preopen_outcome(b, cal, s, first.stop, policy, ev, cap_atr)[0]
                for s in range(base_i, last + 1) if cal.entry_ok[s]]
        b4 = {d: preopen_outcome(b, cal, max(sel.t_idx + d, base_i), first.stop, policy, ev, cap_atr)[0]
              for d in delays}
        b0, b0_reason = plan_trade(b, cal, sel.t_idx, "CLOSE5")
        b0p, _ = plan_trade(b, cal, sel.t_idx, "OPEN6")
        fl = flags[sel.sid]
        row = {"sid": sel.sid, "engine": sel.engine, "rank": sel.rank, "T": sel.T, "t_idx": sel.t_idx,
               "symbol": sel.symbol, "raw_score": sel.raw_score, "family": family.key,
               "policy": policy.name(), "a0": a0, "armed_day": a0 - sel.t_idx, "n_armed": n_armed,
               "filled": fill_i is not None, "fill_idx": fill_i, "fill_px": fill_px,
               "fill_day": (fill_i - sel.t_idx) if fill_i is not None else np.nan,
               "trig": trig, "trig_reason": reason, "mfe": mfe, "mae": mae, "trig_gross": trig_gross,
               "exit_idx": exit_i, "exit_px": exit_px,
               "b2": b2, "b2_reason": b2_reason, "opts": opts, "b0": b0, "b0_reason": b0_reason, "b0p": b0p,
               "first": fl["first"], "repeat": bool(fl["overlap_prior"]), "same_day_other": bool(fl["same_day_other"]),
               "n_blocked": n_blocked, "n_gapped": n_gapped, "stop": first.stop}
        for d in delays:
            row["b4_%d" % d] = b4[d]
        row.update({"ctx_" + k: v for k, v in sel.snap().items()})
        rows.append(row)
    counts["armed"] = len(rows)
    return rows, counts


def settled(rows):
    """Rows whose trigger, B2 and every B3b option settled before the data ended."""
    keep = []
    for r in rows:
        vals = [r["trig"], r["b2"]] + list(r["opts"])
        if all(not np.isnan(v) for v in vals) and len(r["opts"]) > 0:
            keep.append(r)
    return keep


def fill_rate(rows):
    if not rows:
        return np.nan
    return float(np.mean([1.0 if r["filled"] else 0.0 for r in rows]))


def trigger_tests(rows, f_train, boot, b3_draws=1000, seed=7, lens=None):
    """The trigger question per armed order. f_train: the family's fill rate on training years."""
    rs = settled(rows)
    if lens == "first":
        rs = [r for r in rs if r["first"]]
    out = {"n_rows": len(rs), "fill_rate": fill_rate(rs), "f_train": f_train}
    if not rs:
        return out
    day = np.array([r["t_idx"] for r in rs])
    trig = np.array([r["trig"] for r in rs])
    b2 = np.array([r["b2"] for r in rs])

    def paired(x):
        s, c = boot.by_day(day, x)
        return summary(*boot.mean(s, c))

    out["trigger"] = paired(trig)
    out["b2"] = paired(b2)
    out["money_vs_b2"] = paired(trig - b2)
    out["skill_vs_b2p"] = paired(trig - f_train * b2)
    for d in (2, 3, 5):
        out["vs_b4_%d" % d] = paired(trig - np.array([r["b4_%d" % d] for r in rs]))
    # B3b null: participation at f_train, entry session drawn at random from the rest of the window
    rng = np.random.default_rng(seed)
    m = max(len(r["opts"]) for r in rs)
    opts = np.full((len(rs), m), np.nan)
    lens_ = np.array([len(r["opts"]) for r in rs])
    for k, r in enumerate(rs):
        opts[k, :len(r["opts"])] = r["opts"]
    null = np.empty(b3_draws)
    for j in range(b3_draws):
        pick = (rng.random(len(rs)) * lens_).astype(int)
        part = rng.random(len(rs)) < f_train
        null[j] = np.mean(np.where(part, opts[np.arange(len(rs)), pick], 0.0))
    t_mean = float(trig.mean())
    # Gate 3 uses the PAIRED form: per armed order, trigger minus B3b's expected outcome
    # (f_train x the average of its possible entry days), with the day-block interval. The 1,000-draw
    # percentile holds the price paths fixed, ignores their noise and ran hot in no-effect worlds
    # (5 of 20 in the outer 10%), so it is descriptive only.
    exp_b3b = f_train * np.array([np.mean(r["opts"]) for r in rs])
    out["vs_b3b"] = paired(trig - exp_b3b)
    out["b3b_draws_descriptive"] = {"trigger_mean": t_mean, "null_mean": float(null.mean()),
                                    "null_p95": float(np.quantile(null, 0.95)),
                                    "percentile": float(np.mean(null < t_mean) * 100.0)}
    filled = np.array([r["filled"] for r in rs])
    if filled.any():
        out["per_fill_descriptive"] = {"n": int(filled.sum()), "trigger": float(trig[filled].mean()),
                                       "b2_same_orders": float(b2[filled].mean())}
    return out


# ============================================================================ book mode
@dataclass(frozen=True)
class Budget:
    per_day: int = 2
    per_5: int = 6
    max_open: int = 8


def exit_timing(reason, timing=""):
    """When in the exit session the slot is freed. drop 3: run_exit reports it ('timing'); the reason-based guess
    is kept only for records without it."""
    if timing:
        return timing
    if reason in ("STOP", "TARGET", "TRAIL_STOP"):
        return "intraday"
    if reason in ("BACKSTOP", "STUCK", "CLOSE5"):
        return "close"
    return "open"


def priority_key(fam, sel):
    return (fam.priority, sel.rank, 0 if sel.engine == "D" else 1, -sel.raw_score, sel.t_idx, sel.sid)


def run_book(cal, bars, registry, families, policy, mode="trigger", budget=Budget(), cap_atr=CAP_ATR,
             events_by_sym=None):
    """Day-by-day book. mode 'trigger' = v2; 'act_now' = the B2 book (same allocator, next-open buys)."""
    n = cal.n
    fams = sorted(families, key=lambda f: f.priority)
    by_T = defaultdict(list)
    for s in registry.active():
        by_T[s.t_idx].append(s)
    live, served = [], set()
    positions = {}
    entries = np.zeros(n, dtype=int)
    trades, armed_log = [], []
    for a in range(n - 1):
        live.extend(by_T.get(a, []))
        live = [s for s in live if s.t_idx + WINDOW - 1 >= a and s.sid not in served]
        for sym in list(positions):
            tr = positions[sym]
            x = tr["exit_idx"]
            if x is not None and (x < a + 1 or (x == a + 1 and tr["timing"] == "open")):
                del positions[sym]
        if not cal.entry_ok[a + 1]:
            continue
        room = min(budget.per_day, budget.per_5 - int(entries[max(0, a - 3):a + 1].sum()),
                   budget.max_open - len(positions))
        if room <= 0:
            continue
        cands = []
        for s in live:
            if s.symbol in positions:
                continue
            b = bars[s.symbol]
            for fam in fams:
                if not fam.eligible(b, cal, s):
                    continue
                o = armed_order(fam, b, cal, s, a)
                if o is not None:
                    cands.append((priority_key(fam, s), s, fam, o))
                    break
        cands.sort(key=lambda x: x[0])
        chosen, by_sym = [], {}
        for key, s, fam, o in cands:
            if s.symbol in by_sym:
                by_sym[s.symbol]["merged"].append(s.sid)
                continue
            c = {"sel": s, "fam": fam, "order": o, "merged": [s.sid]}
            by_sym[s.symbol] = c
            chosen.append(c)
        chosen = chosen[:room]
        i = a + 1
        for c in chosen:
            s, o = c["sel"], c["order"]
            b = bars[s.symbol]
            ev = events_by_sym.get(s.symbol) if events_by_sym else None
            if mode == "trigger" and o.kind == "stop":
                st, px = fill_buy_stop(b, i, o.trigger, o.limit)
                kind = "stop"
            else:
                st, px = fill_preopen(b, i, cap_atr)
                kind = "open"
                if st == FILLED and not (o.stop < px):
                    st = INVALID_AT_OPEN
            armed_log.append({"arm_idx": a, "sid": s.sid, "symbol": s.symbol, "family": c["fam"].key,
                              "merged": list(c["merged"]), "status": st})
            if st != FILLED:
                continue
            ex = do_exit(b, cal, i, px, kind, policy, o.stop, ev)
            tr = {"symbol": s.symbol, "sid": s.sid, "served": list(c["merged"]), "family": c["fam"].key,
                  "entry_idx": i, "entry_px": px, "exit_idx": ex["exit_idx"], "exit_px": ex["exit_px"],
                  "reason": ex["reason"], "net": ex["net"], "timing": exit_timing(ex["reason"], ex.get("timing", ""))}
            trades.append(tr)
            positions[s.symbol] = tr
            entries[i] += 1
            served.update(c["merged"])
    return trades, armed_log, entries


def book_pnl(cal, bars, trades):
    """Per-session P&L and capital in use (unit notional per trade, marked at closes, cost at exit)."""
    n = cal.n
    P, C = np.zeros(n), np.zeros(n)
    for tr in trades:
        b = bars[tr["symbol"]]
        e, x = tr["entry_idx"], tr["exit_idx"]
        last = x if x is not None else n - 1
        prev = 1.0
        for s in range(e, last + 1):
            start = 1.0 if s == e else prev
            if x is not None and s == x:
                end = tr["exit_px"] / tr["entry_px"] - cost()
            else:
                c = b["close"][s]
                end = c / tr["entry_px"] if not np.isnan(c) else prev
            P[s] += end - start
            C[s] += start
            prev = end
    return P, C


def compare_books(cal, bars, trades_a, trades_b, boot):
    """Net return per session on the capital in use, book a minus book b, on shared session draws."""
    Pa, Ca = book_pnl(cal, bars, trades_a)
    Pb, Cb = book_pnl(cal, bars, trades_b)
    ra, ba = boot.ratio(Pa, Ca)
    rb, bb = boot.ratio(Pb, Cb)
    out = {"a": summary(ra, ba), "b": summary(rb, bb), "a_minus_b": summary(ra - rb, ba - bb),
           "trades_a": len(trades_a), "trades_b": len(trades_b),
           "capital_sessions_a": float(Ca.sum()), "capital_sessions_b": float(Cb.sum())}
    return out


def check_budget(cal, trades, budget=Budget()):
    """Independent re-check of the caps from the trade list (used by the tests)."""
    n = cal.n
    entries = np.zeros(n, dtype=int)
    for t in trades:
        entries[t["entry_idx"]] += 1
    bad = []
    if entries.max(initial=0) > budget.per_day:
        bad.append("per_day")
    for i in range(n):
        if entries[max(0, i - 4):i + 1].sum() > budget.per_5:
            bad.append("per_5")
            break
    for i in range(n):
        open_syms = [t["symbol"] for t in trades if t["entry_idx"] <= i and
                     (t["exit_idx"] is None or t["exit_idx"] > i or
                      (t["exit_idx"] == i and t["timing"] != "open"))]
        if len(open_syms) > budget.max_open:
            bad.append("max_open")
            break
        if len(open_syms) != len(set(open_syms)):
            bad.append("one_per_symbol")
            break
    return bad
