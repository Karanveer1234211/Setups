r"""v2_report.py - the Markdown report of a drop 3 run (discovery or evaluation). Numbers as computed: returns in
percent with two decimals and their sign, differences in basis points with their 95% interval."""
import numpy as np


def _f(x, nd=2, pct=True, sign=True):
    if x is None:
        return "-"
    try:
        v = float(x)
    except (TypeError, ValueError):
        return str(x)
    if not np.isfinite(v):
        return "-"
    v = v * 100.0 if pct else v
    return ("%+.*f" if sign else "%.*f") % (nd, v) + ("%" if pct else "")


def _bp(s):
    """A summary dict {mean, lo, hi} -> '+12.3 bp [-4.5, +29.1]'."""
    if not s or s.get("mean") is None:
        return "-"
    g = lambda v: "-" if v is None or not np.isfinite(v) else "%+.1f" % (v * 1e4)
    return "%s bp [%s, %s]" % (g(s.get("mean")), g(s.get("lo")), g(s.get("hi")))


def _pts(s):
    if not s or s.get("mean") is None:
        return "-"
    g = lambda v: "-" if v is None or not np.isfinite(v) else "%+.3f" % v
    return "%s [%s, %s]" % (g(s.get("mean")), g(s.get("lo")), g(s.get("hi")))


def _book_row(name, b):
    q, c, m = b["quality"], b["capture"], b["money"]
    return "| %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s/%s | %s | %s | %s |" % (
        name, q.get("trades", 0), _f(q.get("expectancy")), _f(q.get("expectancy_gross")), _f(q.get("winner_rate"), 1, sign=False),
        _f(q.get("big_win_rate"), 1, sign=False), _f(q.get("bad_rate"), 1, sign=False), _f(q.get("tail_cvar5")),
        _f(q.get("win_rate"), 1, sign=False), _f(c.get("capture_share"), 1, sign=False), c.get("missed", "-"),
        c.get("major_winners", "-"), _f(m.get("cagr")), _f(m.get("max_dd")), _f(m.get("utilisation"), 0, sign=False))


BOOK_HEAD = ("| book | trades | net / trade | gross / trade | winners > 3% | big > 8% | bad <= -4% | CVaR5 | win rate | "
             "capture | missed / majors | CAGR | max DD | utilisation |\n|---|---|---|---|---|---|---|---|---|---|---|---|---|---|")


def report(res, tables, kind):
    L = []
    L.append("# v2engine drop 3 - %s report (%s)" % (kind, res.get("run")))
    L.append("")
    L.append("- version: %s; declaration sha256 %s" % (res.get("version"), str(res.get("declaration_sha256"))[:16]))
    d = res.get("data", {})
    L.append("- calendar %s; sealed at %s; costs: %s; breadth: %s" % (d.get("calendar"), d.get("sealed_end"),
                                                                      d.get("costs"), d.get("breadth")))
    L.append("- picks: %s; selections %s" % (d.get("picks"), d.get("selections")))
    L.append("- ETFs left out: %s (%s)" % (d.get("etf", {}).get("count"), d.get("etf", {}).get("source")))
    L.append("- bars: %s" % d.get("bars"))
    if kind == "evaluation":
        L.append("- discovery run %s, frozen %s" % (res.get("discovery_run"), res.get("frozen", {}).get("frozen_at")))
    else:
        L.append("- **IN-SAMPLE (2020-22, sealed).** Every gate below is descriptive here; only the evaluation decides.")
    L.append("")
    for eng, E in res["engines"].items():
        bk = E["books"]
        L.append("## Engine %s - %s, %s selections, money-view span %s" % (eng, bk["pool"], bk["selections"],
                                                                           bk["span"]))
        L.append("")
        L.append("### Gates")
        L.append("")
        L.append("| candidate | G1 capture vs PLAN_B (lower bound > -0.10) | G2a per trade vs PLAN_native | p max-t | "
                 "G2b daily vs B2T | p max-t | G3 max DD vs PLAN_native | ACCEPT |")
        L.append("|---|---|---|---|---|---|---|---|")
        for g in bk["gates"]:
            L.append("| %s | %s %s | %s %s | %s | %s %s | %s | %s vs %s %s | **%s** |" % (
                g["name"], _pts(g["G1"]["diff"]), "pass" if g["G1"]["pass"] else "FAIL", _bp(g["G2a"]["diff"]),
                "pass" if g["G2a"]["pass"] else "FAIL", "%.4f" % g["G2a"].get("p_maxt", 1.0), _bp(g["G2b"]["diff"]),
                "pass" if g["G2b"]["pass"] else "FAIL", "%.4f" % g["G2b"].get("p_maxt", 1.0), _f(g["G3"]["max_dd"]),
                _f(g["G3"]["max_dd_plan_native"]), "pass" if g["G3"]["pass"] else "FAIL",
                "YES" if g["accepted"] else "no"))
        L.append("")
        L.append("Candidate minus its information-matched open entry (B2a) and minus PLAN_B (daily money view, per trade, "
                 "capture):")
        L.append("")
        L.append("| candidate | vs B2a daily | vs B2a per trade | vs B2a capture | vs PLAN_B daily |")
        L.append("|---|---|---|---|---|")
        for g in bk["gates"]:
            L.append("| %s | %s | %s | %s | %s |" % (g["name"], _bp(g["vs_B2a"]["daily"]), _bp(g["vs_B2a"]["per_trade"]),
                                                  _pts(g["vs_B2a"]["capture"]), _bp(g["vs_PLAN_B_daily"]["daily"])))
        L.append("")
        L.append("### Books (fully net; gross beside it; classes on net)")
        L.append("")
        L.append(BOOK_HEAD)
        order = ["PLAN_native", "PLAN_B", "B2T_V0", "B2T_V1", "B2T_V2"] + [g["name"] for g in bk["gates"]]
        order += [k for k in bk["books"] if k not in order]
        for k in order:
            if k in bk["books"]:
                L.append(_book_row(k, bk["books"][k]))
        L.append("")
        L.append("### Selection ledger (every selection, one line per book)")
        L.append("")
        st = ["TRADED", "MERGED", "NO_FILL", "NO_ROOM", "NO_LIQ", "HELD_SYMBOL", "NOT_ARMED", "INELIGIBLE", "EXCLUDED"]
        L.append("| book | " + " | ".join(st) + " |")
        L.append("|---|" + "---|" * len(st))
        for k in order:
            if k in bk["books"]:
                led = bk["books"][k]["ledger"]
                L.append("| %s | " % k + " | ".join(str(led.get(s, 0)) for s in st) + " |")
        L.append("")
        L.append("### By year (money-view return; trades and net per trade by entry year)")
        L.append("")
        for k in ["PLAN_native", "PLAN_B", "B2T_V0"] + [g["name"] for g in bk["gates"]]:
            if k not in bk["books"]:
                continue
            by = bk["books"][k]["by_year"]
            L.append("- %s: " % k + "; ".join("%s %s (%s trades, %s)" % (y, _f(v["return"]), v["trades"],
                                                                         _f(v["expectancy"])) for y, v in by.items()))
        L.append("")
        L.append("### Same trigger, different context (the critical requirement)")
        L.append("")
        L.append("Lift per armed order = trigger - f_train x B2 (acting at once with the same participation), exit V0. "
                 "Pairs: A minus B on shared session draws; Level 1: group minus the rest, two-sided max-t.")
        L.append("")
        L.append("Same-moment = from the close of the fill session, the filled pick over the next 5 sessions minus the "
                 "same day's picks (same engine) that had not filled by then (proposal 3).")
        L.append("")
        L.append("| family | armed | fill rate | trigger - B2 | skill vs B2p | vs B3b | same-moment | P1 | P2 | P3 | P4 | "
                 "Level 1 groups p < 0.05 |")
        L.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
        for fam, info in E["research"].items():
            itt, cx = info.get("itt") or {}, info.get("context") or {}
            pairs = cx.get("pairs_arming") or {}
            pc = []
            for pn in sorted(pairs):
                v = pairs[pn]
                pc.append("%s (p %s; n %s/%s)" % (_bp(v.get("a_minus_b")), "%.3f" % v["p_two_sided"]
                                                  if v.get("p_two_sided") is not None and np.isfinite(v["p_two_sided"]) else "-",
                                                  v.get("n_a"), v.get("n_b")))
            while len(pc) < 4:
                pc.append("-")
            l1 = cx.get("level1_arming") or {}
            sig = ["%s %s" % (g, _bp(v["contrast"])) for g, v in l1.items() if v.get("p_maxt", 1) < 0.05]
            sm = (info.get("same_moment") or {}).get("selection_skill")
            L.append("| %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s |" % (
                fam, info.get("counts", {}).get("armed", 0), _f(info.get("fill_rate"), 1, sign=False),
                _bp(itt.get("money_vs_b2")), _bp(itt.get("skill_vs_b2p")), _bp(itt.get("vs_b3b")), _bp(sm), pc[0],
                pc[1], pc[2], pc[3], "; ".join(sig) if sig else "none"))
        L.append("")
        if kind == "evaluation" and E.get("context_confirmation"):
            L.append("Discovery findings re-tested on the evaluation years:")
            L.append("")
            any_ = False
            for fam, rows in E["context_confirmation"].items():
                for r in rows:
                    any_ = True
                    L.append("- %s %s: discovery %s, evaluation %s -> %s" % (fam, r["what"], _bp(r["discovery"]),
                                                                             _bp(r["evaluation"]),
                                                                             "CONFIRMED" if r["confirmed"] else "not confirmed"))
            if not any_:
                L.append("- none: discovery flagged no context group or pair")
            L.append("")
        tb = (tables or {}).get(eng)
        if tb:
            a2 = tb["A2"]
            inel = [k for k, v in a2["eligible"].items() if not v]
            L.append("### Learned on discovery (frozen)")
            L.append("")
            L.append("- A2: f_train %s; %d Level 1 groups; ineligible: %s; risk multipliers: %s" % (
                _f(a2.get("f_train"), 1, sign=False), len(a2["eligible"]), ", ".join(map(str, inel)) or "none",
                ", ".join("%s x%.2f" % (k, v) for k, v in a2["risk"].items()) or "none"))
            ov = tb["A3"]["overrides"]
            L.append("- A3: %d Level 2 cells tested, %d overrides: %s" % (
                len(tb["A3"]["tested"]), len(ov), ", ".join("%s -> %s" % (k, v) for k, v in ov.items()) or "none"))
            L.append("")
        ex = bk.get("experiments") or {}
        if ex:
            L.append("### Experiments (adopt = daily interval above 0 and capture lower bound above -0.10)")
            L.append("")
            L.append("| experiment | a minus b: daily | per trade | capture | adopt |")
            L.append("|---|---|---|---|---|")
            for k, r in ex.items():
                dd = r["a_minus_b"]
                L.append("| %s | %s | %s | %s | %s |" % (k, _bp(dd["daily"]), _bp(dd["per_trade"]), _pts(dd["capture"]),
                                                       "yes" if r["adopt"] else "no"))
            L.append("")
        ex2 = bk.get("experiments_2022") or {}
        if ex2:
            L.append("Forecast experiments on 2022 only (pick_meta's forecasts are out of sample from 2022):")
            L.append("")
            for k, r in ex2.items():
                if k.startswith("E2") or k.startswith("E4"):
                    dd = r["a_minus_b"]
                    L.append("- %s: daily %s, per trade %s, capture %s" % (k, _bp(dd["daily"]), _bp(dd["per_trade"]),
                                                                           _pts(dd["capture"])))
            L.append("")
    return "\n".join(L) + "\n"
