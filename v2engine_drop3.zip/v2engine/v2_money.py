r"""v2_money.py - fully net returns and the money view (drop 3; Karan 31 Oct 19:55, correction 1).

Cost model = stage E's zerodha_base, the one every honest result in the project uses:
  buy    STT 0.1%, stamp duty 0.015%, NSE transaction 0.00322%, SEBI 0.0001%, GST 18% on (transaction + SEBI)
  sell   STT 0.1%, transaction, SEBI, GST, DP Rs 15.93 per stock per sell day
  impact square root: 0.5 x vol20 x sqrt(order value / ADV), on the entry and on the exit (entry-time vol20, ADV
         and order value, as stage E)
  tick   none at the entry, one at the exit (stage E's own tick-size function on real data)
ADV    = median close x volume of the 60 sessions up to the close before the entry session (stage E reads the
         panel's X_turnover_med, the same 60-session median, min 40 sessions); vol20 = sd of the last 20 daily close
         returns at that close. Both are known before the order.
Prices: the fill model gives a RAW execution price (an open, a buy-stop's trigger + slippage, a sell-stop's level -
slippage, a close). Gross return = raw exit / raw entry - 1. Net return = after impact, ticks, taxes and fees.

  CostModel        per-trade net at a declared order value (research view: Rs 1,25,000 = Rs 10 lakh / 8 slots,
                   capped at 2% of ADV like stage E); install() makes every v2_core net_return use it, so every
                   book and every baseline is costed by the same function
  simulate()       the money view: Rs 10 lakh, a slot = equity / slots (8 for the v2 budget, 15 for the original
                   3 a day x 5 sessions), integer shares, the 2% liquidity cap, cash limits, stage E's order of events
                   in a session (open sells, buys, intraday and close sells, mark to market)
  perf()           CAGR, max drawdown, utilisation, Sharpe, worst month - as stage E's perf()
"""
import math

import numpy as np

import v2_core as C

STAT = {"stt": 0.001, "stamp_buy": 0.00015, "txn": 0.0000322, "sebi": 0.000001, "gst": 0.18, "dp": 15.93}
IMPACT_K = 0.5            # zerodha_base
TICKS = {"entry": 0, "exit": 1}
NOTIONAL = 125000.0       # research view: Rs 10 lakh / 8 slots
LIQ_CAP = 0.02            # an order is at most 2% of ADV (stage E)
ADV_WINDOW, ADV_MIN, VOL_WINDOW = 60, 40, 20
CASH_RESERVE = 0.0025     # stage E: an order spends at most cash / (1 + 0.25%)
DAYS_PER_YEAR = 250


def flat_tick(day, price):
    """Synthetic worlds: Rs 0.05 for every price (real runs use stage E's tick-size function)."""
    return 0.05


def prepare_bars(b):
    """Adds 'adv' and 'vol20' (known at each close, on the stock's own bars; a missing bar carries the last value)."""
    c = np.asarray(b["close"], dtype=float)
    v = np.asarray(b["volume"], dtype=float)
    n = len(c)
    ok = ~np.isnan(c)
    pos = np.flatnonzero(ok)
    adv = np.full(n, np.nan)
    vol = np.full(n, np.nan)
    if len(pos):
        import pandas as pd
        cc, vv = c[pos], v[pos]
        a = pd.Series(cc * vv).rolling(ADV_WINDOW, min_periods=ADV_MIN).median().to_numpy(float)
        s = pd.Series(cc).pct_change().rolling(VOL_WINDOW, min_periods=VOL_WINDOW).std().to_numpy(float)  # = stage E
        last = np.maximum.accumulate(np.where(ok, np.arange(n), -1))        # the last bar at or before each session
        has = last >= 0
        k = np.searchsorted(pos, last[has])
        adv[has], vol[has] = a[k], s[k]
    b["adv"], b["vol20"] = adv, vol
    return b


class CostModel:
    """Stage E's zerodha_base costs. stage_e: the imported stage_e_execution module (real runs: its own functions
    are used and the replica is checked against them); None = the replica (tests)."""

    def __init__(self, days, notional=NOTIONAL, liq_cap=LIQ_CAP, tick_fn=flat_tick, stage_e=None):
        self.days = days
        self.notional, self.liq_cap = float(notional), float(liq_cap)
        self.tick_fn = tick_fn
        self.SE = stage_e
        self.sc = stage_e.primary_scenario() if stage_e is not None else None
        if stage_e is not None:
            check_against_stage_e(stage_e)

    # ---------------- the parts (replica, or stage E's own functions)
    def buy_costs(self, value):
        if self.SE is not None:
            return float(sum(self.SE.buy_costs(value, self.sc).values()))
        txn, sebi = value * STAT["txn"], value * STAT["sebi"]
        return value * STAT["stt"] + value * STAT["stamp_buy"] + txn + sebi + STAT["gst"] * (txn + sebi)

    def sell_costs(self, value, dp_due=True, buy_value=0.0):
        if self.SE is not None:
            return float(sum(self.SE.sell_costs(value, self.sc, dp_due, buy_value).values()))
        txn, sebi = value * STAT["txn"], value * STAT["sebi"]
        return value * STAT["stt"] + txn + sebi + STAT["gst"] * (txn + sebi) + (STAT["dp"] if dp_due else 0.0)

    def impact(self, value, adv, vol):
        if self.SE is not None:
            return float(self.SE.impact_frac(self.sc, value, adv, vol))
        if not (np.isfinite(adv) and adv > 0 and np.isfinite(vol)):
            return 0.0
        return float(IMPACT_K * vol * math.sqrt(max(value, 0.0) / adv))

    def tick(self, i, price, side):
        if self.SE is not None:
            return float(self.SE.tick_frac(self.sc, np.datetime64(self.days[i], "ns"), price, side))
        k = TICKS.get(side, 0)
        if k == 0 or not (price > 0):
            return 0.0
        return float(k * self.tick_fn(self.days[i], price) / price)

    # ---------------- one trade
    def order_value(self, b, e, budget=None):
        """The order's value: the budget (research: the declared notional), capped at 2% of the ADV known at the
        close before the entry. NaN when no ADV is known (stage E does not trade it)."""
        adv = b["adv"][e - 1] if e >= 1 else np.nan
        if not (np.isfinite(adv) and adv > 0):
            return np.nan
        v = self.notional if budget is None else float(budget)
        return min(v, self.liq_cap * adv)

    def trade(self, b, e, raw_in, x, raw_out, value=None):
        """Every number of one long trade at an order value (default: the research notional, liquidity-capped)."""
        if value is None:
            value = self.order_value(b, e)
            if not np.isfinite(value):
                value = self.notional            # research rows without ADV: costed at the notional, no impact
        adv = b["adv"][e - 1] if e >= 1 else np.nan
        vol = b["vol20"][e - 1] if e >= 1 else np.nan
        imp = self.impact(value, adv, vol)
        f_in = raw_in * (1.0 + imp + self.tick(e, raw_in, "entry"))
        f_out = raw_out * (1.0 - imp - self.tick(x, raw_out, "exit"))
        bc = self.buy_costs(value)
        sv = value * f_out / f_in
        scost = self.sell_costs(sv, True, value)
        net = (sv - scost - value - bc) / (value + bc)
        return {"net": float(net), "gross": float(raw_out / raw_in - 1.0), "fill_in": float(f_in),
                "fill_out": float(f_out), "impact": float(imp), "value": float(value),
                "cost_frac": float(raw_out / raw_in - 1.0 - net)}

    def net(self, b, e, raw_in, x, raw_out):
        return self.trade(b, e, raw_in, x, raw_out)["net"]


def check_against_stage_e(SE, tol=1e-9):
    """The replica must equal stage E's own functions (STT ... DP, impact, ticks off); refuse otherwise."""
    sc = SE.primary_scenario()
    if getattr(sc, "costs", None) != "zerodha_base":
        raise C.V2Error("stage E's primary scenario is not zerodha_base (%r)" % getattr(sc, "costs", None))
    st = getattr(SE, "STAT", None)
    if st != STAT:
        raise C.V2Error("stage E's STAT %r differs from v2_money's %r" % (st, STAT))
    k = SE.CFG.get("impact_k", {}).get("zerodha_base")
    if k != IMPACT_K:
        raise C.V2Error("stage E's impact_k for zerodha_base is %r, v2_money uses %r" % (k, IMPACT_K))
    rep = CostModel(None)
    for v in (5000.0, 125000.0, 1e6):
        a = float(sum(SE.buy_costs(v, sc).values()))
        if abs(a - rep.buy_costs(v)) > tol * max(1.0, a):
            raise C.V2Error("buy costs differ from stage E at %.0f: %r vs %r" % (v, a, rep.buy_costs(v)))
        s_ = float(sum(SE.sell_costs(v, sc, True, v).values()))
        if abs(s_ - rep.sell_costs(v, True, v)) > tol * max(1.0, s_):
            raise C.V2Error("sell costs differ from stage E at %.0f" % v)
        for adv, vol in ((1e7, 0.02), (5e8, 0.035)):
            i1, i2 = float(SE.impact_frac(sc, v, adv, vol)), rep.impact(v, adv, vol)
            if abs(i1 - i2) > tol:
                raise C.V2Error("impact differs from stage E (%r vs %r)" % (i1, i2))
    return True


def install(cm):
    """Every v2_core net_return (research rows, books, baselines, PLAN) uses this model from now on."""
    C.COST_MODEL["fn"] = cm.net
    C.COST_MODEL["model"] = cm


def uninstall():
    C.COST_MODEL["fn"] = None
    C.COST_MODEL.pop("model", None)


# ============================================================================ the money view
def simulate(cal, bars, trades, cm, capital=1e6, slots=8, t_lo=0, t_hi=None, integer=True, liq_cap=LIQ_CAP):
    """trades: book trades (entry_idx, entry_raw, exit_idx, exit_raw, timing 'open' / 'intraday' / 'close', symbol).
    The book has already applied its budget; this sizes them in rupees. Returns the equity path and every trade
    with its rupee result; trades cash or the cap could not fund are listed as skipped."""
    n = cal.n
    t_hi = n - 1 if t_hi is None else t_hi
    by_entry = {}
    for k, tr in enumerate(trades):
        if t_lo <= tr["entry_idx"] <= t_hi:
            by_entry.setdefault(tr["entry_idx"], []).append(k)
    cash = float(capital)
    prev_eq = cash
    opened, done, skipped = [], [], []
    last_close = {}
    eq = np.full(n, np.nan)
    inv = np.zeros(n)
    npos = np.zeros(n, dtype=int)

    def sell(p, i, dp_due):
        nonlocal cash
        b = bars[p["symbol"]]
        tr = p["tr"]
        raw = tr["exit_raw"]
        slip = cm.impact(p["buy_value"], p["adv"], p["vol"]) + cm.tick(i, raw, "exit")
        fill = raw * (1.0 - slip)
        sv = p["shares"] * fill
        sc = cm.sell_costs(sv, dp_due, p["buy_value"])
        cash += sv - sc
        pnl = sv - sc - p["buy_value"] - p["buy_cost"]
        done.append({**{k: tr[k] for k in ("sid", "symbol", "entry_idx", "exit_idx", "reason") if k in tr},
                     "shares": p["shares"], "buy_value": p["buy_value"], "pnl": pnl,
                     "ret": pnl / (p["buy_value"] + p["buy_cost"]), "gross": raw / tr["entry_raw"] - 1.0,
                     "capped": p["capped"], "b": b is not None})

    for i in range(t_lo, t_hi + 1):
        dp_today = set()
        still = []
        for p in opened:
            tr = p["tr"]
            if tr["exit_idx"] == i and tr["timing"] == "open":
                sell(p, i, p["symbol"] not in dp_today)
                dp_today.add(p["symbol"])
            else:
                still.append(p)
        opened = still
        for k in by_entry.get(i, []):
            tr = trades[k]
            b = bars[tr["symbol"]]
            per = prev_eq / slots
            adv = b["adv"][i - 1] if i >= 1 else np.nan
            vol = b["vol20"][i - 1] if i >= 1 else np.nan
            if not (np.isfinite(adv) and adv > 0):
                skipped.append({"sid": tr.get("sid"), "why": "NO_LIQ"})
                continue
            value, capped = per, False
            if liq_cap is not None and liq_cap * adv < value:
                value, capped = liq_cap * adv, True
            fill = tr["entry_raw"] * (1.0 + cm.impact(value, adv, vol) + cm.tick(i, tr["entry_raw"], "entry"))
            budget = min(value, cash / (1.0 + CASH_RESERVE))
            shares = math.floor(budget / fill) if integer else budget / fill
            if shares <= 0:
                skipped.append({"sid": tr.get("sid"), "why": "CASH"})
                continue
            bv = shares * fill
            bc = cm.buy_costs(bv)
            cash -= bv + bc
            opened.append({"tr": tr, "symbol": tr["symbol"], "shares": shares, "buy_value": bv, "buy_cost": bc,
                           "adv": adv, "vol": vol, "capped": capped})
        still = []
        for p in opened:
            tr = p["tr"]
            if tr["exit_idx"] == i and tr["timing"] in ("intraday", "close"):
                sell(p, i, p["symbol"] not in dp_today)
                dp_today.add(p["symbol"])
            else:
                still.append(p)
        opened = still
        val = 0.0
        for p in opened:
            c = bars[p["symbol"]]["close"][i]
            if not np.isnan(c):
                last_close[id(p)] = c
            val += p["shares"] * last_close.get(id(p), p["buy_value"] / p["shares"])
        eq[i] = cash + val
        inv[i] = val
        npos[i] = len(opened)
        prev_eq = eq[i]
    return {"equity": eq[t_lo:t_hi + 1], "invested": inv[t_lo:t_hi + 1], "positions": npos[t_lo:t_hi + 1],
            "t_lo": t_lo, "t_hi": t_hi, "trades": done, "skipped": skipped, "open_at_end": len(opened),
            "capital": float(capital), "slots": slots}


def perf(sim, days=None):
    """Stage E's measures on a money-view path (CAGR on 250 sessions a year)."""
    eq = np.asarray(sim["equity"], dtype=float)
    eq0 = np.r_[sim["capital"], eq]
    r = eq0[1:] / eq0[:-1] - 1.0
    n = len(r)
    yrs = max(n / DAYS_PER_YEAR, 1e-9)
    cagr = (eq0[-1] / eq0[0]) ** (1.0 / yrs) - 1.0 if eq0[-1] > 0 else -1.0
    dd = eq0 / np.maximum.accumulate(eq0) - 1.0
    sd = float(np.std(r, ddof=1)) if n > 1 else np.nan
    util = float(np.mean(np.asarray(sim["invested"]) / eq)) if n else np.nan
    out = {"cagr": float(cagr), "total_return": float(eq0[-1] / eq0[0] - 1.0), "max_dd": float(dd.min()),
           "sharpe": float(r.mean() / sd * math.sqrt(DAYS_PER_YEAR)) if sd and sd > 0 else np.nan,
           "vol": float(sd * math.sqrt(DAYS_PER_YEAR)) if sd == sd else np.nan, "worst_day": float(r.min()) if n else np.nan,
           "utilisation": util, "final_equity": float(eq0[-1]), "sessions": int(n),
           "trades": len(sim["trades"]), "skipped": len(sim["skipped"]), "open_at_end": sim["open_at_end"]}
    if days is not None and n:
        mo = np.asarray(days[sim["t_lo"]:sim["t_hi"] + 1]).astype("datetime64[M]")
        cut = np.r_[np.flatnonzero(mo[1:] != mo[:-1]), n - 1]
        me = eq0[1:][cut]
        mret = me / np.r_[eq0[0], me[:-1]] - 1.0
        out["worst_month"], out["pos_months"] = float(mret.min()), float(np.mean(mret > 0))
    t = sim["trades"]
    if t:
        rr = np.array([x["ret"] for x in t])
        out.update({"trade_expectancy": float(rr.mean()), "trade_win_rate": float(np.mean(rr > 0)),
                    "calmar": float(cagr / abs(dd.min())) if dd.min() < 0 else np.nan})
    return out


def daily_returns(sim):
    eq0 = np.r_[sim["capital"], np.asarray(sim["equity"], dtype=float)]
    return eq0[1:] / eq0[:-1] - 1.0
