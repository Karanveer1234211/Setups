r"""v2_data.py - real data for v2 (drop 3): production read through tradelab (READ ONLY), mapped onto v2's inputs.

  calendar   NIFTY 50's sessions (tradelab's Market.cal); sealed runs end it at the seal - nothing after the seal
             is loaded at all (bars, states, events, regimes and picks are all cut there)
  bars       stage E's loader (tradelab DailySeries); a bar with its high below its open / close (or the low above)
             is repaired to cover them and counted; lock flags from stage E's own lower_locked rule:
               ll_open / ll_close   the open / close sits locked at the lower band (an exit there waits)
               lower_locked         a frozen bar (o = h = l = c, locked at the close): nothing sells that session
               upper_locked         a frozen up-move bar (o = h = l = c above the previous close): nothing buys
             Wilder ATR14 known at each close (v2_core), ADV (60-session median close x volume) and vol20 (v2_money)
  contexts   tl_state on the stock's own bars up to each close: primary state, the shown event (kind:status, its
             age); tl_context's market environment of every session (needs breadth: a saved copy under
             TRADELAB_OUT / PATHLAB_OUT / V2_OUT\context, else counted once and saved to V2_OUT)
  events     tl_state's S04 breakouts and S10 breakdowns as known at each close (level, start, status) for T1-3 /
             T1-5; swing highs confirmed 3 bars after the pivot (X4)
  picks      pick_meta's research run through tradelab (SHA-256 checked; recorded outcomes renamed *_recorded and
             never read): D and ENS, ranks 1-10; ETFs out (NSE's list when present plus the BEES / ETF / IETF name
             rule, as pathlab); the forecasts (prob_*, pred_*) ride on each selection as pm_* for E2 / E4
  costs      v2_money.CostModel on stage E's own cost functions (checked against the replica at load)
Nothing here writes anywhere except the breadth copy under V2_OUT\context (only when no saved copy exists).
"""
import os
import re
import time
from pathlib import Path

import numpy as np

import v2_core as C
import v2_ctx as X
import v2_money as M

TRADELAB_WANTED = "tradelab v1.3.1"
ETF_SUFFIX = re.compile(r"(BEES|IETF|ETF)$")
LOCK_PREFILTER = -0.015          # a lower-band lock needs a move of at least -2% (the smallest band); -1.5% is safe


class Data:
    """Everything a v2 run reads, on one calendar."""

    def __init__(self):
        self.cal = self.bars = self.registry = self.cm = None
        self.ctx, self.events, self.home, self.index_bars = {}, {}, {}, {}
        self.regime = None
        self.info = {}
        self.sealed_end = None


def tradelab_modules(any_version=False):
    try:
        import tl_common as TC
        import tl_context as TX
        import tl_data as TD
        import tl_state as TS
    except ImportError as e:
        raise C.V2Error("cannot import tradelab (%s). Start with env_v2.bat: it puts tradelab and bigmove_deploy"
                        "\\open_close on PYTHONPATH (read only)" % e)
    if TC.VERSION != TRADELAB_WANTED and not any_version:
        raise C.V2Error("tradelab at %s is %s; v2engine drop 3 was tested against %s. Pass --tradelab-any to accept "
                        "it knowingly." % (Path(TC.__file__).parent, TC.VERSION, TRADELAB_WANTED))
    if getattr(TS, "EVENT_NUM", None) != X.EVENT_NUM:
        raise C.V2Error("tl_state's EVENT_NUM differs from v2_ctx's - a tradelab change; v2 needs updating first")
    return TC, TD, TS, TX


def etf_symbols(root, syms, log=print):
    """pathlab's rule when pathlab is importable (NSE's list + name rule + PATHLAB_OUT\\ref corrections); else the
    name rule plus %CACHE_DAILY_ROOT%\\sectors\\eq_etfseclist.csv when present."""
    try:
        import pl_coverage as PV
        base = Path(os.environ.get("PATHLAB_OUT", str(Path(root) / "_no_pathlab_out")))
        return PV.etf_symbols(Path(root), base, syms)
    except ImportError:
        pass
    import pandas as pd
    out = {s for s in syms if ETF_SUFFIX.search(str(s).upper())}
    src = "the name rule alone (BEES / ETF / IETF endings) - incomplete"
    p = Path(root) / "sectors" / "eq_etfseclist.csv"
    if p.exists():
        E = pd.read_csv(p, dtype=str)
        col = next((c for c in E.columns if str(c).strip().lower() == "symbol"), None)
        if col is None:
            raise C.V2Error("%s has no Symbol column" % p)
        listed = {str(s).strip().upper() for s in E[col].dropna()}
        out |= {s for s in syms if str(s).upper() in listed}
        src = "NSE's ETF list %s plus the name rule" % p
    return out, src


def _breadth(TX, market, ib, need_last, log):
    bases = []
    for env in ("TRADELAB_OUT", "PATHLAB_OUT", "V2_OUT"):
        if os.environ.get(env):
            bases.append((env, Path(os.environ[env])))
    for nm, b in bases:
        got = TX.load_breadth(b)
        if got is None:
            continue
        last = str(got[1].get("calendar_last"))
        if last < str(need_last):
            log("   breadth: %s's copy ends %s, before %s - not used" % (nm, last, need_last))
            continue
        return got[0], "%s (%s), built %s" % (nm, b, got[1].get("built"))
    out = os.environ.get("V2_OUT")
    if not out:
        raise C.V2Error("no saved breadth copy covers the calendar and V2_OUT is not set (env_v2.bat sets it)")
    syms = TX.cache_stock_symbols(market)
    log("   breadth: counting advancers / decliners over %d cached stocks (once; saved to %s\\context) ..." %
        (len(syms), out))
    breadth, meta = TX.ad_breadth(market, ib.cal, syms, log=log)
    import datetime as _dt
    meta.update({"version": TX.CTX_VERSION, "built": _dt.datetime.now().isoformat(timespec="seconds"),
                 "calendar_last": str(ib.cal[-1]), "built_by": C.VERSION})
    TX.save_breadth(Path(out), breadth, meta)
    return breadth, "counted now, saved to %s" % out


def regimes(TX, market, cal_days, log=print):
    """tl_context's environment of every session (codes as v2_ctx.REGIMES; -1 = unknown)."""
    ib = TX.IndexBook(market)
    core = [k for k in ("nifty", "mid", "small", "vix") if k in ib.missing]
    if core:
        raise C.V2Error("index files missing from the cache: %s (the regime needs NIFTY 50, Midcap 150, Smallcap 250 "
                        "and India VIX)" % ", ".join(TX.SPEC[k][0] for k in core))
    breadth, src = _breadth(TX, market, ib, cal_days[-1], log)
    F = TX.market_frame(ib, breadth)
    env = F["environment"].astype(str).to_numpy()
    code = np.array([X.REGIMES.index(e) if e in X.REGIMES else -1 for e in env], dtype=np.int64)
    pos = np.searchsorted(ib.cal, cal_days)
    ok = (pos < len(ib.cal))
    ok[ok] = ib.cal[pos[ok]] == cal_days[ok]
    out = np.full(len(cal_days), -1, dtype=np.int64)
    out[ok] = code[pos[ok]]
    return out, ib, src


def _side(kind):
    return "up" if kind in ("BREAKOUT", "FAILED_BREAKOUT") else "dn"


def symbol_inputs(sym, ds, ss, cal_days, n_cal_end):
    """Per symbol, on the calendar: bar arrays with lock flags, contexts, events. ds: tradelab DailySeries; ss:
    tl_state StateSeries on the same bars cut at the calendar's end (nb bars)."""
    n = len(cal_days)
    nb = n_cal_end
    d = ds.dates[:nb]
    o, h, l, c = (np.asarray(x[:nb], dtype=float) for x in (ds.o, ds.h, ds.l, ds.c))
    v = np.asarray(ds.v[:nb], dtype=float)
    diag = {"bars": int(nb)}
    bad = ~(np.isfinite(o) & np.isfinite(h) & np.isfinite(l) & np.isfinite(c)) | ~(o > 0) | ~(c > 0) | ~(l > 0)
    diag["unusable_bars"] = int(bad.sum())
    with np.errstate(invalid="ignore"):
        rep = ~bad & ((h < np.fmax(o, c)) | (l > np.fmin(o, c)))
    diag["repaired_bars"] = int(rep.sum())
    h2, l2 = np.where(rep, np.fmax(h, np.fmax(o, c)), h), np.where(rep, np.fmin(l, np.fmin(o, c)), l)
    ci = np.searchsorted(cal_days, d)
    okc = ci < n
    okc[okc] = cal_days[ci[okc]] == d[okc]
    use = okc & ~bad
    diag["off_calendar_bars"] = int((~okc).sum())
    rec = {f: np.full(n, np.nan) for f in ("open", "high", "low", "close", "volume")}
    for f, x in (("open", o), ("high", h2), ("low", l2), ("close", c), ("volume", v)):
        rec[f][ci[use]] = x[use]
    for f in ("upper_locked", "lower_locked", "ll_open", "ll_close"):
        rec[f] = np.zeros(n, dtype=bool)
    prev = np.r_[np.nan, c[:-1]]
    with np.errstate(invalid="ignore", divide="ignore"):
        flat = (o == h) & (h == l) & (l == c)
        cand_c = use & (c <= l * (1 + 1e-9)) & (c / prev - 1.0 <= LOCK_PREFILTER)
        cand_o = use & (o <= l * (1 + 1e-9)) & (o / prev - 1.0 <= LOCK_PREFILTER)
        up = use & flat & (c > prev)
    nl = {"close": 0, "open": 0, "frozen": 0}
    for j in np.flatnonzero(cand_c):
        if ds.locked(int(j), "close"):
            rec["ll_close"][ci[j]] = True
            nl["close"] += 1
            if flat[j]:
                rec["lower_locked"][ci[j]] = True
                nl["frozen"] += 1
    for j in np.flatnonzero(cand_o):
        if ds.locked(int(j), "open"):
            rec["ll_open"][ci[j]] = True
            nl["open"] += 1
    rec["upper_locked"][ci[up]] = True
    diag.update({"ll_close": nl["close"], "ll_open": nl["open"], "frozen": nl["frozen"], "up_frozen": int(up.sum())})
    # contexts and events (stock positions -> calendar, carried forward over sessions without a bar)
    at = np.full(n, -1, dtype=np.int64)
    at[ci[okc]] = np.flatnonzero(okc)
    last = np.maximum.accumulate(at)
    has = last >= 0

    def on_cal(x, fill, dtype):
        out = np.full(n, fill, dtype=dtype)
        out[has] = np.asarray(x)[last[has]]
        return out

    st = np.array([X.STATE_CODES.get(s, 0) for s in ss.state[:nb]], dtype=np.int64)
    ek = ss.ev_kind[:nb]
    evc = np.array([X.EVENT_NUM.get("%s:%s" % (k, s) if k else "", 0) for k, s in zip(ek, ss.ev_status[:nb])],
                   dtype=np.int64)
    age = np.where(np.asarray(ek, dtype=object) != "", np.arange(nb) - np.asarray(ss.ev_start[:nb]), -1)
    ctx = {"state": on_cal(st, -1, np.int64), "event": on_cal(evc, 0, np.int64), "age": on_cal(age, -1, np.int64)}
    cal_of = np.where(okc, ci, -1)
    ev = {}
    for side, pre in (("up", "s04"), ("dn", "s10")):
        start = np.full(nb, -1, dtype=np.int64)
        level = np.full(nb, np.nan)
        status = np.full(nb, "", dtype=object)
        ents = sorted([e for e in ss.event_log if _side(e["kind"]) == side and int(e["change"]) < nb],
                      key=lambda e: (int(e["change"]), int(e["start"])))
        for k, e in enumerate(ents):
            j0 = int(e["change"])
            j1 = int(ents[k + 1]["change"]) if k + 1 < len(ents) else nb
            s0 = int(e["start"])
            start[j0:j1] = cal_of[s0] if 0 <= s0 < nb else -1
            level[j0:j1] = float(e["level"])
            status[j0:j1] = str(e["status"])
        ev[pre + "_start"] = on_cal(start, -1, np.int64)
        ev[pre + "_level"] = on_cal(level, np.nan, float)
        ev[pre + "_status"] = on_cal(status, "", object)
    kk = int(ss.cfg.get("swing_k", 3))
    piv = np.asarray(getattr(ss, "piv_hi", []), dtype=np.int64)
    ev["swing_highs"] = [(int(cal_of[p + kk]), float(h[p])) for p in piv if p + kk < nb and cal_of[p + kk] >= 0]
    ev["exit"] = None
    return rec, ctx, ev, diag


def load_real(root, pm_run, engines=("D", "ENS"), ranks=tuple(range(1, 11)), t_first="2020-01-01", t_last=None,
              seal_end=None, warmup_sessions=320, stage_e_any=False, tradelab_any=False, log=print,
              max_symbols=None, with_home=True, costs="stage_e"):
    """Signal days t_first .. t_last (inclusive); seal_end: nothing after this day is loaded (the calendar ends)."""
    t0 = time.time()
    TC, TD, TS, TX = tradelab_modules(tradelab_any)
    prod = TD.Production(stage_e_any)
    market = TD.Market(Path(root), prod)
    D = Data()
    cal_all = np.asarray(market.cal).astype("datetime64[D]")
    end = np.datetime64(seal_end, "D") if seal_end else cal_all[-1]
    lo = np.datetime64(t_first, "D")
    p0 = max(0, int(np.searchsorted(cal_all, lo)) - warmup_sessions)
    p1 = int(np.searchsorted(cal_all, end, side="right"))
    days = cal_all[p0:p1]
    if len(days) < 2:
        raise C.V2Error("the calendar %s .. %s holds fewer than two sessions" % (cal_all[p0] if p0 < len(cal_all)
                                                                                 else "-", end))
    D.cal = C.SessionCalendar(days.tolist())
    D.sealed_end = str(end) if seal_end else None
    D.info.update({"version": C.VERSION, "tradelab": TC.VERSION, "stage_e": prod.describe(),
                   "calendar": [str(days[0]), str(days[-1]), int(len(days))], "sealed_end": D.sealed_end})
    log("   calendar: %s .. %s (%d sessions)%s" % (days[0], days[-1], len(days),
                                                  "  SEALED at %s" % end if seal_end else ""))
    hi = np.datetime64(t_last, "D") if t_last else end
    hi = min(hi, end)
    T, pinfo = TD.load_picks(Path(root), pm_run, list(engines), list(ranks), lo, hi)
    D.info["picks"] = {k: pinfo[k] for k in ("file", "sha256", "rows_selected", "first_day", "last_day") if k in pinfo}
    syms = sorted(set(T["symbol"].astype(str)))
    etf, etf_src = etf_symbols(root, syms, log)
    D.info["etf"] = {"source": etf_src, "count": len(etf & set(syms)), "symbols": sorted(etf & set(syms))}
    syms = [s for s in syms if s not in etf]
    if max_symbols:
        syms = syms[:int(max_symbols)]
    log("   picks: %d rows, %d symbols (%d ETFs left out by %s)" % (len(T), len(syms), D.info["etf"]["count"], etf_src))
    D.regime, ib, bsrc = regimes(TX, market, days, log)
    D.info["breadth"] = bsrc
    if costs == "stage_e":
        D.cm = M.CostModel(D.cal.days, stage_e=prod.EX)        # stage E's own functions, checked against the replica
    elif costs == "replica":                                   # tests only (the stand-in stage E has no cost code)
        D.cm = M.CostModel(D.cal.days)
    else:
        raise C.V2Error("costs must be stage_e or replica")
    D.info["costs"] = costs
    bars = C.BarStore(D.cal)
    agg = {}
    exposure = TX.Exposure(ib) if with_home else None
    pos_series = {}
    for b0 in range(0, len(syms), 100):
        chunk = syms[b0:b0 + 100]
        market.load(chunk)
        for s in chunk:
            ds = market.series(s)
            if ds is None or len(ds) < 2:
                agg["no_bars"] = agg.get("no_bars", 0) + 1
                continue
            nb = int(np.searchsorted(ds.dates, end, side="right"))
            if nb < 2:
                agg["no_bars"] = agg.get("no_bars", 0) + 1
                continue
            ss = TS.StateSeries(s, ds.dates[:nb], ds.o[:nb], ds.h[:nb], ds.l[:nb], ds.c[:nb], ds.v[:nb])
            rec, ctx, ev, dg = symbol_inputs(s, ds, ss, days, nb)
            bars.put_arrays(s, rec)
            M.prepare_bars(bars[s])
            D.ctx[s], D.events[s] = ctx, ev
            pos_series[s] = ds
            for k, v in dg.items():
                agg[k] = agg.get(k, 0) + v
        log("   bars and states: %d / %d symbols (%.0f s)" % (min(b0 + 100, len(syms)), len(syms), time.time() - t0))
    D.bars = bars
    D.info["bars"] = agg
    # index bars for T1-7 (the home index of each selection, at T)
    if with_home:
        for k in ("nifty", "mid", "small"):
            ds = market.series(TX.SPEC[k][0])
            if ds is None:
                continue
            j = np.searchsorted(ds.dates, days)
            ok = j < len(ds.dates)
            ok[ok] = ds.dates[j[ok]] == days[ok]
            hh, cc = np.full(len(days), np.nan), np.full(len(days), np.nan)
            hh[ok], cc[ok] = ds.h[j[ok]], ds.c[j[ok]]
            D.index_bars[k] = {"high": hh, "close": cc}
    # the selections
    reg = C.SelectionRegistry(D.cal)
    drop = {"not_a_session": 0, "no_bars": 0, "etf": 0, "engine": 0}
    fc = [c for c in T.columns if (c.startswith("prob_") or c.startswith("pred_")) and not c.startswith("label_")]
    sd = np.asarray(T["signal_day"].to_numpy(dtype="datetime64[ns]")).astype("datetime64[D]")
    for row, d in zip(T.itertuples(index=False), sd):
        s = str(row.symbol)
        if s in etf:
            drop["etf"] += 1
            continue
        if s not in bars.data:
            drop["no_bars"] += 1
            continue
        if not D.cal.has(d):
            drop["not_a_session"] += 1
            continue
        if str(row.engine) not in C.SelectionRegistry.ENGINES:
            drop["engine"] += 1
            continue
        i = D.cal.idx(d)
        snap = X.snapshot(D.ctx[s], D.regime, i)
        for c in fc:
            val = getattr(row, c, np.nan)
            try:
                snap["pm_" + c] = float(val)
            except (TypeError, ValueError):
                pass
        sel = reg.add(pm_run, str(row.engine), int(row.rank), d, s, float(getattr(row, "score", np.nan)), snap)
        if with_home and exposure is not None:
            ds = pos_series.get(s)
            j = ds.idx(d) if ds is not None else -1
            if j >= 0:
                hm = exposure.of(ds, j).get("home_index", "")
                if hm:
                    D.home[sel.sid] = hm
    D.registry = reg
    D.info["selections"] = {"added": len(reg.active()), "dropped": drop}
    log("   selections: %d (dropped %s) - %.0f s" % (len(reg.active()), drop, time.time() - t0))
    return D
