r"""v2engine.py - command line for the BigMove v2 execution engine (drop 3).

    python v2engine.py --selftest [quick]      the verification suite (synthetic worlds and a fake production cache)
    python v2engine.py --version
    python v2engine.py discover --root <cache root> --out <v2 output folder>
    python v2engine.py freeze   --discovery <out>\discover_<run id> --out <v2 output folder>
    python v2engine.py evaluate --discovery <out>\discover_<run id> --root <cache root> --out <v2 output folder>

discover  reads production READ ONLY through tradelab, sealed at the declaration's seal (2022-12-31): nothing after it
          is loaded. Writes discovery.json, tables.json and REPORT_DISCOVERY.md (in-sample, descriptive).
freeze    records the declaration, the learned tables, the discovery output and every v2 module (SHA-256). Once.
evaluate  refused unless the freeze still matches; the 2023-25 evaluation with the frozen rules; the gates decide.
Options: --declaration <file> (default V2_DROP3_DECLARATION.json next to this file), --stage-e-any, --tradelab-any
(accept a stage_e_execution / tradelab other than the tested versions, knowingly), --max-symbols N (a quick look on
the first N symbols; such a run is marked PARTIAL and can never be frozen).
There is no default cache path: --root is required.
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from v2_core import VERSION, V2Error  # noqa: E402


def _args(argv):
    ap = argparse.ArgumentParser(prog="v2engine.py", description="BigMove v2 execution engine (%s)" % VERSION)
    ap.add_argument("command", choices=("discover", "freeze", "evaluate"))
    ap.add_argument("--root", help="the daily cache root (%%CACHE_DAILY_ROOT%%); required for discover / evaluate")
    ap.add_argument("--out", required=True, help="the v2 output folder (%%V2_OUT%%)")
    ap.add_argument("--discovery", help="a discovery run folder (freeze / evaluate)")
    ap.add_argument("--declaration", help="the declaration file (default: V2_DROP3_DECLARATION.json here)")
    ap.add_argument("--stage-e-any", action="store_true")
    ap.add_argument("--tradelab-any", action="store_true")
    ap.add_argument("--max-symbols", type=int, default=None)
    return ap.parse_args(argv)


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if not argv:
        print(VERSION)
        print(__doc__)
        return 2
    if argv[0] == "--version":
        print(VERSION)
        return 0
    if argv[0] == "--selftest":
        sys.path.insert(0, str(Path(__file__).resolve().parent / "tests"))
        import test_v2
        return test_v2.main(argv[1:])
    try:
        a = _args(argv)
    except SystemExit as e:
        return int(e.code or 2)
    import v2_run as R
    try:
        decl, sha, dpath = R.load_decl(a.declaration)
        out = Path(a.out)
        print("%s  %s  declaration %s (sha256 %s)" % (VERSION, a.command, dpath, sha[:16]))
        if a.command in ("discover", "evaluate"):
            if not a.root:
                print("ERROR: --root is required (there is no default cache path)")
                return 2
            if not Path(a.root).is_dir():
                print("ERROR: --root %s is not a folder" % a.root)
                return 2
            import v2_data as VD
            I = decl["inputs"]
            if a.command == "discover":
                P = decl["periods"]["discovery"]
                data = VD.load_real(a.root, I["picks_run"], tuple(I["engines"]), tuple(I["ranks_loaded"]),
                                    P["first_signal_day"], P["last_signal_day"], seal_end=P["seal_end"],
                                    stage_e_any=a.stage_e_any, tradelab_any=a.tradelab_any, max_symbols=a.max_symbols)
                rid = R.run_id("discover" if not a.max_symbols else "PARTIAL_discover")
                rdir = R.discover(data, decl, sha, out, rid=rid)
                print("next: python v2engine.py freeze --discovery %s --out %s" % (rdir, out))
                return 0
            if not a.discovery:
                print("ERROR: --discovery <discover run folder> is required")
                return 2
            P = decl["periods"]["evaluation"]
            R.check_frozen(a.discovery, sha)            # refuse before loading anything
            data = VD.load_real(a.root, I["picks_run"], tuple(I["engines"]), tuple(I["ranks_loaded"]),
                                P["first_signal_day"], P["last_signal_day"], seal_end=None,
                                stage_e_any=a.stage_e_any, tradelab_any=a.tradelab_any, max_symbols=a.max_symbols)
            R.evaluate(data, decl, sha, a.discovery, out)
            return 0
        if a.command == "freeze":
            if not a.discovery:
                print("ERROR: --discovery <discover run folder> is required")
                return 2
            if "PARTIAL" in Path(a.discovery).name:
                print("ERROR: a --max-symbols run (PARTIAL) is never frozen")
                return 2
            R.freeze(a.discovery, sha, out)
            print("next: python v2engine.py evaluate --discovery %s --root %%CACHE_DAILY_ROOT%% --out %s" % (
                a.discovery, out))
            return 0
    except V2Error as e:
        print("REFUSED: %s" % e)
        return 3
    except Exception as e:  # tradelab's / pathlab's own refusals carry their reason; anything else is a crash
        if type(e).__name__ in ("TLError", "PLError", "StopRun"):
            print("REFUSED (%s): %s" % (type(e).__name__, e))
            return 3
        raise
    return 2


if __name__ == "__main__":
    sys.exit(main())
