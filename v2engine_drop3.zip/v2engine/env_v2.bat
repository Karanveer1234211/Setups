@echo off
rem env_v2.bat - v2engine 0.3 (drop 3): start a v2 session in cmd.
rem   call C:\Users\karanvsi\PyCharmMiscProject\v2engine\env_v2.bat
rem Reads production (the cache, pick_meta's run, stage E's code), tradelab and pathlab READ ONLY.
rem Writes only under V2_OUT. Edit the paths below if your folders differ.
set "BIGMOVE_DIR=C:\Users\karanvsi\PyCharmMiscProject\bigmove_deploy"
set "TRADELAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\tradelab"
set "PATHLAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\pathlab"
set "V2_DIR=C:\Users\karanvsi\PyCharmMiscProject\v2engine"
set "TRADELAB_OUT=C:\QuantData\tradelab"
set "PATHLAB_OUT=C:\QuantData\pathlab"
set "V2_OUT=C:\QuantData\v2engine"
if not exist "%BIGMOVE_DIR%\env_daily.bat" goto :no_env
if not exist "%TRADELAB_DIR%\tl_common.py" goto :no_tradelab
if not exist "%PATHLAB_DIR%\pathlab.py" goto :no_pathlab
if not exist "%V2_DIR%\v2engine.py" goto :no_v2
call "%BIGMOVE_DIR%\env_daily.bat"
if "%CACHE_DAILY_ROOT%"=="" goto :no_root
set "PYTHONPATH=%V2_DIR%;%PATHLAB_DIR%;%TRADELAB_DIR%;%BIGMOVE_DIR%\open_close;%BIGMOVE_DIR%"
if not exist "%V2_OUT%" mkdir "%V2_OUT%"
cd /d "%V2_DIR%"
echo v2engine ready: CACHE_DAILY_ROOT=%CACHE_DAILY_ROOT%   V2_OUT=%V2_OUT%
goto :eof
:no_env
echo ERROR: %BIGMOVE_DIR%\env_daily.bat not found - edit BIGMOVE_DIR at the top of env_v2.bat
exit /b 1
:no_tradelab
echo ERROR: tradelab not found at %TRADELAB_DIR% - edit TRADELAB_DIR at the top of env_v2.bat
exit /b 1
:no_pathlab
echo ERROR: pathlab.py not found in %PATHLAB_DIR% - edit PATHLAB_DIR at the top of env_v2.bat
exit /b 1
:no_v2
echo ERROR: v2engine.py not found in %V2_DIR% - edit V2_DIR at the top of env_v2.bat
exit /b 1
:no_root
echo ERROR: env_daily.bat ran but CACHE_DAILY_ROOT is empty
exit /b 1
