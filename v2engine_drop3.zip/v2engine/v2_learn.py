r"""v2_learn.py - choices made on training years, and the context tests (drop 2).

  replay_targets / learn_targets   X3: each R-grid target replayed on every training trade's own path;
                                   the family's target = best average net R; a context group's curve is
                                   pulled toward the family's with weight n / (n + k), k = 100 (declared)
  choose_policy                    each family's exit policy, chosen on training years by its own budgeted
                                   book's net return per session on the capital in use
  context_table                    Question B: per armed order, the lift against B2p (acting at once with
                                   the same participation) in each context group minus the lift elsewhere;
                                   two-sided max-t across the family's groups
  pool_cells                       Level 2: exact cells pooled toward their Level 1 group (empirical Bayes);
                                   decisions use the raw contrast, sizes the pooled estimate
"""
import numpy as np

from v2_core import R_GRID, x3
from v2_research import book_pnl, do_exit, run_book, settled
from v2_stats import eb_shrink, max_t, summary

SHRINK_K = 100.0


def replay_targets(cal, bars, rows, events_by_sym=None, grid=R_GRID):
    """Net result in R of every filled training row at each grid target (same entry, stop and events)."""
    out = np.full((len(rows), len(grid)), np.nan)
    for i, r in enumerate(rows):
        if not r["filled"]:
            continue
        b = bars[r["symbol"]]
        ev = events_by_sym.get(r["symbol"]) if events_by_sym else None
        px, stop = r["fill_px"], r["stop"]
        unit = (px - stop) / px
        if not (unit > 0):
            continue
        for j, g in enumerate(grid):
            ex = do_exit(b, cal, r["fill_idx"], px, "stop", x3(g), stop, ev)
            out[i, j] = ex["net"] / unit
    return out


def learn_targets(curves, groups=None, grid=R_GRID, k=SHRINK_K):
    """Family target and, per context group, the target from the group's curve shrunk toward the family's."""
    ok = ~np.all(np.isnan(curves), axis=1)
    fam = np.nanmean(curves[ok], axis=0)
    res = {"family": {"target_r": grid[int(np.nanargmax(fam))], "curve": fam.tolist(), "n": int(ok.sum())}}
    if groups is not None:
        keys = list(groups)
        for g in sorted({keys[i] for i in range(len(keys)) if ok[i]}, key=str):
            sel = ok & np.array([kk == g for kk in keys])
            n = int(sel.sum())
            raw = np.nanmean(curves[sel], axis=0)
            w = n / (n + k)
            shr = w * raw + (1 - w) * fam
            res[g] = {"target_r": grid[int(np.nanargmax(shr))], "raw_best": grid[int(np.nanargmax(raw))],
                      "weight": w, "n": n, "curve": shr.tolist()}
    return res


def choose_policy(cal, bars, registry, family, policies, t_lo, t_hi, budget, events_by_sym=None):
    """Exit policy for one family from training sessions [t_lo, t_hi): the family's own budgeted book,
    net return per session on the capital in use. Returns (best name, {name: value})."""
    sub = _Subset(registry, t_lo, t_hi)
    vals = {}
    for pol in policies:
        trades, _, _ = run_book(cal, bars, sub, [family], pol, "trigger", budget, events_by_sym=events_by_sym)
        P, C = book_pnl(cal, bars, trades)
        vals[pol.name()] = float(P.sum() / C.sum()) if C.sum() > 0 else float("nan")
    best = max(vals, key=lambda k: -np.inf if np.isnan(vals[k]) else vals[k])
    return best, vals


class _Subset:
    def __init__(self, registry, t_lo, t_hi):
        self._items = [s for s in registry.active() if t_lo <= s.t_idx < t_hi]

    def active(self):
        return self._items


def context_table(rows, f_train, boot, key, min_n=30):
    """Per group g: lift = trigger - f_train x B2 per armed order; contrast = mean lift in g minus
    mean lift in all other groups, on shared session draws; two-sided max-t across the groups."""
    rs = settled(rows)
    lift = np.array([r["trig"] - f_train * r["b2"] for r in rs])
    day = np.array([r["t_idx"] for r in rs])
    keys = [key(r) for r in rs]                      # tuples allowed (Level 2 cells)
    counts = {}
    for kk in keys:
        counts[kk] = counts.get(kk, 0) + 1
    names = [g for g in sorted(counts, key=str) if counts[g] >= min_n]
    table, obs, boots = {}, [], []
    for g in names:
        m = np.array([kk == g for kk in keys])
        mi, bi = boot.mean(*boot.by_day(day[m], lift[m]))
        mo, bo = boot.mean(*boot.by_day(day[~m], lift[~m]))
        c_obs, c_boot = mi - mo, bi - bo
        table[g] = {"n": int(m.sum()), "lift": summary(mi, bi), "contrast": summary(c_obs, c_boot)}
        obs.append(c_obs)
        boots.append(c_boot)
    if names:
        t, p = max_t(obs, boots, two_sided=True)
        for g, tg, pg in zip(names, t, p):
            table[g]["t"], table[g]["p_maxt"] = float(tg), float(pg)
    return table


def pool_cells(cell_table, parent_of):
    """Level 2: pool each exact cell's lift toward its Level 1 group's cells (empirical Bayes, by group)."""
    out = {}
    by_parent = {}
    for cell, row in cell_table.items():
        by_parent.setdefault(parent_of(cell), []).append(cell)
    for parent, cells in by_parent.items():
        means = [cell_table[c]["lift"]["mean"] for c in cells]
        ses = [cell_table[c]["lift"]["se"] for c in cells]
        ns = [cell_table[c]["n"] for c in cells]
        pooled, w, pm, tau2 = eb_shrink(means, ses, ns)
        for c, pv, wv in zip(cells, pooled, w):
            out[c] = {"parent": parent, "raw": cell_table[c]["lift"]["mean"], "pooled": float(pv), "weight": float(wv),
                      "parent_mean": float(pm), "tau2": float(tau2)}
    return out
