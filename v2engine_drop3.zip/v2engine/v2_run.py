r"""v2_run.py - drop 3 runs: discover (sealed 2020-22) -> freeze -> evaluate (2023-25).

discover   loads data sealed at 2022-12-31 (nothing after it exists for the run), and for each engine:
             - per family, research rows on the primary pool (every selection, armed or not) with exit V0: the
               trigger tests (vs B2 / B2p / B3b / B4), the same-moment selection test (proposal 3) and the context
               tests (Level 1, pairs P1-P4, Level 2 pooled)
             - learns A2's tables and A3's overrides from those rows
             - runs every candidate (A1 / A2 / A3 x V0 / V1 / V2) and every baseline as a budgeted book, money view,
               capture, quality and the gates - IN SAMPLE, descriptive only
             - experiments E1-E4 (descriptive; E2 / E4 on 2022 only)
           writes discovery.json, tables.json, REPORT_DISCOVERY.md under <out>\discover_<run id>
freeze     records the SHA-256 of the declaration, tables.json, discovery.json and every v2 module in frozen.json
evaluate   refused unless frozen.json matches the declaration, the tables and the code now; loads the full data,
           runs the frozen candidates and baselines on the evaluation years with the frozen tables, applies the gates
           (max-t across candidates for G2) and re-tests the discovery context findings; writes evaluation.json and
           REPORT_EVALUATION.md
Every run appends one line to <out>\v2_ledger.jsonl.
"""
import datetime as dt
import hashlib
import json
from pathlib import Path

import numpy as np

import v2_arch as A
import v2_book2 as B
import v2_core as C
import v2_ctx as X
import v2_eval as E
import v2_lab as LB
import v2_money as M
from v2_families import (BreakoutAcceptance, Confirm, Family, FailedBreakdown, HomeIndexTurn, SqueezeBurst,
                         TurnAfterDip)
from v2_research import Budget, fill_rate
from v2_stats import DayBoot

HERE = Path(__file__).resolve().parent
DECL_NAME = "V2_DROP3_DECLARATION.json"
CODE_FILES = ("v2_core.py", "v2_families.py", "v2_research.py", "v2_learn.py", "v2_stats.py", "v2_ctx.py", "v2_lab.py",
              "v2_arch.py", "v2_money.py", "v2_book2.py", "v2_eval.py", "v2_data.py", "v2_run.py", "v2_report.py",
              "v2engine.py")
TAIL = C.WINDOW + 40 + C.LOCK_WAIT + 2       # sessions a selection's trade can need after its signal day


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def jsonable(x):
    if isinstance(x, dict):
        return {(k if isinstance(k, str) else "|".join(map(str, k)) if isinstance(k, tuple) else str(k)): jsonable(v)
                for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [jsonable(v) for v in x]
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating, float)):
        v = float(x)
        return None if not np.isfinite(v) else v
    if isinstance(x, np.ndarray):
        return [jsonable(v) for v in x.tolist()]
    if isinstance(x, (np.bool_,)):
        return bool(x)
    return x


def write_json(p, obj):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(jsonable(obj), indent=1, sort_keys=True), encoding="utf-8")
    tmp.replace(p)


def ledger(out, rec):
    p = Path(out) / "v2_ledger.jsonl"
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8", newline="\n") as fh:
        fh.write(json.dumps(jsonable(rec), sort_keys=True) + "\n")


def run_id(kind):
    return "%s_%s" % (kind, dt.datetime.now().strftime("%Y%m%d_%H%M%S"))


# ============================================================================ families and systems
class AtrStop(Family):
    """E3: the family's order with its stop replaced by the trigger (or the arming close) - k x ATR at the arming close."""

    def __init__(self, fam, k=2.0):
        self.fam, self.k = fam, float(k)
        self.name, self.priority = fam.name, fam.priority
        self.variant = "%s|atr%g" % (fam.variant, k)

    def eligible(self, b, cal, sel):
        return self.fam.eligible(b, cal, sel)

    def arm(self, b, cal, sel, a):
        import dataclasses
        o = self.fam.arm(b, cal, sel, a)
        if o is None:
            return None
        atr = b["atr"][a]
        ref = o.trigger if o.kind == "stop" else b["close"][a]
        if np.isnan(atr):
            return None
        return dataclasses.replace(o, stop=ref - self.k * atr, variant=self.variant)

    def t_stop(self, b, sel):
        return self.fam.t_stop(b, sel) if hasattr(self.fam, "t_stop") else np.nan


def families_for(data):
    ev = data.events
    fam = {"T1-0": Confirm(), "T1-2": TurnAfterDip(), "T1-3": FailedBreakdown(ev), "T1-4": SqueezeBurst(),
           "T1-5a": BreakoutAcceptance(ev, "a"), "T1-5b": BreakoutAcceptance(ev, "b")}
    if data.index_bars and data.home:
        fam["T1-7"] = HomeIndexTurn(data.index_bars, data.home)
    return fam


def arch_family(arch, base, data, tables, fams):
    if arch == "A1":
        return A.ArchFamily(base, "A1")
    elig = {_key(k): v for k, v in tables["A2"]["eligible"].items()}
    risk = {_key(k): v for k, v in tables["A2"]["risk"].items()}
    if arch == "A2":
        return A.ArchFamily(base, "A2", data.ctx, data.regime, eligible=elig, risk=risk)
    ov = {_key(k): fams[v] for k, v in tables["A3"]["overrides"].items() if v in fams}
    return A.ArchFamily(base, "A3", data.ctx, data.regime, eligible=elig, risk=risk, overrides=ov)


def _key(s):
    if isinstance(s, tuple):
        return s
    return tuple(s.split("|"))


def edge_priority(fam, sel):
    v = sel.snap().get("pm_pred_edge", np.nan)
    ok = v is not None and np.isfinite(v)
    return (0 if ok else 1, -(v if ok else 0.0)) + B.default_priority(fam, sel)


def trap_excluded(sel):
    v = sel.snap().get("pm_prob_trap", np.nan)
    return v is not None and np.isfinite(v) and v >= 0.10


# ============================================================================ one period
class Period:
    def __init__(self, data, first, last):
        cal = data.cal
        self.t_lo = int(np.searchsorted(cal.days, np.datetime64(first, "D")))
        self.t_hi = int(np.searchsorted(cal.days, np.datetime64(last, "D"), side="right")) - 1
        self.span = E.Span(cal, self.t_lo, self.t_hi, TAIL)


def learn_tables(data, rows_by_fam, period, log):
    """A2 / A3 tables from the discovery rows (exit V0)."""
    boot = DayBoot(data.cal.n, B=1000, seed=7)
    base = rows_by_fam["T1-0"]
    armed = [r for r in base if r.get("armed")]
    f0 = fill_rate(armed)
    a2 = A.learn_a2(base, f0, boot)
    fr = {k: fill_rate([r for r in v if r.get("armed")]) for k, v in rows_by_fam.items()}
    fams = list(rows_by_fam)
    a3 = A.learn_a3(rows_by_fam, "T1-0", fr, boot, {k: k for k in fams})
    out = {"A2": {"eligible": a2["eligible"], "risk": a2["risk"], "groups": a2["groups"], "f_train": f0},
           "A3": {"overrides": {k: v for k, v in a3["overrides"].items()}, "tested": a3["tested"],
                  "cells_base": a3["cells_base"]}, "fill_rates": fr}
    log("   A2: %d groups, %d ineligible, %d risk-adjusted; A3: %d overrides of %d cells tested" % (
        len(a2["eligible"]), sum(1 for v in a2["eligible"].values() if not v), len(a2["risk"]),
        len(a3["overrides"]), len(a3["tested"])))
    return out


def research_period(data, pool, fams, log):
    rows, info = {}, {}
    boot = DayBoot(data.cal.n, B=1000, seed=7)
    for k, f in fams.items():
        r, cnt = LB.research3(data.cal, data.bars, pool, f, C.X1, data.events, data.ctx, data.regime)
        armed = [x for x in r if x.get("armed")]
        f_tr = fill_rate(armed)
        rows[k] = r
        info[k] = {"counts": dict(cnt), "status": dict(_count(r, "status")), "fill_rate": f_tr,
                   "itt": LB.itt_tests(r, f_tr, boot) if armed else {},
                   "same_moment": LB.same_moment(data.cal, data.bars, r, 5, boot) if armed else {},
                   "context": A.context_tests(r, f_tr, boot) if armed else {}}
        log("   %s: %d selections, %d armed, fill rate %s" % (k, len(r), len(armed),
                                                               "%.3f" % f_tr if f_tr == f_tr else "-"))
    return rows, info


def _count(rows, key):
    out = {}
    for r in rows:
        out[r.get(key)] = out.get(r.get(key), 0) + 1
    return out


def run_books(data, period, engine, fams, tables, budget, log, with_experiments=True, exp_period=None):
    """Every candidate and baseline of one engine on one period -> views, gates, experiments."""
    cal, bars, cm = data.cal, data.bars, data.cm
    pool = LB.Pool(data.registry, engines=(engine,), ranks=(1, 2, 3), name="%s r1-3" % engine)
    pool10 = LB.Pool(data.registry, engines=(engine,), ranks=tuple(range(1, 11)), name="%s r1-10" % engine)
    sels = [s for s in pool.active() if period.t_lo <= s.t_idx <= period.t_hi]
    sids = [s.sid for s in sels]
    plan_tab = B.plan_table(cal, bars, sels)
    sp = period.span
    kw = dict(t_lo=period.t_lo, t_hi=period.t_hi, budget=budget, events_by_sym=data.events)
    base = fams["T1-0"]
    views, books = {}, {}

    def view(name, bk, slots=8, s_ids=None, ptab=None):
        books[name] = bk
        views[name] = E.book_view(cal, bars, bk, cm, sp, ptab or plan_tab, s_ids or sids, slots)
        return views[name]

    view("PLAN_native", B.plan_native(cal, bars, pool10, 3, period.t_lo, period.t_hi), slots=15)
    view("PLAN_B", B.run_book2(cal, bars, pool, "plan", name="PLAN_B", **kw))
    for vk, pol in C.EXIT_VARIANTS.items():
        view("B2T_%s" % vk, B.run_book2(cal, bars, pool, "open_T1", base, pol, name="B2T_%s" % vk, **kw))
    cands = []
    for arch in ("A1", "A2", "A3"):
        fam = arch_family(arch, base, data, tables, fams)
        for vk, pol in C.EXIT_VARIANTS.items():
            nm = "%s_%s" % (arch, vk)
            view(nm, B.run_book2(cal, bars, pool, "trigger", fam, pol, name=nm, **kw))
            view("B2a_" + nm, B.run_book2(cal, bars, pool, "open_at_arm", fam, pol, name="B2a_" + nm, **kw))
            cands.append((nm, vk))
    cmp = E.Compare(sp)
    gl = []
    for nm, vk in cands:
        g = E.gates(cmp, views[nm], views["PLAN_B"], views["PLAN_native"], views["B2T_%s" % vk])
        g["name"] = nm
        g["vs_B2a"] = _diff(cmp, views[nm], views["B2a_" + nm])
        g["vs_PLAN_B_daily"] = _diff(cmp, views[nm], views["PLAN_B"])
        gl.append(g)
    E.adjust(gl)
    out = {"pool": pool.name, "selections": len(sels), "span": [str(cal.days[sp.lo]), str(cal.days[sp.hi]), sp.n],
           "books": {k: _brief(cal, v, sp) for k, v in views.items()}, "gates": gl}
    log("   %s: %d selections, %d books" % (engine, len(sels), len(views)))
    if with_experiments:
        out["experiments"] = experiments(data, period if exp_period is None else exp_period, engine, fams, tables,
                                         budget, pool, pool10)
    return out, books


def _diff(cmp, a, b):
    from v2_stats import summary
    res = {}
    for what in ("daily", "per_trade", "capture"):
        d, bs = cmp.diff(a, b, what)
        res[what] = summary(d, bs)
    return res


def _brief(cal, v, sp):
    q = v["quality"]
    pf = v["perf"]
    keep_q = ("trades", "expectancy", "median", "winner_rate", "big_win_rate", "bad_rate", "deep_rate", "tail_cvar5",
              "worst", "best", "avg_win", "avg_loss", "payoff", "win_rate", "expectancy_gross", "winner_rate_gross",
              "big_win_rate_gross", "bad_rate_gross", "cost_per_trade")
    return {"quality": {k: q.get(k) for k in keep_q}, "capture": v["capture"], "ledger": v["ledger"],
            "money": {k: pf.get(k) for k in ("cagr", "total_return", "max_dd", "sharpe", "utilisation", "worst_month",
                                             "pos_months", "final_equity", "trades", "skipped", "open_at_end")},
            "by_year": E.by_year(cal, v, sp)}


def experiments(data, period, engine, fams, tables, budget, pool, pool10):
    cal, bars, cm = data.cal, data.bars, data.cm
    sp = period.span
    kw = dict(t_lo=period.t_lo, t_hi=period.t_hi, budget=budget, events_by_sym=data.events)
    sels = [s for s in pool.active() if period.t_lo <= s.t_idx <= period.t_hi]
    sids = [s.sid for s in sels]
    ptab = B.plan_table(cal, bars, sels)
    cmp = E.Compare(sp)
    base = fams["T1-0"]
    a1 = A.ArchFamily(base, "A1")
    res = {}

    def v(bk, slots=8):
        return E.book_view(cal, bars, bk, cm, sp, ptab, sids, slots)

    def pair(name, x, y, what="money"):
        res[name] = {"a": _brief(cal, x, sp), "b": _brief(cal, y, sp), "a_minus_b": _diff(cmp, x, y)}

    t3 = v(B.run_book2(cal, bars, pool, "trigger", a1, C.X1, name="A1_V0 r1-3", **kw))
    t10 = v(B.run_book2(cal, bars, pool10, "trigger", a1, C.X1, name="A1_V0 r1-10", **kw))
    o3 = v(B.run_book2(cal, bars, pool, "open_T1", base, C.X1, name="B2T_V0 r1-3", **kw))
    o10 = v(B.run_book2(cal, bars, pool10, "open_T1", base, C.X1, name="B2T_V0 r1-10", **kw))
    pair("E1 trigger r1-10 vs r1-3", t10, t3)
    pair("E1 open T+1 r1-10 vs r1-3", o10, o3)
    pb = v(B.run_book2(cal, bars, pool, "plan", name="PLAN_B", **kw))
    pbs = v(B.run_book2(cal, bars, pool, "plan", priority=edge_priority, name="PLAN_B by score", **kw))
    ob = v(B.run_book2(cal, bars, pool, "open_T1", base, C.X1, priority=edge_priority, name="B2T_V0 by score", **kw))
    pair("E2 PLAN_B by score vs by rank", pbs, pb)
    pair("E2 B2T_V0 by score vs by rank", ob, o3)
    s1 = v(B.run_book2(cal, bars, pool, "trigger", a1, C.X6_V1, name="A1_V1", **kw))
    s2 = v(B.run_book2(cal, bars, pool, "trigger", A.ArchFamily(AtrStop(base, 2.0), "A1"), C.X6_V1, name="A1_V1 ATR stop",
                       **kw))
    pair("E3 ATR stop vs structural stop (A1 x V1)", s2, s1)
    poolx = LB.Pool(data.registry, engines=(engine,), ranks=(1, 2, 3), exclude=trap_excluded, name="%s r1-3 ex trap" % engine)
    tx = v(B.run_book2(cal, bars, poolx, "trigger", a1, C.X1, name="A1_V0 ex trap", **kw))
    px = v(B.run_book2(cal, bars, poolx, "plan", name="PLAN_B ex trap", **kw))
    pair("E4 A1_V0 excluding P(stuck) >= 0.10 vs all", tx, t3)
    pair("E4 PLAN_B excluding P(stuck) >= 0.10 vs all", px, pb)
    for k, r in res.items():
        d = r["a_minus_b"]
        r["adopt"] = bool(d["daily"]["lo"] > 0 and d["capture"]["lo"] > -E.G1_MARGIN)
    return res


# ============================================================================ commands
def load_decl(path=None):
    p = Path(path) if path else HERE / DECL_NAME
    raw = p.read_bytes()
    return json.loads(raw.decode("utf-8")), hashlib.sha256(raw).hexdigest(), p


def setup_costs(data, decl):
    M.install(data.cm)
    C.set_exit_slip(float(decl["orders"]["sell_stop_slippage_atr"]))
    C.set_stop_slip(float(decl["orders"]["buy_stop_slippage_atr"]))


def budget_of(decl):
    b = decl["budget"]
    return Budget(int(b["max_entries_per_day"]), int(b["max_entries_per_5_sessions"]), int(b["max_open"]))


def discover(data, decl, decl_sha, out, log=print, rid=None):
    if data.sealed_end is None or data.sealed_end > decl["periods"]["discovery"]["seal_end"]:
        raise C.V2Error("discovery needs data sealed at %s (got %s)" % (decl["periods"]["discovery"]["seal_end"],
                                                                        data.sealed_end))
    setup_costs(data, decl)
    rid = rid or run_id("discover")
    rdir = Path(out) / rid
    P = decl["periods"]["discovery"]
    per = Period(data, P["first_signal_day"], P["last_signal_day"])
    PX = decl["periods"]["forecast_experiments_discovery"]
    per_x = Period(data, PX["first_signal_day"], PX["last_signal_day"])
    fams = families_for(data)
    res = {"run": rid, "kind": "discover", "version": C.VERSION, "declaration_sha256": decl_sha, "data": data.info,
           "engines": {}}
    tables = {}
    for eng in decl["inputs"]["engines"]:
        log(" engine %s" % eng)
        pool = LB.Pool(data.registry, engines=(eng,), ranks=(1, 2, 3), t_lo=per.t_lo, t_hi=per.t_hi + 1)
        rows, info = research_period(data, pool, fams, log)
        tb = learn_tables(data, rows, per, log)
        tables[eng] = tb
        bk, _ = run_books(data, per, eng, fams, tb, budget_of(decl), log, with_experiments=False)
        bk["experiments"] = experiments(data, per, eng, fams, tb, budget_of(decl),
                                        LB.Pool(data.registry, engines=(eng,), ranks=(1, 2, 3)),
                                        LB.Pool(data.registry, engines=(eng,), ranks=tuple(range(1, 11))))
        bk["experiments_2022"] = experiments(data, per_x, eng, fams, tb, budget_of(decl),
                                             LB.Pool(data.registry, engines=(eng,), ranks=(1, 2, 3)),
                                             LB.Pool(data.registry, engines=(eng,), ranks=tuple(range(1, 11))))
        res["engines"][eng] = {"research": info, "books": bk}
    write_json(rdir / "tables.json", {"run": rid, "declaration_sha256": decl_sha, "tables": tables})
    write_json(rdir / "discovery.json", res)
    import v2_report as R
    (rdir / "REPORT_DISCOVERY.md").write_text(R.report(res, tables, "discovery"), encoding="utf-8")
    ledger(out, {"run": rid, "kind": "discover", "version": C.VERSION, "declaration_sha256": decl_sha,
                 "sealed_end": data.sealed_end, "written": str(rdir)})
    log(" discovery written to %s" % rdir)
    return rdir


def code_hashes():
    return {f: sha256_file(HERE / f) for f in CODE_FILES if (HERE / f).exists()}


def freeze(rdir, decl_sha, out, log=print):
    rdir = Path(rdir)
    for f in ("tables.json", "discovery.json"):
        if not (rdir / f).exists():
            raise C.V2Error("%s has no %s - run discover first" % (rdir, f))
    disc = json.loads((rdir / "discovery.json").read_text(encoding="utf-8"))
    if disc.get("declaration_sha256") != decl_sha:
        raise C.V2Error("the declaration changed since this discovery run (recorded %s, now %s) - rerun discover" % (
            str(disc.get("declaration_sha256"))[:16], decl_sha[:16]))
    fr = rdir / "frozen.json"
    if fr.exists():
        raise C.V2Error("%s is already frozen (%s) - a freeze is never rewritten" % (rdir, fr))
    rec = {"frozen_at": dt.datetime.now().isoformat(timespec="seconds"), "version": C.VERSION,
           "declaration_sha256": decl_sha, "tables_sha256": sha256_file(rdir / "tables.json"),
           "discovery_sha256": sha256_file(rdir / "discovery.json"), "code": code_hashes()}
    write_json(fr, rec)
    ledger(out, {"run": rdir.name, "kind": "protocol_frozen", **rec})
    log(" frozen: %s" % fr)
    return fr


def check_frozen(rdir, decl_sha):
    rdir = Path(rdir)
    fr = rdir / "frozen.json"
    if not fr.exists():
        raise C.V2Error("%s is not frozen - evaluation is refused (run: v2engine.py freeze --discovery %s)" % (rdir, rdir))
    rec = json.loads(fr.read_text(encoding="utf-8"))
    bad = []
    if rec["declaration_sha256"] != decl_sha:
        bad.append("the declaration")
    if rec["tables_sha256"] != sha256_file(rdir / "tables.json"):
        bad.append("tables.json")
    now = code_hashes()
    bad += ["code %s" % f for f, h in rec["code"].items() if now.get(f) != h]
    if bad:
        raise C.V2Error("changed since the freeze: %s - evaluation is refused" % ", ".join(bad))
    return rec


def evaluate(data, decl, decl_sha, rdir, out, log=print, rid=None):
    rec = check_frozen(rdir, decl_sha)
    if data.sealed_end is not None:
        raise C.V2Error("evaluation needs the unsealed data")
    setup_costs(data, decl)
    tables = {k: v for k, v in json.loads((Path(rdir) / "tables.json").read_text(encoding="utf-8"))["tables"].items()}
    disc = json.loads((Path(rdir) / "discovery.json").read_text(encoding="utf-8"))
    rid = rid or run_id("evaluate")
    edir = Path(out) / rid
    P = decl["periods"]["evaluation"]
    per = Period(data, P["first_signal_day"], P["last_signal_day"])
    fams = families_for(data)
    res = {"run": rid, "kind": "evaluate", "version": C.VERSION, "declaration_sha256": decl_sha,
           "discovery_run": Path(rdir).name, "frozen": rec, "data": data.info, "engines": {}}
    for eng in decl["inputs"]["engines"]:
        log(" engine %s" % eng)
        pool = LB.Pool(data.registry, engines=(eng,), ranks=(1, 2, 3), t_lo=per.t_lo, t_hi=per.t_hi + 1)
        rows, info = research_period(data, pool, fams, log)
        conf = confirm_context(disc["engines"][eng]["research"], info)
        bk, _ = run_books(data, per, eng, fams, tables[eng], budget_of(decl), log)
        res["engines"][eng] = {"research": info, "context_confirmation": conf, "books": bk}
    write_json(edir / "evaluation.json", res)
    import v2_report as R
    (edir / "REPORT_EVALUATION.md").write_text(R.report(res, tables, "evaluation"), encoding="utf-8")
    acc = {e: [g["name"] for g in v["books"]["gates"] if g["accepted"]] for e, v in res["engines"].items()}
    ledger(out, {"run": rid, "kind": "evaluate", "version": C.VERSION, "declaration_sha256": decl_sha,
                 "discovery_run": Path(rdir).name, "accepted": acc, "written": str(edir)})
    log(" evaluation written to %s" % edir)
    return edir


def confirm_context(disc_info, eval_info):
    """Discovery context findings (Level 1 groups with two-sided max-t p < 0.05, and the pairs with p < 0.05)
    re-tested on the evaluation years: confirmed = the same sign and an interval excluding 0."""
    out = {}
    eval_info = jsonable(eval_info)                 # the same key form as the stored discovery (tuples -> "a|b|c")
    for fam, d in disc_info.items():
        e = eval_info.get(fam, {})
        dc, ec = d.get("context") or {}, e.get("context") or {}
        rows = []
        for g, v in (dc.get("level1_arming") or {}).items():
            if v.get("p_maxt", 1.0) < 0.05:
                ev = (ec.get("level1_arming") or {}).get(g)
                ok = bool(ev and np.sign(ev["contrast"]["mean"]) == np.sign(v["contrast"]["mean"]) and
                          (ev["contrast"]["lo"] > 0 or ev["contrast"]["hi"] < 0))
                rows.append({"what": "level1 %s" % (g,), "discovery": v["contrast"], "evaluation":
                             ev["contrast"] if ev else None, "confirmed": ok})
        for pn, v in (dc.get("pairs_arming") or {}).items():
            if v.get("p_two_sided", 1.0) < 0.05:
                ev = (ec.get("pairs_arming") or {}).get(pn) or {}
                ok = bool(ev.get("a_minus_b") and np.sign(ev["a_minus_b"]["mean"]) == np.sign(v["a_minus_b"]["mean"])
                          and (ev["a_minus_b"]["lo"] > 0 or ev["a_minus_b"]["hi"] < 0))
                rows.append({"what": "pair %s" % pn, "discovery": v["a_minus_b"], "evaluation": ev.get("a_minus_b"),
                             "confirmed": ok})
        out[fam] = rows
    return out
