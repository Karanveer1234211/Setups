r"""v2_book2.py - budgeted books with a full selection ledger (drop 3, spec v2.4).

Every book reads the same pool of selections, sees the same information at the same closes, spends the same
budget (2 entries a session, 6 in any 5 sessions, 8 open, one position per stock), is costed by the same fully net
cost model and is sized by the same money view. Modes:
  trigger      the family's orders: buy-stops fill inside the session (trigger + slippage), pre-open orders at
               the open; re-armed each evening of the window while the setup holds. A buy-stop goes on every armed
               candidate (a GTT costs nothing until it fills); fills beyond the session's budget are cancelled, the
               open fills first, the rest in an order fixed by the session and selection id (never an outcome)
  open_at_arm  B2a: at the family's arming close, a pre-open buy at the next open instead of the order (the
               same information, the same stop and exit; the family decides only WHEN to act)
  open_T1      B2T: a pre-open buy at T+1's open for every selection (the original timing), the same exit
               policy; initial stop = the family's stop known at T (T1-0: T's low - 0.1 ATR), else T's low - 0.5 ATR.
               With exit V0 (a 5-session time exit) this IS OPEN6.
  plan         PLAN_B: original BigMove trades (T+1 open -> T+5 close, no stop) under the v2 budget
plan_native() is the original BigMove as stage E trades it: 3 a session from the top of the list (the next rank
replaces a pick that cannot be bought), hold 5, duplicates allowed, no other cap; sized at equity / 15.

Ledger - one line per selection per book (a no-fill opportunity never disappears):
  TRADED       an order filled for this selection          MERGED       a same-stock selection's order served it
  NO_FILL      orders placed, none filled in the window      NO_ROOM      armed, never given a slot by the budget
  NO_LIQ       armed only while no ADV was known             HELD_SYMBOL  the stock was already held, never armed
  NOT_ARMED    eligible, the setup never armed               INELIGIBLE   refused by the family / architecture
  EXCLUDED     removed by an experiment's rule known at T (E4)
"""
from collections import Counter, defaultdict
from dataclasses import dataclass

import numpy as np

import v2_core as C
from v2_core import FILLED, INVALID_AT_OPEN, WINDOW, X1, fill_buy_stop, fill_preopen
from v2_research import CAP_ATR, Budget, armed_order, do_exit, exit_timing

LEDGER = ("TRADED", "MERGED", "NO_FILL", "NO_ROOM", "NO_LIQ", "HELD_SYMBOL", "NOT_ARMED", "INELIGIBLE", "EXCLUDED")
MODES = ("trigger", "open_at_arm", "open_T1", "plan")
T1_STOP_ATR = 0.5          # B2T's stop when the family has none known at T: T's low - 0.5 ATR(T)


def tradable(b, i):
    """Stage E trades a stock only with a turnover median known at the close before the entry session."""
    if "adv" not in b:
        return True
    a = b["adv"][i - 1] if i >= 1 else np.nan
    return bool(np.isfinite(a) and a > 0)


def _tiebreak(sid, i):
    """A fixed pseudo-random order of simultaneous fills: a hash of the selection id and the session only."""
    import hashlib
    return hashlib.sha256(("%s|%d" % (sid, i)).encode("ascii")).hexdigest()[:12]


def default_priority(fam, sel):
    return (getattr(fam, "priority", 99) if fam is not None else 0, sel.rank, 0 if sel.engine == "D" else 1,
            -sel.raw_score, sel.t_idx, sel.sid)


def t_stop(family, b, sel):
    f = getattr(family, "fam", family)                    # an architecture wrapper -> its base family
    if f is not None and hasattr(f, "t_stop"):
        return f.t_stop(b, sel)
    T = sel.t_idx
    lo, atr = b["low"][T], b["atr"][T]
    return lo - T1_STOP_ATR * atr if not (np.isnan(lo) or np.isnan(atr)) else np.nan


class _Rec:
    __slots__ = ("eligible_seen", "ineligible_seen", "armed", "orders", "no_room", "no_liq", "held", "fills",
                 "status", "trade", "why")

    def __init__(self):
        self.eligible_seen = self.ineligible_seen = False
        self.armed = self.orders = self.no_room = self.no_liq = self.held = 0
        self.fills = Counter()
        self.status, self.trade, self.why = "", None, ""


def _final(rec):
    if rec.status:
        return rec.status
    if rec.orders:
        return "NO_FILL"
    if rec.no_room:
        return "NO_ROOM"
    if rec.no_liq:
        return "NO_LIQ"
    if rec.held:
        return "HELD_SYMBOL"
    if rec.eligible_seen:
        return "NOT_ARMED"
    return "INELIGIBLE"


def _trade(sel, served, mode, fam, o_stop, i, px, kind, ex, a):
    return {"sid": sel.sid, "served": list(served), "symbol": sel.symbol, "engine": sel.engine, "rank": sel.rank,
            "t_idx": sel.t_idx, "mode": mode, "family": fam.key if fam is not None else "", "arm_idx": a,
            "entry_idx": i, "entry_raw": float(px), "entry_kind": kind, "stop": float(o_stop),
            "exit_idx": ex["exit_idx"], "exit_raw": float(ex["exit_px"]), "reason": ex["reason"],
            "timing": exit_timing(ex["reason"], ex.get("timing", "")), "net": float(ex["net"]),
            "gross": float(ex["r_px"]) if "r_px" in ex else float(ex["exit_px"] / px - 1.0),
            "held": ex.get("held", 0), "mfe": ex.get("mfe", np.nan), "mae": ex.get("mae", np.nan)}


def run_book2(cal, bars, pool, mode, family=None, policy=X1, budget=Budget(), events_by_sym=None, priority=None,
              cap_atr=CAP_ATR, t_lo=0, t_hi=None, name=None):
    """One budgeted book. pool: v2_lab.Pool (its excluded selections go to the ledger as EXCLUDED).
    t_lo / t_hi: the sessions whose selections the book trades (signal days); trades may run past t_hi."""
    if mode not in MODES:
        raise C.V2Error("unknown book mode %r" % mode)
    if mode in ("trigger", "open_at_arm") and family is None:
        raise C.V2Error("mode %s needs a family" % mode)
    n = cal.n
    t_hi = n - 2 if t_hi is None else t_hi
    prio = priority or default_priority
    sels = [s for s in pool.active() if t_lo <= s.t_idx <= t_hi]
    recs = {s.sid: _Rec() for s in sels}
    by_T = defaultdict(list)
    for s in sels:
        by_T[s.t_idx].append(s)
    live, served = [], set()
    positions, trades, orders = {}, [], []
    entries = np.zeros(n, dtype=int)
    single = mode in ("open_T1", "plan")
    last_a = min(t_hi + WINDOW - 1, n - 2)
    for a in range(t_lo, last_a + 1):
        live.extend(by_T.get(a, []))
        if single:
            live = [s for s in live if s.t_idx == a]
        else:
            live = [s for s in live if s.t_idx + WINDOW - 1 >= a and s.sid not in served]
        for sym in list(positions):
            tr = positions[sym]
            x = tr["exit_idx"]
            if x is not None and (x < a + 1 or (x == a + 1 and tr["timing"] == "open")):
                del positions[sym]
        if not live:
            continue
        i = a + 1
        entry_ok = bool(cal.entry_ok[i])
        cands = []
        for s in live:
            rec = recs[s.sid]
            b = bars[s.symbol]
            if s.symbol in positions:
                rec.held += 1
                continue
            if single:
                rec.eligible_seen = True
                if not entry_ok:
                    continue
                stop = np.nan if mode == "plan" else t_stop(family, b, s)
                o = C_Order(stop)
            else:
                if not family.eligible(b, cal, s):
                    rec.ineligible_seen = True
                    continue
                rec.eligible_seen = True
                if not entry_ok:
                    continue
                o = armed_order(family, b, cal, s, a)
                if o is None:
                    continue
            rec.armed += 1
            if not tradable(b, i):
                rec.no_liq += 1
                continue
            cands.append((prio(family, s), s, o))
        cands.sort(key=lambda x: x[0])
        heads, by_sym = [], {}
        for key, s, o in cands:
            if s.symbol in by_sym:
                by_sym[s.symbol]["merged"].append(s.sid)
                continue
            c = {"sel": s, "order": o, "merged": [s.sid]}
            by_sym[s.symbol] = c
            heads.append(c)
        room = min(budget.per_day, budget.per_5 - int(entries[max(0, a - 3):a + 1].sum()),
                   budget.max_open - len(positions))
        room = max(0, room)
        if mode == "trigger":
            # buy-stops: an order on every armed candidate (GTTs cost nothing until they fill); when more fill in a
            # session than the budget allows, the extra fills are cancelled (Kite: the script cancels the rest once
            # the session's budget is used). Daily bars do not show which filled first: fills at the open (a gap
            # through the trigger) come first, the rest in an order fixed by the session and the selection id only
            # (never by any outcome). Pre-open orders (the open) come before every buy-stop.
            pre = [c for c in heads if c["order"].kind != "stop"]
            stp = [c for c in heads if c["order"].kind == "stop"]
            placed = (pre[:room] + stp) if room > 0 else []
            for c in (pre[room:] if room > 0 else heads):
                for sid in c["merged"]:
                    recs[sid].no_room += 1
        else:
            placed = heads[:room]
            for c in heads[room:]:
                for sid in c["merged"]:
                    recs[sid].no_room += 1
        fills = []
        for c in placed:
            s, o = c["sel"], c["order"]
            b = bars[s.symbol]
            for sid in c["merged"]:
                recs[sid].orders += 1
            if mode == "plan":
                d = C.plan_detail(b, cal, s.t_idx, "CLOSE5")
                st = FILLED if d["status"] == "TRADE" else d["status"]
                px, kind = d["entry_raw"], "open"
            elif mode == "trigger" and o.kind == "stop":
                st, px = fill_buy_stop(b, i, o.trigger, o.limit)
                kind, d = "stop", None
            else:
                st, px = fill_preopen(b, i, np.inf if mode == "open_T1" else cap_atr)
                kind, d = "open", None
                if st == FILLED and policy.kind != "X1" and not (o.stop < px):
                    st = INVALID_AT_OPEN
            orders.append({"arm_idx": a, "sid": s.sid, "merged": list(c["merged"]), "status": st, "kind": kind})
            if st != FILLED:
                for sid in c["merged"]:
                    recs[sid].fills[st] += 1
                continue
            first = 0 if kind == "open" or px <= b["open"][i] else 1
            fills.append(((first, _tiebreak(s.sid, i)), c, px, kind, d))
        fills.sort(key=lambda x: x[0])
        for key, c, px, kind, d in fills[room:]:
            for sid in c["merged"]:
                recs[sid].no_room += 1
                recs[sid].fills["CANCELLED_BUDGET"] += 1
        for key, c, px, kind, d in fills[:room]:
            s, o = c["sel"], c["order"]
            b = bars[s.symbol]
            ev = events_by_sym.get(s.symbol) if events_by_sym else None
            if mode == "plan":
                ex = {"exit_idx": d["exit_idx"], "exit_px": d["exit_raw"], "reason": d["reason"],
                      "timing": d["timing"], "net": d["net"], "r_px": d["gross"],
                      "held": d["exit_idx"] - d["entry_idx"]}
                tr = _trade(s, c["merged"], mode, None, np.nan, i, px, "open", ex, a)
            else:
                ex = do_exit(b, cal, i, px, kind, policy, o.stop, ev)
                tr = _trade(s, c["merged"], mode, family, o.stop, i, px, kind, ex, a)
            trades.append(tr)
            positions[s.symbol] = tr
            entries[i] += 1
            for sid in c["merged"]:
                served.add(sid)
                recs[sid].status = "TRADED" if sid == s.sid else "MERGED"
                recs[sid].trade = len(trades) - 1
    ledger = {}
    for s in sels:
        r = recs[s.sid]
        ledger[s.sid] = {"sid": s.sid, "symbol": s.symbol, "engine": s.engine, "rank": s.rank, "t_idx": s.t_idx,
                         "status": _final(r), "armed": r.armed, "orders": r.orders, "no_room": r.no_room,
                         "no_liq": r.no_liq, "held": r.held, "fills": dict(r.fills), "trade": r.trade}
    for s in getattr(pool, "excluded", []):
        if t_lo <= s.t_idx <= t_hi:
            ledger[s.sid] = {"sid": s.sid, "symbol": s.symbol, "engine": s.engine, "rank": s.rank, "t_idx": s.t_idx,
                             "status": "EXCLUDED", "armed": 0, "orders": 0, "no_room": 0, "no_liq": 0, "held": 0,
                             "fills": {}, "trade": None}
    return {"name": name or mode, "mode": mode, "family": family.key if family is not None else "",
            "policy": policy.name(), "trades": trades, "ledger": ledger, "orders": orders, "entries": entries,
            "t_lo": t_lo, "t_hi": t_hi, "budget": budget}


@dataclass(frozen=True)
class C_Order:
    """The single pre-open order of open_T1 / plan books (its stop; nothing else is needed)."""
    stop: float
    kind: str = "preopen"


def plan_native(cal, bars, registry_pool, n_per_day=3, t_lo=0, t_hi=None, name="PLAN_native"):
    """The original BigMove as stage E trades it: each signal day, the first n_per_day picks of the list (rank
    order) that can be bought at T+1's open, held to T+5's close (honest locked exits); duplicates allowed.
    registry_pool: a Pool holding at least ranks 1..n_per_day (deeper ranks are the replacements)."""
    n = cal.n
    t_hi = n - 2 if t_hi is None else t_hi
    by_T = defaultdict(list)
    for s in registry_pool.active():
        if t_lo <= s.t_idx <= t_hi:
            by_T[s.t_idx].append(s)
    trades, ledger = [], {}
    for T in sorted(by_T):
        lst = sorted(by_T[T], key=lambda s: (s.rank, s.sid))
        got = 0
        for s in lst:
            b = bars[s.symbol]
            rec = {"sid": s.sid, "symbol": s.symbol, "engine": s.engine, "rank": s.rank, "t_idx": s.t_idx,
                   "status": "", "trade": None}
            ledger[s.sid] = rec
            if got >= n_per_day:
                rec["status"] = "NOT_NEEDED" if s.rank > n_per_day else "NO_ROOM"
                continue
            if T + 1 > n - 1 or not cal.entry_ok[T + 1]:
                rec["status"] = "NO_FILL"
                continue
            if not tradable(b, T + 1):
                rec["status"] = "NO_LIQ"
                continue
            d = C.plan_detail(b, cal, T, "CLOSE5")
            if d["status"] != "TRADE":
                rec["status"] = "NO_FILL"
                continue
            ex = {"exit_idx": d["exit_idx"], "exit_px": d["exit_raw"], "reason": d["reason"], "timing": d["timing"],
                  "net": d["net"], "r_px": d["gross"], "held": d["exit_idx"] - d["entry_idx"]}
            trades.append(_trade(s, [s.sid], "plan_native", None, np.nan, T + 1, d["entry_raw"], "open", ex, T))
            rec["status"], rec["trade"] = "TRADED", len(trades) - 1
            got += 1
    return {"name": name, "mode": "plan_native", "family": "", "policy": "PLAN", "trades": trades, "ledger": ledger,
            "orders": [], "entries": None, "t_lo": t_lo, "t_hi": t_hi, "budget": None}


# ============================================================================ the measures of a book
def plan_table(cal, bars, sels):
    """The original BigMove trade of every selection (fully net), for the major-winner universe."""
    out = {}
    for s in sels:
        b = bars[s.symbol]
        d = C.plan_detail(b, cal, s.t_idx, "CLOSE5")
        ok = d["status"] == "TRADE" and tradable(b, s.t_idx + 1)
        out[s.sid] = {"net": d["net"] if ok else np.nan, "gross": d["gross"] if ok else np.nan}
    return out


def capture(book, plan_tab, sids, big=0.08):
    """Major winners = selections (in sids) whose original BigMove trade made more than +8% fully net.
    captured = sum of the net of the book's trades that served a major winner (each trade once) / sum of the
    major winners' original net. missed = majors the book neither traded nor merged; held = majors met while the
    book already held the stock (not credited)."""
    majors = [sid for sid in sids if np.isfinite(plan_tab[sid]["net"]) and plan_tab[sid]["net"] > big]
    denom = float(sum(plan_tab[sid]["net"] for sid in majors))
    used, num = set(), 0.0
    missed = held = 0
    for sid in majors:
        led = book["ledger"].get(sid)
        st = led["status"] if led else "ABSENT"
        if st in ("TRADED", "MERGED"):
            k = led["trade"]
            if k is not None and k not in used:
                used.add(k)
                num += book["trades"][k]["net"]
        else:
            missed += 1
            held += st == "HELD_SYMBOL"
    return {"major_winners": len(majors), "original_profit": denom, "captured_profit": num,
            "capture_share": (num / denom) if denom > 0 else np.nan, "missed": missed,
            "missed_share": (missed / len(majors)) if majors else np.nan, "missed_but_held": held}


def ledger_counts(book):
    c = Counter(v["status"] for v in book["ledger"].values())
    return {k: int(c.get(k, 0)) for k in LEDGER + ("NOT_NEEDED",) if c.get(k, 0) or k in LEDGER}


def finished(book, t_end=None):
    """Trades that closed (an exit inside the data, and on or before t_end when given)."""
    return [t for t in book["trades"] if t["exit_idx"] is not None and np.isfinite(t["net"]) and
            (t_end is None or t["exit_idx"] <= t_end)]
