r"""v2_core.py - BigMove v2 execution engine: core mechanics (drops 1-3).

Pure, point-in-time building blocks on a declared input schema. Nothing here reads the cache or any
production file (v2_data does, read only, through tradelab).

  SessionCalendar    NSE sessions; a selection at T may enter on T+1 .. T+10 inclusive
  SelectionRegistry  one immutable record per (pick run, engine, rank, T); repeat flags; append-only store
  BarStore           daily bars per symbol on the calendar, Wilder ATR14 known at each close
  fill_buy_stop / fill_preopen   the research fill model (daily bars)
  run_exit           exit policies X1 = V0 (time), X2 (event-only), X3 (R target), X4 (structure target),
                     X5 (long hold), X6 = V1 / V2 (trailing stop; drop 3); every exit reports when in the
                     session it sells ('open' / 'intraday' / 'close')
  net_return         drop 3: the fully net return through the installed cost model (v2_money), else the flat 35 bp
  plan_detail        the original BigMove trade (T+1 open -> T+5 close / T+6 open), gross and net

Spec: "BigMove Execution Engine - Spec v2" (Claude Doc), v2.4 of 31 Oct 2026.
"""
import datetime as dt
import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

VERSION = "v2engine 0.3 (drop 3)"
CONFIG = {"cost_rt": 0.0035,     # 35 bp round trip, charged once per filled trade (tests may set 0)
          "stop_slip_atr": 0.05,  # a buy-stop fills this many ATRs above its trigger (declared; stress 0 / 0.10)
          "exit_slip_atr": 0.0}   # drop 3: a sell-stop hit inside the day fills this many ATRs BELOW the stop
#                                   (library default 0 keeps drop 2's numbers; every real-data run declares 0.05)


def cost():
    return CONFIG["cost_rt"]


COST_MODEL = {"fn": None}    # drop 3: a fully net cost model (v2_money.install); None = the flat cost_rt


def net_return(b, entry_idx, entry_px, exit_idx, exit_px):
    """Net return of one long trade from its raw execution prices. With a cost model installed (every real-data
    run and every baseline in it): fill prices with impact and the exit tick, then STT, stamp duty, exchange,
    SEBI, GST and DP charges on a declared notional; otherwise the flat round-trip cost."""
    fn = COST_MODEL["fn"]
    if fn is None:
        return exit_px / entry_px - 1.0 - cost()
    return fn(b, entry_idx, entry_px, exit_idx, exit_px)


def set_cost(x):
    CONFIG["cost_rt"] = float(x)


def set_stop_slip(x):
    CONFIG["stop_slip_atr"] = float(x)


def set_exit_slip(x):
    CONFIG["exit_slip_atr"] = float(x)
WINDOW = 10                 # entry on sessions T+1 .. T+10 inclusive
LOCK_WAIT = 20              # a lower-locked exit waits for the first unlocked open within 20 sessions


class V2Error(Exception):
    pass


def to_day(x):
    """Any date-like -> numpy datetime64[D]."""
    if isinstance(x, np.datetime64):
        return x.astype("datetime64[D]")
    if isinstance(x, (dt.date, dt.datetime)):
        return np.datetime64(x.strftime("%Y-%m-%d"), "D")
    return np.datetime64(str(x)[:10], "D")


def day_str(d):
    return str(to_day(d))


def sha16(obj):
    raw = json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:16]


# ============================================================================ calendar
class SessionCalendar:
    """The NSE session calendar.

    sessions       every trading session (the calendar stage E uses for PLAN's 5th close)
    special        special sessions such as Muhurat trading
    count_special  True: special sessions count as sessions for T+k but take no entries;
                   False: they are not sessions at all (dropped from the counting calendar)
    """

    def __init__(self, sessions, special=(), count_special=False):
        days = np.array(sorted({to_day(s) for s in sessions}), dtype="datetime64[D]")
        if len(days) < 2:
            raise V2Error("calendar needs at least two sessions")
        spec = {to_day(s).item() for s in special}          # datetime.date, like days.tolist()
        unknown = spec - set(days.tolist())
        if unknown:
            raise V2Error("special sessions not in the calendar: %s" % sorted(map(str, unknown)))
        if not count_special:
            days = np.array([d for d in days.tolist() if d not in spec], dtype="datetime64[D]")
        self.days = days
        self.n = len(days)
        self.count_special = bool(count_special)
        self._pos = {d: i for i, d in enumerate(days.tolist())}
        self.entry_ok = np.array([d not in spec for d in days.tolist()], dtype=bool)

    def idx(self, d):
        try:
            return self._pos[to_day(d).item()]
        except KeyError:
            raise V2Error("%s is not a session in the calendar" % day_str(d))

    def has(self, d):
        return to_day(d).item() in self._pos

    def date(self, i):
        return self.days[i]

    def window(self, t_idx):
        """Session indices T+1 .. T+10 that exist in the calendar (fewer at the end of data)."""
        return list(range(t_idx + 1, min(t_idx + WINDOW, self.n - 1) + 1))

    def complete(self, t_idx):
        return t_idx + WINDOW <= self.n - 1

    def arming_closes(self, t_idx):
        """Closes after which an order for the next session may be armed: T .. T+9, entry session allowed."""
        out = []
        for a in range(t_idx, min(t_idx + WINDOW - 1, self.n - 2) + 1):
            if self.entry_ok[a + 1]:
                out.append(a)
        return out


# ============================================================================ selections
@dataclass(frozen=True)
class Selection:
    sid: str
    pick_run: str
    engine: str
    rank: int
    T: str
    t_idx: int
    symbol: str
    raw_score: float
    snapshot: tuple = ()
    corrects: str = ""
    fingerprint: str = ""

    def snap(self):
        return dict(self.snapshot)


def make_sid(pick_run, engine, T, rank):
    return "%s/%s-%s-%d" % (pick_run, engine, day_str(T).replace("-", ""), int(rank))


class SelectionRegistry:
    """Every selection keeps its own identity; nothing is merged or extended here."""

    ENGINES = ("D", "ENS")

    def __init__(self, cal):
        self.cal = cal
        self.items = []
        self.by_sid = {}

    def add(self, pick_run, engine, rank, T, symbol, raw_score, snapshot=None, corrects=""):
        if engine not in self.ENGINES:
            raise V2Error("engine must be D or ENS, got %r" % engine)
        rank = int(rank)
        if rank < 1:
            raise V2Error("rank must be >= 1")
        t_idx = self.cal.idx(T)
        sid = make_sid(pick_run, engine, T, rank)
        if corrects:
            n = sum(1 for s in self.items if s.corrects == corrects) + 1
            sid = "%s#c%d" % (corrects, n)
        snap = tuple(sorted((snapshot or {}).items()))
        body = {"sid": sid, "pick_run": pick_run, "engine": engine, "rank": rank, "T": day_str(T),
                "symbol": symbol, "raw_score": float(raw_score), "snapshot": snap, "corrects": corrects}
        fp = sha16(body)
        if sid in self.by_sid:
            old = self.by_sid[sid]
            if old.fingerprint == fp:
                return old
            raise V2Error("selection %s already exists with different content; "
                          "write a correction record instead of editing it" % sid)
        sel = Selection(sid, pick_run, engine, rank, day_str(T), t_idx, symbol, float(raw_score),
                        snap, corrects, fp)
        self.items.append(sel)
        self.by_sid[sid] = sel
        return sel

    def active(self):
        """Selections that are not superseded by a correction."""
        superseded = {s.corrects for s in self.items if s.corrects}
        return [s for s in self.items if s.sid not in superseded]

    def flags(self):
        """Repeat flags (derived, never stored on the record).

        overlap_prior   ids of earlier selections of the same stock whose window overlaps this one
        same_day_other  ids of selections of the same stock on the same T in the other engine
        first           no earlier overlapping selection, and first in priority among same-day ones
        """
        out = {}
        by_sym = {}
        for s in self.active():
            by_sym.setdefault(s.symbol, []).append(s)
        for sym, lst in by_sym.items():
            lst = sorted(lst, key=lambda s: (s.t_idx, s.rank, 0 if s.engine == "D" else 1, -s.raw_score))
            for i, s in enumerate(lst):
                prior = [p.sid for p in lst if p.t_idx < s.t_idx and s.t_idx - p.t_idx <= WINDOW - 1]
                same = [p.sid for p in lst if p.t_idx == s.t_idx and p.sid != s.sid]
                earlier_same = [p for p in lst[:i] if p.t_idx == s.t_idx]
                out[s.sid] = {"overlap_prior": prior, "same_day_other": same,
                              "first": (not prior) and (not earlier_same)}
        return out


class SelectionStore:
    """Append-only JSONL of selection records. A record is never edited; a changed record is refused."""

    def __init__(self, path):
        self.path = Path(path)

    def read(self):
        if not self.path.exists():
            return {}
        out = {}
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                rec = json.loads(line)
                out[rec["sid"]] = rec
        return out

    def append(self, selections):
        have = self.read()
        new = []
        for s in selections:
            rec = {"sid": s.sid, "pick_run": s.pick_run, "engine": s.engine, "rank": s.rank, "T": s.T,
                   "symbol": s.symbol, "raw_score": s.raw_score, "snapshot": [list(kv) for kv in s.snapshot],
                   "corrects": s.corrects, "fingerprint": s.fingerprint}
            if s.sid in have:
                if have[s.sid]["fingerprint"] != s.fingerprint:
                    raise V2Error("store already holds %s with a different fingerprint; refused" % s.sid)
                continue
            new.append(rec)
        if new:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8", newline="\n") as fh:
                for rec in new:
                    fh.write(json.dumps(rec, sort_keys=True) + "\n")
        return len(new)


# ============================================================================ bars
FIELDS = ("open", "high", "low", "close", "volume")


class BarStore:
    """Daily bars per symbol on the calendar's session index. Missing bars are NaN.

    upper_locked / lower_locked: bars locked at the price band (inputs; stage E's rule in integration).
    """

    def __init__(self, cal):
        self.cal = cal
        self.data = {}

    def put(self, symbol, dates, open_, high, low, close, volume=None, upper_locked=None, lower_locked=None):
        n = self.cal.n
        rec = {f: np.full(n, np.nan) for f in FIELDS}
        rec["upper_locked"] = np.zeros(n, dtype=bool)
        rec["lower_locked"] = np.zeros(n, dtype=bool)
        vol = volume if volume is not None else np.zeros(len(dates))
        ul = upper_locked if upper_locked is not None else np.zeros(len(dates), dtype=bool)
        ll = lower_locked if lower_locked is not None else np.zeros(len(dates), dtype=bool)
        for j, d in enumerate(dates):
            if not self.cal.has(d):
                continue            # e.g. a special session dropped from the counting calendar
            i = self.cal.idx(d)
            rec["open"][i], rec["high"][i], rec["low"][i] = open_[j], high[j], low[j]
            rec["close"][i], rec["volume"][i] = close[j], vol[j]
            rec["upper_locked"][i], rec["lower_locked"][i] = bool(ul[j]), bool(ll[j])
        bad = ~np.isnan(rec["open"]) & ((rec["high"] < np.fmax(rec["open"], rec["close"]) - 1e-9) |
                                        (rec["low"] > np.fmin(rec["open"], rec["close"]) + 1e-9))
        if bad.any():
            raise V2Error("%s: %d bars with high/low outside open/close" % (symbol, int(bad.sum())))
        rec["atr"] = wilder_atr(rec["high"], rec["low"], rec["close"])
        self.data[symbol] = rec

    def put_arrays(self, symbol, rec):
        """Bars already on the session index (synthetic worlds); ATR computed here."""
        n = self.cal.n
        for f in FIELDS:
            if len(rec[f]) != n:
                raise V2Error("%s: %s has %d values, calendar has %d" % (symbol, f, len(rec[f]), n))
        rec = dict(rec)
        rec.setdefault("upper_locked", np.zeros(n, dtype=bool))
        rec.setdefault("lower_locked", np.zeros(n, dtype=bool))
        rec["atr"] = wilder_atr(rec["high"], rec["low"], rec["close"])
        self.data[symbol] = rec

    def __getitem__(self, symbol):
        try:
            return self.data[symbol]
        except KeyError:
            raise V2Error("no bars for %s" % symbol)

    def symbols(self):
        return sorted(self.data)


def wilder_atr(high, low, close, n=14):
    """Wilder ATR14 known at each close: true range uses the previous close; the first value is the
    simple mean of the first 14 true ranges; a missing bar carries the last value forward."""
    m = len(close)
    tr = np.full(m, np.nan)
    prev = np.nan
    for i in range(m):
        if np.isnan(close[i]):
            continue
        if np.isnan(prev):
            tr[i] = high[i] - low[i]
        else:
            tr[i] = max(high[i] - low[i], abs(high[i] - prev), abs(low[i] - prev))
        prev = close[i]
    atr = np.full(m, np.nan)
    seen, acc, cur = 0, 0.0, np.nan
    for i in range(m):
        if np.isnan(tr[i]):
            atr[i] = cur
            continue
        if seen < n:
            acc += tr[i]
            seen += 1
            if seen == n:
                cur = acc / n
        else:
            cur = (cur * (n - 1) + tr[i]) / n
        atr[i] = cur
    return atr


# ============================================================================ fills
FILLED, NOT_TRIGGERED, GAPPED_OVER, BLOCKED, NO_BAR, INVALID_AT_OPEN = (
    "FILLED", "NOT_TRIGGERED", "GAPPED_OVER", "BLOCKED", "NO_BAR", "INVALID_AT_OPEN")


def fill_buy_stop(b, i, trigger, limit):
    """A GTT buy-stop for session i: triggers when the day's high reaches the level; fills at the higher
    of the open and the level plus a declared slippage (stop_slip_atr x the arming close's ATR), never
    above the limit; an open above the limit is a miss; a bar locked at the upper band cannot be bought.
    A buy-stop buys into a rising price, so it pays slippage the opening auction does not."""
    o, h = b["open"][i], b["high"][i]
    if np.isnan(o):
        return NO_BAR, np.nan
    if h < trigger:
        return NOT_TRIGGERED, np.nan
    if b["upper_locked"][i]:
        return BLOCKED, np.nan
    if o > limit:
        return GAPPED_OVER, np.nan
    slip = CONFIG["stop_slip_atr"] * b["atr"][i - 1] if i >= 1 and not np.isnan(b["atr"][i - 1]) else 0.0
    return FILLED, min(max(trigger + slip, o), limit)


def fill_preopen(b, i, cap_atr):
    """A pre-open limit buy capped at the previous close + cap_atr x ATR (both known at the close
    before); fills at the open (the auction price)."""
    o = b["open"][i]
    if np.isnan(o):
        return NO_BAR, np.nan
    prev_close, prev_atr = b["close"][i - 1], b["atr"][i - 1]
    if b["upper_locked"][i]:
        return BLOCKED, np.nan
    if not np.isnan(prev_close) and not np.isnan(prev_atr) and o > prev_close + cap_atr * prev_atr:
        return GAPPED_OVER, np.nan
    return FILLED, o


# ============================================================================ exits
@dataclass
class ExitPolicy:
    """kind: X1 time | X2 event-only | X3 R target | X4 structure target | X5 long hold |
    X6 trail (drop 3, Karan 31 Oct 19:55): the trail activates only after a completed close above
    entry x (1 + trail_arm); the stop then moves to the entry plus costs and trails trail_atr x the ATR known at
    that close under the highest close; every change acts from the next executable session; an active stop is
    never loosened; a gap through it fills at the open. extend=False (V1): exit at the base limit like X1;
    extend=True (V2): a trade whose trail is active is held until the trail is hit or the backstop (40); a trade
    whose trail never activated leaves at the base limit. No state is assumed to deserve a longer hold."""
    kind: str
    target_r: float = np.nan        # X3 only
    backstop: int = 20              # X2/X3: 20; X5/X6: 40
    time_sessions: int = 5          # X1: exit at the open this many sessions after the entry session; X6: base hold
    trail_arm: float = 0.03         # X6: a close above entry x (1 + trail_arm) arms the trail (the 'winner' line)
    trail_atr: float = 2.0          # X6: trail distance under the highest close, in ATR
    extend: bool = False            # X6: False = V1 (base limit), True = V2 (extension up to the backstop)

    def name(self):
        if self.kind == "X3":
            return "X3_%gR" % self.target_r
        if self.kind == "X6":
            return "X6_V2_ext%d" % self.backstop if self.extend else "X6_V1"
        return self.kind


X1 = ExitPolicy("X1")
X2 = ExitPolicy("X2", backstop=20)
X4 = ExitPolicy("X4", backstop=20)
X5 = ExitPolicy("X5", backstop=40)
X6_V1 = ExitPolicy("X6", backstop=40, extend=False)     # trailing stop, original holding limit
X6_V2 = ExitPolicy("X6", backstop=40, extend=True)      # trailing stop, extension up to 40 sessions
EXIT_VARIANTS = {"V0": X1, "V1": X6_V1, "V2": X6_V2}    # Karan 31 Oct: the three trailing-exit variants
R_GRID = (1.0, 1.5, 2.0, 3.0, 4.0, 6.0)


def structure_target(swing_highs, entry_idx, entry_px, stop, min_r=1.0, max_r=6.0):
    """X4: the nearest swing high confirmed by the close before entry that lies at least min_r x R above
    the entry; NaN when none lies within max_r x R (the trade then runs without a target)."""
    r = entry_px - stop
    if not (r > 0) or not swing_highs:
        return np.nan
    cands = [lvl for ci, lvl in swing_highs if ci <= entry_idx - 1 and entry_px + min_r * r <= lvl <= entry_px + max_r * r]
    return min(cands) if cands else np.nan


def x3(r):
    return ExitPolicy("X3", target_r=float(r), backstop=20)


def _unlocked_open(b, i, n, ll_open=None):
    """First session >= i with an open and no lower lock at the open, within LOCK_WAIT sessions."""
    lk = b["lower_locked"] if ll_open is None else ll_open
    for k in range(i, min(i + LOCK_WAIT, n - 1) + 1):
        if not np.isnan(b["open"][k]) and not lk[k]:
            return k
    return None


def _run_x6(b, cal, entry_idx, entry_px, policy, stop, events, finish, deferred, stop_fill, ll_open, ll_close, out):
    """X6 V1 / V2 (see ExitPolicy). Same-bar order is worst case: the stop is checked before anything else in a
    session, and on a buy-stop's entry session a low at or below the stop counts as stopped."""
    n = cal.n
    if not (stop < entry_px):
        raise V2Error("stop %.4f must be below the entry %.4f" % (stop, entry_px))
    hi_close, armed = entry_px, False
    hi_seen, lo_seen = entry_px, entry_px
    base_last = entry_idx + policy.time_sessions - 1       # the base hold's last session
    last_idx = entry_idx + policy.backstop

    def done(i, px, reason, timing):
        r = finish(i, px, reason, timing)
        r.update(mfe=hi_seen / entry_px - 1.0, mae=lo_seen / entry_px - 1.0)
        return r

    for i in range(entry_idx, n):
        o, h, lo, c = b["open"][i], b["high"][i], b["low"][i], b["close"][i]
        if np.isnan(o):
            continue
        if i > entry_idx and o <= stop:
            if bool(ll_open[i]):
                return deferred(i, "STOP_GAP")
            hi_seen, lo_seen = max(hi_seen, h), min(lo_seen, lo)
            return done(i, o, "STOP_GAP", "open")
        hi_seen, lo_seen = max(hi_seen, h), min(lo_seen, lo)
        if lo <= stop:
            if bool(b["lower_locked"][i]):
                return deferred(i + 1, "STOP")
            return done(i, stop_fill(i, stop), "TRAIL_STOP" if armed else "STOP", "intraday")
        if i == last_idx:
            if bool(ll_close[i]):
                return deferred(i + 1, "BACKSTOP")
            return done(i, c, "BACKSTOP", "close")
        # ---- decisions at this completed close; they act from the next executable session
        if np.isnan(c):
            continue
        hi_close = max(hi_close, c)
        atr = b["atr"][i]                                   # Wilder ATR known at this close
        if not armed and c > entry_px * (1.0 + policy.trail_arm):
            armed = True
        if armed and not np.isnan(atr):
            stop = max(stop, entry_px * (1.0 + cost()), hi_close - policy.trail_atr * atr)   # never loosened
        if i >= base_last and not (policy.extend and armed) and i + 1 <= n - 1:
            return deferred(i + 1, "TIME")
    out["reason"] = "OPEN_AT_END"
    return out


def run_exit(b, cal, entry_idx, entry_px, entry_kind, policy, stop=np.nan, events=None, target_abs=np.nan):
    """Exit of one long trade on daily bars.

    entry_kind 'stop' (an intraday buy-stop fill) or 'open' (a pre-open fill at the open).
    events: boolean array on the session index; True at a close means exit at the next open.
    Order inside a day without 3-minute bars is worst case: a stop and a target in one day's range
    -> the stop; on the entry day of a buy-stop fill, a low at or below the stop counts as stopped.
    Returns dict(exit_idx, exit_px, reason, held, mfe, mae, net).
    """
    n = cal.n
    out = {"exit_idx": None, "exit_px": np.nan, "reason": "", "held": 0, "mfe": 0.0, "mae": 0.0, "net": np.nan,
           "r_px": np.nan, "timing": ""}
    hi_seen, lo_seen = entry_px, entry_px
    ll_open = b.get("ll_open", b["lower_locked"])          # drop 3: stage E's open / close lock tests
    ll_close = b.get("ll_close", b["lower_locked"])        # (lower_locked alone = a frozen bar: nothing sells)

    def finish(i, px, reason, timing):
        """timing: when in session i the sale happens - 'open', 'intraday' or 'close' (a slot sold at the open is
        free for that session's buys; one sold later in the session frees it from the next session)."""
        out.update(exit_idx=i, exit_px=px, reason=reason, held=i - entry_idx,
                   mfe=hi_seen / entry_px - 1.0, mae=lo_seen / entry_px - 1.0,
                   net=net_return(b, entry_idx, entry_px, i, px), r_px=px / entry_px - 1.0, timing=timing)
        return out

    def stop_fill(i, stp):
        a = b["atr"][i - 1] if i >= 1 and not np.isnan(b["atr"][i - 1]) else 0.0
        return max(stp - CONFIG["exit_slip_atr"] * a, b["low"][i])

    def deferred(i, reason):
        k = _unlocked_open(b, i, n, ll_open)
        if k is None:
            last = min(i + LOCK_WAIT, n - 1)
            return finish(last, b["close"][last], "STUCK", "close")
        return finish(k, b["open"][k], reason + ("" if k == i else "_LOCKWAIT"), "open")

    if policy.kind == "X1":
        k = entry_idx + policy.time_sessions
        if k > n - 1:
            out["reason"] = "OPEN_AT_END"
            return out
        for j in range(entry_idx, k):
            if not np.isnan(b["high"][j]):
                hi_seen, lo_seen = max(hi_seen, b["high"][j]), min(lo_seen, b["low"][j])
        return deferred(k, "TIME")

    if policy.kind == "X6":
        return _run_x6(b, cal, entry_idx, entry_px, policy, stop, events, finish, deferred, stop_fill, ll_open,
                       ll_close, out)
    if policy.kind not in ("X2", "X3", "X4", "X5"):
        raise V2Error("unknown exit policy %s" % policy.kind)
    if not (stop < entry_px):
        raise V2Error("stop %.4f must be below the entry %.4f" % (stop, entry_px))
    target = np.nan
    if policy.kind == "X3":
        target = entry_px + policy.target_r * (entry_px - stop)
    elif policy.kind == "X4":
        target = target_abs            # from structure_target(); NaN = no swing high in range -> no target
    has_t = not np.isnan(target)
    last_idx = entry_idx + policy.backstop
    for i in range(entry_idx, n):
        o, h, lo, c = b["open"][i], b["high"][i], b["low"][i], b["close"][i]
        if np.isnan(o):
            continue
        locked = bool(b["lower_locked"][i])
        if i > entry_idx:
            if o <= stop:                                   # gap through the stop: the open, never the stop
                return deferred(i, "STOP_GAP") if bool(ll_open[i]) else finish(i, o, "STOP_GAP", "open")
            if has_t and o >= target:
                return finish(i, o, "TARGET_GAP", "open")
        hit_stop = lo <= stop
        hit_tgt = has_t and h >= target
        hi_seen, lo_seen = max(hi_seen, h), min(lo_seen, lo)
        if hit_stop:
            if locked:
                return deferred(i + 1, "STOP")
            return finish(i, stop_fill(i, stop), "STOP", "intraday")
        if hit_tgt:
            return finish(i, target, "TARGET", "intraday")
        if i == last_idx:
            if bool(ll_close[i]):
                return deferred(i + 1, "BACKSTOP")
            return finish(i, c, "BACKSTOP", "close")
        if events is not None and events[i] and i + 1 <= n - 1:
            return deferred(i + 1, "EVENT")
    out["reason"] = "OPEN_AT_END"
    return out


def plan_detail(b, cal, t_idx, exit_kind="CLOSE5"):
    """Original BigMove: buy at T+1's open; sell at T+5's close (PLAN) or T+6's open (OPEN6).
    A locked exit waits for the first unlocked open within 20 sessions (stage E's rule); none -> the close of the
    last session searched ('STUCK', as stage E's plan_exit). Returns a dict (status NO_TRADE / BLOCKED / a trade)."""
    n = cal.n
    e = t_idx + 1
    x = t_idx + (5 if exit_kind == "CLOSE5" else 6)
    out = {"status": "NO_TRADE", "net": np.nan, "gross": np.nan, "entry_idx": e, "entry_raw": np.nan,
           "exit_idx": None, "exit_raw": np.nan, "reason": "NO_TRADE", "timing": ""}
    if x > n - 1 or e > n - 1 or np.isnan(b["open"][e]):
        return out
    if b["upper_locked"][e]:
        out.update(status="BLOCKED", reason="BLOCKED")
        return out
    entry = b["open"][e]
    llc = b.get("ll_close", b["lower_locked"])
    llo = b.get("ll_open", b["lower_locked"])
    if exit_kind == "CLOSE5" and not llc[x] and not np.isnan(b["close"][x]):
        k, px, reason, timing = x, b["close"][x], "CLOSE5", "close"
    else:
        k = _unlocked_open(b, x + 1 if exit_kind == "CLOSE5" else x, n, llo)
        if k is None:
            k = min((x + 1 if exit_kind == "CLOSE5" else x) + LOCK_WAIT, n - 1)
            px, reason, timing = b["close"][k], "STUCK", "close"
        else:
            px, timing = b["open"][k], "open"
            reason = "CLOSE5_LOCKWAIT" if exit_kind == "CLOSE5" else ("OPEN" if k == x else "OPEN_LOCKWAIT")
    if np.isnan(px):
        return out
    out.update(status="TRADE", net=net_return(b, e, entry, k, px), gross=px / entry - 1.0, entry_raw=entry,
               exit_idx=k, exit_raw=px, reason=reason, timing=timing)
    return out


def plan_trade(b, cal, t_idx, exit_kind="CLOSE5"):
    """(net, reason) of plan_detail; BLOCKED counts 0 (no trade) as in drop 1."""
    d = plan_detail(b, cal, t_idx, exit_kind)
    if d["status"] == "BLOCKED":
        return 0.0, "BLOCKED"
    return d["net"], d["reason"]
