r"""v2_lab.py - drop 3 research layer (spec v2.4).

  Pool            a selection universe: engines, ranks, signal-day range, optional exclusion (experiment E4)
  research3()     one row per selection in the pool for a family x exit policy. Armed orders carry the trade
                  (price return from the entry fill to the exit fill, net), the matched open entry (B2), the
                  delayed entries (B4), the random-day null (B3b) and the original BigMove trade (PLAN, OPEN6).
                  Selections the family never armed, or found ineligible, stay in the table with their reason:
                  a no-fill opportunity is never dropped from the ledger.
  quality()       the quality profile (declared 31 Oct): net expectancy, winner / big-win / bad-trade rates,
                  tail losses, payoff; on price returns from the actual entry fill to the actual exit fill
  missed_major()  original BigMove trades that made a big win (> +8%) and a book did not take
  same_moment()   proposal 3: from the close of the fill session, the triggered pick against the same day's
                  picks (same engine) that had not triggered by then, paired by signal day
"""
import numpy as np

import v2_ctx as X
from v2_core import SelectionRegistry, plan_detail
from v2_research import research, settled
from v2_stats import summary

QUALITY = {"winner": 0.03, "big_win": 0.08, "bad": -0.04, "tail_q": 0.05, "deep": -0.08}


class Pool:
    """A selection universe over a registry; repeat flags are computed inside the pool."""

    def __init__(self, registry, engines=("D", "ENS"), ranks=(1, 2, 3), t_lo=None, t_hi=None, exclude=None,
                 name=None):
        self.cal = registry.cal
        items = [s for s in registry.active() if s.engine in engines and s.rank in ranks and
                 (t_lo is None or s.t_idx >= t_lo) and (t_hi is None or s.t_idx < t_hi)]
        self.excluded = []
        if exclude is not None:
            self.excluded = [s for s in items if exclude(s)]
            items = [s for s in items if not exclude(s)]
        self._items = items
        self._flags = SelectionRegistry.flags(self)
        self.name = name or "%s r%d-%d" % ("+".join(engines), min(ranks), max(ranks))

    def active(self):
        return self._items

    def flags(self):
        return self._flags


def research3(cal, bars, pool, family, policy, events_by_sym=None, ctx_by_sym=None, regime=None):
    """Rows for every selection in the pool (armed or not). See the module text."""
    rows, counts = research(cal, bars, pool, family, policy, events_by_sym)
    by_sid = {r["sid"]: r for r in rows}
    out = []
    for sel in pool.active():
        b = bars[sel.symbol]
        d0 = plan_detail(b, cal, sel.t_idx, "CLOSE5")
        d0p = plan_detail(b, cal, sel.t_idx, "OPEN6")
        b0 = 0.0 if d0["status"] == "BLOCKED" else d0["net"]
        b0_reason, b0p = d0["reason"], (0.0 if d0p["status"] == "BLOCKED" else d0p["net"])
        r = by_sid.get(sel.sid)
        if r is None:
            r = {"sid": sel.sid, "engine": sel.engine, "rank": sel.rank, "T": sel.T, "t_idx": sel.t_idx,
                 "symbol": sel.symbol, "raw_score": sel.raw_score, "family": family.key, "policy": policy.name(),
                 "armed": False, "filled": False, "fill_idx": None, "trig": np.nan, "b2": np.nan, "opts": [],
                 "status": "INELIGIBLE" if not family.eligible(b, cal, sel) else "NEVER_ARMED",
                 "b0": b0, "b0_reason": b0_reason, "b0p": b0p}
            r.update({"ctx_" + k: v for k, v in sel.snap().items()})
        else:
            r = dict(r)
            r["armed"] = True
            r["status"] = "FILLED" if r["filled"] else ("NO_FILL_" + str(r["trig_reason"]))
        r["plan_net"], r["plan_gross"] = d0["net"], d0["gross"]          # fully net / raw price return
        r["gross"] = r.get("trig_gross", np.nan) if r.get("filled") else np.nan
        r["net"] = r["trig"] if r.get("filled") else np.nan
        if ctx_by_sym is not None and r.get("armed"):
            sn = X.snapshot(ctx_by_sym[sel.symbol], regime, int(r["a0"]))
            r.update({"actx_" + k: v for k, v in sn.items()})
        out.append(r)
    counts["pool"] = len(pool.active())
    counts["excluded"] = len(getattr(pool, "excluded", []))
    return out, counts


def quality(gross, net):
    """The quality profile of a set of trades. Classes on the FULLY NET return (Karan 31 Oct 19:55: winner > +3%,
    big win > +8%, bad <= -4%, deep <= -8%, all from the entry), the same classes on the gross price return beside
    them (*_gross); tails on net (CVaR5 = the mean of the worst 5% of trades)."""
    gross = np.asarray(gross, dtype=float)
    net = np.asarray(net, dtype=float)
    ok = ~np.isnan(net)
    gross, net = gross[ok], net[ok]
    n = len(net)
    if n == 0:
        return {"trades": 0}
    q = QUALITY
    k = max(1, int(np.ceil(q["tail_q"] * n)))
    worst = np.sort(net)[:k]
    wins, losses = net[net > 0], net[net <= 0]
    g = gross[~np.isnan(gross)]
    return {"trades": int(n), "expectancy": float(net.mean()), "median": float(np.median(net)),
            "winner_rate": float(np.mean(net > q["winner"])), "big_win_rate": float(np.mean(net > q["big_win"])),
            "bad_rate": float(np.mean(net <= q["bad"])), "deep_rate": float(np.mean(net <= q["deep"])),
            "tail_cvar5": float(worst.mean()), "worst": float(net.min()), "best": float(net.max()),
            "avg_win": float(wins.mean()) if len(wins) else np.nan,
            "avg_loss": float(losses.mean()) if len(losses) else np.nan,
            "payoff": float(wins.mean() / abs(losses.mean())) if len(wins) and len(losses) and losses.mean() != 0 else np.nan,
            "win_rate": float(np.mean(net > 0)),
            "expectancy_gross": float(g.mean()) if len(g) else np.nan,
            "winner_rate_gross": float(np.mean(g > q["winner"])) if len(g) else np.nan,
            "big_win_rate_gross": float(np.mean(g > q["big_win"])) if len(g) else np.nan,
            "bad_rate_gross": float(np.mean(g <= q["bad"])) if len(g) else np.nan,
            "cost_per_trade": float(np.mean(gross[~np.isnan(gross)] - net[~np.isnan(gross)])) if len(g) else np.nan}


def missed_major(rows, traded_sids):
    """Selections whose original BigMove trade made a big win (> +8% fully net) that the book did not take."""
    big = [r for r in rows if not np.isnan(r.get("plan_net", np.nan)) and r["plan_net"] > QUALITY["big_win"]]
    missed = [r for r in big if r["sid"] not in traded_sids]
    return {"major_winners": len(big), "missed": len(missed), "missed_share": (len(missed) / len(big)) if big else np.nan}


def same_moment(cal, bars, rows, h=5, boot=None):
    """Selection skill: for every fill at session i, the filled pick's return from the close of i to the close of
    i + h minus the mean of the same signal day's picks (same engine, in the pool) that had not filled by i,
    over the same sessions. Entry component: the fill session's own move, close of i over the fill price."""
    by_day = {}
    for r in rows:
        by_day.setdefault((r["engine"], r["t_idx"]), []).append(r)
    diffs, days, entry = [], [], []
    for (eng, t), lst in by_day.items():
        for r in lst:
            if not r.get("filled"):
                continue
            i = int(r["fill_idx"])
            if i + h > cal.n - 1:
                continue
            c = bars[r["symbol"]]["close"]
            if np.isnan(c[i]) or np.isnan(c[i + h]):
                continue
            mine = c[i + h] / c[i] - 1.0
            peers = []
            for q in lst:
                if q["sid"] == r["sid"] or (q.get("filled") and int(q["fill_idx"]) <= i):
                    continue
                cq = bars[q["symbol"]]["close"]
                if not np.isnan(cq[i]) and not np.isnan(cq[i + h]):
                    peers.append(cq[i + h] / cq[i] - 1.0)
            entry.append(c[i] / r["fill_px"] - 1.0)
            if peers:
                diffs.append(mine - float(np.mean(peers)))
                days.append(t)
    out = {"fills_with_peers": len(diffs), "entry_component_mean": float(np.mean(entry)) if entry else np.nan}
    if diffs and boot is not None:
        s, n = boot.by_day(np.array(days), np.array(diffs))
        out["selection_skill"] = summary(*boot.mean(s, n))
    elif diffs:
        out["selection_skill"] = {"mean": float(np.mean(diffs))}
    return out


def itt_tests(rows, f_train, boot):
    """Per armed order (intention to treat): trigger vs B2 (matched open entry), B2p (B2 at the training fill
    rate), B3b (random day, paired), B4 (delays). Thin wrapper over v2_research.trigger_tests on armed rows."""
    from v2_research import trigger_tests
    armed = [r for r in rows if r.get("armed")]
    return trigger_tests(armed, f_train, boot)


def armed_settled(rows):
    return settled([r for r in rows if r.get("armed")])
