r"""v2_arch.py - the three architectures and the context tests (spec v2.4, Karan 31 Oct).

A1 Universal    the family as declared, on every selection, blind to state / event / market.
A2 Shared       the same family; at each arming close the Level 1 context (state group x event group x regime
                group, known at that close) decides eligibility, and a stop-width multiplier per group adjusts
                risk. Both learned on training years only:
                  eligible(g) = empirical-Bayes pooled lift (trigger - f_train x B2, per armed order) >= 0;
                                groups with fewer than MIN_N armed orders inherit the family (eligible)
                  risk(g)     = clip(80th percentile |MAE| of the group's filled trades / the family's, 0.75, 1.5);
                                fewer than MIN_FILLS fills -> 1.0
A3 Specialized  A2 plus, in exact Level 2 cells with at least MIN_N2 armed orders in training, another family
                when its lift beats the shared family's in that cell (two-sided max-t over the candidate cells,
                p < ALPHA); it stays in the final system only if it also holds in the out-of-sample years.
Context tests   per family, on the context at the first arming close (and at T): Level 1 contrasts (group minus
                the rest, two-sided max-t), the declared pairs P1-P4 (A minus B, same trigger), Level 2 cells
                with their lift pooled toward the Level 1 group. Nothing here decides a trade by itself.
"""
import dataclasses
import math

import numpy as np

import v2_ctx as X
from v2_families import Family
from v2_learn import context_table, pool_cells
from v2_lab import armed_settled
from v2_stats import eb_shrink, max_t, summary

MIN_N, MIN_N2, MIN_FILLS, ALPHA = 30, 40, 30, 0.05
RISK_CLIP = (0.75, 1.5)


def _actx(r, prefix="actx_"):
    return {"state": int(r.get(prefix + "state", -1)), "event": int(r.get(prefix + "event", 0)),
            "age": int(r.get(prefix + "age", -1)), "regime": int(r.get(prefix + "regime", -1))}


class ArchFamily(Family):
    """A family seen through an architecture. The base family's own eligibility always applies."""

    def __init__(self, fam, arch, ctx_by_sym=None, regime=None, eligible=None, risk=None, overrides=None):
        self.fam, self.arch = fam, arch
        self.ctx, self.regime = ctx_by_sym, regime
        self.eligible_tab, self.risk, self.overrides = eligible, risk, overrides or {}
        self.name, self.priority = fam.name, fam.priority
        self.variant = "%s|%s" % (arch, fam.variant)

    def eligible(self, b, cal, sel):
        if self.overrides:
            return True                      # an override family may apply; each arm call checks its own rule
        return self.fam.eligible(b, cal, sel)

    def _snap(self, sel, a):
        return X.snapshot(self.ctx[sel.symbol], self.regime, a)

    def _adj(self, o, b, a, snap):
        if o is None or not self.risk:
            return o
        m = float(self.risk.get(X.level1(snap), 1.0))
        ref = o.trigger if o.kind == "stop" else b["close"][a]
        if not (ref > o.stop) or m == 1.0:
            return o
        return dataclasses.replace(o, stop=ref - m * (ref - o.stop))

    def arm(self, b, cal, sel, a):
        if self.arch == "A1":
            return self.fam.arm(b, cal, sel, a)
        snap = self._snap(sel, a)
        if self.overrides:
            f2 = self.overrides.get(X.level2(snap))
            if f2 is not None:
                if not f2.eligible(b, cal, sel):
                    return None
                o = f2.arm(b, cal, sel, a)
                return self._adj(dataclasses.replace(o, family=f2.name, variant=f2.variant) if o else None, b, a, snap)
            if not self.fam.eligible(b, cal, sel):
                return None
        if self.eligible_tab is not None and not self.eligible_tab.get(X.level1(snap), True):
            return None
        return self._adj(self.fam.arm(b, cal, sel, a), b, a, snap)


def _lift(rows, f_train):
    return np.array([r["trig"] - f_train * r["b2"] for r in rows])


def learn_a2(rows, f_train, boot, min_n=MIN_N, min_fills=MIN_FILLS):
    """Eligibility and risk tables from one family's A1 rows on training years (context at the first arming close)."""
    rs = armed_settled(rows)
    if not rs:
        return {"eligible": {}, "risk": {}, "groups": {}}
    lift = _lift(rs, f_train)
    day = np.array([r["t_idx"] for r in rs])
    keys = [X.level1(_actx(r)) for r in rs]
    groups = sorted(set(keys))
    means, ses, ns = [], [], []
    for g in groups:
        m = np.array([k == g for k in keys])
        obs, bs = boot.mean(*boot.by_day(day[m], lift[m]))
        means.append(obs)
        ses.append(float(np.nanstd(bs, ddof=1)) if m.sum() > 1 else np.nan)
        ns.append(int(m.sum()))
    pooled, w, parent, tau2 = eb_shrink(means, ses, ns)
    eligible, info = {}, {}
    for g, mu, se, n, pv in zip(groups, means, ses, ns, pooled):
        ok = True if n < min_n or np.isnan(pv) else bool(pv >= 0.0)
        eligible[g] = ok
        info[g] = {"n": n, "lift": float(mu), "se": float(se) if not np.isnan(se) else np.nan, "pooled": float(pv),
                   "eligible": ok}
    fills = [r for r in rs if r["filled"] and not np.isnan(r.get("mae", np.nan))]
    risk = {}
    if len(fills) >= min_fills:
        fam_q = np.quantile([-r["mae"] for r in fills], 0.8)
        for g in groups:
            fg = [-r["mae"] for r in fills if X.level1(_actx(r)) == g]
            if len(fg) >= min_fills and fam_q > 0:
                risk[g] = float(np.clip(np.quantile(fg, 0.8) / fam_q, *RISK_CLIP))
    return {"eligible": eligible, "risk": risk, "groups": info, "parent": float(parent) if not np.isnan(parent) else np.nan,
            "tau2": float(tau2) if not np.isnan(tau2) else np.nan}


def learn_a3(rows_by_family, base_key, f_train_by_family, boot, families, min_n2=MIN_N2, alpha=ALPHA):
    """Specialised overrides {Level 2 cell: family} learned on training years. rows_by_family: {family key: A1 rows};
    families: {family key: Family object}."""
    def cell_stats(rows, f):
        rs = armed_settled(rows)
        lift = _lift(rs, f) if rs else np.array([])
        day = np.array([r["t_idx"] for r in rs])
        cells = [X.level2(_actx(r)) for r in rs]
        out = {}
        for c in set(cells):
            m = np.array([cc == c for cc in cells])
            if m.sum() >= min_n2:
                out[c] = boot.mean(*boot.by_day(day[m], lift[m])) + (int(m.sum()),)
        return out
    base = cell_stats(rows_by_family[base_key], f_train_by_family[base_key])
    others = {k: cell_stats(v, f_train_by_family[k]) for k, v in rows_by_family.items() if k != base_key}
    cand, obs, boots = [], [], []
    for c, (mb, bb, nb) in base.items():
        best = None
        for k, st in others.items():
            if c in st and (best is None or st[c][0] > best[1][0]):
                best = (k, st[c])
        if best is None or not (best[1][0] > mb):
            continue
        cand.append((c, best[0]))
        obs.append(best[1][0] - mb)
        boots.append(best[1][1] - bb)
    overrides, tested = {}, []
    if cand:
        t, p = max_t(obs, boots, two_sided=True)
        for (c, k), d, tt, pp in zip(cand, obs, t, p):
            keep = bool(pp < alpha and d > 0)
            tested.append({"cell": c, "family": k, "diff": float(d), "t": float(tt), "p_maxt": float(pp), "kept": keep})
            if keep:
                overrides[c] = families[k]
    return {"overrides": overrides, "tested": tested, "cells_base": len(base)}


def pair_tests(rows, f_train, boot, prefix="actx_"):
    """The declared pairs P1-P4: mean lift (A) minus mean lift (B), the same family, shared session draws."""
    rs = armed_settled(rows)
    out = {}
    if not rs:
        return out
    lift = _lift(rs, f_train)
    day = np.array([r["t_idx"] for r in rs])
    for name, fn in X.PAIRS.items():
        lab = np.array([fn(_actx(r, prefix)) or "" for r in rs])
        a, b = lab == "A", lab == "B"
        rec = {"n_a": int(a.sum()), "n_b": int(b.sum())}
        if a.sum() >= MIN_N and b.sum() >= MIN_N:
            ma, ba = boot.mean(*boot.by_day(day[a], lift[a]))
            mb, bb = boot.mean(*boot.by_day(day[b], lift[b]))
            s = summary(ma - mb, ba - bb)
            se = s["se"]
            z = (ma - mb) / se if se and se > 0 else np.nan
            rec.update({"lift_a": float(ma), "lift_b": float(mb), "a_minus_b": s,
                        "p_two_sided": float(math.erfc(abs(z) / math.sqrt(2.0))) if not np.isnan(z) else np.nan})
        out[name] = rec
    return out


def context_tests(rows, f_train, boot, min_n=MIN_N, min_n2=MIN_N2):
    """Level 1 (at the arming close and at T), the declared pairs, Level 2 with pooling."""
    rs = armed_settled(rows)
    out = {"n": len(rs)}
    if not rs:
        return out
    out["level1_arming"] = context_table(rs, f_train, boot, key=lambda r: X.level1(_actx(r)), min_n=min_n)
    out["level1_at_T"] = context_table(rs, f_train, boot, key=lambda r: X.level1(_actx(r, "ctx_")), min_n=min_n)
    out["pairs_arming"] = pair_tests(rs, f_train, boot)
    out["pairs_at_T"] = pair_tests(rs, f_train, boot, prefix="ctx_")
    l2 = context_table(rs, f_train, boot, key=lambda r: X.level2(_actx(r)), min_n=min_n2)
    out["level2"] = l2
    out["level2_pooled"] = pool_cells(l2, X.level2_parent) if l2 else {}
    return out
