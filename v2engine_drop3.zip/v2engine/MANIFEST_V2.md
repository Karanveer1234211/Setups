# MANIFEST_V2.md - v2engine 0.3 (drop 3), 31 Oct 2026

Unzip so that C:\Users\karanvsi\PyCharmMiscProject\v2engine\ holds exactly these files (delete the drop 2 folder first). Nothing to ignore; nothing goes into bigmove_deploy, tradelab or pathlab.

| file | sha256 (first 16) | bytes |
|---|---|---|
| README_V2.md | 8d6a346557aac0f3 | 5,010 |
| V2_DROP3_DECLARATION.json | 634b0fcd5ec972a5 | 9,959 |
| env_v2.bat | 8933f1140a9c3a06 | 1,791 |
| tests\test_drop3.py | 3df2c8b5b838947d | 34,448 |
| tests\test_v2.py | b2afaeb5a3013c5e | 40,603 |
| tests\v2_synth_data.py | 97a98648684a1ef9 | 1,717 |
| tests\v2_world.py | c4603f88cfe5412f | 7,776 |
| tests\v2_world3.py | caa028d3d3bcb409 | 8,147 |
| v2_arch.py | e2ea7e5d0060ba8a | 9,447 |
| v2_book2.py | ba16d01c70718c1a | 17,565 |
| v2_core.py | 530938838f6de093 | 27,480 |
| v2_ctx.py | 9d1e31b9fed9a846 | 4,603 |
| v2_data.py | 35ce964e2be90041 | 17,382 |
| v2_eval.py | 4b5eb0da21afd0e9 | 6,420 |
| v2_families.py | 17bd56a032bfc063 | 11,880 |
| v2_lab.py | ea4b833e095d7b9e | 8,906 |
| v2_learn.py | 5d62a87c83da3501 | 5,810 |
| v2_money.py | 0882effbff43bc77 | 14,870 |
| v2_report.py | d5e50ebcfcec0d1d | 11,252 |
| v2_research.py | b9eaeed81a02749d | 16,435 |
| v2_run.py | ed7be04c19beb1b0 | 23,001 |
| v2_stats.py | bd517d03283e2b25 | 4,768 |
| v2engine.py | fa59e29986bddb04 | 5,670 |
