# setuplab v0.1 - entry setups for engine D's picks vs the model's D1 entry, on the same trades

Built 7 Nov 2026. Two files: `setuplab.py` and `tests\test_setuplab.py`. Reads ChatGPT's compact backtester data
(read only); writes only into the `--out` folder.

## What it does
- Re-implements the A/B/C backtester's rules (backtest.pyz) vectorised: first qualifying open D1..D5, conditions
  read at the previous session, exits original_d5 or fresh (5 sessions), 0.35 pp cost. **Reproduces all 60
  delivered ledgers exactly** (status, entry day, net; largest difference 7e-15 pp).
- Your comparison: each setup's own filled trades vs the model's D1 entry on exactly those trade ids, with 95%
  circular block-bootstrap intervals over signal days.
- Controls on the same ids (no indicators): blind D2 / D3, price dips (DIP_0..DIP_5 % under the D1 open, DIPATR_x
  ATR), bounce markers (down, then a green day / an up close), Tuesday entries (TUE, TUE_DIP_2 - the weekly
  feature changes on Mondays, so its setups can only fire on a Tuesday open).
- The whole pair space of the features (every pair of change directions = A/B/C's family), B / A+B with dips, and
  an exploration of what adds most on top of a 2% dip.

## Install and run (cmd)
Put the two files in `C:\Users\karanvsi\PyCharmMiscProject\setuplab\` (tests in `setuplab\tests\`). Set `ABC` to
the folder where you extracted BigMove_ABC_Compact (it holds `data\` and `behaviour_features.parquet`).

    cd /d C:\Users\karanvsi\PyCharmMiscProject\setuplab
    set ABC=C:\path\to\BigMove_ABC_Compact
    python setuplab.py --selftest
    python setuplab.py reproduce --data %ABC%\data --features %ABC%\behaviour_features.parquet --ledgers %ABC%\combination_runs\<hash>
    python setuplab.py run --data %ABC%\data --features %ABC%\behaviour_features.parquet --out C:\QuantData\setuplab\RUN_001

Expected: `21 checks, 0 failed` / `VERIFIED (setuplab v0.1)`; reproduce prints `REPRODUCED`; run takes about a
minute. Needs numpy, pandas, pyarrow (scipy not needed).

**Model features (after the engine D rebuild):** point `--features` at any parquet with symbol + timestamp (or
date) and feature columns, and list the columns to test (big panels are read column by column):

    python setuplab.py run --data %ABC%\data --features %CACHE_DAILY_ROOT%\panel\panel.parquet --columns f1,f2,f3 --out C:\QuantData\setuplab\RUN_002

A missing `<feature>_change` column is computed as the change from the symbol's previous row.

## Outputs
`REPORT.md`; `vs_D1.csv` (every setup vs D1, both exits, with coverage and its percentile in the pair space);
`vs_price_controls.csv` (A/B/C and the combos vs every control on the same ids); `by_year.csv`;
`explore_on_dip.csv`; `ledgers\` (every non-space setup's trade ledger).

## Verified
21 checks: hand-computed trades (entry, gap, both exits, drawdown, zero changes, missing-data rules, dips, ATR dip,
Tuesday, bounce), and three planted worlds - a real setup is found and beats the dip control; in a fall-then-bounce
world noise setups beat D1 (the waiting trap) but NOT the dip control; in a random walk nothing beats D1.
Plus the 60-ledger reproduction on the real data.

## Read with care
Everything here is exploratory on the history the setups were found on (2020-2026, 2026 included). The combos and the
dip exploration were chosen after the first run. The forward paper ledger is the only clean test.
