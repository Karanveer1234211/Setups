@echo off
rem env_playbook.bat - playbook v1.1 (BMPB2): start a playbook session in cmd.
rem   call C:\Users\karanvsi\PyCharmMiscProject\playbook\env_playbook.bat
rem Runs v2engine's env_v2.bat (bigmove_deploy's env_daily.bat: CACHE_DAILY_ROOT; PYTHONPATH to v2engine, pathlab,
rem tradelab, open_close; V2_OUT), then puts playbook first on PYTHONPATH. Reads production READ ONLY.
rem Writes only under PB_OUT. Edit the paths below if your folders differ.
set "V2_ENV=C:\Users\karanvsi\PyCharmMiscProject\v2engine\env_v2.bat"
set "PB_DIR=C:\Users\karanvsi\PyCharmMiscProject\playbook"
set "PB_OUT=C:\QuantData\playbook"
if not exist "%V2_ENV%" goto :no_v2
if not exist "%PB_DIR%\playbook.py" goto :no_pb
set "PYTHONPATH="
call "%V2_ENV%"
if "%PYTHONPATH%"=="" goto :v2_failed
if "%CACHE_DAILY_ROOT%"=="" goto :no_root
set "PYTHONPATH=%PB_DIR%;%PYTHONPATH%"
if not exist "%PB_OUT%" mkdir "%PB_OUT%"
cd /d "%PB_DIR%"
echo playbook ready: CACHE_DAILY_ROOT=%CACHE_DAILY_ROOT%   PB_OUT=%PB_OUT%
goto :eof
:no_v2
echo ERROR: %V2_ENV% not found - edit V2_ENV at the top of env_playbook.bat
exit /b 1
:no_pb
echo ERROR: playbook.py not found in %PB_DIR% - edit PB_DIR at the top of env_playbook.bat
exit /b 1
:v2_failed
echo ERROR: env_v2.bat stopped (its message is above) - playbook needs v2engine 0.3, tradelab and pathlab
exit /b 1
:no_root
echo ERROR: env_v2.bat ran but CACHE_DAILY_ROOT is empty
exit /b 1
