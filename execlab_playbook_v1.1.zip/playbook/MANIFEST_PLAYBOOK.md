# MANIFEST - playbook v1.1 (BMPB2, 1 Nov 2026)

Folder: C:\Users\karanvsi\PyCharmMiscProject\playbook\ (next to v2engine\, tradelab\, pathlab\), replacing v1.0's
files. Needs: v2engine 0.3 (drop 3), tradelab v1.3.1, pathlab, bigmove_deploy's env_daily.bat; Python 3.12 / 3.13
with numpy and pandas. On TradingView: replace the whole script with BigMove_Playbook.pine (v1.1).
env_playbook.bat has CRLF line endings and labels no_v2, no_pb, v2_failed, no_root (no duplicates).
Outputs only under PB_OUT (C:\QuantData\playbook).

| file | lines | bytes | sha256 (first 16) |
|---|---|---|---|
| BigMove_Playbook.pine | 1488 | 103716 | ee1bd8850431fec4 |
| README_PLAYBOOK.md | 150 | 11541 | fa39ae95febc6339 |
| env_playbook.bat | 32 | 1436 | fc5b2d2f1856b7b3 |
| pb_core.py | 665 | 29271 | 2dbcc9877c49e726 |
| playbook.py | 493 | 27490 | 30776f2b1a633668 |
| tests\data\NSE_IRCTC_1D.json | 5 | 11880 | ad7915077c26c2fe |
| tests\pb_mutate.py | 82 | 4550 | 0d1b88dafd95790e |
| tests\pine_lint.py | 382 | 18511 | 1cd46846ef6a7384 |
| tests\pine_twin.py | 267 | 10652 | 9640c4c9d4cd1109 |
| tests\test_playbook.py | 788 | 47387 | a8bf51ba69f68c57 |

Verified 1 Nov 2026: 89 checks, 0 failed (full: 24,000 twin cases, the Pine linted with pynescript 0.3.0) on Python 3.13 / numpy 2.5.3 / pandas 3.0.5; 88 checks, 0 failed (quick) on Python 3.13 and on Python 3.12 / numpy 2.4.1 / pandas 2.3.3; 10 of 10 planted bugs caught (tests\pb_mutate.py); 4 of 4 planted Pine mistakes caught by the linter; the twin = pb_core on 3,740 cases on real NSE:IRCTC bars from TradingView. The Pine has not been compiled by TradingView.
