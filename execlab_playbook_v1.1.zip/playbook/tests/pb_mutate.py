r"""pb_mutate.py - plants one bug at a time in a copy of the playbook bundle and requires the quick self-test to catch it.

  python tests\pb_mutate.py            every mutation (the quick suite: no Pine lint, 6,000 twin cases)
  python tests\pb_mutate.py swing      only the mutations whose name contains 'swing'
A crash is not a catch: a mutation counts only when the suite prints a FAIL line.
"""
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

MUTATIONS = [
    ("re-set buy stop without its ATR offset", "pb_core.py",
     "                    trig = base + pb.O * b.atr[a]\n", "                    trig = base\n"),
    ("invalidation not checked while waiting", "pb_core.py",
     "            if a > t and is_invalid(b, t, a, pb, lvl):", "            if False and is_invalid(b, t, a, pb, lvl):"),
    ("invalidation not checked on the window's last evening", "pb_core.py",
     "            if is_invalid(b, t, t + V, pb, lvl):          # the closing evening", "            if False:          # the closing evening"),
    ("swing-low stop placed above the close", "pb_core.py",
     "        stop = s if s < b.c[e] else np.nan", "        stop = s"),
    ("close exit on the entry session", "pb_core.py",
     '        elif pb.XC != "NONE" and j > e:', '        elif pb.XC != "NONE":'),
    ("twin: range low without the current session", "tests/pine_twin.py",
     "            base = b.ema[i] if E == \"LMEMA\" else b.rng_low(i, NN)", "            base = b.ema[i] if E == \"LMEMA\" else b.rng_low(i - 1, NN)"),
    ("swing high needs a strictly higher right side", "pb_core.py",
     "            if h[p] > max(h[p - k:p]) and h[p] >= max(h[p + 1:i + 1]):", "            if h[p] > max(h[p - k:p]) and h[p] > max(h[p + 1:i + 1]):"),
    ("the map ignores S05", "pb_core.py",
     "                (not r.regimes or regime in r.regimes) and (not r.s05 or s05 in r.s05):", "                (not r.regimes or regime in r.regimes):"),
    ("a v1.1 default differs from the Pine's", "pb_core.py",
     '"P7": Playbook("P7", "SWHI", 0.10, 10, 0.3, 0.0, "NONE", IV="SWL", IK=0.0,', '"P7": Playbook("P7", "SWHI", 0.10, 10, 0.3, 0.0, "NONE", IV="SWL", IK=0.5,'),
    ("time stop on the wrong side", "tests/pine_twin.py",
     "elif int(pb.TS) > 0 and held == int(pb.TS) and not (b.c[i] > epx * (1 + pb.TSP / 100.0)):", "elif int(pb.TS) > 0 and held == int(pb.TS) and b.c[i] > epx * (1 + pb.TSP / 100.0):"),
]


def run_suite(d):
    r = subprocess.run([sys.executable, str(d / "tests" / "test_playbook.py"), "quick"], cwd=str(d),
                       env=dict(os.environ), capture_output=True, text=True)
    return r, [ln.strip()[:110] for ln in r.stdout.splitlines() if ln.startswith("  FAIL")][:2]


def main():
    pick = sys.argv[1:]
    todo = [m for m in MUTATIONS if not pick or any(k in m[0] for k in pick)]
    tmp = Path(tempfile.mkdtemp(prefix="pbmut_"))
    caught = 0
    try:
        d = tmp / "playbook"
        shutil.copytree(ROOT, d, ignore=shutil.ignore_patterns("__pycache__"))
        r, fails = run_suite(d)                 # the copy without a bug must pass, or every 'catch' means nothing
        if r.returncode != 0 or fails:
            print("BASELINE FAILS in the copy (set V2_DIR, PATHLAB_DIR and TRADELAB_DIR): %s" % (
                fails or r.stdout.splitlines()[-2:] + r.stderr.splitlines()[-3:]))
            return 2
        print("  baseline: the unmutated copy passes")
        for name, fn, old, new in todo:
            d = tmp / "playbook"
            if d.exists():
                shutil.rmtree(d)
            shutil.copytree(ROOT, d, ignore=shutil.ignore_patterns("__pycache__"))
            src = (d / fn).read_text(encoding="utf-8")
            if src.count(old) != 1:
                print("  SKIP?  %s: the original text is not unique in %s (%d)" % (name, fn, src.count(old)))
                continue
            (d / fn).write_text(src.replace(old, new), encoding="utf-8")
            r, fails = run_suite(d)
            ok = r.returncode != 0 and bool(fails)
            caught += ok
            print("  %s  %s   %s" % ("caught" if ok else "MISSED", name, fails if ok else
                                        (r.stdout.splitlines()[-2:] + r.stderr.splitlines()[-2:])), flush=True)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("%d of %d planted bugs caught" % (caught, len(todo)))
    return 0 if caught == len(todo) else 1


if __name__ == "__main__":
    sys.exit(main())
