r"""pine_twin.py - the Pine strategy's logic for one pick, bar by bar, with a minimal TradingView broker emulator.

BigMove_Playbook.pine is a transliteration of run_twin() below (same states, same order of steps at each close).
pb_core.simulate_pick() is an independent window-loop implementation of the same rules. The tests run both on
thousands of random bar paths and playbooks and require identical trades: a disagreement is a bug in one of them.

Broker (TradingView, daily bars, no bar magnifier, orders placed at a close act from the next bar):
    an open position: a 'close at the next open' order fills at the open first; else the exit orders (stop / target)
    via the path rule; a pending entry: market at the open, limit, stop, stop-limit (pb_core's fill helpers).
"""
import math

import numpy as np

import pb_core as P

WAIT, WORK, IN, DONE = "WAIT", "WORK", "IN", "DONE"
FINAL = ("SKIP", "NO_ORDER", "NO_LEVEL", "NO_ATR", "NO_FILL", "INVALID")


class Broker:
    def __init__(self, b):
        self.b = b
        self.entry = None          # ("MKT"|"LMT"|"STP"|"STL", trig, lim), active from the bar after it is placed
        self.pos = None            # (entry_i, px)
        self.exit = None           # (stop, tgt)
        self.close_next = False
        self.closed = None         # (exit_i, px, how)

    # orders (called by the script at a close)
    def place(self, kind, trig=np.nan, lim=np.nan):
        self.entry = (kind, trig, lim)

    def cancel(self):
        self.entry = None

    def set_exit(self, stop, tgt):
        self.exit = (stop, tgt)

    def close_at_open(self):
        self.close_next = True

    def close_now(self, i):
        self.closed = (i, float(self.b.c[i]), "NOW")
        self.pos = None

    # one bar of the emulator (before the script runs at its close)
    def bar(self, i):
        o, h, l = self.b.o[i], self.b.h[i], self.b.l[i]
        if self.pos is not None and self.pos[0] < i:
            if self.close_next:
                self.closed = (i, float(o), "OPEN")
                self.pos = None
                return
            if self.exit is not None:
                ex = P.exit_in_bar(o, h, l, self.exit[0], self.exit[1])
                if ex is not None:
                    self.closed = (i, float(ex[0]), ex[1])
                    self.pos = None
            return
        if self.entry is not None and self.pos is None and self.closed is None:
            kind, trig, lim = self.entry
            if kind == "MKT":
                px = o
            elif kind == "LMT":
                px = P.fill_limit_buy(o, h, l, lim)
            elif kind == "STP":
                px = P.fill_stop_limit(o, h, l, trig, None)
            else:
                px = P.fill_stop_limit(o, h, l, trig, lim)
            if px is not None:
                self.pos = (i, float(px))
                self.entry = None


def run_twin(b, t, pb, lvl, comm):
    """Same result dict as pb_core.simulate_pick."""
    n = b.n
    r = {"status": "", "entry_i": None, "entry_px": np.nan, "exit_i": None, "exit_px": np.nan, "reason": "",
         "net": np.nan, "gross": np.nan, "trig": np.nan, "stop": np.nan, "target": np.nan, "armed": False,
         "entry_how": ""}
    br = Broker(b)
    st = WAIT
    why = ""                     # NO_ORDER / NO_LEVEL / NO_ATR / NO_FILL (kept if there is no fallback)
    mode = ""                    # "MKT": a market order is pending (fills at the next open)
    how = "ORDER"
    E, V, NN = pb.E, int(pb.V), int(pb.N)
    trig = lim = np.nan
    atrT = b.atr[t]
    ebar = None
    epx = stop = tgt = hic = np.nan
    armed = False
    txbar = None
    xwhy = ""                    # why the position is sold at the next open: TIME / TSTOP / XCLOSE
    hold = int(pb.H)
    max_hold = int(pb.EX) if (pb.TR and int(pb.EX) > hold) else hold
    cpct = comm / 100.0

    def stl(tr, atr_now):
        return ("STL", tr, tr + pb.L * atr_now) if pb.L > 0 else ("STP", tr, np.nan)

    def fallback(reason):
        nonlocal st, why, mode, how
        why = reason
        if pb.F == "OPEN":
            br.place("MKT")
            mode, how, st = "MKT", "FALLBACK", WORK
        else:
            st = reason

    def invalid(i):
        if pb.IV == "TLOW":
            x = b.l[t] - pb.IK * atrT
        elif pb.IV == "LVL":
            x = lvl - pb.IK * atrT
        elif pb.IV == "SWL":
            x = b.swl[i] - pb.IK * b.atr[i]
        elif pb.IV == "EMA50":
            x = b.ema50[i] - pb.IK * b.atr[i]
        else:
            return False
        return bool(np.isfinite(x) and b.c[i] < x)

    def reset_order(i):
        """STPD / SWHI / STRNG / LMEMA / LMRNG: a fresh order for the next bar, or none this evening."""
        if not np.isfinite(b.atr[i]):
            br.cancel()
            return
        if E in ("STPD", "SWHI", "STRNG"):
            base = b.h[i] if E == "STPD" else (b.swh[i] if E == "SWHI" else b.rng_high(i, NN))
            tr = base + pb.O * b.atr[i]
            if np.isfinite(tr) and tr > b.c[i]:
                br.place(*stl(tr, b.atr[i]))
            else:
                br.cancel()
        else:
            base = b.ema[i] if E == "LMEMA" else b.rng_low(i, NN)
            br.place("LMT", lim=base + pb.O * b.atr[i])

    for i in range(t, n):
        if i > t:
            br.bar(i)
        k = i - t
        # ---- detection (what the broker did during bar i)
        if st == WORK and br.pos is not None and br.pos[0] == i:
            st, ebar, epx = IN, i, br.pos[1]
        if st == IN and br.closed is not None:
            xi, xpx, xhow = br.closed
            st = DONE
            if xhow == "OPEN":
                reason = xwhy
                if np.isfinite(stop) and b.o[xi] <= stop:
                    reason = "STOP_GAP"
                elif np.isfinite(tgt) and b.o[xi] >= tgt:
                    reason = "TARGET_GAP"
            elif xhow == "NOW":
                reason = "TIME"
            else:
                reason = xhow
            if armed and reason.startswith("STOP"):
                reason = "TRAIL" + reason[4:]
            r.update(exit_i=xi, exit_px=xpx, reason=reason)
            break
        # ---- the script at close i
        if k == 0:
            if E == "SKIP":
                st = "SKIP"
            elif invalid(i):
                st = "INVALID"
            elif E == "OPEN":
                st = WORK
                if pb.G > 0:
                    lim = b.c[t] * (1 + pb.G / 100.0)
                    br.place("LMT", lim=lim)
                else:
                    br.place("MKT")
                    mode = "MKT"
            elif E == "DELAY":
                st = WORK
            elif E in ("STLV", "LMLV") and not np.isfinite(lvl):
                fallback("NO_LEVEL")
            elif not np.isfinite(atrT):
                fallback("NO_ATR")
            else:
                st = WORK
                if E in ("STH", "STLV"):
                    trig = (b.h[t] if E == "STH" else lvl) + pb.O * atrT
                    if trig > b.c[t]:
                        br.place(*stl(trig, atrT))
                    else:
                        fallback("NO_ORDER")
                elif E in ("LMLV", "LMTC"):
                    lim = (lvl + pb.O * atrT) if E == "LMLV" else (b.c[t] - pb.O * atrT)
                    br.place("LMT", lim=lim)
                else:                                         # STPD SWHI STRNG LMEMA LMRNG
                    reset_order(i)
        elif st == WORK and mode != "MKT":
            if invalid(i):                                    # the setup broke while the entry waited
                br.cancel()
                st = "INVALID"
            elif E == "OPEN":                                 # the gap-capped limit had its one session
                br.cancel()
                fallback("NO_FILL")
            elif E == "DELAY":
                if k == V:
                    br.place("MKT")
                    mode = "MKT"
            elif k >= V:                                      # the window is over
                br.cancel()
                fallback("NO_FILL")
            elif E in ("STH", "STLV"):
                if not (trig > b.c[i]):                       # already through: cancelled
                    br.cancel()
                    fallback("NO_FILL")
            elif E in ("STPD", "SWHI", "STRNG", "LMEMA", "LMRNG"):
                reset_order(i)
        if st == IN:
            if i == ebar:
                stop, tgt = P.stop_target(b, t, i, epx, pb, lvl)
                hic = epx
            hic = max(hic, b.c[i])
            if pb.TR:
                if not armed and b.c[i] > epx * (1 + pb.TA / 100.0):
                    armed = True
                if armed and np.isfinite(b.atr[i]):
                    lv = max(epx * (1 + 2 * cpct), hic - pb.TM * b.atr[i])
                    stop = lv if not np.isfinite(stop) else max(stop, lv)
            if np.isfinite(stop) or np.isfinite(tgt):
                br.set_exit(stop, tgt)
            held = i - ebar + 1
            if txbar is None:
                if held >= (max_hold if armed else hold):
                    txbar = i
                    if pb.X == "CLOSE":
                        br.close_now(i)
                        st = DONE
                        r.update(exit_i=i, exit_px=float(b.c[i]), reason="TIME")
                        break
                    xwhy = "TIME"
                    br.close_at_open()
                elif int(pb.TS) > 0 and held == int(pb.TS) and not (b.c[i] > epx * (1 + pb.TSP / 100.0)):
                    txbar, xwhy = i, "TSTOP"
                    br.close_at_open()
                elif pb.XC != "NONE" and i > ebar:
                    base = b.ema[i] if pb.XC == "EMA20" else (b.ema50[i] if pb.XC == "EMA50" else b.swl[i])
                    x = base - pb.XK * b.atr[i]
                    if np.isfinite(x) and b.c[i] < x:
                        txbar, xwhy = i, "XCLOSE"
                        br.close_at_open()
        if st in FINAL:
            break
    # ---- the result
    r["trig"] = trig if E in ("STH", "STLV") else (lim if E in ("LMLV", "LMTC") else np.nan)
    if st in FINAL:
        r["status"] = st
        return r
    if st in (WAIT, WORK):
        r["status"] = "OPEN_AT_END"
        return r
    if st == IN:
        r.update(status="OPEN_AT_END", entry_i=int(ebar), entry_px=float(epx))
        return r
    r.update(status="FILLED", entry_i=int(ebar), entry_px=float(epx), entry_how=how, stop=stop, target=tgt,
             armed=armed)
    r["gross"] = r["exit_px"] / epx - 1.0
    r["net"] = P.net_of(epx, r["exit_px"], comm)
    return r
