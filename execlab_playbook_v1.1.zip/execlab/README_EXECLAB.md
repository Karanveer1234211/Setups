# execlab v1.1 - the execution research engine on BigMove's selections

Built 1 Nov 2026. For every D and ENS selection (top 3 a day), execlab decides at each close of its ten-session
watch window whether to buy tomorrow (and with which order), wait, or give up, and at each close of a position
whether to keep it, sell at the next open, or put a protective stop or a take-profit on it. It learns those
decisions from 2020-22 only, compares them with the original BigMove (PLAN), OPEN6 and a same-budget open-entry book,
and keeps 2023-25 sealed until you freeze the candidates and the acceptance rule.

## What changed from v1.0

- **The crash.** v1.0 kept every variant's fold models and trades in memory until the end of the run and wrote
  nothing before the last engine finished; its context variants used scikit-learn's categorical path (extra float64
  copies of the training data). On your PC ENS ran out of memory and D's finished results were lost with it.
  v1.1 writes each engine to its own folder the moment it finishes, keeps one variant at a time in memory (the others
  wait on disk), has no categorical inputs, prints the process memory after every step, and **resumes**: run the same
  command again and finished engines are kept, never recomputed.
- **The bifurcation: general vs state vs state + event.** Three model variants, each adding one block:
  `general` (the stock's own bars, no tl_state input), `state` (+ tl_state's confirmed state: one-hot, sessions in
  it, the S05 flag, changed since T), `state_event` (+ the shown event: one-hot, its age, the close's distance to its
  level, changed since T). No market-wide series in any variant (v1.0's context variant carried NIFTY / Smallcap /
  VIX / regime: one value a day shared by the day's three picks). The report puts the three side by side **per
  state and per state x event** (each variant's best configuration against OPEN6, Benjamini-Hochberg).
- **State-anchored orders and structural exits.** New entry orders: ODIP (limit at the entry session's open - 0.25
  ATR), LVL_RT (retest: limit at the event level + 0.25 ATR, offered only while below the close), LVL_RC (reclaim:
  buy stop at the level + 0.25 ATR, only while above the close), SWHI (buy stop at the last confirmed swing high +
  0.1 ATR). New hold orders: STOP_SW (sell stop at the last confirmed swing low - 0.25 ATR), STOP_LV (at the event
  level - 0.25 ATR). An order that cannot be placed at a close (no level, wrong side) is no choice there.
- **New features** (all point-in-time, ATR units): EMA20 / EMA50 gaps, the 10-session move, the 20-session signed
  volume flow, the 20-session return minus NIFTY's, the 15-session range height, the 20-session efficiency, the
  distance to the last swing low / high (tl_state's rule; on the fake cache execlab's swing highs equal tl_state's on
  100% of 18,375 stock-sessions), state age, S05, event age, distance to the event level, state / event changed.
- **Per-state cards**: what the best configuration did in each state (orders used, exits taken, abandons, vs OPEN6).
- **why** (new command): what the engines' picks have in common in the panel (below).

## Install (cmd)

Unzip so that `C:\Users\karanvsi\PyCharmMiscProject\execlab\` sits next to `v2engine\`, `tradelab\`, `pathlab\`
(replace the v1.0 files; your C:\QuantData\execlab output folder stays as it is).

    call C:\Users\karanvsi\PyCharmMiscProject\execlab\env_execlab.bat
    python execlab.py --selftest quick

Expected last two lines: `48 checks, 0 failed (... s)` and `VERIFIED (execlab v1.1)`. Run one heavy job at a time:
two scikit-learn jobs side by side on the same cores slow each other down many times over.

## 1. Discover (2020-22; 2023-25 is not even loaded)

Both engines in one process:

    python execlab.py discover --root %CACHE_DAILY_ROOT% --out %XL_OUT%

or, if memory is tight, one engine per process into the same run (the second command reports both engines):

    python execlab.py discover --root %CACHE_DAILY_ROOT% --out %XL_OUT% --engines D
    python execlab.py discover --root %CACHE_DAILY_ROOT% --out %XL_OUT% --engines D,ENS

If a run stops part-way (memory, power, Ctrl+C), run the same command again: the log says which engines it keeps.
The same finished run twice is refused (`--again` repeats it).

Time and memory, measured on the 2-core build machine at your scale (a synthetic world with 2,058 selections, the
declaration as written): one engine, one variant (state_event, the widest) with its 4 hurdles took 647 s (hold learning
279 s, then 84 s per hurdle) and peaked at 859 MB. The whole run (2 engines x 3 variants) is about an hour there;
scikit-learn uses every core, so a PC with more cores is faster. Your real load adds the cache's bars on top.

Per engine: 3 variants (general / state / state_event) x 4 hurdles (0 / 25 / 50 / 100 bp) = 12 configurations.
Writes `%XL_OUT%\disc_<id>\`:

- `<engine>\` (written when that engine finishes): `section.md`, `ledger_research.csv`, `ledger_execution.csv`,
  `configs.csv`, `daily_returns.csv`, `state_tables.csv`, `cards_setup.csv`, `cards_exit.csv`, `models.pkl`,
  `DONE.json`
- `REPORT.md` - per engine: the research ledger table (every selection on its own: net per selection with unfilled
  = 0, vs OPEN6, vs PLAN, majors captured / missed, bad trades avoided, false triggers), the execution ledger table
  (Rs 10 lakh, your budgets: CAGR, worst drawdown, CAGR at a -25% drawdown, daily excess over the same-budget open
  entry with its interval, Romano-Wolf adjusted p), PBO, the candidates; **general vs state vs state + event by
  state and by state | event**; for the best configuration: orders and exits, majors, the per-state cards, entry-lag
  cohorts, abandons, setup cards, exit cards, the intraday study (exploratory)
- the same CSVs combined over the finished engines, `candidates.json`, `models.pkl`, `RUN.json` (with the engines
  requested and finished)
- `ledger_research.csv` carries tl_state's state and event group at T for every selection (`state_T`, `event_T`)

## 2. Why the engines pick what they pick (exploratory, 2020-22)

    python execlab.py why --root %CACHE_DAILY_ROOT% --out %XL_OUT%

Reads `%CACHE_DAILY_ROOT%\panel_oc\panel.parquet` READ ONLY (tradelab's reader and label firewall), discovery rows
only, 25 features at a time. Every feature becomes the stock's percentile among that day's panel stocks. Each
engine's top-3 picks are compared with 40 random other panel stocks a day:

- signature: per feature, the picks' mean percentile with a 95% block-bootstrap interval (BH over features)
- surrogate: an ADDITIVE gradient-boosted classifier (every feature on its own) and a FULL one (interactions
  allowed), out of fold over time blocks: their AUC is how much of the selection the panel explains; the gap is how
  much of it needs combinations of features
- drivers: per pick, the additive surrogate's exact term for each feature = what made this stock look like a pick
  (`why_picks.csv`: top 5 per pick with the pick's percentile and the term)
- pairs: Friedman's H^2 between the strongest features under the full surrogate (`why_pairs.csv`)
- the recorded PLAN net (pick_meta) by each pick's top driver (exploratory)

It is a model OF the engine, not the engine's own reasoning: the engines' fold models are not read (if you send the
list of files under the stage D run folders, the attribution can be done on the engines themselves). Writes
`%XL_OUT%\why_<id>\WHY.md`, `why_features.csv`, `why_picks.csv`, `why_pairs.csv`, `RUN.json`.

## 3. Freeze (once you have read the discovery report)

    python execlab.py status --out %XL_OUT%
    python execlab.py freeze --out %XL_OUT% --run disc_<id>

The candidates are chosen by the declared rule, not by hand: per engine, configurations whose discovery portfolio
beats the same-budget open entry with a Romano-Wolf adjusted p under 0.20 across the engine's 12, whose own CAGR and
net per selection are above 0, best first, at most 5. Freeze refuses a run with an unfinished engine, a run made
with changed settings (`--quick`, `--variants`, ...), a changed declaration or code, a ranks 1-10 run, or a changed
models file. No candidate = nothing to freeze, and that is the result.

## 4. Evaluate (one shot, the sealed 2023-25)

    python execlab.py evaluate --root %CACHE_DAILY_ROOT% --out %XL_OUT%

Applies the frozen models unchanged to signal days 2023-01-01 .. 2025-12-31. Refused when the code, the declaration,
the models or scikit-learn's version changed after the freeze. An evaluation stopped part-way resumes with the same
command (an engine's sealed result, once written, is never recomputed); a finished one is refused. A1 (daily excess
over the same-budget open entry, interval above 0, own CAGR above 0), A2 (CAGR at a -25% drawdown at least the open
entry's), A3 (major winners' profit captured >= 70%), A4 (excess positive in at least 2 of the 3 years). ACCEPTED =
all four, and still means paper trading first (the production rule).

## How it decides

- Watch (every close T .. T+9; the order acts in the next session only): ABANDON, WAIT, or one of OPEN, BSTOP (close
  + 0.5 ATR), BHIGH (high + 0.1 ATR), SWHI (swing high + 0.1 ATR), LVL_RC (level + 0.25 ATR) - buy stops at max(open,
  trigger) + 0.05 ATR -, LDIP / LDEEP (close - 0.5 / 1 ATR), ODIP (the session's open - 0.25 ATR), LVL_RT (level +
  0.25 ATR) - limits that need the low strictly below them, at min(open, limit). An unfilled order keeps the
  selection watching; an entry is possible on T+1 .. T+10.
- Hold (every close of a position, up to 40 sessions, then the next open): KEEP, EXIT (next open; a locked open waits
  up to 20 sessions), STOP1 / STOP2 (1 / 2 ATR under the close), STOP_SW (swing low - 0.25 ATR), STOP_LV (level - 0.25
  ATR), TP2 (2 ATR over the close).
- Learning: approximate policy iteration with realized values; paired advantage models (each action against the open
  entry / KEEP on the same rows); five purged time-block folds (51 sessions); start OPEN6; three rounds.
- Portfolio: <= 2 entries a day, <= 6 in 5 sessions, <= 8 open, one per stock; orders ranked by estimated advantage;
  1/8 of equity, integer shares, 2% of ADV, cash (v2_money.simulate). Costs: stage E's zerodha_base, fully net.

## Verified here / not

- Fills and exits by hand for all 9 entry and 7 hold orders (gaps, trade-through, locks, the side rules of the level
  and swing orders); the OPEN6 identity (exit session and price, stage E net to 1e-12); the cost stand-in within 2 bp.
- No look-ahead (everything after a cut redrawn, levels and swings included: identical features up to it), no raw
  price level, the label firewall and the nesting general < state < state_event; swings, state age, event levels and
  S05 by hand; execlab's swing highs = tl_state's on the fake cache.
- Planted worlds: the dip entry found in bull states and the open kept in bear states; failed breakouts avoided;
  early exits; major winners held; **state_event > state > general** where the effects are keyed on the state and the
  event; no configuration ever chose an order that could not be placed. Absent and null worlds: no positive edge.
- The CLI: discovery never loads 2023; refusals; freeze -> one evaluation; **a run stopped in ENS keeps D and resumes
  ENS only**; the fake production cache through v2engine's adapter; `why` on the fake cache.
- `why` on a planted panel: the planted features found, the planted pair as the strongest interaction, AUC 0.996;
  on random picks AUC 0.49 and no feature flagged.
- 30 planted bugs (tests\xl_mutate.py), each caught by a failing check.
- 48 checks, 0 failed on Python 3.13 / numpy 2.5.3 / pandas 3.0.5 / scikit-learn 1.9.1 and on Python 3.12 / numpy
  2.4.1 / pandas 2.3.3 / scikit-learn 1.5.2 (quick).
- **Not verified: your machine's memory.** The memory line after each step is there so that a run that grows shows
  where.

## Discipline

2020-22 is the discovery period. v1.0's discovery (D: no candidate; ENS: stopped by memory) stays on the record;
v1.1 is a second, separately declared look at the same years, which is exactly why the one-shot sealed 2023-25 stays
the judge. Everything in a discovery or why report is a hypothesis. Edit the declaration before discovering, never
after looking at a sealed result.
