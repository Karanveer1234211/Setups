r"""xl_eval.py - execlab v1.1: the measures (every interval is a 95% circular block bootstrap over signal days or sessions).

research    per selection, unfilled = 0: net, paired against OPEN6 and PLAN; status counts; trades (win rate, hold,
            MFE / MAE); major winners (PLAN net > +8%): profit captured, missed; bad trades (PLAN net < -5%): avoided,
            loss avoided; false triggers (traded and lost); opportunity cost (OPEN6 net of what was not traded)
portfolio   the execution ledger in rupees: CAGR, worst drawdown, Sharpe, CAGR at a -25% worst drawdown; mean daily
            return minus OPEN_SB's (same budgets, same sizing)
families    Romano-Wolf step-down adjusted p-values over all configurations of an engine; PBO by CSCV over their
            daily returns
state       results by tl_state state and by state x event group at T (all selections first), Benjamini-Hochberg;
            with the orders the policy used and the exits it took in each group
cohorts     by entry lag (T+1 .. T+10) and by the close of an abandon
candidates  the declared rule (at most 5 per engine); acceptance A1-A4 on the sealed period
"""
import numpy as np

import xl_feat as F
import xl_sim as S
from xl_common import bh, block_mean, cagr_at_dd, daily_diff, pbo_cscv, romano_wolf



def stat_args(decl):
    s = decl["stats"]
    return {"B": int(s["B"]), "block": int(s["block"]), "seed": int(s["seed"])}


def research_metrics(world, res, op6, decl):
    sa = stat_args(decl)
    days = world.recs["t"]
    o6 = np.nan_to_num(op6["open6"])
    pl = np.nan_to_num(op6["plan"])
    net0 = res["net0"]
    tr = res["status"] == "TRADED"
    out = {"records": int(world.n_rec), "out_of_period": len(world.out_of_period),
           "status": {k: int((res["status"] == k).sum()) for k in np.unique(res["status"])},
           "net": block_mean(days, net0, **sa), "vs_open6": block_mean(days, net0 - o6, **sa),
           "vs_plan": block_mean(days, net0 - pl, **sa), "open6": block_mean(days, o6, **sa),
           "plan": block_mean(days, pl, **sa)}
    nt = res["net"][tr]
    held = (res["x"] - res["e"])[tr]
    out["trades"] = {"n": int(tr.sum()), "win": float(np.mean(nt > 0)) if tr.any() else np.nan,
                     "mean": float(nt.mean()) if tr.any() else np.nan,
                     "median_held": float(np.median(held)) if tr.any() else np.nan,
                     "mfe": _nanmean(res["mfe"][tr]), "mae": _nanmean(res["mae"][tr]),
                     "kinds": {S.ENTRY[k]: int((res["kind"][tr] == k).sum()) for k in range(len(S.ENTRY))},
                     "exits": {S.REASONS[k]: int((res["reason"][tr] == k).sum()) for k in range(1, len(S.REASONS))
                               if (res["reason"][tr] == k).any()}}
    big = float(decl["majors"]["plan_net_above"])
    bad = float(decl["bad"]["plan_net_below"])
    mj = np.isfinite(op6["plan"]) & (op6["plan"] > big)
    bd = np.isfinite(op6["plan"]) & (op6["plan"] < bad)
    den = float(op6["plan"][mj].sum())
    out["majors"] = {"n": int(mj.sum()), "plan_profit": den, "captured": float(net0[mj & tr].sum()),
                     "capture_share": float(net0[mj & tr].sum() / den) if den > 0 else np.nan,
                     "missed": int((mj & ~tr).sum()), "traded": int((mj & tr).sum())}
    out["bad"] = {"n": int(bd.sum()), "avoided": int((bd & ~tr).sum()),
                  "loss_avoided": float(-op6["plan"][bd & ~tr].sum()),
                  "traded_net": float(net0[bd & tr].sum())}
    o6t = np.isfinite(op6["open6"])
    out["false_triggers"] = {"n": int((tr & (res["net"] < 0)).sum()),
                             "share": float(np.mean(res["net"][tr] < 0)) if tr.any() else np.nan,
                             "open6_share": float(np.mean(op6["open6"][o6t] < 0)) if o6t.any() else np.nan}
    nt_ = ~tr
    out["opportunity_cost"] = {"records": int(nt_.sum()), "open6_given_up": float(o6[nt_].sum()),
                               "per_selection": float(o6[nt_].sum() / max(1, world.n_rec))}
    return out


def portfolio_metrics(r, perf, r_base, decl):
    s = decl["stats"]
    out = {k: perf.get(k) for k in ("cagr", "max_dd", "sharpe", "trades", "skipped", "utilisation", "worst_month",
                                    "pos_months", "trade_expectancy", "trade_win_rate")}
    out["at_dd"] = cagr_at_dd(r, float(s["dd_target"]))
    if r_base is not None:
        out["excess"] = daily_diff(r, r_base, B=int(s["B"]), block=int(s["block"]), seed=int(s["seed"]))
    return out


def family(daily, base, decl):
    """daily: {config: daily returns}; base: OPEN_SB's. Romano-Wolf p (one-sided, excess > 0) and PBO."""
    names = list(daily)
    if not names:
        return {}, {"pbo": np.nan}
    s = decl["stats"]
    Dm = np.array([np.asarray(daily[k]) - np.asarray(base) for k in names])
    rw = romano_wolf(Dm, B=int(s["B"]), block=int(s["block"]), seed=int(s["seed"]))
    pbo = pbo_cscv(np.array([daily[k] for k in names]), int(s["pbo_blocks"]))
    return {k: v for k, v in zip(names, rw)}, pbo


def record_groups(world):
    """tl_state's state name and event group of every record at its signal close T."""
    R = world.recs
    st = world.B.st[R["j"], R["t"]]
    ev = world.B.ev[R["j"], R["t"]]
    sname = np.array([F.STATE_NAME.get(int(x), "UNKNOWN") for x in st], dtype=object)
    ename = np.array([F.EVENT_GROUP.get(int(x), "none") for x in ev], dtype=object)
    return sname, ename


def _order_key(name):
    parts = str(name).split("|")
    a = F.STATE_ORDER.index(parts[0]) if parts[0] in F.STATE_ORDER else 99
    b = F.EVENT_ORDER.index(parts[1]) if len(parts) > 1 and parts[1] in F.EVENT_ORDER else (0 if len(parts) == 1 else 99)
    return (name == "other", a, b, str(name))


def group_rows(world, res, op6, decl, key):
    """'all' first, then one row per group (groups under state_tables.min_selections pooled as 'other'): selections,
    traded, abandoned, the policy's net per selection (unfilled 0), OPEN6's and PLAN's, the paired difference vs OPEN6
    (95% block bootstrap over signal days), BH q over the groups, the orders used and the exits taken."""
    sa = stat_args(decl)
    minn = int(decl.get("state_tables", {}).get("min_selections", 30))
    t = world.recs["t"]
    o6 = np.nan_to_num(op6["open6"])
    pl = np.nan_to_num(op6["plan"])
    d = res["net0"] - o6
    key = np.asarray(key, dtype=object)
    small = {g for g in set(key) if int((key == g).sum()) < minn}
    key2 = np.array(["other" if g in small else g for g in key], dtype=object)
    tr_all = res["status"] == "TRADED"
    rows = []
    for g in ["all"] + sorted(set(key2), key=_order_key):
        m = np.ones(len(key2), bool) if g == "all" else key2 == g
        st = block_mean(t[m], d[m], **sa)
        tr = tr_all & m
        orders = {S.ENTRY[k]: int((res["kind"][tr] == k).sum()) for k in range(len(S.ENTRY))}
        exits = {S.REASONS[k]: int((res["reason"][tr] == k).sum()) for k in range(1, len(S.REASONS))}
        rows.append({"group": g, "n": int(m.sum()), "traded": int(tr.sum()),
                     "abandoned": int(((res["status"] == "ABANDONED") & m).sum()),
                     "net": float(np.mean(res["net0"][m])), "open6": float(np.mean(o6[m])),
                     "plan": float(np.mean(pl[m])), "diff": st, "p": st["p"],
                     "orders": {k: v for k, v in orders.items() if v}, "exits": {k: v for k, v in exits.items() if v}})
    sub = rows[1:]
    if sub:
        rej, qv = bh([r["p"] for r in sub], float(decl["stats"]["fdr_q"]))
        for r, rj, q in zip(sub, rej, qv):
            r["q"], r["flag"] = float(q), bool(rj)
    rows[0]["q"], rows[0]["flag"] = np.nan, False
    return rows


def state_tables(world, res, op6, decl):
    """{'by_state': rows, 'by_state_event': rows} for one configuration (see group_rows)."""
    sname, ename = record_groups(world)
    se = np.array(["%s|%s" % (a, b) for a, b in zip(sname, ename)], dtype=object)
    return {"by_state": group_rows(world, res, op6, decl, sname),
            "by_state_event": group_rows(world, res, op6, decl, se)}


def cohorts(world, res):
    tr = res["status"] == "TRADED"
    lag = res["e"] - world.recs["t"]
    out = []
    for L in range(1, world.W + 1):
        m = tr & (lag == L)
        out.append({"lag": L, "n": int(m.sum()), "mean": float(res["net"][m].mean()) if m.any() else np.nan,
                    "held": float(np.median((res["x"] - res["e"])[m])) if m.any() else np.nan,
                    "win": float(np.mean(res["net"][m] > 0)) if m.any() else np.nan})
    ab = res["status"] == "ABANDONED"
    aband = [{"close": "T+%d" % d, "n": int((ab & (res["decision_d"] == d)).sum())} for d in range(world.W)]
    return out, aband


def candidates(cfgs, rw, decl):
    """cfgs: {name: metrics}; rw: Romano-Wolf per name. The declared rule."""
    lim = int(decl["candidates"]["max"])
    ok = [k for k in cfgs if rw.get(k) and np.isfinite(rw[k]["p_adj"]) and rw[k]["p_adj"] < 0.20 and
          rw[k]["mean"] > 0 and cfgs[k]["portfolio"]["cagr"] > 0 and cfgs[k]["research"]["net"]["mean"] > 0]
    ok.sort(key=lambda k: -rw[k]["mean"])
    return ok[:lim]


def acceptance(port, base_port, major_share, yearly_excess, rw_p, n_cand):
    a1 = port["excess"]["lo"] > 0 if np.isfinite(port["excess"].get("lo", np.nan)) else False
    a1 = a1 and port["cagr"] > 0
    if n_cand > 1:
        a1 = a1 and np.isfinite(rw_p) and rw_p < 0.05
    a2 = (np.isfinite(port["at_dd"]["cagr"]) and np.isfinite(base_port["at_dd"]["cagr"]) and
          port["at_dd"]["cagr"] >= base_port["at_dd"]["cagr"])
    a3 = np.isfinite(major_share) and major_share >= 0.70
    pos = [v for v in yearly_excess.values() if np.isfinite(v)]
    a4 = sum(v > 0 for v in pos) >= 2
    return {"A1": bool(a1), "A2": bool(a2), "A3": bool(a3), "A4": bool(a4), "ACCEPTED": bool(a1 and a2 and a3 and a4)}


def yearly(days, r, rb):
    yr = np.asarray(days).astype("datetime64[Y]").astype(int) + 1970
    out = {}
    for y in np.unique(yr):
        m = yr == y
        out[int(y)] = float(np.mean(np.asarray(r)[m] - np.asarray(rb)[m])) if m.any() else np.nan
    return out


def _nanmean(x):
    x = np.asarray(x, dtype=float)
    return float(np.nanmean(x)) if np.isfinite(x).any() else np.nan


def intraday_study(world, res, decl, hurdle_bp, log=print):
    """Trades the policy bought at the open, on entry sessions with usable 3-minute bars (from intraday.from):
    buying at a checkpoint bar's close instead (same exit). 'always' = every such trade at the checkpoint;
    'chosen' = before the open, a ridge model on what was known at the decision close (the stock's general features,
    its tl_state state / event features) picks the checkpoint when it expects the checkpoint's net to beat the open's;
    cross-fitted on purged time blocks of these trades only. Values are paired against the open entry."""
    from xl_common import purged_folds
    import xl_learn as XLL
    D = world.D
    sa = stat_args(decl)
    lo = np.datetime64(decl["intraday"]["from"], "D")
    rows = []
    want = {}
    if getattr(D, "intraday", None) is not None:
        for r in np.flatnonzero((res["status"] == "TRADED") & (res["kind"] == 0)):
            e = int(res["e"][r])
            day = np.datetime64(D.cal.days[e], "D")
            if day >= lo:
                want.setdefault(world.recs["sym"][r], []).append((r, e, day))
    for sym, lst in want.items():
        got = D.intraday.closes(sym, [d for _, _, d in lst])
        for r, e, day in lst:
            if got.get(day) is not None:
                rows.append((r, e, got[day]))
    out = {"sessions": len(rows), "checkpoints": {}}
    if len(rows) < 30:
        out["note"] = "fewer than 30 open entries with usable 3-minute bars on the entry session"
        return out
    rows.sort(key=lambda x: x[0])
    rr = np.array([x[0] for x in rows])
    ee = np.array([x[1] for x in rows])
    j = world.recs["j"][rr]
    Xp = np.c_[world.fs.S[j, ee - 1], world.fs.X[j, ee - 1]]
    days = world.recs["t"][rr]
    K = max(2, min(world.K, 5))
    try:
        folds = purged_folds(days, K, int(decl["learning"]["purge_sessions"]))
    except Exception:              # noqa: BLE001 - too few distinct days: no choice model
        folds = []
    base = res["net"][rr]
    for name, k in decl["intraday"]["checkpoints"].items():
        y = np.full(len(rows), np.nan)
        for q, (r, e, cl) in enumerate(rows):
            pk = cl[k]
            if np.isfinite(pk):
                y[q] = D.cm.trade(D.bars[world.recs["sym"][r]], e, float(pk), int(res["x"][r]), float(res["px"][r]))["net"]
        ok = np.isfinite(y)
        if ok.sum() < 30:
            continue
        diff = y - base
        pred = np.full(len(rows), np.nan)
        for te, tr in folds:
            tr = tr[ok[tr]]
            te = te[ok[te]]
            if len(te) and len(tr) >= 20:
                pred[te] = XLL.Ridge(10.0).fit(Xp[tr], np.clip(diff[tr], -0.2, 0.2)).predict(Xp[te])
        chosen = np.isfinite(pred) & (pred > 0)
        val = np.where(chosen, diff, 0.0)
        out["checkpoints"][name] = {"n": int(ok.sum()), "always": block_mean(days[ok], diff[ok], **sa),
                                    "chosen": block_mean(days[ok], val[ok], **sa), "picked": int(chosen.sum()),
                                    "records": rr[ok], "picked_records": rr[ok & chosen]}
    return out
