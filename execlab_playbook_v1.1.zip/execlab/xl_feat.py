r"""xl_feat.py - execlab v1.1: what is known at a close, as features (point-in-time, no labels, no raw price levels).

Three blocks = the three model variants (the bifurcation: what tl_state's state, then its event, add):
  general      the stock's own bars: returns, ATR %, distance from the 20 / 60-session highs and lows, EMA20 / EMA50
               gaps (in % and in ATRs), where the close sits in the day's range, gap, body, volume ratio, vol20, log
               ADV, ATR5 / ATR20, lock flags, the 10-session move in ATRs, the 20-session volume flow (signed volume
               share), the 20-session return minus NIFTY's, the 15-session range height in ATRs, the 20-session
               efficiency, the distance to the last confirmed swing low / high in ATRs (tl_state's swing rule: higher /
               lower than the 3 bars before, not lower / higher than the 3 after, known 3 sessions later)
               + the selection (rank, raw score, re-selections) + the watch window / the position
  state        general + tl_state's confirmed state (one-hot S01 S02 S03 S06 S07 S08 S09 S12; UNKNOWN and
               INSUFFICIENT_DATA = all 0), sessions in that state, the S05 overextension flag (tl_state's thresholds:
               0, 1 overextended, 2 extreme), state changed since T (watch) / since the entry session (hold)
  state_event  state + tl_state's shown event (one-hot: breakout NEW / CONFIRMED / STALLED, failed breakout,
               breakdown (any status), bear trap = failed breakdown), its age, the close's distance from the event's
               level in ATRs, event changed since T / since the entry session
No market-wide series in any variant (NIFTY / Smallcap / VIX / regime: one value a day shared by the day's three
selections; v1.0's context variant carried them).

Every value at close i uses bars up to i only: the tests redraw everything after a cut and require identical
features up to it, and scale a stock's prices by 10 and require identical features (log ADV, a liquidity level in
rupees, is the one declared exception).
"""
import numpy as np
import pandas as pd

from xl_common import XLError

SYM = ("ret1", "ret3", "ret5", "ret10", "ret20", "atr_pct", "dist_hi20", "dist_lo20", "dist_hi60", "ema20_gap",
       "ema50_gap", "clv", "gap", "body_atr", "vol_ratio", "vol20", "adv_log", "comp", "up_lock", "dn_lock")
GEN_NEW = ("ema20_atr", "ema50_atr", "m10_atr", "flow20", "rs20", "range15_atr", "eff20", "swl_atr", "swh_atr")
GEN = SYM + GEN_NEW
STATE = ("st_S01", "st_S02", "st_S03", "st_S06", "st_S07", "st_S08", "st_S09", "st_S12", "st_age", "s05")
EVENT = ("ev_bo_new", "ev_bo_conf", "ev_bo_stall", "ev_fbo", "ev_bd", "ev_fbd", "ev_age", "lvl_atr")
CTXF = STATE + EVENT                       # stored per stock and close (fs.X)
SEL = ("rank", "score", "resel10", "resel_today")
WATCH = ("day", "ret_since_T", "runup_T", "pullback_T", "move_T_atr")
HOLD = ("age", "lag", "gain", "mfe", "dd_peak", "gain_atr", "kind_stop", "kind_limit")
CHANGE = ("st_chg", "ev_chg")
VARIANTS = ("general", "state", "state_event")

ONEHOT_STATES = (1, 2, 3, 6, 7, 8, 9, 12)
EVENT_ONEHOT = (("ev_bo_new", (1,)), ("ev_bo_conf", (2,)), ("ev_bo_stall", (3,)), ("ev_fbo", (4,)),
                ("ev_bd", (5, 6, 7)), ("ev_fbd", (8,)))
UP_EVENTS = (1, 2, 3, 4)                   # their level: the breakout level (tl_state's s04 log)
DN_EVENTS = (5, 6, 7, 8)                   # the breakdown level (s10 log)
STATE_NAME = {-1: "INSUFFICIENT", 0: "UNKNOWN", 1: "S01", 2: "S02", 3: "S03", 6: "S06", 7: "S07", 8: "S08", 9: "S09",
              12: "S12"}
STATE_ORDER = ("S01", "S02", "S03", "S06", "S07", "S08", "S09", "S12", "UNKNOWN", "INSUFFICIENT")
EVENT_GROUP = {0: "none", 1: "breakout", 2: "breakout", 3: "bo_stalled", 4: "failed_bo", 5: "breakdown", 6: "breakdown",
               7: "breakdown", 8: "bear_trap"}
EVENT_ORDER = ("none", "breakout", "bo_stalled", "failed_bo", "breakdown", "bear_trap")
S05 = {"ext20_atr": 3.0, "ext50_atr": 6.0, "ext10_atr": 6.0, "extreme20_atr": 4.5, "extreme50_atr": 9.0}
SWING_K = 3
AGE_CAP = 250


def firewall(names):
    bad = [n for n in names if n.startswith("label_")]
    if bad:
        raise XLError("label firewall: %s" % bad)
    allowed = set(GEN) | set(CTXF) | set(SEL) | set(WATCH) | set(HOLD) | set(CHANGE)
    unk = [n for n in names if n not in allowed]
    if unk:
        raise XLError("feature(s) not on the declared list: %s" % unk)
    return True


def columns(kind, variant):
    base = GEN + SEL + (WATCH if kind == "watch" else HOLD)
    if variant == "general":
        cols = base
    elif variant == "state":
        cols = base + STATE + ("st_chg",)
    elif variant == "state_event":
        cols = base + STATE + ("st_chg",) + EVENT + ("ev_chg",)
    else:
        raise XLError("unknown variant %r (v1.1: general, state, state_event)" % variant)
    firewall(cols)
    return list(cols)


def state_group(code):
    c = int(code) if np.isfinite(code) else -1
    if c in (1, 2, 3):
        return 0
    if c in (6, 7):
        return 1
    if c in (8, 9):
        return 2
    return 3


def _ffill(x):
    x = np.asarray(x, dtype=float)
    ok = np.isfinite(x)
    idx = np.where(ok, np.arange(len(x)), -1)
    np.maximum.accumulate(idx, out=idx)
    return np.where(idx >= 0, x[np.maximum(idx, 0)], np.nan)


def _lagret(c, k):
    out = np.full(len(c), np.nan)
    if len(c) > k:
        with np.errstate(invalid="ignore", divide="ignore"):
            out[k:] = c[k:] / c[:-k] - 1.0
    return out


def _shift(x, k):
    out = np.full(len(x), np.nan)
    if len(x) > k:
        out[k:] = x[:-k]
    return out


def _roll(x, w, how, minp=None):
    s = pd.Series(x)
    r = s.rolling(w, min_periods=max(2, w // 2) if minp is None else minp)
    return getattr(r, how)().to_numpy(float)


def _ema(x, span):
    return pd.Series(x).ewm(span=span, adjust=False, min_periods=span).mean().to_numpy(float)


def swings(h, l, k=SWING_K):
    """tl_state's confirmed swings on the stock's own bars (missing bars skipped). Returns (swh, swl) on the input
    index: the last swing high / low KNOWN at each close (a swing at bar p needs k bars after it: known at p + k)."""
    h = np.asarray(h, dtype=float)
    l = np.asarray(l, dtype=float)
    n = len(h)
    swh, swl = np.full(n, np.nan), np.full(n, np.nan)
    idx = np.flatnonzero(np.isfinite(h) & np.isfinite(l))
    if len(idx) < 2 * k + 1:
        return swh, swl
    hh, ll = h[idx], l[idx]
    hs, ls = pd.Series(hh), pd.Series(ll)
    lh = hs.rolling(k, min_periods=k).max().shift(1).to_numpy(float)
    rh = hs.rolling(k, min_periods=k).max().shift(-k).to_numpy(float)
    lo_ = ls.rolling(k, min_periods=k).min().shift(1).to_numpy(float)
    ro = ls.rolling(k, min_periods=k).min().shift(-k).to_numpy(float)
    with np.errstate(invalid="ignore"):
        ph = np.flatnonzero(np.isfinite(lh) & np.isfinite(rh) & (hh > lh) & (hh >= rh))
        pl = np.flatnonzero(np.isfinite(lo_) & np.isfinite(ro) & (ll < lo_) & (ll <= ro))
    for out, piv, vals in ((swh, ph, hh), (swl, pl, ll)):
        if len(piv):
            mark = np.full(n, -1, dtype=np.int64)
            mark[idx[piv + k]] = piv
            last = np.maximum.accumulate(mark)
            out[:] = np.where(last >= 0, vals[np.maximum(last, 0)], np.nan)
    return swh, swl


def event_level(ev_codes, events):
    """The level of the event shown at each close: up-side events -> tl_state's breakout level (s04), down-side ->
    the breakdown level (s10); NaN without an event or a level."""
    ev = np.asarray(ev_codes)
    lv = np.full(len(ev), np.nan)
    ev_ = events or {}
    up, dn = ev_.get("s04_level"), ev_.get("s10_level")
    if up is not None:
        lv = np.where(np.isin(ev, UP_EVENTS), np.asarray(up, dtype=float), lv)
    if dn is not None:
        lv = np.where(np.isin(ev, DN_EVENTS), np.asarray(dn, dtype=float), lv)
    return lv


def run_age(code):
    """Sessions since the code last changed (0 on the session it changed)."""
    c = np.asarray(code)
    n = len(c)
    if n == 0:
        return np.zeros(0)
    chg = np.r_[True, c[1:] != c[:-1]]
    start = np.maximum.accumulate(np.where(chg, np.arange(n), 0))
    return (np.arange(n) - start).astype(float)


def stock_features(b, nifty=None, sw=None):
    """(n, len(GEN)) float32: the stock's own features at every close (NaN where unknown)."""
    o, h, l, c0, v = (np.asarray(b[k], dtype=float) for k in ("open", "high", "low", "close", "volume"))
    n = len(c0)
    has = np.isfinite(c0)
    c = _ffill(c0)
    atr = np.asarray(b["atr"], dtype=float)
    prev = np.r_[np.nan, c[:-1]]
    F = np.full((n, len(GEN)), np.nan)
    with np.errstate(invalid="ignore", divide="ignore"):
        tr = np.where(has, np.fmax(h - l, np.fmax(np.abs(h - prev), np.abs(l - prev))), np.nan)
        hh = np.where(has, h, np.nan)
        ll = np.where(has, l, np.nan)
        F[:, 0], F[:, 1], F[:, 2], F[:, 3], F[:, 4] = (_lagret(c, k) for k in (1, 3, 5, 10, 20))
        F[:, 5] = atr / c
        F[:, 6] = c / _roll(hh, 20, "max") - 1.0
        F[:, 7] = c / _roll(ll, 20, "min") - 1.0
        F[:, 8] = c / _roll(hh, 60, "max") - 1.0
        e20, e50 = _ema(c, 20), _ema(c, 50)
        F[:, 9] = c / e20 - 1.0
        F[:, 10] = c / e50 - 1.0
        rng = h - l
        F[:, 11] = np.where(has, np.where(rng > 0, (c0 - l) / np.where(rng > 0, rng, 1.0), 0.5), np.nan)
        F[:, 12] = np.where(has, o / prev - 1.0, np.nan)
        F[:, 13] = np.where(has, (c0 - o) / atr, np.nan)
        vm = _roll(np.where(has, v, np.nan), 20, "median")
        vm_prev = np.r_[np.nan, vm[:-1]]
        F[:, 14] = np.where(has, v / vm_prev, np.nan)
        F[:, 15] = np.asarray(b.get("vol20", np.full(n, np.nan)), dtype=float)
        adv = np.asarray(b.get("adv", np.full(n, np.nan)), dtype=float)
        F[:, 16] = np.where(adv > 0, np.log10(np.where(adv > 0, adv, 1.0)), np.nan)
        F[:, 17] = _roll(tr, 5, "mean") / _roll(tr, 20, "mean")
        F[:, 18] = np.asarray(b["upper_locked"], dtype=float)
        F[:, 19] = np.asarray(b.get("ll_close", b["lower_locked"]), dtype=float)
        g = len(SYM)
        F[:, g + 0] = (c - e20) / atr
        F[:, g + 1] = (c - e50) / atr
        F[:, g + 2] = (c - _shift(c, 10)) / atr
        vv = np.where(has & np.isfinite(v), v, 0.0)
        dc = c - prev
        inc = np.sign(np.nan_to_num(dc)) * vv
        den = _roll(vv, 20, "sum", 20)
        F[:, g + 3] = np.where(den > 0, _roll(inc, 20, "sum", 20) / np.where(den > 0, den, 1.0), np.nan)
        if nifty is not None:
            F[:, g + 4] = F[:, 4] - _lagret(_ffill(nifty), 20)
        F[:, g + 5] = (_roll(hh, 15, "max", 8) - _roll(ll, 15, "min", 8)) / atr
        adc = _roll(np.abs(np.nan_to_num(dc)), 20, "sum", 20)
        F[:, g + 6] = np.where(adc > 0, (c - _shift(c, 20)) / np.where(adc > 0, adc, 1.0), np.nan)
        swh, swl = sw if sw is not None else swings(h, l)
        F[:, g + 7] = (c - swl) / atr
        F[:, g + 8] = (swh - c) / atr
    F[~np.isfinite(F)] = np.nan
    return F.astype(np.float32)


def context_features(st, ev, ev_age, lvl, close, atr, gen):
    """(n, len(CTXF)) float32 from the state / event codes on the calendar, the event age, the event level and the
    stock's general features (for S05: EMA20 / EMA50 gaps and the 10-session move in ATRs)."""
    n = len(st)
    X = np.zeros((n, len(CTXF)))
    st = np.asarray(st)
    ev = np.asarray(ev)
    for q, code in enumerate(ONEHOT_STATES):
        X[:, q] = st == code
    X[:, STATE.index("st_age")] = np.minimum(run_age(st), AGE_CAP)
    d20 = gen[:, GEN.index("ema20_atr")].astype(float)
    d50 = gen[:, GEN.index("ema50_atr")].astype(float)
    m10 = gen[:, GEN.index("m10_atr")].astype(float)
    with np.errstate(invalid="ignore"):
        ext = (d20 >= S05["extreme20_atr"]) | (d50 >= S05["extreme50_atr"])
        over = (d20 >= S05["ext20_atr"]) | (d50 >= S05["ext50_atr"]) | (m10 >= S05["ext10_atr"])
    s05 = np.where(ext, 2.0, np.where(over, 1.0, 0.0))
    s05[~np.isfinite(d20)] = np.nan
    X[:, STATE.index("s05")] = s05
    o = len(STATE)
    for q, (_, codes) in enumerate(EVENT_ONEHOT):
        X[:, o + q] = np.isin(ev, codes)
    ag = np.asarray(ev_age, dtype=float)
    X[:, o + EVENT.index("ev_age")] = np.where((ag >= 0) & (ev != 0), ag, np.nan)
    with np.errstate(invalid="ignore", divide="ignore"):
        X[:, o + EVENT.index("lvl_atr")] = (np.asarray(close, dtype=float) - lvl) / atr
    X[~np.isfinite(X)] = np.nan
    return X.astype(np.float32)


class FeatureStore:
    """S[k, i, :] = stock k's general features at close i; X[k, i, :] = its state / event features (B: xl_sim.Bars,
    which holds the state / event codes, the event level and the swing levels on the calendar)."""

    def __init__(self, D, B):
        self.D = D
        self.syms = list(B.syms)
        self.k = dict(B.k)
        n = D.cal.n
        self.S = np.full((len(self.syms), n, len(GEN)), np.nan, dtype=np.float32)
        self.X = np.full((len(self.syms), n, len(CTXF)), np.nan, dtype=np.float32)
        nifty = ((getattr(D, "index_bars", {}) or {}).get("nifty") or {}).get("close")
        ctx = getattr(D, "ctx", {}) or {}
        for s, j in self.k.items():
            b = D.bars[s]
            self.S[j] = stock_features(b, nifty, (B.swh[j], B.swl[j]))
            cx = ctx.get(s)
            age = np.asarray(cx["age"], dtype=float) if cx is not None else np.full(n, -1.0)
            self.X[j] = context_features(B.st[j], B.ev[j], age, B.lvl[j], B.cf[j], B.atr[j], self.S[j])


def assemble(fs, cols, j, i, sel, extra):
    """Rows for stocks j at closes i: the declared columns in order. sel: dict of SEL arrays; extra: dict of the
    window / position / change arrays. Returns float32 (rows, len(cols))."""
    j = np.asarray(j, dtype=np.int64)
    i = np.asarray(i, dtype=np.int64)
    out = np.empty((len(j), len(cols)), dtype=np.float32)
    gk = {c: k for k, c in enumerate(GEN)}
    xk = {c: k for k, c in enumerate(CTXF)}
    for q, c in enumerate(cols):
        if c in gk:
            out[:, q] = fs.S[j, i, gk[c]]
        elif c in xk:
            out[:, q] = fs.X[j, i, xk[c]]
        elif c in sel:
            out[:, q] = sel[c]
        elif c in extra:
            out[:, q] = extra[c]
        else:
            raise XLError("no values for column %s" % c)
    return out
