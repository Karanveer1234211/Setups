r"""xl_why.py - execlab v1.1: why does an engine pick what it picks? (exploratory, discovery period only)

For every signal day the panel's stocks are ranked feature by feature (percentile among that day's panel stocks:
0 = lowest, 1 = highest). An engine's top-3 picks are compared with a fixed random sample of the day's other panel
stocks (the controls, the same for every engine):
  signature   per feature, the picks' mean percentile and its 95% block-bootstrap interval over days (0.5 = no
              preference), Benjamini-Hochberg over the features
  surrogate   two gradient-boosted classifiers, picks vs controls, out of fold over time blocks: ADDITIVE (no
              interactions: every feature on its own) and FULL (interactions allowed). Their AUC is how much of the
              selection the panel explains; the gap is how much of it needs combinations of features.
  drivers     per pick, the additive surrogate's exact term for each feature (its log-odds at the pick's percentile
              minus at 0.5): the pick's top drivers = what made this stock look like a pick
  pairs       Friedman's H^2 between the strongest features under the full surrogate (the share of their joint effect
              that is not the sum of the two)
  outcomes    pick_meta's recorded net (the plain plan) by each pick's top driver (exploratory)
This is a model OF the engine: the engine's own fold models are not read. It describes what the picks have in
common; it is not the engine's reasoning, and the AUC says how faithful the description is.
Reads the panel READ ONLY, rows of the discovery period only, a chunk of features at a time.
"""
import numpy as np
import pandas as pd

from xl_common import XLError, bh, block_mean, purged_folds

IST = "Asia/Kolkata"


def to_day(x):
    s = pd.to_datetime(pd.Series(x))
    if getattr(s.dt, "tz", None) is not None:
        s = s.dt.tz_convert(IST).dt.tz_localize(None)
    return s.to_numpy(dtype="datetime64[ns]").astype("datetime64[D]")


# ============================================================================ the panel, a chunk at a time
class PanelReader:
    def __init__(self, path, tcol, lo, hi, batch=400_000, to_day_fn=None, log=print):
        import pyarrow.parquet as pq
        self.path, self.tcol, self.batch = path, tcol, int(batch)
        self.pf = pq.ParquetFile(path)
        td = to_day_fn or to_day
        lo, hi = np.datetime64(lo, "D"), np.datetime64(hi, "D")
        days, syms, keep = [], [], []
        for rb in self.pf.iter_batches(batch_size=self.batch, columns=[tcol, "symbol"]):
            b = rb.to_pandas()
            d = td(b[tcol])
            m = (d >= lo) & (d <= hi)
            keep.append(m)
            days.append(d[m])
            syms.append(b["symbol"].astype(str).to_numpy()[m])
        self.keep = np.concatenate(keep) if keep else np.zeros(0, bool)
        self.day = np.concatenate(days) if days else np.zeros(0, "datetime64[D]")
        self.sym = np.concatenate(syms) if syms else np.zeros(0, object)
        self.n = int(self.keep.sum())
        log("   panel %s: %d rows in %s .. %s (%d days)" % (path, self.n, lo, hi, len(np.unique(self.day))))

    def chunk(self, cols):
        """Values of cols for the window's rows, in the reader's row order (float32)."""
        out = np.full((self.n, len(cols)), np.nan, dtype=np.float32)
        pos, w = 0, 0
        for rb in self.pf.iter_batches(batch_size=self.batch, columns=list(cols)):
            k = rb.num_rows
            m = self.keep[pos:pos + k]
            pos += k
            if not m.any():
                continue
            b = rb.to_pandas()
            for q, c in enumerate(cols):
                v = pd.to_numeric(b[c], errors="coerce") if b[c].dtype != bool else b[c].astype(float)
                out[w:w + int(m.sum()), q] = np.asarray(v, dtype=np.float32)[m]
            w += int(m.sum())
        return out


def day_percentiles(day_codes, V):
    """Percentile (0..1, average ties) of each value among the same day's rows, per column; NaN stays NaN."""
    df = pd.DataFrame(V)
    df["_d"] = day_codes
    return df.groupby("_d").rank(pct=True).to_numpy(dtype=np.float32)


# ============================================================================ the analysis
def _hgb(cfg, additive, seed):
    from sklearn.ensemble import HistGradientBoostingClassifier
    kw = dict(cfg["hgb"])
    if additive:
        kw["interaction_cst"] = "no_interactions"
    return HistGradientBoostingClassifier(random_state=int(seed), early_stopping=False, **kw)


def _auc(y, s):
    y = np.asarray(y, bool)
    ok = np.isfinite(s)
    y, s = y[ok], s[ok]
    if y.all() or not y.any():
        return np.nan
    r = pd.Series(s).rank().to_numpy()
    n1 = y.sum()
    n0 = len(y) - n1
    return float((r[y].sum() - n1 * (n1 + 1) / 2.0) / (n1 * n0))


def contributions(model, X, ref=0.5):
    """Exact per-feature terms of an ADDITIVE classifier: f(ref with feature k = x_k) - f(ref)."""
    n, p = X.shape
    R = np.full((n, p), ref, dtype=np.float32)
    base = float(model.decision_function(R[:1])[0])
    out = np.zeros((n, p))
    for k in range(p):
        R[:, k] = X[:, k]
        out[:, k] = model.decision_function(R) - base
        R[:, k] = ref
    return out, base


def h_statistic(model, X, feats_idx, rng, n=300):
    """Friedman's H^2 for every pair of the given features (brute-force partial dependence on n sampled rows)."""
    m = min(n, len(X))
    Xs = X[rng.choice(len(X), m, replace=False)].astype(np.float32)

    def pd_of(cols):
        out = np.zeros(m)
        for i in range(m):
            Z = Xs.copy()
            for c in cols:
                Z[:, c] = Xs[i, c]
            out[i] = model.decision_function(Z).mean()
        return out - out.mean()

    single = {k: pd_of([k]) for k in feats_idx}
    rows = []
    for a in range(len(feats_idx)):
        for b in range(a + 1, len(feats_idx)):
            ka, kb = feats_idx[a], feats_idx[b]
            joint = pd_of([ka, kb])
            den = float(np.sum(joint ** 2))
            num = float(np.sum((joint - single[ka] - single[kb]) ** 2))
            rows.append((ka, kb, num / den if den > 0 else np.nan))
    rows.sort(key=lambda x: -np.nan_to_num(x[2]))
    return rows


def analyse(reader, feats, picks, cfg, stats, log=print):
    """reader: PanelReader; feats: usable panel columns (label firewall applied by the caller); picks: DataFrame with
    engine, day (datetime64[D]), symbol, rank, and optionally net. Returns {engine: result}."""
    if not feats:
        raise XLError("the panel has no usable feature columns")
    rng = np.random.default_rng(int(stats.get("seed", 7)))
    sa = {"B": int(stats["B"]), "block": int(stats["block"]), "seed": int(stats["seed"])}
    pk = picks[picks["rank"] <= 3].copy()
    pk["day"] = pk["day"].to_numpy().astype("datetime64[D]")
    # controls: per day a fixed random sample of the day's panel stocks that no engine picked (ranks 1-3)
    picked = set(zip(pk["day"].tolist(), pk["symbol"].tolist()))
    udays, inv = np.unique(reader.day, return_inverse=True)
    rows_by_day = pd.Series(np.arange(reader.n)).groupby(inv).apply(lambda s: s.to_numpy())
    k_ctl = int(cfg["controls_per_day"])
    ctl = []
    pday = set(pk["day"].tolist())
    for q, d in enumerate(udays):
        if d not in pday:
            continue
        cand = [r for r in rows_by_day.iloc[q] if (d, reader.sym[r]) not in picked]
        if cand:
            ctl += rng.choice(cand, min(k_ctl, len(cand)), replace=False).tolist()
    ctl = np.array(sorted(ctl), dtype=np.int64)
    key = pd.Series(np.arange(reader.n), index=pd.MultiIndex.from_arrays([reader.day, reader.sym]))
    key = key[~key.index.duplicated(keep="last")]
    mi = pd.MultiIndex.from_arrays([pk["day"].to_numpy(), pk["symbol"].astype(str).to_numpy()])
    prow = key.reindex(mi).to_numpy()
    have = np.isfinite(prow)
    log("   why: %d picks (ranks 1-3), %d in the panel; %d controls on %d days" % (
        len(pk), int(have.sum()), len(ctl), len(pday)))
    want = np.unique(np.r_[prow[have].astype(np.int64), ctl])
    pos = {int(r): q for q, r in enumerate(want)}
    P = np.full((len(want), len(feats)), np.nan, dtype=np.float32)
    ch = int(cfg["chunk_features"])
    for c0 in range(0, len(feats), ch):
        cols = feats[c0:c0 + ch]
        V = reader.chunk(cols)
        P[:, c0:c0 + len(cols)] = day_percentiles(inv, V)[want]
        del V
        log("   why: percentiles %d / %d features" % (min(c0 + ch, len(feats)), len(feats)))
    out = {}
    for eng in sorted(pk["engine"].unique()):
        m = (pk["engine"] == eng).to_numpy() & have
        pr = prow[m].astype(np.int64)
        e_pk = pk[m].reset_index(drop=True)
        Xp = P[[pos[int(r)] for r in pr]]
        Xc = P[[pos[int(r)] for r in ctl]]
        dp = e_pk["day"].to_numpy()
        dc = reader.day[ctl]
        res = {"picks": int(len(Xp)), "controls": int(len(Xc)), "features": len(feats)}
        if len(Xp) < 50:
            res["note"] = "fewer than 50 picks in the panel"
            out[eng] = res
            continue
        # signature
        sig = []
        for k, f in enumerate(feats):
            v = Xp[:, k].astype(float)
            ok = np.isfinite(v)
            st = block_mean(dp[ok].astype("datetime64[D]").astype(np.int64), v[ok] - 0.5, **sa) if ok.sum() >= 20 \
                else {"mean": np.nan, "lo": np.nan, "hi": np.nan, "p": np.nan}
            sig.append({"feature": f, "mean_pct": 0.5 + st["mean"], "lo": 0.5 + st["lo"], "hi": 0.5 + st["hi"],
                        "p": st["p"], "top_decile": float(np.mean(v[ok] >= 0.9)) if ok.any() else np.nan,
                        "bottom_decile": float(np.mean(v[ok] <= 0.1)) if ok.any() else np.nan,
                        "missing": float(np.mean(~ok))})
        rej, qv = bh([s["p"] if np.isfinite(s["p"]) else 1.0 for s in sig], float(stats.get("fdr_q", 0.10)))
        for s, rj, q in zip(sig, rej, qv):
            s["q"], s["flag"] = float(q), bool(rj)
        # surrogates out of fold (time blocks over days)
        X = np.r_[Xp, Xc]
        y = np.r_[np.ones(len(Xp), bool), np.zeros(len(Xc), bool)]
        dd = np.r_[dp, dc].astype("datetime64[D]").astype(np.int64)
        order = np.argsort(dd, kind="stable")
        X, y, dd = X[order], y[order], dd[order]
        K = int(cfg["folds"])
        oof = {"additive": np.full(len(y), np.nan), "full": np.full(len(y), np.nan)}
        try:
            folds = purged_folds(dd, K, 5)
        except Exception:            # noqa: BLE001 - too few days for folds
            folds = []
        for te, tr in folds:
            if y[tr].all() or not y[tr].any():
                continue
            for nm, add in (("additive", True), ("full", False)):
                mdl = _hgb(cfg, add, 7).fit(X[tr], y[tr])
                oof[nm][te] = mdl.decision_function(X[te])
        res["auc"] = {nm: _auc(y, s) for nm, s in oof.items()}
        # drivers (additive, fitted on everything)
        add = _hgb(cfg, True, 7).fit(X, y)
        Cc, base = contributions(add, Xp)
        imp = np.mean(np.abs(Cc), axis=0)
        for k, s in enumerate(sig):
            s["importance"] = float(imp[k])
        res["signature"] = sorted(sig, key=lambda s: -s["importance"])
        top = np.argsort(-Cc, axis=1)[:, :5]
        drv = []
        for q in range(len(Xp)):
            drv.append({"day": str(dp[q]), "symbol": e_pk["symbol"][q], "rank": int(e_pk["rank"][q]),
                        "net": float(e_pk["net"][q]) if "net" in e_pk and np.isfinite(e_pk["net"][q]) else np.nan,
                        "drivers": [(feats[k], float(Xp[q, k]), float(Cc[q, k])) for k in top[q]]})
        res["drivers"] = drv
        # pairs (full model, strongest additive features)
        full = _hgb(cfg, False, 7).fit(X, y)
        kk = list(np.argsort(-imp)[:min(int(cfg["top_pairs_features"]), len(feats))])
        res["pairs"] = [{"a": feats[a], "b": feats[b], "h2": h} for a, b, h in
                        h_statistic(full, X, kk, np.random.default_rng(11), int(cfg["pairs_sample"]))] if len(kk) >= 2 \
            else []
        # recorded outcome by top driver (exploratory)
        oc = []
        if "net" in e_pk:
            tops = np.array(["%s %s" % (d["drivers"][0][0], "high" if d["drivers"][0][1] >= 0.5 else "low")
                             for d in drv], dtype=object)
            net = e_pk["net"].to_numpy(dtype=float)
            dpi = dp.astype("datetime64[D]").astype(np.int64)
            for g in sorted(set(tops)):
                mm = (tops == g) & np.isfinite(net)
                if mm.sum() >= int(cfg["min_driver_picks"]):
                    oc.append({"driver": g, "n": int(mm.sum()), "net": block_mean(dpi[mm], net[mm], **sa)})
            allm = np.isfinite(net)
            res["net_all"] = block_mean(dpi[allm], net[allm], **sa) if allm.sum() >= 20 else None
        res["outcomes"] = sorted(oc, key=lambda r: -r["n"])
        out[eng] = res
        log("   why %s: AUC additive %.3f, full %.3f; top features %s" % (
            eng, res["auc"]["additive"], res["auc"]["full"], ", ".join(s["feature"] for s in res["signature"][:5])))
    return out


# ============================================================================ outputs
def write(od, res, run, log=print):
    from pathlib import Path

    import xl_report as RP
    from xl_common import fmt_ci, fmt_pct
    od = Path(od)
    od.mkdir(parents=True, exist_ok=True)
    L = ["# Why the engines pick what they pick (exploratory, %s .. %s)" % (run["t_from"], run["t_to"]), "",
         "%s | panel %s | %s | %d usable panel features (label firewall applied)" % (
             run["version"], run["panel"], run["when"], run["features"]), "",
         "Each feature is the stock's percentile among that day's panel stocks (0 lowest, 1 highest). Picks = an "
         "engine's ranks 1-3; controls = %d random other panel stocks a day. A surrogate model of the engine, not "
         "the engine's own models: the AUC says how much of the selection the panel explains (0.5 = nothing, 1 = "
         "all); additive = every feature on its own; full = with interactions. Intervals: 95%% block bootstrap over "
         "signal days." % run["controls_per_day"], ""]
    sig_rows, drv_rows, pair_rows = [], [], []
    for eng, r in res.items():
        L += ["## Engine %s" % eng, ""]
        if r.get("note"):
            L += [r["note"], ""]
            continue
        a = r["auc"]
        L += ["%d picks, %d controls. Out-of-fold AUC: additive %.3f, full %.3f (interaction gap %+.3f)." % (
            r["picks"], r["controls"], a["additive"], a["full"], a["full"] - a["additive"]), ""]
        L += ["Signature (top 25 by the additive surrogate's mean |term|; * = BH q <= 0.10 that the picks' mean "
              "percentile differs from 0.5):", ""]
        L.append("| feature | picks' mean percentile | top decile | bottom decile | importance | flag |")
        L.append("| --- | --- | --- | --- | --- | --- |")
        for s in r["signature"][:25]:
            L.append("| %s | %.3f [%.3f, %.3f] | %s | %s | %.3f | %s |" % (
                s["feature"], s["mean_pct"], s["lo"], s["hi"], fmt_pct(s["top_decile"], 0).lstrip("+"),
                fmt_pct(s["bottom_decile"], 0).lstrip("+"), s["importance"], "*" if s.get("flag") else ""))
        L.append("")
        if r.get("pairs"):
            L += ["Interactions (Friedman's H^2 under the full surrogate; 0 = additive, 1 = purely joint):", ""]
            L.append("| feature a | feature b | H^2 |")
            L.append("| --- | --- | --- |")
            for p in r["pairs"][:10]:
                L.append("| %s | %s | %.3f |" % (p["a"], p["b"], p["h2"]))
            L.append("")
        if r.get("outcomes"):
            L += ["Recorded net (pick_meta, the plain plan) by the pick's top driver (exploratory; all picks %s):" %
                  fmt_ci(r.get("net_all")), ""]
            L.append("| top driver | picks | net |")
            L.append("| --- | --- | --- |")
            for o in r["outcomes"]:
                L.append("| %s | %d | %s |" % (o["driver"], o["n"], fmt_ci(o["net"])))
            L.append("")
        for s in r["signature"]:
            sig_rows.append(dict(engine=eng, **{k: v for k, v in s.items()}))
        for d in r["drivers"]:
            row = {"engine": eng, "day": d["day"], "symbol": d["symbol"], "rank": d["rank"], "net": d["net"]}
            for k, (f, pct, c) in enumerate(d["drivers"], 1):
                row["driver%d" % k], row["pct%d" % k], row["term%d" % k] = f, pct, c
            drv_rows.append(row)
        for p in r.get("pairs", []):
            pair_rows.append(dict(engine=eng, **p))
    L += ["## Files", "", "why_features.csv (every feature's signature), why_picks.csv (every pick's top 5 drivers: "
          "feature, the pick's percentile, its log-odds term), why_pairs.csv, RUN.json.", ""]
    (od / "WHY.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    RP.write_csv(od / "why_features.csv", ("engine", "feature", "mean_pct", "lo", "hi", "p", "q", "flag",
                                           "top_decile", "bottom_decile", "missing", "importance"), sig_rows)
    hd = ["engine", "day", "symbol", "rank", "net"] + [x % k for k in range(1, 6) for x in ("driver%d", "pct%d",
                                                                                         "term%d")]
    RP.write_csv(od / "why_picks.csv", hd, drv_rows)
    RP.write_csv(od / "why_pairs.csv", ("engine", "a", "b", "h2"), pair_rows)
