r"""test_execlab.py - execlab v1.1's checks.

  python execlab.py --selftest          everything (planted, absent and null worlds; the CLI's seal / freeze /
                                        evaluate; the fake production cache when pathlab / tradelab / v2engine exist)
  python execlab.py --selftest quick    the same with smaller worlds
  python tests/test_execlab.py unit     the fast unit checks only (the mutation harness runs these)
"""
import copy
import io
import json
import os
import shutil
import sys
import tempfile
import time
from contextlib import redirect_stdout
from pathlib import Path
from types import SimpleNamespace

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
for p_ in (str(ROOT), str(HERE)):
    if p_ not in sys.path:
        sys.path.insert(0, p_)


def _v2():
    for c in (os.environ.get("V2_DIR", ""), str(ROOT.parent / "v2engine")):
        if c and (Path(c) / "v2_core.py").exists():
            if c not in sys.path:
                sys.path.insert(0, c)
            return Path(c)
    return None


_v2()
import v2_core as C  # noqa: E402
import v2_money as M  # noqa: E402
import xl_common as XC  # noqa: E402
import xl_eval as EV  # noqa: E402
import xl_feat as F  # noqa: E402
import xl_learn as XLL  # noqa: E402
import xl_ledger as LG  # noqa: E402
import xl_sim as S  # noqa: E402
import xl_world as XW  # noqa: E402

RESULTS = []
NAN = float("nan")
LOG = []


def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok), detail))
    print("  %s  %s%s" % ("ok  " if ok else "FAIL", name, "" if ok else "   <- %s" % (detail,)), flush=True)


def quiet(*a, **k):
    LOG.append(" ".join(str(x) for x in a))


def test_decl(fast=True):
    d = XC.load_decl()
    if fast:
        d["learning"].update(folds=3, iterations_hold=2, iterations_watch=2, hold_sample_entries=2,
                             max_train_rows=40000, min_records=50)
        d["learning"]["hgb"].update(max_iter=60, learning_rate=0.1, min_samples_leaf=50)
        d["stats"]["B"] = 600
    return d


# ============================================================================ hand-made bars
def hand_data(scen, n=50):
    """One symbol per scenario: 20 quiet sessions (o 100, h 101, l 99, c 100: ATR 2), then the scenario's bars."""
    days = XW.business_days("2021-01-04", n)
    cal = C.SessionCalendar(days.tolist())
    bars = C.BarStore(cal)
    for s, sc in scen.items():
        o, h, l, c = np.full(n, 100.0), np.full(n, 101.0), np.full(n, 99.0), np.full(n, 100.0)
        rec = {"open": o, "high": h, "low": l, "close": c, "volume": np.full(n, 1e6),
               "upper_locked": np.zeros(n, bool), "lower_locked": np.zeros(n, bool),
               "ll_open": np.zeros(n, bool), "ll_close": np.zeros(n, bool)}
        for i, bar in sc.get("bars", {}).items():
            if bar is None:
                for f in ("open", "high", "low", "close"):
                    rec[f][i] = np.nan
            else:
                rec["open"][i], rec["high"][i], rec["low"][i], rec["close"][i] = bar
        for f in ("upper_locked", "lower_locked", "ll_open"):
            for i in sc.get(f, ()):
                rec[f][i] = True
        bars.put_arrays(s, rec)
        M.prepare_bars(bars[s])
    D = SimpleNamespace(cal=cal, bars=bars, cm=M.CostModel(cal.days))
    return D


def x01_fills():
    D = hand_data({"A": {"bars": {21: (100.5, 101.5, 99.5, 101)}}, "B": {"bars": {21: (102, 103, 101.8, 102.5)}},
                   "Cg": {"bars": {21: (98.5, 99, 97.5, 98)}}, "Dt": {"bars": {21: (100, 100.5, 99, 100)}},
                   "E": {"bars": {21: (105, 105, 105, 105)}, "upper_locked": (21,)}, "Fm": {"bars": {21: None}},
                   "G": {"bars": {21: (100.2, 101.0, 100, 100.8)}}})
    B = S.Bars(D, ["A", "B", "Cg", "Dt", "E", "Fm", "G"])
    em = XC.load_decl()["entry_menu"]
    j = np.arange(7)
    a = np.full(7, 20)
    atr = B.atr[0, 20]
    got = {k: S.entry_fill(B, j, a, k, em, 0.05) for k in S.ENTRY}
    exp = {"OPEN": [100.5, 102, 98.5, 100, NAN, NAN, 100.2],
           "BSTOP": [101 + 0.05 * atr, 102 + 0.05 * atr, NAN, NAN, NAN, NAN, 101.0],
           "BHIGH": [101 + 0.1 * atr + 0.05 * atr, 102 + 0.05 * atr, NAN, NAN, NAN, NAN, NAN],
           "LDIP": [NAN, NAN, 98.5, NAN, NAN, NAN, NAN],
           "LDEEP": [NAN, NAN, 100 - atr, NAN, NAN, NAN, NAN]}
    ok = abs(atr - 2.0) < 1e-12
    bad = []
    for k in exp:
        f, px = got[k]
        e = np.array(exp[k])
        good = np.array_equal(f, np.isfinite(e)) and np.allclose(px[f], e[np.isfinite(e)], atol=1e-9)
        if not good:
            bad.append((k, f.tolist(), np.round(px, 4).tolist()))
    check("x01a entries by hand: open, buy stops (open / trigger + 0.05 ATR, capped at the high), limits (strictly "
          "through, min(open, limit)), upper lock and missing bar = no fill", ok and not bad, (atr, bad))
    # v1.1 orders: ODIP (open - 0.25 ATR), LVL_RT (level + 0.25 ATR, only below the close), LVL_RC (level + 0.25 ATR,
    # only above the close), SWHI (swing high + 0.1 ATR, only above the close)
    B.lvl[:, 20] = [99.0, 101.0, 99.0, 101.5, np.nan, 99.0, 99.0]
    B.swh[:, 20] = [100.5, 101.5, 102.0, np.nan, 102.0, 102.0, 101.0]
    exp2 = {"ODIP": [100.5 - 0.5, NAN, 98.5 - 0.5, 100 - 0.5, NAN, NAN, NAN],
            "LVL_RT": [NAN, NAN, 98.5, NAN, NAN, NAN, NAN],
            "LVL_RC": [NAN, 102 + 0.05 * atr, NAN, NAN, NAN, NAN, NAN],
            "SWHI": [100.5 + 0.1 * atr + 0.05 * atr, 102 + 0.05 * atr, NAN, NAN, NAN, NAN, NAN]}
    av_exp = {"LVL_RT": [True, False, True, False, False, True, True], "LVL_RC": [False, True, False, True, False,
                                                                                  False, False],
              "SWHI": [True, True, True, False, True, True, True]}
    bad2 = []
    for k, e in exp2.items():
        f, px = S.entry_fill(B, j, a, k, em, 0.05)
        e = np.array(e)
        if not (np.array_equal(f, np.isfinite(e)) and np.allclose(px[f], e[np.isfinite(e)], atol=1e-9)):
            bad2.append((k, f.tolist(), np.round(px, 4).tolist()))
        if k in av_exp:
            av = S.entry_avail(B, j, a, k, em)
            if av.tolist() != av_exp[k]:
                bad2.append((k, "avail", av.tolist()))
    check("x01c v1.1 orders by hand: ODIP (open - 0.25 ATR, strictly through), LVL_RT (a retest limit: only while "
          "below the close), LVL_RC and SWHI (buy stops: only while above the close; gap -> open + slippage)",
          not bad2, bad2)
    B.entry_ok = B.entry_ok.copy()
    B.entry_ok[21] = False
    f, _ = S.entry_fill(B, j, a, "OPEN", em)
    check("x01b a session that takes no entries fills nothing", not f.any())


def x02_holds():
    lw = 20
    D = hand_data({"ex": {"bars": {21: (100.7, 101, 100, 100.5)}},
                   "exlock": {"ll_open": (21, 22), "bars": {23: (99.3, 100, 99, 99.5)}},
                   "stuck": {"ll_open": tuple(range(21, 49))},
                   "gap": {"bars": {21: (97.5, 98.5, 97, 98)}}, "ins": {"bars": {21: (99, 99.5, 97.9, 98.5)}},
                   "frozen": {"bars": {21: (97, 97, 97, 97)}, "lower_locked": (21,)},
                   "lkopen": {"bars": {21: (97.5, 98.5, 97, 98)}, "ll_open": (21,)},
                   "tpgap": {"bars": {21: (104.5, 105, 104, 104.2)}}, "tpin": {"bars": {21: (101, 104.5, 100.5, 104)}},
                   "tptouch": {"bars": {21: (101, 104.0, 100, 103)}}})
    names = ["ex", "exlock", "stuck", "gap", "ins", "frozen", "lkopen", "tpgap", "tpin", "tptouch"]
    B = S.Bars(D, names, lw)
    hm = XC.load_decl()["hold_menu"]
    H = S.HOLDA.index
    i = np.full(len(names), 20)
    j = np.arange(len(names))
    act = np.array([H("EXIT"), H("EXIT"), H("EXIT"), H("STOP1"), H("STOP1"), H("STOP1"), H("STOP1"), H("TP2"),
                    H("TP2"), H("TP2")])
    done, xs, px, rc, tc = S.resolve_hold(B, j, i, act, hm, 0.05)
    atr = B.atr[0, 20]
    exp = [(True, 21, 100.7, "EXIT", 1), (True, 23, 99.3, "EXIT", 1), (True, 41, 100.0, "STUCK", 3),
           (True, 21, max(97.5 - 0.05 * atr, 97), "STOP1", 1), (True, 21, max(98 - 0.05 * atr, 97.9), "STOP1", 2),
           (False, -1, NAN, "", 0), (False, -1, NAN, "", 0), (True, 21, 104.5, "TP2", 1), (True, 21, 104.0, "TP2", 2),
           (False, -1, NAN, "", 0)]
    bad = []
    for q, (dn, x, p, r, t) in enumerate(exp):
        g = (bool(done[q]), int(xs[q]), float(px[q]), S.REASONS[rc[q]], int(tc[q]))
        if g[0] != dn or (dn and (g[1] != x or abs(g[2] - p) > 1e-9 or g[3] != r or g[4] != t)):
            bad.append((names[q], g, (dn, x, p, r, t)))
    s2 = S.resolve_hold(B, j[4:5], i[4:5], np.array([H("STOP2")]), hm, 0.05)[0]
    k_ = S.resolve_hold(B, j[:1], i[:1], np.array([H("KEEP")]), hm, 0.05)[0]
    check("x02 exits by hand: next open, lock wait, STUCK after 20, stop gap / inside the day (- 0.05 ATR, floored at "
          "the low), no stop fill on a frozen bar or at a locked open, target gap / through / touch, KEEP",
          not bad and not s2.any() and not k_.any(), bad)
    # STOP_SW at swing low - 0.25 ATR (98.5 - 0.5 = 98.0) and STOP_LV at level - 0.25 ATR; not offered at or above
    # the close (100)
    B.swl[:, 20] = 98.5
    B.lvl[:, 20] = [101.0, np.nan, 99.0, 98.6, 99.0, 98.6, 98.6, 99.0, 99.0, 99.0]
    q = [names.index(x) for x in ("gap", "ins", "frozen", "ex")]
    dS = S.resolve_hold(B, j[q], i[q], np.full(4, H("STOP_SW")), hm, 0.05)
    expS = [(True, 21, max(97.5 - 0.05 * atr, 97), "STOP_SW", 1), (True, 21, max(98.0 - 0.05 * atr, 97.9), "STOP_SW", 2),
            (False, -1, NAN, "", 0), (False, -1, NAN, "", 0)]
    badS = []
    for z, (dn, x, pz, r, t) in enumerate(expS):
        g = (bool(dS[0][z]), int(dS[1][z]), float(dS[2][z]), S.REASONS[dS[3][z]], int(dS[4][z]))
        if g[0] != dn or (dn and (g[1] != x or abs(g[2] - pz) > 1e-9 or g[3] != r or g[4] != t)):
            badS.append((z, g))
    av = S.hold_avail(B, j, i, hm)
    lv_ok = av[:, H("STOP_LV")].tolist() == [False, False, True, True, True, True, True, True, True, True]
    dL = S.resolve_hold(B, j[0:1], i[0:1], np.array([H("STOP_LV")]), hm, 0.05)[0]       # level above the close
    check("x02b structural stops by hand: STOP_SW gap / inside the day at swing low - 0.25 ATR (- 0.05 ATR), none on "
          "a frozen bar; STOP_LV offered only while level - 0.25 ATR is below the close, never filled above it",
          not badS and lv_ok and not dL.any(), (badS, av[:, H("STOP_LV")].tolist()))


def x03_open6_and_costs(D, fast):
    W = XLL.World(D, test_decl(), "D", [1, 2, 3], "2020-01-01", "2030-01-01", log=quiet)
    op6 = S.comparators(W.B, W.recs)
    r, a, d = W.watch_rows()
    first = d == 0
    Fm, Pm, _ = XLL.entry_table(W, r[first], a[first])
    rr = r[first][Fm[:, 0]]
    pos = {"r": rr, "j": W.recs["j"][rr], "e": W.recs["t"][rr] + 1, "P": Pm[Fm[:, 0], 0], "kind": np.zeros(len(rr), int)}
    rule = lambda ids, h, i, rm: np.where(h >= 4, S.HOLDA.index("EXIT"), S.HOLDA.index("KEEP"))  # noqa: E731
    out = S.hold_forward(W.B, pos, rule, W.H, test_decl()["hold_menu"], 0.05)
    nets = S.trade_nets(W.B, pos["j"], pos["e"], pos["P"], out["x"], out["px"])
    ok6 = np.isfinite(op6["open6"][rr])
    same_x = np.array_equal(out["x"][ok6], op6["open6_x"][rr][ok6])
    dpx = np.nanmax(np.abs(out["px"][ok6] - op6["open6_px"][rr][ok6]))
    dnet = np.nanmax(np.abs(nets[ok6] - op6["open6"][rr][ok6]))
    stuck = int(np.sum(out["reason"] == S.REASONS.index("STUCK")))
    waited = int(np.sum(out["x"][ok6] > W.recs["t"][rr][ok6] + 6))
    check("x03a the hold engine with 'sell at the open after age 4' = v2's OPEN6 on every record (exit session, price, "
          "stage E net to 1e-12; %d lock waits)" % waited, same_x and dpx < 1e-9 and dnet < 1e-12 and ok6.sum() > 100
          and waited > 0, (same_x, dpx, dnet, ok6.sum(), waited, stuck))
    ap = S.approx_net(W.B, pos["j"], pos["e"], pos["P"], out["px"])
    dd = np.abs(ap - nets)[ok6]
    check("x03b the learning stand-in for costs is within 2 bp of stage E's net (median %.2f bp, max %.2f bp)" % (
        1e4 * np.median(dd), 1e4 * dd.max()), dd.max() < 2e-4, dd.max())


def x05_leak(fast):
    n = 330 if fast else 450
    cut = 250
    A = XW.make_world(n_days=n, n_sym=30, seed=11)
    Bw = XW.make_world(n_days=n, n_sym=30, seed=11, perturb_after=cut)
    d = test_decl()
    out = []
    for Dx in (A, Bw):
        W = XLL.World(Dx, d, "D", [1, 2, 3], "2020-01-01", "2030-01-01", log=quiet)
        cols = F.columns("watch", "state_event")
        sels = [s for s in W.all_recs if s.t_idx <= cut]
        tt = np.array([s.t_idx for s in sels])
        jj = np.array([W.B.k[s.symbol] for s in sels])
        aa = np.minimum(tt + np.arange(len(tt)) % 10, cut)
        W.recs = {"j": jj, "t": tt, "rank": np.array([s.rank for s in sels], float),
                  "score": np.array([s.raw_score for s in sels], float)}
        Xw = W.watch_X(cols, np.arange(len(tt)), aa)
        e = np.minimum(tt + 1, cut)
        i = np.minimum(e + np.arange(len(tt)) % 7, cut)
        P = W.B.o[jj, e]
        rm = np.array([np.nanmax(W.B.cf[j_, e_:i_ + 1]) for j_, e_, i_ in zip(jj, e, i)])
        Xh = W.hold_X(F.columns("hold", "state_event"), jj, i, e, tt, P, np.zeros(len(tt)), W.recs["rank"],
                      W.recs["score"], rm)
        out.append((W.fs.S[:, :cut + 1], W.fs.X[:, :cut + 1], np.c_[W.B.lvl[:, :cut + 1], W.B.swh[:, :cut + 1],
                                                                   W.B.swl[:, :cut + 1]], Xw, Xh, W.fs.S[:, cut + 2:]))
    eq = lambda u, v: np.array_equal(np.isnan(u), np.isnan(v)) and np.allclose(np.nan_to_num(u), np.nan_to_num(v))  # noqa: E731
    same = all(eq(out[0][k], out[1][k]) for k in range(5))
    differs = not eq(out[0][5], out[1][5])
    check("x05 no look-ahead: every bar, state, event and market value after a cut redrawn -> identical general and "
          "state / event features, event levels, swing levels, watch and hold features at every close up to the cut "
          "(and different after it)", same and differs,
          [eq(out[0][k], out[1][k]) for k in range(5)])


def x06_scale():
    A = XW.make_world(n_days=300, n_sym=12, seed=12)
    Bw = XW.make_world(n_days=300, n_sym=12, seed=12, scale={"S003": 10.0})
    fa, fb = F.stock_features(A.bars["S003"]), F.stock_features(Bw.bars["S003"])
    ok = np.array_equal(np.isnan(fa), np.isnan(fb)) and np.allclose(np.nan_to_num(fa), np.nan_to_num(fb), rtol=2e-5,
                                                                     atol=2e-6)
    check("x06 no raw price level: a stock's prices x 10 (volume / 10, same rupee turnover) -> identical features",
          ok, np.nanmax(np.abs(fa - fb)))


def x07_firewall():
    ok = all(XC.XLError is not None and F.firewall(F.columns(k, v)) for k in ("watch", "hold")
             for v in F.VARIANTS)
    caught = 0
    for bad in (["label_ret5"], ["close"], ["ret1", "label_x"]):
        try:
            F.firewall(bad)
        except XC.XLError:
            caught += 1
    gen = set(F.columns("watch", "general"))
    sta = set(F.columns("hold", "state"))
    sev = set(F.columns("hold", "state_event"))
    nest = gen < set(F.columns("watch", "state")) < set(F.columns("watch", "state_event"))
    check("x07 label firewall: declared columns only; label_* and undeclared names refused; general has no tl_state "
          "column, state no event column, state_event both (nested)", ok and caught == 3 and not (gen & set(F.CTXF))
          and not (sta & set(F.EVENT)) and set(F.EVENT) <= sev and nest, caught)


def x07b_guard():
    caught = []
    for bad in (ROOT / "out", ROOT / "tests" / "x"):
        try:
            XC.guard_out(bad)
            caught.append(False)
        except XC.XLError:
            caught.append(True)
    tmp = Path(tempfile.mkdtemp(prefix="xlg_"))
    try:
        XC.guard_out(tmp / "root" / "out", tmp / "root")
        caught.append(False)
    except XC.XLError:
        caught.append(True)
    ok_free = XC.guard_out(tmp / "out") is not None
    shutil.rmtree(tmp, ignore_errors=True)
    check("x07b outputs are refused inside execlab's folder and inside the cache root; elsewhere allowed",
          all(caught) and ok_free, caught)


def x08_backward():
    W = SimpleNamespace(H=3)
    C_ = np.array([[100.0, 110.0, 99.0, 120.0, 120.0]])
    val = np.full((1, 4, len(S.HOLDA)), np.nan)
    ex = S.HOLDA.index("EXIT")
    val[0, :, ex] = [0.01, 0.02, -0.03, 0.05]
    st = {"C": C_, "val": val, "hit": np.isfinite(val)}
    keep = np.zeros((1, 3), np.int64)
    V, Y = XLL.hold_values(W, st, keep)
    v2 = 120 / 99 * 1.05 - 1
    v1 = 99 / 110 * (1 + v2) - 1
    v0 = 110 / 100 * (1 + v1) - 1
    A2 = keep.copy()
    A2[0, 1] = ex
    V2, Y2 = XLL.hold_values(W, st, A2)
    ok = np.allclose(V[0], [v0, v1, v2, 0.05]) and np.isclose(V2[0, 1], 0.02) and np.isclose(V2[0, 0], 1.1 * 1.02 - 1)
    ok &= np.isclose(Y[0, 1, ex], 0.02) and np.isclose(Y[0, 1, 0], v1)
    Wv = SimpleNamespace(W=3, n_rec=1)
    NET = np.full((3, len(S.ENTRY)), np.nan)
    Fm = np.zeros((3, len(S.ENTRY)), bool)
    NET[:, 0], Fm[:, 0] = [0.05, 0.08, -0.02], True
    Fm[1, 3] = False
    A = np.array([1, 2, 0])
    Vw, Yw = XLL.watch_values(Wv, np.arange(3), NET, Fm, A, 0.01)
    ok2 = np.isclose(Vw[0, 0], 0.07) and np.isclose(Yw[0, 2], 0.04) and np.isclose(Yw[0, 1], 0.07) and \
        np.isclose(Yw[1, 2 + 3], 0.0) and np.isclose(Vw[0, 2], 0.0)
    check("x08 backward induction by hand: hold values / targets (keep compounds the next close, exit ends) and watch "
          "values (enter = net - hurdle when filled, else watch on; wait; abandon = 0)", ok and ok2,
          (V.tolist(), Vw.tolist()))


def x09_purge():
    rng = np.random.default_rng(3)
    t = np.sort(rng.integers(0, 800, 3000))
    folds = XC.purged_folds(t, 5, 51)
    cover = np.zeros(len(t), int)
    ok = True
    for te, tr in folds:
        cover[te] += 1
        a, b = t[te].min(), t[te].max()
        ok &= bool(np.all((t[tr] + 51 < a) | (t[tr] > b + 51)))
        ok &= not (set(te) & set(tr))
        bad = (t + 51 >= a) & (t <= b + 51)
        ok &= not np.any(np.isin(np.flatnonzero(bad), tr))
    check("x09 purged folds: each record tested once; no training record's 51-session path overlaps a test block",
          ok and np.all(cover == 1))


def x10_stats():
    rng = np.random.default_rng(5)
    cov = 0
    for k in range(200):
        days = np.repeat(np.arange(60), 3)
        v = rng.normal(0, 1, len(days))
        s = XC.block_mean(days, v, B=400, block=5, seed=k)
        cov += s["lo"] <= 0 <= s["hi"]
    d = rng.normal(0, 0.01, (5, 800))
    d[0] += 0.003
    rw = XC.romano_wolf(d, B=800, block=10, seed=1)
    rej, q = XC.bh([0.001, 0.01, 0.02, 0.5, 0.9], 0.05)
    R = rng.normal(0, 0.01, (12, 600))
    p_null = XC.pbo_cscv(R, 10)["pbo"]
    R2 = R.copy()
    R2[3] += 0.004
    p_dom = XC.pbo_cscv(R2, 10)["pbo"]
    r = rng.normal(0.001, 0.02, 1000)
    cd = XC.cagr_at_dd(r, -0.25)
    check("x10 statistics: block-bootstrap 95%% coverage %d/200; Romano-Wolf (true %.3f, nulls >= %.2f); BH; PBO null "
          "%.2f vs dominant %.2f; CAGR at -25%% DD lands on -25%%" % (cov, rw[0]["p_adj"],
                                                                   min(x["p_adj"] for x in rw[1:]), p_null, p_dom),
          175 <= cov <= 198 and rw[0]["p_adj"] < 0.01 and min(x["p_adj"] for x in rw[1:]) > 0.05 and
          rej.tolist() == [True, True, True, False, False] and 0.1 <= p_null <= 0.9 and p_dom < 0.1 and
          (cd["f"] == 1.0 or abs(cd["max_dd"] + 0.25) < 1e-6))


def x11_allocator():
    D = XW.make_world(effects=("absent",), n_days=260, n_sym=12, seed=21, picks=3)
    d = test_decl()
    W = XLL.World(D, d, "D", [1, 2, 3], "2020-01-01", "2030-01-01", log=quiet)
    rng = np.random.default_rng(4)
    nq = W.n_rec * W.W
    act = np.where(rng.random(nq) < 0.5, 2, 1).astype(np.int8)
    act[rng.random(nq) < 0.05] = 0
    t = np.repeat(W.recs["t"], W.W) + np.tile(np.arange(W.W), W.n_rec)
    R = {"act": act, "prio": rng.random(nq), "fill": rng.random(nq) < 0.6, "kind": np.zeros(nq, np.int64),
         "e": t + 1, "P": np.full(nq, 100.0), "x": t + 1 + rng.integers(1, 15, nq), "px": np.full(nq, 101.0),
         "timing": rng.choice([1, 2, 3], nq).astype(np.int8), "reason": np.ones(nq, np.int8),
         "net": np.full(nq, 0.01), "mfe": np.zeros(nq), "mae": np.zeros(nq)}
    exe = LG.execution(W, R, d)
    res = LG.research(W, R)
    v = LG.check_budgets(W, exe, d)
    st = {k: int((exe["status"] == k).sum()) for k in LG.STATUS}
    ok = sum(v.values()) == 0 and st["NO_ROOM"] > 0 and st["HELD_SYMBOL"] > 0 and st["TRADED"] > 0
    tr = exe["status"] == "TRADED"
    ok &= bool(np.all(R["fill"][exe["row"][tr]])) and bool(np.all(exe["net0"][~tr] == 0))
    ok &= int((res["status"] == "TRADED").sum()) >= st["TRADED"]
    q = exe["row"][tr]
    ok &= bool(np.all(R["act"][q] == 2))
    check("x11 allocator under random orders: <= 2 a day, <= 6 in 5 sessions, <= 8 open, one per stock - 0 violations; "
          "NO_ROOM / HELD_SYMBOL used; only filled ENTER rows trade; unfilled = 0 (%s)" % st, ok, (v, st))
    # three filled candidates on one close with a budget of 2 -> the two best by priority
    d2 = copy.deepcopy(d)
    d2["portfolio"]["max_entries_day"] = 2
    R2 = {k: np.array(v_, copy=True) for k, v_ in R.items()}
    R2["act"][:] = 0
    first_t = W.recs["t"][0]
    same = np.flatnonzero(W.recs["t"] == first_t)[:3]
    if len(same) == 3:
        rows = same * W.W
        for dd in range(1, W.W):
            R2["act"][rows + dd] = 1                   # they keep watching (and never fill again)
            R2["fill"][rows + dd] = False
        R2["act"][rows] = 2
        R2["fill"][rows] = True
        R2["prio"][rows] = [0.1, 0.9, 0.5]
        R2["x"][rows] = first_t + 5
        e2 = LG.execution(W, R2, d2)
        got = [e2["status"][r] for r in same]
        check("x11b budget binds: of three filled orders the two with the highest advantage trade, the third NO_ROOM",
              got == ["NO_ROOM", "TRADED", "TRADED"], got)



def x18_swings():
    h = np.array([10, 11, 12, 15, 13, 12, 11, 12, 14, 13, 12, 11, 10], float)
    l = h - 1.0
    swh, swl = F.swings(h, l)
    e_h = np.r_[np.full(6, np.nan), np.full(5, 15.0), np.full(2, 14.0)]
    e_l = np.r_[np.full(9, np.nan), np.full(4, 10.0)]
    same = lambda u, v: np.array_equal(np.isnan(u), np.isnan(v)) and np.allclose(np.nan_to_num(u), np.nan_to_num(v))  # noqa: E731
    h2 = np.r_[h[:5], np.nan, h[5:]]                     # a missing session is skipped, not a bar
    l2 = np.r_[l[:5], np.nan, l[5:]]
    swh2, swl2 = F.swings(h2, l2)
    ok2 = same(np.delete(swh2, 5), e_h) and same(np.delete(swl2, 5), e_l)
    st = np.array([1, 1, 1, 3, 3, 8, 8, 8, 8])
    ag = F.run_age(st).tolist()
    check("x18 swings by hand (tl_state's rule: higher than the 3 before, not lower than the 3 after, known 3 sessions "
          "later; a missing session skipped) and state age", same(swh, e_h) and same(swl, e_l) and ok2 and
          ag == [0, 1, 2, 0, 1, 0, 1, 2, 3], (swh.tolist(), swl.tolist(), ag))
    ev = np.array([0, 1, 4, 5, 8, 3])
    up, dn = np.array([10.0, 11, 12, 13, 14, 15]), np.array([20.0, 21, 22, 23, 24, 25])
    lv = F.event_level(ev, {"s04_level": up, "s10_level": dn})
    gen = np.zeros((5, len(F.GEN)), np.float32)
    gen[:, F.GEN.index("ema20_atr")] = [3.2, 4.6, 1.0, 1.0, 2.9]
    gen[:, F.GEN.index("ema50_atr")] = [1.0, 1.0, 9.1, 6.2, 5.9]
    gen[:, F.GEN.index("m10_atr")] = [0.0, 0.0, 0.0, 0.0, 6.1]
    X = F.context_features(np.array([1, 3, 6, 9, 12]), np.zeros(5, int), np.full(5, -1.0), np.full(5, np.nan),
                           np.full(5, 100.0), np.full(5, 2.0), gen)
    s05 = X[:, F.STATE.index("s05")].tolist()
    oh = X[:, :8].argmax(axis=1).tolist()
    check("x18b event level by hand (up-side events -> the breakout level, down-side -> the breakdown level, none -> "
          "none), S05 by tl_state's thresholds (3 / 6 / 6 ATR overextended, 4.5 / 9 extreme) and the state one-hot",
          same(lv, np.array([np.nan, 11, 12, 23, 24, 15])) and s05 == [1.0, 2.0, 2.0, 1.0, 1.0] and
          oh == [0, 2, 3, 6, 7], (lv.tolist(), s05, oh))


def why_world(tmp, planted=True, n_days=160, n_sym=250, seed=81):
    """A synthetic panel (timestamp IST, symbol, f0..f9, a label and a raw level column) and picks: engine D picks
    the top 3 of pct(f0) + 1.0 x [pct(f1) > 0.8 and pct(f2) > 0.8] each day (f0 carries a large day effect, so only a
    per-day percentile sees it); ENS picks at random."""
    import pandas as pd
    rng = np.random.default_rng(seed)
    days = XW.business_days("2021-01-04", n_days)
    syms = np.array(["Q%03d" % k for k in range(n_sym)])
    rows, picks = [], []
    for d in days:
        f = rng.normal(0, 1, (n_sym, 10))
        f[:, 0] += rng.normal(0, 3)
        df = pd.DataFrame(f, columns=["f%d" % k for k in range(10)])
        df["symbol"] = syms
        df["timestamp"] = pd.Timestamp(str(d)).tz_localize("Asia/Kolkata")
        df["label_ret5"] = rng.normal(0, 1, n_sym)
        df["close"] = rng.uniform(50, 500, n_sym)
        pr = df[["f0", "f1", "f2"]].rank(pct=True)
        score = pr["f0"] + 1.0 * ((pr["f1"] > 0.8) & (pr["f2"] > 0.8))
        if not planted:
            score = pd.Series(rng.random(n_sym))
        top = np.argsort(-score.to_numpy())[:10]
        for rk, k in enumerate(top, 1):
            picks.append(("D", d, syms[k], rk, rng.normal(0.01, 0.05)))
        for rk, k in enumerate(rng.choice(n_sym, 10, replace=False), 1):
            picks.append(("ENS", d, syms[k], rk, rng.normal(0.0, 0.05)))
        rows.append(df)
    P = pd.concat(rows, ignore_index=True)
    path = Path(tmp) / "panel.parquet"
    P.to_parquet(path, index=False, row_group_size=7000)
    pk = pd.DataFrame(picks, columns=["engine", "day", "symbol", "rank", "net"])
    pk["day"] = pk["day"].to_numpy().astype("datetime64[D]")
    return path, pk


def x19_why():
    import xl_why as XWY
    tmp = Path(tempfile.mkdtemp(prefix="xlwhy_"))
    try:
        decl = test_decl()
        cfg = dict(decl["why"], controls_per_day=30, pairs_sample=120, top_pairs_features=5)
        cfg["hgb"] = dict(cfg["hgb"], max_iter=80, min_samples_leaf=20)
        path, pk = why_world(tmp)
        feats = ["f%d" % k for k in range(10)]
        rd = XWY.PanelReader(path, "timestamp", "2020-01-01", "2022-12-31", batch=5000, log=quiet)
        res = XWY.analyse(rd, feats, pk, cfg, dict(decl["stats"]), quiet)
        D_, E_ = res["D"], res["ENS"]
        sig = {s_["feature"]: s_ for s_ in D_["signature"]}
        top3 = {s_["feature"] for s_ in D_["signature"][:3]}
        pair = (D_["pairs"][0]["a"], D_["pairs"][0]["b"]) if D_["pairs"] else ()
        drv = [d_["drivers"][0][0] for d_ in D_["drivers"]]
        share = float(np.mean([x in ("f0", "f1", "f2") for x in drv]))
        check("x19a why, planted (D picks the top of f0 within the day plus f1 AND f2 both high): f0 / f1 / f2 are the "
              "top 3 features (%s), picks' mean percentile f0 %.2f f1 %.2f f2 %.2f, AUC additive %.3f / full %.3f, "
              "the strongest pair %s (H^2 %.2f), %.0f%% of picks' top driver in f0-f2" % (
                  sorted(top3), sig["f0"]["mean_pct"], sig["f1"]["mean_pct"], sig["f2"]["mean_pct"],
                  D_["auc"]["additive"], D_["auc"]["full"], pair, D_["pairs"][0]["h2"] if D_["pairs"] else np.nan,
                  100 * share),
              top3 == {"f0", "f1", "f2"} and sig["f0"]["mean_pct"] > 0.75 and sig["f1"]["mean_pct"] > 0.8 and
              D_["auc"]["additive"] > 0.85 and D_["auc"]["full"] >= D_["auc"]["additive"] - 0.01 and
              set(pair) == {"f1", "f2"} and share > 0.9, (D_["auc"], D_["pairs"][:3]))
        nflag = sum(1 for s_ in E_["signature"] if s_.get("flag"))
        check("x19b why, absent (ENS picks at random): AUC additive %.3f / full %.3f near 0.5, %d of 10 features "
              "flagged" % (E_["auc"]["additive"], E_["auc"]["full"], nflag),
              abs(E_["auc"]["additive"] - 0.5) < 0.08 and abs(E_["auc"]["full"] - 0.5) < 0.08 and nflag <= 1,
              E_["auc"])
        pct = XWY.day_percentiles(np.array([0, 0, 0, 1, 1]), np.array([[1.0], [3.0], [2.0], [100.0], [np.nan]]))
        check("x19c percentiles are within the day (a day effect cancels; NaN stays NaN)",
              np.allclose(pct[:4, 0], [1 / 3, 1.0, 2 / 3, 1.0]) and np.isnan(pct[4, 0]), pct.ravel().tolist())
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ============================================================================ learning on planted worlds
def discover_world(D, variants, hurdles, decl, eng="D"):
    W = XLL.World(D, decl, eng, [1, 2, 3], "2020-01-01", "2030-01-01", log=quiet)
    op6 = S.comparators(W.B, W.recs)
    r, a, d = W.watch_rows()
    Fm, Pm, AV = XLL.entry_table(W, r, a)
    t_lo, t_hi = int(W.recs["t"].min()), D.cal.n - 1
    R0 = LG.rows_open_sb(W, Fm, op6)
    e0 = LG.execution(W, R0, decl)
    s0, r0, p0 = LG.money(W, LG.book_trades(W, e0), decl, t_lo, t_hi)
    out = {"W": W, "op6": op6, "r0": r0, "e0": e0, "sim0": s0, "cfg": {}}
    for v in variants:
        qh, hd = XLL.learn_hold(W, v, quiet)
        NETm, trades = XLL.enter_outcomes(W, qh, r, a, Fm, Pm)
        Xw = W.watch_X(F.columns("watch", v), r, a)
        for hb in hurdles:
            qw, _, wd = XLL.learn_watch(W, v, Xw, r, a, d, Fm, NETm, hb, quiet, AV=AV)
            A, Qm = XLL.watch_decisions(W, qw, Xw, r, a, d, AV=AV)
            R = LG.rows_policy(W, A, Qm, Fm, Pm, trades)
            res, exe = LG.research(W, R), LG.execution(W, R, decl)
            sim, rr, pf = LG.money(W, LG.book_trades(W, exe), decl, t_lo, t_hi)
            out["cfg"]["%s/%d" % (v, hb)] = {"res": res, "exe": exe, "rr": rr, "sim": sim, "qw": qw, "qh": qh,
                                             "NETm": NETm,
                                             "Xw": Xw, "A": A, "Qm": Qm, "R": R,
                                             "m": EV.research_metrics(W, res, op6, decl),
                                             "p": EV.portfolio_metrics(rr, pf, r0, decl), "hd": hd}
    out["rad"] = (r, a, d, Fm, Pm)
    out["AV"] = AV
    return out


def x12_planted(fast, seed=31):
    D = XW.make_world(effects=("entry", "abandon", "exit", "tail"), n_days=560 if fast else 650,
                      n_sym=70 if fast else 80, seed=seed)
    decl = test_decl()
    o = discover_world(D, ["state_event", "state", "general"], [0, 100], decl)
    W, op6 = o["W"], o["op6"]
    c = o["cfg"]["state_event/0"]
    res, m, p = c["res"], c["m"], c["p"]
    j, t = W.recs["j"], W.recs["t"]
    st = W.B.st[j, t].astype(int)
    ev = W.B.ev[j, t].astype(int)
    tr = res["status"] == "TRADED"
    bull = np.isin(st, (1, 2, 3)) & (ev != 4)
    bear = np.isin(st, (8, 9)) & (ev != 4)
    flat = np.isin(st, (6, 7)) & (ev != 4)
    LOG.append("x12 bull lags %s kinds %s" % (np.bincount((res["e"] - t)[tr & bull], minlength=11).tolist(),
                                               np.bincount(res["kind"][tr & bull], minlength=len(S.ENTRY)).tolist()))
    LOG.append("x12 bear lags %s kinds %s status %s" % (np.bincount((res["e"] - t)[tr & bear], minlength=11).tolist(),
                                                        np.bincount(res["kind"][tr & bear], minlength=len(S.ENTRY)).tolist(),
                                                        {k: int((res["status"][bear] == k).sum()) for k in LG.STATUS}))
    fbo = ev == 4
    o1 = W.B.o[j, t + 1]
    cheap = float(np.nanmean(res["P"][tr & bull] / o1[tr & bull] - 1.0))
    lag = res["e"] - t
    lag1_bear = float(np.mean(lag[tr & bear] == 1))
    later_bull = float(np.mean(lag[tr & bull] >= 2))
    lag1_bull = 1.0 - later_bull
    r_, a_, d_, Fm_, Pm_ = o["rad"]
    n_open = c["NETm"][d_ == 0, 0]                       # the same hold policy, bought at T+1's open
    gain = res["net0"] - np.where(Fm_[d_ == 0, 0], n_open, 0.0)
    tg = XC.block_mean(t[bull], gain[bull], B=600)
    # v1.1: buy stops that enter on the turn (BSTOP / BHIGH / SWHI) buy after the bottom, so the average fill is below
    # T+1's open but not by v1.0's 0.5% (limits only); with ten actions the T+1 share of the bear picks moves with the
    # thread count (55-68% here), so it is asked to be high AND far above the bull picks' T+1 share
    check("x12a planted entry: bull-state picks dip then rally -> %.0f%% bought after T+1, %.2f%% below T+1's open on "
          "average, the timing adds %s a pick over buying T+1's open with the same exits; bear-state picks rally at "
          "once -> %.0f%% bought on T+1 (bull picks %.0f%%)" % (100 * later_bull, 100 * cheap, XC.fmt_ci(tg),
                                                               100 * lag1_bear, 100 * lag1_bull),
          cheap < 0 and later_bull > 0.5 and tg["lo"] > 0 and lag1_bear > 0.4 and lag1_bear - lag1_bull > 0.25,
          (cheap, later_bull, tg, lag1_bear, LOG[-2:]))
    pf, of = float(np.mean(res["net0"][fbo])), float(np.nanmean(np.nan_to_num(op6["open6"][fbo])))
    ent = float(np.mean(tr[fbo] & (lag[fbo] <= 9)))
    check("x12b planted abandon: failed-breakout picks (falling for 10 sessions) - the policy %+.2f%% a pick (unfilled "
          "0) vs OPEN6 %+.2f%%; bought before T+10 in %.0f%%" % (100 * pf, 100 * of, 100 * ent),
          pf > -0.04 and pf > of + 0.08, (pf, of, ent))
    held = res["x"] - res["e"]
    hf, hb_ = float(np.median(held[tr & flat])), float(np.median(held[tr & bull]))
    check("x12c planted exit: turn / flat picks (up 3 days, then down) held %.0f sessions (median) vs %.0f for bull "
          "picks that keep rising" % (hf, hb_), hf <= 5 and hb_ >= 8, (hf, hb_))
    check("x12d planted tail: major winners' PLAN profit captured %.0f%% (>= 70%%), %d of %d missed" % (
        100 * m["majors"]["capture_share"], m["majors"]["missed"], m["majors"]["n"]),
        m["majors"]["capture_share"] >= 0.7, m["majors"])
    check("x12e the policy beats OPEN6 per selection %s and OPEN_SB in the portfolio %s (both above 0)" % (
        XC.fmt_ci(m["vs_open6"]), XC.fmt_ci(p["excess"], unit="bp")),
        m["vs_open6"]["lo"] > 0 and p["excess"]["lo"] > 0)
    u = o["cfg"]["general/0"]["m"]
    sv = o["cfg"]["state/0"]["m"]
    check("x12f the bifurcation: effects keyed on the state (entry, exit, tail) and on the event (failed breakout): "
          "state_event %s > state %s > general %s per selection" % (XC.fmt_ci(m["net"]), XC.fmt_ci(sv["net"]),
                                                                    XC.fmt_ci(u["net"])),
          m["net"]["mean"] > sv["net"]["mean"] > u["net"]["mean"])
    AV = o["AV"]
    badav = 0
    for nm_, cf in o["cfg"].items():
        A_ = cf["A"]
        ent = np.flatnonzero(A_ >= 2)
        badav += int((~AV[ent, A_[ent] - 2]).sum())
    used = sorted({S.ENTRY[int(k)] for cf in o["cfg"].values() for k in cf["res"]["kind"][cf["res"]["status"] ==
                                                                                           "TRADED"]})
    check("x12l no configuration ever chose an order that could not be placed (%d) - orders used: %s" % (badav, used),
          badav == 0)
    n100 = int((o["cfg"]["state_event/100"]["res"]["status"] == "TRADED").sum())
    check("x12g a 100 bp hurdle trades no more than none (%d vs %d)" % (n100, int(tr.sum())), n100 <= tr.sum())
    v = LG.check_budgets(W, c["exe"], decl)
    vv = LG.check_budgets(W, o["e0"], decl)
    check("x12h execution ledgers (policy and OPEN_SB): 0 budget violations", sum(v.values()) + sum(vv.values()) == 0,
          (v, vv))
    ok = len(res["status"]) == W.n_rec and len(W.all_recs) == W.n_rec + len(W.out_of_period)
    okt = bool(np.all((lag[tr] >= 1) & (lag[tr] <= W.W) & (res["x"][tr] > res["e"][tr]) & np.isfinite(res["P"][tr])))
    check("x12i research ledger: every selection once (%d + %d out of period), every trade inside its window, exits "
          "after the entry session" % (W.n_rec, len(W.out_of_period)), ok and okt)
    e0 = o["e0"]
    t0 = e0["status"] == "TRADED"
    ok0 = bool(np.all(e0["e"][t0] == t[t0] + 1)) and np.array_equal(e0["x"][t0], op6["open6_x"][t0]) and \
        np.allclose(e0["net"][t0], op6["open6"][t0])
    check("x12j OPEN_SB trades are exactly the OPEN6 trades (T+1 open, T+6 open, same net)", ok0)
    sim = c["sim"]
    pnl = sum(x["pnl"] for x in sim["trades"])
    eq_ok = sim["open_at_end"] > 0 or abs(sim["equity"][-1] - (sim["capital"] + pnl)) < 1e-6 * sim["capital"]
    check("x12k money view: final equity = capital + every trade's rupee result (%d trades, %d skipped for cash / "
          "liquidity)" % (len(sim["trades"]), len(sim["skipped"])), eq_ok)
    return o


def x13_absent(fast):
    D = XW.make_world(effects=("absent",), n_days=420 if fast else 600, n_sym=50, seed=41)
    decl = test_decl()
    o = discover_world(D, ["state_event"], [0], decl)
    c = o["cfg"]["state_event/0"]
    m = c["m"]
    check("x13a absent effects: the policy's own net per selection %s is not above 0 (it may avoid OPEN6's costs: %s)"
          % (XC.fmt_ci(m["net"]), XC.fmt_ci(m["vs_open6"])), not (m["net"]["lo"] > 0))
    W = o["W"]
    r, a, d, Fm, Pm = o["rad"]
    A_in, Qm_in = XLL.watch_decisions(W, c["qw"], c["Xw"], r, a, d, full=True, AV=o["AV"])
    check("x13b out-of-fold decisions differ from the in-sample model's (the evaluation never uses a model on its own "
          "training rows): %.0f%% of rows differ" % (100 * np.mean(A_in != c["A"])), np.mean(A_in != c["A"]) > 0.02)


def x14_null(fast):
    k = 6 if fast else 12
    flags = 0
    decl = test_decl()
    decl["learning"]["model"] = "ridge"
    for s in range(k):
        D = XW.make_world(effects=("absent",), n_days=330, n_sym=40, seed=500 + s)
        o = discover_world(D, ["state_event"], [0], decl)
        flags += int(o["cfg"]["state_event/0"]["m"]["net"]["lo"] > 0)
    check("x14 null worlds (ridge): own net per selection 'above 0' in %d of %d (expected about 0)" % (flags, k),
          flags <= max(1, k // 6), flags)


def x15_intraday(fast):
    D = XW.make_world(effects=("intraday",), n_days=320 if fast else 420, n_sym=40, seed=51)
    decl = test_decl()
    decl["intraday"]["from"] = "2019-01-01"
    W = XLL.World(D, decl, "D", [1, 2, 3], "2020-01-01", "2030-01-01", log=quiet)
    op6 = S.comparators(W.B, W.recs)
    r, a, d = W.watch_rows()
    Fm, Pm, _ = XLL.entry_table(W, r, a)
    res = LG.research(W, LG.rows_open_sb(W, Fm, op6))
    st = EV.intraday_study(W, res, decl, 0, quiet)
    c = st["checkpoints"].get("1000", {})
    ev = W.B.ev[W.recs["j"], W.recs["t"]]
    base = float(np.mean(ev[c["records"]] == 1)) if c else NAN
    prec = float(np.mean(ev[c["picked_records"]] == 1)) if c and len(c["picked_records"]) else NAN
    ok = bool(c) and c["chosen"]["lo"] > 0 and c["always"]["hi"] < 0 and prec > 2.5 * base
    check("x15 planted intraday: waiting until 10:00 loses in general %s; chosen before the open "
          "(%s picked, %.0f%% of them new breakouts vs %.0f%% of all) %s" % (
              XC.fmt_ci(c.get("always")), c.get("picked"), 100 * prec, 100 * base, XC.fmt_ci(c.get("chosen"))), ok,
          {k: v for k, v in c.items() if "records" not in k})


# ============================================================================ the CLI: seal, freeze, evaluate
def _run(X, argv, **kw):
    try:
        return X.main(argv, **kw)
    except Exception as e:              # noqa: BLE001 - a crash is a result the check sees (never a pass)
        return "EXC:%s" % type(e).__name__


def x16_cli(fast):
    import execlab as X
    tmp = Path(tempfile.mkdtemp(prefix="xlcli_"))
    try:
        D = XW.make_world(effects=("entry", "exit"), n_days=1560, n_sym=40, seed=61, picks=2)
        seen = []

        def loader(a, decl, t_from, t_to, seal_end, log):
            seen.append((t_from, t_to, seal_end))
            return XW.cut(D, seal_end)

        dpath = tmp / "decl.json"
        d = test_decl()
        d["learning"]["model"] = "ridge"
        d["hurdles_bp"] = [0, 50]
        d["variants"] = {"state_event": d["variants"]["state_event"]}
        dpath.write_text(json.dumps({k: v for k, v in d.items() if not k.startswith("_")}), encoding="utf-8")
        out = tmp / "out"
        buf = io.StringIO()
        with redirect_stdout(buf):
            rc1 = _run(X, ["discover", "--out", str(out), "--decl", str(dpath), "--engines", "D"], loader=loader,
                         log=quiet)
        runs = sorted(out.glob("disc_*"))
        rep = (runs[0] / "REPORT.md").read_text(encoding="utf-8") if runs else ""
        cal_end = XW.cut(D, seen[0][2]).cal.days[-1] if seen else None
        check("x16a discover: the loader is cut at 2022-12-31 (nothing of 2023-25 exists), report and ledgers written",
              rc1 == 0 and seen and seen[0][2] == "2022-12-31" and str(cal_end) <= "2022-12-31" and
              "### Research ledger" in rep and (runs[0] / "ledger_research.csv").exists(), (rc1, seen))
        lines = (runs[0] / "ledger_research.csv").read_text(encoding="utf-8").splitlines()
        nsel = len([s for s in D.registry.active() if s.engine == "D" and "2020-01-01" <= s.T <= "2022-12-31"])
        check("x16b every selection of the period is in the research ledger once per configuration (incl. "
              "OUT_OF_PERIOD)", len(lines) - 1 == nsel * 2, (len(lines) - 1, nsel))
        with redirect_stdout(buf):
            rc2 = _run(X, ["discover", "--out", str(out), "--decl", str(dpath), "--engines", "D", "--to", "2023-06-30"],
                         loader=loader, log=quiet)
            rc3 = _run(X, ["discover", "--out", str(out), "--decl", str(dpath), "--engines", "D"], loader=loader,
                         log=quiet)
            rc4 = _run(X, ["discover", "--out", str(out), "--decl", str(dpath), "--engines", "D", "--folds", "2"],
                         loader=loader, log=quiet)
        qrun = [p for p in sorted(out.glob("disc_*")) if p != runs[0]]
        with redirect_stdout(buf):
            rc5 = _run(X, ["freeze", "--out", str(out), "--decl", str(dpath), "--run", qrun[0].name], log=quiet) if qrun \
                else -1
            rc6 = _run(X, ["evaluate", "--out", str(out), "--decl", str(dpath), "--engines", "D"], loader=loader,
                         log=quiet)
            rc7 = _run(X, ["freeze", "--out", str(out), "--decl", str(dpath), "--run", runs[0].name], log=quiet)
        fz = out / "FROZEN.json"
        check("x16c refused: discovery into 2023 (3), the same run again (3), freezing a run with changed settings "
              "(3), evaluating before a freeze (3); freezing the declared run works (0)",
              (rc2, rc3, rc5, rc6) == (3, 3, 3, 3) and rc4 == 0 and rc7 == 0 and fz.exists(),
              (rc2, rc3, rc4, rc5, rc6, rc7))
        frozen = json.loads(fz.read_text()) if fz.exists() else {}
        out2 = tmp / "out2"
        out2.mkdir()
        shutil.copytree(runs[0], out2 / runs[0].name)
        f2 = dict(frozen)
        f2["models"] = str(out2 / runs[0].name / "models.pkl")
        f2["code"] = dict(frozen.get("code", {}), **{"xl_sim.py": "0000000000000000"})
        (out2 / "FROZEN.json").write_text(json.dumps(f2), encoding="utf-8")
        with redirect_stdout(buf):
            rc8 = _run(X, ["evaluate", "--out", str(out2), "--decl", str(dpath), "--engines", "D"], loader=loader,
                         log=quiet)
        nseen = len(seen)
        has_c = bool(frozen.get("candidates", {}).get("D"))
        with redirect_stdout(buf):
            rc9 = _run(X, ["evaluate", "--out", str(out), "--decl", str(dpath), "--engines", "D"], loader=loader,
                         log=quiet)
            rc10 = _run(X, ["evaluate", "--out", str(out), "--decl", str(dpath), "--engines", "D"], loader=loader,
                          log=quiet)
            rc11 = _run(X, ["freeze", "--out", str(out), "--decl", str(dpath), "--run", runs[0].name, "--replace"],
                          log=quiet)
        ev = sorted(out.glob("eval_*"))
        erep = (ev[0] / "REPORT.md").read_text(encoding="utf-8") if ev else ""
        check("x16d evaluate: refused when the code changed after the freeze (3, nothing loaded); runs once on the "
              "sealed 2023-25 (0), the second time refused (3), no re-freeze after it (3)",
              rc8 == 3 and nseen == len(seen) - 1 and rc9 == 0 and rc10 == 3 and rc11 == 3 and
              seen[-1][:3] == ("2023-01-01", "2025-12-31", "2025-12-31") and len(ev) == 1,
              (rc8, rc9, rc10, rc11, seen[-1:]))
        if has_c:
            check("x16e the sealed report: frozen candidates only, acceptance A1-A4 per candidate",
                  "### Acceptance (sealed)" in erep and all(c in erep for c in frozen["candidates"]["D"]))
        led = [json.loads(x) for x in (out / "execlab_ledger.jsonl").read_text().splitlines()]
        check("x16f the ledger records every discover / freeze / evaluate (%d lines)" % len(led),
              {x["cmd"] for x in led} == {"discover", "freeze", "evaluate"} and len(led) >= 6)
        with redirect_stdout(buf):
            rcb = _run(X, ["discover", "--decl", str(dpath)], loader=None, log=quiet)
            rcc = _run(X, ["discover", "--out", str(out), "--decl", str(dpath)], loader=None, log=quiet)
        check("x16g no silent defaults: discover without --out (2) or --root (2) refused", (rcb, rcc) == (2, 2),
              (rcb, rcc))
        # a run stopped part-way (ENS dies, as on a PC out of memory): D is on disk and is kept; the same command
        # resumes with ENS only; then the same command is refused
        out3 = tmp / "out3"
        real = X.engine_discover
        calls = []

        def dying(D_, decl_, eng, *aa, **kk):
            calls.append(eng)
            if eng == "ENS" and calls.count("ENS") == 1:
                raise MemoryError("planted: out of memory in ENS")
            return real(D_, decl_, eng, *aa, **kk)

        X.engine_discover = dying
        try:
            with redirect_stdout(buf):
                rr1 = _run(X, ["discover", "--out", str(out3), "--decl", str(dpath), "--engines", "D,ENS"],
                           loader=loader, log=quiet)
                run3 = sorted(out3.glob("disc_*"))
                dn1 = json.loads((run3[0] / "D" / "DONE.json").read_text()) if run3 else {}
                rep1 = (run3[0] / "REPORT.md").read_text(encoding="utf-8") if run3 else ""
                rfz = _run(X, ["freeze", "--out", str(out3), "--decl", str(dpath), "--run", run3[0].name], log=quiet) \
                    if run3 else -1
                rr2 = _run(X, ["discover", "--out", str(out3), "--decl", str(dpath), "--engines", "D,ENS"],
                           loader=loader, log=quiet)
                rr3 = _run(X, ["discover", "--out", str(out3), "--decl", str(dpath), "--engines", "D,ENS"],
                           loader=loader, log=quiet)
        finally:
            X.engine_discover = real
        dn2 = json.loads((run3[0] / "D" / "DONE.json").read_text()) if run3 else {}
        en2 = (run3[0] / "ENS" / "DONE.json").exists() if run3 else False
        cj = json.loads((run3[0] / "candidates.json").read_text()) if run3 else {}
        lr3 = (run3[0] / "ledger_research.csv").read_text(encoding="utf-8").splitlines() if run3 else []
        engs = {ln.split(",")[0] for ln in lr3[1:]}
        check("x16h a run stopped in ENS keeps D on disk (its report section, ledgers, models; ENS 'not finished'); "
              "freezing it is refused (3); the same command resumes ENS only (D not recomputed: %s); then refused (3)" %
              calls, str(rr1).startswith("EXC:MemoryError") and dn1.get("run") and "Not finished yet" in rep1 and
              rfz == 3 and rr2 == 0 and rr3 == 3 and dn2.get("when") == dn1.get("when") and en2 and
              calls == ["D", "ENS", "ENS"] and engs == {"D", "ENS"} and cj.get("engines_done") == ["D", "ENS"],
              (rr1, rfz, rr2, rr3, calls, engs, cj.get("engines_done")))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _find(name, env, marker):
    for c in (os.environ.get(env, ""), str(ROOT.parent / name), str(ROOT.parent / "work" / name)):
        if c and (Path(c) / marker).exists():
            return Path(c)
    return None


def x17_fake_cache():
    pdir, tdir = _find("pathlab", "PATHLAB_DIR", "pathlab.py"), _find("tradelab", "TRADELAB_DIR", "tl_common.py")
    if pdir is None or tdir is None:
        check("x17 the fake production cache needs pathlab and tradelab (PATHLAB_DIR / TRADELAB_DIR)", False,
              (pdir, tdir))
        return
    os.environ["TRADELAB_DIR"] = str(tdir)
    for p_ in (str(pdir / "tests"), str(pdir), str(tdir / "tests"), str(tdir)):
        if p_ not in sys.path:
            sys.path.insert(0, p_)
    saved = {k: os.environ.pop(k, None) for k in ("TRADELAB_OUT", "PATHLAB_OUT", "V2_OUT")}
    import pl_world as PW
    import tl_world as TWL
    import execlab as X
    tmp = Path(tempfile.mkdtemp(prefix="xlfake_"))
    try:
        w = PW.make_cache_world(tmp / "w1", n_regular=14, n_3m=3)
        TWL.use_mods(w["root"])
        os.environ["V2_OUT"] = str(tmp / "v2out")
        d = test_decl()
        d["learning"]["model"] = "ridge"
        d["hurdles_bp"] = [0]
        d["variants"] = {"state_event": d["variants"]["state_event"]}
        d["learning"]["min_records"] = 30
        dpath = tmp / "decl.json"
        dpath.write_text(json.dumps({k: v for k, v in d.items() if not k.startswith("_")}), encoding="utf-8")
        out = tmp / "out"
        buf = io.StringIO()
        with redirect_stdout(buf):
            rc = _run(X, ["discover", "--root", str(w["root"]), "--out", str(out), "--pm-run", "PM_TEST_001",
                         "--stage-e-any", "--costs", "replica", "--decl", str(dpath)], log=quiet)
        runs = sorted(out.glob("disc_*"))
        rep = (runs[0] / "REPORT.md").read_text(encoding="utf-8") if runs else ""
        run = json.loads((runs[0] / "RUN.json").read_text()) if runs else {}
        check("x17 the fake production cache through v2engine's adapter (tradelab, stage E stand-in, VIX, 3-minute "
              "bars): discover runs, data cut at 2022-12-31, both engines reported, the stand-in recorded as a change "
              "(such a run can never be frozen)",
              rc == 0 and "## Engine D" in rep and "## Engine ENS" in rep and run.get("data_to", "9") <= "2022-12-31"
              and run.get("overrides", {}).get("costs") == "replica" and run["overrides"].get("pm_run") == "PM_TEST_001",
              (rc, run.get("data_to"), run.get("overrides"), LOG[-5:]))
        # execlab's swing highs = tl_state's own (v2 carries tl_state's confirmed swing highs with the session known)
        import xl_data as XD
        Dr = XD.load_real(w["root"], "PM_TEST_001", ["D", "ENS"], [1, 2, 3], "2020-01-01", "2022-12-31",
                          "2022-12-31", log=quiet, stage_e_any=True, costs="replica", warmup=320)
        Br = S.Bars(Dr, sorted({s_.symbol for s_ in Dr.registry.active()}))
        agree, tot, lv = 0, 0, 0
        for s_, j_ in Br.k.items():
            ref = np.full(Dr.cal.n, np.nan)
            for ci, px in sorted(Dr.events[s_].get("swing_highs", [])):
                ref[ci:] = px
            m_ = np.arange(Dr.cal.n) >= 20
            a_, b_ = ref[m_], Br.swh[j_][m_]
            agree += int(np.sum((np.isnan(a_) & np.isnan(b_)) | np.isclose(a_, b_)))
            tot += int(m_.sum())
            lv += int(np.isfinite(Br.lvl[j_]).sum())
        check("x17b on the fake cache: execlab's swing highs equal tl_state's own on %.2f%% of %d stock-sessions; event "
              "levels present on %d stock-sessions" % (100.0 * agree / max(tot, 1), tot, lv),
              tot > 1000 and agree >= 0.99 * tot and lv > 0, (agree, tot, lv))
        with redirect_stdout(buf):
            rcw = _run(X, ["why", "--root", str(w["root"]), "--out", str(out), "--pm-run", "PM_TEST_001",
                           "--decl", str(dpath)], log=quiet)
            rcw2 = _run(X, ["why", "--root", str(w["root"]), "--out", str(out), "--pm-run", "PM_TEST_001",
                            "--decl", str(dpath), "--to", "2023-03-31"], log=quiet)
        wr = sorted(out.glob("why_*"))
        wmd = (wr[0] / "WHY.md").read_text(encoding="utf-8") if wr else ""
        wf = (wr[0] / "why_features.csv").read_text(encoding="utf-8") if wr else ""
        wrun = json.loads((wr[0] / "RUN.json").read_text()) if wr else {}
        check("x17c why on the fake cache: runs (panel_oc through tradelab's reader, the label column dropped by the "
              "firewall), both engines reported; asking past 2022 is refused (3)",
              rcw == 0 and "## Engine D" in wmd and "## Engine ENS" in wmd and "label_" not in wf and
              wrun.get("features") == 1 and rcw2 == 3, (rcw, rcw2, wrun.get("features"), LOG[-4:]))
    finally:
        os.environ.pop("V2_OUT", None)
        for k_, v_ in saved.items():
            if v_ is not None:
                os.environ[k_] = v_
        shutil.rmtree(tmp, ignore_errors=True)


def main(argv=None):
    argv = list(argv or [])
    fast = "quick" in argv or "unit" in argv
    t0 = time.time()
    print("execlab selftest (%s)%s" % (XC.VERSION, " - quick" if fast else ""), flush=True)
    import execlab as X
    print("  " + ", ".join("%s %s" % kv for kv in X.versions().items()), flush=True)
    only = [x for a in argv if a.startswith("only=") for x in a.split("=", 1)[1].split(",") if x]
    only = set(only) if only else None
    units = [("x01", x01_fills), ("x02", x02_holds),
             ("x03", lambda: x03_open6_and_costs(XW.make_world(effects=("absent",), n_days=300, n_sym=30, seed=7,
                                                                locks=0.03), fast)),
             ("x05", lambda: x05_leak(fast)), ("x06", x06_scale), ("x07", x07_firewall), ("x07b", x07b_guard), ("x08", x08_backward),
             ("x09", x09_purge), ("x10", x10_stats), ("x11", x11_allocator), ("x18", x18_swings), ("x19", x19_why)]
    worlds = [("x12", lambda: x12_planted(fast)), ("x13", lambda: x13_absent(fast)), ("x14", lambda: x14_null(fast)),
              ("x15", lambda: x15_intraday(fast)), ("x16", lambda: x16_cli(fast)), ("x17", x17_fake_cache)]
    for name, fn in units + ([] if "unit" in argv else worlds):
        if only is None or name in only:
            fn()
    nf = sum(1 for _, ok, _ in RESULTS if not ok)
    print("%d checks, %d failed (%.0f s)" % (len(RESULTS), nf, time.time() - t0))
    print("VERIFIED (%s)" % XC.VERSION if nf == 0 else "NOT VERIFIED")
    return 0 if nf == 0 else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
