# MANIFEST - execlab v1.1 (1 Nov 2026)

Copy the whole folder to C:\Users\karanvsi\PyCharmMiscProject\execlab\ (next to v2engine, tradelab, pathlab),
replacing v1.0's files. Nothing else changes: no file of bigmove_deploy, tradelab, pathlab or v2engine is replaced.
Your output folder C:\QuantData\execlab keeps v1.0's runs; v1.1 runs go into new disc_<id> folders.

Needs: Python 3.10+, numpy, pandas, scikit-learn >= 1.2 (1.5.2 and 1.9.1 tested), pyarrow (as tradelab), v2engine
0.3 (drop 3), tradelab v1.3.1, pathlab v1.0 (read only, through env_v2.bat).

| file | lines | bytes | sha256 (first 16) |
|---|---|---|---|
| README_EXECLAB.md | 164 | 12312 | cfe935ead916e1a3 |
| XL_DECLARATION.json | 255 | 11799 | 1153b33664141c54 |
| env_execlab.bat | 37 | 1601 | 55fc4114557a916c |
| execlab.py | 776 | 39024 | 610106183700fc11 |
| tests\test_execlab.py | 973 | 54621 | dab271b4fce1d9c4 |
| tests\xl_mutate.py | 91 | 7806 | 87a5ca723a288541 |
| tests\xl_world.py | 253 | 11934 | 0cc857b84c7bb0eb |
| xl_cards.py | 92 | 3604 | 547698d571f62bda |
| xl_common.py | 328 | 13398 | 5894964c7e5d0868 |
| xl_data.py | 105 | 4574 | 069c8c0f88676c22 |
| xl_eval.py | 263 | 13352 | 4eb00d596c844395 |
| xl_feat.py | 305 | 14308 | 349fb172449158ac |
| xl_learn.py | 530 | 24289 | 28d8cc1bb2d33bdc |
| xl_ledger.py | 222 | 9697 | cc5b33940ddedd3d |
| xl_report.py | 296 | 16122 | 8605724df5591cc8 |
| xl_sim.py | 358 | 17863 | b6663731bd00fda8 |
| xl_why.py | 336 | 17545 | 7bfc1f3ecc54e498 |

Verified 1 Nov 2026: 48 checks, 0 failed, full and quick, on Python 3.13 / numpy 2.5.3 / pandas 3.0.5 / scikit-learn 1.9.1; 48 checks, 0 failed (quick) on Python 3.12 / numpy 2.4.1 / pandas 2.3.3 / scikit-learn 1.5.2; 30 of 30 planted bugs caught (tests\xl_mutate.py). Not yet run on Karan's cache.
