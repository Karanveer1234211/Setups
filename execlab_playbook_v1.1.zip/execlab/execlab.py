r"""execlab.py - execlab v1.1: the execution research engine on BigMove's selections.

  python execlab.py --selftest [quick]
  python execlab.py discover --root %CACHE_DAILY_ROOT% --out %XL_OUT%          (2020-22 only; 2023-25 is not loaded)
  python execlab.py why      --root %CACHE_DAILY_ROOT% --out %XL_OUT%          (what the engines' picks have in common)
  python execlab.py freeze   --out %XL_OUT% --run disc_<id>                    (the candidates and the acceptance rule)
  python execlab.py evaluate --root %CACHE_DAILY_ROOT% --out %XL_OUT%          (once: the sealed 2023-25)
  python execlab.py status   --out %XL_OUT%

Each engine is written to <run>\<engine>\ the moment it finishes; the same command resumes a run that stopped part-way
(finished engines are kept). Reads production READ ONLY through v2engine 0.3 (tradelab, stage E's costs). Writes only
under --out. Every command appends to <out>\execlab_ledger.jsonl.
"""
import argparse
import gc
import json
import os
import pickle
import platform
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import xl_common as XC  # noqa: E402
import xl_eval as EV  # noqa: E402
import xl_feat as F  # noqa: E402
import xl_learn as XLL  # noqa: E402
import xl_ledger as LG  # noqa: E402
import xl_report as RP  # noqa: E402
import xl_sim as S  # noqa: E402
from xl_cards import exit_cards, setup_cards  # noqa: E402

QUICK = {"learning.folds": 3, "learning.iterations_hold": 2, "learning.iterations_watch": 2,
         "learning.hold_sample_entries": 2, "learning.max_train_rows": 60000, "learning.hgb.max_iter": 60,
         "learning.hgb.learning_rate": 0.1}


def set_path(d, dotted, v):
    ks = dotted.split(".")
    for k in ks[:-1]:
        d = d[k]
    d[ks[-1]] = v


def versions():
    out = {"python": platform.python_version(), "numpy": np.__version__}
    try:
        import pandas
        out["pandas"] = pandas.__version__
    except ImportError:
        pass
    try:
        import sklearn
        out["sklearn"] = sklearn.__version__
    except ImportError:
        out["sklearn"] = None
    return out


def parse_ranks(s):
    out = []
    for part in str(s).split(","):
        if "-" in part:
            a, b = part.split("-")
            out += list(range(int(a), int(b) + 1))
        elif part.strip():
            out.append(int(part))
    return sorted(set(out))


def strip(qs):
    """Only the models trained on everything (fold -1): what is frozen."""
    q = XLL.QSet(qs.actions, qs.cols, qs.specialised, qs.ref, qs.level)
    q.models = {k: v for k, v in qs.models.items() if k[0] == -1}
    q.const = {k: v for k, v in qs.const.items() if k[0] == -1}
    return q


def real_loader(a, decl, t_from, t_to, seal_end, log):
    import xl_data as XD
    return XD.load_real(a.root, a.pm_run, a.engines, a.ranks, t_from, t_to, seal_end, log=log,
                        stage_e_any=a.stage_e_any, tradelab_any=a.tradelab_any, costs=a.costs,
                        max_symbols=a.max_symbols, warmup=int(decl["data"]["warmup_sessions"]))


# ============================================================================ one engine
def _json(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, (np.bool_,)):
        return bool(o)
    return str(o)


def _base(world, decl, op6, Fm, t_lo, t_hi):
    R0 = LG.rows_open_sb(world, Fm, op6)
    e0 = LG.execution(world, R0, decl)
    _, r0, p0 = LG.money(world, LG.book_trades(world, e0), decl, t_lo, t_hi)
    pn = LG.plan_native_book(world, t_lo, t_hi)
    _, rP, pP = LG.money(world, pn, decl, t_lo, t_hi, slots=15)
    return e0, r0, EV.portfolio_metrics(r0, p0, None, decl), rP, EV.portfolio_metrics(rP, pP, r0, decl)


def _detail(world, decl, cfg, X, cols, op6, qh, trades, hurdle, log):
    res = cfg["res"]
    co, ab = EV.cohorts(world, res)
    cfg["cohorts"], cfg["abandons"] = co, ab
    cfg["setup_cards"] = setup_cards(world, X, cols, cfg["A"], res, op6, XLL.WATCH_ACTIONS, decl)
    tr = np.flatnonzero(res["status"] == "TRADED")
    if len(tr):
        ti = {(int(rw), int(k)): q for q, (rw, k) in enumerate(zip(trades["row"], trades["k"]))}
        sel = np.array([ti[(int(res["row"][r]), int(res["kind"][r]))] for r in tr])
        pos = {k: np.asarray(v)[sel] for k, v in trades["pos"].items()}
        trace = []
        _, hm = XLL._menus(decl)
        S.hold_forward(world.B, pos, XLL.hold_decider(world, qh, pos, full=cfg.get("full", False)), world.H, hm,
                       decl["fills"]["exit_slip_atr"], trace=trace)
        if trace:
            ids = np.concatenate([t[0] for t in trace])
            hh = np.concatenate([t[1] for t in trace])
            acts = np.concatenate([t[2] for t in trace])
            rmax = np.concatenate([t[3] for t in trace])
            R = world.recs
            r = pos["r"][ids]
            Xh = world.hold_X(qh.cols, pos["j"][ids], pos["e"][ids] + hh, pos["e"][ids], R["t"][r], pos["P"][ids],
                              pos["kind"][ids], R["rank"][r], R["score"][r], rmax)
            cfg["exit_cards"] = exit_cards(Xh, qh.cols, acts, S.HOLDA, decl)
    if not cfg.get("full"):                       # exploratory, never frozen: discovery only
        cfg["intraday"] = EV.intraday_study(world, res, decl, hurdle, log)


def _config(world, decl, name, v, hb, A, Qm, Fm, Pm, trades, op6, r0, t_lo, t_hi, full=False):
    R = LG.rows_policy(world, A, Qm, Fm, Pm, trades)
    res, exe = LG.research(world, R), LG.execution(world, R, decl)
    _, rr, pf = LG.money(world, LG.book_trades(world, exe), decl, t_lo, t_hi)
    c = {"variant": v, "hurdle": hb, "res": res, "exe": exe, "A": A, "full": full,
         "research": EV.research_metrics(world, res, op6, decl), "portfolio": EV.portfolio_metrics(rr, pf, r0, decl),
         "budget_check": LG.check_budgets(world, exe, decl), "tables": EV.state_tables(world, res, op6, decl)}
    return c, rr


def engine_discover(D, decl, eng, ranks, t_from, t_to, B, fs, variants, hurdles, log, work=None):
    t0 = time.time()
    world = XLL.World(D, decl, eng, ranks, t_from, t_to, log=log, B=B, fs=fs)
    E = {"n_all": len(world.all_recs), "n_rec": world.n_rec, "n_oop": len(world.out_of_period), "configs": {},
         "learning": {}, "world": world}
    need = int(decl["learning"]["min_records"])
    if world.n_rec < need:
        E["skipped"] = "Engine %s: %d selections with a complete path - too few to learn from (%d needed)." % (
            eng, world.n_rec, need)
        return E, {}
    op6 = S.comparators(B, world.recs)
    E["op6"] = op6
    r, a, d = world.watch_rows()
    Fm, Pm, AV = XLL.entry_table(world, r, a)
    t_lo, t_hi = int(world.recs["t"].min()), D.cal.n - 1
    E["t_lo"], E["t_hi"] = t_lo, t_hi
    e0, r0, E["open_sb"], rP, E["plan_native"] = _base(world, decl, op6, Fm, t_lo, t_hi)
    E["open_sb_exe"], E["daily"] = e0, {"OPEN_SB": r0, "PLAN_native": rP}
    E["base_research"] = EV.research_metrics(world, {"net0": np.nan_to_num(op6["open6"]), "status": np.where(
        np.isfinite(op6["open6"]), "TRADED", "NO_FILL").astype(object), "net": op6["open6"],
        "x": np.where(np.isfinite(op6["open6"]), op6["open6_x"], -1), "e": world.recs["t"] + 1,
        "mfe": np.full(world.n_rec, np.nan), "mae": np.full(world.n_rec, np.nan),
        "kind": np.zeros(world.n_rec, np.int64), "reason": np.ones(world.n_rec, np.int8)}, op6, decl)
    models = {"hold": {}, "watch": {}}
    parked = {}
    for v in variants:
        qh, hd = XLL.learn_hold(world, v, log)
        E["learning"]["hold %s" % v] = hd["value_by_iteration"]
        NETm, trades = XLL.enter_outcomes(world, qh, r, a, Fm, Pm)
        cols = F.columns("watch", v)
        Xw = world.watch_X(cols, r, a)
        models["hold"][v] = strip(qh)
        for hb in hurdles:
            qw, _, wd = XLL.learn_watch(world, v, Xw, r, a, d, Fm, NETm, hb, log, AV=AV)
            E["learning"]["watch %s %dbp" % (v, hb)] = wd["value_by_iteration"]
            A, Qm = XLL.watch_decisions(world, qw, Xw, r, a, d, AV=AV)
            name = "%s/%dbp" % (v, hb)
            E["configs"][name], E["daily"][name] = _config(world, decl, name, v, hb, A, Qm, Fm, Pm, trades, op6, r0,
                                                          t_lo, t_hi)
            models["watch"][name] = strip(qw)
            del qw, Qm
        # this variant's fold models and trades wait on disk for the details (memory: one variant at a time)
        blob = (qh, trades, Xw, cols)
        if work is not None:
            work.mkdir(parents=True, exist_ok=True)
            pth = work / ("%s_%s.pkl" % (eng, v))
            with open(pth, "wb") as fh:
                pickle.dump(blob, fh, protocol=4)
            parked[v] = pth
        else:
            parked[v] = blob
        del qh, trades, Xw, NETm, blob
        gc.collect()
        log("   %s %s done (%.0f s, %s)" % (eng, v, time.time() - t0, XC.mem_text()))
    names = list(E["configs"])
    E["rw"], E["pbo"] = EV.family({k: E["daily"][k] for k in names}, r0, decl)
    E["candidates"] = EV.candidates(E["configs"], E["rw"], decl)
    best = E["candidates"][0] if E["candidates"] else max(names, key=lambda k: E["rw"][k]["mean"])
    E["best"] = best
    E["variant_best"] = {v: max([k for k in names if E["configs"][k]["variant"] == v],
                                key=lambda k: E["rw"][k]["mean"]) for v in variants}
    loaded = {}
    for name in dict.fromkeys(E["candidates"] + [best]):
        c = E["configs"][name]
        v = c["variant"]
        if v not in loaded:
            loaded.clear()
            gc.collect()
            if isinstance(parked[v], Path):
                with open(parked[v], "rb") as fh:
                    loaded[v] = pickle.load(fh)
            else:
                loaded[v] = parked[v]
        qh, trades, Xw, cols = loaded[v]
        _detail(world, decl, c, Xw, cols, op6, qh, trades, c["hurdle"], log)
    loaded.clear()
    for v, pth in parked.items():
        if isinstance(pth, Path):
            try:
                pth.unlink()
            except OSError:
                pass
    E["seconds"] = round(time.time() - t0, 1)
    E["memory"] = XC.mem_text()
    log("   %s done in %.0f s (%s); candidates: %s" % (eng, time.time() - t0, E["memory"],
                                                         ", ".join(E["candidates"]) or "none"))
    return E, models


def engine_evaluate(D, decl, eng, ranks, t_from, t_to, B, fs, cands, models, log):
    t0 = time.time()
    world = XLL.World(D, decl, eng, ranks, t_from, t_to, folds=1, log=log, B=B, fs=fs)
    E = {"n_all": len(world.all_recs), "n_rec": world.n_rec, "n_oop": len(world.out_of_period), "configs": {},
         "world": world}
    if world.n_rec == 0 or not cands:
        E["skipped"] = "Engine %s: %s." % (eng, "no frozen candidate" if not cands else "no selections")
        return E
    op6 = S.comparators(B, world.recs)
    E["op6"] = op6
    r, a, d = world.watch_rows()
    Fm, Pm, AV = XLL.entry_table(world, r, a)
    t_lo, t_hi = int(world.recs["t"].min()), D.cal.n - 1
    E["t_lo"], E["t_hi"] = t_lo, t_hi
    e0, r0, E["open_sb"], rP, E["plan_native"] = _base(world, decl, op6, Fm, t_lo, t_hi)
    E["daily"] = {"OPEN_SB": r0, "PLAN_native": rP}
    days = D.cal.days[t_lo:t_hi + 1]
    for name in cands:
        v, hb = name.split("/")[0], int(name.split("/")[1].replace("bp", ""))
        qh, qw = models["hold"][v], models["watch"][name]
        cols = F.columns("watch", v)
        Xw = world.watch_X(cols, r, a)
        A, Qm = XLL.watch_decisions(world, qw, Xw, r, a, d, full=True, AV=AV)
        want = np.zeros(Fm.shape, bool)
        m = A >= 2
        want[np.flatnonzero(m), A[m] - 2] = True
        NETm, trades = XLL.enter_outcomes(world, qh, r, a, Fm, Pm, full=True, only=want)
        c, rr = _config(world, decl, name, v, hb, A, Qm, Fm, Pm, trades, op6, r0, t_lo, t_hi, full=True)
        c["years"] = EV.yearly(days, rr, r0)
        E["configs"][name] = c
        E["daily"][name] = rr
        _detail(world, decl, c, Xw, cols, op6, qh, trades, hb, log)
        del trades, NETm, Xw
        gc.collect()
    E["rw"], _ = EV.family({k: E["daily"][k] for k in cands}, r0, decl)
    E["acceptance"] = {}
    for name in cands:
        c = E["configs"][name]
        acc = EV.acceptance(c["portfolio"], E["open_sb"], c["research"]["majors"]["capture_share"], c["years"],
                            E["rw"][name]["p_adj"], len(cands))
        acc["years"] = c["years"]
        E["acceptance"][name] = acc
    E["best"] = cands[0]
    E["variant_best"] = {}
    for name in cands:
        E["variant_best"].setdefault(E["configs"][name]["variant"], name)
    E["seconds"] = round(time.time() - t0, 1)
    E["memory"] = XC.mem_text()
    return E


# ============================================================================ outputs (per engine, then combined)
CSV_NAMES = ("ledger_research.csv", "ledger_execution.csv", "configs.csv", "state_tables.csv", "cards_setup.csv",
             "cards_exit.csv")


def engine_done(od, eng, tag):
    f = od / eng / "DONE.json"
    if not f.exists():
        return None
    try:
        dn = json.loads(f.read_text(encoding="utf-8"))
    except ValueError:
        return None
    return dn if dn.get("run") == tag else None


def save_engine(od, tag, eng, E, models, decl, sealed):
    """Everything of one engine into its own folder <run>/<engine>; DONE.json last (no DONE.json = unfinished)."""
    ed = od / eng
    ed.mkdir(parents=True, exist_ok=True)
    dn = ed / "DONE.json"
    if dn.exists():
        dn.unlink()
    lr, le, cfgs, groups, sc, ec = [], [], [], [], [], []
    if not E.get("skipped"):
        w, op6 = E["world"], E["op6"]
        for name, c in E["configs"].items():
            lr += RP.ledger_rows(w, eng, name, c["res"], op6, decl)
            le += RP.ledger_rows(w, eng, name, c["exe"], op6, decl)
            m, p = c["research"], c["portfolio"]
            cfgs.append({"engine": eng, "config": name, "net": m["net"]["mean"], "net_lo": m["net"]["lo"],
                         "net_hi": m["net"]["hi"], "vs_open6": m["vs_open6"]["mean"], "vs_open6_lo": m["vs_open6"]["lo"],
                         "vs_open6_hi": m["vs_open6"]["hi"], "traded": m["trades"]["n"], "win": m["trades"]["win"],
                         "majors_capture": m["majors"]["capture_share"], "majors_missed": m["majors"]["missed"],
                         "bad_avoided": m["bad"]["avoided"], "false_trigger_share": m["false_triggers"]["share"],
                         "cagr": p["cagr"], "max_dd": p["max_dd"], "sharpe": p["sharpe"], "cagr_at_dd": p["at_dd"]["cagr"],
                         "excess": p["excess"]["mean"], "excess_lo": p["excess"]["lo"], "excess_hi": p["excess"]["hi"],
                         "rw_p": E.get("rw", {}).get(name, {}).get("p_adj"), "trades_book": p["trades"],
                         "budget_violations": sum(c["budget_check"].values())})
            groups += RP.group_csv_rows(eng, name, c["variant"], c.get("tables", {}))
            for k, cd in enumerate(c.get("setup_cards", []), 1):
                sc.append({"engine": eng, "config": name, "card": k, "rule": cd["rule"], "rows": cd["rows"],
                           "decided": cd["records_decided"], "actions": cd["actions"], "vs_open6": cd["vs_open6"]["mean"],
                           "lo": cd["vs_open6"].get("lo"), "hi": cd["vs_open6"].get("hi")})
            for k, cd in enumerate(c.get("exit_cards", []), 1):
                ec.append({"engine": eng, "config": name, "card": k, "rule": cd["rule"], "rows": cd["rows"],
                           "actions": cd["actions"]})
        days = w.D.cal.days[E["t_lo"]:E["t_hi"] + 1]
        names = list(E["daily"])
        RP.write_csv(ed / "daily_returns.csv", ["session"] + names,
                     [[str(dd)] + [float(E["daily"][k][q]) for k in names] for q, dd in enumerate(days)])
    RP.write_csv(ed / "ledger_research.csv", RP.LEDGER_COLS, lr)
    RP.write_csv(ed / "ledger_execution.csv", RP.LEDGER_COLS, le)
    RP.write_csv(ed / "configs.csv", list(cfgs[0]) if cfgs else ["engine", "config"], cfgs)
    RP.write_csv(ed / "state_tables.csv", RP.GROUP_COLS, groups)
    RP.write_csv(ed / "cards_setup.csv", ("engine", "config", "card", "rule", "rows", "decided", "actions", "vs_open6",
                                          "lo", "hi"), sc)
    RP.write_csv(ed / "cards_exit.csv", ("engine", "config", "card", "rule", "rows", "actions"), ec)
    (ed / "section.md").write_text("\n".join(RP.engine_section(eng, E, decl, sealed)) + "\n", encoding="utf-8")
    msha = None
    if models is not None and not sealed:
        blob = pickle.dumps({"version": XC.VERSION, "engine": eng, "models": models}, protocol=4)
        (ed / "models.pkl").write_bytes(blob)
        msha = XC.sha16_bytes(blob)
    summary = {"run": tag, "engine": eng, "when": time.strftime("%Y-%m-%d %H:%M:%S"), "skipped": E.get("skipped"),
               "n_rec": E.get("n_rec"), "candidates": E.get("candidates", []), "best": E.get("best"),
               "variant_best": E.get("variant_best", {}),
               "rw": {k: {kk: vv for kk, vv in v.items() if not isinstance(vv, np.ndarray)}
                      for k, v in E.get("rw", {}).items()},
               "acceptance": E.get("acceptance"), "models_sha16": msha, "seconds": E.get("seconds"),
               "memory": E.get("memory")}
    dn.write_text(json.dumps(summary, indent=1, default=_json), encoding="utf-8")
    return summary


def combine(od, tag, run, decl, engines, sealed, title):
    """REPORT.md, the combined CSVs, RUN.json (and for a discovery models.pkl and candidates.json) from every
    finished engine of the run."""
    done = {e: engine_done(od, e, tag) for e in engines}
    sections = {e: (od / e / "section.md").read_text(encoding="utf-8").splitlines() if dn else None
                for e, dn in done.items()}
    pending = [e for e, dn in done.items() if not dn]
    for nm in CSV_NAMES:
        RP.concat_csv(od / nm, [od / e / nm for e, dn in done.items() if dn])
    run = dict(run, engines_done=[e for e, dn in done.items() if dn], engines_pending=pending)
    (od / "RUN.json").write_text(json.dumps(run, indent=1, sort_keys=True, default=_json), encoding="utf-8")
    RP.report(od / "REPORT.md", title, run, sections, decl, sealed, pending)
    if sealed:
        return done
    models = {}
    for e, dn in done.items():
        if dn and (od / e / "models.pkl").exists():
            models[e] = pickle.loads((od / e / "models.pkl").read_bytes())["models"]
    blob = pickle.dumps({"version": XC.VERSION, "models": models}, protocol=4)
    (od / "models.pkl").write_bytes(blob)
    cand = {"run": tag, "decl_fingerprint": decl["_fingerprint"], "overrides": run["overrides"], "ranks": run["ranks"],
            "models_sha16": XC.sha16_bytes(blob), "code": XC.code_hashes(), "versions": versions(),
            "rule": decl["candidates"]["rule"], "engines_requested": run.get("engines_requested", engines),
            "engines_done": run["engines_done"],
            "candidates": {e: dn.get("candidates", []) for e, dn in done.items() if dn},
            "rw": {e: dn.get("rw", {}) for e, dn in done.items() if dn}}
    (od / "candidates.json").write_text(json.dumps(cand, indent=1, default=_json), encoding="utf-8")
    return done


# ============================================================================ commands
def _decl(a):
    decl = XC.load_decl(a.decl)
    over = {}
    if getattr(a, "quick", False):
        for k, v in QUICK.items():
            set_path(decl, k, v)
            over[k] = v
    for k in ("model",):
        v = getattr(a, k, None)
        if v:
            set_path(decl, "learning.model", v)
            over["learning.model"] = v
    if getattr(a, "folds", None):
        set_path(decl, "learning.folds", int(a.folds))
        over["learning.folds"] = int(a.folds)
    return decl, over


def _requested(od, engines):
    f = od / "RUN.json"
    prev = []
    if f.exists():
        try:
            prev = json.loads(f.read_text(encoding="utf-8")).get("engines_requested", [])
        except ValueError:
            prev = []
    return list(dict.fromkeys(list(prev) + list(engines)))


def cmd_discover(a, loader, log):
    decl, over = _decl(a)
    variants = list(decl["variants"])
    hurdles = [int(x) for x in decl["hurdles_bp"]]
    if a.variants:
        variants = [v for v in a.variants.split(",") if v]
        over["variants"] = variants
    for v in variants:
        F.columns("watch", v)                       # unknown variant -> refused before anything is loaded
    if a.hurdles:
        hurdles = [int(x) for x in a.hurdles.split(",") if x != ""]
        over["hurdles_bp"] = hurdles
    dd = decl["data"]
    a.pm_run = a.pm_run or dd["pm_run"]
    t_from = a.d_from or dd["discovery_from"]
    t_to = a.d_to or dd["discovery_to"]
    if np.datetime64(t_to, "D") > np.datetime64(dd["discovery_to"], "D"):
        log("REFUSED: discovery ends at %s; 2023-25 stays sealed until freeze (then: evaluate)" % dd["discovery_to"])
        return 3
    if t_from != dd["discovery_from"]:
        over["from"] = t_from
    if t_to != dd["discovery_to"]:
        over["to"] = t_to
    if a.pm_run != dd["pm_run"]:
        over["pm_run"] = a.pm_run
    for k in ("max_symbols", "stage_e_any", "tradelab_any"):
        if getattr(a, k, None):
            over[k] = getattr(a, k)
    if a.costs != "stage_e":
        over["costs"] = a.costs
    out = XC.guard_out(a.out, a.root)
    key = {"decl": decl["_fingerprint"], "over": over, "code": XC.code_hashes(), "pm_run": a.pm_run,
           "ranks": a.ranks, "from": t_from, "to": t_to, "root": str(a.root)}
    rid = XC.sha16_obj(key)
    tag = "disc_%s%s" % (rid, "" if a.ranks == [1, 2, 3] else "_r%d-%d" % (min(a.ranks), max(a.ranks)))
    od = out / tag
    todo = [e for e in a.engines if a.again or not engine_done(od, e, tag)]
    if not todo:
        log("REFUSED: %s already holds this exact run for %s (same declaration, code, data and settings); --again "
            "repeats it" % (od, ", ".join(a.engines)))
        return 3
    kept = [e for e in a.engines if e not in todo]
    t0 = time.time()
    XC.ledger_append(out, {"cmd": "discover", "run": tag, "start": time.strftime("%Y-%m-%d %H:%M:%S"),
                           "engines": todo, "kept": kept, **key})
    log("execlab discover %s -> %s%s" % (XC.VERSION, od, ("  (kept, already finished: %s)" % ", ".join(kept))
                                         if kept else ""))
    D = loader(a, decl, t_from, t_to, t_to, log)
    if np.datetime64(D.cal.days[-1], "D") > np.datetime64(dd["discovery_to"], "D"):
        raise XC.XLError("the loaded calendar ends after the discovery period (%s): refusing" % D.cal.days[-1])
    B = S.Bars(D, sorted({s.symbol for s in D.registry.active()}), int(decl["window"]["lock_wait"]))
    fs = F.FeatureStore(D, B)
    log("   data ready: %d stocks x %d sessions (%s)" % (len(B.syms), D.cal.n, XC.mem_text()))
    od.mkdir(parents=True, exist_ok=True)
    requested = _requested(od, a.engines)
    run = {"version": XC.VERSION, "decl_fingerprint": decl["_fingerprint"], "when": time.strftime("%Y-%m-%d %H:%M"),
           "t_from": t_from, "t_to": t_to, "data_to": str(D.cal.days[-1]), "ranks": a.ranks, "engines": requested,
           "engines_requested": requested, "overrides": over, "code": XC.code_hashes(), "versions": versions(),
           "data": D.info, "variants": variants, "hurdles_bp": hurdles}
    title = "execlab discovery"
    for eng in todo:
        E, mdl = engine_discover(D, decl, eng, a.ranks, t_from, t_to, B, fs, variants, hurdles, log,
                                 work=od / "_work")
        save_engine(od, tag, eng, E, mdl, decl, sealed=False)
        del E, mdl
        gc.collect()
        combine(od, tag, dict(run, seconds=round(time.time() - t0, 1)), decl, requested, False, title)
        log("   %s written: %s" % (eng, od / eng))
    done = combine(od, tag, dict(run, seconds=round(time.time() - t0, 1)), decl, requested, False, title)
    try:
        (od / "_work").rmdir()
    except OSError:
        pass
    cand = {e: dn.get("candidates", []) for e, dn in done.items() if dn}
    XC.ledger_append(out, {"cmd": "discover", "run": tag, "done": time.strftime("%Y-%m-%d %H:%M:%S"),
                           "engines": todo, "candidates": cand, "seconds": round(time.time() - t0, 1)})
    log("done in %.0f s: %s" % (time.time() - t0, od / "REPORT.md"))
    for e, c in cand.items():
        log("   %s candidates: %s" % (e, ", ".join(c) or "none"))
    pend = [e for e, dn in done.items() if not dn]
    if pend:
        log("   not finished yet: %s (the same command with --engines %s resumes this run)" % (
            ", ".join(pend), ",".join(pend)))
    return 0


def cmd_freeze(a, log):
    out = XC.guard_out(a.out, getattr(a, "root", None))
    decl = XC.load_decl(a.decl)
    od = out / a.run
    fz = out / "FROZEN.json"
    try:
        cand = json.loads((od / "candidates.json").read_text(encoding="utf-8"))
    except FileNotFoundError:
        log("REFUSED: %s has no candidates.json (run discover first)" % od)
        return 3
    why = []
    if cand["overrides"]:
        why.append("the run changed declared settings %s (freeze needs a run with the declaration as written)" %
                   cand["overrides"])
    if cand["decl_fingerprint"] != decl["_fingerprint"]:
        why.append("the declaration changed since the run")
    if cand["code"] != XC.code_hashes():
        why.append("the code changed since the run")
    if cand["ranks"] != [1, 2, 3]:
        why.append("ranks %s is the separate experiment; only the top-3 universe is frozen" % cand["ranks"])
    miss = [e for e in cand.get("engines_requested", []) if e not in cand.get("engines_done", [])]
    if miss:
        why.append("engine(s) %s of this run are not finished (run the same discover command again: it resumes)" %
                   ", ".join(miss))
    if XC.sha16_file(od / "models.pkl") != cand["models_sha16"]:
        why.append("models.pkl does not match the run")
    if list(out.glob("eval_*")):
        why.append("a sealed evaluation already exists")
    if fz.exists() and not a.replace:
        why.append("FROZEN.json exists (--replace overwrites it while no evaluation has run)")
    if why:
        for w in why:
            log("REFUSED: " + w)
        return 3
    if not any(cand["candidates"].values()):
        log("Nothing to freeze: no engine has a candidate under the declared rule. That is the result.")
        XC.ledger_append(out, {"cmd": "freeze", "run": a.run, "result": "no candidate"})
        return 0
    fr = {"version": XC.VERSION, "frozen": time.strftime("%Y-%m-%d %H:%M:%S"), "run": a.run,
          "decl_fingerprint": decl["_fingerprint"], "code": XC.code_hashes(), "versions": cand["versions"],
          "models": str(od / "models.pkl"), "models_sha16": cand["models_sha16"], "candidates": cand["candidates"],
          "acceptance": decl["acceptance"], "sealed_from": decl["data"]["sealed_from"],
          "sealed_to": decl["data"]["sealed_to"]}
    fz.write_text(json.dumps(fr, indent=1), encoding="utf-8")
    XC.ledger_append(out, {"cmd": "freeze", "run": a.run, "frozen": fr["frozen"], "candidates": fr["candidates"],
                           "models_sha16": fr["models_sha16"]})
    log("FROZEN: %s" % fz)
    for e, c in fr["candidates"].items():
        log("   %s: %s" % (e, ", ".join(c) or "none"))
    return 0


def cmd_evaluate(a, loader, log):
    out = XC.guard_out(a.out, a.root)
    decl = XC.load_decl(a.decl)
    fz = out / "FROZEN.json"
    if not fz.exists():
        log("REFUSED: no FROZEN.json in %s (discover, then freeze)" % out)
        return 3
    fr = json.loads(fz.read_text(encoding="utf-8"))
    tag = "eval_%s" % XC.sha16_obj({"frozen": fr, "root": str(a.root)})
    od = out / tag
    evals = sorted(out.glob("eval_*"))
    why = []
    if fr["decl_fingerprint"] != decl["_fingerprint"]:
        why.append("the declaration changed after the freeze")
    if fr["code"] != XC.code_hashes():
        why.append("the code changed after the freeze")
    if not Path(fr["models"]).exists():
        why.append("the frozen models file %s is missing (the discovery folder was moved or deleted)" % fr["models"])
    elif XC.sha16_file(fr["models"]) != fr["models_sha16"]:
        why.append("the frozen models file changed")
    if versions().get("sklearn") != fr["versions"].get("sklearn") and decl["learning"]["model"] == "hgb":
        why.append("scikit-learn is %s, the models were fitted with %s" % (versions().get("sklearn"),
                                                                          fr["versions"].get("sklearn")))
    if [p for p in evals if p.name != tag]:
        why.append("the sealed evaluation already ran (one shot): %s" % [p.name for p in evals])
    todo = [e for e in a.engines if not engine_done(od, e, tag)]
    if od.exists() and not todo:
        why.append("the sealed evaluation already ran for %s (one shot): %s" % (", ".join(a.engines), od))
    if why:
        for w in why:
            log("REFUSED: " + w)
        return 3
    kept = [e for e in a.engines if e not in todo]
    a.pm_run = a.pm_run or decl["data"]["pm_run"]
    blob = pickle.loads(Path(fr["models"]).read_bytes())
    models = blob["models"]
    t_from, t_to = fr["sealed_from"], fr["sealed_to"]
    od.mkdir(parents=True, exist_ok=True)
    XC.ledger_append(out, {"cmd": "evaluate", "run": tag, "start": time.strftime("%Y-%m-%d %H:%M:%S"),
                           "frozen": fr["frozen"], "candidates": fr["candidates"], "engines": todo, "kept": kept})
    t0 = time.time()
    a.ranks = [1, 2, 3]
    D = loader(a, decl, t_from, t_to, t_to, log)
    B = S.Bars(D, sorted({s.symbol for s in D.registry.active()}), int(decl["window"]["lock_wait"]))
    fs = F.FeatureStore(D, B)
    run = {"version": XC.VERSION, "decl_fingerprint": decl["_fingerprint"], "when": time.strftime("%Y-%m-%d %H:%M"),
           "t_from": t_from, "t_to": t_to, "data_to": str(D.cal.days[-1]), "ranks": [1, 2, 3], "engines": a.engines,
           "engines_requested": a.engines, "overrides": {}, "code": XC.code_hashes(), "versions": versions(),
           "data": D.info, "frozen": fr}
    title = "execlab sealed evaluation 2023-25"
    for eng in todo:
        E = engine_evaluate(D, decl, eng, [1, 2, 3], t_from, t_to, B, fs, fr["candidates"].get(eng, []),
                            models.get(eng, {}), log)
        save_engine(od, tag, eng, E, None, decl, sealed=True)
        del E
        gc.collect()
        combine(od, tag, dict(run, seconds=round(time.time() - t0, 1)), decl, a.engines, True, title)
    done = combine(od, tag, dict(run, seconds=round(time.time() - t0, 1)), decl, a.engines, True, title)
    verdict = {e: (dn or {}).get("acceptance") or {} for e, dn in done.items()}
    XC.ledger_append(out, {"cmd": "evaluate", "run": tag, "done": time.strftime("%Y-%m-%d %H:%M:%S"),
                           "verdict": {e: {k: v["ACCEPTED"] for k, v in d.items()} for e, d in verdict.items()}})
    log("done: %s" % (od / "REPORT.md"))
    for e, d in verdict.items():
        for k, v in d.items():
            log("   %s %s: %s" % (e, k, "ACCEPTED" if v["ACCEPTED"] else "rejected (%s)" % ", ".join(
                x for x in ("A1", "A2", "A3", "A4") if not v[x])))
    return 0


def cmd_why(a, log):
    """What the engines' top-3 picks have in common in the panel (discovery period only; exploratory)."""
    import xl_why as XW
    decl = XC.load_decl(a.decl)
    cfg = decl["why"]
    dd = decl["data"]
    t_from = a.d_from or dd["discovery_from"]
    t_to = a.d_to or dd["discovery_to"]
    if np.datetime64(t_to, "D") > np.datetime64(dd["discovery_to"], "D"):
        log("REFUSED: why reads the discovery period only (to %s)" % dd["discovery_to"])
        return 3
    if not a.root or not Path(a.root).is_dir():
        log("ERROR: --root is required (no silent default cache path)")
        return 2
    out = XC.guard_out(a.out, a.root)
    pm_run = a.pm_run or dd["pm_run"]
    panel = a.panel or cfg["panel"]
    import v2_data as VD
    TC, TD, TS, TX = VD.tradelab_modules(a.tradelab_any)
    key = {"decl": decl["_fingerprint"], "code": XC.code_hashes(), "pm_run": pm_run, "engines": a.engines,
           "from": t_from, "to": t_to, "root": str(a.root), "panel": panel}
    tag = "why_%s" % XC.sha16_obj(key)
    od = out / tag
    if (od / "WHY.md").exists() and not a.again:
        log("REFUSED: %s already holds this exact why run; --again repeats it" % od)
        return 3
    t0 = time.time()
    XC.ledger_append(out, {"cmd": "why", "run": tag, "start": time.strftime("%Y-%m-%d %H:%M:%S"), **key})
    log("execlab why %s -> %s" % (XC.VERSION, od))
    T, pinfo = TD.load_picks(Path(a.root), pm_run, list(a.engines), [1, 2, 3], np.datetime64(t_from, "D"),
                             np.datetime64(t_to, "D"))
    import pandas as pd
    picks = pd.DataFrame({"engine": T["engine"].astype(str).to_numpy(), "day": TC.to_day(T["signal_day"]),
                          "symbol": T["symbol"].astype(str).to_numpy(), "rank": T["rank"].astype(int).to_numpy()})
    if "net" in T.columns:
        picks["net"] = pd.to_numeric(T["net"], errors="coerce").to_numpy(dtype=float)
    pf = TD.PanelFeatures(Path(a.root), panel)
    feats = list(pf.allowed)
    reader = XW.PanelReader(pf.path, pf.tcol, t_from, t_to, to_day_fn=TC.to_day, log=log)
    res = XW.analyse(reader, feats, picks, cfg, dict(decl["stats"]), log)
    run = {"version": XC.VERSION, "when": time.strftime("%Y-%m-%d %H:%M"), "t_from": t_from, "t_to": t_to,
           "panel": panel, "features": len(feats), "dropped": {k: (len(v) if isinstance(v, list) else v)
                                                              for k, v in pf.dropped.items()},
           "controls_per_day": int(cfg["controls_per_day"]), "picks_file": pinfo.get("file"), "key": key,
           "seconds": round(time.time() - t0, 1), "memory": XC.mem_text()}
    XW.write(od, res, run, log)
    (od / "RUN.json").write_text(json.dumps(run, indent=1, default=_json), encoding="utf-8")
    XC.ledger_append(out, {"cmd": "why", "run": tag, "done": time.strftime("%Y-%m-%d %H:%M:%S"),
                           "auc": {e: r.get("auc") for e, r in res.items()}, "seconds": run["seconds"]})
    log("done in %.0f s: %s" % (time.time() - t0, od / "WHY.md"))
    return 0


def cmd_status(a, log):
    out = Path(a.out)
    log("execlab %s, output folder %s" % (XC.VERSION, out))
    for p in sorted(out.glob("disc_*")):
        c = p / "candidates.json"
        if c.exists():
            cc = json.loads(c.read_text(encoding="utf-8"))
            pend = [e for e in cc.get("engines_requested", []) if e not in cc.get("engines_done", [])]
            log("   %s: candidates %s%s" % (p.name, cc["candidates"], ("; NOT FINISHED: %s (the same discover "
                                                                        "command resumes)" % ", ".join(pend))
                                          if pend else ""))
        else:
            log("   %s: unfinished (no engine finished yet)" % p.name)
    for p in sorted(out.glob("why_*")):
        log("   %s: %s" % (p.name, "WHY.md" if (p / "WHY.md").exists() else "unfinished"))
    fz = out / "FROZEN.json"
    log("   FROZEN.json: %s" % (json.loads(fz.read_text(encoding="utf-8"))["frozen"] if fz.exists() else "none"))
    for p in sorted(out.glob("eval_*")):
        log("   %s (sealed evaluation)" % p.name)
    return 0


def main(argv=None, loader=None, log=print):
    ap = argparse.ArgumentParser(prog="execlab", description=XC.VERSION)
    ap.add_argument("--selftest", nargs="?", const="full", default=None)
    sub = ap.add_subparsers(dest="cmd")
    for nm in ("discover", "why", "freeze", "evaluate", "status"):
        p = sub.add_parser(nm)
        p.add_argument("--out", required=False, default=os.environ.get("XL_OUT"))
        p.add_argument("--decl", default=None)
        if nm in ("discover", "evaluate", "why"):
            p.add_argument("--root", default=None)
            p.add_argument("--pm-run", default=None, help="default: the declaration's data.pm_run")
            p.add_argument("--engines", default="D,ENS")
            p.add_argument("--stage-e-any", action="store_true")
            p.add_argument("--tradelab-any", action="store_true")
            p.add_argument("--costs", default="stage_e", choices=("stage_e", "replica"))
            p.add_argument("--max-symbols", type=int, default=None)
        if nm == "why":
            p.add_argument("--panel", default=None, help="default: the declaration's why.panel (panel_oc)")
            p.add_argument("--from", dest="d_from", default=None)
            p.add_argument("--to", dest="d_to", default=None)
            p.add_argument("--again", action="store_true")
        if nm == "discover":
            p.add_argument("--ranks", default="1-3")
            p.add_argument("--from", dest="d_from", default=None)
            p.add_argument("--to", dest="d_to", default=None)
            p.add_argument("--quick", action="store_true")
            p.add_argument("--variants", default=None)
            p.add_argument("--hurdles", default=None)
            p.add_argument("--model", default=None, choices=("hgb", "ridge"))
            p.add_argument("--folds", type=int, default=None)
            p.add_argument("--again", action="store_true")
        if nm == "freeze":
            p.add_argument("--run", required=True)
            p.add_argument("--replace", action="store_true")
    a = ap.parse_args(argv)
    if a.selftest:
        sys.path.insert(0, str(HERE / "tests"))
        import test_execlab
        return test_execlab.main(["quick"] if a.selftest == "quick" else [])
    if not a.cmd:
        ap.print_help()
        return 2
    if not a.out:
        log("ERROR: --out is required (or set XL_OUT); there is no default output folder")
        return 2
    try:
        if a.cmd in ("discover", "evaluate"):
            if loader is None and not a.root:
                log("ERROR: --root is required (no silent default cache path)")
                return 2
            a.engines = [e for e in a.engines.split(",") if e]
            if a.cmd == "discover":
                a.ranks = parse_ranks(a.ranks)
            fn = cmd_discover if a.cmd == "discover" else cmd_evaluate
            return fn(a, loader or real_loader, log)
        if a.cmd == "why":
            a.engines = [e for e in a.engines.split(",") if e]
            return cmd_why(a, log)
        if a.cmd == "freeze":
            return cmd_freeze(a, log)
        return cmd_status(a, log)
    except XC.XLError as e:
        log("ERROR: %s" % e)
        return 3


if __name__ == "__main__":
    sys.exit(main())
