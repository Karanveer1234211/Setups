r"""xl_sim.py - execlab v1.1: fills, position paths and trade costs on daily bars (orders decided at a close act in
the next session only).

Entry orders (session i = decision close a + 1; ATR = ATR(a)):
  OPEN    market at the open
  BSTOP   buy stop at the close + 0.5 ATR        BHIGH  buy stop at the day's high + 0.1 ATR
  SWHI    buy stop at the last confirmed swing high + 0.1 ATR (placed only while that trigger is above the close)
  LVL_RC  buy stop at the event's level + 0.25 ATR (a reclaim: placed only while that trigger is above the close)
          every buy stop fills when the high reaches the trigger, at max(open, trigger) + 0.05 ATR, never above the
          day's high
  LDIP / LDEEP  limit at the close - 0.5 / 1 ATR
  ODIP    limit at the entry session's own open - 0.25 ATR (placed right after the open)
  LVL_RT  limit at the event's level + 0.25 ATR (a retest: placed only while that limit is below the close)
          every limit needs the low strictly below it and fills at min(open, limit)
  nothing fills on a missing bar, an upper-locked bar or a session that takes no entries.
Hold orders (age h = sessions since the entry session's close; at h = 40 the position is sold at the next open):
  KEEP  nothing         EXIT  sell at the next open; a lower-locked open waits for the first unlocked open within 20
                              sessions (none: the close of the last session searched, STUCK)
  STOPm   sell stop at close - m ATR(i)
  STOP_SW sell stop at the last confirmed swing low - 0.25 ATR(i)   STOP_LV  at the event's level - 0.25 ATR(i)
          (both offered only while the stop is below the close); every stop: a gap through fills at the open - 0.05
          ATR, inside the day at the stop - 0.05 ATR (never below the low); no fill on a frozen lower-locked bar or
          at a locked open
  TP2   sell limit at close + 2 ATR: the open if it opens above, else the limit when the high trades through it
An order that cannot be placed (no level, wrong side) is not a choice: entry_avail / hold_avail say which are.
Every trade's reported net is stage E's (v2_money.CostModel.trade at the research notional); inside the learning
recursions a per-position cost fraction stands in for it (the same parts at the notional, a 0.05 tick).
"""
import numpy as np

import xl_feat as F
from xl_common import XLError

ENTRY = ("OPEN", "BSTOP", "BHIGH", "LDIP", "LDEEP", "ODIP", "LVL_RT", "LVL_RC", "SWHI")
ENTRY_CLASS = {"OPEN": "market", "BSTOP": "stop", "BHIGH": "stop", "LDIP": "limit", "LDEEP": "limit",
               "ODIP": "limit", "LVL_RT": "limit", "LVL_RC": "stop", "SWHI": "stop"}
STOP_KINDS = tuple(k for k, e in enumerate(ENTRY) if ENTRY_CLASS[e] == "stop")
LIMIT_KINDS = tuple(k for k, e in enumerate(ENTRY) if ENTRY_CLASS[e] == "limit")
HOLDA = ("KEEP", "EXIT", "STOP1", "STOP2", "TP2", "STOP_SW", "STOP_LV")
REASONS = ("", "EXIT", "STOP1", "STOP2", "TP2", "FORCED", "STUCK", "END", "STOP_SW", "STOP_LV")
TIMING = ("", "open", "intraday", "close")


class Bars:
    """The stocks' bars stacked on the calendar: arrays (stocks, sessions)."""

    def __init__(self, D, symbols, lock_wait=20):
        self.D, self.cal, self.cm = D, D.cal, D.cm
        self.syms = list(symbols)
        self.k = {s: j for j, s in enumerate(self.syms)}
        n = D.cal.n
        self.n = n
        S = len(self.syms)
        f = lambda: np.full((S, n), np.nan)          # noqa: E731
        self.o, self.h, self.l, self.c, self.cf, self.atr, self.adv, self.vol = (f() for _ in range(8))
        self.ul, self.lk, self.llo, self.llc = (np.zeros((S, n), bool) for _ in range(4))
        for s, j in self.k.items():
            b = D.bars[s]
            for nm in ("open", "high", "low", "close", "atr", "adv", "vol20"):
                getattr(self, {"open": "o", "high": "h", "low": "l", "close": "c", "atr": "atr", "adv": "adv",
                               "vol20": "vol"}[nm])[j] = np.asarray(b[nm], dtype=float)
            self.ul[j] = np.asarray(b["upper_locked"], bool)
            self.lk[j] = np.asarray(b["lower_locked"], bool)
            self.llo[j] = np.asarray(b.get("ll_open", b["lower_locked"]), bool)
            self.llc[j] = np.asarray(b.get("ll_close", b["lower_locked"]), bool)
            c = self.c[j]
            idx = np.where(np.isfinite(c), np.arange(n), -1)
            np.maximum.accumulate(idx, out=idx)
            self.cf[j] = np.where(idx >= 0, c[np.maximum(idx, 0)], np.nan)
        # tl_state's state / event codes, the shown event's level, the last confirmed swing high / low (calendar)
        self.st = np.full((S, n), -1, dtype=np.int16)
        self.ev = np.zeros((S, n), dtype=np.int16)
        self.lvl, self.swh, self.swl = f(), f(), f()
        ctx = getattr(D, "ctx", {}) or {}
        evs = getattr(D, "events", {}) or {}
        for s, j in self.k.items():
            cx = ctx.get(s)
            if cx is not None:
                self.st[j] = np.asarray(cx["state"], dtype=np.int64)
                self.ev[j] = np.asarray(cx["event"], dtype=np.int64)
            self.lvl[j] = F.event_level(self.ev[j], evs.get(s))
            self.swh[j], self.swl[j] = F.swings(self.h[j], self.l[j])
        self.entry_ok = np.asarray(D.cal.entry_ok, bool)
        # first session k >= i with an unlocked open, within lock_wait sessions (-1: none)
        good = np.isfinite(self.o) & ~self.llo
        nxt = np.full((S, n + 1), -1, dtype=np.int64)
        for i in range(n - 1, -1, -1):
            nxt[:, i] = np.where(good[:, i], i, nxt[:, i + 1])
        lim = np.arange(n)[None, :] + lock_wait
        self.nxt_open = np.where((nxt[:, :n] >= 0) & (nxt[:, :n] <= lim), nxt[:, :n], -1)
        self.lock_wait = lock_wait
        N = float(D.cm.notional)
        self.N = N
        self.s0 = D.cm.sell_costs(N, True, N) / N
        self.b0 = D.cm.buy_costs(N) / N

    def impact(self, j, e):
        """Impact fraction of the research notional for entries at sessions e (ADV, vol20 at e - 1)."""
        j, e = np.asarray(j), np.asarray(e)
        adv, vol = self.adv[j, e - 1], self.vol[j, e - 1]
        ok = np.isfinite(adv) & (adv > 0) & np.isfinite(vol)
        out = np.zeros(len(j))
        if self.cm.SE is None:
            from v2_money import IMPACT_K
            out[ok] = IMPACT_K * vol[ok] * np.sqrt(self.N / adv[ok])
        else:
            for q in np.flatnonzero(ok):
                out[q] = self.cm.impact(self.N, adv[q], vol[q])
        return out


def _ref(B, j, a, ref):
    if ref == "event_level":
        return B.lvl[j, a]
    if ref == "swing_high":
        return B.swh[j, a]
    if ref == "swing_low":
        return B.swl[j, a]
    raise XLError("unknown order reference %r" % ref)


def entry_avail(B, j, a, kind, decl_menu):
    """Can the order be placed at closes a? (a decision close with a bar; a level order needs its level on the
    right side of the close)."""
    j, a = np.asarray(j, dtype=np.int64), np.asarray(a, dtype=np.int64)
    m = decl_menu[kind]
    c, atr = B.c[j, a], B.atr[j, a]
    ok = np.isfinite(c)
    if m["type"] == "market_open":
        return ok
    ok &= np.isfinite(atr) & (atr > 0)
    if m["type"] in ("buy_stop", "buy_limit", "open_limit"):
        return ok
    x = _ref(B, j, a, m["ref"]) + m["atr"] * atr
    with np.errstate(invalid="ignore"):
        if m["type"] == "level_limit":
            return ok & np.isfinite(x) & (x < c)
        if m["type"] in ("level_stop", "swing_stop"):
            return ok & np.isfinite(x) & (x > c)
    raise XLError("unknown entry type %r" % m["type"])


def entry_fill(B, j, a, kind, decl_menu, stop_slip=0.05):
    """Orders decided at closes a for sessions a + 1. Returns (filled bool, raw fill price)."""
    j, a = np.asarray(j, dtype=np.int64), np.asarray(a, dtype=np.int64)
    i = a + 1
    ok = i <= B.n - 1
    ii = np.minimum(i, B.n - 1)
    o, h, l = B.o[j, ii], B.h[j, ii], B.l[j, ii]
    ok &= np.isfinite(o) & ~B.ul[j, ii] & B.entry_ok[ii]
    ok &= entry_avail(B, j, a, kind, decl_menu)
    atr, c, hi = B.atr[j, a], B.c[j, a], B.h[j, a]
    px = np.full(len(j), np.nan)
    m = decl_menu[kind]
    with np.errstate(invalid="ignore"):
        if m["type"] == "market_open":
            f = ok
            px[f] = o[f]
        elif m["type"] in ("buy_stop", "level_stop", "swing_stop"):
            if m["type"] == "buy_stop":
                ref = c if m["ref"] == "close" else hi
            else:
                ref = _ref(B, j, a, m["ref"])
            trig = ref + m["atr"] * atr
            f = ok & np.isfinite(trig) & (h >= trig)
            px[f] = np.minimum(np.maximum(o[f], trig[f]) + stop_slip * atr[f], h[f])
        elif m["type"] in ("buy_limit", "level_limit", "open_limit"):
            if m["type"] == "buy_limit":
                lim = c + m["atr"] * atr
            elif m["type"] == "open_limit":
                lim = o + m["atr"] * atr
            else:
                lim = _ref(B, j, a, m["ref"]) + m["atr"] * atr
            f = ok & np.isfinite(lim) & (l < lim)
            px[f] = np.minimum(o[f], lim[f])
        else:
            raise XLError("unknown entry type %r" % m["type"])
    return f, px


def hold_avail(B, j, i, hold_menu):
    """(positions, len(HOLDA)) bool: which hold orders can be placed at closes i (KEEP / EXIT always)."""
    j, i = np.asarray(j, dtype=np.int64), np.asarray(i, dtype=np.int64)
    out = np.ones((len(j), len(HOLDA)), bool)
    c, atr = B.cf[j, i], B.atr[j, i]
    base = np.isfinite(c) & np.isfinite(atr) & (atr > 0)
    for q, name in enumerate(HOLDA):
        typ = hold_menu[name]["type"]
        if typ in ("keep", "sell_open"):
            continue
        if typ in ("sell_stop", "sell_limit"):
            out[:, q] = base
        elif typ == "sell_stop_level":
            stp = _ref(B, j, i, hold_menu[name]["ref"]) - hold_menu[name]["atr"] * atr
            with np.errstate(invalid="ignore"):
                out[:, q] = base & np.isfinite(stp) & (stp < c)
        else:
            raise XLError("unknown hold type %r" % typ)
    return out


def resolve_hold(B, j, i, act, hold_menu, exit_slip=0.05, H_end=None):
    """Positions of stocks j deciding at closes i with hold actions act (indices into HOLDA). Resolves session i + 1.
    Returns (done bool, exit session, raw exit price, reason code, timing code)."""
    n = B.n
    m = len(j)
    done = np.zeros(m, bool)
    xs = np.full(m, -1, dtype=np.int64)
    px = np.full(m, np.nan)
    rc = np.zeros(m, np.int8)
    tc = np.zeros(m, np.int8)
    nx = i + 1
    inb = nx <= n - 1
    nxc = np.minimum(nx, n - 1)
    c, atr = B.cf[j, i], B.atr[j, i]
    o, h, l = B.o[j, nxc], B.h[j, nxc], B.l[j, nxc]
    for q, name in enumerate(HOLDA):
        sel = act == q
        if not sel.any() or name == "KEEP":
            continue
        typ = hold_menu[name]["type"]
        if typ == "sell_open":
            k = np.where(inb, B.nxt_open[j, nxc], -1)
            s = sel & (k >= 0)
            done[s], xs[s], px[s], tc[s] = True, k[s], B.o[j[s], k[s]], 1
            stuck = sel & (k < 0) & inb
            kk = np.minimum(nx + B.lock_wait, n - 1)
            done[stuck], xs[stuck], px[stuck], tc[stuck] = True, kk[stuck], B.cf[j[stuck], kk[stuck]], 3
            rc[s] = REASONS.index("EXIT")
            rc[stuck] = REASONS.index("STUCK")
        elif typ in ("sell_stop", "sell_stop_level"):
            if typ == "sell_stop":
                stp = c - hold_menu[name]["atr"] * atr
            else:
                stp = _ref(B, j, i, hold_menu[name]["ref"]) - hold_menu[name]["atr"] * atr
                with np.errstate(invalid="ignore"):
                    stp = np.where(stp < c, stp, np.nan)          # not offered at or above the close
            live = sel & inb & np.isfinite(o) & np.isfinite(stp) & ~B.lk[j, nxc]
            gap = live & (o <= stp) & ~B.llo[j, nxc]
            ins = live & ~(o <= stp) & (l <= stp)
            slip = exit_slip * atr
            done[gap], xs[gap], px[gap], tc[gap] = True, nx[gap], np.maximum(o[gap] - slip[gap], l[gap]), 1
            done[ins], xs[ins], px[ins], tc[ins] = True, nx[ins], np.maximum(stp[ins] - slip[ins], l[ins]), 2
            rc[gap | ins] = REASONS.index(name)
        elif typ == "sell_limit":
            tp = c + hold_menu[name]["atr"] * atr
            live = sel & inb & np.isfinite(o) & np.isfinite(tp) & ~B.lk[j, nxc]
            go = live & (o >= tp) & ~B.llo[j, nxc]
            ins = live & ~(o >= tp) & (h > tp)
            done[go], xs[go], px[go], tc[go] = True, nx[go], o[go], 1
            done[ins], xs[ins], px[ins], tc[ins] = True, nx[ins], tp[ins], 2
            rc[go | ins] = REASONS.index(name)
        else:
            raise XLError("unknown hold type %r" % typ)
    return done, xs, px, rc, tc


def hold_forward(B, pos, decide, H, hold_menu, exit_slip=0.05, chunk=60000, trace=None):
    """Runs positions forward under a hold policy. pos: dict of arrays j, e (entry session), P (raw fill), plus
    whatever decide needs. decide(sub_pos_index, h, i, runmax) -> action indices (it builds its own features).
    At age H (or the data's end) the position is sold at the next open / marked at the last close (END).
    Returns dict of arrays: x (exit session), px (raw exit), reason, timing, mfe / mae (best / worst high / low
    over the held sessions after the entry session, over the fill)."""
    npos = len(pos["j"])
    out = {"x": np.full(npos, -1, dtype=np.int64), "px": np.full(npos, np.nan), "reason": np.zeros(npos, np.int8),
           "timing": np.zeros(npos, np.int8), "mfe": np.full(npos, np.nan), "mae": np.full(npos, np.nan)}
    for c0 in range(0, npos, chunk):
        ids = np.arange(c0, min(npos, c0 + chunk))
        j, e, P = pos["j"][ids], pos["e"][ids], pos["P"][ids]
        alive = np.ones(len(ids), bool)
        runmax = B.cf[j, e].copy()
        hi = np.full(len(ids), -np.inf)
        lo = np.full(len(ids), np.inf)
        for h in range(H + 1):
            q = np.flatnonzero(alive)
            if not len(q):
                break
            jj, ee = j[q], e[q]
            i = ee + h
            end = i >= B.n - 1
            ic = np.minimum(i, B.n - 1)
            if h > 0:
                hh, ll_ = B.h[jj, ic], B.l[jj, ic]
                hi[q] = np.where(np.isfinite(hh), np.maximum(hi[q], hh), hi[q])
                lo[q] = np.where(np.isfinite(ll_), np.minimum(lo[q], ll_), lo[q])
            runmax[q] = np.fmax(runmax[q], B.cf[jj, ic])
            if end.any():
                qe = q[end]
                out["x"][ids[qe]], out["px"][ids[qe]] = B.n - 1, B.cf[j[qe], B.n - 1]
                out["reason"][ids[qe]], out["timing"][ids[qe]] = REASONS.index("END"), 3
                alive[qe] = False
            q2 = q[~end]
            if not len(q2):
                continue
            i2 = e[q2] + h
            act = np.zeros(len(q2), np.int64)
            if h == H:
                act[:] = HOLDA.index("EXIT")
            else:
                miss = ~np.isfinite(B.c[j[q2], i2])
                dq = q2[~miss]
                if len(dq):
                    act[~miss] = decide(ids[dq], h, e[dq] + h, runmax[dq])
                    if trace is not None:
                        trace.append((ids[dq].copy(), np.full(len(dq), h), act[~miss].copy(), runmax[dq].copy()))
            done, xs, px, rc, tc = resolve_hold(B, j[q2], i2, act, hold_menu, exit_slip)
            if h == H:
                rc[done & (rc == REASONS.index("EXIT"))] = REASONS.index("FORCED")
            dd = q2[done]
            out["x"][ids[dd]], out["px"][ids[dd]] = xs[done], px[done]
            out["reason"][ids[dd]], out["timing"][ids[dd]] = rc[done], tc[done]
            alive[dd] = False
        with np.errstate(invalid="ignore", divide="ignore"):
            out["mfe"][ids] = np.where(np.isfinite(hi), hi / P - 1.0, 0.0)
            out["mae"][ids] = np.where(np.isfinite(lo), lo / P - 1.0, 0.0)
    return out


def trade_nets(B, j, e, P, x, px):
    """Stage E's fully net return of each trade (research notional, liquidity-capped)."""
    out = np.full(len(j), np.nan)
    for q in range(len(j)):
        if x[q] >= 0 and np.isfinite(px[q]) and np.isfinite(P[q]):
            out[q] = B.cm.trade(B.D.bars[B.syms[j[q]]], int(e[q]), float(P[q]), int(x[q]), float(px[q]))["net"]
    return out


def approx_net(B, j, e, P, x_px, imp=None):
    """The learning stand-in for a trade's net: (exit x (1 - sell fraction)) / (fill x (1 + buy fraction)) - 1."""
    imp = B.impact(j, e) if imp is None else imp
    with np.errstate(invalid="ignore", divide="ignore"):
        sf = B.s0 + imp + 0.05 / np.where(x_px > 0, x_px, np.nan)
        return x_px * (1.0 - sf) / (P * (1.0 + B.b0 + imp)) - 1.0


def comparators(B, recs):
    """OPEN6 and PLAN (fully net, stage E's lock rules) for every record; BLOCKED / no trade = NaN with a status."""
    import v2_core as C
    import v2_money as M
    M.install(B.cm)
    out = {k: np.full(len(recs["t"]), np.nan) for k in ("open6", "plan", "open6_gross", "plan_gross")}
    out["open6_x"] = np.full(len(recs["t"]), -1, dtype=np.int64)
    out["open6_px"] = np.full(len(recs["t"]), np.nan)
    out["open6_tim"] = np.ones(len(recs["t"]), np.int8)
    st = np.empty(len(recs["t"]), dtype=object)
    for q in range(len(recs["t"])):
        b = B.D.bars[recs["sym"][q]]
        d6 = C.plan_detail(b, B.cal, int(recs["t"][q]), "OPEN6")
        d5 = C.plan_detail(b, B.cal, int(recs["t"][q]), "CLOSE5")
        st[q] = d6["status"]
        if d6["status"] == "TRADE":
            out["open6"][q], out["open6_gross"][q] = d6["net"], d6["gross"]
            out["open6_x"][q], out["open6_px"][q] = d6["exit_idx"], d6["exit_raw"]
            out["open6_tim"][q] = 1 if d6["timing"] == "open" else 3
        if d5["status"] == "TRADE":
            out["plan"][q], out["plan_gross"][q] = d5["net"], d5["gross"]
    out["status"] = st
    return out
