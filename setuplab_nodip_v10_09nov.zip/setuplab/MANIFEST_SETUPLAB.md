# MANIFEST - setuplab v1.0 (8 Nov 2026: nodip - the no-dip study v2; on top of v0.9's runners and v0.8's frozen setups, zones and TradingView indicator)

Folder: C:\Users\karanvsi\PyCharmMiscProject\setuplab\ (tests in setuplab\tests\). v1.0 changes three files: setuplab.py, tests\test_setuplab.py, README_SETUPLAB.md (and this manifest); the others are v0.8's, unchanged. FROZEN_SETUPS.json is the freeze (never edit it: a changed copy is refused). Writes only under --out (C:\QuantData\setuplab). The scan, the zones, the runners and nodip read tradelab's readers (tradelab with the setups add-on on PYTHONPATH: env_tradelab.bat or env_playbook.bat); the self-test also reads production's features_daily.py (bigmove_deploy on PYTHONPATH). Python with numpy, pandas, pyarrow. BigMove_Setups.pine goes into TradingView's Pine Editor.

| file | sha256 (first 16) | bytes | lines | v1.0 |
|---|---|---|---|---|
| setuplab.py | 7f5a9da61fee13a6 | 304383 | 5504 | changed: the nodip command; the session before the pick (on request) |
| FROZEN_SETUPS.json | bed8fd610cf686af | 24439 | 935 | unchanged |
| BigMove_Setups.pine | 1904f972378eb49c | 24113 | 588 | unchanged |
| features_final.txt | bcb6c16bdfd7513d | 1689 | 60 | unchanged |
| README_SETUPLAB.md | 6c563483115076aa | 34866 | 429 | changed: the v1.0 section |
| tests\test_setuplab.py | 4d9d69473143806b | 105604 | 1663 | changed: n1-n5 |
| tests\pine_mirror.py | 326cb336f1c7e96c | 13337 | 337 | unchanged |

FROZEN_SETUPS.json's own sha256 (inside the file): 483f1539324f3ae5... (`python setuplab.py frozen` prints FROZEN FILE OK).

Verified where it was built: 79 self-test checks, 0 failed, with pandas 2.3.3 / numpy 2.4.1 (Karan's versions) and pandas 3.0.5 / numpy 2.5.3. v0.6's 38; v0.7's f1-f14; v0.8's z1-z6 and p1-p3; v0.9's r1-r7; v1.0's n1-n5 (8 checks): pooling by hand; every condition by hand; planted, moderate, absent and fading worlds (the replay's cut-offs from the training years only; the earn-its-place test is what keeps a true rule first when the edge is moderate); the session before the pick = the panel's own value and change, the candles = the bars, by hand; the nodip command end to end. Reading the session before the pick leaves every existing command's numbers unchanged (it is off unless nodip asks for it; checked). Planted bugs caught: v0.8 5 of 5; v0.9 8 of 8; v1.0 7 of 7. Runtime at Karan's scale (22,854 pooled stock-days, 839 conditions, 360,480 rules): search 29 s, replay 107 s, peak memory 0.84 GB. The Pine has not been compiled by TradingView.
